import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { ExpedienteResumenService } from '../../core/services/expediente-resumen.service';
import { ExpedienteResumen } from '../../core/models/expediente-resumen';
import { RedactarOficioDialog, RedactarOficioDialogData } from '../../shared/redactar-oficio-dialog/redactar-oficio-dialog';
import { RecordatorioDialog, RecordatorioDialogData } from '../../shared/recordatorio-dialog/recordatorio-dialog';
import { RespuestaExternaDialog, RespuestaExternaDialogData } from '../../shared/respuesta-externa-dialog/respuesta-externa-dialog';

const ETIQUETAS_ESTATUS: Record<string, string> = {
  RECIBIDO: 'Recibido',
  EN_INVESTIGACION: 'En Investigación',
  EN_GESTION_DIRECTOR: 'Gestión con Director',
  LISTO_A_DICTAMINAR: 'Listo a Dictaminar',
  CONCLUIDO: 'Concluido'
};

@Component({
  selector: 'app-bandeja',
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatChipsModule,
    MatTooltipModule,
    MatDialogModule,
    MatSnackBarModule
  ],
  templateUrl: './bandeja.html',
  styleUrl: './bandeja.css'
})
export class Bandeja implements OnInit {
  displayedColumns = ['folio', 'fechaAdmision', 'quejosoNombre', 'asunto', 'unidadAcademica', 'estatus', 'progreso', 'acciones'];

  todos: ExpedienteResumen[] = [];
  filtrados: ExpedienteResumen[] = [];

  busqueda = '';
  estatusSeleccionado = 'TODOS';
  unidadSeleccionada = 'TODAS';
  unidadesDisponibles: string[] = [];

  readonly etiquetasEstatus = ETIQUETAS_ESTATUS;

  constructor(
    private expedienteResumenService: ExpedienteResumenService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.cargar();
  }

  cargar(): void {
    this.expedienteResumenService.listarTodos().subscribe({
      next: (items) => {
        this.todos = items;
        this.unidadesDisponibles = [...new Set(items.map(i => i.unidadAcademica).filter(Boolean))].sort();
        this.aplicarFiltros();
        this.cdr.detectChanges();
      },
      error: () => {
        this.cdr.detectChanges();
        this.snackBar.open('No fue posible cargar la bandeja de expedientes.', 'Cerrar', { duration: 3000 });
      }
    });
  }

  aplicarFiltros(): void {
    const texto = this.busqueda.trim().toLowerCase();

    this.filtrados = this.todos.filter(e => {
      const pasaEstatus = this.estatusSeleccionado === 'TODOS' || e.estatus === this.estatusSeleccionado;
      const pasaUnidad = this.unidadSeleccionada === 'TODAS' || e.unidadAcademica === this.unidadSeleccionada;
      const pasaTexto = !texto
        || e.folio.toLowerCase().includes(texto)
        || (e.quejosoNombre ?? '').toLowerCase().includes(texto)
        || (e.asunto ?? '').toLowerCase().includes(texto);

      return pasaEstatus && pasaUnidad && pasaTexto;
    });
  }

  etiquetaEstatus(estatus: string): string {
    return this.etiquetasEstatus[estatus] ?? estatus;
  }

  etiquetaAccionPrincipal(e: ExpedienteResumen): string | null {
    if (e.estatus === 'RECIBIDO') return 'Solicitar Oficio';
    if (e.estatus === 'EN_GESTION_DIRECTOR' && !e.numeroOficioVigente) return 'Redactar Oficio al Director';
    return null;
  }

  accionPrincipal(e: ExpedienteResumen): void {
    const siguienteFase = e.estatus === 'RECIBIDO' ? 'SOLICITUD_INFORMACION' : 'GESTION_DIRECTOR';

    const data: RedactarOficioDialogData = {
      expedienteId: e.expedienteId,
      folio: e.folio,
      siguienteFase,
      unidadAcademica: e.unidadAcademica
    };

    this.dialog.open(RedactarOficioDialog, { width: '560px', data }).afterClosed().subscribe(resultado => {
      if (resultado) {
        this.snackBar.open('Oficio generado y enviado correctamente.', 'Cerrar', { duration: 3000 });
        this.cargar();
      }
    });
  }

  verDetalle(e: ExpedienteResumen): void {
    this.router.navigate(['/expediente', e.folio]);
  }

  abrirRecordatorio(e: ExpedienteResumen): void {
    if (!e.oficioIdVigente || !e.numeroOficioVigente || !e.faseOficioVigente) return;

    const data: RecordatorioDialogData = {
      oficioId: e.oficioIdVigente,
      numeroOficio: e.numeroOficioVigente,
      fase: e.faseOficioVigente
    };

    this.dialog.open(RecordatorioDialog, { width: '520px', data }).afterClosed().subscribe(resultado => {
      if (resultado) {
        this.snackBar.open('Recordatorio enviado correctamente.', 'Cerrar', { duration: 3000 });
        this.cargar();
      }
    });
  }

  abrirRespuestaExterna(e: ExpedienteResumen): void {
    if (!e.oficioIdVigente || !e.numeroOficioVigente) return;

    const data: RespuestaExternaDialogData = {
      oficioId: e.oficioIdVigente,
      numeroOficio: e.numeroOficioVigente,
      destinatarioNombre: e.destinatarioNombreVigente ?? e.unidadAcademica
    };

    this.dialog.open(RespuestaExternaDialog, { width: '560px', data }).afterClosed().subscribe(resultado => {
      if (resultado) {
        this.snackBar.open('Respuesta registrada correctamente.', 'Cerrar', { duration: 3000 });
        this.cargar();
      }
    });
  }
}
