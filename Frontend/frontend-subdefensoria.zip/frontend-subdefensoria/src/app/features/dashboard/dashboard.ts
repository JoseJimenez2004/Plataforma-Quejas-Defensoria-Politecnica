import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { RouterLink } from '@angular/router';
import { ExpedienteResumenService } from '../../core/services/expediente-resumen.service';
import { AlertaService } from '../../core/services/alerta.service';

@Component({
  selector: 'app-dashboard',
  imports: [MatCardModule, MatIconModule, RouterLink],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class Dashboard implements OnInit {
  totalPendientesOficio = 0;
  totalEnCurso = 0;
  totalVencidos = 0;

  constructor(
    private expedienteResumenService: ExpedienteResumenService,
    private alertaService: AlertaService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.expedienteResumenService.listarTodos().subscribe(items => {
      this.totalPendientesOficio = items.filter(
        e => e.estatus === 'RECIBIDO' || (e.estatus === 'EN_GESTION_DIRECTOR' && !e.numeroOficioVigente)
      ).length;
      this.totalEnCurso = items.filter(
        e => e.estatus === 'EN_INVESTIGACION' || e.estatus === 'EN_GESTION_DIRECTOR'
      ).length;
      this.cdr.detectChanges();
    });

    this.alertaService.obtenerVencidos().subscribe(items => {
      this.totalVencidos = items.length;
      this.cdr.detectChanges();
    });
  }
}
