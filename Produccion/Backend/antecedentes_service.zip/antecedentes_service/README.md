# DDP — Antecedentes V5 (Python)

Microservicio independiente. No modifica Java ni escribe en PostgreSQL.

## Fuentes

- `defensoria_db` / `public.quejas` (PostgreSQL puerto host 5432)
- `defensoria_historico_db` / `public.quejas_historicas` (puerto host 5433)

Ambas consultas son **solo lectura**. Los nombres de columnas se verificaron con los metadatos compartidos. El esquema de credenciales, red y permisos todavía debe validarse en el servidor.

## API

**Compatibilidad con Java existente:** `POST /api/antecedentes/buscar`

```json
{"texto":"Narración de la queja", "umbral":0.0, "topK":500}
```

Devuelve `{"antecedentes": [...]}`. Cada elemento es plano e incluye `folio`, `similitud` (0–1), `historico`, `quejoso`, `denunciado`, `texto_original`, `fragmento`, `fecha_hechos`, `tipo_violencia`, `unidad_academica` y `estatus`, compatibles con `MotorAntecedentesModelo.java` del ZIP recibido. **Java solo envía texto y filtra las personas después**. No es posible calcular las tres dimensiones para la queja entrante a partir de ese contrato sin información adicional.

**API completa V5:** `POST /api/v5/antecedentes/buscar`

```json
{
  "folio":"FOL-001",
  "descripcion":"Narración de los hechos",
  "fechaHechos":"2026-09-15",
  "unidadAcademicaClave":"ESCOM",
  "quejoso":{"numeroIdentificacion":"BOLETA-001"},
  "denunciado":{"numeroIdentificacion":"EMP-001"},
  "topK":10
}
```

Devuelve `por_hechos`, `por_involucrados` y `coincidencias_fuertes` por separado. V5 usa identificaciones exactas normalizadas; no equipara personas por nombres. La base actual no tiene ID del denunciado en `quejas`, por lo que la dimensión correspondiente será limitada. `folio` excluye la propia queja de origen `SISTEMA`. No enviar nombres ni narraciones reales en tickets o registros.

## Algoritmo

Modelo `paraphrase-multilingual-MiniLM-L12-v2` con embeddings normalizados. Similaridad textual = 0.85 × coseno semántico + 0.15 × coseno TF-IDF (unigramas/bigramas, `min_df=2` si es posible). Identidad independiente por `numeroIdentificacion`. Coincidencia fuerte = identidad + similitud de hechos ≥ 0.50 entre los primeros 100 candidatos. Metadatos de resolución no intervienen en el puntaje. Resultados son evidencia para revisión, no veredictos.

## Ejecutar localmente

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export SYSTEM_DATABASE_URL='postgresql://...'
export HISTORIC_DATABASE_URL='postgresql://...'
uvicorn app.main:app --host 127.0.0.1 --port 8080
```

En contenedor:

```bash
podman build -t ddp-antecedentes-v5 -f Containerfile .
podman run --rm --name antecedentes-v5-test --env-file .env -p 127.0.0.1:8095:8080 ddp-antecedentes-v5
```

No usar puerto 8093 del servicio anterior hasta validar. `GET /health` solo verifica que el proceso esté vivo. La primera búsqueda descarga/carga el modelo y puede superar el timeout de lectura de Java (15 segundos); precalentar el modelo antes de cambiar tráfico. La implementación actual vuelve a leer y reindexar los casos en cada petición: adecuada para prototipo con pocos registros, no para producción con corpus grande. Para producción, implementar caché/versionado del índice, actualización segura, métricas y controles de acceso/autorización HTTP.

## Pruebas

```bash
pip install pytest
pytest -q
```

## Pendientes del equipo (sin cambios automáticos)

1. **Infraestructura/BD:** conexión privada desde el host de Python a los puertos PostgreSQL del servidor de BD, usuarios separados con permisos `SELECT` exclusivamente y restricciones de firewall/TLS apropiadas.
2. **Primer Contacto (opcional para V5 completo):** enviar folio y objeto de queja con identificadores al nuevo endpoint `/api/v5/antecedentes/buscar`, o exponer un mecanismo autenticado para obtener el folio entrante. El endpoint antiguo ya puede recibir peticiones sin tocar Java, pero solo ofrece ranking por hechos.
3. **Primer Contacto (operación):** confirmar `antecedentes.modelo.url` y cómo se enrutará al nuevo contenedor, así como el timeout de 15 s.
4. **Seguridad:** autenticación entre servicios, autorización de consulta, trazabilidad sin datos sensibles, tratamiento de datos personales y no exponer las bases de datos públicamente.
5. **Validación:** probar con casos sintéticos/anonimizados y verificar el comportamiento con la base histórica vacía.

**No se ha desplegado ni probado contra las bases reales.**
