"""Notebook V5 scoring: 0.85 semantic + 0.15 TF-IDF (1-2 grams)."""
import threading
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from .core import evaluate

MODEL_NAME = 'sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'
_lock = threading.Lock()
_model = None


def get_model():
    global _model
    if _model is None:
        with _lock:
            if _model is None:
                from sentence_transformers import SentenceTransformer
                _model = SentenceTransformer(MODEL_NAME)
    return _model


def search(query, records, top_k=10):
    if not str(query.get('descripcion') or '').strip():
        raise ValueError('La descripción no puede estar vacía')
    own_folio = query.get('folio')
    own_origin = query.get('origen', 'SISTEMA')
    records = [r for r in records if str(r.get('descripcion') or '').strip() and
               not (own_folio and r['folio'] == own_folio and r['origen'] == own_origin)]
    if not records:
        return {'por_hechos': [], 'por_involucrados': [], 'coincidencias_fuertes': []}
    model = get_model()
    texts = [r['descripcion'] for r in records]
    embeddings = model.encode(texts, normalize_embeddings=True, batch_size=64, show_progress_bar=False)
    query_embedding = model.encode([query['descripcion']], normalize_embeddings=True, show_progress_bar=False)
    semantic = cosine_similarity(query_embedding, embeddings)[0]
    # Notebook min_df=2; adjust for small corpus, and guard empty vocabulary.
    lexical = np.zeros(len(records), dtype=float)
    try:
        vectorizer = TfidfVectorizer(lowercase=True, strip_accents='unicode', ngram_range=(1, 2),
                                     min_df=2 if len(records) >= 2 else 1,
                                     sublinear_tf=True, max_features=100000)
        matrix = vectorizer.fit_transform(texts)
        lexical = cosine_similarity(vectorizer.transform([query['descripcion']]), matrix)[0]
    except ValueError as ex:
        if 'empty vocabulary' not in str(ex) and 'After pruning' not in str(ex):
            raise
    scores = np.clip(.85 * semantic + .15 * lexical, 0, 1)
    return evaluate(query, records, scores, semantic, lexical, top_k)
