from app.core import evaluate, same_person
from app.db import adapt


def test_id_only():
    assert same_person({'numeroIdentificacion':'A-123'}, {'numeroIdentificacion':'a-123'})
    assert not same_person({'nombre':'Ana'}, {'nombre':'Ana'})


def test_independent_dimensions():
    query = {'fechaHechos':'2026-01-01', 'quejoso': {'numeroIdentificacion':'ABC'}, 'denunciado':{}}
    records = [{'folio':'F1','origen':'SISTEMA','quejoso':{'numeroIdentificacion':'ABC'},'denunciado':{},'fechaHechos':'2026-01-02'},
               {'folio':'F2','origen':'HISTORICO','quejoso':{},'denunciado':{},'fechaHechos':None}]
    r = evaluate(query, records, [.8,.9], [.8,.9], [.8,.9], 2)
    assert [x['folio'] for x in r['por_hechos']] == ['F2','F1']
    assert len(r['por_involucrados']) == 1
    assert len(r['coincidencias_fuertes']) == 1
    assert r['coincidencias_fuertes'][0]['folio'] == 'F1'


def test_empty():
    assert evaluate({}, [], [], [], [])['coincidencias_fuertes'] == []


def test_adapt():
    r = adapt({'id':1,'folio':'F1','q_nombre':'A','d_nombre':'B'}, 'SISTEMA')
    assert r['quejoso']['nombre'] == 'A'
