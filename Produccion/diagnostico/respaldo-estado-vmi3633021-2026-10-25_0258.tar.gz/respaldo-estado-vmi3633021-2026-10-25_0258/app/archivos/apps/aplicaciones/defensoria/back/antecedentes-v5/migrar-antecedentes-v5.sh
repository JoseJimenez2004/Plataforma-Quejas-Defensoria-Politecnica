#!/usr/bin/env bash
set -Eeuo pipefail

SERVICIO="antecedentes-service"
RESPALDO="antecedentes-service-java-backup"

IMAGEN_JAVA="localhost/defensoria-antecedentes-service:latest"
IMAGEN_V5="localhost/defensoria-antecedentes-v5:cpu-mapeo-v4"

BASE="/apps/aplicaciones/defensoria/back/antecedentes-v5"
ENV_FILE="$BASE/.env"
MODEL_CACHE="$BASE/model-cache"

verificar() {
    echo "===== VERIFICACIÓN PREVIA ====="

    podman container exists "$SERVICIO" ||
        { echo "ERROR: falta el servicio original"; exit 1; }

    podman image exists "$IMAGEN_V5" ||
        { echo "ERROR: falta la imagen V5"; exit 1; }

    test -f "$ENV_FILE" ||
        { echo "ERROR: falta .env"; exit 1; }

    test -d "$MODEL_CACHE" ||
        { echo "ERROR: falta la caché del modelo"; exit 1; }

    if podman container exists "$RESPALDO"; then
        echo "ERROR: ya existe el respaldo Java"
        exit 1
    fi

    IMAGEN_ACTUAL=$(podman inspect "$SERVICIO" \
        --format '{{.ImageName}}')

    if [[ "$IMAGEN_ACTUAL" != "$IMAGEN_JAVA" ]]; then
        echo "ERROR: el contenedor original no utiliza la imagen Java esperada"
        exit 1
    fi

    echo "Verificación correcta"
}

recuperar_java() {
    local estado="$?"

    trap - ERR INT TERM

    echo "ERROR: falló o se interrumpió la migración."
    echo "Intentando recuperar Java..."

    if podman container exists "$SERVICIO"; then
        local imagen_actual
        imagen_actual=$(podman inspect "$SERVICIO" --format '{{.ImageName}}' 2>/dev/null || true)

        if [[ "$imagen_actual" == "$IMAGEN_V5" ]]; then
            podman stop "$SERVICIO" || true
            podman rm "$SERVICIO" || true
        fi
    fi

    if podman container exists "$RESPALDO"; then
        if ! podman container exists "$SERVICIO"; then
            podman rename "$RESPALDO" "$SERVICIO" || true
        fi
    fi

    if podman container exists "$SERVICIO"; then
        local imagen_restaurada
        imagen_restaurada=$(podman inspect "$SERVICIO" --format '{{.ImageName}}' 2>/dev/null || true)

        if [[ "$imagen_restaurada" == "$IMAGEN_JAVA" ]]; then
            podman start "$SERVICIO" || true
        fi
    fi

    echo "Revise el estado de Java y el puerto 8093."
    exit "$estado"
}

migrar() {
    verificar

    trap recuperar_java ERR
    trap 'false' INT TERM

    echo "===== DETENER JAVA ====="
    podman stop "$SERVICIO"

    echo "===== CONSERVAR JAVA ====="
    podman rename "$SERVICIO" "$RESPALDO"

    echo "===== INICIAR PYTHON V5 ====="

    podman run -d \
        --name "$SERVICIO" \
        --restart unless-stopped \
        -p 0.0.0.0:8093:8080 \
        --memory 2g \
        --env-file "$ENV_FILE" \
        -e HF_HOME=/models \
        -e HF_HUB_OFFLINE=1 \
        -e TRANSFORMERS_OFFLINE=1 \
        -v "$MODEL_CACHE":/models:ro \
        "$IMAGEN_V5"

    echo "===== VERIFICAR PYTHON V5 ====="

    for INTENTO in $(seq 1 20); do
        if curl --fail --silent \
            --max-time 5 \
            http://127.0.0.1:8093/health \
            >/dev/null; then
            echo "Python V5 responde correctamente"
            trap - ERR INT TERM
            echo "Migración finalizada"
            return 0
        fi

        sleep 3
    done

    echo "ERROR: Python V5 no respondió correctamente"
    return 1
}

case "${1:-}" in
    verificar)
        verificar
        ;;
    --ejecutar)
        migrar
        ;;
    *)
        echo "Uso: $0 verificar | --ejecutar"
        ;;
esac
