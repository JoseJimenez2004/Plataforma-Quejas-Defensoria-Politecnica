#!/bin/bash
set -euo pipefail

BASE_DIR="/apps/aplicaciones/defensoria/back/antecedentes-v5"

SERVICIO="antecedentes-v5"
IMAGEN="localhost/defensoria-antecedentes-v5:cpu-compatible"

PUERTO_HOST=8096
PUERTO_CONTENEDOR=8080

ENV_FILE="$BASE_DIR/.env"
CACHE_DIR="$BASE_DIR/model-cache"

iniciar() {
    if podman container exists "$SERVICIO"; then
        echo "El contenedor $SERVICIO ya existe."
        exit 1
    fi

    test -f "$ENV_FILE" || {
        echo "ERROR: No existe el archivo .env"
        exit 1
    }

    test -d "$CACHE_DIR" || {
        echo "ERROR: No existe la caché del modelo"
        exit 1
    }

    podman run -d \
        --name "$SERVICIO" \
        --network bridge \
        -p "127.0.0.1:${PUERTO_HOST}:${PUERTO_CONTENEDOR}" \
        --memory 2g \
        --restart unless-stopped \
        --env-file "$ENV_FILE" \
        -e HF_HOME=/models \
        -e HF_HUB_OFFLINE=1 \
        -e TRANSFORMERS_OFFLINE=1 \
        -v "$CACHE_DIR:/models:ro" \
        "$IMAGEN"

    echo "V5 iniciado en el puerto $PUERTO_HOST"
}

estado() {
    podman ps -a --filter "name=^${SERVICIO}$"

    echo
    curl -sS --max-time 10 \
        "http://127.0.0.1:${PUERTO_HOST}/health"
    echo
}

logs() {
    podman logs --tail 80 "$SERVICIO"
}

case "${1:-}" in
    up)
        iniciar
        ;;
    status)
        estado
        ;;
    logs)
        logs
        ;;
    *)
        echo "Uso: bash $0 {up|status|logs}"
        ;;
esac
