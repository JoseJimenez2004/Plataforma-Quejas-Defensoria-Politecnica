#!/usr/bin/env bash
set -Eeuo pipefail

BASE="/apps/aplicaciones/defensoria/back"
PROJECT="$BASE/service_antecedentes"
CACHE="$BASE/antecedentes-v5/model-cache"
IMAGE="localhost/defensoria-antecedentes-service:python-v5"
SERVICE="antecedentes-service"
ENV_FILE="$PROJECT/.env"
PORT=8093

health() {
    curl -fsS --max-time 15 \
      "http://127.0.0.1:$PORT/health"
    echo
}

case "${1:-}" in
  estado)
    echo "===== CONTENEDOR ====="
    podman ps -a --filter "name=^${SERVICE}$"
    echo "===== RECURSOS ====="
    podman stats --no-stream "$SERVICE"
    echo "===== SALUD ====="
    health
    ;;

  construir)
    echo "===== CONSTRUIR IMAGEN ====="
    podman build \
      -f "$PROJECT/Containerfile" \
      -t "$IMAGE" \
      "$PROJECT"
    echo "Imagen construida: $IMAGE"
    ;;

  *)
    echo "Uso: bash deploy.sh {estado|construir}"
    echo
    echo "estado: verifica producción sin modificarla"
    echo "construir: construye una imagen sin reiniciar producción"
    echo
    echo "La sustitución de producción requiere validación adicional."
    exit 1
    ;;
esac
