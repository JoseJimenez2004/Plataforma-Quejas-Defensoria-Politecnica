#!/bin/bash
echo "ERROR: Despliegue antiguo deshabilitado."
echo "El servicio antecedentes-service utiliza Python V5."
echo "No ejecutar el despliegue Java anterior."
exit 1
