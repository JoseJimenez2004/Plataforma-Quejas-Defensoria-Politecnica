#!/usr/bin/env bash
set -Eeuo pipefail

SERVICIO="antecedentes-service"
RESPALDO_JAVA="antecedentes-service-java-backup"
RESPALDO_PYTHON="antecedentes-service-python-backup"
IMAGEN_V5="localhost/defensoria-antecedentes-v5:cpu-mapeo-v4"

if [[ "${1:-}" != "--ejecutar" ]]; then
    echo "Reversión preparada. No se realizaron cambios."
    exit 0
fi

echo "===== VALIDACIONES PREVIAS ====="

for NOMBRE in "$SERVICIO" "$RESPALDO_JAVA"; do
    if ! podman container exists "$NOMBRE"; then
        echo "ERROR: no existe $NOMBRE"
        exit 1
    fi
done

if podman container exists "$RESPALDO_PYTHON"; then
    echo "ERROR: el nombre de respaldo Python está ocupado"
    exit 1
fi

IMAGEN_ACTUAL=$(podman inspect "$SERVICIO" \
    --format '{{.ImageName}}')

if [[ "$IMAGEN_ACTUAL" != "$IMAGEN_V5" ]]; then
    echo "ERROR: producción no utiliza la imagen Python V5 esperada"
    exit 1
fi

echo "===== VERIFICANDO ESTADO DE JAVA ====="

ESTADO_JAVA=$(podman inspect "$RESPALDO_JAVA"     --format '{{.State.Status}}')

if [[ "$ESTADO_JAVA" != "exited" &&
      "$ESTADO_JAVA" != "created" ]]; then
    echo "ERROR: Java de respaldo no está detenido"
    exit 1
fi

recuperar_reversion() {
    local estado=$?
    trap - ERR
    echo "ERROR: falló la reversión. Revisando Java..."

    if ! podman container exists "$SERVICIO"; then
        if podman container exists "$RESPALDO_JAVA"; then
            podman rename "$RESPALDO_JAVA" "$SERVICIO" || true
        fi
    fi

    if podman container exists "$SERVICIO"; then
        local imagen
        imagen=$(podman inspect "$SERVICIO" \
            --format '{{.ImageName}}' 2>/dev/null || true)

        if [[ "$imagen" != "$IMAGEN_V5" ]]; then
            podman start "$SERVICIO" || true
        fi
    fi

    echo "Verifique manualmente el servicio y el puerto 8093."
    exit "$estado"
}

trap recuperar_reversion ERR

echo "===== DESACTIVANDO REINICIO AUTOMÁTICO ====="
podman update --restart=no "$SERVICIO"

echo "===== DETENIENDO PYTHON ====="
podman stop "$SERVICIO"

echo "===== VERIFICANDO PYTHON DETENIDO ====="

ESTADO_PYTHON=$(podman inspect "$SERVICIO"     --format '{{.State.Status}}')

if [[ "$ESTADO_PYTHON" != "exited" ]]; then
    echo "ERROR: Python no quedó detenido"
    exit 1
fi

echo "===== CONSERVANDO PYTHON ====="
podman rename "$SERVICIO" "$RESPALDO_PYTHON"

echo "===== RESTAURANDO JAVA ====="
podman rename "$RESPALDO_JAVA" "$SERVICIO"

if ! podman start "$SERVICIO"; then
    echo "ERROR: Java no pudo iniciarse"
    exit 1
fi

echo "===== VERIFICANDO JAVA ====="

if curl --fail --silent --show-error \
    --retry 5 \
    --retry-delay 2 \
    --retry-connrefused \
    --max-time 15 \
    http://127.0.0.1:8093/api/antecedentes/health \
    > /dev/null; then
    echo "Java restaurado correctamente"
else
    echo "ATENCIÓN: Java inició, pero no pasó la verificación HTTP"
    exit 1
fi
