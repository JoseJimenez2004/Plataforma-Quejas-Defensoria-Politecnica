import {
  HttpClient,
  HttpParams,
  Injectable,
  setClassMetadata,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-BX5W5AEF.js";

// src/app/core/services/revision.service.ts
var RevisionService = class _RevisionService {
  http;
  apiUrl = "/api/revision";
  constructor(http) {
    this.http = http;
  }
  /** Una página de la cola (10 por defecto, la más reciente arriba) + indicadores + equipo. */
  bandeja(filtro = "todas", texto = "", pagina = 0, tamanio = 10) {
    let params = new HttpParams().set("filtro", filtro).set("pagina", pagina).set("tamanio", tamanio);
    if (texto.trim()) {
      params = params.set("q", texto.trim());
    }
    return this.http.get(`${this.apiUrl}/bandeja`, { params });
  }
  /** Suelta la queja (la regresa a la cola para que la tome otra recepcionista). */
  liberar(folio) {
    return this.http.post(`${this.apiUrl}/quejas/${folio}/liberar`, {});
  }
  /** Mantiene la queja a nombre de quien la revisa mientras sigue abierta en pantalla. */
  renovar(folio) {
    return this.http.post(`${this.apiUrl}/quejas/${folio}/renovar`, {});
  }
  detalle(folio) {
    return this.http.get(`${this.apiUrl}/quejas/${folio}`);
  }
  antecedentes(folio) {
    return this.http.get(`${this.apiUrl}/quejas/${folio}/antecedentes`);
  }
  /** Abogados con su carga de trabajo y cuál sugiere el sistema para esta queja. */
  abogados(folio) {
    return this.http.get(`${this.apiUrl}/quejas/${folio}/abogados`);
  }
  urlEvidencia(id) {
    return `${this.apiUrl}/quejas/evidencias/${id}`;
  }
  /** El endpoint exige JWT, así que un <a href> normal no sirve (el navegador no manda el
   * Authorization header en una navegación directa) -- se descarga como blob y se abre. */
  descargarEvidencia(id) {
    return this.http.get(this.urlEvidencia(id), { responseType: "blob" });
  }
  rechazar(folio, datos) {
    return this.http.post(`${this.apiUrl}/quejas/${folio}/rechazar`, datos);
  }
  turnar(folio, datos) {
    return this.http.post(`${this.apiUrl}/quejas/${folio}/turnar`, datos);
  }
  areas() {
    return this.http.get(`${this.apiUrl}/catalogos/areas`);
  }
  defensores() {
    return this.http.get(`${this.apiUrl}/catalogos/defensores`);
  }
  identificacionesOficiales() {
    return this.http.get(`${this.apiUrl}/catalogos/identificaciones-oficiales`);
  }
  registrarManual(formData) {
    return this.http.post(`${this.apiUrl}/registro-manual`, formData);
  }
  static \u0275fac = function RevisionService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _RevisionService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _RevisionService, factory: _RevisionService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RevisionService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

export {
  RevisionService
};
//# sourceMappingURL=chunk-2GBWUYF6.js.map
