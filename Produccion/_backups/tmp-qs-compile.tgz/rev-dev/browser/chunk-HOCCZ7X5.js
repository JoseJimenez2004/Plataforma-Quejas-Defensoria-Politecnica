import {
  RevisionService
} from "./chunk-2GBWUYF6.js";
import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel,
  NgSelectOption,
  SelectControlValueAccessor,
  ɵNgSelectMultipleOption
} from "./chunk-QD7SBTDO.js";
import {
  ActivatedRoute,
  DomSanitizer,
  Router,
  RouterLink
} from "./chunk-3TUQ6HGZ.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DecimalPipe,
  NgTemplateOutlet,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassMap,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainer,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵreference,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtemplateRefExtractor,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-BX5W5AEF.js";

// src/app/pages/validacion/validacion.ts
var _c0 = () => ({ clave: "nombreCompleto" });
var _c1 = () => ({ clave: "identificacionOficial", obsSiempre: true });
var _c2 = () => ({ clave: "numeroIdentificacion", permiteNa: true, etiquetaNa: "No aplicable (no es estudiante)" });
var _c3 = () => ({ clave: "fechaHechos" });
var _c4 = () => ({ clave: "datosDenunciado" });
var _c5 = () => ({ clave: "numeroEmpleado", permiteNa: true, etiquetaNa: "No aplica (ni boleta ni n\xFAmero de empleado; exhibi\xF3 otra identificaci\xF3n)" });
var _forTrack0 = ($index, $item) => $item.grupo;
var _forTrack1 = ($index, $item) => $item.clave;
var _forTrack2 = ($index, $item) => $item.id;
function Validacion_ng_template_11_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 13);
    \u0275\u0275listener("click", function Validacion_ng_template_11_Conditional_5_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r4);
      const clave_r2 = \u0275\u0275nextContext().clave;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.setRespuesta(clave_r2, "na"));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext();
    const clave_r2 = ctx_r4.clave;
    const etiquetaNa_r6 = ctx_r4.etiquetaNa;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275classProp("activo", ctx_r2.r(clave_r2).valor === "na");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(etiquetaNa_r6 || "No aplicable");
  }
}
function Validacion_ng_template_11_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 14)(1, "label", 15);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "textarea", 16);
    \u0275\u0275twoWayListener("ngModelChange", function Validacion_ng_template_11_Conditional_6_Template_textarea_ngModelChange_3_listener($event) {
      \u0275\u0275restoreView(_r7);
      const clave_r2 = \u0275\u0275nextContext().clave;
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.r(clave_r2).observacion, $event) || (ctx_r2.r(clave_r2).observacion = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const clave_r2 = \u0275\u0275nextContext().clave;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275classProp("obs-requerida", ctx_r2.r(clave_r2).valor === false);
    \u0275\u0275advance();
    \u0275\u0275property("for", "obs-" + clave_r2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" Observaciones", ctx_r2.r(clave_r2).valor === false ? " para el quejoso (obligatorio)" : " (opcional)", ": ");
    \u0275\u0275advance();
    \u0275\u0275property("id", "obs-" + clave_r2);
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.r(clave_r2).observacion);
    \u0275\u0275property("name", "obs-" + clave_r2);
  }
}
function Validacion_ng_template_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 8)(1, "button", 9);
    \u0275\u0275listener("click", function Validacion_ng_template_11_Template_button_click_1_listener() {
      const clave_r2 = \u0275\u0275restoreView(_r1).clave;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.setRespuesta(clave_r2, true));
    });
    \u0275\u0275text(2, "S\xED");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "button", 10);
    \u0275\u0275listener("click", function Validacion_ng_template_11_Template_button_click_3_listener() {
      const clave_r2 = \u0275\u0275restoreView(_r1).clave;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.setRespuesta(clave_r2, false));
    });
    \u0275\u0275text(4, "No");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(5, Validacion_ng_template_11_Conditional_5_Template, 2, 3, "button", 11);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(6, Validacion_ng_template_11_Conditional_6_Template, 4, 7, "div", 12);
  }
  if (rf & 2) {
    const clave_r2 = ctx.clave;
    const obsSiempre_r8 = ctx.obsSiempre;
    const permiteNa_r9 = ctx.permiteNa;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275classProp("activo", ctx_r2.r(clave_r2).valor === true);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("activo", ctx_r2.r(clave_r2).valor === false);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(permiteNa_r9 ? 5 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.r(clave_r2).valor === false || obsSiempre_r8 ? 6 : -1);
  }
}
function Validacion_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 6);
    \u0275\u0275text(1, "Cargando queja\u2026");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 23);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Tel: ", ctx_r2.queja.telefonoContacto);
  }
}
function Validacion_Conditional_14_ng_container_30_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function Validacion_Conditional_14_Conditional_38_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 33);
    \u0275\u0275text(1, "Cargando cat\xE1logo\u2026");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_Conditional_38_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 33);
    \u0275\u0275text(1, "No se pudo cargar el cat\xE1logo de documentos.");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_Conditional_38_Conditional_3_For_1_For_5_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(0, "svg", 55);
    \u0275\u0275element(1, "path", 57)(2, "polyline", 58)(3, "path", 59);
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_Conditional_38_Conditional_3_For_1_For_5_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(0, "svg", 55);
    \u0275\u0275element(1, "rect", 60)(2, "circle", 61)(3, "path", 62);
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_Conditional_38_Conditional_3_For_1_For_5_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "small");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const doc_r12 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(doc_r12.detalle);
  }
}
function Validacion_Conditional_14_Conditional_38_Conditional_3_For_1_For_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 53);
    \u0275\u0275listener("click", function Validacion_Conditional_14_Conditional_38_Conditional_3_For_1_For_5_Template_button_click_0_listener() {
      const doc_r12 = \u0275\u0275restoreView(_r11).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(5);
      return \u0275\u0275resetView(ctx_r2.tipoIdentificacionPresentada = doc_r12.clave);
    });
    \u0275\u0275elementStart(1, "span", 54);
    \u0275\u0275conditionalCreate(2, Validacion_Conditional_14_Conditional_38_Conditional_3_For_1_For_5_Conditional_2_Template, 4, 0, ":svg:svg", 55)(3, Validacion_Conditional_14_Conditional_38_Conditional_3_For_1_For_5_Conditional_3_Template, 4, 0, ":svg:svg", 55);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 56)(5, "strong");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(7, Validacion_Conditional_14_Conditional_38_Conditional_3_For_1_For_5_Conditional_7_Template, 2, 1, "small");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const doc_r12 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext(5);
    \u0275\u0275classProp("elegido", ctx_r2.tipoIdentificacionPresentada === doc_r12.clave);
    \u0275\u0275property("title", "Marcar como la identificaci\xF3n que exhibi\xF3");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(doc_r12.grupo.startsWith("Representaci\xF3n") ? 2 : 3);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(doc_r12.nombre);
    \u0275\u0275advance();
    \u0275\u0275conditional(doc_r12.detalle ? 7 : -1);
  }
}
function Validacion_Conditional_14_Conditional_38_Conditional_3_For_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 49)(1, "p", 50);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 51);
    \u0275\u0275repeaterCreate(4, Validacion_Conditional_14_Conditional_38_Conditional_3_For_1_For_5_Template, 8, 6, "button", 52, _forTrack1);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const g_r13 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(g_r13.grupo);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(g_r13.items);
  }
}
function Validacion_Conditional_14_Conditional_38_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275repeaterCreate(0, Validacion_Conditional_14_Conditional_38_Conditional_3_For_1_Template, 6, 1, "div", 49, _forTrack0);
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(3);
    \u0275\u0275repeater(ctx_r2.gruposIdentificacion);
  }
}
function Validacion_Conditional_14_Conditional_38_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 27);
    \u0275\u0275conditionalCreate(1, Validacion_Conditional_14_Conditional_38_Conditional_1_Template, 2, 0, "span", 33)(2, Validacion_Conditional_14_Conditional_38_Conditional_2_Template, 2, 0, "span", 33)(3, Validacion_Conditional_14_Conditional_38_Conditional_3_Template, 2, 0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.cargandoIdentificaciones ? 1 : ctx_r2.identificaciones.length === 0 ? 2 : 3);
  }
}
function Validacion_Conditional_14_For_66_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 63);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const doc_r14 = ctx.$implicit;
    \u0275\u0275property("value", doc_r14.clave);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(doc_r14.nombre);
  }
}
function Validacion_Conditional_14_For_66_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "optgroup", 32);
    \u0275\u0275repeaterCreate(1, Validacion_Conditional_14_For_66_For_2_Template, 2, 2, "option", 63, _forTrack1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const g_r15 = ctx.$implicit;
    \u0275\u0275property("label", g_r15.grupo);
    \u0275\u0275advance();
    \u0275\u0275repeater(g_r15.items);
  }
}
function Validacion_Conditional_14_ng_container_67_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function Validacion_Conditional_14_Conditional_76_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "strong");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Boleta: ", ctx_r2.queja.numeroIdentificacionQuejoso);
  }
}
function Validacion_Conditional_14_Conditional_77_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 33);
    \u0275\u0275text(1, "No registr\xF3 n\xFAmero de boleta.");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_ng_container_78_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function Validacion_Conditional_14_Conditional_79_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "strong");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("N\xFAmero de empleado: ", ctx_r2.queja.numeroIdentificacionQuejoso);
  }
}
function Validacion_Conditional_14_Conditional_79_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 33);
    \u0275\u0275text(1, "No registr\xF3 n\xFAmero de empleado.");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_Conditional_79_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function Validacion_Conditional_14_Conditional_79_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 34)(1, "p", 21);
    \u0275\u0275text(2, " \xBFEl n\xFAmero de empleado registrado concuerda con la constancia o credencial institucional aportada? ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 22)(4, "span", 23);
    \u0275\u0275text(5, "Dato capturado:");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(6, Validacion_Conditional_14_Conditional_79_Conditional_6_Template, 2, 1, "strong")(7, Validacion_Conditional_14_Conditional_79_Conditional_7_Template, 2, 0, "span", 33);
    \u0275\u0275elementEnd();
    \u0275\u0275template(8, Validacion_Conditional_14_Conditional_79_ng_container_8_Template, 1, 0, "ng-container", 25);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    const sino_r16 = \u0275\u0275reference(12);
    \u0275\u0275advance(6);
    \u0275\u0275conditional(ctx_r2.queja.numeroIdentificacionQuejoso && ctx_r2.esEmpleado ? 6 : 7);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", sino_r16)("ngTemplateOutletContext", \u0275\u0275pureFunction0(3, _c5));
  }
}
function Validacion_Conditional_14_Conditional_86_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 23);
    \u0275\u0275text(1, "C\xE1lculo autom\xE1tico del sistema:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "span", 64);
    \u0275\u0275text(3, " Fecha de hechos: ");
    \u0275\u0275elementStart(4, "strong");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 65);
    \u0275\u0275text(7, "|");
    \u0275\u0275elementEnd();
    \u0275\u0275text(8, " Presentaci\xF3n: ");
    \u0275\u0275elementStart(9, "strong");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span", 65);
    \u0275\u0275text(12, "|");
    \u0275\u0275elementEnd();
    \u0275\u0275text(13, " Transcurridos: ");
    \u0275\u0275elementStart(14, "strong");
    \u0275\u0275text(15);
    \u0275\u0275pipe(16, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(17, "span", 66);
    \u0275\u0275text(18);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r2.fechaCorta(ctx_r2.queja.fechaHechos));
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r2.fechaCorta(ctx_r2.queja.fechaCreacion));
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate2("", \u0275\u0275pipeBind2(16, 9, ctx_r2.diasDesdeHechos, "1.0-0"), " ", ctx_r2.diasDesdeHechos === 1 ? "d\xEDa" : "d\xEDas");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("plazo-ok", ctx_r2.dentroDePlazo)("plazo-vencido", !ctx_r2.dentroDePlazo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r2.dentroDePlazo ? "En t\xE9rmino" : "T\xE9rmino fenecido", " ");
  }
}
function Validacion_Conditional_14_Conditional_87_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 33);
    \u0275\u0275text(1, "La queja no tiene fecha de los hechos capturada; verif\xEDquela en las constancias.");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_ng_container_88_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function Validacion_Conditional_14_Conditional_95_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "strong");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r2.queja.nombreCompletoDenunciado);
  }
}
function Validacion_Conditional_14_Conditional_96_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 33);
    \u0275\u0275text(1, "No captur\xF3 el nombre de la persona se\xF1alada; revise la narraci\xF3n de los hechos.");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_ng_container_101_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function Validacion_Conditional_14_Conditional_111_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275textInterpolate1(" \xB7 faltan ", ctx_r2.totalRequisitos - ctx_r2.contestadas, " por contestar ");
  }
}
function Validacion_Conditional_14_Conditional_120_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 18);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("", ctx_r2.imagenesCredencial.length, " im\xE1genes adjuntas \u2014 elige cu\xE1l ver en grande.");
  }
}
function Validacion_Conditional_14_Conditional_121_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 68);
    \u0275\u0275text(1, "Cargando\u2026");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_Conditional_121_Conditional_5_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 74);
    \u0275\u0275listener("click", function Validacion_Conditional_14_Conditional_121_Conditional_5_For_2_Template_button_click_0_listener() {
      const \u0275$index_387_r19 = \u0275\u0275restoreView(_r18).$index;
      const ctx_r2 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r2.seleccionarCredencial(\u0275$index_387_r19));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const img_r20 = ctx.$implicit;
    const \u0275$index_387_r19 = ctx.$index;
    const ctx_r2 = \u0275\u0275nextContext(4);
    \u0275\u0275classProp("activa", \u0275$index_387_r19 === ctx_r2.indiceCredencial);
    \u0275\u0275property("title", img_r20.nombreArchivo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", \u0275$index_387_r19 + 1, " ");
  }
}
function Validacion_Conditional_14_Conditional_121_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 71);
    \u0275\u0275repeaterCreate(1, Validacion_Conditional_14_Conditional_121_Conditional_5_For_2_Template, 2, 4, "button", 73, _forTrack2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r2.imagenesCredencial);
  }
}
function Validacion_Conditional_14_Conditional_121_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 67);
    \u0275\u0275conditionalCreate(1, Validacion_Conditional_14_Conditional_121_Conditional_1_Template, 2, 0, "div", 68);
    \u0275\u0275element(2, "img", 69);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p", 70);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(5, Validacion_Conditional_14_Conditional_121_Conditional_5_Template, 3, 0, "div", 71);
    \u0275\u0275elementStart(6, "button", 72);
    \u0275\u0275listener("click", function Validacion_Conditional_14_Conditional_121_Template_button_click_6_listener() {
      \u0275\u0275restoreView(_r17);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.verDocumento(ctx_r2.credencialId));
    });
    \u0275\u0275text(7, "Abrir en tama\xF1o real");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.cargandoCredencial ? 1 : -1);
    \u0275\u0275advance();
    \u0275\u0275property("src", ctx_r2.credencialUrl, \u0275\u0275sanitizeUrl)("alt", ctx_r2.credencialNombre);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r2.credencialNombre);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.imagenesCredencial.length > 1 ? 5 : -1);
  }
}
function Validacion_Conditional_14_Conditional_122_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 6);
    \u0275\u0275text(1, "Cargando identificaci\xF3n\u2026");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_Conditional_123_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 46)(1, "p");
    \u0275\u0275text(2, "No se adjunt\xF3 una imagen de identificaci\xF3n.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p", 23);
    \u0275\u0275text(4, "Si el quejoso subi\xF3 un PDF, \xE1brelo desde la lista de evidencias.");
    \u0275\u0275elementEnd()();
  }
}
function Validacion_Conditional_14_Conditional_127_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 33);
    \u0275\u0275text(1, "No se adjuntaron documentos.");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_Conditional_128_For_2_Case_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(0, "svg", 55);
    \u0275\u0275element(1, "rect", 79)(2, "circle", 80)(3, "polyline", 81);
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_Conditional_128_For_2_Case_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(0, "svg", 55);
    \u0275\u0275element(1, "path", 57)(2, "polyline", 58);
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_Conditional_128_For_2_Case_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(0, "svg", 55);
    \u0275\u0275element(1, "path", 82)(2, "polyline", 83);
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_14_Conditional_128_For_2_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 23);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ev_r22 = \u0275\u0275nextContext().$implicit;
    const ctx_r2 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r2.formatearTamanio(ev_r22.tamanioBytes));
  }
}
function Validacion_Conditional_14_Conditional_128_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "li")(1, "span", 75);
    \u0275\u0275conditionalCreate(2, Validacion_Conditional_14_Conditional_128_For_2_Case_2_Template, 4, 0, ":svg:svg", 55)(3, Validacion_Conditional_14_Conditional_128_For_2_Case_3_Template, 3, 0, ":svg:svg", 55)(4, Validacion_Conditional_14_Conditional_128_For_2_Case_4_Template, 3, 0, ":svg:svg", 55);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 76)(6, "span", 77);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(8, Validacion_Conditional_14_Conditional_128_For_2_Conditional_8_Template, 2, 1, "span", 23);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "button", 78);
    \u0275\u0275listener("click", function Validacion_Conditional_14_Conditional_128_For_2_Template_button_click_9_listener() {
      const ev_r22 = \u0275\u0275restoreView(_r21).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r2.verDocumento(ev_r22.id));
    });
    \u0275\u0275text(10, "Ver");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    let tmp_14_0;
    const ev_r22 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275classMap(ctx_r2.tipoIcono(ev_r22));
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_14_0 = ctx_r2.tipoIcono(ev_r22)) === "imagen" ? 2 : tmp_14_0 === "pdf" ? 3 : 4);
    \u0275\u0275advance(4);
    \u0275\u0275property("title", ev_r22.nombreArchivo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ev_r22.nombreArchivo);
    \u0275\u0275advance();
    \u0275\u0275conditional(ev_r22.tamanioBytes ? 8 : -1);
  }
}
function Validacion_Conditional_14_Conditional_128_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ul", 48);
    \u0275\u0275repeaterCreate(1, Validacion_Conditional_14_Conditional_128_For_2_Template, 11, 6, "li", null, _forTrack2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r2.queja.evidencias);
  }
}
function Validacion_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 7)(1, "div", 17)(2, "h3");
    \u0275\u0275text(3, "Revisi\xF3n del Quejoso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 18)(5, "strong");
    \u0275\u0275text(6, "Instrucci\xF3n:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(7, " Valide los datos asentados en la queja contra las constancias adjuntas. Si la totalidad de los requisitos se satisface afirmativamente (");
    \u0275\u0275elementStart(8, "strong");
    \u0275\u0275text(9, "S\xED");
    \u0275\u0275elementEnd();
    \u0275\u0275text(10, "), proceda a la canalizaci\xF3n. Si determina uno o m\xE1s incumplimientos (");
    \u0275\u0275elementStart(11, "strong");
    \u0275\u0275text(12, "No");
    \u0275\u0275elementEnd();
    \u0275\u0275text(13, "), motive la inconsistencia o se\xF1ale el requerimiento de prevenci\xF3n correspondiente. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "ol", 19)(15, "li")(16, "p", 20);
    \u0275\u0275text(17, "Identidad de la persona quejosa");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "p", 21);
    \u0275\u0275text(19, "\xBFEl nombre asentado coincide \xEDntegramente con la identificaci\xF3n oficial adjunta?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "div", 22)(21, "strong");
    \u0275\u0275text(22);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "span", 23);
    \u0275\u0275text(24);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(25, Validacion_Conditional_14_Conditional_25_Template, 2, 1, "span", 23);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "p", 24)(27, "strong");
    \u0275\u0275text(28, "Criterio de cotejo:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(29, " Considere v\xE1lido el registro si la persona acredita un solo apellido. Verifique que no existan discrepancias ortogr\xE1ficas sustantivas. ");
    \u0275\u0275elementEnd();
    \u0275\u0275template(30, Validacion_Conditional_14_ng_container_30_Template, 1, 0, "ng-container", 25);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "li")(32, "p", 20);
    \u0275\u0275text(33, "Validez y suficiencia de la documentaci\xF3n de identidad y personalidad jur\xEDdica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "p", 21);
    \u0275\u0275text(35, " \xBFEl Quejoso exhibi\xF3 una identificaci\xF3n oficial con fotograf\xEDa v\xE1lida y vigente (y, en su caso, la constancia id\xF3nea de representaci\xF3n legal), en t\xE9rminos del Art\xEDculo 13 de la Gaceta Polit\xE9cnica y del apartado de Control y Gesti\xF3n Administrativa de Documentos? ");
    \u0275\u0275elementStart(36, "button", 26);
    \u0275\u0275listener("click", function Validacion_Conditional_14_Template_button_click_36_listener() {
      \u0275\u0275restoreView(_r10);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.alternarListadoOficial());
    });
    \u0275\u0275text(37);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(38, Validacion_Conditional_14_Conditional_38_Template, 4, 1, "div", 27);
    \u0275\u0275elementStart(39, "div", 24)(40, "strong");
    \u0275\u0275text(41, "Criterio de cotejo operativo:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(42, "ul")(43, "li")(44, "strong");
    \u0275\u0275text(45, "Presentaci\xF3n personal:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(46, " se tendr\xE1 por satisfecha con credencial para votar (INE), pasaporte, c\xE9dula profesional, cartilla del SMN, licencia de conducir o credencial del IPN vigente. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(47, "li")(48, "strong");
    \u0275\u0275text(49, "Casos de representaci\xF3n:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(50, "ul")(51, "li")(52, "em");
    \u0275\u0275text(53, "Menores de edad (CECyT):");
    \u0275\u0275elementEnd();
    \u0275\u0275text(54, " verificar acta de nacimiento del alumno o documento judicial de tutela, acompa\xF1ada de la identificaci\xF3n oficial vigente del padre, madre o tutor legal. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(55, "li")(56, "em");
    \u0275\u0275text(57, "Representaci\xF3n legal / Apoderado:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(58, " verificar poder notarial o carta poder simple ratificada/firmada ante dos testigos, adjuntando las identificaciones oficiales de todas las partes intervinientes. ");
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275elementStart(59, "div", 28)(60, "label", 29);
    \u0275\u0275text(61, "Identificaci\xF3n que exhibi\xF3:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(62, "select", 30);
    \u0275\u0275twoWayListener("ngModelChange", function Validacion_Conditional_14_Template_select_ngModelChange_62_listener($event) {
      \u0275\u0275restoreView(_r10);
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.tipoIdentificacionPresentada, $event) || (ctx_r2.tipoIdentificacionPresentada = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementStart(63, "option", 31);
    \u0275\u0275text(64, "Seleccione el documento");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(65, Validacion_Conditional_14_For_66_Template, 3, 1, "optgroup", 32, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(67, Validacion_Conditional_14_ng_container_67_Template, 1, 0, "ng-container", 25);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(68, "li")(69, "p", 20);
    \u0275\u0275text(70, "Correspondencia de matr\xEDcula institucional (en su caso)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(71, "p", 21);
    \u0275\u0275text(72, " \xBFEl n\xFAmero de boleta registrado concuerda con la constancia o credencial institucional aportada? ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(73, "div", 22)(74, "span", 23);
    \u0275\u0275text(75, "Dato capturado:");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(76, Validacion_Conditional_14_Conditional_76_Template, 2, 1, "strong")(77, Validacion_Conditional_14_Conditional_77_Template, 2, 0, "span", 33);
    \u0275\u0275elementEnd();
    \u0275\u0275template(78, Validacion_Conditional_14_ng_container_78_Template, 1, 0, "ng-container", 25);
    \u0275\u0275conditionalCreate(79, Validacion_Conditional_14_Conditional_79_Template, 9, 4, "div", 34);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(80, "li")(81, "p", 20);
    \u0275\u0275text(82, "Oportunidad en la presentaci\xF3n (c\xF3mputo de temporalidad)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(83, "p", 21);
    \u0275\u0275text(84);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(85, "div", 22);
    \u0275\u0275conditionalCreate(86, Validacion_Conditional_14_Conditional_86_Template, 19, 12)(87, Validacion_Conditional_14_Conditional_87_Template, 2, 0, "span", 33);
    \u0275\u0275elementEnd();
    \u0275\u0275template(88, Validacion_Conditional_14_ng_container_88_Template, 1, 0, "ng-container", 25);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(89, "li")(90, "p", 20);
    \u0275\u0275text(91, "Identificaci\xF3n de la persona se\xF1alada o denunciada");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(92, "p", 21);
    \u0275\u0275text(93, "\xBFLa queja aporta elementos suficientes para la plena identificaci\xF3n de la persona se\xF1alada?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(94, "div", 22);
    \u0275\u0275conditionalCreate(95, Validacion_Conditional_14_Conditional_95_Template, 2, 1, "strong")(96, Validacion_Conditional_14_Conditional_96_Template, 2, 0, "span", 33);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(97, "p", 24)(98, "strong");
    \u0275\u0275text(99, "Criterio de cotejo:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(100, " Se tienen por satisfechos cuando menos el nombre y apellido(s) o datos de adscripci\xF3n que permitan su individualizaci\xF3n. ");
    \u0275\u0275elementEnd();
    \u0275\u0275template(101, Validacion_Conditional_14_ng_container_101_Template, 1, 0, "ng-container", 25);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(102, "div", 35)(103, "label", 36);
    \u0275\u0275text(104, "Observaciones generales (opcional):");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(105, "textarea", 37);
    \u0275\u0275twoWayListener("ngModelChange", function Validacion_Conditional_14_Template_textarea_ngModelChange_105_listener($event) {
      \u0275\u0275restoreView(_r10);
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.observaciones, $event) || (ctx_r2.observaciones = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(106, "div", 38)(107, "div", 39);
    \u0275\u0275element(108, "div", 40);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(109, "p", 41);
    \u0275\u0275text(110);
    \u0275\u0275conditionalCreate(111, Validacion_Conditional_14_Conditional_111_Template, 1, 1);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(112, "div", 42)(113, "button", 43);
    \u0275\u0275listener("click", function Validacion_Conditional_14_Template_button_click_113_listener() {
      \u0275\u0275restoreView(_r10);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.irACanalizar());
    });
    \u0275\u0275text(114, " \u2192 Canalizar Queja ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(115, "button", 44);
    \u0275\u0275listener("click", function Validacion_Conditional_14_Template_button_click_115_listener() {
      \u0275\u0275restoreView(_r10);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.regresarAlQuejoso());
    });
    \u0275\u0275text(116);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(117, "div", 45)(118, "h3");
    \u0275\u0275text(119, "Identificaci\xF3n del quejoso");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(120, Validacion_Conditional_14_Conditional_120_Template, 2, 1, "p", 18);
    \u0275\u0275conditionalCreate(121, Validacion_Conditional_14_Conditional_121_Template, 8, 5)(122, Validacion_Conditional_14_Conditional_122_Template, 2, 0, "p", 6)(123, Validacion_Conditional_14_Conditional_123_Template, 5, 0, "div", 46);
    \u0275\u0275elementStart(124, "div", 47)(125, "h4");
    \u0275\u0275text(126, "Evidencias adjuntas");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(127, Validacion_Conditional_14_Conditional_127_Template, 2, 0, "span", 33)(128, Validacion_Conditional_14_Conditional_128_Template, 3, 0, "ul", 48);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    const sino_r16 = \u0275\u0275reference(12);
    \u0275\u0275advance(15);
    \u0275\u0275classProp("dato-cumplido", ctx_r2.respuestas.nombreCompleto.valor === true)("dato-fallido", ctx_r2.respuestas.nombreCompleto.valor === false);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(ctx_r2.queja.nombreCompletoQuejoso);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r2.queja.correoInstitucional);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.queja.telefonoContacto ? 25 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275property("ngTemplateOutlet", sino_r16)("ngTemplateOutletContext", \u0275\u0275pureFunction0(60, _c0));
    \u0275\u0275advance();
    \u0275\u0275classProp("dato-cumplido", ctx_r2.respuestas.identificacionOficial.valor === true)("dato-fallido", ctx_r2.respuestas.identificacionOficial.valor === false);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1(" ", ctx_r2.mostrarListadoOficial ? "Ocultar cat\xE1logo de documentos" : "Ver cat\xE1logo de documentos", " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.mostrarListadoOficial ? 38 : -1);
    \u0275\u0275advance(24);
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.tipoIdentificacionPresentada);
    \u0275\u0275property("disabled", ctx_r2.cargandoIdentificaciones);
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r2.gruposIdentificacion);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", sino_r16)("ngTemplateOutletContext", \u0275\u0275pureFunction0(61, _c1));
    \u0275\u0275advance();
    \u0275\u0275classProp("dato-cumplido", ctx_r2.estadoRequisito("numeroIdentificacion") === "si")("dato-fallido", ctx_r2.estadoRequisito("numeroIdentificacion") === "no");
    \u0275\u0275advance(8);
    \u0275\u0275conditional(ctx_r2.queja.numeroIdentificacionQuejoso && !ctx_r2.esEmpleado ? 76 : 77);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", sino_r16)("ngTemplateOutletContext", \u0275\u0275pureFunction0(62, _c2));
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.respuestas.numeroIdentificacion.valor === "na" ? 79 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("dato-cumplido", ctx_r2.respuestas.fechaHechos.valor === true)("dato-fallido", ctx_r2.respuestas.fechaHechos.valor === false);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" \xBFLa queja fue promovida dentro del t\xE9rmino de ", ctx_r2.plazoDias, " d\xEDas naturales posteriores a los hechos imputados? ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r2.diasDesdeHechos !== null ? 86 : 87);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", sino_r16)("ngTemplateOutletContext", \u0275\u0275pureFunction0(63, _c3));
    \u0275\u0275advance();
    \u0275\u0275classProp("dato-cumplido", ctx_r2.respuestas.datosDenunciado.valor === true)("dato-fallido", ctx_r2.respuestas.datosDenunciado.valor === false);
    \u0275\u0275advance(6);
    \u0275\u0275conditional(ctx_r2.queja.nombreCompletoDenunciado && ctx_r2.queja.nombreCompletoDenunciado.trim() && ctx_r2.queja.nombreCompletoDenunciado !== "No especificado" ? 95 : 96);
    \u0275\u0275advance(6);
    \u0275\u0275property("ngTemplateOutlet", sino_r16)("ngTemplateOutletContext", \u0275\u0275pureFunction0(64, _c4));
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.observaciones);
    \u0275\u0275advance(3);
    \u0275\u0275styleProp("width", ctx_r2.cumplidos / ctx_r2.totalRequisitos * 100, "%");
    \u0275\u0275classProp("completo", ctx_r2.puedeCanalizar);
    \u0275\u0275advance();
    \u0275\u0275classProp("completo", ctx_r2.puedeCanalizar);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2(" ", ctx_r2.cumplidos, " de ", ctx_r2.totalRequisitos, " requisitos satisfechos ");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.contestadas < ctx_r2.totalRequisitos ? 111 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", !ctx_r2.puedeCanalizar)("title", ctx_r2.puedeCanalizar ? "" : "Todos los requisitos deben estar en S\xED (o No aplicable) para canalizar.");
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", !ctx_r2.puedeRegresar)("title", ctx_r2.motivoBloqueoRegresar);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r2.enviando ? "Enviando\u2026" : "\u2190 Regresar al Quejoso", " ");
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r2.imagenesCredencial.length > 1 ? 120 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.credencialUrl ? 121 : ctx_r2.cargandoCredencial ? 122 : 123);
    \u0275\u0275advance(6);
    \u0275\u0275conditional(ctx_r2.queja.evidencias.length === 0 ? 127 : 128);
  }
}
var PLAZO_DIAS_QUEJA = 90;
var MOTIVO_SI_NO = {
  nombreCompleto: "El nombre asentado en la queja no coincide \xEDntegramente con la identificaci\xF3n oficial adjunta.",
  identificacionOficial: "No se exhibi\xF3 una identificaci\xF3n oficial con fotograf\xEDa v\xE1lida y vigente (o, en su caso, la constancia id\xF3nea de representaci\xF3n legal), en t\xE9rminos del Art\xEDculo 13 de la Gaceta Polit\xE9cnica y del apartado de Control y Gesti\xF3n Administrativa de Documentos.",
  numeroIdentificacion: "El n\xFAmero de boleta registrado no concuerda con la constancia o credencial institucional aportada.",
  numeroEmpleado: "El n\xFAmero de empleado registrado no concuerda con la constancia o credencial institucional aportada.",
  fechaHechos: `La queja no fue promovida dentro del t\xE9rmino de ${PLAZO_DIAS_QUEJA} d\xEDas naturales posteriores a los hechos.`,
  datosDenunciado: "La queja no aporta elementos suficientes para la plena identificaci\xF3n de la persona se\xF1alada."
};
var TITULO_PREGUNTA = {
  nombreCompleto: "Identidad de la persona quejosa",
  identificacionOficial: "Documentaci\xF3n de identidad y personalidad jur\xEDdica",
  numeroIdentificacion: "Matr\xEDcula institucional (boleta)",
  numeroEmpleado: "Matr\xEDcula institucional (n\xFAmero de empleado)",
  fechaHechos: "Oportunidad en la presentaci\xF3n",
  datosDenunciado: "Identificaci\xF3n de la persona se\xF1alada"
};
var ORDEN_PREGUNTAS = [
  "nombreCompleto",
  "identificacionOficial",
  "numeroIdentificacion",
  "fechaHechos",
  "datosDenunciado"
];
var Validacion = class _Validacion {
  route;
  router;
  revisionService;
  toast;
  sanitizer;
  cdr;
  plazoDias = PLAZO_DIAS_QUEJA;
  folio = "";
  queja = null;
  cargando = true;
  enviando = false;
  respuestas = {
    nombreCompleto: { valor: null, observacion: "" },
    identificacionOficial: { valor: null, observacion: "" },
    numeroIdentificacion: { valor: null, observacion: "" },
    numeroEmpleado: { valor: null, observacion: "" },
    fechaHechos: { valor: null, observacion: "" },
    datosDenunciado: { valor: null, observacion: "" }
  };
  totalRequisitos = ORDEN_PREGUNTAS.length;
  /** Observaciones generales, adicionales a las de cada pregunta (opcional). */
  observaciones = "";
  identificaciones = [];
  tipoIdentificacionPresentada = "";
  cargandoIdentificaciones = false;
  mostrarListadoOficial = false;
  imagenesCredencial = [];
  indiceCredencial = 0;
  credencialUrl = null;
  credencialNombre = "";
  credencialId = null;
  cargandoCredencial = false;
  credencialObjectUrl = null;
  constructor(route, router, revisionService, toast, sanitizer, cdr) {
    this.route = route;
    this.router = router;
    this.revisionService = revisionService;
    this.toast = toast;
    this.sanitizer = sanitizer;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.folio = this.route.snapshot.paramMap.get("folio") ?? "";
    this.cargar();
  }
  ngOnDestroy() {
    if (this.credencialObjectUrl) {
      URL.revokeObjectURL(this.credencialObjectUrl);
      this.credencialObjectUrl = null;
    }
  }
  // ---------------- lista de verificación ----------------
  /** Acceso tipado desde la plantilla (el ng-template recibe la clave como string). */
  r(clave) {
    return this.respuestas[clave];
  }
  setRespuesta(clave, valor) {
    this.r(clave).valor = valor;
    this.cdr.detectChanges();
  }
  /**
   * Estado de cada requisito: 'si' (Sí o No aplicable), 'no' o null (sin contestar). El
   * requisito 3 combina la boleta y, si la boleta "No aplica", el número de empleado.
   */
  estadoRequisito(clave) {
    const valor = this.r(clave).valor;
    if (clave === "numeroIdentificacion" && valor === "na") {
      const empleado = this.respuestas.numeroEmpleado.valor;
      return empleado === null ? null : empleado === false ? "no" : "si";
    }
    return valor === null ? null : valor === false ? "no" : "si";
  }
  get cumplidos() {
    return ORDEN_PREGUNTAS.filter((c) => this.estadoRequisito(c) === "si").length;
  }
  get contestadas() {
    return ORDEN_PREGUNTAS.filter((c) => this.estadoRequisito(c) !== null).length;
  }
  /** Preguntas contestadas con "No" (en el requisito 3, la boleta o el número de empleado). */
  get preguntasEnNo() {
    return ORDEN_PREGUNTAS.filter((c) => this.estadoRequisito(c) === "no").map((c) => c === "numeroIdentificacion" && this.respuestas.numeroIdentificacion.valor === "na" ? "numeroEmpleado" : c);
  }
  /** Preguntas en "No" a las que todavía les falta la observación para el quejoso. */
  get noSinObservacion() {
    return this.preguntasEnNo.filter((c) => !this.respuestas[c].observacion.trim());
  }
  get puedeCanalizar() {
    return this.cumplidos === this.totalRequisitos;
  }
  get puedeRegresar() {
    return this.preguntasEnNo.length > 0 && this.noSinObservacion.length === 0 && !this.enviando;
  }
  get motivoBloqueoRegresar() {
    if (this.preguntasEnNo.length === 0) {
      return 'Marca al menos una pregunta como "No" para regresar la queja.';
    }
    if (this.noSinObservacion.length > 0) {
      return 'Escribe la observaci\xF3n de cada pregunta marcada como "No".';
    }
    return "";
  }
  // ---------------- datos calculados para las preguntas ----------------
  /** Días naturales entre la fecha de los hechos y la fecha de registro de la queja.
   * null si la queja no trae fecha de los hechos (p. ej. registros manuales). */
  get diasDesdeHechos() {
    const hechos = this.aFechaLocal(this.queja?.fechaHechos);
    const registro = this.aFechaLocal(this.queja?.fechaCreacion);
    if (!hechos || !registro) {
      return null;
    }
    const msPorDia = 24 * 60 * 60 * 1e3;
    return Math.round((registro.getTime() - hechos.getTime()) / msPorDia);
  }
  get dentroDePlazo() {
    const dias = this.diasDesdeHechos;
    return dias === null ? null : dias <= this.plazoDias;
  }
  get etiquetaTipoIdentificacion() {
    switch ((this.queja?.tipoIdentificacionQuejoso ?? "").toLowerCase()) {
      case "alumno":
        return "N\xFAmero de boleta";
      case "empleado":
        return "N\xFAmero de empleado";
      default:
        return "Boleta / n\xFAmero de empleado";
    }
  }
  get esEmpleado() {
    return (this.queja?.tipoIdentificacionQuejoso ?? "").toLowerCase() === "empleado";
  }
  /** Catálogo de documentos agrupado (identificación oficial, IPN, representación). */
  get gruposIdentificacion() {
    const grupos = [];
    for (const doc of this.identificaciones) {
      const nombre = doc.grupo || "Identificaci\xF3n oficial";
      let g = grupos.find((x) => x.grupo === nombre);
      if (!g) {
        g = { grupo: nombre, items: [] };
        grupos.push(g);
      }
      g.items.push(doc);
    }
    return grupos;
  }
  /** "Boleta" o "Número de empleado" para el dato capturado de la pregunta 3. */
  get etiquetaDatoCapturado() {
    return (this.queja?.tipoIdentificacionQuejoso ?? "").toLowerCase() === "empleado" ? "N\xFAmero de empleado" : "Boleta";
  }
  /** "15/jun/2023" -- formato del cómputo automático de la pregunta 4. */
  fechaCorta(valor) {
    const fecha = this.aFechaLocal(valor);
    if (!fecha) {
      return "";
    }
    const meses = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
    return `${String(fecha.getDate()).padStart(2, "0")}/${meses[fecha.getMonth()]}/${fecha.getFullYear()}`;
  }
  get esAlumno() {
    return (this.queja?.tipoIdentificacionQuejoso ?? "").toLowerCase() === "alumno";
  }
  /** "2026-09-30" o "2026-09-30T12:34:56" → fecha local a medianoche, sin corrimiento por
   * zona horaria (new Date('2026-09-30') la interpretaría como UTC y en México daría el 29). */
  aFechaLocal(valor) {
    if (!valor) {
      return null;
    }
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(valor);
    if (!m) {
      return null;
    }
    return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  }
  formatearFecha(valor) {
    const fecha = this.aFechaLocal(valor);
    return fecha ? fecha.toLocaleDateString("es-MX", { day: "2-digit", month: "long", year: "numeric" }) : "";
  }
  alternarListadoOficial() {
    this.mostrarListadoOficial = !this.mostrarListadoOficial;
  }
  // ---------------- acciones ----------------
  irACanalizar() {
    if (!this.puedeCanalizar) {
      this.toast.advertencia('Todos los requisitos deben estar en "S\xED" (o "No aplicable") para canalizar la queja.');
      return;
    }
    this.router.navigate(["/turnado", this.folio]);
  }
  regresarAlQuejoso() {
    if (!this.puedeRegresar) {
      this.toast.advertencia(this.motivoBloqueoRegresar || "Revisa las respuestas antes de regresar la queja.");
      return;
    }
    const motivos = this.preguntasEnNo.map((c) => MOTIVO_SI_NO[c]);
    const detalle = this.preguntasEnNo.map((c) => `\u2022 ${TITULO_PREGUNTA[c]}: ${this.respuestas[c].observacion.trim()}`);
    const idPresentada = this.identificaciones.find((i) => i.clave === this.tipoIdentificacionPresentada);
    if (idPresentada && this.respuestas.identificacionOficial.valor === false) {
      detalle.push(`\u2022 Identificaci\xF3n revisada: ${idPresentada.nombre}`);
    }
    if (this.observaciones.trim()) {
      detalle.push("", this.observaciones.trim());
    }
    this.enviando = true;
    this.revisionService.rechazar(this.folio, { motivos, observaciones: detalle.join("\n") }).subscribe({
      next: () => {
        this.toast.exito("La queja fue regresada al quejoso con observaciones.");
        this.router.navigate(["/"]);
      },
      error: (err) => {
        this.enviando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo regresar la queja.");
        this.cdr.detectChanges();
      }
    });
  }
  verDocumento(id) {
    this.revisionService.descargarEvidencia(id).subscribe({
      next: (blob) => {
        const url = URL.createObjectURL(blob);
        window.open(url, "_blank");
      },
      error: () => this.toast.error("No se pudo abrir el documento.")
    });
  }
  // ---------------- carga ----------------
  soltando = false;
  /** Regresa la queja a la cola (deja de estar a nombre de esta recepcionista). */
  soltar() {
    this.soltando = true;
    this.revisionService.liberar(this.folio).subscribe({
      next: () => {
        this.toast.exito(`La queja ${this.folio} regres\xF3 a la bandeja.`);
        this.router.navigate(["/"]);
      },
      error: (err) => {
        this.soltando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo soltar la queja.");
        this.cdr.detectChanges();
      }
    });
  }
  cargar() {
    this.cargando = true;
    this.revisionService.detalle(this.folio).subscribe({
      next: (queja) => {
        this.queja = queja;
        this.cargando = false;
        this.cargarCredencial();
        this.cargarIdentificaciones();
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.cargando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo cargar la queja.");
        this.router.navigate(["/"]);
      }
    });
  }
  cargarIdentificaciones() {
    this.cargandoIdentificaciones = true;
    this.revisionService.identificacionesOficiales().subscribe({
      next: (lista) => {
        this.identificaciones = lista;
        this.cargandoIdentificaciones = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargandoIdentificaciones = false;
        this.identificaciones = [];
        this.cdr.detectChanges();
      }
    });
  }
  cargarCredencial() {
    this.imagenesCredencial = (this.queja?.evidencias ?? []).filter((ev) => (ev.tipoMime ?? "").toLowerCase().startsWith("image/"));
    this.indiceCredencial = 0;
    if (this.imagenesCredencial.length === 0) {
      return;
    }
    this.mostrarCredencial(0);
  }
  seleccionarCredencial(indice) {
    if (indice === this.indiceCredencial || indice < 0 || indice >= this.imagenesCredencial.length) {
      return;
    }
    this.mostrarCredencial(indice);
  }
  mostrarCredencial(indice) {
    const imagen = this.imagenesCredencial[indice];
    if (!imagen) {
      return;
    }
    this.indiceCredencial = indice;
    this.credencialId = imagen.id;
    this.credencialNombre = imagen.nombreArchivo;
    this.cargandoCredencial = true;
    if (this.credencialObjectUrl) {
      URL.revokeObjectURL(this.credencialObjectUrl);
      this.credencialObjectUrl = null;
      this.credencialUrl = null;
    }
    this.revisionService.descargarEvidencia(imagen.id).subscribe({
      next: (blob) => {
        this.credencialObjectUrl = URL.createObjectURL(blob);
        this.credencialUrl = this.sanitizer.bypassSecurityTrustUrl(this.credencialObjectUrl);
        this.cargandoCredencial = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargandoCredencial = false;
        this.cdr.detectChanges();
      }
    });
  }
  formatearTamanio(bytes) {
    if (!bytes || bytes <= 0) {
      return "";
    }
    if (bytes < 1024) {
      return `${bytes} B`;
    }
    const kb = bytes / 1024;
    if (kb < 1024) {
      return `${kb.toFixed(kb < 10 ? 1 : 0)} KB`;
    }
    return `${(kb / 1024).toFixed(1)} MB`;
  }
  tipoIcono(ev) {
    const tipo = (ev.tipoMime ?? "").toLowerCase();
    if (tipo.startsWith("image/")) {
      return "imagen";
    }
    if (tipo === "application/pdf") {
      return "pdf";
    }
    return "archivo";
  }
  static \u0275fac = function Validacion_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Validacion)(\u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(RevisionService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(DomSanitizer), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Validacion, selectors: [["app-validacion"]], decls: 15, vars: 4, consts: [["sino", ""], [1, "page-header"], [1, "page-header-subtitulo"], [1, "acciones-encabezado"], ["routerLink", "/", "title", "La queja sigue a tu nombre; se libera sola tras 20 minutos sin actividad", 1, "btn-secondary"], ["type", "button", "title", "Regresa la queja a la bandeja para que la atienda otra recepcionista", 1, "btn-secondary", 3, "click", "disabled"], [1, "cargando"], [1, "rejilla-validacion"], [1, "acciones-pregunta"], ["type", "button", 1, "btn-si", 3, "click"], ["type", "button", 1, "btn-no", 3, "click"], ["type", "button", 1, "btn-na", 3, "activo"], [1, "obs-pregunta", 3, "obs-requerida"], ["type", "button", 1, "btn-na", 3, "click"], [1, "obs-pregunta"], [3, "for"], ["rows", "2", "placeholder", "Qu\xE9 falta o qu\xE9 no coincide, y qu\xE9 debe corregir el quejoso\u2026", 3, "ngModelChange", "id", "ngModel", "name"], [1, "card"], [1, "pista-checks"], [1, "lista-preguntas"], [1, "titulo-requisito"], [1, "etiqueta-dato"], [1, "dato-capturado"], [1, "meta"], [1, "criterio"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], ["type", "button", 1, "link-listado", 3, "click"], [1, "catalogo-documentos"], [1, "input-group"], ["for", "tipoIdentificacionPresentada"], ["id", "tipoIdentificacionPresentada", "name", "tipoIdentificacionPresentada", 3, "ngModelChange", "ngModel", "disabled"], ["value", "", "disabled", ""], [3, "label"], [1, "sin-dato"], [1, "sub-requisito"], [1, "observaciones-validacion"], ["for", "obs-generales"], ["id", "obs-generales", "rows", "3", "name", "observaciones", "placeholder", "Algo adicional que deba saber el quejoso\u2026", 3, "ngModelChange", "ngModel"], [1, "progreso-requisitos"], [1, "progreso-barra"], [1, "progreso-relleno"], [1, "contador-checks"], [1, "acciones-validacion"], [1, "btn-exito", 3, "click", "disabled", "title"], [1, "btn-secondary", "boton-rechazar", 3, "click", "disabled", "title"], [1, "card", "card-credencial"], [1, "credencial-vacia"], [1, "evidencias-validacion"], [1, "lista-documentos"], [1, "catalogo-grupo"], [1, "catalogo-grupo-titulo"], [1, "catalogo-items"], ["type", "button", 1, "catalogo-item", 3, "elegido", "title"], ["type", "button", 1, "catalogo-item", 3, "click", "title"], ["aria-hidden", "true", 1, "catalogo-icono"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], [1, "catalogo-texto"], ["d", "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"], ["points", "14 2 14 8 20 8"], ["d", "M9 15h6M9 18h4"], ["x", "2", "y", "5", "width", "20", "height", "14", "rx", "2"], ["cx", "8", "cy", "12", "r", "2.5"], ["d", "M13 10h5M13 14h4"], [3, "value"], [1, "computo"], [1, "separador"], [1, "plazo"], [1, "marco-credencial"], [1, "marco-credencial-cargando"], [3, "src", "alt"], [1, "pie-credencial"], [1, "miniaturas-credencial"], [1, "btn-secondary", 3, "click"], ["type", "button", 1, "miniatura-boton", 3, "activa", "title"], ["type", "button", 1, "miniatura-boton", 3, "click", "title"], [1, "icono-documento"], [1, "datos-documento"], [1, "nombre-documento", 3, "title"], [1, "btn-secondary", "boton-ver", 3, "click"], ["x", "3", "y", "3", "width", "18", "height", "18", "rx", "2"], ["cx", "8.5", "cy", "8.5", "r", "1.5"], ["points", "21 15 16 10 5 21"], ["d", "M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"], ["points", "13 2 13 9 20 9"]], template: function Validacion_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 1)(1, "div")(2, "h2");
      \u0275\u0275text(3);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(4, "p", 2);
      \u0275\u0275text(5, "Verifica que los datos proporcionados existan y coincidan con la identificaci\xF3n.");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(6, "div", 3)(7, "a", 4);
      \u0275\u0275text(8, " Volver (la conservo) ");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(9, "button", 5);
      \u0275\u0275listener("click", function Validacion_Template_button_click_9_listener() {
        return ctx.soltar();
      });
      \u0275\u0275text(10);
      \u0275\u0275elementEnd()()();
      \u0275\u0275template(11, Validacion_ng_template_11_Template, 7, 6, "ng-template", null, 0, \u0275\u0275templateRefExtractor);
      \u0275\u0275conditionalCreate(13, Validacion_Conditional_13_Template, 2, 0, "p", 6)(14, Validacion_Conditional_14_Template, 129, 65, "div", 7);
    }
    if (rf & 2) {
      \u0275\u0275advance(3);
      \u0275\u0275textInterpolate1("Validaci\xF3n de Datos e Identificaci\xF3n \u2014 ", ctx.folio);
      \u0275\u0275advance(6);
      \u0275\u0275property("disabled", ctx.soltando);
      \u0275\u0275advance();
      \u0275\u0275textInterpolate1(" ", ctx.soltando ? "Soltando\u2026" : "Soltar y volver a la Bandeja", " ");
      \u0275\u0275advance(3);
      \u0275\u0275conditional(ctx.cargando ? 13 : ctx.queja ? 14 : -1);
    }
  }, dependencies: [CommonModule, NgTemplateOutlet, FormsModule, NgSelectOption, \u0275NgSelectMultipleOption, DefaultValueAccessor, SelectControlValueAccessor, NgControlStatus, NgModel, RouterLink, DecimalPipe], styles: ['@charset "UTF-8";\n\n\n.cargando[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.rejilla-validacion[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(0, 1.25fr) minmax(0, 1fr);\n  gap: 20px;\n  align-items: start;\n}\n@media (max-width: 1000px) {\n  .rejilla-validacion[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n}\n.pista-checks[_ngcontent-%COMP%] {\n  margin: 0 0 14px;\n  font-size: 0.84rem;\n  color: var(--texto-suave);\n}\n.etiqueta-dato[_ngcontent-%COMP%] {\n  font-size: 0.86rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.sin-dato[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-style: italic;\n}\n.lista-documentos[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n.lista-documentos[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 9px 10px;\n  margin: 0 -10px;\n  border-radius: 8px;\n  font-size: 0.86rem;\n  transition: background 0.15s ease;\n}\n.lista-documentos[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:hover {\n  background: var(--gris-fondo);\n}\n.lista-documentos[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:not(:last-child) {\n  border-bottom: 1px solid var(--borde);\n}\n.icono-documento[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 32px;\n  height: 32px;\n  border-radius: 8px;\n  flex-shrink: 0;\n}\n.icono-documento[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 17px;\n  height: 17px;\n}\n.icono-documento.imagen[_ngcontent-%COMP%] {\n  background: var(--acento-azul-suave);\n  color: var(--acento-azul);\n}\n.icono-documento.pdf[_ngcontent-%COMP%] {\n  background: #fdecea;\n  color: var(--peligro);\n}\n.icono-documento.archivo[_ngcontent-%COMP%] {\n  background: var(--gris-fondo);\n  color: var(--texto-suave);\n}\n.datos-documento[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n  flex: 1;\n}\n.nombre-documento[_ngcontent-%COMP%] {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-weight: 500;\n}\n.datos-documento[_ngcontent-%COMP%]   .meta[_ngcontent-%COMP%] {\n  font-size: 0.76rem;\n  color: var(--texto-suave);\n}\n.boton-ver[_ngcontent-%COMP%] {\n  padding: 5px 12px;\n  font-size: 0.78rem;\n  flex-shrink: 0;\n}\n.card-credencial[_ngcontent-%COMP%] {\n  position: sticky;\n  top: 16px;\n}\n.marco-credencial[_ngcontent-%COMP%] {\n  position: relative;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  background: var(--gris-fondo);\n  padding: 8px;\n  overflow: hidden;\n}\n.marco-credencial[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  display: block;\n  width: 100%;\n  height: auto;\n  max-height: 62vh;\n  object-fit: contain;\n  border-radius: 4px;\n}\n.marco-credencial-cargando[_ngcontent-%COMP%] {\n  position: absolute;\n  inset: 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: rgba(255, 255, 255, 0.75);\n  color: var(--texto-suave);\n  font-size: 0.8rem;\n  z-index: 1;\n}\n.miniaturas-credencial[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin: 10px 0 12px;\n}\n.miniatura-boton[_ngcontent-%COMP%] {\n  width: 30px;\n  height: 30px;\n  border-radius: 6px;\n  border: 1.5px solid var(--borde);\n  background: #fff;\n  color: var(--texto-suave);\n  font-size: 0.78rem;\n  font-weight: 600;\n}\n.miniatura-boton[_ngcontent-%COMP%]:hover {\n  border-color: var(--guinda-vivo);\n  color: var(--guinda-vivo);\n}\n.miniatura-boton.activa[_ngcontent-%COMP%] {\n  border-color: var(--guinda);\n  background: var(--guinda);\n  color: #fff;\n}\n.pie-credencial[_ngcontent-%COMP%] {\n  margin: 10px 0 12px;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n  word-break: break-word;\n}\n.credencial-vacia[_ngcontent-%COMP%] {\n  padding: 26px 16px;\n  border: 1px dashed var(--borde);\n  border-radius: 8px;\n  text-align: center;\n  color: var(--texto-suave);\n  font-size: 0.88rem;\n}\n.credencial-vacia[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0 0 6px;\n}\n.credencial-vacia[_ngcontent-%COMP%]   .meta[_ngcontent-%COMP%] {\n  font-size: 0.78rem;\n}\n.progreso-requisitos[_ngcontent-%COMP%] {\n  margin-top: 22px;\n}\n.progreso-barra[_ngcontent-%COMP%] {\n  height: 8px;\n  border-radius: 999px;\n  background: var(--gris-fondo);\n  overflow: hidden;\n}\n.progreso-relleno[_ngcontent-%COMP%] {\n  height: 100%;\n  border-radius: 999px;\n  background: var(--acento-ambar);\n  transition: width 0.25s ease, background 0.25s ease;\n}\n.progreso-relleno.completo[_ngcontent-%COMP%] {\n  background: var(--exito);\n}\n.contador-checks[_ngcontent-%COMP%] {\n  margin: 8px 0 0;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.contador-checks.completo[_ngcontent-%COMP%] {\n  color: var(--exito);\n  font-weight: 600;\n}\n.acciones-validacion[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  margin-top: 14px;\n  flex-wrap: wrap;\n}\n.acciones-validacion[_ngcontent-%COMP%]   .boton-rechazar[_ngcontent-%COMP%] {\n  color: var(--peligro);\n  border-color: var(--peligro);\n}\n.acciones-validacion[_ngcontent-%COMP%]   .boton-rechazar[_ngcontent-%COMP%]:hover {\n  background: #fdecea;\n}\n.acciones-pregunta[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  justify-content: flex-end;\n  align-items: start;\n  flex-wrap: wrap;\n}\n.btn-si[_ngcontent-%COMP%], \n.btn-no[_ngcontent-%COMP%] {\n  padding: 7px 18px;\n  border-radius: 8px;\n  border: 1.5px solid var(--borde);\n  background: #fff;\n  color: var(--texto);\n  font-size: 0.84rem;\n  font-weight: 600;\n  cursor: pointer;\n  transition:\n    background 0.15s ease,\n    border-color 0.15s ease,\n    color 0.15s ease;\n}\n.btn-si[_ngcontent-%COMP%]:hover, \n.btn-no[_ngcontent-%COMP%]:hover {\n  border-color: var(--guinda-vivo);\n  color: var(--guinda-vivo);\n}\n.btn-si.activo[_ngcontent-%COMP%], \n.btn-no.activo[_ngcontent-%COMP%] {\n  border-color: var(--guinda);\n  background: var(--guinda);\n  color: #fff;\n}\n.btn-si.activo[_ngcontent-%COMP%] {\n  background: var(--exito);\n  border-color: var(--exito);\n}\n.btn-no.activo[_ngcontent-%COMP%] {\n  background: var(--peligro);\n  border-color: var(--peligro);\n}\n.nota-apellido[_ngcontent-%COMP%] {\n  margin: 8px 0 0;\n  font-size: 0.78rem;\n  color: var(--texto-suave);\n}\n.sub-pregunta[_ngcontent-%COMP%] {\n  margin: 4px 0 8px;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n}\n.input-group[_ngcontent-%COMP%] {\n  margin-top: 12px;\n}\n.input-group[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 5px;\n  font-size: 0.82rem;\n  font-weight: 500;\n  color: var(--texto);\n}\n.input-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 8px 10px;\n  border-radius: 6px;\n  border: 1px solid var(--borde);\n  background: #fff;\n  color: var(--texto);\n  font-size: 0.85rem;\n}\n.observaciones-validacion[_ngcontent-%COMP%] {\n  margin-top: 16px;\n}\n.observaciones-validacion[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 6px;\n  font-size: 0.84rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.observaciones-validacion[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 10px;\n  border-radius: 6px;\n  border: 1px solid var(--borde);\n  resize: vertical;\n  font-size: 0.85rem;\n  font-family: inherit;\n}\n.lista-preguntas[_ngcontent-%COMP%] {\n  list-style: none;\n  counter-reset: pregunta;\n  margin: 0;\n  padding: 0;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%] {\n  counter-increment: pregunta;\n  position: relative;\n  padding: 14px 12px 14px 44px;\n  margin: 0 -12px;\n  border-radius: 8px;\n  border-bottom: 1px solid var(--borde);\n  transition: background 0.15s ease;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]::before {\n  content: counter(pregunta);\n  position: absolute;\n  left: 12px;\n  top: 14px;\n  width: 22px;\n  height: 22px;\n  border-radius: 50%;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-size: 0.78rem;\n  font-weight: 700;\n  display: grid;\n  place-items: center;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]:last-child {\n  border-bottom: none;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]   .acciones-pregunta[_ngcontent-%COMP%] {\n  justify-content: flex-start;\n  margin-top: 10px;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li.dato-cumplido[_ngcontent-%COMP%] {\n  background: var(--acento-verde-suave);\n  border-bottom-color: transparent;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li.dato-cumplido[_ngcontent-%COMP%]::before {\n  background: var(--acento-verde);\n  color: #fff;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li.dato-fallido[_ngcontent-%COMP%] {\n  background: #fdecec;\n  border-bottom-color: transparent;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li.dato-fallido[_ngcontent-%COMP%]::before {\n  background: var(--peligro);\n  color: #fff;\n}\n.instruccion[_ngcontent-%COMP%] {\n  margin: 0 0 6px;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n}\n.dato-capturado[_ngcontent-%COMP%] {\n  margin: 6px 0 0;\n  font-size: 0.9rem;\n  color: var(--texto);\n}\n.dato-capturado[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  display: block;\n  font-weight: 600;\n  word-break: break-word;\n}\n.dato-capturado[_ngcontent-%COMP%]   strong.en-linea[_ngcontent-%COMP%] {\n  display: inline;\n}\n.dato-capturado[_ngcontent-%COMP%]   .meta[_ngcontent-%COMP%] {\n  display: block;\n  margin-top: 4px;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.plazo[_ngcontent-%COMP%] {\n  display: inline-block;\n  margin-top: 8px;\n  padding: 3px 10px;\n  border-radius: 999px;\n  font-size: 0.78rem;\n  font-weight: 600;\n}\n.plazo.plazo-ok[_ngcontent-%COMP%] {\n  background: var(--acento-verde-suave);\n  color: var(--acento-verde);\n}\n.plazo.plazo-vencido[_ngcontent-%COMP%] {\n  background: #fdecec;\n  color: var(--peligro);\n}\n.link-listado[_ngcontent-%COMP%] {\n  margin-left: 6px;\n  padding: 0;\n  border: none;\n  background: none;\n  color: var(--guinda-vivo);\n  font-size: 0.8rem;\n  font-weight: 600;\n  text-decoration: underline;\n  cursor: pointer;\n}\n.listado-oficial[_ngcontent-%COMP%] {\n  margin: 8px 0;\n  padding: 10px 14px;\n  border-radius: 6px;\n  background: var(--gris-fondo);\n  font-size: 0.82rem;\n}\n.listado-oficial[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  margin: 0;\n  padding-left: 18px;\n}\n.listado-oficial[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin: 2px 0;\n}\n.obs-pregunta[_ngcontent-%COMP%] {\n  margin-top: 10px;\n}\n.obs-pregunta[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 5px;\n  font-size: 0.8rem;\n  font-weight: 500;\n  color: var(--texto-suave);\n}\n.obs-pregunta[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 8px 10px;\n  border-radius: 6px;\n  border: 1px solid var(--borde);\n  resize: vertical;\n  font-size: 0.85rem;\n  font-family: inherit;\n  background: #fff;\n}\n.obs-pregunta.obs-requerida[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  color: var(--peligro);\n  font-weight: 600;\n}\n.acciones-encabezado[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  text-decoration: none;\n}\n.acciones-encabezado[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  justify-content: flex-end;\n}\n.titulo-requisito[_ngcontent-%COMP%] {\n  margin: 0 0 4px;\n  color: var(--guinda);\n  font-size: 0.78rem;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.03em;\n}\n.criterio[_ngcontent-%COMP%] {\n  margin: 8px 0 0;\n  padding: 8px 12px;\n  border-left: 3px solid #e3c9d5;\n  border-radius: 0 6px 6px 0;\n  background: #fbf7f9;\n  color: var(--texto-suave);\n  font-size: 0.8rem;\n  line-height: 1.45;\n}\n.criterio[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  margin: 4px 0 0;\n  padding-left: 18px;\n}\n.criterio[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin: 2px 0;\n}\n.computo[_ngcontent-%COMP%] {\n  display: block;\n  margin-top: 2px;\n  font-size: 0.84rem;\n}\n.computo[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  display: inline;\n}\n.computo[_ngcontent-%COMP%]   .separador[_ngcontent-%COMP%] {\n  margin: 0 6px;\n  color: #bbb;\n}\n.btn-na[_ngcontent-%COMP%] {\n  padding: 7px 14px;\n  border-radius: 8px;\n  border: 1.5px solid var(--borde);\n  background: #fff;\n  color: var(--texto);\n  font-size: 0.84rem;\n  font-weight: 600;\n  cursor: pointer;\n}\n.btn-na[_ngcontent-%COMP%]:hover {\n  border-color: #6b7280;\n}\n.btn-na.activo[_ngcontent-%COMP%] {\n  border-color: #6b7280;\n  background: #6b7280;\n  color: #fff;\n}\n.dato-na[_ngcontent-%COMP%] {\n  opacity: 0.85;\n}\n.catalogo-documentos[_ngcontent-%COMP%] {\n  margin: 8px 0 4px;\n  padding: 12px;\n  border: 1px solid #eee;\n  border-radius: 10px;\n  background: #fff;\n}\n.catalogo-grupo[_ngcontent-%COMP%]    + .catalogo-grupo[_ngcontent-%COMP%] {\n  margin-top: 10px;\n}\n.catalogo-grupo-titulo[_ngcontent-%COMP%] {\n  margin: 0 0 6px;\n  color: var(--texto-suave);\n  font-size: 0.72rem;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n}\n.catalogo-items[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(210px, 1fr));\n  gap: 6px;\n}\n.catalogo-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 8px;\n  padding: 8px 10px;\n  border: 1.5px solid #ece7ea;\n  border-radius: 8px;\n  background: #fbf9fa;\n  text-align: left;\n  font: inherit;\n  color: inherit;\n  cursor: pointer;\n}\n.catalogo-item[_ngcontent-%COMP%]:hover {\n  border-color: #d9b8c7;\n}\n.catalogo-item.elegido[_ngcontent-%COMP%] {\n  border-color: var(--guinda);\n  background: var(--guinda-suave);\n}\n.catalogo-icono[_ngcontent-%COMP%] {\n  display: grid;\n  place-items: center;\n  width: 28px;\n  height: 28px;\n  flex-shrink: 0;\n  border-radius: 6px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.catalogo-icono[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 17px;\n  height: 17px;\n}\n.catalogo-texto[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  font-size: 0.8rem;\n  line-height: 1.3;\n}\n.catalogo-texto[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 0.72rem;\n}\n.sub-requisito[_ngcontent-%COMP%] {\n  margin-top: 12px;\n  padding: 10px 12px;\n  border-left: 3px solid #d5d8de;\n  border-radius: 0 8px 8px 0;\n  background: #f7f8fa;\n}\n/*# sourceMappingURL=validacion.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Validacion, [{
    type: Component,
    args: [{ selector: "app-validacion", standalone: true, imports: [CommonModule, FormsModule, RouterLink], template: `<div class="page-header">
  <div>
    <h2>Validaci\xF3n de Datos e Identificaci\xF3n \u2014 {{ folio }}</h2>
    <p class="page-header-subtitulo">Verifica que los datos proporcionados existan y coincidan con la identificaci\xF3n.</p>
  </div>
  <div class="acciones-encabezado">
    <a routerLink="/" class="btn-secondary" title="La queja sigue a tu nombre; se libera sola tras 20 minutos sin actividad">
      Volver (la conservo)
    </a>
    <button type="button" class="btn-secondary" (click)="soltar()" [disabled]="soltando"
            title="Regresa la queja a la bandeja para que la atienda otra recepcionista">
      {{ soltando ? 'Soltando\u2026' : 'Soltar y volver a la Bandeja' }}
    </button>
  </div>
</div>

<!-- Botones S\xED / No + observaci\xF3n cuando la respuesta es "No". Se reutiliza en las 5 preguntas. -->
<ng-template #sino let-clave="clave" let-obsSiempre="obsSiempre" let-permiteNa="permiteNa" let-etiquetaNa="etiquetaNa">
  <div class="acciones-pregunta">
    <button type="button" class="btn-si" [class.activo]="r(clave).valor === true"
            (click)="setRespuesta(clave, true)">S\xED</button>
    <button type="button" class="btn-no" [class.activo]="r(clave).valor === false"
            (click)="setRespuesta(clave, false)">No</button>
    @if (permiteNa) {
      <button type="button" class="btn-na" [class.activo]="r(clave).valor === 'na'"
              (click)="setRespuesta(clave, 'na')">{{ etiquetaNa || 'No aplicable' }}</button>
    }
  </div>
  @if (r(clave).valor === false || obsSiempre) {
    <div class="obs-pregunta" [class.obs-requerida]="r(clave).valor === false">
      <label [for]="'obs-' + clave">
        Observaciones{{ r(clave).valor === false ? ' para el quejoso (obligatorio)' : ' (opcional)' }}:
      </label>
      <textarea
        [id]="'obs-' + clave"
        rows="2"
        [(ngModel)]="r(clave).observacion"
        [name]="'obs-' + clave"
        placeholder="Qu\xE9 falta o qu\xE9 no coincide, y qu\xE9 debe corregir el quejoso\u2026"
      ></textarea>
    </div>
  }
</ng-template>

@if (cargando) {
  <p class="cargando">Cargando queja\u2026</p>
} @else if (queja) {
  <div class="rejilla-validacion">

    <!-- Columna izquierda: lista de verificaci\xF3n -->
    <div class="card">
      <h3>Revisi\xF3n del Quejoso</h3>
      <p class="pista-checks">
        <strong>Instrucci\xF3n:</strong> Valide los datos asentados en la queja contra las constancias adjuntas.
        Si la totalidad de los requisitos se satisface afirmativamente (<strong>S\xED</strong>), proceda a la
        canalizaci\xF3n. Si determina uno o m\xE1s incumplimientos (<strong>No</strong>), motive la inconsistencia o
        se\xF1ale el requerimiento de prevenci\xF3n correspondiente.
      </p>

      <ol class="lista-preguntas">
        <!-- 1. Identidad de la persona quejosa -->
        <li [class.dato-cumplido]="respuestas.nombreCompleto.valor === true"
            [class.dato-fallido]="respuestas.nombreCompleto.valor === false">
          <p class="titulo-requisito">Identidad de la persona quejosa</p>
          <p class="etiqueta-dato">\xBFEl nombre asentado coincide \xEDntegramente con la identificaci\xF3n oficial adjunta?</p>
          <div class="dato-capturado">
            <strong>{{ queja.nombreCompletoQuejoso }}</strong>
            <span class="meta">{{ queja.correoInstitucional }}</span>
            @if (queja.telefonoContacto) {
              <span class="meta">Tel: {{ queja.telefonoContacto }}</span>
            }
          </div>
          <p class="criterio">
            <strong>Criterio de cotejo:</strong> Considere v\xE1lido el registro si la persona acredita un solo
            apellido. Verifique que no existan discrepancias ortogr\xE1ficas sustantivas.
          </p>
          <ng-container *ngTemplateOutlet="sino; context: { clave: 'nombreCompleto' }"></ng-container>
        </li>

        <!-- 2. Validez y suficiencia de la documentaci\xF3n de identidad y personalidad jur\xEDdica -->
        <li [class.dato-cumplido]="respuestas.identificacionOficial.valor === true"
            [class.dato-fallido]="respuestas.identificacionOficial.valor === false">
          <p class="titulo-requisito">Validez y suficiencia de la documentaci\xF3n de identidad y personalidad jur\xEDdica</p>
          <p class="etiqueta-dato">
            \xBFEl Quejoso exhibi\xF3 una identificaci\xF3n oficial con fotograf\xEDa v\xE1lida y vigente (y, en su caso, la
            constancia id\xF3nea de representaci\xF3n legal), en t\xE9rminos del Art\xEDculo 13 de la Gaceta Polit\xE9cnica y
            del apartado de Control y Gesti\xF3n Administrativa de Documentos?
            <button type="button" class="link-listado" (click)="alternarListadoOficial()">
              {{ mostrarListadoOficial ? 'Ocultar cat\xE1logo de documentos' : 'Ver cat\xE1logo de documentos' }}
            </button>
          </p>
          @if (mostrarListadoOficial) {
            <div class="catalogo-documentos">
              @if (cargandoIdentificaciones) {
                <span class="sin-dato">Cargando cat\xE1logo\u2026</span>
              } @else if (identificaciones.length === 0) {
                <span class="sin-dato">No se pudo cargar el cat\xE1logo de documentos.</span>
              } @else {
                @for (g of gruposIdentificacion; track g.grupo) {
                  <div class="catalogo-grupo">
                    <p class="catalogo-grupo-titulo">{{ g.grupo }}</p>
                    <div class="catalogo-items">
                      @for (doc of g.items; track doc.clave) {
                        <button type="button" class="catalogo-item" [class.elegido]="tipoIdentificacionPresentada === doc.clave"
                                (click)="tipoIdentificacionPresentada = doc.clave" [title]="'Marcar como la identificaci\xF3n que exhibi\xF3'">
                          <span class="catalogo-icono" aria-hidden="true">
                            @if (doc.grupo.startsWith('Representaci\xF3n')) {
                              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><path d="M9 15h6M9 18h4"></path></svg>
                            } @else {
                              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"></rect><circle cx="8" cy="12" r="2.5"></circle><path d="M13 10h5M13 14h4"></path></svg>
                            }
                          </span>
                          <span class="catalogo-texto">
                            <strong>{{ doc.nombre }}</strong>
                            @if (doc.detalle) { <small>{{ doc.detalle }}</small> }
                          </span>
                        </button>
                      }
                    </div>
                  </div>
                }
              }
            </div>
          }
          <div class="criterio">
            <strong>Criterio de cotejo operativo:</strong>
            <ul>
              <li>
                <strong>Presentaci\xF3n personal:</strong> se tendr\xE1 por satisfecha con credencial para votar (INE),
                pasaporte, c\xE9dula profesional, cartilla del SMN, licencia de conducir o credencial del IPN vigente.
              </li>
              <li>
                <strong>Casos de representaci\xF3n:</strong>
                <ul>
                  <li>
                    <em>Menores de edad (CECyT):</em> verificar acta de nacimiento del alumno o documento judicial
                    de tutela, acompa\xF1ada de la identificaci\xF3n oficial vigente del padre, madre o tutor legal.
                  </li>
                  <li>
                    <em>Representaci\xF3n legal / Apoderado:</em> verificar poder notarial o carta poder simple
                    ratificada/firmada ante dos testigos, adjuntando las identificaciones oficiales de todas las
                    partes intervinientes.
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          <div class="input-group">
            <label for="tipoIdentificacionPresentada">Identificaci\xF3n que exhibi\xF3:</label>
            <select id="tipoIdentificacionPresentada" [(ngModel)]="tipoIdentificacionPresentada"
                    name="tipoIdentificacionPresentada" [disabled]="cargandoIdentificaciones">
              <option value="" disabled>Seleccione el documento</option>
              @for (g of gruposIdentificacion; track g.grupo) {
                <optgroup [label]="g.grupo">
                  @for (doc of g.items; track doc.clave) {
                    <option [value]="doc.clave">{{ doc.nombre }}</option>
                  }
                </optgroup>
              }
            </select>
          </div>
          <ng-container *ngTemplateOutlet="sino; context: { clave: 'identificacionOficial', obsSiempre: true }"></ng-container>
        </li>

        <!-- 3. Correspondencia de matr\xEDcula institucional (en su caso) -->
        <li [class.dato-cumplido]="estadoRequisito('numeroIdentificacion') === 'si'"
            [class.dato-fallido]="estadoRequisito('numeroIdentificacion') === 'no'">
          <p class="titulo-requisito">Correspondencia de matr\xEDcula institucional (en su caso)</p>
          <p class="etiqueta-dato">
            \xBFEl n\xFAmero de boleta registrado concuerda con la constancia o credencial institucional aportada?
          </p>
          <div class="dato-capturado">
            <span class="meta">Dato capturado:</span>
            @if (queja.numeroIdentificacionQuejoso && !esEmpleado) {
              <strong>Boleta: {{ queja.numeroIdentificacionQuejoso }}</strong>
            } @else {
              <span class="sin-dato">No registr\xF3 n\xFAmero de boleta.</span>
            }
          </div>
          <ng-container *ngTemplateOutlet="sino; context: { clave: 'numeroIdentificacion', permiteNa: true, etiquetaNa: 'No aplicable (no es estudiante)' }"></ng-container>

          @if (respuestas.numeroIdentificacion.valor === 'na') {
            <div class="sub-requisito">
              <p class="etiqueta-dato">
                \xBFEl n\xFAmero de empleado registrado concuerda con la constancia o credencial institucional aportada?
              </p>
              <div class="dato-capturado">
                <span class="meta">Dato capturado:</span>
                @if (queja.numeroIdentificacionQuejoso && esEmpleado) {
                  <strong>N\xFAmero de empleado: {{ queja.numeroIdentificacionQuejoso }}</strong>
                } @else {
                  <span class="sin-dato">No registr\xF3 n\xFAmero de empleado.</span>
                }
              </div>
              <ng-container *ngTemplateOutlet="sino; context: { clave: 'numeroEmpleado', permiteNa: true, etiquetaNa: 'No aplica (ni boleta ni n\xFAmero de empleado; exhibi\xF3 otra identificaci\xF3n)' }"></ng-container>
            </div>
          }
        </li>

        <!-- 4. Oportunidad en la presentaci\xF3n (c\xF3mputo de temporalidad) -->
        <li [class.dato-cumplido]="respuestas.fechaHechos.valor === true"
            [class.dato-fallido]="respuestas.fechaHechos.valor === false">
          <p class="titulo-requisito">Oportunidad en la presentaci\xF3n (c\xF3mputo de temporalidad)</p>
          <p class="etiqueta-dato">
            \xBFLa queja fue promovida dentro del t\xE9rmino de {{ plazoDias }} d\xEDas naturales posteriores a los hechos
            imputados?
          </p>
          <div class="dato-capturado">
            @if (diasDesdeHechos !== null) {
              <span class="meta">C\xE1lculo autom\xE1tico del sistema:</span>
              <span class="computo">
                Fecha de hechos: <strong>{{ fechaCorta(queja.fechaHechos) }}</strong>
                <span class="separador">|</span>
                Presentaci\xF3n: <strong>{{ fechaCorta(queja.fechaCreacion) }}</strong>
                <span class="separador">|</span>
                Transcurridos: <strong>{{ diasDesdeHechos | number: '1.0-0' }} {{ diasDesdeHechos === 1 ? 'd\xEDa' : 'd\xEDas' }}</strong>
              </span>
              <span class="plazo" [class.plazo-ok]="dentroDePlazo" [class.plazo-vencido]="!dentroDePlazo">
                {{ dentroDePlazo ? 'En t\xE9rmino' : 'T\xE9rmino fenecido' }}
              </span>
            } @else {
              <span class="sin-dato">La queja no tiene fecha de los hechos capturada; verif\xEDquela en las constancias.</span>
            }
          </div>
          <ng-container *ngTemplateOutlet="sino; context: { clave: 'fechaHechos' }"></ng-container>
        </li>

        <!-- 5. Identificaci\xF3n de la persona se\xF1alada o denunciada -->
        <li [class.dato-cumplido]="respuestas.datosDenunciado.valor === true"
            [class.dato-fallido]="respuestas.datosDenunciado.valor === false">
          <p class="titulo-requisito">Identificaci\xF3n de la persona se\xF1alada o denunciada</p>
          <p class="etiqueta-dato">\xBFLa queja aporta elementos suficientes para la plena identificaci\xF3n de la persona se\xF1alada?</p>
          <div class="dato-capturado">
            @if (queja.nombreCompletoDenunciado && queja.nombreCompletoDenunciado.trim() && queja.nombreCompletoDenunciado !== 'No especificado') {
              <strong>{{ queja.nombreCompletoDenunciado }}</strong>
            } @else {
              <span class="sin-dato">No captur\xF3 el nombre de la persona se\xF1alada; revise la narraci\xF3n de los hechos.</span>
            }
          </div>
          <p class="criterio">
            <strong>Criterio de cotejo:</strong> Se tienen por satisfechos cuando menos el nombre y apellido(s) o
            datos de adscripci\xF3n que permitan su individualizaci\xF3n.
          </p>
          <ng-container *ngTemplateOutlet="sino; context: { clave: 'datosDenunciado' }"></ng-container>
        </li>
      </ol>

      <div class="observaciones-validacion">
        <label for="obs-generales">Observaciones generales (opcional):</label>
        <textarea
          id="obs-generales"
          rows="3"
          [(ngModel)]="observaciones"
          name="observaciones"
          placeholder="Algo adicional que deba saber el quejoso\u2026"
        ></textarea>
      </div>

      <div class="progreso-requisitos">
        <div class="progreso-barra">
          <div class="progreso-relleno" [class.completo]="puedeCanalizar"
               [style.width.%]="(cumplidos / totalRequisitos) * 100"></div>
        </div>
        <p class="contador-checks" [class.completo]="puedeCanalizar">
          {{ cumplidos }} de {{ totalRequisitos }} requisitos satisfechos
          @if (contestadas < totalRequisitos) {
            \xB7 faltan {{ totalRequisitos - contestadas }} por contestar
          }
        </p>
      </div>

      <div class="acciones-validacion">
        <button class="btn-exito" [disabled]="!puedeCanalizar"
                [title]="puedeCanalizar ? '' : 'Todos los requisitos deben estar en S\xED (o No aplicable) para canalizar.'"
                (click)="irACanalizar()">
          \u2192 Canalizar Queja
        </button>
        <button class="btn-secondary boton-rechazar" [disabled]="!puedeRegresar"
                [title]="motivoBloqueoRegresar" (click)="regresarAlQuejoso()">
          {{ enviando ? 'Enviando\u2026' : '\u2190 Regresar al Quejoso' }}
        </button>
      </div>
    </div>

    <!-- Columna derecha: credencial en grande -->
    <div class="card card-credencial">
      <h3>Identificaci\xF3n del quejoso</h3>
      @if (imagenesCredencial.length > 1) {
        <p class="pista-checks">{{ imagenesCredencial.length }} im\xE1genes adjuntas \u2014 elige cu\xE1l ver en grande.</p>
      }

      @if (credencialUrl) {
        <div class="marco-credencial">
          @if (cargandoCredencial) {
            <div class="marco-credencial-cargando">Cargando\u2026</div>
          }
          <img [src]="credencialUrl" [alt]="credencialNombre" />
        </div>
        <p class="pie-credencial">{{ credencialNombre }}</p>

        @if (imagenesCredencial.length > 1) {
          <div class="miniaturas-credencial">
            @for (img of imagenesCredencial; track img.id; let i = $index) {
              <button
                type="button"
                class="miniatura-boton"
                [class.activa]="i === indiceCredencial"
                [title]="img.nombreArchivo"
                (click)="seleccionarCredencial(i)"
              >
                {{ i + 1 }}
              </button>
            }
          </div>
        }

        <button class="btn-secondary" (click)="verDocumento(credencialId!)">Abrir en tama\xF1o real</button>
      } @else if (cargandoCredencial) {
        <p class="cargando">Cargando identificaci\xF3n\u2026</p>
      } @else {
        <div class="credencial-vacia">
          <p>No se adjunt\xF3 una imagen de identificaci\xF3n.</p>
          <p class="meta">Si el quejoso subi\xF3 un PDF, \xE1brelo desde la lista de evidencias.</p>
        </div>
      }

      <!-- Evidencias (lista compacta) -->
      <div class="evidencias-validacion">
        <h4>Evidencias adjuntas</h4>
        @if (queja.evidencias.length === 0) {
          <span class="sin-dato">No se adjuntaron documentos.</span>
        } @else {
          <ul class="lista-documentos">
            @for (ev of queja.evidencias; track ev.id) {
              <li>
                <span class="icono-documento" [class]="tipoIcono(ev)">
                  @switch (tipoIcono(ev)) {
                    @case ('imagen') {
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>
                    }
                    @case ('pdf') {
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>
                    }
                    @default {
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                    }
                  }
                </span>
                <span class="datos-documento">
                  <span class="nombre-documento" [title]="ev.nombreArchivo">{{ ev.nombreArchivo }}</span>
                  @if (ev.tamanioBytes) {
                    <span class="meta">{{ formatearTamanio(ev.tamanioBytes) }}</span>
                  }
                </span>
                <button class="btn-secondary boton-ver" (click)="verDocumento(ev.id)">Ver</button>
              </li>
            }
          </ul>
        }
      </div>
    </div>

  </div>
}
`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/validacion/validacion.scss */\n.cargando {\n  color: var(--texto-suave);\n}\n.rejilla-validacion {\n  display: grid;\n  grid-template-columns: minmax(0, 1.25fr) minmax(0, 1fr);\n  gap: 20px;\n  align-items: start;\n}\n@media (max-width: 1000px) {\n  .rejilla-validacion {\n    grid-template-columns: 1fr;\n  }\n}\n.pista-checks {\n  margin: 0 0 14px;\n  font-size: 0.84rem;\n  color: var(--texto-suave);\n}\n.etiqueta-dato {\n  font-size: 0.86rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.sin-dato {\n  color: var(--texto-suave);\n  font-style: italic;\n}\n.lista-documentos {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n.lista-documentos li {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 9px 10px;\n  margin: 0 -10px;\n  border-radius: 8px;\n  font-size: 0.86rem;\n  transition: background 0.15s ease;\n}\n.lista-documentos li:hover {\n  background: var(--gris-fondo);\n}\n.lista-documentos li:not(:last-child) {\n  border-bottom: 1px solid var(--borde);\n}\n.icono-documento {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 32px;\n  height: 32px;\n  border-radius: 8px;\n  flex-shrink: 0;\n}\n.icono-documento svg {\n  width: 17px;\n  height: 17px;\n}\n.icono-documento.imagen {\n  background: var(--acento-azul-suave);\n  color: var(--acento-azul);\n}\n.icono-documento.pdf {\n  background: #fdecea;\n  color: var(--peligro);\n}\n.icono-documento.archivo {\n  background: var(--gris-fondo);\n  color: var(--texto-suave);\n}\n.datos-documento {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n  flex: 1;\n}\n.nombre-documento {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-weight: 500;\n}\n.datos-documento .meta {\n  font-size: 0.76rem;\n  color: var(--texto-suave);\n}\n.boton-ver {\n  padding: 5px 12px;\n  font-size: 0.78rem;\n  flex-shrink: 0;\n}\n.card-credencial {\n  position: sticky;\n  top: 16px;\n}\n.marco-credencial {\n  position: relative;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  background: var(--gris-fondo);\n  padding: 8px;\n  overflow: hidden;\n}\n.marco-credencial img {\n  display: block;\n  width: 100%;\n  height: auto;\n  max-height: 62vh;\n  object-fit: contain;\n  border-radius: 4px;\n}\n.marco-credencial-cargando {\n  position: absolute;\n  inset: 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: rgba(255, 255, 255, 0.75);\n  color: var(--texto-suave);\n  font-size: 0.8rem;\n  z-index: 1;\n}\n.miniaturas-credencial {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin: 10px 0 12px;\n}\n.miniatura-boton {\n  width: 30px;\n  height: 30px;\n  border-radius: 6px;\n  border: 1.5px solid var(--borde);\n  background: #fff;\n  color: var(--texto-suave);\n  font-size: 0.78rem;\n  font-weight: 600;\n}\n.miniatura-boton:hover {\n  border-color: var(--guinda-vivo);\n  color: var(--guinda-vivo);\n}\n.miniatura-boton.activa {\n  border-color: var(--guinda);\n  background: var(--guinda);\n  color: #fff;\n}\n.pie-credencial {\n  margin: 10px 0 12px;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n  word-break: break-word;\n}\n.credencial-vacia {\n  padding: 26px 16px;\n  border: 1px dashed var(--borde);\n  border-radius: 8px;\n  text-align: center;\n  color: var(--texto-suave);\n  font-size: 0.88rem;\n}\n.credencial-vacia p {\n  margin: 0 0 6px;\n}\n.credencial-vacia .meta {\n  font-size: 0.78rem;\n}\n.progreso-requisitos {\n  margin-top: 22px;\n}\n.progreso-barra {\n  height: 8px;\n  border-radius: 999px;\n  background: var(--gris-fondo);\n  overflow: hidden;\n}\n.progreso-relleno {\n  height: 100%;\n  border-radius: 999px;\n  background: var(--acento-ambar);\n  transition: width 0.25s ease, background 0.25s ease;\n}\n.progreso-relleno.completo {\n  background: var(--exito);\n}\n.contador-checks {\n  margin: 8px 0 0;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.contador-checks.completo {\n  color: var(--exito);\n  font-weight: 600;\n}\n.acciones-validacion {\n  display: flex;\n  gap: 12px;\n  margin-top: 14px;\n  flex-wrap: wrap;\n}\n.acciones-validacion .boton-rechazar {\n  color: var(--peligro);\n  border-color: var(--peligro);\n}\n.acciones-validacion .boton-rechazar:hover {\n  background: #fdecea;\n}\n.acciones-pregunta {\n  display: flex;\n  gap: 10px;\n  justify-content: flex-end;\n  align-items: start;\n  flex-wrap: wrap;\n}\n.btn-si,\n.btn-no {\n  padding: 7px 18px;\n  border-radius: 8px;\n  border: 1.5px solid var(--borde);\n  background: #fff;\n  color: var(--texto);\n  font-size: 0.84rem;\n  font-weight: 600;\n  cursor: pointer;\n  transition:\n    background 0.15s ease,\n    border-color 0.15s ease,\n    color 0.15s ease;\n}\n.btn-si:hover,\n.btn-no:hover {\n  border-color: var(--guinda-vivo);\n  color: var(--guinda-vivo);\n}\n.btn-si.activo,\n.btn-no.activo {\n  border-color: var(--guinda);\n  background: var(--guinda);\n  color: #fff;\n}\n.btn-si.activo {\n  background: var(--exito);\n  border-color: var(--exito);\n}\n.btn-no.activo {\n  background: var(--peligro);\n  border-color: var(--peligro);\n}\n.nota-apellido {\n  margin: 8px 0 0;\n  font-size: 0.78rem;\n  color: var(--texto-suave);\n}\n.sub-pregunta {\n  margin: 4px 0 8px;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n}\n.input-group {\n  margin-top: 12px;\n}\n.input-group label {\n  display: block;\n  margin-bottom: 5px;\n  font-size: 0.82rem;\n  font-weight: 500;\n  color: var(--texto);\n}\n.input-group select {\n  width: 100%;\n  padding: 8px 10px;\n  border-radius: 6px;\n  border: 1px solid var(--borde);\n  background: #fff;\n  color: var(--texto);\n  font-size: 0.85rem;\n}\n.observaciones-validacion {\n  margin-top: 16px;\n}\n.observaciones-validacion label {\n  display: block;\n  margin-bottom: 6px;\n  font-size: 0.84rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.observaciones-validacion textarea {\n  width: 100%;\n  padding: 10px;\n  border-radius: 6px;\n  border: 1px solid var(--borde);\n  resize: vertical;\n  font-size: 0.85rem;\n  font-family: inherit;\n}\n.lista-preguntas {\n  list-style: none;\n  counter-reset: pregunta;\n  margin: 0;\n  padding: 0;\n}\n.lista-preguntas > li {\n  counter-increment: pregunta;\n  position: relative;\n  padding: 14px 12px 14px 44px;\n  margin: 0 -12px;\n  border-radius: 8px;\n  border-bottom: 1px solid var(--borde);\n  transition: background 0.15s ease;\n}\n.lista-preguntas > li::before {\n  content: counter(pregunta);\n  position: absolute;\n  left: 12px;\n  top: 14px;\n  width: 22px;\n  height: 22px;\n  border-radius: 50%;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-size: 0.78rem;\n  font-weight: 700;\n  display: grid;\n  place-items: center;\n}\n.lista-preguntas > li:last-child {\n  border-bottom: none;\n}\n.lista-preguntas > li .acciones-pregunta {\n  justify-content: flex-start;\n  margin-top: 10px;\n}\n.lista-preguntas > li.dato-cumplido {\n  background: var(--acento-verde-suave);\n  border-bottom-color: transparent;\n}\n.lista-preguntas > li.dato-cumplido::before {\n  background: var(--acento-verde);\n  color: #fff;\n}\n.lista-preguntas > li.dato-fallido {\n  background: #fdecec;\n  border-bottom-color: transparent;\n}\n.lista-preguntas > li.dato-fallido::before {\n  background: var(--peligro);\n  color: #fff;\n}\n.instruccion {\n  margin: 0 0 6px;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n}\n.dato-capturado {\n  margin: 6px 0 0;\n  font-size: 0.9rem;\n  color: var(--texto);\n}\n.dato-capturado strong {\n  display: block;\n  font-weight: 600;\n  word-break: break-word;\n}\n.dato-capturado strong.en-linea {\n  display: inline;\n}\n.dato-capturado .meta {\n  display: block;\n  margin-top: 4px;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.plazo {\n  display: inline-block;\n  margin-top: 8px;\n  padding: 3px 10px;\n  border-radius: 999px;\n  font-size: 0.78rem;\n  font-weight: 600;\n}\n.plazo.plazo-ok {\n  background: var(--acento-verde-suave);\n  color: var(--acento-verde);\n}\n.plazo.plazo-vencido {\n  background: #fdecec;\n  color: var(--peligro);\n}\n.link-listado {\n  margin-left: 6px;\n  padding: 0;\n  border: none;\n  background: none;\n  color: var(--guinda-vivo);\n  font-size: 0.8rem;\n  font-weight: 600;\n  text-decoration: underline;\n  cursor: pointer;\n}\n.listado-oficial {\n  margin: 8px 0;\n  padding: 10px 14px;\n  border-radius: 6px;\n  background: var(--gris-fondo);\n  font-size: 0.82rem;\n}\n.listado-oficial ul {\n  margin: 0;\n  padding-left: 18px;\n}\n.listado-oficial li {\n  margin: 2px 0;\n}\n.obs-pregunta {\n  margin-top: 10px;\n}\n.obs-pregunta label {\n  display: block;\n  margin-bottom: 5px;\n  font-size: 0.8rem;\n  font-weight: 500;\n  color: var(--texto-suave);\n}\n.obs-pregunta textarea {\n  width: 100%;\n  padding: 8px 10px;\n  border-radius: 6px;\n  border: 1px solid var(--borde);\n  resize: vertical;\n  font-size: 0.85rem;\n  font-family: inherit;\n  background: #fff;\n}\n.obs-pregunta.obs-requerida label {\n  color: var(--peligro);\n  font-weight: 600;\n}\n.acciones-encabezado a {\n  text-decoration: none;\n}\n.acciones-encabezado {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  justify-content: flex-end;\n}\n.titulo-requisito {\n  margin: 0 0 4px;\n  color: var(--guinda);\n  font-size: 0.78rem;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.03em;\n}\n.criterio {\n  margin: 8px 0 0;\n  padding: 8px 12px;\n  border-left: 3px solid #e3c9d5;\n  border-radius: 0 6px 6px 0;\n  background: #fbf7f9;\n  color: var(--texto-suave);\n  font-size: 0.8rem;\n  line-height: 1.45;\n}\n.criterio ul {\n  margin: 4px 0 0;\n  padding-left: 18px;\n}\n.criterio li {\n  margin: 2px 0;\n}\n.computo {\n  display: block;\n  margin-top: 2px;\n  font-size: 0.84rem;\n}\n.computo strong {\n  display: inline;\n}\n.computo .separador {\n  margin: 0 6px;\n  color: #bbb;\n}\n.btn-na {\n  padding: 7px 14px;\n  border-radius: 8px;\n  border: 1.5px solid var(--borde);\n  background: #fff;\n  color: var(--texto);\n  font-size: 0.84rem;\n  font-weight: 600;\n  cursor: pointer;\n}\n.btn-na:hover {\n  border-color: #6b7280;\n}\n.btn-na.activo {\n  border-color: #6b7280;\n  background: #6b7280;\n  color: #fff;\n}\n.dato-na {\n  opacity: 0.85;\n}\n.catalogo-documentos {\n  margin: 8px 0 4px;\n  padding: 12px;\n  border: 1px solid #eee;\n  border-radius: 10px;\n  background: #fff;\n}\n.catalogo-grupo + .catalogo-grupo {\n  margin-top: 10px;\n}\n.catalogo-grupo-titulo {\n  margin: 0 0 6px;\n  color: var(--texto-suave);\n  font-size: 0.72rem;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n}\n.catalogo-items {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(210px, 1fr));\n  gap: 6px;\n}\n.catalogo-item {\n  display: flex;\n  align-items: flex-start;\n  gap: 8px;\n  padding: 8px 10px;\n  border: 1.5px solid #ece7ea;\n  border-radius: 8px;\n  background: #fbf9fa;\n  text-align: left;\n  font: inherit;\n  color: inherit;\n  cursor: pointer;\n}\n.catalogo-item:hover {\n  border-color: #d9b8c7;\n}\n.catalogo-item.elegido {\n  border-color: var(--guinda);\n  background: var(--guinda-suave);\n}\n.catalogo-icono {\n  display: grid;\n  place-items: center;\n  width: 28px;\n  height: 28px;\n  flex-shrink: 0;\n  border-radius: 6px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.catalogo-icono svg {\n  width: 17px;\n  height: 17px;\n}\n.catalogo-texto {\n  display: flex;\n  flex-direction: column;\n  font-size: 0.8rem;\n  line-height: 1.3;\n}\n.catalogo-texto small {\n  color: var(--texto-suave);\n  font-size: 0.72rem;\n}\n.sub-requisito {\n  margin-top: 12px;\n  padding: 10px 12px;\n  border-left: 3px solid #d5d8de;\n  border-radius: 0 8px 8px 0;\n  background: #f7f8fa;\n}\n/*# sourceMappingURL=validacion.css.map */\n'] }]
  }], () => [{ type: ActivatedRoute }, { type: Router }, { type: RevisionService }, { type: ToastService }, { type: DomSanitizer }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Validacion, { className: "Validacion", filePath: "src/app/pages/validacion/validacion.ts", lineNumber: 69 });
})();
export {
  PLAZO_DIAS_QUEJA,
  Validacion
};
//# sourceMappingURL=chunk-HOCCZ7X5.js.map
