import {
  RevisionService
} from "./chunk-2GBWUYF6.js";
import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel
} from "./chunk-QD7SBTDO.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DatePipe,
  HttpClient,
  Injectable,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIndex,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-BX5W5AEF.js";

// src/app/core/services/historial.service.ts
var HistorialService = class _HistorialService {
  http;
  apiUrl = "/api/revision/historial";
  constructor(http) {
    this.http = http;
  }
  listar(texto, estatus, fechaDesde, fechaHasta) {
    const params = {};
    if (texto)
      params["texto"] = texto;
    if (estatus)
      params["estatus"] = estatus;
    if (fechaDesde)
      params["fechaDesde"] = fechaDesde;
    if (fechaHasta)
      params["fechaHasta"] = fechaHasta;
    return this.http.get(this.apiUrl, { params });
  }
  /** El endpoint exige JWT -- se descarga como blob (no un <a href> directo) para poder
   * mandar el Authorization header, igual que la descarga de evidencias. */
  exportar(texto, estatus, fechaDesde, fechaHasta) {
    const params = {};
    if (texto)
      params["texto"] = texto;
    if (estatus)
      params["estatus"] = estatus;
    if (fechaDesde)
      params["fechaDesde"] = fechaDesde;
    if (fechaHasta)
      params["fechaHasta"] = fechaHasta;
    return this.http.get(`${this.apiUrl}/exportar`, { params, responseType: "blob" });
  }
  /** Una página del historial (10 por defecto) con los totales del mismo filtro. */
  pagina(texto, estatus, fechaDesde, fechaHasta, soloMias, pagina, tamanio = 10) {
    const params = { pagina: String(pagina), tamanio: String(tamanio), soloMias: String(soloMias) };
    if (texto.trim())
      params["texto"] = texto.trim();
    if (estatus)
      params["estatus"] = estatus;
    if (fechaDesde)
      params["fechaDesde"] = fechaDesde;
    if (fechaHasta)
      params["fechaHasta"] = fechaHasta;
    return this.http.get(`${this.apiUrl}/pagina`, { params });
  }
  static \u0275fac = function HistorialService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _HistorialService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _HistorialService, factory: _HistorialService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HistorialService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/historial/historial.ts
var _forTrack0 = ($index, $item) => $item.valor;
var _forTrack1 = ($index, $item) => $item.numeroFolio;
function Historial_Conditional_13_For_71_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 43);
    \u0275\u0275listener("click", function Historial_Conditional_13_For_71_Template_button_click_0_listener() {
      const op_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.cambiarResultado(op_r4.valor));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const op_r4 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("activa", ctx_r1.resultado === op_r4.valor);
    \u0275\u0275attribute("aria-selected", ctx_r1.resultado === op_r4.valor);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(op_r4.etiqueta);
  }
}
function Historial_Conditional_13_Conditional_84_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 44);
    \u0275\u0275listener("click", function Historial_Conditional_13_Conditional_84_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.limpiarFiltros());
    });
    \u0275\u0275text(1, "Limpiar filtros");
    \u0275\u0275elementEnd();
  }
}
function Historial_Conditional_13_Conditional_85_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 8);
    \u0275\u0275text(1, "Cargando\u2026");
    \u0275\u0275elementEnd();
  }
}
function Historial_Conditional_13_Conditional_86_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 8);
    \u0275\u0275text(1, "No hay quejas atendidas que coincidan con los filtros.");
    \u0275\u0275elementEnd();
  }
}
function Historial_Conditional_13_Conditional_87_For_21_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 53);
    \u0275\u0275text(1, "Ventanilla");
    \u0275\u0275elementEnd();
  }
}
function Historial_Conditional_13_Conditional_87_For_21_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 57);
    \u0275\u0275text(1, "Turnada");
    \u0275\u0275elementEnd();
  }
}
function Historial_Conditional_13_Conditional_87_For_21_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 58);
    \u0275\u0275text(1, "Con observaciones");
    \u0275\u0275elementEnd();
  }
}
function Historial_Conditional_13_Conditional_87_For_21_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 55);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const f_r7 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(f_r7.folioPrimerContacto);
  }
}
function Historial_Conditional_13_Conditional_87_For_21_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "em", 60);
    \u0275\u0275text(1, "(t\xFA)");
    \u0275\u0275elementEnd();
  }
}
function Historial_Conditional_13_Conditional_87_For_21_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "tr")(1, "td")(2, "span", 52);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(4, Historial_Conditional_13_Conditional_87_For_21_Conditional_4_Template, 2, 0, "span", 53);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "td")(6, "span", 54);
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "date");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "td")(10, "span", 54);
    \u0275\u0275text(11);
    \u0275\u0275pipe(12, "date");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span", 55);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "td", 56);
    \u0275\u0275text(16);
    \u0275\u0275elementStart(17, "span", 55);
    \u0275\u0275text(18);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(19, "td");
    \u0275\u0275conditionalCreate(20, Historial_Conditional_13_Conditional_87_For_21_Conditional_20_Template, 2, 0, "span", 57)(21, Historial_Conditional_13_Conditional_87_For_21_Conditional_21_Template, 2, 0, "span", 58);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "td", 59);
    \u0275\u0275text(23);
    \u0275\u0275conditionalCreate(24, Historial_Conditional_13_Conditional_87_For_21_Conditional_24_Template, 2, 1, "span", 55);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "td");
    \u0275\u0275text(26);
    \u0275\u0275conditionalCreate(27, Historial_Conditional_13_Conditional_87_For_21_Conditional_27_Template, 2, 0, "em", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "td", 47)(29, "button", 61);
    \u0275\u0275listener("click", function Historial_Conditional_13_Conditional_87_For_21_Template_button_click_29_listener() {
      const f_r7 = \u0275\u0275restoreView(_r6).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.verDetalle(f_r7));
    });
    \u0275\u0275text(30);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const f_r7 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("mia", f_r7.esMia);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(f_r7.numeroFolio);
    \u0275\u0275advance();
    \u0275\u0275conditional(f_r7.tipoIngreso === "Ventanilla" ? 4 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(8, 15, f_r7.fechaCreacion, "dd/MM/yy HH:mm"));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(f_r7.fechaAtencion ? \u0275\u0275pipeBind2(12, 18, f_r7.fechaAtencion, "dd/MM/yy HH:mm") : "\u2014");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("en ", ctx_r1.duracion(f_r7.horasAtencion));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", f_r7.nombreQuejoso, " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(f_r7.unidadAcademicaClave || "");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(f_r7.resultado === "TURNADO" ? 20 : 21);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", f_r7.estatusActual, " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(f_r7.folioPrimerContacto ? 24 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", f_r7.atendioNombre || "\u2014", " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(f_r7.esMia ? 27 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", f_r7.resultado === "RECHAZADO" ? "Ver motivo" : "Ver detalle", " ");
  }
}
function Historial_Conditional_13_Conditional_87_Conditional_25_For_4_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 64);
    \u0275\u0275text(1, "\u2026");
    \u0275\u0275elementEnd();
  }
}
function Historial_Conditional_13_Conditional_87_Conditional_25_For_4_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 38);
    \u0275\u0275listener("click", function Historial_Conditional_13_Conditional_87_Conditional_25_For_4_Conditional_1_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r9);
      const p_r10 = \u0275\u0275nextContext().$implicit;
      const ctx_r1 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r1.irAPagina(p_r10));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r10 = \u0275\u0275nextContext().$implicit;
    const ctx_r1 = \u0275\u0275nextContext(4);
    \u0275\u0275classProp("actual", p_r10 === ctx_r1.pagina);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(p_r10 + 1);
  }
}
function Historial_Conditional_13_Conditional_87_Conditional_25_For_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, Historial_Conditional_13_Conditional_87_Conditional_25_For_4_Conditional_0_Template, 2, 0, "span", 64)(1, Historial_Conditional_13_Conditional_87_Conditional_25_For_4_Conditional_1_Template, 2, 3, "button", 65);
  }
  if (rf & 2) {
    const p_r10 = ctx.$implicit;
    \u0275\u0275conditional(p_r10 === null ? 0 : 1);
  }
}
function Historial_Conditional_13_Conditional_87_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "nav", 51)(1, "button", 62);
    \u0275\u0275listener("click", function Historial_Conditional_13_Conditional_87_Conditional_25_Template_button_click_1_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.irAPagina(ctx_r1.pagina - 1));
    });
    \u0275\u0275text(2, "\u2039");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(3, Historial_Conditional_13_Conditional_87_Conditional_25_For_4_Template, 2, 1, null, null, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275elementStart(5, "button", 63);
    \u0275\u0275listener("click", function Historial_Conditional_13_Conditional_87_Conditional_25_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.irAPagina(ctx_r1.pagina + 1));
    });
    \u0275\u0275text(6, "\u203A");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const d_r11 = \u0275\u0275nextContext(2);
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r1.pagina === 0);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.paginasVisibles);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r1.pagina >= d_r11.totalPaginas - 1);
  }
}
function Historial_Conditional_13_Conditional_87_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 45)(1, "table", 46)(2, "thead")(3, "tr")(4, "th");
    \u0275\u0275text(5, "Folio");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "th");
    \u0275\u0275text(7, "Lleg\xF3");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "th");
    \u0275\u0275text(9, "Atendida");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "th");
    \u0275\u0275text(11, "Quejoso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "th");
    \u0275\u0275text(13, "Resultado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "th");
    \u0275\u0275text(15, "D\xF3nde va");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "th");
    \u0275\u0275text(17, "Atendi\xF3");
    \u0275\u0275elementEnd();
    \u0275\u0275element(18, "th", 47);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(19, "tbody");
    \u0275\u0275repeaterCreate(20, Historial_Conditional_13_Conditional_87_For_21_Template, 31, 21, "tr", 48, _forTrack1);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(22, "div", 49)(23, "span", 50);
    \u0275\u0275text(24);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(25, Historial_Conditional_13_Conditional_87_Conditional_25_Template, 7, 2, "nav", 51);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const d_r11 = \u0275\u0275nextContext();
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275classProp("recargando", ctx_r1.cargando);
    \u0275\u0275advance(20);
    \u0275\u0275repeater(d_r11.filas);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.rangoMostrado);
    \u0275\u0275advance();
    \u0275\u0275conditional(d_r11.totalPaginas > 1 ? 25 : -1);
  }
}
function Historial_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 10)(1, "div", 11)(2, "span", 12);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(3, "svg", 4);
    \u0275\u0275element(4, "path", 13)(5, "polyline", 14)(6, "polyline", 15);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(7, "span", 16)(8, "span", 17);
    \u0275\u0275text(9, "Atendidas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "strong");
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "span", 18);
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(14, "button", 19);
    \u0275\u0275listener("click", function Historial_Conditional_13_Template_button_click_14_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cambiarResultado(ctx_r1.resultado === "TURNADO" ? "" : "TURNADO"));
    });
    \u0275\u0275elementStart(15, "span", 12);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(16, "svg", 4);
    \u0275\u0275element(17, "path", 20)(18, "path", 21);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(19, "span", 16)(20, "span", 17);
    \u0275\u0275text(21, "Turnadas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "strong");
    \u0275\u0275text(23);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "span", 18);
    \u0275\u0275text(25);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(26, "button", 19);
    \u0275\u0275listener("click", function Historial_Conditional_13_Template_button_click_26_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cambiarResultado(ctx_r1.resultado === "RECHAZADO" ? "" : "RECHAZADO"));
    });
    \u0275\u0275elementStart(27, "span", 12);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(28, "svg", 4);
    \u0275\u0275element(29, "path", 22)(30, "path", 23);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(31, "span", 16)(32, "span", 17);
    \u0275\u0275text(33, "Con observaciones");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "strong");
    \u0275\u0275text(35);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(36, "span", 18);
    \u0275\u0275text(37);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(38, "button", 19);
    \u0275\u0275listener("click", function Historial_Conditional_13_Template_button_click_38_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cambiarSoloMias(!ctx_r1.soloMias));
    });
    \u0275\u0275elementStart(39, "span", 12);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(40, "svg", 4);
    \u0275\u0275element(41, "circle", 24)(42, "path", 25);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(43, "span", 16)(44, "span", 17);
    \u0275\u0275text(45, "Atendidas por ti");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "strong");
    \u0275\u0275text(47);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(48, "span", 18);
    \u0275\u0275text(49);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(50, "div", 26)(51, "span", 12);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(52, "svg", 4);
    \u0275\u0275element(53, "circle", 27)(54, "polyline", 28);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(55, "span", 16)(56, "span", 17);
    \u0275\u0275text(57, "Tiempo de atenci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(58, "strong");
    \u0275\u0275text(59);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(60, "span", 18);
    \u0275\u0275text(61, "promedio de llegada a atenci\xF3n");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(62, "div", 29)(63, "div", 30)(64, "div", 31);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(65, "svg", 4);
    \u0275\u0275element(66, "circle", 32)(67, "path", 33);
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(68, "input", 34);
    \u0275\u0275twoWayListener("ngModelChange", function Historial_Conditional_13_Template_input_ngModelChange_68_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.texto, $event) || (ctx_r1.texto = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("ngModelChange", function Historial_Conditional_13_Template_input_ngModelChange_68_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.buscar());
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(69, "div", 35);
    \u0275\u0275repeaterCreate(70, Historial_Conditional_13_For_71_Template, 2, 4, "button", 36, _forTrack0);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(72, "div", 37)(73, "button", 38);
    \u0275\u0275listener("click", function Historial_Conditional_13_Template_button_click_73_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cambiarSoloMias(false));
    });
    \u0275\u0275text(74, "Todo el equipo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(75, "button", 38);
    \u0275\u0275listener("click", function Historial_Conditional_13_Template_button_click_75_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cambiarSoloMias(true));
    });
    \u0275\u0275text(76, "Solo yo");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(77, "div", 39)(78, "label");
    \u0275\u0275text(79, "Llegaron del ");
    \u0275\u0275elementStart(80, "input", 40);
    \u0275\u0275twoWayListener("ngModelChange", function Historial_Conditional_13_Template_input_ngModelChange_80_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.fechaDesde, $event) || (ctx_r1.fechaDesde = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("change", function Historial_Conditional_13_Template_input_change_80_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cambiarFechas());
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(81, "label");
    \u0275\u0275text(82, "al ");
    \u0275\u0275elementStart(83, "input", 41);
    \u0275\u0275twoWayListener("ngModelChange", function Historial_Conditional_13_Template_input_ngModelChange_83_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.fechaHasta, $event) || (ctx_r1.fechaHasta = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("change", function Historial_Conditional_13_Template_input_change_83_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cambiarFechas());
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(84, Historial_Conditional_13_Conditional_84_Template, 2, 0, "button", 42);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(85, Historial_Conditional_13_Conditional_85_Template, 2, 0, "p", 8)(86, Historial_Conditional_13_Conditional_86_Template, 2, 0, "div", 8)(87, Historial_Conditional_13_Conditional_87_Template, 26, 4);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const d_r11 = ctx;
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(11);
    \u0275\u0275textInterpolate(d_r11.resumen.total);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.hayFiltros ? "con los filtros aplicados" : "en todo el historial");
    \u0275\u0275advance();
    \u0275\u0275classProp("seleccionado", ctx_r1.resultado === "TURNADO");
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(d_r11.resumen.turnadas);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", ctx_r1.porcentaje(d_r11.resumen.turnadas, d_r11.resumen.total), "% admitidas a Primer Contacto");
    \u0275\u0275advance();
    \u0275\u0275classProp("seleccionado", ctx_r1.resultado === "RECHAZADO");
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(d_r11.resumen.rechazadas);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", ctx_r1.porcentaje(d_r11.resumen.rechazadas, d_r11.resumen.total), "% regresadas al quejoso");
    \u0275\u0275advance();
    \u0275\u0275classProp("seleccionado", ctx_r1.soloMias);
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(d_r11.resumen.atendidasPorMi);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.soloMias ? "mostrando solo las tuyas" : "clic para ver solo las tuyas");
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate(ctx_r1.duracion(d_r11.resumen.horasPromedioAtencion));
    \u0275\u0275advance(9);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.texto);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.opcionesResultado);
    \u0275\u0275advance(3);
    \u0275\u0275classProp("activa", !ctx_r1.soloMias);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("activa", ctx_r1.soloMias);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.fechaDesde);
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.fechaHasta);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.hayFiltros ? 84 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.cargando && !d_r11.filas.length ? 85 : d_r11.filas.length === 0 ? 86 : 87);
  }
}
function Historial_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 8);
    \u0275\u0275text(1, "Cargando historial\u2026");
    \u0275\u0275elementEnd();
  }
}
function Historial_Conditional_15_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 71);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.detalleSeleccionado.motivoRechazo);
  }
}
function Historial_Conditional_15_Conditional_20_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 70)(1, "strong");
    \u0275\u0275text(2, "Comentarios:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", ctx_r1.detalleSeleccionado.comentariosRecepcion);
  }
}
function Historial_Conditional_15_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 70)(1, "strong");
    \u0275\u0275text(2, "\xC1rea:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 70)(5, "strong");
    \u0275\u0275text(6, "Defensor asignado:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(8, Historial_Conditional_15_Conditional_20_Conditional_8_Template, 4, 1, "p", 70);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", ctx_r1.detalleSeleccionado.areaTurnada);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", ctx_r1.detalleSeleccionado.defensorAsignado);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.detalleSeleccionado.comentariosRecepcion ? 8 : -1);
  }
}
function Historial_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 66);
    \u0275\u0275listener("click", function Historial_Conditional_15_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarDetalle());
    });
    \u0275\u0275elementStart(1, "div", 67);
    \u0275\u0275listener("click", function Historial_Conditional_15_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 68)(3, "h3");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 69);
    \u0275\u0275listener("click", function Historial_Conditional_15_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarDetalle());
    });
    \u0275\u0275text(6, "\u2715");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "p", 70)(8, "strong");
    \u0275\u0275text(9, "Quejoso:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "p", 70)(12, "strong");
    \u0275\u0275text(13, "Motivo:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "p", 70)(16, "strong");
    \u0275\u0275text(17, "Estatus:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(18);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(19, Historial_Conditional_15_Conditional_19_Template, 2, 1, "p", 71)(20, Historial_Conditional_15_Conditional_20_Template, 9, 3);
    \u0275\u0275elementStart(21, "div", 72)(22, "button", 73);
    \u0275\u0275listener("click", function Historial_Conditional_15_Template_button_click_22_listener() {
      \u0275\u0275restoreView(_r12);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarDetalle());
    });
    \u0275\u0275text(23, "Cerrar");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.detalleSeleccionado.numeroFolio);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1(" ", ctx_r1.detalleSeleccionado.nombreCompletoQuejoso);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", ctx_r1.detalleSeleccionado.motivo);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", ctx_r1.detalleSeleccionado.estatus);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.detalleSeleccionado.estatus === "RECHAZADA" ? 19 : ctx_r1.detalleSeleccionado.estatus === "TURNADA" ? 20 : -1);
  }
}
var TAMANIO_PAGINA = 10;
var Historial = class _Historial {
  historialService;
  revisionService;
  toast;
  cdr;
  opcionesResultado = [
    { valor: "", etiqueta: "Todas" },
    { valor: "TURNADO", etiqueta: "Turnadas" },
    { valor: "RECHAZADO", etiqueta: "Con observaciones" }
  ];
  datos = null;
  cargando = true;
  exportando = false;
  texto = "";
  resultado = "";
  soloMias = false;
  fechaDesde = "";
  fechaHasta = "";
  pagina = 0;
  mostrarModalDetalle = false;
  detalleSeleccionado = null;
  fechaHoy = (() => {
    const t = new Intl.DateTimeFormat("es-MX", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(/* @__PURE__ */ new Date());
    return t.charAt(0).toUpperCase() + t.slice(1);
  })();
  busquedaId = null;
  constructor(historialService, revisionService, toast, cdr) {
    this.historialService = historialService;
    this.revisionService = revisionService;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.cargar();
  }
  ngOnDestroy() {
    if (this.busquedaId !== null) {
      clearTimeout(this.busquedaId);
    }
  }
  // ---------------- filtros ----------------
  cambiarResultado(valor) {
    this.resultado = valor;
    this.recargarDesdeInicio();
  }
  cambiarSoloMias(valor) {
    this.soloMias = valor;
    this.recargarDesdeInicio();
  }
  buscar() {
    if (this.busquedaId !== null) {
      clearTimeout(this.busquedaId);
    }
    this.busquedaId = setTimeout(() => this.recargarDesdeInicio(), 350);
  }
  cambiarFechas() {
    if (this.fechaDesde && this.fechaHasta && this.fechaDesde > this.fechaHasta) {
      this.toast.advertencia('La fecha "Desde" no puede ser posterior a la fecha "Hasta".');
      return;
    }
    this.recargarDesdeInicio();
  }
  limpiarFiltros() {
    this.texto = "";
    this.resultado = "";
    this.soloMias = false;
    this.fechaDesde = "";
    this.fechaHasta = "";
    this.recargarDesdeInicio();
  }
  get hayFiltros() {
    return !!(this.texto || this.resultado || this.soloMias || this.fechaDesde || this.fechaHasta);
  }
  recargarDesdeInicio() {
    this.pagina = 0;
    this.cargar();
  }
  // ---------------- paginado ----------------
  irAPagina(p) {
    if (!this.datos || p < 0 || p >= this.datos.totalPaginas || p === this.pagina) {
      return;
    }
    this.pagina = p;
    this.cargar();
  }
  get paginasVisibles() {
    const total = this.datos?.totalPaginas ?? 0;
    const paginas = [];
    for (let i = 0; i < total; i++) {
      if (i === 0 || i === total - 1 || Math.abs(i - this.pagina) <= 1) {
        paginas.push(i);
      } else if (paginas[paginas.length - 1] !== null) {
        paginas.push(null);
      }
    }
    return paginas;
  }
  get rangoMostrado() {
    if (!this.datos || this.datos.totalElementos === 0) {
      return "";
    }
    const desde = this.datos.pagina * this.datos.tamanio + 1;
    return `Mostrando ${desde}\u2013${desde + this.datos.filas.length - 1} de ${this.datos.totalElementos}`;
  }
  // ---------------- textos ----------------
  /** 5 h, 2.3 días… */
  duracion(horas) {
    if (horas === null || horas === void 0) {
      return "\u2014";
    }
    if (horas < 1) {
      return `${Math.max(1, Math.round(horas * 60))} min`;
    }
    if (horas < 48) {
      return `${Math.round(horas)} h`;
    }
    return `${(horas / 24).toFixed(1)} d\xEDas`;
  }
  porcentaje(parte, total) {
    return total > 0 ? Math.round(parte / total * 100) : 0;
  }
  // ---------------- detalle y exportación ----------------
  verDetalle(fila) {
    this.revisionService.detalle(fila.numeroFolio).subscribe({
      next: (detalle) => {
        this.detalleSeleccionado = detalle;
        this.mostrarModalDetalle = true;
        this.cdr.detectChanges();
      },
      error: () => this.toast.error("No se pudo cargar el detalle de la queja.")
    });
  }
  cerrarDetalle() {
    this.mostrarModalDetalle = false;
    this.detalleSeleccionado = null;
  }
  exportar() {
    this.exportando = true;
    this.historialService.exportar(this.texto, this.resultado, this.fechaDesde, this.fechaHasta).subscribe({
      next: (blob) => {
        this.exportando = false;
        const url = URL.createObjectURL(blob);
        const enlace = document.createElement("a");
        enlace.href = url;
        enlace.download = "historial-tramites.xlsx";
        enlace.click();
        URL.revokeObjectURL(url);
        this.cdr.detectChanges();
      },
      error: () => {
        this.exportando = false;
        this.toast.error("No se pudo exportar el reporte.");
        this.cdr.detectChanges();
      }
    });
  }
  cargar() {
    this.cargando = true;
    this.historialService.pagina(this.texto, this.resultado, this.fechaDesde, this.fechaHasta, this.soloMias, this.pagina, TAMANIO_PAGINA).subscribe({
      next: (datos) => {
        this.datos = datos;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.toast.error("No se pudo cargar el historial.");
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function Historial_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Historial)(\u0275\u0275directiveInject(HistorialService), \u0275\u0275directiveInject(RevisionService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Historial, selectors: [["app-historial"]], decls: 16, vars: 5, consts: [[1, "pagina"], [1, "encabezado"], [1, "fecha"], ["type", "button", 1, "btn-guinda", 3, "click", "disabled"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"], ["points", "7 10 12 15 17 10"], ["x1", "12", "y1", "15", "x2", "12", "y2", "3"], [1, "estado"], [1, "modal-overlay"], [1, "indicadores"], [1, "indicador"], [1, "indicador-icono"], ["d", "M3 12a9 9 0 1 0 3-6.7"], ["points", "3 4 3 9 8 9"], ["points", "12 7 12 12 16 14"], [1, "indicador-cuerpo"], [1, "indicador-titulo"], [1, "indicador-detalle"], ["type", "button", 1, "indicador", "clic", 3, "click"], ["d", "M5 12h14"], ["d", "M12 5l7 7-7 7"], ["d", "M9 14 4 9l5-5"], ["d", "M4 9h10.5a5.5 5.5 0 0 1 0 11H11"], ["cx", "12", "cy", "8", "r", "4"], ["d", "M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1"], ["title", "Promedio entre que lleg\xF3 la queja y Recepci\xF3n la atendi\xF3", 1, "indicador"], ["cx", "12", "cy", "12", "r", "10"], ["points", "12 6 12 12 16 14"], [1, "card-panel"], [1, "filtros"], [1, "buscador"], ["cx", "11", "cy", "11", "r", "7"], ["d", "m21 21-4.3-4.3"], ["type", "search", "name", "texto", "placeholder", "Folio, nombre o unidad", "aria-label", "Buscar en el historial", 3, "ngModelChange", "ngModel"], ["role", "tablist", 1, "pestanas"], ["type", "button", "role", "tab", 3, "activa"], ["role", "tablist", "aria-label", "Qui\xE9n la atendi\xF3", 1, "pestanas"], ["type", "button", 3, "click"], [1, "rango"], ["type", "date", "name", "fechaDesde", 3, "ngModelChange", "change", "ngModel"], ["type", "date", "name", "fechaHasta", 3, "ngModelChange", "change", "ngModel"], ["type", "button", 1, "limpiar"], ["type", "button", "role", "tab", 3, "click"], ["type", "button", 1, "limpiar", 3, "click"], [1, "tabla-envoltura"], [1, "tabla-cola"], [1, "derecha"], [3, "mia"], [1, "paginado"], [1, "paginado-rango"], ["aria-label", "P\xE1ginas del historial"], [1, "folio"], [1, "etiqueta-origen"], [1, "fecha-fila"], [1, "hace"], [1, "quejoso"], [1, "chip", "contigo"], [1, "chip", "observaciones"], [1, "donde"], [1, "tu"], ["type", "button", 1, "btn-fila", "secundario", 3, "click"], ["type", "button", "aria-label", "P\xE1gina anterior", 3, "click", "disabled"], ["type", "button", "aria-label", "P\xE1gina siguiente", 3, "click", "disabled"], [1, "paginado-salto"], ["type", "button", 3, "actual"], [1, "modal-overlay", 3, "click"], [1, "modal", "card", 3, "click"], [1, "modal-header"], ["aria-label", "Cerrar", 1, "modal-cerrar", 3, "click"], [1, "detalle-linea"], [1, "aviso-peligro"], [1, "modal-acciones"], [1, "btn-primary", 3, "click"]], template: function Historial_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "section", 0)(1, "div", 1)(2, "div")(3, "h2");
      \u0275\u0275text(4, "Historial de Recepci\xF3n");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(5, "p", 2);
      \u0275\u0275text(6);
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(7, "button", 3);
      \u0275\u0275listener("click", function Historial_Template_button_click_7_listener() {
        return ctx.exportar();
      });
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(8, "svg", 4);
      \u0275\u0275element(9, "path", 5)(10, "polyline", 6)(11, "line", 7);
      \u0275\u0275elementEnd();
      \u0275\u0275text(12);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(13, Historial_Conditional_13_Template, 88, 24)(14, Historial_Conditional_14_Template, 2, 0, "p", 8);
      \u0275\u0275elementEnd();
      \u0275\u0275conditionalCreate(15, Historial_Conditional_15_Template, 24, 5, "div", 9);
    }
    if (rf & 2) {
      let tmp_3_0;
      \u0275\u0275advance(6);
      \u0275\u0275textInterpolate1("", ctx.fechaHoy, " \xB7 Quejas que Recepci\xF3n ya turn\xF3 o regres\xF3 con observaciones.");
      \u0275\u0275advance();
      \u0275\u0275property("disabled", ctx.exportando);
      \u0275\u0275advance(5);
      \u0275\u0275textInterpolate1(" ", ctx.exportando ? "Exportando\u2026" : "Exportar a Excel", " ");
      \u0275\u0275advance();
      \u0275\u0275conditional((tmp_3_0 = ctx.datos) ? 13 : ctx.cargando ? 14 : -1, tmp_3_0);
      \u0275\u0275advance(2);
      \u0275\u0275conditional(ctx.mostrarModalDetalle && ctx.detalleSeleccionado ? 15 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, DefaultValueAccessor, NgControlStatus, NgModel, DatePipe], styles: ['@charset "UTF-8";\n\n\n.pagina[_ngcontent-%COMP%] {\n  max-width: 1360px;\n}\n.encabezado[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 24px;\n  margin-bottom: 24px;\n}\n.encabezado[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--guinda);\n  font-size: 28px;\n  font-weight: 800;\n}\n.encabezado[_ngcontent-%COMP%]   .fecha[_ngcontent-%COMP%] {\n  margin: 4px 0 0;\n  color: var(--texto-suave);\n  font-size: 14px;\n}\n.btn-guinda[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  padding: 10px 16px;\n  border-radius: 8px;\n  background: var(--guinda);\n  color: #fff;\n  font-weight: 700;\n  text-decoration: none;\n  white-space: nowrap;\n}\n.btn-guinda[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n}\n.btn-guinda[_ngcontent-%COMP%]:hover {\n  background: var(--guinda-oscuro);\n}\n.indicadores[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));\n  gap: 16px;\n  margin-bottom: 24px;\n}\n.indicador[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 12px;\n  padding: 16px;\n  border-radius: 14px;\n  background: #fff;\n  border: 1px solid transparent;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);\n  text-align: left;\n  font: inherit;\n  color: inherit;\n}\n.indicador.clic[_ngcontent-%COMP%] {\n  cursor: pointer;\n  transition: border-color 0.15s ease, transform 0.15s ease;\n}\n.indicador.clic[_ngcontent-%COMP%]:hover {\n  border-color: #e6c9d6;\n  transform: translateY(-1px);\n}\n.indicador.seleccionado[_ngcontent-%COMP%] {\n  border-color: var(--guinda);\n}\n.indicador.alerta[_ngcontent-%COMP%] {\n  background: #fff8eb;\n  border-color: #f0d7a6;\n}\n.indicador.alerta[_ngcontent-%COMP%]   .indicador-icono[_ngcontent-%COMP%] {\n  color: var(--advertencia);\n  background: #fdf0d6;\n}\n.indicador-icono[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  flex-shrink: 0;\n  display: grid;\n  place-items: center;\n  border-radius: 10px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.indicador-icono[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 22px;\n  height: 22px;\n}\n.indicador-cuerpo[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n}\n.indicador-cuerpo[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: var(--negro-inst);\n  font-size: 26px;\n  font-weight: 900;\n  line-height: 1.3;\n}\n.indicador-titulo[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 13px;\n  font-weight: 700;\n}\n.indicador-detalle[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 12px;\n  line-height: 1.35;\n}\n.distribucion[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) 300px;\n  gap: 24px;\n  align-items: start;\n}\n@media (max-width: 1280px) {\n  .distribucion[_ngcontent-%COMP%] {\n    grid-template-columns: minmax(0, 1fr);\n  }\n}\n.card-panel[_ngcontent-%COMP%] {\n  background: #fff;\n  border-radius: 14px;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);\n  padding: 20px;\n}\n.card-panel[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 18px;\n  font-weight: 900;\n  color: var(--negro-inst);\n}\n.cola-encabezado[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  flex-wrap: wrap;\n  gap: 12px 24px;\n  margin-bottom: 14px;\n}\n.cola-encabezado[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 4px 0 0;\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.buscador[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  align-items: center;\n  flex: 0 1 300px;\n}\n.buscador[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 10px;\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.buscador[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 9px 32px 9px 34px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font: inherit;\n  font-size: 14px;\n}\n.buscador[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]:focus {\n  outline: 2px solid var(--guinda-suave);\n  border-color: var(--guinda);\n}\n.buscador[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]::-webkit-search-cancel-button {\n  display: none;\n}\n.buscador-limpiar[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 6px;\n  border: none;\n  background: none;\n  font-size: 18px;\n  color: var(--texto-suave);\n}\n.pestanas[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 6px;\n  overflow-x: auto;\n  padding-bottom: 12px;\n  margin-bottom: 4px;\n  border-bottom: 1px solid #eee;\n}\n.pestanas[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  padding: 7px 12px;\n  border: 1px solid transparent;\n  border-radius: 999px;\n  background: #f4f5f7;\n  color: var(--texto);\n  font-size: 13px;\n  font-weight: 600;\n  white-space: nowrap;\n}\n.pestanas[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover {\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.pestanas[_ngcontent-%COMP%]   button.activa[_ngcontent-%COMP%] {\n  background: var(--guinda);\n  color: #fff;\n}\n.pestanas[_ngcontent-%COMP%]   button.activa[_ngcontent-%COMP%]   .pestana-conteo[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.22);\n  color: #fff;\n}\n.pestana-conteo[_ngcontent-%COMP%] {\n  min-width: 22px;\n  padding: 1px 7px;\n  border-radius: 999px;\n  background: #fff;\n  color: var(--texto-suave);\n  font-size: 12px;\n  text-align: center;\n}\n.estado[_ngcontent-%COMP%] {\n  padding: 32px 12px;\n  color: var(--texto-suave);\n  text-align: center;\n}\n.estado.vacio[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  color: #c9c9c9;\n}\n.tabla-envoltura[_ngcontent-%COMP%] {\n  overflow-x: auto;\n}\n.tabla-cola[_ngcontent-%COMP%] {\n  width: 100%;\n  border-collapse: separate;\n  border-spacing: 0 6px;\n  font-size: 14px;\n}\n.tabla-cola[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  padding: 10px 12px 4px;\n  color: var(--texto-suave);\n  font-size: 12px;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n  text-align: left;\n  white-space: nowrap;\n}\n.tabla-cola[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  padding: 10px 12px;\n  background: #f9fafb;\n  vertical-align: middle;\n}\n.tabla-cola[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:first-child {\n  border-radius: 8px 0 0 8px;\n}\n.tabla-cola[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:last-child {\n  border-radius: 0 8px 8px 0;\n}\n.tabla-cola[_ngcontent-%COMP%]   tr.mia[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  background: #f1f8f3;\n}\n.tabla-cola[_ngcontent-%COMP%]   tr.ocupada[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  color: #8a8f98;\n}\n.tabla-cola[_ngcontent-%COMP%]   .centro[_ngcontent-%COMP%] {\n  text-align: center;\n}\n.tabla-cola[_ngcontent-%COMP%]   .derecha[_ngcontent-%COMP%] {\n  text-align: right;\n}\n.folio[_ngcontent-%COMP%] {\n  display: block;\n  font-weight: 700;\n  color: var(--negro-inst);\n  white-space: nowrap;\n}\n.etiqueta-origen[_ngcontent-%COMP%] {\n  display: inline-block;\n  margin-top: 2px;\n  padding: 0 6px;\n  border-radius: 4px;\n  background: #ece7f6;\n  color: #5b3d99;\n  font-size: 11px;\n  font-weight: 600;\n}\n.fecha-fila[_ngcontent-%COMP%] {\n  display: block;\n  white-space: nowrap;\n}\n.hace[_ngcontent-%COMP%] {\n  display: block;\n  color: var(--texto-suave);\n  font-size: 12px;\n}\n.quejoso[_ngcontent-%COMP%] {\n  min-width: 160px;\n}\n.docs[_ngcontent-%COMP%] {\n  display: inline-grid;\n  place-items: center;\n  width: 22px;\n  height: 22px;\n  border-radius: 50%;\n  color: #fff;\n  font-size: 12px;\n  font-weight: 800;\n}\n.docs.ok[_ngcontent-%COMP%] {\n  background: var(--exito);\n}\n.docs.falta[_ngcontent-%COMP%] {\n  background: var(--advertencia);\n}\n.chip[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding: 3px 10px;\n  border-radius: 999px;\n  font-size: 12px;\n  font-weight: 700;\n  white-space: nowrap;\n  max-width: 190px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  vertical-align: middle;\n}\n.chip.nueva[_ngcontent-%COMP%] {\n  background: #fbf1e0;\n  color: #9a6512;\n}\n.chip.corregida[_ngcontent-%COMP%] {\n  background: #ece7f6;\n  color: #5b3d99;\n}\n.chip.contigo[_ngcontent-%COMP%] {\n  background: #e3f3e8;\n  color: #1d6b3a;\n}\n.chip.ocupada[_ngcontent-%COMP%] {\n  background: #e8eefc;\n  color: #2f55b3;\n}\n.acciones[_ngcontent-%COMP%] {\n  white-space: nowrap;\n}\n.btn-fila[_ngcontent-%COMP%] {\n  margin-left: 6px;\n  padding: 7px 14px;\n  border: 1px solid var(--guinda);\n  border-radius: 6px;\n  background: var(--guinda);\n  color: #fff;\n  font-size: 13px;\n  font-weight: 700;\n}\n.btn-fila[_ngcontent-%COMP%]:hover:not(:disabled) {\n  background: var(--guinda-oscuro);\n}\n.btn-fila.secundario[_ngcontent-%COMP%] {\n  background: #fff;\n  color: var(--guinda);\n}\n.btn-fila.secundario[_ngcontent-%COMP%]:hover:not(:disabled) {\n  background: var(--guinda-suave);\n}\n.btn-fila[_ngcontent-%COMP%]:disabled {\n  border-color: #d5d8de;\n  background: #eceef1;\n  color: #8a8f98;\n  cursor: not-allowed;\n}\n.paginado[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  flex-wrap: wrap;\n  gap: 12px;\n  margin-top: 12px;\n  padding-top: 12px;\n  border-top: 1px solid #eee;\n}\n.paginado[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n.paginado[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  min-width: 34px;\n  height: 34px;\n  padding: 0 8px;\n  border: 1px solid var(--borde);\n  border-radius: 6px;\n  background: #fff;\n  color: var(--texto);\n  font-weight: 600;\n}\n.paginado[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover:not(:disabled) {\n  border-color: var(--guinda);\n  color: var(--guinda);\n}\n.paginado[_ngcontent-%COMP%]   button.actual[_ngcontent-%COMP%] {\n  border-color: var(--guinda);\n  background: var(--guinda);\n  color: #fff;\n}\n.paginado[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:disabled {\n  opacity: 0.4;\n  cursor: not-allowed;\n}\n.paginado-rango[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.paginado-salto[_ngcontent-%COMP%] {\n  padding: 0 4px;\n  color: var(--texto-suave);\n}\n.filtros[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n  gap: 10px 14px;\n  margin-bottom: 8px;\n}\n.filtros[_ngcontent-%COMP%]   .pestanas[_ngcontent-%COMP%] {\n  border-bottom: none;\n  padding-bottom: 0;\n  margin-bottom: 0;\n}\n.rango[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 13px;\n  color: var(--texto-suave);\n}\n.rango[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.rango[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  padding: 6px 8px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font: inherit;\n}\n.limpiar[_ngcontent-%COMP%] {\n  border: none;\n  background: none;\n  color: var(--guinda);\n  font-weight: 600;\n  text-decoration: underline;\n}\n.recargando[_ngcontent-%COMP%] {\n  opacity: 0.6;\n}\n.chip.observaciones[_ngcontent-%COMP%] {\n  background: #fdecec;\n  color: var(--peligro);\n}\n.donde[_ngcontent-%COMP%] {\n  min-width: 150px;\n  font-size: 13px;\n}\n.btn-fila[_ngcontent-%COMP%] {\n  white-space: nowrap;\n}\n.tu[_ngcontent-%COMP%] {\n  font-style: normal;\n  color: var(--guinda);\n}\nbutton.btn-guinda[_ngcontent-%COMP%] {\n  border: none;\n}\n.detalle-linea[_ngcontent-%COMP%] {\n  font-size: 0.9rem;\n  margin: 0 0 8px;\n}\n/*# sourceMappingURL=historial.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Historial, [{
    type: Component,
    args: [{ selector: "app-historial", standalone: true, imports: [CommonModule, FormsModule], template: `<section class="pagina">
  <div class="encabezado">
    <div>
      <h2>Historial de Recepci\xF3n</h2>
      <p class="fecha">{{ fechaHoy }} \xB7 Quejas que Recepci\xF3n ya turn\xF3 o regres\xF3 con observaciones.</p>
    </div>
    <button type="button" class="btn-guinda" (click)="exportar()" [disabled]="exportando">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
      {{ exportando ? 'Exportando\u2026' : 'Exportar a Excel' }}
    </button>
  </div>

  @if (datos; as d) {
    <div class="indicadores">
      <div class="indicador">
        <span class="indicador-icono"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"></path><polyline points="3 4 3 9 8 9"></polyline><polyline points="12 7 12 12 16 14"></polyline></svg></span>
        <span class="indicador-cuerpo">
          <span class="indicador-titulo">Atendidas</span>
          <strong>{{ d.resumen.total }}</strong>
          <span class="indicador-detalle">{{ hayFiltros ? 'con los filtros aplicados' : 'en todo el historial' }}</span>
        </span>
      </div>
      <button type="button" class="indicador clic" [class.seleccionado]="resultado === 'TURNADO'" (click)="cambiarResultado(resultado === 'TURNADO' ? '' : 'TURNADO')">
        <span class="indicador-icono"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"></path><path d="M12 5l7 7-7 7"></path></svg></span>
        <span class="indicador-cuerpo">
          <span class="indicador-titulo">Turnadas</span>
          <strong>{{ d.resumen.turnadas }}</strong>
          <span class="indicador-detalle">{{ porcentaje(d.resumen.turnadas, d.resumen.total) }}% admitidas a Primer Contacto</span>
        </span>
      </button>
      <button type="button" class="indicador clic" [class.seleccionado]="resultado === 'RECHAZADO'" (click)="cambiarResultado(resultado === 'RECHAZADO' ? '' : 'RECHAZADO')">
        <span class="indicador-icono"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"></path><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"></path></svg></span>
        <span class="indicador-cuerpo">
          <span class="indicador-titulo">Con observaciones</span>
          <strong>{{ d.resumen.rechazadas }}</strong>
          <span class="indicador-detalle">{{ porcentaje(d.resumen.rechazadas, d.resumen.total) }}% regresadas al quejoso</span>
        </span>
      </button>
      <button type="button" class="indicador clic" [class.seleccionado]="soloMias" (click)="cambiarSoloMias(!soloMias)">
        <span class="indicador-icono"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"></circle><path d="M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1"></path></svg></span>
        <span class="indicador-cuerpo">
          <span class="indicador-titulo">Atendidas por ti</span>
          <strong>{{ d.resumen.atendidasPorMi }}</strong>
          <span class="indicador-detalle">{{ soloMias ? 'mostrando solo las tuyas' : 'clic para ver solo las tuyas' }}</span>
        </span>
      </button>
      <div class="indicador" title="Promedio entre que lleg\xF3 la queja y Recepci\xF3n la atendi\xF3">
        <span class="indicador-icono"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg></span>
        <span class="indicador-cuerpo">
          <span class="indicador-titulo">Tiempo de atenci\xF3n</span>
          <strong>{{ duracion(d.resumen.horasPromedioAtencion) }}</strong>
          <span class="indicador-detalle">promedio de llegada a atenci\xF3n</span>
        </span>
      </div>
    </div>

    <div class="card-panel">
      <div class="filtros">
        <div class="buscador">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><path d="m21 21-4.3-4.3"></path></svg>
          <input type="search" [(ngModel)]="texto" (ngModelChange)="buscar()" name="texto" placeholder="Folio, nombre o unidad" aria-label="Buscar en el historial" />
        </div>
        <div class="pestanas" role="tablist">
          @for (op of opcionesResultado; track op.valor) {
            <button type="button" role="tab" [class.activa]="resultado === op.valor" [attr.aria-selected]="resultado === op.valor"
                    (click)="cambiarResultado(op.valor)">{{ op.etiqueta }}</button>
          }
        </div>
        <div class="pestanas" role="tablist" aria-label="Qui\xE9n la atendi\xF3">
          <button type="button" [class.activa]="!soloMias" (click)="cambiarSoloMias(false)">Todo el equipo</button>
          <button type="button" [class.activa]="soloMias" (click)="cambiarSoloMias(true)">Solo yo</button>
        </div>
        <div class="rango">
          <label>Llegaron del
            <input type="date" [(ngModel)]="fechaDesde" (change)="cambiarFechas()" name="fechaDesde" />
          </label>
          <label>al
            <input type="date" [(ngModel)]="fechaHasta" (change)="cambiarFechas()" name="fechaHasta" />
          </label>
        </div>
        @if (hayFiltros) {
          <button type="button" class="limpiar" (click)="limpiarFiltros()">Limpiar filtros</button>
        }
      </div>

      @if (cargando && !d.filas.length) {
        <p class="estado">Cargando\u2026</p>
      } @else if (d.filas.length === 0) {
        <div class="estado">No hay quejas atendidas que coincidan con los filtros.</div>
      } @else {
        <div class="tabla-envoltura" [class.recargando]="cargando">
          <table class="tabla-cola">
            <thead>
              <tr>
                <th>Folio</th>
                <th>Lleg\xF3</th>
                <th>Atendida</th>
                <th>Quejoso</th>
                <th>Resultado</th>
                <th>D\xF3nde va</th>
                <th>Atendi\xF3</th>
                <th class="derecha"></th>
              </tr>
            </thead>
            <tbody>
              @for (f of d.filas; track f.numeroFolio) {
                <tr [class.mia]="f.esMia">
                  <td>
                    <span class="folio">{{ f.numeroFolio }}</span>
                    @if (f.tipoIngreso === 'Ventanilla') { <span class="etiqueta-origen">Ventanilla</span> }
                  </td>
                  <td><span class="fecha-fila">{{ f.fechaCreacion | date: 'dd/MM/yy HH:mm' }}</span></td>
                  <td>
                    <span class="fecha-fila">{{ f.fechaAtencion ? (f.fechaAtencion | date: 'dd/MM/yy HH:mm') : '\u2014' }}</span>
                    <span class="hace">en {{ duracion(f.horasAtencion) }}</span>
                  </td>
                  <td class="quejoso">
                    {{ f.nombreQuejoso }}
                    <span class="hace">{{ f.unidadAcademicaClave || '' }}</span>
                  </td>
                  <td>
                    @if (f.resultado === 'TURNADO') {
                      <span class="chip contigo">Turnada</span>
                    } @else {
                      <span class="chip observaciones">Con observaciones</span>
                    }
                  </td>
                  <td class="donde">
                    {{ f.estatusActual }}
                    @if (f.folioPrimerContacto) { <span class="hace">{{ f.folioPrimerContacto }}</span> }
                  </td>
                  <td>{{ f.atendioNombre || '\u2014' }} @if (f.esMia) { <em class="tu">(t\xFA)</em> }</td>
                  <td class="derecha">
                    <button type="button" class="btn-fila secundario" (click)="verDetalle(f)">
                      {{ f.resultado === 'RECHAZADO' ? 'Ver motivo' : 'Ver detalle' }}
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>

        <div class="paginado">
          <span class="paginado-rango">{{ rangoMostrado }}</span>
          @if (d.totalPaginas > 1) {
            <nav aria-label="P\xE1ginas del historial">
              <button type="button" (click)="irAPagina(pagina - 1)" [disabled]="pagina === 0" aria-label="P\xE1gina anterior">\u2039</button>
              @for (p of paginasVisibles; track $index) {
                @if (p === null) {
                  <span class="paginado-salto">\u2026</span>
                } @else {
                  <button type="button" [class.actual]="p === pagina" (click)="irAPagina(p)">{{ p + 1 }}</button>
                }
              }
              <button type="button" (click)="irAPagina(pagina + 1)" [disabled]="pagina >= d.totalPaginas - 1" aria-label="P\xE1gina siguiente">\u203A</button>
            </nav>
          }
        </div>
      }
    </div>
  } @else if (cargando) {
    <p class="estado">Cargando historial\u2026</p>
  }
</section>

@if (mostrarModalDetalle && detalleSeleccionado) {
  <div class="modal-overlay" (click)="cerrarDetalle()">
    <div class="modal card" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>{{ detalleSeleccionado.numeroFolio }}</h3>
        <button class="modal-cerrar" (click)="cerrarDetalle()" aria-label="Cerrar">\u2715</button>
      </div>

      <p class="detalle-linea"><strong>Quejoso:</strong> {{ detalleSeleccionado.nombreCompletoQuejoso }}</p>
      <p class="detalle-linea"><strong>Motivo:</strong> {{ detalleSeleccionado.motivo }}</p>
      <p class="detalle-linea"><strong>Estatus:</strong> {{ detalleSeleccionado.estatus }}</p>

      @if (detalleSeleccionado.estatus === 'RECHAZADA') {
        <p class="aviso-peligro">{{ detalleSeleccionado.motivoRechazo }}</p>
      } @else if (detalleSeleccionado.estatus === 'TURNADA') {
        <p class="detalle-linea"><strong>\xC1rea:</strong> {{ detalleSeleccionado.areaTurnada }}</p>
        <p class="detalle-linea"><strong>Defensor asignado:</strong> {{ detalleSeleccionado.defensorAsignado }}</p>
        @if (detalleSeleccionado.comentariosRecepcion) {
          <p class="detalle-linea"><strong>Comentarios:</strong> {{ detalleSeleccionado.comentariosRecepcion }}</p>
        }
      }

      <div class="modal-acciones">
        <button class="btn-primary" (click)="cerrarDetalle()">Cerrar</button>
      </div>
    </div>
  </div>
}
`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/historial/historial.scss */\n.pagina {\n  max-width: 1360px;\n}\n.encabezado {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 24px;\n  margin-bottom: 24px;\n}\n.encabezado h2 {\n  margin: 0;\n  color: var(--guinda);\n  font-size: 28px;\n  font-weight: 800;\n}\n.encabezado .fecha {\n  margin: 4px 0 0;\n  color: var(--texto-suave);\n  font-size: 14px;\n}\n.btn-guinda {\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  padding: 10px 16px;\n  border-radius: 8px;\n  background: var(--guinda);\n  color: #fff;\n  font-weight: 700;\n  text-decoration: none;\n  white-space: nowrap;\n}\n.btn-guinda svg {\n  width: 18px;\n  height: 18px;\n}\n.btn-guinda:hover {\n  background: var(--guinda-oscuro);\n}\n.indicadores {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));\n  gap: 16px;\n  margin-bottom: 24px;\n}\n.indicador {\n  display: flex;\n  align-items: flex-start;\n  gap: 12px;\n  padding: 16px;\n  border-radius: 14px;\n  background: #fff;\n  border: 1px solid transparent;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);\n  text-align: left;\n  font: inherit;\n  color: inherit;\n}\n.indicador.clic {\n  cursor: pointer;\n  transition: border-color 0.15s ease, transform 0.15s ease;\n}\n.indicador.clic:hover {\n  border-color: #e6c9d6;\n  transform: translateY(-1px);\n}\n.indicador.seleccionado {\n  border-color: var(--guinda);\n}\n.indicador.alerta {\n  background: #fff8eb;\n  border-color: #f0d7a6;\n}\n.indicador.alerta .indicador-icono {\n  color: var(--advertencia);\n  background: #fdf0d6;\n}\n.indicador-icono {\n  width: 40px;\n  height: 40px;\n  flex-shrink: 0;\n  display: grid;\n  place-items: center;\n  border-radius: 10px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.indicador-icono svg {\n  width: 22px;\n  height: 22px;\n}\n.indicador-cuerpo {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n}\n.indicador-cuerpo strong {\n  color: var(--negro-inst);\n  font-size: 26px;\n  font-weight: 900;\n  line-height: 1.3;\n}\n.indicador-titulo {\n  color: var(--texto-suave);\n  font-size: 13px;\n  font-weight: 700;\n}\n.indicador-detalle {\n  color: var(--texto-suave);\n  font-size: 12px;\n  line-height: 1.35;\n}\n.distribucion {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) 300px;\n  gap: 24px;\n  align-items: start;\n}\n@media (max-width: 1280px) {\n  .distribucion {\n    grid-template-columns: minmax(0, 1fr);\n  }\n}\n.card-panel {\n  background: #fff;\n  border-radius: 14px;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);\n  padding: 20px;\n}\n.card-panel h3 {\n  margin: 0;\n  font-size: 18px;\n  font-weight: 900;\n  color: var(--negro-inst);\n}\n.cola-encabezado {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  flex-wrap: wrap;\n  gap: 12px 24px;\n  margin-bottom: 14px;\n}\n.cola-encabezado p {\n  margin: 4px 0 0;\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.buscador {\n  position: relative;\n  display: flex;\n  align-items: center;\n  flex: 0 1 300px;\n}\n.buscador svg {\n  position: absolute;\n  left: 10px;\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.buscador input {\n  width: 100%;\n  padding: 9px 32px 9px 34px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font: inherit;\n  font-size: 14px;\n}\n.buscador input:focus {\n  outline: 2px solid var(--guinda-suave);\n  border-color: var(--guinda);\n}\n.buscador input::-webkit-search-cancel-button {\n  display: none;\n}\n.buscador-limpiar {\n  position: absolute;\n  right: 6px;\n  border: none;\n  background: none;\n  font-size: 18px;\n  color: var(--texto-suave);\n}\n.pestanas {\n  display: flex;\n  gap: 6px;\n  overflow-x: auto;\n  padding-bottom: 12px;\n  margin-bottom: 4px;\n  border-bottom: 1px solid #eee;\n}\n.pestanas button {\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  padding: 7px 12px;\n  border: 1px solid transparent;\n  border-radius: 999px;\n  background: #f4f5f7;\n  color: var(--texto);\n  font-size: 13px;\n  font-weight: 600;\n  white-space: nowrap;\n}\n.pestanas button:hover {\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.pestanas button.activa {\n  background: var(--guinda);\n  color: #fff;\n}\n.pestanas button.activa .pestana-conteo {\n  background: rgba(255, 255, 255, 0.22);\n  color: #fff;\n}\n.pestana-conteo {\n  min-width: 22px;\n  padding: 1px 7px;\n  border-radius: 999px;\n  background: #fff;\n  color: var(--texto-suave);\n  font-size: 12px;\n  text-align: center;\n}\n.estado {\n  padding: 32px 12px;\n  color: var(--texto-suave);\n  text-align: center;\n}\n.estado.vacio svg {\n  width: 40px;\n  height: 40px;\n  color: #c9c9c9;\n}\n.tabla-envoltura {\n  overflow-x: auto;\n}\n.tabla-cola {\n  width: 100%;\n  border-collapse: separate;\n  border-spacing: 0 6px;\n  font-size: 14px;\n}\n.tabla-cola th {\n  padding: 10px 12px 4px;\n  color: var(--texto-suave);\n  font-size: 12px;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n  text-align: left;\n  white-space: nowrap;\n}\n.tabla-cola td {\n  padding: 10px 12px;\n  background: #f9fafb;\n  vertical-align: middle;\n}\n.tabla-cola td:first-child {\n  border-radius: 8px 0 0 8px;\n}\n.tabla-cola td:last-child {\n  border-radius: 0 8px 8px 0;\n}\n.tabla-cola tr.mia td {\n  background: #f1f8f3;\n}\n.tabla-cola tr.ocupada td {\n  color: #8a8f98;\n}\n.tabla-cola .centro {\n  text-align: center;\n}\n.tabla-cola .derecha {\n  text-align: right;\n}\n.folio {\n  display: block;\n  font-weight: 700;\n  color: var(--negro-inst);\n  white-space: nowrap;\n}\n.etiqueta-origen {\n  display: inline-block;\n  margin-top: 2px;\n  padding: 0 6px;\n  border-radius: 4px;\n  background: #ece7f6;\n  color: #5b3d99;\n  font-size: 11px;\n  font-weight: 600;\n}\n.fecha-fila {\n  display: block;\n  white-space: nowrap;\n}\n.hace {\n  display: block;\n  color: var(--texto-suave);\n  font-size: 12px;\n}\n.quejoso {\n  min-width: 160px;\n}\n.docs {\n  display: inline-grid;\n  place-items: center;\n  width: 22px;\n  height: 22px;\n  border-radius: 50%;\n  color: #fff;\n  font-size: 12px;\n  font-weight: 800;\n}\n.docs.ok {\n  background: var(--exito);\n}\n.docs.falta {\n  background: var(--advertencia);\n}\n.chip {\n  display: inline-block;\n  padding: 3px 10px;\n  border-radius: 999px;\n  font-size: 12px;\n  font-weight: 700;\n  white-space: nowrap;\n  max-width: 190px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  vertical-align: middle;\n}\n.chip.nueva {\n  background: #fbf1e0;\n  color: #9a6512;\n}\n.chip.corregida {\n  background: #ece7f6;\n  color: #5b3d99;\n}\n.chip.contigo {\n  background: #e3f3e8;\n  color: #1d6b3a;\n}\n.chip.ocupada {\n  background: #e8eefc;\n  color: #2f55b3;\n}\n.acciones {\n  white-space: nowrap;\n}\n.btn-fila {\n  margin-left: 6px;\n  padding: 7px 14px;\n  border: 1px solid var(--guinda);\n  border-radius: 6px;\n  background: var(--guinda);\n  color: #fff;\n  font-size: 13px;\n  font-weight: 700;\n}\n.btn-fila:hover:not(:disabled) {\n  background: var(--guinda-oscuro);\n}\n.btn-fila.secundario {\n  background: #fff;\n  color: var(--guinda);\n}\n.btn-fila.secundario:hover:not(:disabled) {\n  background: var(--guinda-suave);\n}\n.btn-fila:disabled {\n  border-color: #d5d8de;\n  background: #eceef1;\n  color: #8a8f98;\n  cursor: not-allowed;\n}\n.paginado {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  flex-wrap: wrap;\n  gap: 12px;\n  margin-top: 12px;\n  padding-top: 12px;\n  border-top: 1px solid #eee;\n}\n.paginado nav {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n.paginado button {\n  min-width: 34px;\n  height: 34px;\n  padding: 0 8px;\n  border: 1px solid var(--borde);\n  border-radius: 6px;\n  background: #fff;\n  color: var(--texto);\n  font-weight: 600;\n}\n.paginado button:hover:not(:disabled) {\n  border-color: var(--guinda);\n  color: var(--guinda);\n}\n.paginado button.actual {\n  border-color: var(--guinda);\n  background: var(--guinda);\n  color: #fff;\n}\n.paginado button:disabled {\n  opacity: 0.4;\n  cursor: not-allowed;\n}\n.paginado-rango {\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.paginado-salto {\n  padding: 0 4px;\n  color: var(--texto-suave);\n}\n.filtros {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n  gap: 10px 14px;\n  margin-bottom: 8px;\n}\n.filtros .pestanas {\n  border-bottom: none;\n  padding-bottom: 0;\n  margin-bottom: 0;\n}\n.rango {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 13px;\n  color: var(--texto-suave);\n}\n.rango label {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.rango input {\n  padding: 6px 8px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font: inherit;\n}\n.limpiar {\n  border: none;\n  background: none;\n  color: var(--guinda);\n  font-weight: 600;\n  text-decoration: underline;\n}\n.recargando {\n  opacity: 0.6;\n}\n.chip.observaciones {\n  background: #fdecec;\n  color: var(--peligro);\n}\n.donde {\n  min-width: 150px;\n  font-size: 13px;\n}\n.btn-fila {\n  white-space: nowrap;\n}\n.tu {\n  font-style: normal;\n  color: var(--guinda);\n}\nbutton.btn-guinda {\n  border: none;\n}\n.detalle-linea {\n  font-size: 0.9rem;\n  margin: 0 0 8px;\n}\n/*# sourceMappingURL=historial.css.map */\n'] }]
  }], () => [{ type: HistorialService }, { type: RevisionService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Historial, { className: "Historial", filePath: "src/app/pages/historial/historial.ts", lineNumber: 26 });
})();
export {
  Historial
};
//# sourceMappingURL=chunk-OZIR4GQH.js.map
