import {
  AuthRevisionService
} from "./chunk-SEQEMDFH.js";
import {
  RevisionService
} from "./chunk-2GBWUYF6.js";
import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel
} from "./chunk-QD7SBTDO.js";
import {
  NavigationEnd,
  Router,
  RouterLink,
  RouterLinkActive,
  RouterOutlet
} from "./chunk-3TUQ6HGZ.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DatePipe,
  DestroyRef,
  HostListener,
  HttpClient,
  Injectable,
  Observable,
  ToastService,
  assertInInjectionContext,
  filter,
  inject,
  setClassMetadata,
  takeUntil,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵdomElement,
  ɵɵdomElementEnd,
  ɵɵdomElementStart,
  ɵɵdomListener,
  ɵɵdomProperty,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵresolveDocument,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-BX5W5AEF.js";

// node_modules/@angular/core/fesm2022/rxjs-interop.mjs
/**
 * @license Angular v21.2.18
 * (c) 2010-2026 Google LLC. https://angular.dev/
 * License: MIT
 */
function takeUntilDestroyed(destroyRef) {
  if (!destroyRef) {
    ngDevMode && assertInInjectionContext(takeUntilDestroyed);
    destroyRef = inject(DestroyRef);
  }
  const destroyed$ = new Observable((subscriber) => {
    if (destroyRef.destroyed) {
      subscriber.next();
      return;
    }
    const unregisterFn = destroyRef.onDestroy(subscriber.next.bind(subscriber));
    return unregisterFn;
  });
  return (source) => {
    return source.pipe(takeUntil(destroyed$));
  };
}

// src/app/core/models/revision.models.ts
function etiquetaRol(rol) {
  switch (rol) {
    case "ADMIN_SISTEMAS":
      return "Admin. de Sistemas";
    case "RECEPCIONISTA":
      return "Recepcionista";
    case "ANALISTA_PRIMER_CONTACTO":
      return "Analista de Primer Contacto";
    case "SUBDEFENSOR":
      return "Subdefensor";
    case "DEFENSOR":
      return "Defensor";
    default:
      return rol;
  }
}
function iniciales(nombreCompleto) {
  const partes = (nombreCompleto ?? "").trim().split(/\s+/).filter(Boolean);
  if (partes.length === 0)
    return "?";
  if (partes.length === 1)
    return partes[0].slice(0, 2).toUpperCase();
  return (partes[0][0] + partes[1][0]).toUpperCase();
}

// src/app/shared/campana-notificaciones/campana-notificaciones.ts
var _forTrack0 = ($index, $item) => $item.id;
function CampanaNotificaciones_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "span", 5);
    \u0275\u0275text(1);
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.noLeidas > 99 ? "99+" : ctx_r0.noLeidas);
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275domElementStart(0, "button", 11);
    \u0275\u0275domListener("click", function CampanaNotificaciones_Conditional_6_Conditional_4_Template_button_click_0_listener($event) {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.marcarTodas($event));
    });
    \u0275\u0275text(1, "Marcar todas como le\xEDdas");
    \u0275\u0275domElementEnd();
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "p", 10);
    \u0275\u0275text(1, "Cargando\u2026");
    \u0275\u0275domElementEnd();
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "p", 10);
    \u0275\u0275text(1, "No se pudieron cargar las notificaciones.");
    \u0275\u0275domElementEnd();
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "p", 10);
    \u0275\u0275text(1, "No tienes notificaciones.");
    \u0275\u0275domElementEnd();
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_8_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275domElementStart(0, "li", 13);
    \u0275\u0275domListener("click", function CampanaNotificaciones_Conditional_6_Conditional_8_For_2_Template_li_click_0_listener($event) {
      const n_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.marcarLeida(n_r4, $event));
    });
    \u0275\u0275domElementStart(1, "span", 14);
    \u0275\u0275text(2);
    \u0275\u0275domElementEnd();
    \u0275\u0275domElementStart(3, "span", 15);
    \u0275\u0275text(4);
    \u0275\u0275domElementEnd();
    \u0275\u0275domElementStart(5, "span", 16);
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "date");
    \u0275\u0275domElementEnd()();
  }
  if (rf & 2) {
    const n_r4 = ctx.$implicit;
    \u0275\u0275classProp("no-leida", !n_r4.leida);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(n_r4.titulo);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(n_r4.mensaje);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(7, 5, n_r4.fechaCreacion, "dd/MM/yyyy HH:mm"));
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "ul");
    \u0275\u0275repeaterCreate(1, CampanaNotificaciones_Conditional_6_Conditional_8_For_2_Template, 8, 8, "li", 12, _forTrack0);
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.notificaciones);
  }
}
function CampanaNotificaciones_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "div", 7);
    \u0275\u0275domListener("click", function CampanaNotificaciones_Conditional_6_Template_div_click_0_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275domElementStart(1, "div", 8)(2, "strong");
    \u0275\u0275text(3, "Notificaciones");
    \u0275\u0275domElementEnd();
    \u0275\u0275conditionalCreate(4, CampanaNotificaciones_Conditional_6_Conditional_4_Template, 2, 0, "button", 9);
    \u0275\u0275domElementEnd();
    \u0275\u0275conditionalCreate(5, CampanaNotificaciones_Conditional_6_Conditional_5_Template, 2, 0, "p", 10)(6, CampanaNotificaciones_Conditional_6_Conditional_6_Template, 2, 0, "p", 10)(7, CampanaNotificaciones_Conditional_6_Conditional_7_Template, 2, 0, "p", 10)(8, CampanaNotificaciones_Conditional_6_Conditional_8_Template, 3, 0, "ul");
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r0.noLeidas > 0 ? 4 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.cargando ? 5 : !ctx_r0.disponible ? 6 : ctx_r0.notificaciones.length === 0 ? 7 : 8);
  }
}
var CampanaNotificaciones = class _CampanaNotificaciones {
  http;
  cdr;
  apiUrl = "/api/notificaciones";
  intervaloMs = 6e4;
  temporizador = null;
  noLeidas = 0;
  abierta = false;
  cargando = false;
  disponible = true;
  notificaciones = [];
  constructor(http, cdr) {
    this.http = http;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.contar();
    this.temporizador = setInterval(() => this.contar(), this.intervaloMs);
  }
  ngOnDestroy() {
    if (this.temporizador) {
      clearInterval(this.temporizador);
    }
  }
  cerrar() {
    if (this.abierta) {
      this.abierta = false;
      this.cdr.detectChanges();
    }
  }
  alternar(evento) {
    evento.stopPropagation();
    this.abierta = !this.abierta;
    if (this.abierta) {
      this.cargarLista();
    }
    this.cdr.detectChanges();
  }
  marcarLeida(n, evento) {
    evento.stopPropagation();
    if (n.leida) {
      return;
    }
    this.http.put(`${this.apiUrl}/${n.id}/leida`, {}).subscribe({
      next: () => {
        n.leida = true;
        this.noLeidas = Math.max(0, this.noLeidas - 1);
        this.cdr.detectChanges();
      },
      error: () => {
      }
    });
  }
  marcarTodas(evento) {
    evento.stopPropagation();
    this.notificaciones.filter((n) => !n.leida).forEach((n) => this.marcarLeida(n, evento));
  }
  contar() {
    this.http.get(`${this.apiUrl}/mias/no-leidas`).subscribe({
      next: (r) => {
        this.disponible = true;
        this.noLeidas = r?.noLeidas ?? 0;
        this.cdr.detectChanges();
      },
      // Si notificaciones-service no responde, la campana simplemente no muestra conteo.
      error: () => {
        this.disponible = false;
        this.cdr.detectChanges();
      }
    });
  }
  cargarLista() {
    this.cargando = true;
    this.http.get(`${this.apiUrl}/mias`).subscribe({
      next: (lista) => {
        this.notificaciones = (lista ?? []).slice(0, 30);
        this.noLeidas = this.notificaciones.filter((n) => !n.leida).length;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.disponible = false;
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function CampanaNotificaciones_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _CampanaNotificaciones)(\u0275\u0275directiveInject(HttpClient), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _CampanaNotificaciones, selectors: [["app-campana-notificaciones"]], hostBindings: function CampanaNotificaciones_HostBindings(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275listener("click", function CampanaNotificaciones_click_HostBindingHandler() {
        return ctx.cerrar();
      }, \u0275\u0275resolveDocument);
    }
  }, decls: 7, vars: 4, consts: [[1, "campana"], ["type", "button", 1, "campana-boton", 3, "click", "title"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"], ["d", "M10.3 21a1.94 1.94 0 0 0 3.4 0"], [1, "campana-conteo"], [1, "campana-panel"], [1, "campana-panel", 3, "click"], [1, "campana-encabezado"], ["type", "button", 1, "campana-todas"], [1, "campana-vacio"], ["type", "button", 1, "campana-todas", 3, "click"], [3, "no-leida"], [3, "click"], [1, "titulo"], [1, "mensaje"], [1, "fecha"]], template: function CampanaNotificaciones_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275domElementStart(0, "div", 0)(1, "button", 1);
      \u0275\u0275domListener("click", function CampanaNotificaciones_Template_button_click_1_listener($event) {
        return ctx.alternar($event);
      });
      \u0275\u0275namespaceSVG();
      \u0275\u0275domElementStart(2, "svg", 2);
      \u0275\u0275domElement(3, "path", 3)(4, "path", 4);
      \u0275\u0275domElementEnd();
      \u0275\u0275conditionalCreate(5, CampanaNotificaciones_Conditional_5_Template, 2, 1, "span", 5);
      \u0275\u0275domElementEnd();
      \u0275\u0275conditionalCreate(6, CampanaNotificaciones_Conditional_6_Template, 9, 2, "div", 6);
      \u0275\u0275domElementEnd();
    }
    if (rf & 2) {
      \u0275\u0275advance();
      \u0275\u0275domProperty("title", ctx.disponible ? "Notificaciones" : "Notificaciones no disponibles por ahora");
      \u0275\u0275attribute("aria-label", ctx.noLeidas ? ctx.noLeidas + " notificaciones sin leer" : "Notificaciones");
      \u0275\u0275advance(4);
      \u0275\u0275conditional(ctx.noLeidas > 0 ? 5 : -1);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.abierta ? 6 : -1);
    }
  }, dependencies: [CommonModule, DatePipe], styles: ["\n.campana[_ngcontent-%COMP%] {\n  position: relative;\n}\n.campana-boton[_ngcontent-%COMP%] {\n  position: relative;\n  width: 40px;\n  height: 40px;\n  display: grid;\n  place-items: center;\n  border: none;\n  border-radius: 50%;\n  background: transparent;\n  color: var(--texto-suave, #666);\n  cursor: pointer;\n}\n.campana-boton[_ngcontent-%COMP%]:hover {\n  background: var(--guinda-suave, #f7eef1);\n  color: var(--guinda, #6c1d45);\n}\n.campana-boton[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 21px;\n  height: 21px;\n}\n.campana-conteo[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 3px;\n  right: 2px;\n  min-width: 18px;\n  height: 18px;\n  padding: 0 5px;\n  border-radius: 9px;\n  background: var(--peligro, #c62828);\n  color: #fff;\n  font-size: 0.68rem;\n  font-weight: 700;\n  line-height: 18px;\n  text-align: center;\n}\n.campana-panel[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  top: 46px;\n  z-index: 50;\n  width: min(360px, 90vw);\n  max-height: 420px;\n  overflow-y: auto;\n  border-radius: 10px;\n  background: #fff;\n  box-shadow: 0 12px 32px rgba(16, 24, 40, 0.18);\n}\n.campana-panel[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n.campana-panel[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 2px;\n  padding: 10px 14px;\n  border-top: 1px solid #eee;\n  cursor: pointer;\n}\n.campana-panel[_ngcontent-%COMP%]   li.no-leida[_ngcontent-%COMP%] {\n  background: var(--guinda-suave, #f7eef1);\n}\n.campana-encabezado[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px 14px;\n}\n.campana-todas[_ngcontent-%COMP%] {\n  border: none;\n  background: none;\n  color: var(--guinda-vivo, #9d2449);\n  font-size: 0.78rem;\n  font-weight: 600;\n  cursor: pointer;\n}\n.titulo[_ngcontent-%COMP%] {\n  font-weight: 600;\n  font-size: 0.86rem;\n}\n.mensaje[_ngcontent-%COMP%] {\n  font-size: 0.82rem;\n  color: var(--texto, #333);\n}\n.fecha[_ngcontent-%COMP%] {\n  font-size: 0.72rem;\n  color: var(--texto-suave, #666);\n}\n.campana-vacio[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 18px 14px;\n  font-size: 0.85rem;\n  color: var(--texto-suave, #666);\n}\n/*# sourceMappingURL=campana-notificaciones.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CampanaNotificaciones, [{
    type: Component,
    args: [{ selector: "app-campana-notificaciones", standalone: true, imports: [CommonModule], template: `<div class="campana">
  <button type="button" class="campana-boton" (click)="alternar($event)"
          [attr.aria-label]="noLeidas ? noLeidas + ' notificaciones sin leer' : 'Notificaciones'"
          [title]="disponible ? 'Notificaciones' : 'Notificaciones no disponibles por ahora'">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
    @if (noLeidas > 0) {
      <span class="campana-conteo">{{ noLeidas > 99 ? '99+' : noLeidas }}</span>
    }
  </button>

  @if (abierta) {
    <div class="campana-panel" (click)="$event.stopPropagation()">
      <div class="campana-encabezado">
        <strong>Notificaciones</strong>
        @if (noLeidas > 0) {
          <button type="button" class="campana-todas" (click)="marcarTodas($event)">Marcar todas como le\xEDdas</button>
        }
      </div>
      @if (cargando) {
        <p class="campana-vacio">Cargando\u2026</p>
      } @else if (!disponible) {
        <p class="campana-vacio">No se pudieron cargar las notificaciones.</p>
      } @else if (notificaciones.length === 0) {
        <p class="campana-vacio">No tienes notificaciones.</p>
      } @else {
        <ul>
          @for (n of notificaciones; track n.id) {
            <li [class.no-leida]="!n.leida" (click)="marcarLeida(n, $event)">
              <span class="titulo">{{ n.titulo }}</span>
              <span class="mensaje">{{ n.mensaje }}</span>
              <span class="fecha">{{ n.fechaCreacion | date: 'dd/MM/yyyy HH:mm' }}</span>
            </li>
          }
        </ul>
      }
    </div>
  }
</div>
`, styles: ["/* src/app/shared/campana-notificaciones/campana-notificaciones.scss */\n.campana {\n  position: relative;\n}\n.campana-boton {\n  position: relative;\n  width: 40px;\n  height: 40px;\n  display: grid;\n  place-items: center;\n  border: none;\n  border-radius: 50%;\n  background: transparent;\n  color: var(--texto-suave, #666);\n  cursor: pointer;\n}\n.campana-boton:hover {\n  background: var(--guinda-suave, #f7eef1);\n  color: var(--guinda, #6c1d45);\n}\n.campana-boton svg {\n  width: 21px;\n  height: 21px;\n}\n.campana-conteo {\n  position: absolute;\n  top: 3px;\n  right: 2px;\n  min-width: 18px;\n  height: 18px;\n  padding: 0 5px;\n  border-radius: 9px;\n  background: var(--peligro, #c62828);\n  color: #fff;\n  font-size: 0.68rem;\n  font-weight: 700;\n  line-height: 18px;\n  text-align: center;\n}\n.campana-panel {\n  position: absolute;\n  right: 0;\n  top: 46px;\n  z-index: 50;\n  width: min(360px, 90vw);\n  max-height: 420px;\n  overflow-y: auto;\n  border-radius: 10px;\n  background: #fff;\n  box-shadow: 0 12px 32px rgba(16, 24, 40, 0.18);\n}\n.campana-panel ul {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n.campana-panel li {\n  display: grid;\n  gap: 2px;\n  padding: 10px 14px;\n  border-top: 1px solid #eee;\n  cursor: pointer;\n}\n.campana-panel li.no-leida {\n  background: var(--guinda-suave, #f7eef1);\n}\n.campana-encabezado {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px 14px;\n}\n.campana-todas {\n  border: none;\n  background: none;\n  color: var(--guinda-vivo, #9d2449);\n  font-size: 0.78rem;\n  font-weight: 600;\n  cursor: pointer;\n}\n.titulo {\n  font-weight: 600;\n  font-size: 0.86rem;\n}\n.mensaje {\n  font-size: 0.82rem;\n  color: var(--texto, #333);\n}\n.fecha {\n  font-size: 0.72rem;\n  color: var(--texto-suave, #666);\n}\n.campana-vacio {\n  margin: 0;\n  padding: 18px 14px;\n  font-size: 0.85rem;\n  color: var(--texto-suave, #666);\n}\n/*# sourceMappingURL=campana-notificaciones.css.map */\n"] }]
  }], () => [{ type: HttpClient }, { type: ChangeDetectorRef }], { cerrar: [{
    type: HostListener,
    args: ["document:click"]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(CampanaNotificaciones, { className: "CampanaNotificaciones", filePath: "src/app/shared/campana-notificaciones/campana-notificaciones.ts", lineNumber: 30 });
})();

// src/app/core/services/perfil.service.ts
var PerfilService = class _PerfilService {
  http;
  apiUrl = "/api/admin/perfil";
  constructor(http) {
    this.http = http;
  }
  cambiarPassword(datos) {
    return this.http.put(`${this.apiUrl}/password`, datos);
  }
  static \u0275fac = function PerfilService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _PerfilService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _PerfilService, factory: _PerfilService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PerfilService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/recepcion-layout/recepcion-layout.ts
var _c0 = () => ({ exact: true });
function RecepcionLayout_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 30);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_23_Template_div_click_0_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(1, "button", 31);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_23_Template_button_click_1_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.abrirModalPassword());
    });
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 11);
    \u0275\u0275element(3, "circle", 32)(4, "path", 33)(5, "path", 34)(6, "path", 35);
    \u0275\u0275elementEnd();
    \u0275\u0275text(7, " Cambiar contrase\xF1a ");
    \u0275\u0275elementEnd()();
  }
}
function RecepcionLayout_Conditional_49_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 54);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_49_Conditional_5_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.cerrarModalPassword());
    });
    \u0275\u0275text(1, "\u2715");
    \u0275\u0275elementEnd();
  }
}
function RecepcionLayout_Conditional_49_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 39);
    \u0275\u0275text(1, " Tu cuenta tiene una contrase\xF1a temporal. Debes establecer una nueva antes de continuar usando el panel. ");
    \u0275\u0275elementEnd();
  }
}
function RecepcionLayout_Conditional_49_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 50);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorPassword);
  }
}
function RecepcionLayout_Conditional_49_Conditional_45_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 55);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_49_Conditional_45_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.cerrarModalPassword());
    });
    \u0275\u0275text(1, "Cancelar");
    \u0275\u0275elementEnd();
  }
}
function RecepcionLayout_Conditional_49_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 29)(1, "div", 36);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_49_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 37)(3, "h3");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(5, RecepcionLayout_Conditional_49_Conditional_5_Template, 2, 0, "button", 38);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(6, RecepcionLayout_Conditional_49_Conditional_6_Template, 2, 0, "p", 39);
    \u0275\u0275elementStart(7, "div", 40)(8, "label");
    \u0275\u0275text(9, "Contrase\xF1a actual");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "div", 41)(11, "input", 42);
    \u0275\u0275twoWayListener("ngModelChange", function RecepcionLayout_Conditional_49_Template_input_ngModelChange_11_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordActual, $event) || (ctx_r1.passwordActual = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "button", 43);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_49_Template_button_click_12_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.mostrarActual = !ctx_r1.mostrarActual);
    });
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(14, "div", 40)(15, "label");
    \u0275\u0275text(16, "Contrase\xF1a nueva");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "div", 41)(18, "input", 44);
    \u0275\u0275twoWayListener("ngModelChange", function RecepcionLayout_Conditional_49_Template_input_ngModelChange_18_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordNueva, $event) || (ctx_r1.passwordNueva = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "button", 43);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_49_Template_button_click_19_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.mostrarNueva = !ctx_r1.mostrarNueva);
    });
    \u0275\u0275text(20);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "ul", 45)(22, "li")(23, "span", 46);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(24, "svg", 47);
    \u0275\u0275element(25, "polyline", 48);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(26, " Al menos 8 caracteres ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(27, "li")(28, "span", 46);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(29, "svg", 47);
    \u0275\u0275element(30, "polyline", 48);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(31, " Una letra may\xFAscula ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(32, "li")(33, "span", 46);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(34, "svg", 47);
    \u0275\u0275element(35, "polyline", 48);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(36, " Un n\xFAmero ");
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(37, "div", 40)(38, "label");
    \u0275\u0275text(39, "Confirmar contrase\xF1a nueva");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "input", 49);
    \u0275\u0275twoWayListener("ngModelChange", function RecepcionLayout_Conditional_49_Template_input_ngModelChange_40_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordConfirmar, $event) || (ctx_r1.passwordConfirmar = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(41, RecepcionLayout_Conditional_49_Conditional_41_Template, 2, 1, "p", 50);
    \u0275\u0275elementStart(42, "div", 51)(43, "button", 52);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_49_Template_button_click_43_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.guardarPassword());
    });
    \u0275\u0275text(44);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(45, RecepcionLayout_Conditional_49_Conditional_45_Template, 2, 0, "button", 53);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.cambioObligatorio ? "Actualiza tu contrase\xF1a temporal" : "Cambiar mi contrase\xF1a");
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx_r1.cambioObligatorio ? 5 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.cambioObligatorio ? 6 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275property("type", ctx_r1.mostrarActual ? "text" : "password");
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordActual);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.mostrarActual ? "\u{1F648}" : "\u{1F441}\uFE0F");
    \u0275\u0275advance(5);
    \u0275\u0275property("type", ctx_r1.mostrarNueva ? "text" : "password");
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordNueva);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.mostrarNueva ? "\u{1F648}" : "\u{1F441}\uFE0F");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleLongitud);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleMayuscula);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleNumero);
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordConfirmar);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.errorPassword ? 41 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r1.guardandoPassword);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.guardandoPassword ? "Guardando\u2026" : "Actualizar Contrase\xF1a", " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx_r1.cambioObligatorio ? 45 : -1);
  }
}
var INTERVALO_RENOVAR_MS = 4 * 60 * 1e3;
var RUTA_CON_QUEJA = /^\/(validacion|turnado|rechazo)\/([^/?#]+)/;
var RecepcionLayout = class _RecepcionLayout {
  authService;
  perfilService;
  router;
  toast;
  cdr;
  etiquetaRol = etiquetaRol;
  anio = (/* @__PURE__ */ new Date()).getFullYear();
  revisionService = inject(RevisionService);
  destroyRef = inject(DestroyRef);
  renovarId = null;
  folioRenovando = "";
  menuAbierto = false;
  mostrarModalPassword = false;
  cambioObligatorio = false;
  passwordActual = "";
  passwordNueva = "";
  passwordConfirmar = "";
  mostrarActual = false;
  mostrarNueva = false;
  guardandoPassword = false;
  errorPassword = "";
  constructor(authService, perfilService, router, toast, cdr) {
    this.authService = authService;
    this.perfilService = perfilService;
    this.router = router;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.vigilarQuejaAbierta(this.router.url);
    this.router.events.pipe(filter((e) => e instanceof NavigationEnd), takeUntilDestroyed(this.destroyRef)).subscribe((e) => this.vigilarQuejaAbierta(e.urlAfterRedirects));
    this.destroyRef.onDestroy(() => this.detenerRenovacion());
    const usuario = this.authService.usuarioActual();
    if (usuario?.forzarCambioPassword) {
      this.cambioObligatorio = true;
      this.abrirModalPassword();
    }
  }
  get nombreUsuario() {
    return this.authService.usuarioActual()?.nombre ?? "";
  }
  get rolUsuario() {
    const rol = this.authService.usuarioActual()?.rol;
    return rol ? this.etiquetaRol(rol) : "";
  }
  get inicialesUsuario() {
    return iniciales(this.nombreUsuario);
  }
  cerrarMenuAlHacerClickFuera() {
    this.menuAbierto = false;
  }
  alternarMenu(evento) {
    evento.stopPropagation();
    this.menuAbierto = !this.menuAbierto;
  }
  abrirModalPassword() {
    this.menuAbierto = false;
    this.passwordActual = "";
    this.passwordNueva = "";
    this.passwordConfirmar = "";
    this.errorPassword = "";
    this.mostrarModalPassword = true;
  }
  cerrarModalPassword() {
    if (this.cambioObligatorio) {
      this.toast.advertencia("Debes actualizar tu contrase\xF1a temporal antes de continuar.");
      return;
    }
    this.mostrarModalPassword = false;
  }
  get cumpleLongitud() {
    return this.passwordNueva.length >= 8;
  }
  get cumpleMayuscula() {
    return /[A-Z]/.test(this.passwordNueva);
  }
  get cumpleNumero() {
    return /\d/.test(this.passwordNueva);
  }
  get cumpleCoinciden() {
    return this.passwordNueva.length > 0 && this.passwordNueva === this.passwordConfirmar;
  }
  guardarPassword() {
    this.errorPassword = "";
    if (!this.passwordActual) {
      this.errorPassword = "Ingresa tu contrase\xF1a actual.";
      return;
    }
    if (!this.cumpleLongitud || !this.cumpleMayuscula || !this.cumpleNumero) {
      this.errorPassword = "La nueva contrase\xF1a no cumple los requisitos.";
      return;
    }
    if (!this.cumpleCoinciden) {
      this.errorPassword = "La confirmaci\xF3n no coincide con la nueva contrase\xF1a.";
      return;
    }
    this.guardandoPassword = true;
    this.perfilService.cambiarPassword({
      passwordActual: this.passwordActual,
      passwordNueva: this.passwordNueva
    }).subscribe({
      next: () => {
        this.guardandoPassword = false;
        this.cambioObligatorio = false;
        this.mostrarModalPassword = false;
        this.authService.marcarPasswordActualizada();
        this.toast.exito("Contrase\xF1a actualizada correctamente.");
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.guardandoPassword = false;
        this.errorPassword = err?.error?.mensaje ?? "No se pudo actualizar la contrase\xF1a.";
        this.cdr.detectChanges();
      }
    });
  }
  cerrarSesion() {
    this.authService.logout();
    this.router.navigate(["/login"]);
  }
  /**
   * Mientras la recepcionista tenga abierta una queja (validación, rechazo o turnado), se le
   * avisa al backend cada pocos minutos que la sigue trabajando; así no se libera sola en una
   * revisión larga. Al salir de esas pantallas se deja de avisar y, si la abandona sin
   * terminar, el backend la libera a los 20 minutos.
   */
  vigilarQuejaAbierta(url) {
    const folio = RUTA_CON_QUEJA.exec(url)?.[2] ?? "";
    if (folio === this.folioRenovando) {
      return;
    }
    this.detenerRenovacion();
    if (!folio) {
      return;
    }
    this.folioRenovando = folio;
    this.renovarId = setInterval(() => {
      this.revisionService.renovar(folio).subscribe({
        error: (err) => {
          this.detenerRenovacion();
          this.toast.advertencia(err?.error?.mensaje ?? "Esta queja ya no est\xE1 a tu nombre.");
        }
      });
    }, INTERVALO_RENOVAR_MS);
  }
  detenerRenovacion() {
    if (this.renovarId !== null) {
      clearInterval(this.renovarId);
    }
    this.renovarId = null;
    this.folioRenovando = "";
  }
  static \u0275fac = function RecepcionLayout_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _RecepcionLayout)(\u0275\u0275directiveInject(AuthRevisionService), \u0275\u0275directiveInject(PerfilService), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _RecepcionLayout, selectors: [["app-recepcion-layout"]], hostBindings: function RecepcionLayout_HostBindings(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275listener("click", function RecepcionLayout_click_HostBindingHandler() {
        return ctx.cerrarMenuAlHacerClickFuera();
      }, \u0275\u0275resolveDocument);
    }
  }, decls: 50, vars: 9, consts: [[1, "app-shell"], [1, "header"], [1, "brand"], [1, "logo-mark"], [1, "user-area"], [1, "dropdown"], [1, "perfil-boton", 3, "click"], [1, "avatar"], [1, "perfil-texto"], [1, "perfil-nombre"], [1, "perfil-rol"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["points", "6 9 12 15 18 9"], [1, "dropdown-menu"], [1, "logout-btn", 3, "click"], [1, "app-body"], [1, "sidebar"], ["routerLink", "/", "routerLinkActive", "active", 3, "routerLinkActiveOptions"], ["x", "2", "y", "4", "width", "20", "height", "16", "rx", "2"], ["d", "M22 6l-10 7L2 6"], ["routerLink", "/historial", "routerLinkActive", "active"], ["d", "M3 12a9 9 0 1 0 3-6.7"], ["points", "3 4 3 9 8 9"], ["points", "12 7 12 12 16 14"], ["routerLink", "/registro-manual", "routerLinkActive", "active"], ["d", "M12 20h9"], ["d", "M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"], [1, "app-content"], [1, "footer"], [1, "modal-overlay"], [1, "dropdown-menu", 3, "click"], [3, "click"], ["cx", "7.5", "cy", "15.5", "r", "5.5"], ["d", "M21 2l-9.6 9.6"], ["d", "M15.5 7.5L18 5"], ["d", "M17 3l4 4"], [1, "modal", "card", 3, "click"], [1, "modal-header"], ["aria-label", "Cerrar", 1, "modal-cerrar"], [1, "aviso-inline"], [1, "input-group"], [1, "campo-password"], ["name", "passwordActual", 3, "ngModelChange", "type", "ngModel"], ["type", "button", 1, "alternar-password", 3, "click"], ["name", "passwordNueva", 3, "ngModelChange", "type", "ngModel"], [1, "requisitos-password"], [1, "marca"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "3", "stroke-linecap", "round", "stroke-linejoin", "round"], ["points", "20 6 9 17 4 12"], ["type", "password", "name", "passwordConfirmar", 3, "ngModelChange", "ngModel"], [1, "mensaje-campo"], [1, "modal-acciones"], [1, "btn-primary", 3, "click", "disabled"], [1, "btn-secondary"], ["aria-label", "Cerrar", 1, "modal-cerrar", 3, "click"], [1, "btn-secondary", 3, "click"]], template: function RecepcionLayout_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "header", 1)(2, "div", 2)(3, "div", 3);
      \u0275\u0275text(4, "IPN");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(5, "div")(6, "h1");
      \u0275\u0275text(7, "Defensor\xEDa de los Derechos Polit\xE9cnicos");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(8, "p");
      \u0275\u0275text(9, "M\xF3dulo de Recepci\xF3n");
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(10, "div", 4);
      \u0275\u0275element(11, "app-campana-notificaciones");
      \u0275\u0275elementStart(12, "div", 5)(13, "button", 6);
      \u0275\u0275listener("click", function RecepcionLayout_Template_button_click_13_listener($event) {
        return ctx.alternarMenu($event);
      });
      \u0275\u0275elementStart(14, "span", 7);
      \u0275\u0275text(15);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(16, "span", 8)(17, "span", 9);
      \u0275\u0275text(18);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(19, "span", 10);
      \u0275\u0275text(20);
      \u0275\u0275elementEnd()();
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(21, "svg", 11);
      \u0275\u0275element(22, "polyline", 12);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(23, RecepcionLayout_Conditional_23_Template, 8, 0, "div", 13);
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(24, "button", 14);
      \u0275\u0275listener("click", function RecepcionLayout_Template_button_click_24_listener() {
        return ctx.cerrarSesion();
      });
      \u0275\u0275text(25, "Cerrar sesi\xF3n");
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(26, "div", 15)(27, "aside", 16)(28, "nav")(29, "a", 17);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(30, "svg", 11);
      \u0275\u0275element(31, "rect", 18)(32, "path", 19);
      \u0275\u0275elementEnd();
      \u0275\u0275text(33, " Bandeja de Entrada ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(34, "a", 20);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(35, "svg", 11);
      \u0275\u0275element(36, "path", 21)(37, "polyline", 22)(38, "polyline", 23);
      \u0275\u0275elementEnd();
      \u0275\u0275text(39, " Historial ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(40, "a", 24);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(41, "svg", 11);
      \u0275\u0275element(42, "path", 25)(43, "path", 26);
      \u0275\u0275elementEnd();
      \u0275\u0275text(44, " Registro Manual ");
      \u0275\u0275elementEnd()()();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(45, "main", 27);
      \u0275\u0275element(46, "router-outlet");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(47, "footer", 28);
      \u0275\u0275text(48);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(49, RecepcionLayout_Conditional_49_Template, 46, 20, "div", 29);
    }
    if (rf & 2) {
      \u0275\u0275advance(13);
      \u0275\u0275attribute("aria-expanded", ctx.menuAbierto);
      \u0275\u0275advance(2);
      \u0275\u0275textInterpolate(ctx.inicialesUsuario);
      \u0275\u0275advance(3);
      \u0275\u0275textInterpolate(ctx.nombreUsuario);
      \u0275\u0275advance(2);
      \u0275\u0275textInterpolate(ctx.rolUsuario);
      \u0275\u0275advance(3);
      \u0275\u0275conditional(ctx.menuAbierto ? 23 : -1);
      \u0275\u0275advance(6);
      \u0275\u0275property("routerLinkActiveOptions", \u0275\u0275pureFunction0(8, _c0));
      \u0275\u0275advance(19);
      \u0275\u0275textInterpolate1("\xA9 ", ctx.anio, " - Defensor\xEDa de los Derechos Polit\xE9cnicos");
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.mostrarModalPassword ? 49 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, DefaultValueAccessor, NgControlStatus, NgModel, RouterLink, RouterLinkActive, RouterOutlet, CampanaNotificaciones], styles: ['@charset "UTF-8";\n\n\n[_nghost-%COMP%] {\n  display: block;\n  min-height: 100vh;\n}\n.app-shell[_ngcontent-%COMP%] {\n  min-height: 100vh;\n  display: flex;\n  flex-direction: column;\n  background: #f4f5f7;\n}\n.header[_ngcontent-%COMP%] {\n  position: fixed;\n  inset: 0 0 auto 0;\n  z-index: 1000;\n  height: 72px;\n  background: #fff;\n  border-bottom: 1px solid var(--borde);\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n  padding: 0 28px;\n}\n.brand[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 14px;\n  min-width: 0;\n}\n.brand[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 18px;\n  color: var(--guinda);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.brand[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 2px 0 0;\n  font-size: 13px;\n  color: var(--texto-suave);\n}\n.logo-mark[_ngcontent-%COMP%] {\n  width: 44px;\n  height: 44px;\n  flex-shrink: 0;\n  border-radius: 10px;\n  background: var(--guinda);\n  color: #fff;\n  display: grid;\n  place-items: center;\n  font-weight: 700;\n}\n.user-area[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.logout-btn[_ngcontent-%COMP%] {\n  border: none;\n  background: var(--guinda);\n  color: #fff;\n  padding: 9px 16px;\n  border-radius: 6px;\n  font-weight: 600;\n  white-space: nowrap;\n}\n.logout-btn[_ngcontent-%COMP%]:hover {\n  background: var(--guinda-oscuro);\n}\n.perfil-boton[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: none;\n  border: none;\n  padding: 5px 8px;\n  border-radius: 8px;\n}\n.perfil-boton[_ngcontent-%COMP%]:hover {\n  background: var(--gris-fondo);\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-texto[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  line-height: 1.2;\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-nombre[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: var(--texto);\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-rol[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: var(--guinda-vivo);\n  font-weight: 600;\n}\n.perfil-boton[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.app-body[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  margin-top: 72px;\n}\n.sidebar[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 72px;\n  left: 0;\n  bottom: 40px;\n  width: 250px;\n  overflow-y: auto;\n  background: #fff;\n  border-right: 1px solid var(--borde);\n  padding: 22px 14px;\n  z-index: 900;\n}\n.sidebar[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 12px 14px;\n  border-radius: 8px;\n  color: var(--texto);\n  text-decoration: none;\n  font-weight: 500;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  flex-shrink: 0;\n  opacity: 0.7;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover, \n.sidebar[_ngcontent-%COMP%]   a.active[_ngcontent-%COMP%] {\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover   svg[_ngcontent-%COMP%], \n.sidebar[_ngcontent-%COMP%]   a.active[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  opacity: 1;\n}\n.app-content[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  margin-left: 250px;\n  padding: 32px 32px 72px 40px;\n  min-height: calc(100vh - 72px);\n}\n.footer[_ngcontent-%COMP%] {\n  position: fixed;\n  inset: auto 0 0 0;\n  z-index: 1000;\n  height: 40px;\n  background: #3b0a22;\n  color: #fff;\n  display: grid;\n  place-items: center;\n  font-size: 12px;\n}\n@media (max-width: 900px) {\n  .brand[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n    font-size: 15px;\n  }\n  .perfil-texto[_ngcontent-%COMP%] {\n    display: none !important;\n  }\n  .app-body[_ngcontent-%COMP%] {\n    flex-direction: column;\n  }\n  .sidebar[_ngcontent-%COMP%] {\n    position: static;\n    width: auto;\n    padding: 10px 12px;\n    border-right: none;\n    border-bottom: 1px solid var(--borde);\n  }\n  .sidebar[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%] {\n    flex-direction: row;\n    overflow-x: auto;\n  }\n  .sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n    white-space: nowrap;\n  }\n  .app-content[_ngcontent-%COMP%] {\n    margin-left: 0;\n    padding: 20px 16px 64px;\n  }\n}\n@media (max-width: 600px) {\n  .header[_ngcontent-%COMP%] {\n    padding: 0 12px;\n  }\n  .brand[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:last-child {\n    display: none;\n  }\n}\n/*# sourceMappingURL=recepcion-layout.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RecepcionLayout, [{
    type: Component,
    args: [{ selector: "app-recepcion-layout", standalone: true, imports: [CommonModule, FormsModule, RouterLink, RouterLinkActive, RouterOutlet, CampanaNotificaciones], template: `<!-- Mismo armaz\xF3n que el m\xF3dulo de Primer Contacto (encabezado blanco con marca IPN, men\xFA
     lateral claro y pie guinda) para que los paneles del sistema se vean como uno solo. -->
<div class="app-shell">
  <header class="header">
    <div class="brand">
      <div class="logo-mark">IPN</div>
      <div>
        <h1>Defensor\xEDa de los Derechos Polit\xE9cnicos</h1>
        <p>M\xF3dulo de Recepci\xF3n</p>
      </div>
    </div>

    <div class="user-area">
      <app-campana-notificaciones></app-campana-notificaciones>

      <div class="dropdown">
        <button class="perfil-boton" (click)="alternarMenu($event)" [attr.aria-expanded]="menuAbierto">
          <span class="avatar">{{ inicialesUsuario }}</span>
          <span class="perfil-texto">
            <span class="perfil-nombre">{{ nombreUsuario }}</span>
            <span class="perfil-rol">{{ rolUsuario }}</span>
          </span>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
        </button>

        @if (menuAbierto) {
          <div class="dropdown-menu" (click)="$event.stopPropagation()">
            <button (click)="abrirModalPassword()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="5.5"></circle><path d="M21 2l-9.6 9.6"></path><path d="M15.5 7.5L18 5"></path><path d="M17 3l4 4"></path></svg>
              Cambiar contrase\xF1a
            </button>
          </div>
        }
      </div>

      <button class="logout-btn" (click)="cerrarSesion()">Cerrar sesi\xF3n</button>
    </div>
  </header>

  <div class="app-body">
    <aside class="sidebar">
      <nav>
        <a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{ exact: true }">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"></rect><path d="M22 6l-10 7L2 6"></path></svg>
          Bandeja de Entrada
        </a>
        <a routerLink="/historial" routerLinkActive="active">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"></path><polyline points="3 4 3 9 8 9"></polyline><polyline points="12 7 12 12 16 14"></polyline></svg>
          Historial
        </a>
        <a routerLink="/registro-manual" routerLinkActive="active">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"></path></svg>
          Registro Manual
        </a>
      </nav>
    </aside>

    <main class="app-content">
      <router-outlet />
    </main>
  </div>

  <footer class="footer">\xA9 {{ anio }} - Defensor\xEDa de los Derechos Polit\xE9cnicos</footer>
</div>

@if (mostrarModalPassword) {
  <div class="modal-overlay">
    <div class="modal card" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>{{ cambioObligatorio ? 'Actualiza tu contrase\xF1a temporal' : 'Cambiar mi contrase\xF1a' }}</h3>
        @if (!cambioObligatorio) {
          <button class="modal-cerrar" (click)="cerrarModalPassword()" aria-label="Cerrar">\u2715</button>
        }
      </div>

      @if (cambioObligatorio) {
        <p class="aviso-inline">
          Tu cuenta tiene una contrase\xF1a temporal. Debes establecer una nueva antes de continuar
          usando el panel.
        </p>
      }

      <div class="input-group">
        <label>Contrase\xF1a actual</label>
        <div class="campo-password">
          <input
            [type]="mostrarActual ? 'text' : 'password'"
            [(ngModel)]="passwordActual"
            name="passwordActual"
          />
          <button
            type="button"
            class="alternar-password"
            (click)="mostrarActual = !mostrarActual"
          >{{ mostrarActual ? '\u{1F648}' : '\u{1F441}\uFE0F' }}</button>
        </div>
      </div>

      <div class="input-group">
        <label>Contrase\xF1a nueva</label>
        <div class="campo-password">
          <input
            [type]="mostrarNueva ? 'text' : 'password'"
            [(ngModel)]="passwordNueva"
            name="passwordNueva"
          />
          <button
            type="button"
            class="alternar-password"
            (click)="mostrarNueva = !mostrarNueva"
          >{{ mostrarNueva ? '\u{1F648}' : '\u{1F441}\uFE0F' }}</button>
        </div>
      </div>

      <ul class="requisitos-password">
        <li [class.cumplido]="cumpleLongitud">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Al menos 8 caracteres
        </li>
        <li [class.cumplido]="cumpleMayuscula">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Una letra may\xFAscula
        </li>
        <li [class.cumplido]="cumpleNumero">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Un n\xFAmero
        </li>
      </ul>

      <div class="input-group">
        <label>Confirmar contrase\xF1a nueva</label>
        <input type="password" [(ngModel)]="passwordConfirmar" name="passwordConfirmar" />
      </div>

      @if (errorPassword) {
        <p class="mensaje-campo">{{ errorPassword }}</p>
      }

      <div class="modal-acciones">
        <button class="btn-primary" (click)="guardarPassword()" [disabled]="guardandoPassword">
          {{ guardandoPassword ? 'Guardando\u2026' : 'Actualizar Contrase\xF1a' }}
        </button>
        @if (!cambioObligatorio) {
          <button class="btn-secondary" (click)="cerrarModalPassword()">Cancelar</button>
        }
      </div>
    </div>
  </div>
}
`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/recepcion-layout/recepcion-layout.scss */\n:host {\n  display: block;\n  min-height: 100vh;\n}\n.app-shell {\n  min-height: 100vh;\n  display: flex;\n  flex-direction: column;\n  background: #f4f5f7;\n}\n.header {\n  position: fixed;\n  inset: 0 0 auto 0;\n  z-index: 1000;\n  height: 72px;\n  background: #fff;\n  border-bottom: 1px solid var(--borde);\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n  padding: 0 28px;\n}\n.brand {\n  display: flex;\n  align-items: center;\n  gap: 14px;\n  min-width: 0;\n}\n.brand h1 {\n  margin: 0;\n  font-size: 18px;\n  color: var(--guinda);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.brand p {\n  margin: 2px 0 0;\n  font-size: 13px;\n  color: var(--texto-suave);\n}\n.logo-mark {\n  width: 44px;\n  height: 44px;\n  flex-shrink: 0;\n  border-radius: 10px;\n  background: var(--guinda);\n  color: #fff;\n  display: grid;\n  place-items: center;\n  font-weight: 700;\n}\n.user-area {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.logout-btn {\n  border: none;\n  background: var(--guinda);\n  color: #fff;\n  padding: 9px 16px;\n  border-radius: 6px;\n  font-weight: 600;\n  white-space: nowrap;\n}\n.logout-btn:hover {\n  background: var(--guinda-oscuro);\n}\n.perfil-boton {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: none;\n  border: none;\n  padding: 5px 8px;\n  border-radius: 8px;\n}\n.perfil-boton:hover {\n  background: var(--gris-fondo);\n}\n.perfil-boton .perfil-texto {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  line-height: 1.2;\n}\n.perfil-boton .perfil-nombre {\n  font-size: 14px;\n  color: var(--texto);\n}\n.perfil-boton .perfil-rol {\n  font-size: 12px;\n  color: var(--guinda-vivo);\n  font-weight: 600;\n}\n.perfil-boton svg {\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.app-body {\n  flex: 1;\n  display: flex;\n  margin-top: 72px;\n}\n.sidebar {\n  position: fixed;\n  top: 72px;\n  left: 0;\n  bottom: 40px;\n  width: 250px;\n  overflow-y: auto;\n  background: #fff;\n  border-right: 1px solid var(--borde);\n  padding: 22px 14px;\n  z-index: 900;\n}\n.sidebar nav {\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n}\n.sidebar a {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 12px 14px;\n  border-radius: 8px;\n  color: var(--texto);\n  text-decoration: none;\n  font-weight: 500;\n}\n.sidebar a svg {\n  width: 18px;\n  height: 18px;\n  flex-shrink: 0;\n  opacity: 0.7;\n}\n.sidebar a:hover,\n.sidebar a.active {\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.sidebar a:hover svg,\n.sidebar a.active svg {\n  opacity: 1;\n}\n.app-content {\n  flex: 1;\n  min-width: 0;\n  margin-left: 250px;\n  padding: 32px 32px 72px 40px;\n  min-height: calc(100vh - 72px);\n}\n.footer {\n  position: fixed;\n  inset: auto 0 0 0;\n  z-index: 1000;\n  height: 40px;\n  background: #3b0a22;\n  color: #fff;\n  display: grid;\n  place-items: center;\n  font-size: 12px;\n}\n@media (max-width: 900px) {\n  .brand h1 {\n    font-size: 15px;\n  }\n  .perfil-texto {\n    display: none !important;\n  }\n  .app-body {\n    flex-direction: column;\n  }\n  .sidebar {\n    position: static;\n    width: auto;\n    padding: 10px 12px;\n    border-right: none;\n    border-bottom: 1px solid var(--borde);\n  }\n  .sidebar nav {\n    flex-direction: row;\n    overflow-x: auto;\n  }\n  .sidebar a {\n    white-space: nowrap;\n  }\n  .app-content {\n    margin-left: 0;\n    padding: 20px 16px 64px;\n  }\n}\n@media (max-width: 600px) {\n  .header {\n    padding: 0 12px;\n  }\n  .brand > div:last-child {\n    display: none;\n  }\n}\n/*# sourceMappingURL=recepcion-layout.css.map */\n'] }]
  }], () => [{ type: AuthRevisionService }, { type: PerfilService }, { type: Router }, { type: ToastService }, { type: ChangeDetectorRef }], { cerrarMenuAlHacerClickFuera: [{
    type: HostListener,
    args: ["document:click"]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(RecepcionLayout, { className: "RecepcionLayout", filePath: "src/app/pages/recepcion-layout/recepcion-layout.ts", lineNumber: 29 });
})();
export {
  RecepcionLayout
};
//# sourceMappingURL=chunk-XZMSBIAQ.js.map
