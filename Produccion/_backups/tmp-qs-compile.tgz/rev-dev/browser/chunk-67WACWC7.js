import {
  RevisionService
} from "./chunk-2GBWUYF6.js";
import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel,
  NgSelectOption,
  SelectControlValueAccessor,
  ɵNgSelectMultipleOption
} from "./chunk-QD7SBTDO.js";
import {
  ActivatedRoute,
  Router
} from "./chunk-3TUQ6HGZ.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DatePipe,
  ToastService,
  forkJoin,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstyleProp,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtextInterpolate3,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-BX5W5AEF.js";

// src/app/pages/turnado/turnado.ts
var _forTrack0 = ($index, $item) => $item.id;
var _forTrack1 = ($index, $item) => $item.numeroFolio;
function Turnado_Conditional_4_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275textInterpolate1(" | Boleta/Empleado: ", ctx_r0.queja.numeroIdentificacionQuejoso, " ");
  }
}
function Turnado_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 1);
    \u0275\u0275text(1);
    \u0275\u0275conditionalCreate(2, Turnado_Conditional_4_Conditional_2_Template, 1, 1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2(" ", ctx_r0.folio, " \xB7 C. ", ctx_r0.queja.nombreCompletoQuejoso, " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.queja.numeroIdentificacionQuejoso ? 2 : -1);
  }
}
function Turnado_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 2);
    \u0275\u0275text(1, "Cargando\u2026");
    \u0275\u0275elementEnd();
  }
}
function Turnado_Conditional_6_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 5);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.antecedentes.length);
  }
}
function Turnado_Conditional_6_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 6);
    \u0275\u0275text(1, "No se encontraron quejas previas de esta persona.");
    \u0275\u0275elementEnd();
  }
}
function Turnado_Conditional_6_Conditional_6_For_4_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "strong");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const a_r3 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(a_r3.defensorAsignado);
  }
}
function Turnado_Conditional_6_Conditional_6_For_4_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 29);
    \u0275\u0275text(1, "Sin abogado asignado");
    \u0275\u0275elementEnd();
  }
}
function Turnado_Conditional_6_Conditional_6_For_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "article", 25)(1, "div", 26)(2, "span", 27);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 28);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "dl")(7, "div")(8, "dt");
    \u0275\u0275text(9, "Fecha");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "dd");
    \u0275\u0275text(11);
    \u0275\u0275pipe(12, "date");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "div")(14, "dt");
    \u0275\u0275text(15, "Unidad");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "dd");
    \u0275\u0275text(17);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div")(19, "dt");
    \u0275\u0275text(20, "Estado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "dd");
    \u0275\u0275text(22);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(23, "div")(24, "dt");
    \u0275\u0275text(25, "Abogado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "dd");
    \u0275\u0275conditionalCreate(27, Turnado_Conditional_6_Conditional_6_For_4_Conditional_27_Template, 2, 1, "strong")(28, Turnado_Conditional_6_Conditional_6_For_4_Conditional_28_Template, 2, 0, "span", 29);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const a_r3 = ctx.$implicit;
    \u0275\u0275classProp("cerrado", !a_r3.enCurso);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(a_r3.numeroFolio);
    \u0275\u0275advance();
    \u0275\u0275classProp("denunciado", a_r3.relacion === "MISMO_DENUNCIADO");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", a_r3.relacion === "MISMO_DENUNCIADO" ? "Mismo denunciado" : "Misma persona quejosa", " ");
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(12, 10, a_r3.fecha, "dd/MM/yyyy"));
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(a_r3.unidadAcademicaClave || "\u2014");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(a_r3.estadoActual);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(a_r3.defensorAsignado ? 27 : 28);
  }
}
function Turnado_Conditional_6_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 20);
    \u0275\u0275text(1, " Otras quejas de la misma persona quejosa o contra la misma persona se\xF1alada. Revisa si hay duplicidad y qui\xE9n las atiende antes de turnar. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "div", 22);
    \u0275\u0275repeaterCreate(3, Turnado_Conditional_6_Conditional_6_For_4_Template, 29, 13, "article", 23, _forTrack1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 24);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r0.antecedentes);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" Se encontraron ", ctx_r0.antecedentes.length, " antecedente(s) relacionado(s). Verifica si existe duplicidad antes de turnar. ");
  }
}
function Turnado_Conditional_6_For_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 12);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ab_r4 = ctx.$implicit;
    \u0275\u0275property("value", ab_r4.nombre);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate3(" ", ab_r4.nombre, " \u2014 ", ab_r4.cargaActiva, " en tr\xE1mite", ab_r4.sugerido ? " \xB7 sugerido" : "", " ");
  }
}
function Turnado_Conditional_6_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 13);
    \u0275\u0275text(1, " Todav\xEDa no hay abogados (rol Subdefensor o Defensor) dados de alta en Usuarios y Roles. ");
    \u0275\u0275elementEnd();
  }
}
function Turnado_Conditional_6_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 14);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.avisoCarga);
  }
}
function Turnado_Conditional_6_For_42_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " \xB7 Titular ");
  }
}
function Turnado_Conditional_6_For_42_Conditional_12_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 38);
    \u0275\u0275text(1, "Sugerido");
    \u0275\u0275elementEnd();
  }
}
function Turnado_Conditional_6_For_42_Conditional_12_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 39);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ab_r6 = \u0275\u0275nextContext(2).$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Lleva ", ab_r6.foliosAntecedente.join(", "));
  }
}
function Turnado_Conditional_6_For_42_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 36);
    \u0275\u0275conditionalCreate(1, Turnado_Conditional_6_For_42_Conditional_12_Conditional_1_Template, 2, 0, "span", 38);
    \u0275\u0275conditionalCreate(2, Turnado_Conditional_6_For_42_Conditional_12_Conditional_2_Template, 2, 1, "span", 39);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ab_r6 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275conditional(ab_r6.sugerido ? 1 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ab_r6.foliosAntecedente.length ? 2 : -1);
  }
}
function Turnado_Conditional_6_For_42_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 37);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ab_r6 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ab_r6.motivoSugerencia);
  }
}
function Turnado_Conditional_6_For_42_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "li")(1, "button", 30);
    \u0275\u0275listener("click", function Turnado_Conditional_6_For_42_Template_button_click_1_listener() {
      const ab_r6 = \u0275\u0275restoreView(_r5).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.elegir(ab_r6));
    });
    \u0275\u0275elementStart(2, "span", 31)(3, "span", 32);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 33);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "span", 34);
    \u0275\u0275element(8, "span");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "span", 35);
    \u0275\u0275text(10);
    \u0275\u0275conditionalCreate(11, Turnado_Conditional_6_For_42_Conditional_11_Template, 1, 0);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(12, Turnado_Conditional_6_For_42_Conditional_12_Template, 3, 2, "span", 36);
    \u0275\u0275conditionalCreate(13, Turnado_Conditional_6_For_42_Conditional_13_Template, 2, 1, "span", 37);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ab_r6 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275classProp("elegido", ctx_r0.defensorAsignado === ab_r6.nombre)("sugerido", ab_r6.sugerido);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ab_r6.nombre);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ab_r6.cargaActiva);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", ctx_r0.anchoCarga(ab_r6), "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2(" ", ab_r6.cargaActiva, " en tr\xE1mite \xB7 ", ab_r6.totalAsignadas, " en total ");
    \u0275\u0275advance();
    \u0275\u0275conditional(ab_r6.rol === "DEFENSOR" ? 11 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ab_r6.sugerido || ab_r6.foliosAntecedente.length ? 12 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ab_r6.sugerido && ab_r6.motivoSugerencia ? 13 : -1);
  }
}
function Turnado_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 3)(1, "div", 4)(2, "h3");
    \u0275\u0275text(3, "Antecedentes de la queja");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(4, Turnado_Conditional_6_Conditional_4_Template, 2, 1, "span", 5);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(5, Turnado_Conditional_6_Conditional_5_Template, 2, 0, "p", 6)(6, Turnado_Conditional_6_Conditional_6_Template, 7, 1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 7)(8, "div", 3)(9, "h3");
    \u0275\u0275text(10, "Canalizaci\xF3n del Expediente");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "p", 8);
    \u0275\u0275text(12, "Esta queja se canalizar\xE1 a ");
    \u0275\u0275elementStart(13, "strong");
    \u0275\u0275text(14, "Primer Contacto");
    \u0275\u0275elementEnd();
    \u0275\u0275text(15, " para su an\xE1lisis.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "div", 9)(17, "label");
    \u0275\u0275text(18, "Defensor / Abogado Responsable:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "select", 10);
    \u0275\u0275twoWayListener("ngModelChange", function Turnado_Conditional_6_Template_select_ngModelChange_19_listener($event) {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.defensorAsignado, $event) || (ctx_r0.defensorAsignado = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementStart(20, "option", 11);
    \u0275\u0275text(21, "Seleccione un responsable");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(22, Turnado_Conditional_6_For_23_Template, 2, 4, "option", 12, _forTrack0);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(24, Turnado_Conditional_6_Conditional_24_Template, 2, 0, "span", 13);
    \u0275\u0275conditionalCreate(25, Turnado_Conditional_6_Conditional_25_Template, 2, 1, "span", 14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "div", 9)(27, "label");
    \u0275\u0275text(28, "Comentarios de Recepci\xF3n:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "textarea", 15);
    \u0275\u0275twoWayListener("ngModelChange", function Turnado_Conditional_6_Template_textarea_ngModelChange_29_listener($event) {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.comentarios, $event) || (ctx_r0.comentarios = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(30, "div", 16)(31, "button", 17);
    \u0275\u0275listener("click", function Turnado_Conditional_6_Template_button_click_31_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.turnar());
    });
    \u0275\u0275text(32);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(33, "button", 18);
    \u0275\u0275listener("click", function Turnado_Conditional_6_Template_button_click_33_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.pausar());
    });
    \u0275\u0275text(34, "Pausar / Guardar Avance");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(35, "aside", 19)(36, "h3");
    \u0275\u0275text(37, "Carga de trabajo de los abogados");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(38, "p", 20);
    \u0275\u0275text(39, " Quejas en tr\xE1mite de cada abogado, de menor a mayor. Se sugiere al de menor carga, salvo que alguien ya lleve un antecedente de esta queja: en ese caso se le sugiere a \xE9l para dar continuidad. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "ul", 21);
    \u0275\u0275repeaterCreate(41, Turnado_Conditional_6_For_42_Template, 14, 13, "li", null, _forTrack0);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r0.antecedentes.length ? 4 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.antecedentes.length === 0 ? 5 : 6);
    \u0275\u0275advance(14);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.defensorAsignado);
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r0.abogados);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r0.abogados.length === 0 ? 24 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.avisoCarga ? 25 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.comentarios);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r0.turnando);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r0.turnando ? "Turnando\u2026" : "\u2B06 Generar Folio Oficial y Turnar", " ");
    \u0275\u0275advance(9);
    \u0275\u0275repeater(ctx_r0.abogados);
  }
}
var Turnado = class _Turnado {
  route;
  router;
  revisionService;
  toast;
  cdr;
  folio = "";
  queja = null;
  antecedentes = [];
  abogados = [];
  cargando = true;
  turnando = false;
  defensorAsignado = "";
  comentarios = "";
  constructor(route, router, revisionService, toast, cdr) {
    this.route = route;
    this.router = router;
    this.revisionService = revisionService;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.folio = this.route.snapshot.paramMap.get("folio") ?? "";
    this.cargar();
  }
  cargar() {
    this.cargando = true;
    forkJoin({
      queja: this.revisionService.detalle(this.folio),
      antecedentes: this.revisionService.antecedentes(this.folio),
      abogados: this.revisionService.abogados(this.folio)
    }).subscribe({
      next: ({ queja, antecedentes, abogados }) => {
        this.queja = queja;
        this.antecedentes = antecedentes;
        this.abogados = abogados;
        this.defensorAsignado = abogados.find((a) => a.sugerido)?.nombre ?? "";
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.cargando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo cargar la informaci\xF3n de turnado.");
        this.cdr.detectChanges();
      }
    });
  }
  elegir(abogado) {
    this.defensorAsignado = abogado.nombre;
  }
  /** Ancho de la barra de carga relativo a quien más quejas en trámite lleva. */
  anchoCarga(abogado) {
    const maximo = Math.max(1, ...this.abogados.map((a) => a.cargaActiva));
    return Math.round(abogado.cargaActiva / maximo * 100);
  }
  /** Aviso cuando se elige a alguien con más carga que el sugerido (sin bloquear el turnado). */
  get avisoCarga() {
    const elegido = this.abogados.find((a) => a.nombre === this.defensorAsignado);
    const sugerido = this.abogados.find((a) => a.sugerido);
    if (!elegido || !sugerido || elegido === sugerido || elegido.cargaActiva <= sugerido.cargaActiva) {
      return "";
    }
    return `${elegido.nombre} lleva ${elegido.cargaActiva} quejas en tr\xE1mite; ${sugerido.nombre} lleva ${sugerido.cargaActiva}. Confirma que hay una raz\xF3n para asign\xE1rsela.`;
  }
  pausar() {
    this.toast.info('Avance guardado. La queja sigue "En Proceso".');
    this.router.navigate(["/"]);
  }
  turnar() {
    if (!this.defensorAsignado) {
      this.toast.advertencia("Selecciona el defensor responsable.");
      return;
    }
    this.turnando = true;
    this.revisionService.turnar(this.folio, {
      defensorAsignado: this.defensorAsignado,
      comentarios: this.comentarios
    }).subscribe({
      next: () => {
        this.turnando = false;
        this.toast.exito("Queja turnada correctamente.");
        this.router.navigate(["/"]);
      },
      error: (err) => {
        this.turnando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo turnar la queja.");
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function Turnado_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Turnado)(\u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(RevisionService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Turnado, selectors: [["app-turnado"]], decls: 7, vars: 2, consts: [[1, "page-header"], [1, "page-header-subtitulo"], [1, "cargando"], [1, "card"], [1, "titulo-con-conteo"], [1, "conteo"], [1, "sin-antecedentes"], [1, "rejilla-turnado"], [1, "aviso-inline"], [1, "input-group"], ["name", "defensorAsignado", 3, "ngModelChange", "ngModel"], ["value", "", "disabled", ""], [3, "value"], [1, "mensaje-campo", "aviso-sin-datos"], [1, "aviso-carga"], ["rows", "4", "name", "comentarios", "placeholder", "Escriba aqu\xED una nota breve para el abogado\u2026", 3, "ngModelChange", "ngModel"], [1, "modal-acciones", "acciones-turnado"], [1, "btn-primary", 3, "click", "disabled"], [1, "btn-secondary", 3, "click"], [1, "card", "carga"], [1, "explicacion"], [1, "carga-lista"], [1, "antecedentes"], [1, "antecedente", 3, "cerrado"], [1, "aviso-peligro"], [1, "antecedente"], [1, "antecedente-cabeza"], [1, "antecedente-folio"], [1, "chip-relacion"], [1, "sin-dato"], ["type", "button", 1, "carga-fila", 3, "click"], [1, "carga-cabeza"], [1, "carga-nombre"], [1, "carga-numero"], [1, "carga-barra"], [1, "carga-pie"], [1, "carga-etiquetas"], [1, "carga-motivo"], [1, "etiqueta", "sugerido"], [1, "etiqueta", "antecedente"]], template: function Turnado_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "div")(2, "h2");
      \u0275\u0275text(3, "B\xFAsqueda de Antecedentes y Turnado");
      \u0275\u0275elementEnd();
      \u0275\u0275conditionalCreate(4, Turnado_Conditional_4_Template, 3, 3, "p", 1);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(5, Turnado_Conditional_5_Template, 2, 0, "p", 2)(6, Turnado_Conditional_6_Template, 43, 8);
    }
    if (rf & 2) {
      \u0275\u0275advance(4);
      \u0275\u0275conditional(ctx.queja ? 4 : -1);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.cargando ? 5 : ctx.queja ? 6 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, NgSelectOption, \u0275NgSelectMultipleOption, DefaultValueAccessor, SelectControlValueAccessor, NgControlStatus, NgModel, DatePipe], styles: ['@charset "UTF-8";\n\n\n.cargando[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.sin-antecedentes[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 0.88rem;\n}\n.explicacion[_ngcontent-%COMP%] {\n  margin: 0 0 12px;\n  color: var(--texto-suave);\n  font-size: 0.84rem;\n}\n.titulo-con-conteo[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.titulo-con-conteo[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin-bottom: 8px;\n}\n.conteo[_ngcontent-%COMP%] {\n  min-width: 26px;\n  margin-bottom: 8px;\n  padding: 2px 8px;\n  border-radius: 999px;\n  background: var(--guinda);\n  color: #fff;\n  font-size: 0.78rem;\n  font-weight: 700;\n  text-align: center;\n}\n.antecedentes[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));\n  gap: 12px;\n  margin-bottom: 12px;\n}\n.antecedente[_ngcontent-%COMP%] {\n  padding: 12px 14px;\n  border: 1px solid #ece7ea;\n  border-left: 4px solid var(--guinda);\n  border-radius: 10px;\n  background: #fbf9fa;\n}\n.antecedente.cerrado[_ngcontent-%COMP%] {\n  border-left-color: #b9bdc5;\n  background: #f7f8fa;\n}\n.antecedente[_ngcontent-%COMP%]   dl[_ngcontent-%COMP%] {\n  margin: 8px 0 0;\n  display: grid;\n  gap: 4px;\n}\n.antecedente[_ngcontent-%COMP%]   dl[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 70px 1fr;\n  gap: 8px;\n  font-size: 0.84rem;\n}\n.antecedente[_ngcontent-%COMP%]   dt[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.antecedente[_ngcontent-%COMP%]   dd[_ngcontent-%COMP%] {\n  margin: 0;\n}\n.antecedente-cabeza[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 8px;\n}\n.antecedente-folio[_ngcontent-%COMP%] {\n  font-weight: 800;\n  color: var(--negro-inst);\n}\n.chip-relacion[_ngcontent-%COMP%] {\n  padding: 2px 8px;\n  border-radius: 999px;\n  background: #e8eefc;\n  color: #2f55b3;\n  font-size: 0.72rem;\n  font-weight: 700;\n  white-space: nowrap;\n}\n.chip-relacion.denunciado[_ngcontent-%COMP%] {\n  background: #ece7f6;\n  color: #5b3d99;\n}\n.sin-dato[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-style: italic;\n}\n.rejilla-turnado[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) 360px;\n  gap: 20px;\n  margin-top: 20px;\n  align-items: start;\n}\n@media (max-width: 1150px) {\n  .rejilla-turnado[_ngcontent-%COMP%] {\n    grid-template-columns: minmax(0, 1fr);\n  }\n}\n.aviso-sin-datos[_ngcontent-%COMP%] {\n  color: var(--advertencia);\n}\n.aviso-carga[_ngcontent-%COMP%] {\n  display: block;\n  margin-top: 6px;\n  padding: 8px 10px;\n  border-radius: 8px;\n  background: #fff8eb;\n  color: #8a5a00;\n  font-size: 0.8rem;\n}\n.acciones-turnado[_ngcontent-%COMP%] {\n  margin-top: 4px;\n}\n.carga-lista[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 8px;\n}\n.carga-fila[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n  padding: 10px 12px;\n  border: 1.5px solid #eceef1;\n  border-radius: 10px;\n  background: #f9fafb;\n  text-align: left;\n  font: inherit;\n  color: inherit;\n  cursor: pointer;\n}\n.carga-fila[_ngcontent-%COMP%]:hover {\n  border-color: #d9b8c7;\n}\n.carga-fila.sugerido[_ngcontent-%COMP%] {\n  border-color: #b9dcc4;\n  background: #f3faf5;\n}\n.carga-fila.elegido[_ngcontent-%COMP%] {\n  border-color: var(--guinda);\n  background: var(--guinda-suave);\n}\n.carga-cabeza[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: baseline;\n  gap: 8px;\n}\n.carga-nombre[_ngcontent-%COMP%] {\n  font-weight: 700;\n  font-size: 0.88rem;\n}\n.carga-numero[_ngcontent-%COMP%] {\n  color: var(--guinda);\n  font-size: 1.2rem;\n  font-weight: 900;\n}\n.carga-barra[_ngcontent-%COMP%] {\n  height: 6px;\n  border-radius: 999px;\n  background: #e6e8ec;\n  overflow: hidden;\n}\n.carga-barra[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  display: block;\n  height: 100%;\n  border-radius: inherit;\n  background: var(--guinda);\n}\n.carga-pie[_ngcontent-%COMP%], \n.carga-motivo[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 0.76rem;\n}\n.carga-motivo[_ngcontent-%COMP%] {\n  color: #1d6b3a;\n}\n.carga-etiquetas[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n}\n.etiqueta[_ngcontent-%COMP%] {\n  padding: 2px 8px;\n  border-radius: 999px;\n  font-size: 0.72rem;\n  font-weight: 700;\n}\n.etiqueta.sugerido[_ngcontent-%COMP%] {\n  background: #e3f3e8;\n  color: #1d6b3a;\n}\n.etiqueta.antecedente[_ngcontent-%COMP%] {\n  background: #ece7f6;\n  color: #5b3d99;\n}\n/*# sourceMappingURL=turnado.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Turnado, [{
    type: Component,
    args: [{ selector: "app-turnado", standalone: true, imports: [CommonModule, FormsModule], template: `<div class="page-header">
  <div>
    <h2>B\xFAsqueda de Antecedentes y Turnado</h2>
    @if (queja) {
      <p class="page-header-subtitulo">
        {{ folio }} \xB7 C. {{ queja.nombreCompletoQuejoso }}
        @if (queja.numeroIdentificacionQuejoso) { | Boleta/Empleado: {{ queja.numeroIdentificacionQuejoso }} }
      </p>
    }
  </div>
</div>

@if (cargando) {
  <p class="cargando">Cargando\u2026</p>
} @else if (queja) {
  <!-- ================= Antecedentes ================= -->
  <div class="card">
    <div class="titulo-con-conteo">
      <h3>Antecedentes de la queja</h3>
      @if (antecedentes.length) { <span class="conteo">{{ antecedentes.length }}</span> }
    </div>

    @if (antecedentes.length === 0) {
      <p class="sin-antecedentes">No se encontraron quejas previas de esta persona.</p>
    } @else {
      <p class="explicacion">
        Otras quejas de la misma persona quejosa o contra la misma persona se\xF1alada. Revisa si hay duplicidad y
        qui\xE9n las atiende antes de turnar.
      </p>
      <div class="antecedentes">
        @for (a of antecedentes; track a.numeroFolio) {
          <article class="antecedente" [class.cerrado]="!a.enCurso">
            <div class="antecedente-cabeza">
              <span class="antecedente-folio">{{ a.numeroFolio }}</span>
              <span class="chip-relacion" [class.denunciado]="a.relacion === 'MISMO_DENUNCIADO'">
                {{ a.relacion === 'MISMO_DENUNCIADO' ? 'Mismo denunciado' : 'Misma persona quejosa' }}
              </span>
            </div>
            <dl>
              <div><dt>Fecha</dt><dd>{{ a.fecha | date: 'dd/MM/yyyy' }}</dd></div>
              <div><dt>Unidad</dt><dd>{{ a.unidadAcademicaClave || '\u2014' }}</dd></div>
              <div><dt>Estado</dt><dd>{{ a.estadoActual }}</dd></div>
              <div>
                <dt>Abogado</dt>
                <dd>
                  @if (a.defensorAsignado) { <strong>{{ a.defensorAsignado }}</strong> }
                  @else { <span class="sin-dato">Sin abogado asignado</span> }
                </dd>
              </div>
            </dl>
          </article>
        }
      </div>
      <p class="aviso-peligro">
        Se encontraron {{ antecedentes.length }} antecedente(s) relacionado(s). Verifica si existe duplicidad antes de turnar.
      </p>
    }
  </div>

  <div class="rejilla-turnado">
    <!-- ================= Canalizaci\xF3n ================= -->
    <div class="card">
      <h3>Canalizaci\xF3n del Expediente</h3>

      <p class="aviso-inline">Esta queja se canalizar\xE1 a <strong>Primer Contacto</strong> para su an\xE1lisis.</p>

      <div class="input-group">
        <label>Defensor / Abogado Responsable:</label>
        <select [(ngModel)]="defensorAsignado" name="defensorAsignado">
          <option value="" disabled>Seleccione un responsable</option>
          @for (ab of abogados; track ab.id) {
            <option [value]="ab.nombre">
              {{ ab.nombre }} \u2014 {{ ab.cargaActiva }} en tr\xE1mite{{ ab.sugerido ? ' \xB7 sugerido' : '' }}
            </option>
          }
        </select>
        @if (abogados.length === 0) {
          <span class="mensaje-campo aviso-sin-datos">
            Todav\xEDa no hay abogados (rol Subdefensor o Defensor) dados de alta en Usuarios y Roles.
          </span>
        }
        @if (avisoCarga) {
          <span class="aviso-carga">{{ avisoCarga }}</span>
        }
      </div>

      <div class="input-group">
        <label>Comentarios de Recepci\xF3n:</label>
        <textarea rows="4" [(ngModel)]="comentarios" name="comentarios" placeholder="Escriba aqu\xED una nota breve para el abogado\u2026"></textarea>
      </div>

      <div class="modal-acciones acciones-turnado">
        <button class="btn-primary" (click)="turnar()" [disabled]="turnando">
          {{ turnando ? 'Turnando\u2026' : '\u2B06 Generar Folio Oficial y Turnar' }}
        </button>
        <button class="btn-secondary" (click)="pausar()">Pausar / Guardar Avance</button>
      </div>
    </div>

    <!-- ================= Carga de los abogados ================= -->
    <aside class="card carga">
      <h3>Carga de trabajo de los abogados</h3>
      <p class="explicacion">
        Quejas en tr\xE1mite de cada abogado, de menor a mayor. Se sugiere al de menor carga, salvo que alguien ya
        lleve un antecedente de esta queja: en ese caso se le sugiere a \xE9l para dar continuidad.
      </p>
      <ul class="carga-lista">
        @for (ab of abogados; track ab.id) {
          <li>
            <button type="button" class="carga-fila" [class.elegido]="defensorAsignado === ab.nombre"
                    [class.sugerido]="ab.sugerido" (click)="elegir(ab)">
              <span class="carga-cabeza">
                <span class="carga-nombre">{{ ab.nombre }}</span>
                <span class="carga-numero">{{ ab.cargaActiva }}</span>
              </span>
              <span class="carga-barra"><span [style.width.%]="anchoCarga(ab)"></span></span>
              <span class="carga-pie">
                {{ ab.cargaActiva }} en tr\xE1mite \xB7 {{ ab.totalAsignadas }} en total
                @if (ab.rol === 'DEFENSOR') { \xB7 Titular }
              </span>
              @if (ab.sugerido || ab.foliosAntecedente.length) {
                <span class="carga-etiquetas">
                  @if (ab.sugerido) { <span class="etiqueta sugerido">Sugerido</span> }
                  @if (ab.foliosAntecedente.length) {
                    <span class="etiqueta antecedente">Lleva {{ ab.foliosAntecedente.join(', ') }}</span>
                  }
                </span>
              }
              @if (ab.sugerido && ab.motivoSugerencia) {
                <span class="carga-motivo">{{ ab.motivoSugerencia }}</span>
              }
            </button>
          </li>
        }
      </ul>
    </aside>
  </div>
}
`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/turnado/turnado.scss */\n.cargando {\n  color: var(--texto-suave);\n}\n.sin-antecedentes {\n  color: var(--texto-suave);\n  font-size: 0.88rem;\n}\n.explicacion {\n  margin: 0 0 12px;\n  color: var(--texto-suave);\n  font-size: 0.84rem;\n}\n.titulo-con-conteo {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.titulo-con-conteo h3 {\n  margin-bottom: 8px;\n}\n.conteo {\n  min-width: 26px;\n  margin-bottom: 8px;\n  padding: 2px 8px;\n  border-radius: 999px;\n  background: var(--guinda);\n  color: #fff;\n  font-size: 0.78rem;\n  font-weight: 700;\n  text-align: center;\n}\n.antecedentes {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));\n  gap: 12px;\n  margin-bottom: 12px;\n}\n.antecedente {\n  padding: 12px 14px;\n  border: 1px solid #ece7ea;\n  border-left: 4px solid var(--guinda);\n  border-radius: 10px;\n  background: #fbf9fa;\n}\n.antecedente.cerrado {\n  border-left-color: #b9bdc5;\n  background: #f7f8fa;\n}\n.antecedente dl {\n  margin: 8px 0 0;\n  display: grid;\n  gap: 4px;\n}\n.antecedente dl div {\n  display: grid;\n  grid-template-columns: 70px 1fr;\n  gap: 8px;\n  font-size: 0.84rem;\n}\n.antecedente dt {\n  color: var(--texto-suave);\n}\n.antecedente dd {\n  margin: 0;\n}\n.antecedente-cabeza {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 8px;\n}\n.antecedente-folio {\n  font-weight: 800;\n  color: var(--negro-inst);\n}\n.chip-relacion {\n  padding: 2px 8px;\n  border-radius: 999px;\n  background: #e8eefc;\n  color: #2f55b3;\n  font-size: 0.72rem;\n  font-weight: 700;\n  white-space: nowrap;\n}\n.chip-relacion.denunciado {\n  background: #ece7f6;\n  color: #5b3d99;\n}\n.sin-dato {\n  color: var(--texto-suave);\n  font-style: italic;\n}\n.rejilla-turnado {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) 360px;\n  gap: 20px;\n  margin-top: 20px;\n  align-items: start;\n}\n@media (max-width: 1150px) {\n  .rejilla-turnado {\n    grid-template-columns: minmax(0, 1fr);\n  }\n}\n.aviso-sin-datos {\n  color: var(--advertencia);\n}\n.aviso-carga {\n  display: block;\n  margin-top: 6px;\n  padding: 8px 10px;\n  border-radius: 8px;\n  background: #fff8eb;\n  color: #8a5a00;\n  font-size: 0.8rem;\n}\n.acciones-turnado {\n  margin-top: 4px;\n}\n.carga-lista {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 8px;\n}\n.carga-fila {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n  padding: 10px 12px;\n  border: 1.5px solid #eceef1;\n  border-radius: 10px;\n  background: #f9fafb;\n  text-align: left;\n  font: inherit;\n  color: inherit;\n  cursor: pointer;\n}\n.carga-fila:hover {\n  border-color: #d9b8c7;\n}\n.carga-fila.sugerido {\n  border-color: #b9dcc4;\n  background: #f3faf5;\n}\n.carga-fila.elegido {\n  border-color: var(--guinda);\n  background: var(--guinda-suave);\n}\n.carga-cabeza {\n  display: flex;\n  justify-content: space-between;\n  align-items: baseline;\n  gap: 8px;\n}\n.carga-nombre {\n  font-weight: 700;\n  font-size: 0.88rem;\n}\n.carga-numero {\n  color: var(--guinda);\n  font-size: 1.2rem;\n  font-weight: 900;\n}\n.carga-barra {\n  height: 6px;\n  border-radius: 999px;\n  background: #e6e8ec;\n  overflow: hidden;\n}\n.carga-barra span {\n  display: block;\n  height: 100%;\n  border-radius: inherit;\n  background: var(--guinda);\n}\n.carga-pie,\n.carga-motivo {\n  color: var(--texto-suave);\n  font-size: 0.76rem;\n}\n.carga-motivo {\n  color: #1d6b3a;\n}\n.carga-etiquetas {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n}\n.etiqueta {\n  padding: 2px 8px;\n  border-radius: 999px;\n  font-size: 0.72rem;\n  font-weight: 700;\n}\n.etiqueta.sugerido {\n  background: #e3f3e8;\n  color: #1d6b3a;\n}\n.etiqueta.antecedente {\n  background: #ece7f6;\n  color: #5b3d99;\n}\n/*# sourceMappingURL=turnado.css.map */\n'] }]
  }], () => [{ type: ActivatedRoute }, { type: Router }, { type: RevisionService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Turnado, { className: "Turnado", filePath: "src/app/pages/turnado/turnado.ts", lineNumber: 18 });
})();
export {
  Turnado
};
//# sourceMappingURL=chunk-67WACWC7.js.map
