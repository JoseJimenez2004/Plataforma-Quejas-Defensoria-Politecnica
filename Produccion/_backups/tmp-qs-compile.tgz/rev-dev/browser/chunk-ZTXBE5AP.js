import {
  RevisionService
} from "./chunk-2GBWUYF6.js";
import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel
} from "./chunk-QD7SBTDO.js";
import {
  Router,
  RouterLink
} from "./chunk-3TUQ6HGZ.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DatePipe,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIndex,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstyleProp,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-BX5W5AEF.js";

// src/app/pages/bandeja/bandeja.ts
var _forTrack0 = ($index, $item) => $item.valor;
var _forTrack1 = ($index, $item) => $item.nombre;
var _forTrack2 = ($index, $item) => $item.numeroFolio;
function Bandeja_Conditional_11_Conditional_76_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 46);
    \u0275\u0275listener("click", function Bandeja_Conditional_11_Conditional_76_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.limpiarBusqueda());
    });
    \u0275\u0275text(1, "\xD7");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_11_For_79_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 47);
    \u0275\u0275listener("click", function Bandeja_Conditional_11_For_79_Template_button_click_0_listener() {
      const op_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.cambiarFiltro(op_r5.valor));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementStart(2, "span", 48);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const op_r5 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("activa", ctx_r1.filtro === op_r5.valor);
    \u0275\u0275property("title", op_r5.ayuda);
    \u0275\u0275attribute("aria-selected", ctx_r1.filtro === op_r5.valor);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", op_r5.etiqueta, " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.conteoFiltro(op_r5.valor));
  }
}
function Bandeja_Conditional_11_Conditional_80_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 6);
    \u0275\u0275text(1, "Cargando\u2026");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_11_Conditional_81_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275textInterpolate1(' No hay quejas que coincidan con "', ctx_r1.busqueda, '". ');
  }
}
function Bandeja_Conditional_11_Conditional_81_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, ' No tienes quejas abiertas. Toma una de "Disponibles". ');
  }
}
function Bandeja_Conditional_11_Conditional_81_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " No hay quejas en esta vista. ");
  }
}
function Bandeja_Conditional_11_Conditional_81_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 39);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(1, "svg", 49);
    \u0275\u0275element(2, "rect", 10)(3, "polyline", 50);
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(4, "p");
    \u0275\u0275conditionalCreate(5, Bandeja_Conditional_11_Conditional_81_Conditional_5_Template, 1, 1)(6, Bandeja_Conditional_11_Conditional_81_Conditional_6_Template, 1, 0)(7, Bandeja_Conditional_11_Conditional_81_Conditional_7_Template, 1, 0);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ctx_r1.busqueda ? 5 : ctx_r1.filtro === "mias" ? 6 : 7);
  }
}
function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 58);
    \u0275\u0275text(1, "Ventanilla");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 62);
    \u0275\u0275text(1, "\u2713");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 63);
    \u0275\u0275text(1, "!");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_19_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 69);
    \u0275\u0275text(1, "Contigo");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_19_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 70);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r6 = \u0275\u0275nextContext(2).$implicit;
    \u0275\u0275property("title", "La est\xE1 atendiendo " + item_r6.revisandoPorNombre);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Con ", item_r6.revisandoPorNombre);
  }
}
function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, Bandeja_Conditional_11_Conditional_82_For_20_Conditional_19_Conditional_0_Template, 2, 0, "span", 69)(1, Bandeja_Conditional_11_Conditional_82_For_20_Conditional_19_Conditional_1_Template, 2, 2, "span", 70);
  }
  if (rf & 2) {
    const item_r6 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275conditional(item_r6.esMia ? 0 : 1);
  }
}
function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 64);
    \u0275\u0275text(1, " Corregida ");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r6 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275property("title", item_r6.rechazadaAntesPor ? "La regres\xF3 con observaciones " + item_r6.rechazadaAntesPor : "El quejoso atendi\xF3 las observaciones");
  }
}
function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 65);
    \u0275\u0275text(1, "Nueva");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "button", 67);
    \u0275\u0275text(1, " Ocupada ");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r6 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275property("title", "La atiende " + item_r6.revisandoPorNombre + ". Se libera sola si la deja 20 min sin actividad.");
  }
}
function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 71);
    \u0275\u0275listener("click", function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_24_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r7);
      const item_r6 = \u0275\u0275nextContext().$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.soltar(item_r6));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "button", 72);
    \u0275\u0275listener("click", function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_24_Template_button_click_2_listener() {
      \u0275\u0275restoreView(_r7);
      const item_r6 = \u0275\u0275nextContext().$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.atender(item_r6));
    });
    \u0275\u0275text(3, "Continuar");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r6 = \u0275\u0275nextContext().$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275property("disabled", ctx_r1.soltando === item_r6.numeroFolio);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.soltando === item_r6.numeroFolio ? "\u2026" : "Soltar", " ");
  }
}
function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 72);
    \u0275\u0275listener("click", function Bandeja_Conditional_11_Conditional_82_For_20_Conditional_25_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r8);
      const item_r6 = \u0275\u0275nextContext().$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.atender(item_r6));
    });
    \u0275\u0275text(1, "Atender");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_11_Conditional_82_For_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td")(2, "span", 57);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(4, Bandeja_Conditional_11_Conditional_82_For_20_Conditional_4_Template, 2, 0, "span", 58);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "td")(6, "span", 59);
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "date");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "span", 60);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "td", 61);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "td");
    \u0275\u0275text(14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "td", 53);
    \u0275\u0275conditionalCreate(16, Bandeja_Conditional_11_Conditional_82_For_20_Conditional_16_Template, 2, 0, "span", 62)(17, Bandeja_Conditional_11_Conditional_82_For_20_Conditional_17_Template, 2, 0, "span", 63);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "td");
    \u0275\u0275conditionalCreate(19, Bandeja_Conditional_11_Conditional_82_For_20_Conditional_19_Template, 2, 1)(20, Bandeja_Conditional_11_Conditional_82_For_20_Conditional_20_Template, 2, 1, "span", 64)(21, Bandeja_Conditional_11_Conditional_82_For_20_Conditional_21_Template, 2, 0, "span", 65);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "td", 66);
    \u0275\u0275conditionalCreate(23, Bandeja_Conditional_11_Conditional_82_For_20_Conditional_23_Template, 2, 1, "button", 67)(24, Bandeja_Conditional_11_Conditional_82_For_20_Conditional_24_Template, 4, 2)(25, Bandeja_Conditional_11_Conditional_82_For_20_Conditional_25_Template, 2, 0, "button", 68);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const item_r6 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("ocupada", ctx_r1.bloqueadaPorOtro(item_r6))("mia", item_r6.esMia);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(item_r6.numeroFolio);
    \u0275\u0275advance();
    \u0275\u0275conditional(item_r6.origen === "MANUAL" ? 4 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(8, 13, item_r6.fechaCreacion, "dd/MM/yy HH:mm"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r1.hace(item_r6.fechaCreacion));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r6.nombreQuejoso);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r6.unidadAcademicaClave || "\u2014");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(item_r6.documentacionAparenteCompleta ? 16 : 17);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(item_r6.estatus === "EN_VALIDACION" ? 19 : item_r6.estatus === "CORREGIDA" ? 20 : 21);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r1.bloqueadaPorOtro(item_r6) ? 23 : item_r6.esMia ? 24 : 25);
  }
}
function Bandeja_Conditional_11_Conditional_82_Conditional_21_Conditional_3_For_4_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 77);
    \u0275\u0275text(1, "\u2026");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_11_Conditional_82_Conditional_21_Conditional_3_For_4_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 79);
    \u0275\u0275listener("click", function Bandeja_Conditional_11_Conditional_82_Conditional_21_Conditional_3_For_4_Conditional_1_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r10);
      const p_r11 = \u0275\u0275nextContext().$implicit;
      const ctx_r1 = \u0275\u0275nextContext(5);
      return \u0275\u0275resetView(ctx_r1.irAPagina(p_r11));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r11 = \u0275\u0275nextContext().$implicit;
    const ctx_r1 = \u0275\u0275nextContext(5);
    \u0275\u0275classProp("actual", p_r11 === ctx_r1.pagina);
    \u0275\u0275attribute("aria-current", p_r11 === ctx_r1.pagina ? "page" : null);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(p_r11 + 1);
  }
}
function Bandeja_Conditional_11_Conditional_82_Conditional_21_Conditional_3_For_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, Bandeja_Conditional_11_Conditional_82_Conditional_21_Conditional_3_For_4_Conditional_0_Template, 2, 0, "span", 77)(1, Bandeja_Conditional_11_Conditional_82_Conditional_21_Conditional_3_For_4_Conditional_1_Template, 2, 4, "button", 78);
  }
  if (rf & 2) {
    const p_r11 = ctx.$implicit;
    \u0275\u0275conditional(p_r11 === null ? 0 : 1);
  }
}
function Bandeja_Conditional_11_Conditional_82_Conditional_21_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "nav", 74)(1, "button", 75);
    \u0275\u0275listener("click", function Bandeja_Conditional_11_Conditional_82_Conditional_21_Conditional_3_Template_button_click_1_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r1.irAPagina(ctx_r1.pagina - 1));
    });
    \u0275\u0275text(2, "\u2039");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(3, Bandeja_Conditional_11_Conditional_82_Conditional_21_Conditional_3_For_4_Template, 2, 1, null, null, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275elementStart(5, "button", 76);
    \u0275\u0275listener("click", function Bandeja_Conditional_11_Conditional_82_Conditional_21_Conditional_3_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r1.irAPagina(ctx_r1.pagina + 1));
    });
    \u0275\u0275text(6, "\u203A");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const r_r12 = \u0275\u0275nextContext(3);
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r1.pagina === 0);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.paginasVisibles);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r1.pagina >= r_r12.totalPaginas - 1);
  }
}
function Bandeja_Conditional_11_Conditional_82_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 56)(1, "span", 73);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(3, Bandeja_Conditional_11_Conditional_82_Conditional_21_Conditional_3_Template, 7, 2, "nav", 74);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const r_r12 = \u0275\u0275nextContext(2);
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.rangoMostrado);
    \u0275\u0275advance();
    \u0275\u0275conditional(r_r12.totalPaginas > 1 ? 3 : -1);
  }
}
function Bandeja_Conditional_11_Conditional_82_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 51)(1, "table", 52)(2, "thead")(3, "tr")(4, "th");
    \u0275\u0275text(5, "Folio");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "th");
    \u0275\u0275text(7, "Lleg\xF3");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "th");
    \u0275\u0275text(9, "Quejoso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "th");
    \u0275\u0275text(11, "Unidad");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "th", 53);
    \u0275\u0275text(13, "Docs.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "th");
    \u0275\u0275text(15, "Estado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "th", 54);
    \u0275\u0275text(17, "Acci\xF3n");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(18, "tbody");
    \u0275\u0275repeaterCreate(19, Bandeja_Conditional_11_Conditional_82_For_20_Template, 26, 16, "tr", 55, _forTrack2);
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(21, Bandeja_Conditional_11_Conditional_82_Conditional_21_Template, 4, 2, "div", 56);
  }
  if (rf & 2) {
    const r_r12 = \u0275\u0275nextContext();
    \u0275\u0275advance(19);
    \u0275\u0275repeater(r_r12.lista);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(r_r12.totalPaginas > 1 || r_r12.totalElementos > 0 ? 21 : -1);
  }
}
function Bandeja_Conditional_11_For_90_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "em");
    \u0275\u0275text(1, "(t\xFA)");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_11_For_90_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li")(1, "div", 80)(2, "span", 81);
    \u0275\u0275text(3);
    \u0275\u0275conditionalCreate(4, Bandeja_Conditional_11_For_90_Conditional_4_Template, 2, 0, "em");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 82);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 83);
    \u0275\u0275element(8, "span");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "span", 84);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const p_r13 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("yo", p_r13.soyYo);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("", p_r13.nombre, " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(p_r13.soyYo ? 4 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("activa", p_r13.enAtencion > 0);
    \u0275\u0275property("title", p_r13.enAtencion + " queja(s) abiertas ahora");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("", p_r13.enAtencion, " abiertas");
    \u0275\u0275advance();
    \u0275\u0275property("title", p_r13.atendidasHoy + " atendidas hoy");
    \u0275\u0275advance();
    \u0275\u0275styleProp("width", ctx_r1.anchoBarra(p_r13), "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", p_r13.atendidasHoy, " atendidas hoy");
  }
}
function Bandeja_Conditional_11_ForEmpty_91_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li", 44);
    \u0275\u0275text(1, "No hay recepcionistas activas.");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 7)(1, "button", 8);
    \u0275\u0275listener("click", function Bandeja_Conditional_11_Template_button_click_1_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cambiarFiltro("disponibles"));
    });
    \u0275\u0275elementStart(2, "span", 9);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(3, "svg", 4);
    \u0275\u0275element(4, "rect", 10)(5, "path", 11);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(6, "span", 12)(7, "span", 13);
    \u0275\u0275text(8, "Por atender");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "strong");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span", 14);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(13, "button", 15);
    \u0275\u0275listener("click", function Bandeja_Conditional_11_Template_button_click_13_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cambiarFiltro("en_atencion"));
    });
    \u0275\u0275elementStart(14, "span", 9);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(15, "svg", 4);
    \u0275\u0275element(16, "path", 16)(17, "circle", 17)(18, "path", 18)(19, "path", 19);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(20, "span", 12)(21, "span", 13);
    \u0275\u0275text(22, "En atenci\xF3n ahora");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "strong");
    \u0275\u0275text(24);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "span", 14);
    \u0275\u0275text(26);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(27, "div", 20)(28, "span", 9);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(29, "svg", 4);
    \u0275\u0275element(30, "path", 21)(31, "polyline", 22);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(32, "span", 12)(33, "span", 13);
    \u0275\u0275text(34, "Atendidas hoy");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(35, "strong");
    \u0275\u0275text(36);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "span", 14);
    \u0275\u0275text(38);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(39, "div", 23)(40, "span", 9);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(41, "svg", 4);
    \u0275\u0275element(42, "circle", 24)(43, "polyline", 25);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(44, "span", 12)(45, "span", 13);
    \u0275\u0275text(46, "Espera m\xE1s larga");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(47, "strong");
    \u0275\u0275text(48);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(49, "span", 14);
    \u0275\u0275text(50);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(51, "div", 26)(52, "span", 9);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(53, "svg", 4);
    \u0275\u0275element(54, "path", 27)(55, "path", 28);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(56, "span", 12)(57, "span", 13);
    \u0275\u0275text(58, "Tiempo de respuesta");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(59, "strong");
    \u0275\u0275text(60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(61, "span", 14);
    \u0275\u0275text(62);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(63, "div", 29)(64, "div", 30)(65, "div", 31)(66, "div")(67, "h3");
    \u0275\u0275text(68, "Cola de quejas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(69, "p");
    \u0275\u0275text(70, "La m\xE1s reciente arriba. Al abrir una queja queda a tu nombre y nadie m\xE1s puede atenderla.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(71, "div", 32);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(72, "svg", 4);
    \u0275\u0275element(73, "circle", 33)(74, "path", 34);
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(75, "input", 35);
    \u0275\u0275twoWayListener("ngModelChange", function Bandeja_Conditional_11_Template_input_ngModelChange_75_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.busqueda, $event) || (ctx_r1.busqueda = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("ngModelChange", function Bandeja_Conditional_11_Template_input_ngModelChange_75_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.buscar());
    });
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(76, Bandeja_Conditional_11_Conditional_76_Template, 2, 0, "button", 36);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(77, "div", 37);
    \u0275\u0275repeaterCreate(78, Bandeja_Conditional_11_For_79_Template, 4, 6, "button", 38, _forTrack0);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(80, Bandeja_Conditional_11_Conditional_80_Template, 2, 0, "p", 6)(81, Bandeja_Conditional_11_Conditional_81_Template, 8, 1, "div", 39)(82, Bandeja_Conditional_11_Conditional_82_Template, 22, 1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(83, "aside", 40)(84, "h3");
    \u0275\u0275text(85, "Equipo de Recepci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(86, "p", 41);
    \u0275\u0275text(87, "Quejas abiertas y atendidas hoy por cada recepcionista.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(88, "ul", 42);
    \u0275\u0275repeaterCreate(89, Bandeja_Conditional_11_For_90_Template, 11, 12, "li", 43, _forTrack1, false, Bandeja_Conditional_11_ForEmpty_91_Template, 2, 0, "li", 44);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(92, "div", 45)(93, "span");
    \u0275\u0275text(94, "Tu d\xEDa");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(95, "strong");
    \u0275\u0275text(96);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(97, "span");
    \u0275\u0275text(98);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const r_r12 = ctx;
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275classProp("seleccionado", ctx_r1.filtro === "disponibles");
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(r_r12.indicadores.porAtender);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", r_r12.indicadores.nuevasHoy, " llegaron hoy \xB7 ", r_r12.indicadores.corregidas, " corregidas");
    \u0275\u0275advance();
    \u0275\u0275classProp("seleccionado", ctx_r1.filtro === "en_atencion");
    \u0275\u0275advance(11);
    \u0275\u0275textInterpolate(r_r12.indicadores.enAtencion);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", r_r12.indicadores.enAtencionMias, " contigo");
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate(r_r12.indicadores.atendidasHoy);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", r_r12.indicadores.turnadasHoy, " turnadas \xB7 ", r_r12.indicadores.rechazadasHoy, " con observaciones");
    \u0275\u0275advance();
    \u0275\u0275classProp("alerta", ctx_r1.esperaEnAlerta);
    \u0275\u0275property("title", ctx_r1.esperaEnAlerta ? "Lleva " + ctx_r1.diasAlertaEspera + " d\xEDas o m\xE1s sin que nadie la tome" : "La queja que m\xE1s tiempo lleva esperando");
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(ctx_r1.esperaMasLarga);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(r_r12.indicadores.folioMasAntiguo ?? "Sin quejas en espera");
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate(ctx_r1.tiempoPromedio);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("promedio \xB7 \xFAltimos 30 d\xEDas (", r_r12.indicadores.atendidasUltimos30, ")");
    \u0275\u0275advance(13);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.busqueda);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.busqueda ? 76 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.opcionesFiltro);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.cargando ? 80 : r_r12.lista.length === 0 ? 81 : 82);
    \u0275\u0275advance(9);
    \u0275\u0275repeater(r_r12.equipo);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(r_r12.indicadores.atendidasHoyMias);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("atendidas \xB7 ", r_r12.indicadores.enAtencionMias, " abiertas");
  }
}
function Bandeja_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 6);
    \u0275\u0275text(1, "Cargando bandeja\u2026");
    \u0275\u0275elementEnd();
  }
}
var INTERVALO_REFRESCO_MS = 2e4;
var TAMANIO_PAGINA = 10;
var DIAS_ALERTA_ESPERA = 3;
var Bandeja = class _Bandeja {
  revisionService;
  toast;
  router;
  cdr;
  opcionesFiltro = [
    { valor: "todas", etiqueta: "Toda la cola", ayuda: "Por atender y en atenci\xF3n" },
    { valor: "disponibles", etiqueta: "Disponibles", ayuda: "Nadie las ha tomado" },
    { valor: "mias", etiqueta: "Mis quejas", ayuda: "Las que tienes abiertas" },
    { valor: "corregidas", etiqueta: "Corregidas", ayuda: "Reenviadas tras observaciones" },
    { valor: "en_atencion", etiqueta: "En atenci\xF3n", ayuda: "Abiertas por el equipo" }
  ];
  resumen = null;
  cargando = true;
  filtro = "todas";
  busqueda = "";
  pagina = 0;
  soltando = "";
  /** "Jueves, 15 de octubre de 2026" (igual que el panel de Primer Contacto). */
  fechaHoy = (() => {
    const texto = new Intl.DateTimeFormat("es-MX", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric"
    }).format(/* @__PURE__ */ new Date());
    return texto.charAt(0).toUpperCase() + texto.slice(1);
  })();
  intervaloId = null;
  busquedaId = null;
  constructor(revisionService, toast, router, cdr) {
    this.revisionService = revisionService;
    this.toast = toast;
    this.router = router;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.cargar();
    this.intervaloId = setInterval(() => this.cargar(true), INTERVALO_REFRESCO_MS);
  }
  ngOnDestroy() {
    if (this.intervaloId !== null) {
      clearInterval(this.intervaloId);
    }
    if (this.busquedaId !== null) {
      clearTimeout(this.busquedaId);
    }
  }
  // ---------------- filtros, búsqueda y paginado ----------------
  cambiarFiltro(filtro) {
    if (this.filtro === filtro) {
      return;
    }
    this.filtro = filtro;
    this.pagina = 0;
    this.cargar();
  }
  /** Espera a que la recepcionista deje de escribir para no pedir una página por tecla. */
  buscar() {
    if (this.busquedaId !== null) {
      clearTimeout(this.busquedaId);
    }
    this.busquedaId = setTimeout(() => {
      this.pagina = 0;
      this.cargar();
    }, 350);
  }
  limpiarBusqueda() {
    this.busqueda = "";
    this.pagina = 0;
    this.cargar();
  }
  irAPagina(pagina) {
    if (!this.resumen || pagina < 0 || pagina >= this.resumen.totalPaginas || pagina === this.pagina) {
      return;
    }
    this.pagina = pagina;
    this.cargar();
  }
  /** Números de página a mostrar: primera, última y las cercanas a la actual, con "…" en medio. */
  get paginasVisibles() {
    const total = this.resumen?.totalPaginas ?? 0;
    const paginas = [];
    for (let i = 0; i < total; i++) {
      const cerca = Math.abs(i - this.pagina) <= 1;
      if (i === 0 || i === total - 1 || cerca) {
        paginas.push(i);
      } else if (paginas[paginas.length - 1] !== null) {
        paginas.push(null);
      }
    }
    return paginas;
  }
  get rangoMostrado() {
    if (!this.resumen || this.resumen.totalElementos === 0) {
      return "";
    }
    const desde = this.resumen.pagina * this.resumen.tamanio + 1;
    const hasta = desde + this.resumen.lista.length - 1;
    return `Mostrando ${desde}\u2013${hasta} de ${this.resumen.totalElementos}`;
  }
  /** Cuántas quejas hay en cada filtro (para los contadores de las pestañas). */
  conteoFiltro(filtro) {
    const i = this.resumen?.indicadores;
    if (!i) {
      return null;
    }
    switch (filtro) {
      case "todas":
        return i.porAtender + i.enAtencion;
      case "disponibles":
        return i.porAtender;
      case "mias":
        return i.enAtencionMias;
      case "corregidas":
        return i.corregidas;
      case "en_atencion":
        return i.enAtencion;
    }
  }
  // ---------------- acciones sobre una fila ----------------
  bloqueadaPorOtro(item) {
    return item.estatus === "EN_VALIDACION" && !item.esMia;
  }
  atender(item) {
    this.router.navigate(["/validacion", item.numeroFolio]);
  }
  soltar(item) {
    this.soltando = item.numeroFolio;
    this.revisionService.liberar(item.numeroFolio).subscribe({
      next: () => {
        this.soltando = "";
        this.toast.exito(`La queja ${item.numeroFolio} regres\xF3 a la cola.`);
        this.cargar(true);
      },
      error: (err) => {
        this.soltando = "";
        this.toast.error(err?.error?.mensaje ?? "No se pudo soltar la queja.");
        this.cdr.detectChanges();
      }
    });
  }
  // ---------------- textos de apoyo ----------------
  /** "hace 5 min", "hace 3 h", "hace 2 días". */
  hace(fecha) {
    if (!fecha) {
      return "";
    }
    const minutos = Math.max(0, Math.floor((Date.now() - new Date(fecha).getTime()) / 6e4));
    if (minutos < 60) {
      return minutos <= 1 ? "hace un momento" : `hace ${minutos} min`;
    }
    const horas = Math.floor(minutos / 60);
    if (horas < 24) {
      return `hace ${horas} h`;
    }
    const dias = Math.floor(horas / 24);
    return dias === 1 ? "hace 1 d\xEDa" : `hace ${dias} d\xEDas`;
  }
  /** Cuánto lleva esperando la queja más antigua, en el formato más claro ("2 días", "5 h"). */
  get esperaMasLarga() {
    const fecha = this.resumen?.indicadores.fechaMasAntigua;
    if (!fecha) {
      return "\u2014";
    }
    const horas = Math.max(0, (Date.now() - new Date(fecha).getTime()) / 36e5);
    if (horas < 1) {
      return `${Math.max(1, Math.round(horas * 60))} min`;
    }
    if (horas < 24) {
      return `${Math.floor(horas)} h`;
    }
    const dias = Math.floor(horas / 24);
    return dias === 1 ? "1 d\xEDa" : `${dias} d\xEDas`;
  }
  get esperaEnAlerta() {
    const fecha = this.resumen?.indicadores.fechaMasAntigua;
    return !!fecha && Date.now() - new Date(fecha).getTime() >= DIAS_ALERTA_ESPERA * 864e5;
  }
  diasAlertaEspera = DIAS_ALERTA_ESPERA;
  get tiempoPromedio() {
    const horas = this.resumen?.indicadores.horasPromedioAtencion;
    if (horas === null || horas === void 0) {
      return "\u2014";
    }
    if (horas < 1) {
      return `${Math.max(1, Math.round(horas * 60))} min`;
    }
    if (horas < 48) {
      return `${Math.round(horas)} h`;
    }
    return `${(horas / 24).toFixed(1)} d\xEDas`;
  }
  /** Ancho de la barra de "atendidas hoy" relativo a quien más lleva. */
  anchoBarra(persona) {
    const maximo = Math.max(1, ...(this.resumen?.equipo ?? []).map((p) => p.atendidasHoy));
    return Math.round(persona.atendidasHoy / maximo * 100);
  }
  // ---------------- carga ----------------
  cargar(silencioso = false) {
    if (!silencioso) {
      this.cargando = true;
    }
    this.revisionService.bandeja(this.filtro, this.busqueda, this.pagina, TAMANIO_PAGINA).subscribe({
      next: (resumen) => {
        if (resumen.lista.length === 0 && resumen.totalPaginas > 0 && this.pagina >= resumen.totalPaginas) {
          this.pagina = resumen.totalPaginas - 1;
          this.cargar(silencioso);
          return;
        }
        this.resumen = resumen;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        if (!silencioso) {
          this.toast.error("No se pudo cargar la bandeja de entrada.");
        }
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function Bandeja_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Bandeja)(\u0275\u0275directiveInject(RevisionService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Bandeja, selectors: [["app-bandeja"]], decls: 13, vars: 2, consts: [[1, "pagina"], [1, "encabezado"], [1, "fecha"], ["routerLink", "/registro-manual", 1, "btn-guinda"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M12 5v14M5 12h14"], [1, "estado"], [1, "indicadores"], ["type", "button", "title", "Ver las quejas que nadie ha tomado", 1, "indicador", "clic", 3, "click"], [1, "indicador-icono"], ["x", "2", "y", "4", "width", "20", "height", "16", "rx", "2"], ["d", "M22 6l-10 7L2 6"], [1, "indicador-cuerpo"], [1, "indicador-titulo"], [1, "indicador-detalle"], ["type", "button", "title", "Ver qui\xE9n est\xE1 atendiendo qu\xE9", 1, "indicador", "clic", 3, "click"], ["d", "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"], ["cx", "9", "cy", "7", "r", "4"], ["d", "M23 21v-2a4 4 0 0 0-3-3.87"], ["d", "M16 3.13a4 4 0 0 1 0 7.75"], [1, "indicador"], ["d", "M22 11.08V12a10 10 0 1 1-5.93-9.14"], ["points", "22 4 12 14.01 9 11.01"], [1, "indicador", 3, "title"], ["cx", "12", "cy", "12", "r", "10"], ["points", "12 6 12 12 16 14"], ["title", "Tiempo promedio entre que llega una queja y Recepci\xF3n la turna o la regresa con observaciones", 1, "indicador"], ["d", "M3 3v18h18"], ["d", "M7 15l4-4 3 3 5-6"], [1, "distribucion"], [1, "card-panel", "cola"], [1, "cola-encabezado"], [1, "buscador"], ["cx", "11", "cy", "11", "r", "7"], ["d", "m21 21-4.3-4.3"], ["type", "search", "name", "busqueda", "placeholder", "Folio, nombre o unidad", "aria-label", "Buscar en la cola", 3, "ngModelChange", "ngModel"], ["type", "button", "aria-label", "Limpiar b\xFAsqueda", 1, "buscador-limpiar"], ["role", "tablist", 1, "pestanas"], ["type", "button", "role", "tab", 3, "activa", "title"], [1, "estado", "vacio"], [1, "card-panel", "equipo"], [1, "equipo-sub"], [1, "equipo-lista"], [3, "yo"], [1, "equipo-vacio"], [1, "tu-dia"], ["type", "button", "aria-label", "Limpiar b\xFAsqueda", 1, "buscador-limpiar", 3, "click"], ["type", "button", "role", "tab", 3, "click", "title"], [1, "pestana-conteo"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round"], ["points", "22 6 12 13 2 6"], [1, "tabla-envoltura"], [1, "tabla-cola"], [1, "centro"], [1, "derecha"], [3, "ocupada", "mia"], [1, "paginado"], [1, "folio"], [1, "etiqueta-origen"], [1, "fecha-fila"], [1, "hace"], [1, "quejoso"], ["title", "Trae archivos adjuntos y datos m\xEDnimos", 1, "docs", "ok"], ["title", "Podr\xEDa faltar documentaci\xF3n", 1, "docs", "falta"], [1, "chip", "corregida", 3, "title"], [1, "chip", "nueva"], [1, "derecha", "acciones"], ["type", "button", "disabled", "", 1, "btn-fila", 3, "title"], ["type", "button", 1, "btn-fila"], [1, "chip", "contigo"], [1, "chip", "ocupada", 3, "title"], ["type", "button", "title", "Regresarla a la cola", 1, "btn-fila", "secundario", 3, "click", "disabled"], ["type", "button", 1, "btn-fila", 3, "click"], [1, "paginado-rango"], ["aria-label", "P\xE1ginas de la cola"], ["type", "button", "aria-label", "P\xE1gina anterior", 3, "click", "disabled"], ["type", "button", "aria-label", "P\xE1gina siguiente", 3, "click", "disabled"], [1, "paginado-salto"], ["type", "button", 3, "actual"], ["type", "button", 3, "click"], [1, "equipo-fila"], [1, "equipo-nombre"], [1, "equipo-abiertas", 3, "title"], [1, "equipo-barra", 3, "title"], [1, "equipo-atendidas"]], template: function Bandeja_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "section", 0)(1, "div", 1)(2, "div")(3, "h2");
      \u0275\u0275text(4, "Bandeja de Entrada");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(5, "p", 2);
      \u0275\u0275text(6);
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(7, "a", 3);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(8, "svg", 4);
      \u0275\u0275element(9, "path", 5);
      \u0275\u0275elementEnd();
      \u0275\u0275text(10, " Registro manual ");
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(11, Bandeja_Conditional_11_Template, 99, 25)(12, Bandeja_Conditional_12_Template, 2, 0, "p", 6);
      \u0275\u0275elementEnd();
    }
    if (rf & 2) {
      let tmp_1_0;
      \u0275\u0275advance(6);
      \u0275\u0275textInterpolate(ctx.fechaHoy);
      \u0275\u0275advance(5);
      \u0275\u0275conditional((tmp_1_0 = ctx.resumen) ? 11 : ctx.cargando ? 12 : -1, tmp_1_0);
    }
  }, dependencies: [CommonModule, FormsModule, DefaultValueAccessor, NgControlStatus, NgModel, RouterLink, DatePipe], styles: ['@charset "UTF-8";\n\n\n.pagina[_ngcontent-%COMP%] {\n  max-width: 1360px;\n}\n.encabezado[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 24px;\n  margin-bottom: 24px;\n}\n.encabezado[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--guinda);\n  font-size: 28px;\n  font-weight: 800;\n}\n.encabezado[_ngcontent-%COMP%]   .fecha[_ngcontent-%COMP%] {\n  margin: 4px 0 0;\n  color: var(--texto-suave);\n  font-size: 14px;\n}\n.btn-guinda[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  padding: 10px 16px;\n  border-radius: 8px;\n  background: var(--guinda);\n  color: #fff;\n  font-weight: 700;\n  text-decoration: none;\n  white-space: nowrap;\n}\n.btn-guinda[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n}\n.btn-guinda[_ngcontent-%COMP%]:hover {\n  background: var(--guinda-oscuro);\n}\n.indicadores[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));\n  gap: 16px;\n  margin-bottom: 24px;\n}\n.indicador[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 12px;\n  padding: 16px;\n  border-radius: 14px;\n  background: #fff;\n  border: 1px solid transparent;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);\n  text-align: left;\n  font: inherit;\n  color: inherit;\n}\n.indicador.clic[_ngcontent-%COMP%] {\n  cursor: pointer;\n  transition: border-color 0.15s ease, transform 0.15s ease;\n}\n.indicador.clic[_ngcontent-%COMP%]:hover {\n  border-color: #e6c9d6;\n  transform: translateY(-1px);\n}\n.indicador.seleccionado[_ngcontent-%COMP%] {\n  border-color: var(--guinda);\n}\n.indicador.alerta[_ngcontent-%COMP%] {\n  background: #fff8eb;\n  border-color: #f0d7a6;\n}\n.indicador.alerta[_ngcontent-%COMP%]   .indicador-icono[_ngcontent-%COMP%] {\n  color: var(--advertencia);\n  background: #fdf0d6;\n}\n.indicador-icono[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  flex-shrink: 0;\n  display: grid;\n  place-items: center;\n  border-radius: 10px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.indicador-icono[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 22px;\n  height: 22px;\n}\n.indicador-cuerpo[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n}\n.indicador-cuerpo[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: var(--negro-inst);\n  font-size: 26px;\n  font-weight: 900;\n  line-height: 1.3;\n}\n.indicador-titulo[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 13px;\n  font-weight: 700;\n}\n.indicador-detalle[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 12px;\n  line-height: 1.35;\n}\n.distribucion[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) 300px;\n  gap: 24px;\n  align-items: start;\n}\n@media (max-width: 1280px) {\n  .distribucion[_ngcontent-%COMP%] {\n    grid-template-columns: minmax(0, 1fr);\n  }\n}\n.card-panel[_ngcontent-%COMP%] {\n  background: #fff;\n  border-radius: 14px;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);\n  padding: 20px;\n}\n.card-panel[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 18px;\n  font-weight: 900;\n  color: var(--negro-inst);\n}\n.cola-encabezado[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  flex-wrap: wrap;\n  gap: 12px 24px;\n  margin-bottom: 14px;\n}\n.cola-encabezado[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 4px 0 0;\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.buscador[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  align-items: center;\n  flex: 0 1 300px;\n}\n.buscador[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 10px;\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.buscador[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 9px 32px 9px 34px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font: inherit;\n  font-size: 14px;\n}\n.buscador[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]:focus {\n  outline: 2px solid var(--guinda-suave);\n  border-color: var(--guinda);\n}\n.buscador[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]::-webkit-search-cancel-button {\n  display: none;\n}\n.buscador-limpiar[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 6px;\n  border: none;\n  background: none;\n  font-size: 18px;\n  color: var(--texto-suave);\n}\n.pestanas[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 6px;\n  overflow-x: auto;\n  padding-bottom: 12px;\n  margin-bottom: 4px;\n  border-bottom: 1px solid #eee;\n}\n.pestanas[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  padding: 7px 12px;\n  border: 1px solid transparent;\n  border-radius: 999px;\n  background: #f4f5f7;\n  color: var(--texto);\n  font-size: 13px;\n  font-weight: 600;\n  white-space: nowrap;\n}\n.pestanas[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover {\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.pestanas[_ngcontent-%COMP%]   button.activa[_ngcontent-%COMP%] {\n  background: var(--guinda);\n  color: #fff;\n}\n.pestanas[_ngcontent-%COMP%]   button.activa[_ngcontent-%COMP%]   .pestana-conteo[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.22);\n  color: #fff;\n}\n.pestana-conteo[_ngcontent-%COMP%] {\n  min-width: 22px;\n  padding: 1px 7px;\n  border-radius: 999px;\n  background: #fff;\n  color: var(--texto-suave);\n  font-size: 12px;\n  text-align: center;\n}\n.estado[_ngcontent-%COMP%] {\n  padding: 32px 12px;\n  color: var(--texto-suave);\n  text-align: center;\n}\n.estado.vacio[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  color: #c9c9c9;\n}\n.tabla-envoltura[_ngcontent-%COMP%] {\n  overflow-x: auto;\n}\n.tabla-cola[_ngcontent-%COMP%] {\n  width: 100%;\n  border-collapse: separate;\n  border-spacing: 0 6px;\n  font-size: 14px;\n}\n.tabla-cola[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  padding: 10px 12px 4px;\n  color: var(--texto-suave);\n  font-size: 12px;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n  text-align: left;\n  white-space: nowrap;\n}\n.tabla-cola[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  padding: 10px 12px;\n  background: #f9fafb;\n  vertical-align: middle;\n}\n.tabla-cola[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:first-child {\n  border-radius: 8px 0 0 8px;\n}\n.tabla-cola[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:last-child {\n  border-radius: 0 8px 8px 0;\n}\n.tabla-cola[_ngcontent-%COMP%]   tr.mia[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  background: #f1f8f3;\n}\n.tabla-cola[_ngcontent-%COMP%]   tr.ocupada[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  color: #8a8f98;\n}\n.tabla-cola[_ngcontent-%COMP%]   .centro[_ngcontent-%COMP%] {\n  text-align: center;\n}\n.tabla-cola[_ngcontent-%COMP%]   .derecha[_ngcontent-%COMP%] {\n  text-align: right;\n}\n.folio[_ngcontent-%COMP%] {\n  display: block;\n  font-weight: 700;\n  color: var(--negro-inst);\n  white-space: nowrap;\n}\n.etiqueta-origen[_ngcontent-%COMP%] {\n  display: inline-block;\n  margin-top: 2px;\n  padding: 0 6px;\n  border-radius: 4px;\n  background: #ece7f6;\n  color: #5b3d99;\n  font-size: 11px;\n  font-weight: 600;\n}\n.fecha-fila[_ngcontent-%COMP%] {\n  display: block;\n  white-space: nowrap;\n}\n.hace[_ngcontent-%COMP%] {\n  display: block;\n  color: var(--texto-suave);\n  font-size: 12px;\n}\n.quejoso[_ngcontent-%COMP%] {\n  min-width: 160px;\n}\n.docs[_ngcontent-%COMP%] {\n  display: inline-grid;\n  place-items: center;\n  width: 22px;\n  height: 22px;\n  border-radius: 50%;\n  color: #fff;\n  font-size: 12px;\n  font-weight: 800;\n}\n.docs.ok[_ngcontent-%COMP%] {\n  background: var(--exito);\n}\n.docs.falta[_ngcontent-%COMP%] {\n  background: var(--advertencia);\n}\n.chip[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding: 3px 10px;\n  border-radius: 999px;\n  font-size: 12px;\n  font-weight: 700;\n  white-space: nowrap;\n  max-width: 190px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  vertical-align: middle;\n}\n.chip.nueva[_ngcontent-%COMP%] {\n  background: #fbf1e0;\n  color: #9a6512;\n}\n.chip.corregida[_ngcontent-%COMP%] {\n  background: #ece7f6;\n  color: #5b3d99;\n}\n.chip.contigo[_ngcontent-%COMP%] {\n  background: #e3f3e8;\n  color: #1d6b3a;\n}\n.chip.ocupada[_ngcontent-%COMP%] {\n  background: #e8eefc;\n  color: #2f55b3;\n}\n.acciones[_ngcontent-%COMP%] {\n  white-space: nowrap;\n}\n.btn-fila[_ngcontent-%COMP%] {\n  margin-left: 6px;\n  padding: 7px 14px;\n  border: 1px solid var(--guinda);\n  border-radius: 6px;\n  background: var(--guinda);\n  color: #fff;\n  font-size: 13px;\n  font-weight: 700;\n}\n.btn-fila[_ngcontent-%COMP%]:hover:not(:disabled) {\n  background: var(--guinda-oscuro);\n}\n.btn-fila.secundario[_ngcontent-%COMP%] {\n  background: #fff;\n  color: var(--guinda);\n}\n.btn-fila.secundario[_ngcontent-%COMP%]:hover:not(:disabled) {\n  background: var(--guinda-suave);\n}\n.btn-fila[_ngcontent-%COMP%]:disabled {\n  border-color: #d5d8de;\n  background: #eceef1;\n  color: #8a8f98;\n  cursor: not-allowed;\n}\n.paginado[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  flex-wrap: wrap;\n  gap: 12px;\n  margin-top: 12px;\n  padding-top: 12px;\n  border-top: 1px solid #eee;\n}\n.paginado[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n.paginado[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  min-width: 34px;\n  height: 34px;\n  padding: 0 8px;\n  border: 1px solid var(--borde);\n  border-radius: 6px;\n  background: #fff;\n  color: var(--texto);\n  font-weight: 600;\n}\n.paginado[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover:not(:disabled) {\n  border-color: var(--guinda);\n  color: var(--guinda);\n}\n.paginado[_ngcontent-%COMP%]   button.actual[_ngcontent-%COMP%] {\n  border-color: var(--guinda);\n  background: var(--guinda);\n  color: #fff;\n}\n.paginado[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:disabled {\n  opacity: 0.4;\n  cursor: not-allowed;\n}\n.paginado-rango[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.paginado-salto[_ngcontent-%COMP%] {\n  padding: 0 4px;\n  color: var(--texto-suave);\n}\n.equipo-sub[_ngcontent-%COMP%] {\n  margin: 4px 0 14px;\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.equipo-lista[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 8px;\n}\n.equipo-lista[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  padding: 10px 12px;\n  border-radius: 8px;\n  background: #f9fafb;\n}\n.equipo-lista[_ngcontent-%COMP%]   li.yo[_ngcontent-%COMP%] {\n  background: var(--guinda-suave);\n}\n.equipo-fila[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: baseline;\n  gap: 8px;\n}\n.equipo-nombre[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 600;\n  color: var(--negro-inst);\n}\n.equipo-nombre[_ngcontent-%COMP%]   em[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 400;\n  color: var(--guinda);\n}\n.equipo-abiertas[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n  color: var(--texto-suave);\n  font-size: 12px;\n}\n.equipo-abiertas.activa[_ngcontent-%COMP%] {\n  color: #2f55b3;\n  font-weight: 700;\n}\n.equipo-barra[_ngcontent-%COMP%] {\n  height: 6px;\n  margin: 8px 0 4px;\n  border-radius: 999px;\n  background: #e9ebef;\n  overflow: hidden;\n}\n.equipo-barra[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  display: block;\n  height: 100%;\n  border-radius: inherit;\n  background: var(--guinda);\n}\n.equipo-atendidas[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 12px;\n}\n.equipo-vacio[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.tu-dia[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  flex-wrap: wrap;\n  gap: 6px;\n  margin-top: 14px;\n  padding-top: 14px;\n  border-top: 1px solid #eee;\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.tu-dia[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: var(--guinda);\n  font-size: 22px;\n  font-weight: 900;\n}\n@media (max-width: 700px) {\n  .encabezado[_ngcontent-%COMP%] {\n    flex-direction: column;\n    align-items: flex-start;\n    gap: 12px;\n  }\n  .buscador[_ngcontent-%COMP%] {\n    flex-basis: 100%;\n  }\n}\n/*# sourceMappingURL=bandeja.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Bandeja, [{
    type: Component,
    args: [{ selector: "app-bandeja", standalone: true, imports: [CommonModule, FormsModule, RouterLink], template: `<section class="pagina">
  <div class="encabezado">
    <div>
      <h2>Bandeja de Entrada</h2>
      <p class="fecha">{{ fechaHoy }}</p>
    </div>
    <a routerLink="/registro-manual" class="btn-guinda">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"></path></svg>
      Registro manual
    </a>
  </div>

  @if (resumen; as r) {
    <!-- ================= Indicadores ================= -->
    <div class="indicadores">
      <button type="button" class="indicador clic" [class.seleccionado]="filtro === 'disponibles'"
              (click)="cambiarFiltro('disponibles')" title="Ver las quejas que nadie ha tomado">
        <span class="indicador-icono">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"></rect><path d="M22 6l-10 7L2 6"></path></svg>
        </span>
        <span class="indicador-cuerpo">
          <span class="indicador-titulo">Por atender</span>
          <strong>{{ r.indicadores.porAtender }}</strong>
          <span class="indicador-detalle">{{ r.indicadores.nuevasHoy }} llegaron hoy \xB7 {{ r.indicadores.corregidas }} corregidas</span>
        </span>
      </button>

      <button type="button" class="indicador clic" [class.seleccionado]="filtro === 'en_atencion'"
              (click)="cambiarFiltro('en_atencion')" title="Ver qui\xE9n est\xE1 atendiendo qu\xE9">
        <span class="indicador-icono">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
        </span>
        <span class="indicador-cuerpo">
          <span class="indicador-titulo">En atenci\xF3n ahora</span>
          <strong>{{ r.indicadores.enAtencion }}</strong>
          <span class="indicador-detalle">{{ r.indicadores.enAtencionMias }} contigo</span>
        </span>
      </button>

      <div class="indicador">
        <span class="indicador-icono">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
        </span>
        <span class="indicador-cuerpo">
          <span class="indicador-titulo">Atendidas hoy</span>
          <strong>{{ r.indicadores.atendidasHoy }}</strong>
          <span class="indicador-detalle">{{ r.indicadores.turnadasHoy }} turnadas \xB7 {{ r.indicadores.rechazadasHoy }} con observaciones</span>
        </span>
      </div>

      <div class="indicador" [class.alerta]="esperaEnAlerta"
           [title]="esperaEnAlerta ? 'Lleva ' + diasAlertaEspera + ' d\xEDas o m\xE1s sin que nadie la tome' : 'La queja que m\xE1s tiempo lleva esperando'">
        <span class="indicador-icono">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
        </span>
        <span class="indicador-cuerpo">
          <span class="indicador-titulo">Espera m\xE1s larga</span>
          <strong>{{ esperaMasLarga }}</strong>
          <span class="indicador-detalle">{{ r.indicadores.folioMasAntiguo ?? 'Sin quejas en espera' }}</span>
        </span>
      </div>

      <div class="indicador" title="Tiempo promedio entre que llega una queja y Recepci\xF3n la turna o la regresa con observaciones">
        <span class="indicador-icono">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"></path><path d="M7 15l4-4 3 3 5-6"></path></svg>
        </span>
        <span class="indicador-cuerpo">
          <span class="indicador-titulo">Tiempo de respuesta</span>
          <strong>{{ tiempoPromedio }}</strong>
          <span class="indicador-detalle">promedio \xB7 \xFAltimos 30 d\xEDas ({{ r.indicadores.atendidasUltimos30 }})</span>
        </span>
      </div>
    </div>

    <div class="distribucion">
      <!-- ================= Cola ================= -->
      <div class="card-panel cola">
        <div class="cola-encabezado">
          <div>
            <h3>Cola de quejas</h3>
            <p>La m\xE1s reciente arriba. Al abrir una queja queda a tu nombre y nadie m\xE1s puede atenderla.</p>
          </div>
          <div class="buscador">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><path d="m21 21-4.3-4.3"></path></svg>
            <input type="search" [(ngModel)]="busqueda" (ngModelChange)="buscar()" name="busqueda"
                   placeholder="Folio, nombre o unidad" aria-label="Buscar en la cola" />
            @if (busqueda) {
              <button type="button" class="buscador-limpiar" (click)="limpiarBusqueda()" aria-label="Limpiar b\xFAsqueda">\xD7</button>
            }
          </div>
        </div>

        <div class="pestanas" role="tablist">
          @for (op of opcionesFiltro; track op.valor) {
            <button type="button" role="tab" [attr.aria-selected]="filtro === op.valor"
                    [class.activa]="filtro === op.valor" (click)="cambiarFiltro(op.valor)" [title]="op.ayuda">
              {{ op.etiqueta }}
              <span class="pestana-conteo">{{ conteoFiltro(op.valor) }}</span>
            </button>
          }
        </div>

        @if (cargando) {
          <p class="estado">Cargando\u2026</p>
        } @else if (r.lista.length === 0) {
          <div class="estado vacio">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"></rect><polyline points="22 6 12 13 2 6"></polyline></svg>
            <p>
              @if (busqueda) { No hay quejas que coincidan con "{{ busqueda }}". }
              @else if (filtro === 'mias') { No tienes quejas abiertas. Toma una de "Disponibles". }
              @else { No hay quejas en esta vista. }
            </p>
          </div>
        } @else {
          <div class="tabla-envoltura">
            <table class="tabla-cola">
              <thead>
                <tr>
                  <th>Folio</th>
                  <th>Lleg\xF3</th>
                  <th>Quejoso</th>
                  <th>Unidad</th>
                  <th class="centro">Docs.</th>
                  <th>Estado</th>
                  <th class="derecha">Acci\xF3n</th>
                </tr>
              </thead>
              <tbody>
                @for (item of r.lista; track item.numeroFolio) {
                  <tr [class.ocupada]="bloqueadaPorOtro(item)" [class.mia]="item.esMia">
                    <td>
                      <span class="folio">{{ item.numeroFolio }}</span>
                      @if (item.origen === 'MANUAL') { <span class="etiqueta-origen">Ventanilla</span> }
                    </td>
                    <td>
                      <span class="fecha-fila">{{ item.fechaCreacion | date: 'dd/MM/yy HH:mm' }}</span>
                      <span class="hace">{{ hace(item.fechaCreacion) }}</span>
                    </td>
                    <td class="quejoso">{{ item.nombreQuejoso }}</td>
                    <td>{{ item.unidadAcademicaClave || '\u2014' }}</td>
                    <td class="centro">
                      @if (item.documentacionAparenteCompleta) {
                        <span class="docs ok" title="Trae archivos adjuntos y datos m\xEDnimos">\u2713</span>
                      } @else {
                        <span class="docs falta" title="Podr\xEDa faltar documentaci\xF3n">!</span>
                      }
                    </td>
                    <td>
                      @if (item.estatus === 'EN_VALIDACION') {
                        @if (item.esMia) {
                          <span class="chip contigo">Contigo</span>
                        } @else {
                          <span class="chip ocupada" [title]="'La est\xE1 atendiendo ' + item.revisandoPorNombre">Con {{ item.revisandoPorNombre }}</span>
                        }
                      } @else if (item.estatus === 'CORREGIDA') {
                        <span class="chip corregida"
                              [title]="item.rechazadaAntesPor ? 'La regres\xF3 con observaciones ' + item.rechazadaAntesPor : 'El quejoso atendi\xF3 las observaciones'">
                          Corregida
                        </span>
                      } @else {
                        <span class="chip nueva">Nueva</span>
                      }
                    </td>
                    <td class="derecha acciones">
                      @if (bloqueadaPorOtro(item)) {
                        <button type="button" class="btn-fila" disabled
                                [title]="'La atiende ' + item.revisandoPorNombre + '. Se libera sola si la deja 20 min sin actividad.'">
                          Ocupada
                        </button>
                      } @else if (item.esMia) {
                        <button type="button" class="btn-fila secundario" (click)="soltar(item)"
                                [disabled]="soltando === item.numeroFolio" title="Regresarla a la cola">
                          {{ soltando === item.numeroFolio ? '\u2026' : 'Soltar' }}
                        </button>
                        <button type="button" class="btn-fila" (click)="atender(item)">Continuar</button>
                      } @else {
                        <button type="button" class="btn-fila" (click)="atender(item)">Atender</button>
                      }
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

          @if (r.totalPaginas > 1 || r.totalElementos > 0) {
            <div class="paginado">
              <span class="paginado-rango">{{ rangoMostrado }}</span>
              @if (r.totalPaginas > 1) {
                <nav aria-label="P\xE1ginas de la cola">
                  <button type="button" (click)="irAPagina(pagina - 1)" [disabled]="pagina === 0" aria-label="P\xE1gina anterior">\u2039</button>
                  @for (p of paginasVisibles; track $index) {
                    @if (p === null) {
                      <span class="paginado-salto">\u2026</span>
                    } @else {
                      <button type="button" [class.actual]="p === pagina" (click)="irAPagina(p)"
                              [attr.aria-current]="p === pagina ? 'page' : null">{{ p + 1 }}</button>
                    }
                  }
                  <button type="button" (click)="irAPagina(pagina + 1)" [disabled]="pagina >= r.totalPaginas - 1" aria-label="P\xE1gina siguiente">\u203A</button>
                </nav>
              }
            </div>
          }
        }
      </div>

      <!-- ================= Equipo ================= -->
      <aside class="card-panel equipo">
        <h3>Equipo de Recepci\xF3n</h3>
        <p class="equipo-sub">Quejas abiertas y atendidas hoy por cada recepcionista.</p>

        <ul class="equipo-lista">
          @for (p of r.equipo; track p.nombre) {
            <li [class.yo]="p.soyYo">
              <div class="equipo-fila">
                <span class="equipo-nombre">{{ p.nombre }} @if (p.soyYo) { <em>(t\xFA)</em> }</span>
                <span class="equipo-abiertas" [class.activa]="p.enAtencion > 0"
                      [title]="p.enAtencion + ' queja(s) abiertas ahora'">{{ p.enAtencion }} abiertas</span>
              </div>
              <div class="equipo-barra" [title]="p.atendidasHoy + ' atendidas hoy'">
                <span [style.width.%]="anchoBarra(p)"></span>
              </div>
              <span class="equipo-atendidas">{{ p.atendidasHoy }} atendidas hoy</span>
            </li>
          } @empty {
            <li class="equipo-vacio">No hay recepcionistas activas.</li>
          }
        </ul>

        <div class="tu-dia">
          <span>Tu d\xEDa</span>
          <strong>{{ r.indicadores.atendidasHoyMias }}</strong>
          <span>atendidas \xB7 {{ r.indicadores.enAtencionMias }} abiertas</span>
        </div>
      </aside>
    </div>
  } @else if (cargando) {
    <p class="estado">Cargando bandeja\u2026</p>
  }
</section>
`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/bandeja/bandeja.scss */\n.pagina {\n  max-width: 1360px;\n}\n.encabezado {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 24px;\n  margin-bottom: 24px;\n}\n.encabezado h2 {\n  margin: 0;\n  color: var(--guinda);\n  font-size: 28px;\n  font-weight: 800;\n}\n.encabezado .fecha {\n  margin: 4px 0 0;\n  color: var(--texto-suave);\n  font-size: 14px;\n}\n.btn-guinda {\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  padding: 10px 16px;\n  border-radius: 8px;\n  background: var(--guinda);\n  color: #fff;\n  font-weight: 700;\n  text-decoration: none;\n  white-space: nowrap;\n}\n.btn-guinda svg {\n  width: 18px;\n  height: 18px;\n}\n.btn-guinda:hover {\n  background: var(--guinda-oscuro);\n}\n.indicadores {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));\n  gap: 16px;\n  margin-bottom: 24px;\n}\n.indicador {\n  display: flex;\n  align-items: flex-start;\n  gap: 12px;\n  padding: 16px;\n  border-radius: 14px;\n  background: #fff;\n  border: 1px solid transparent;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);\n  text-align: left;\n  font: inherit;\n  color: inherit;\n}\n.indicador.clic {\n  cursor: pointer;\n  transition: border-color 0.15s ease, transform 0.15s ease;\n}\n.indicador.clic:hover {\n  border-color: #e6c9d6;\n  transform: translateY(-1px);\n}\n.indicador.seleccionado {\n  border-color: var(--guinda);\n}\n.indicador.alerta {\n  background: #fff8eb;\n  border-color: #f0d7a6;\n}\n.indicador.alerta .indicador-icono {\n  color: var(--advertencia);\n  background: #fdf0d6;\n}\n.indicador-icono {\n  width: 40px;\n  height: 40px;\n  flex-shrink: 0;\n  display: grid;\n  place-items: center;\n  border-radius: 10px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.indicador-icono svg {\n  width: 22px;\n  height: 22px;\n}\n.indicador-cuerpo {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n}\n.indicador-cuerpo strong {\n  color: var(--negro-inst);\n  font-size: 26px;\n  font-weight: 900;\n  line-height: 1.3;\n}\n.indicador-titulo {\n  color: var(--texto-suave);\n  font-size: 13px;\n  font-weight: 700;\n}\n.indicador-detalle {\n  color: var(--texto-suave);\n  font-size: 12px;\n  line-height: 1.35;\n}\n.distribucion {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) 300px;\n  gap: 24px;\n  align-items: start;\n}\n@media (max-width: 1280px) {\n  .distribucion {\n    grid-template-columns: minmax(0, 1fr);\n  }\n}\n.card-panel {\n  background: #fff;\n  border-radius: 14px;\n  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);\n  padding: 20px;\n}\n.card-panel h3 {\n  margin: 0;\n  font-size: 18px;\n  font-weight: 900;\n  color: var(--negro-inst);\n}\n.cola-encabezado {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  flex-wrap: wrap;\n  gap: 12px 24px;\n  margin-bottom: 14px;\n}\n.cola-encabezado p {\n  margin: 4px 0 0;\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.buscador {\n  position: relative;\n  display: flex;\n  align-items: center;\n  flex: 0 1 300px;\n}\n.buscador svg {\n  position: absolute;\n  left: 10px;\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.buscador input {\n  width: 100%;\n  padding: 9px 32px 9px 34px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font: inherit;\n  font-size: 14px;\n}\n.buscador input:focus {\n  outline: 2px solid var(--guinda-suave);\n  border-color: var(--guinda);\n}\n.buscador input::-webkit-search-cancel-button {\n  display: none;\n}\n.buscador-limpiar {\n  position: absolute;\n  right: 6px;\n  border: none;\n  background: none;\n  font-size: 18px;\n  color: var(--texto-suave);\n}\n.pestanas {\n  display: flex;\n  gap: 6px;\n  overflow-x: auto;\n  padding-bottom: 12px;\n  margin-bottom: 4px;\n  border-bottom: 1px solid #eee;\n}\n.pestanas button {\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  padding: 7px 12px;\n  border: 1px solid transparent;\n  border-radius: 999px;\n  background: #f4f5f7;\n  color: var(--texto);\n  font-size: 13px;\n  font-weight: 600;\n  white-space: nowrap;\n}\n.pestanas button:hover {\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.pestanas button.activa {\n  background: var(--guinda);\n  color: #fff;\n}\n.pestanas button.activa .pestana-conteo {\n  background: rgba(255, 255, 255, 0.22);\n  color: #fff;\n}\n.pestana-conteo {\n  min-width: 22px;\n  padding: 1px 7px;\n  border-radius: 999px;\n  background: #fff;\n  color: var(--texto-suave);\n  font-size: 12px;\n  text-align: center;\n}\n.estado {\n  padding: 32px 12px;\n  color: var(--texto-suave);\n  text-align: center;\n}\n.estado.vacio svg {\n  width: 40px;\n  height: 40px;\n  color: #c9c9c9;\n}\n.tabla-envoltura {\n  overflow-x: auto;\n}\n.tabla-cola {\n  width: 100%;\n  border-collapse: separate;\n  border-spacing: 0 6px;\n  font-size: 14px;\n}\n.tabla-cola th {\n  padding: 10px 12px 4px;\n  color: var(--texto-suave);\n  font-size: 12px;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n  text-align: left;\n  white-space: nowrap;\n}\n.tabla-cola td {\n  padding: 10px 12px;\n  background: #f9fafb;\n  vertical-align: middle;\n}\n.tabla-cola td:first-child {\n  border-radius: 8px 0 0 8px;\n}\n.tabla-cola td:last-child {\n  border-radius: 0 8px 8px 0;\n}\n.tabla-cola tr.mia td {\n  background: #f1f8f3;\n}\n.tabla-cola tr.ocupada td {\n  color: #8a8f98;\n}\n.tabla-cola .centro {\n  text-align: center;\n}\n.tabla-cola .derecha {\n  text-align: right;\n}\n.folio {\n  display: block;\n  font-weight: 700;\n  color: var(--negro-inst);\n  white-space: nowrap;\n}\n.etiqueta-origen {\n  display: inline-block;\n  margin-top: 2px;\n  padding: 0 6px;\n  border-radius: 4px;\n  background: #ece7f6;\n  color: #5b3d99;\n  font-size: 11px;\n  font-weight: 600;\n}\n.fecha-fila {\n  display: block;\n  white-space: nowrap;\n}\n.hace {\n  display: block;\n  color: var(--texto-suave);\n  font-size: 12px;\n}\n.quejoso {\n  min-width: 160px;\n}\n.docs {\n  display: inline-grid;\n  place-items: center;\n  width: 22px;\n  height: 22px;\n  border-radius: 50%;\n  color: #fff;\n  font-size: 12px;\n  font-weight: 800;\n}\n.docs.ok {\n  background: var(--exito);\n}\n.docs.falta {\n  background: var(--advertencia);\n}\n.chip {\n  display: inline-block;\n  padding: 3px 10px;\n  border-radius: 999px;\n  font-size: 12px;\n  font-weight: 700;\n  white-space: nowrap;\n  max-width: 190px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  vertical-align: middle;\n}\n.chip.nueva {\n  background: #fbf1e0;\n  color: #9a6512;\n}\n.chip.corregida {\n  background: #ece7f6;\n  color: #5b3d99;\n}\n.chip.contigo {\n  background: #e3f3e8;\n  color: #1d6b3a;\n}\n.chip.ocupada {\n  background: #e8eefc;\n  color: #2f55b3;\n}\n.acciones {\n  white-space: nowrap;\n}\n.btn-fila {\n  margin-left: 6px;\n  padding: 7px 14px;\n  border: 1px solid var(--guinda);\n  border-radius: 6px;\n  background: var(--guinda);\n  color: #fff;\n  font-size: 13px;\n  font-weight: 700;\n}\n.btn-fila:hover:not(:disabled) {\n  background: var(--guinda-oscuro);\n}\n.btn-fila.secundario {\n  background: #fff;\n  color: var(--guinda);\n}\n.btn-fila.secundario:hover:not(:disabled) {\n  background: var(--guinda-suave);\n}\n.btn-fila:disabled {\n  border-color: #d5d8de;\n  background: #eceef1;\n  color: #8a8f98;\n  cursor: not-allowed;\n}\n.paginado {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  flex-wrap: wrap;\n  gap: 12px;\n  margin-top: 12px;\n  padding-top: 12px;\n  border-top: 1px solid #eee;\n}\n.paginado nav {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n.paginado button {\n  min-width: 34px;\n  height: 34px;\n  padding: 0 8px;\n  border: 1px solid var(--borde);\n  border-radius: 6px;\n  background: #fff;\n  color: var(--texto);\n  font-weight: 600;\n}\n.paginado button:hover:not(:disabled) {\n  border-color: var(--guinda);\n  color: var(--guinda);\n}\n.paginado button.actual {\n  border-color: var(--guinda);\n  background: var(--guinda);\n  color: #fff;\n}\n.paginado button:disabled {\n  opacity: 0.4;\n  cursor: not-allowed;\n}\n.paginado-rango {\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.paginado-salto {\n  padding: 0 4px;\n  color: var(--texto-suave);\n}\n.equipo-sub {\n  margin: 4px 0 14px;\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.equipo-lista {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 8px;\n}\n.equipo-lista li {\n  padding: 10px 12px;\n  border-radius: 8px;\n  background: #f9fafb;\n}\n.equipo-lista li.yo {\n  background: var(--guinda-suave);\n}\n.equipo-fila {\n  display: flex;\n  justify-content: space-between;\n  align-items: baseline;\n  gap: 8px;\n}\n.equipo-nombre {\n  font-size: 14px;\n  font-weight: 600;\n  color: var(--negro-inst);\n}\n.equipo-nombre em {\n  font-style: normal;\n  font-weight: 400;\n  color: var(--guinda);\n}\n.equipo-abiertas {\n  flex-shrink: 0;\n  color: var(--texto-suave);\n  font-size: 12px;\n}\n.equipo-abiertas.activa {\n  color: #2f55b3;\n  font-weight: 700;\n}\n.equipo-barra {\n  height: 6px;\n  margin: 8px 0 4px;\n  border-radius: 999px;\n  background: #e9ebef;\n  overflow: hidden;\n}\n.equipo-barra span {\n  display: block;\n  height: 100%;\n  border-radius: inherit;\n  background: var(--guinda);\n}\n.equipo-atendidas {\n  color: var(--texto-suave);\n  font-size: 12px;\n}\n.equipo-vacio {\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.tu-dia {\n  display: flex;\n  align-items: baseline;\n  flex-wrap: wrap;\n  gap: 6px;\n  margin-top: 14px;\n  padding-top: 14px;\n  border-top: 1px solid #eee;\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.tu-dia strong {\n  color: var(--guinda);\n  font-size: 22px;\n  font-weight: 900;\n}\n@media (max-width: 700px) {\n  .encabezado {\n    flex-direction: column;\n    align-items: flex-start;\n    gap: 12px;\n  }\n  .buscador {\n    flex-basis: 100%;\n  }\n}\n/*# sourceMappingURL=bandeja.css.map */\n'] }]
  }], () => [{ type: RevisionService }, { type: ToastService }, { type: Router }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Bandeja, { className: "Bandeja", filePath: "src/app/pages/bandeja/bandeja.ts", lineNumber: 38 });
})();
export {
  Bandeja
};
//# sourceMappingURL=chunk-ZTXBE5AP.js.map
