import {
  DefaultValueAccessor,
  FormsModule,
  MaxLengthValidator,
  NG_VALUE_ACCESSOR,
  NgControlStatus,
  NgControlStatusGroup,
  NgForm,
  NgModel,
  NgSelectOption,
  RadioControlValueAccessor,
  RequiredValidator,
  SelectControlValueAccessor,
  ɵNgNoValidate,
  ɵNgSelectMultipleOption
} from "./chunk-QD7SBTDO.js";
import {
  Router,
  RouterLink
} from "./chunk-3TUQ6HGZ.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  HttpClient,
  Injectable,
  Input,
  Output,
  ToastService,
  ViewChild,
  forwardRef,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵNgOnChangesFeature,
  ɵɵProvidersFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵdomElement,
  ɵɵdomElementEnd,
  ɵɵdomElementStart,
  ɵɵdomListener,
  ɵɵdomProperty,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵqueryRefresh,
  ɵɵreference,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵrepeaterTrackByIndex,
  ɵɵresetView,
  ɵɵresolveDocument,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty,
  ɵɵviewQuery
} from "./chunk-BX5W5AEF.js";

// src/app/shared/datepicker/datepicker.ts
var _forTrack0 = ($index, $item) => $item.iso;
function Datepicker_Conditional_6_For_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 8);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const nombre_r3 = ctx.$implicit;
    const \u0275$index_21_r4 = ctx.$index;
    \u0275\u0275property("ngValue", \u0275$index_21_r4);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(nombre_r3);
  }
}
function Datepicker_Conditional_6_For_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 8);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ano_r5 = ctx.$implicit;
    \u0275\u0275property("ngValue", ano_r5);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ano_r5);
  }
}
function Datepicker_Conditional_6_For_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const d_r6 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(d_r6);
  }
}
function Datepicker_Conditional_6_For_16_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 16);
    \u0275\u0275listener("click", function Datepicker_Conditional_6_For_16_For_2_Template_button_click_0_listener() {
      const celda_r8 = \u0275\u0275restoreView(_r7).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.seleccionarDia(celda_r8));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const celda_r8 = ctx.$implicit;
    \u0275\u0275classProp("datepicker__dia--fuera", celda_r8.fueraDeMes)("datepicker__dia--hoy", celda_r8.esHoy)("datepicker__dia--seleccionado", celda_r8.esSeleccionado);
    \u0275\u0275property("disabled", celda_r8.deshabilitado);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", celda_r8.dia, " ");
  }
}
function Datepicker_Conditional_6_For_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 12);
    \u0275\u0275repeaterCreate(1, Datepicker_Conditional_6_For_16_For_2_Template, 2, 8, "button", 15, _forTrack0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const semana_r9 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275repeater(semana_r9);
  }
}
function Datepicker_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 4);
    \u0275\u0275listener("click", function Datepicker_Conditional_6_Template_div_click_0_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(1, "div", 5)(2, "button", 6);
    \u0275\u0275listener("click", function Datepicker_Conditional_6_Template_button_click_2_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cambiarMesVista(-1));
    });
    \u0275\u0275text(3, "\u2039");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "select", 7);
    \u0275\u0275twoWayListener("ngModelChange", function Datepicker_Conditional_6_Template_select_ngModelChange_4_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.vistaMes, $event) || (ctx_r1.vistaMes = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275repeaterCreate(5, Datepicker_Conditional_6_For_6_Template, 2, 2, "option", 8, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "select", 9);
    \u0275\u0275twoWayListener("ngModelChange", function Datepicker_Conditional_6_Template_select_ngModelChange_7_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.vistaAno, $event) || (ctx_r1.vistaAno = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275repeaterCreate(8, Datepicker_Conditional_6_For_9_Template, 2, 2, "option", 8, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "button", 10);
    \u0275\u0275listener("click", function Datepicker_Conditional_6_Template_button_click_10_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cambiarMesVista(1));
    });
    \u0275\u0275text(11, "\u203A");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(12, "div", 11);
    \u0275\u0275repeaterCreate(13, Datepicker_Conditional_6_For_14_Template, 2, 1, "span", null, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(15, Datepicker_Conditional_6_For_16_Template, 3, 0, "div", 12, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275elementStart(17, "div", 13)(18, "button", 14);
    \u0275\u0275listener("click", function Datepicker_Conditional_6_Template_button_click_18_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.irAHoy());
    });
    \u0275\u0275text(19, "Hoy");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "button", 14);
    \u0275\u0275listener("click", function Datepicker_Conditional_6_Template_button_click_20_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.limpiar());
    });
    \u0275\u0275text(21, "Limpiar");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.vistaMes);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r1.nombresMes);
    \u0275\u0275advance(2);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.vistaAno);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r1.listaAnos);
    \u0275\u0275advance(5);
    \u0275\u0275repeater(ctx_r1.nombresDia);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.semanas);
  }
}
var NOMBRES_MES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre"
];
var NOMBRES_DIA = ["D", "L", "M", "M", "J", "V", "S"];
var Datepicker = class _Datepicker {
  elementRef;
  placeholder = "dd/mm/aaaa";
  /** Fecha máxima seleccionable, formato ISO yyyy-mm-dd. */
  max = "";
  /** Fecha mínima seleccionable, formato ISO yyyy-mm-dd. Si no se da, se usa 100 años atrás. */
  min = "";
  /** Se emite además del ngModelChange normal, para poder enganchar lógica extra (p. ej.
   * detectar menor de edad) igual que el (change) del input nativo. */
  cambio = new EventEmitter();
  nombresMes = NOMBRES_MES;
  nombresDia = NOMBRES_DIA;
  valor = "";
  abierto = false;
  disabled = false;
  vistaAno = (/* @__PURE__ */ new Date()).getFullYear();
  vistaMes = (/* @__PURE__ */ new Date()).getMonth();
  onChange = () => {
  };
  onTouched = () => {
  };
  constructor(elementRef) {
    this.elementRef = elementRef;
  }
  onDocClick(event) {
    if (this.abierto && !this.elementRef.nativeElement.contains(event.target)) {
      this.abierto = false;
    }
  }
  writeValue(val) {
    this.valor = val || "";
    const base = this.valor || this.max || this.hoyIso();
    const [ano, mes] = base.split("-").map(Number);
    this.vistaAno = ano;
    this.vistaMes = mes - 1;
  }
  registerOnChange(fn) {
    this.onChange = fn;
  }
  registerOnTouched(fn) {
    this.onTouched = fn;
  }
  setDisabledState(disabled) {
    this.disabled = disabled;
  }
  get textoMostrado() {
    if (!this.valor)
      return "";
    const [ano, mes, dia] = this.valor.split("-");
    return `${dia}/${mes}/${ano}`;
  }
  get anoMinimo() {
    return this.min ? Number(this.min.split("-")[0]) : (/* @__PURE__ */ new Date()).getFullYear() - 100;
  }
  get anoMaximo() {
    return this.max ? Number(this.max.split("-")[0]) : (/* @__PURE__ */ new Date()).getFullYear() + 1;
  }
  get listaAnos() {
    const anos = [];
    for (let a = this.anoMaximo; a >= this.anoMinimo; a--)
      anos.push(a);
    return anos;
  }
  alternar() {
    if (this.disabled)
      return;
    this.abierto = !this.abierto;
    if (this.abierto)
      this.onTouched();
  }
  cerrar() {
    this.abierto = false;
  }
  cambiarMesVista(delta) {
    let mes = Number(this.vistaMes) + delta;
    let ano = Number(this.vistaAno);
    if (mes < 0) {
      mes = 11;
      ano--;
    } else if (mes > 11) {
      mes = 0;
      ano++;
    }
    this.vistaMes = mes;
    this.vistaAno = ano;
  }
  seleccionarDia(celda) {
    if (celda.deshabilitado)
      return;
    this.valor = celda.iso;
    this.onChange(this.valor);
    this.cambio.emit(this.valor);
    this.abierto = false;
    const [ano, mes] = celda.iso.split("-").map(Number);
    this.vistaAno = ano;
    this.vistaMes = mes - 1;
  }
  irAHoy() {
    const hoy = this.hoyIso();
    if (this.max && hoy > this.max)
      return;
    if (this.min && hoy < this.min)
      return;
    const [ano, mes] = hoy.split("-").map(Number);
    this.vistaAno = ano;
    this.vistaMes = mes - 1;
    this.valor = hoy;
    this.onChange(this.valor);
    this.cambio.emit(this.valor);
    this.abierto = false;
  }
  limpiar() {
    this.valor = "";
    this.onChange("");
    this.cambio.emit("");
    this.abierto = false;
  }
  get semanas() {
    const vistaAno = Number(this.vistaAno);
    const vistaMes = Number(this.vistaMes);
    const primerDiaMes = new Date(vistaAno, vistaMes, 1);
    const diasEnMes = new Date(vistaAno, vistaMes + 1, 0).getDate();
    const diasEnMesAnterior = new Date(vistaAno, vistaMes, 0).getDate();
    const inicioSemana = primerDiaMes.getDay();
    const celdas = [];
    for (let i = inicioSemana - 1; i >= 0; i--) {
      const dia = diasEnMesAnterior - i;
      celdas.push(this.crearCelda(dia, vistaMes - 1, vistaAno, true));
    }
    for (let dia = 1; dia <= diasEnMes; dia++) {
      celdas.push(this.crearCelda(dia, vistaMes, vistaAno, false));
    }
    let siguiente = 1;
    while (celdas.length % 7 !== 0) {
      celdas.push(this.crearCelda(siguiente++, vistaMes + 1, vistaAno, true));
    }
    const semanas = [];
    for (let i = 0; i < celdas.length; i += 7) {
      semanas.push(celdas.slice(i, i + 7));
    }
    return semanas;
  }
  crearCelda(dia, mes, ano, fueraDeMes) {
    let m = Number(mes);
    let a = Number(ano);
    if (m < 0) {
      m = 11;
      a--;
    } else if (m > 11) {
      m = 0;
      a++;
    }
    const iso = `${a}-${String(m + 1).padStart(2, "0")}-${String(dia).padStart(2, "0")}`;
    return {
      dia,
      iso,
      fueraDeMes,
      deshabilitado: !!this.max && iso > this.max || !!this.min && iso < this.min,
      esHoy: iso === this.hoyIso(),
      esSeleccionado: iso === this.valor
    };
  }
  hoyIso() {
    return (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  }
  static \u0275fac = function Datepicker_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Datepicker)(\u0275\u0275directiveInject(ElementRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Datepicker, selectors: [["app-datepicker"]], hostBindings: function Datepicker_HostBindings(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275listener("click", function Datepicker_click_HostBindingHandler($event) {
        return ctx.onDocClick($event);
      }, \u0275\u0275resolveDocument);
    }
  }, inputs: { placeholder: "placeholder", max: "max", min: "min" }, outputs: { cambio: "cambio" }, features: [\u0275\u0275ProvidersFeature([
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => _Datepicker),
      multi: true
    }
  ])], decls: 7, vars: 5, consts: [[1, "datepicker"], ["type", "button", 1, "datepicker__disparador", 3, "click", "disabled"], [1, "datepicker__icono"], [1, "datepicker__panel"], [1, "datepicker__panel", 3, "click"], [1, "datepicker__cabecera"], ["type", "button", "aria-label", "Mes anterior", 1, "datepicker__nav", 3, "click"], ["aria-label", "Mes", 1, "datepicker__select", 3, "ngModelChange", "ngModel"], [3, "ngValue"], ["aria-label", "A\xF1o", 1, "datepicker__select", 3, "ngModelChange", "ngModel"], ["type", "button", "aria-label", "Mes siguiente", 1, "datepicker__nav", 3, "click"], [1, "datepicker__dias-semana"], [1, "datepicker__semana"], [1, "datepicker__pie"], ["type", "button", 1, "datepicker__accion", 3, "click"], ["type", "button", 1, "datepicker__dia", 3, "datepicker__dia--fuera", "datepicker__dia--hoy", "datepicker__dia--seleccionado", "disabled"], ["type", "button", 1, "datepicker__dia", 3, "click", "disabled"]], template: function Datepicker_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "button", 1);
      \u0275\u0275listener("click", function Datepicker_Template_button_click_1_listener() {
        return ctx.alternar();
      });
      \u0275\u0275elementStart(2, "span");
      \u0275\u0275text(3);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(4, "span", 2);
      \u0275\u0275text(5, "\u{1F4C5}");
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(6, Datepicker_Conditional_6_Template, 22, 2, "div", 3);
      \u0275\u0275elementEnd();
    }
    if (rf & 2) {
      \u0275\u0275advance();
      \u0275\u0275classProp("datepicker__disparador--vacio", !ctx.valor);
      \u0275\u0275property("disabled", ctx.disabled);
      \u0275\u0275advance(2);
      \u0275\u0275textInterpolate(ctx.textoMostrado || ctx.placeholder);
      \u0275\u0275advance(3);
      \u0275\u0275conditional(ctx.abierto ? 6 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, NgSelectOption, \u0275NgSelectMultipleOption, SelectControlValueAccessor, NgControlStatus, NgModel], styles: ["\n.datepicker[_ngcontent-%COMP%] {\n  position: relative;\n}\n.datepicker__disparador[_ngcontent-%COMP%] {\n  width: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 8px;\n  padding: 10px 12px;\n  border: 1px solid var(--borde);\n  border-radius: 6px;\n  background: #fff;\n  font-size: 0.95rem;\n  color: var(--texto);\n  cursor: pointer;\n  text-align: left;\n  transition: border-color 0.15s ease, box-shadow 0.15s ease;\n}\n.datepicker__disparador[_ngcontent-%COMP%]:hover {\n  border-color: var(--guinda-vivo);\n}\n.datepicker__disparador[_ngcontent-%COMP%]:focus-visible {\n  outline: none;\n  border-color: var(--guinda-vivo);\n  box-shadow: 0 0 0 3px var(--guinda-suave);\n}\n.datepicker__disparador--vacio[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]:first-child {\n  color: #999;\n}\n.datepicker__disparador[_ngcontent-%COMP%]:disabled {\n  background: var(--gris-fondo);\n  cursor: not-allowed;\n}\n.datepicker__icono[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n  opacity: 0.7;\n}\n.datepicker__panel[_ngcontent-%COMP%] {\n  position: absolute;\n  z-index: 200;\n  top: calc(100% + 6px);\n  left: 0;\n  min-width: 280px;\n  background: #fff;\n  border: 1px solid var(--borde);\n  border-radius: 10px;\n  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);\n  padding: 14px;\n  animation: _ngcontent-%COMP%_datepicker-entrada 0.15s ease both;\n}\n@media (max-width: 420px) {\n  .datepicker__panel[_ngcontent-%COMP%] {\n    position: fixed;\n    left: 16px;\n    right: 16px;\n    top: auto;\n    bottom: 16px;\n    min-width: 0;\n  }\n}\n@keyframes _ngcontent-%COMP%_datepicker-entrada {\n  from {\n    opacity: 0;\n    transform: translateY(-6px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n.datepicker__cabecera[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  margin-bottom: 10px;\n}\n.datepicker__nav[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n  width: 30px;\n  height: 30px;\n  border-radius: 50%;\n  border: none;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-size: 1.1rem;\n  line-height: 1;\n  cursor: pointer;\n  transition: background 0.15s ease;\n}\n.datepicker__nav[_ngcontent-%COMP%]:hover {\n  background: var(--guinda);\n  color: #fff;\n}\n.datepicker__select[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  padding: 6px 4px;\n  border: 1px solid var(--borde);\n  border-radius: 6px;\n  background: #fff;\n  font-size: 0.85rem;\n  color: var(--texto);\n  font-weight: 600;\n}\n.datepicker__dias-semana[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(7, 1fr);\n  text-align: center;\n  font-size: 0.72rem;\n  font-weight: 700;\n  color: var(--texto-suave);\n  margin-bottom: 4px;\n}\n.datepicker__semana[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(7, 1fr);\n}\n.datepicker__dia[_ngcontent-%COMP%] {\n  aspect-ratio: 1;\n  min-height: 34px;\n  border: none;\n  background: transparent;\n  border-radius: 50%;\n  font-size: 0.85rem;\n  color: var(--texto);\n  cursor: pointer;\n  transition:\n    background 0.15s ease,\n    color 0.15s ease,\n    transform 0.1s ease;\n}\n.datepicker__dia[_ngcontent-%COMP%]:hover:not(:disabled) {\n  background: var(--guinda-suave);\n}\n.datepicker__dia[_ngcontent-%COMP%]:active:not(:disabled) {\n  transform: scale(0.92);\n}\n.datepicker__dia--fuera[_ngcontent-%COMP%] {\n  color: #ccc;\n}\n.datepicker__dia--hoy[_ngcontent-%COMP%] {\n  font-weight: 700;\n  color: var(--guinda-vivo);\n  box-shadow: inset 0 0 0 1px var(--guinda-vivo);\n}\n.datepicker__dia--seleccionado[_ngcontent-%COMP%] {\n  background: var(--guinda) !important;\n  color: #fff !important;\n  font-weight: 700;\n}\n.datepicker__dia[_ngcontent-%COMP%]:disabled {\n  color: #ddd;\n  cursor: not-allowed;\n}\n.datepicker__pie[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  margin-top: 10px;\n  padding-top: 10px;\n  border-top: 1px solid var(--borde);\n}\n.datepicker__accion[_ngcontent-%COMP%] {\n  border: none;\n  background: none;\n  color: var(--guinda-vivo);\n  font-size: 0.8rem;\n  font-weight: 600;\n  cursor: pointer;\n  padding: 4px 8px;\n  border-radius: 4px;\n}\n.datepicker__accion[_ngcontent-%COMP%]:hover {\n  background: var(--guinda-suave);\n}\n/*# sourceMappingURL=datepicker.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Datepicker, [{
    type: Component,
    args: [{ selector: "app-datepicker", standalone: true, imports: [CommonModule, FormsModule], providers: [
      {
        provide: NG_VALUE_ACCESSOR,
        useExisting: forwardRef(() => Datepicker),
        multi: true
      }
    ], template: '<div class="datepicker">\n  <button\n    type="button"\n    class="datepicker__disparador"\n    [class.datepicker__disparador--vacio]="!valor"\n    [disabled]="disabled"\n    (click)="alternar()"\n  >\n    <span>{{ textoMostrado || placeholder }}</span>\n    <span class="datepicker__icono">\u{1F4C5}</span>\n  </button>\n\n  @if (abierto) {\n    <div class="datepicker__panel" (click)="$event.stopPropagation()">\n      <div class="datepicker__cabecera">\n        <button type="button" class="datepicker__nav" (click)="cambiarMesVista(-1)" aria-label="Mes anterior">\u2039</button>\n\n        <!-- ngValue, NO value: con [value] el <option> guarda el indice como TEXTO, y\n             entonces vistaMes + 1 concatena en vez de sumar ("2" + 1 = "21"), lo que producia\n             fechas invalidas como 2004-21-19. [ngValue] conserva el tipo numerico. -->\n        <select class="datepicker__select" [(ngModel)]="vistaMes" aria-label="Mes">\n          @for (nombre of nombresMes; track nombre; let i = $index) {\n            <option [ngValue]="i">{{ nombre }}</option>\n          }\n        </select>\n        <select class="datepicker__select" [(ngModel)]="vistaAno" aria-label="A\xF1o">\n          @for (ano of listaAnos; track ano) {\n            <option [ngValue]="ano">{{ ano }}</option>\n          }\n        </select>\n\n        <button type="button" class="datepicker__nav" (click)="cambiarMesVista(1)" aria-label="Mes siguiente">\u203A</button>\n      </div>\n\n      <div class="datepicker__dias-semana">\n        @for (d of nombresDia; track $index) {\n          <span>{{ d }}</span>\n        }\n      </div>\n\n      @for (semana of semanas; track $index) {\n        <div class="datepicker__semana">\n          @for (celda of semana; track celda.iso) {\n            <button\n              type="button"\n              class="datepicker__dia"\n              [class.datepicker__dia--fuera]="celda.fueraDeMes"\n              [class.datepicker__dia--hoy]="celda.esHoy"\n              [class.datepicker__dia--seleccionado]="celda.esSeleccionado"\n              [disabled]="celda.deshabilitado"\n              (click)="seleccionarDia(celda)"\n            >\n              {{ celda.dia }}\n            </button>\n          }\n        </div>\n      }\n\n      <div class="datepicker__pie">\n        <button type="button" class="datepicker__accion" (click)="irAHoy()">Hoy</button>\n        <button type="button" class="datepicker__accion" (click)="limpiar()">Limpiar</button>\n      </div>\n    </div>\n  }\n</div>\n', styles: ["/* src/app/shared/datepicker/datepicker.scss */\n.datepicker {\n  position: relative;\n}\n.datepicker__disparador {\n  width: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 8px;\n  padding: 10px 12px;\n  border: 1px solid var(--borde);\n  border-radius: 6px;\n  background: #fff;\n  font-size: 0.95rem;\n  color: var(--texto);\n  cursor: pointer;\n  text-align: left;\n  transition: border-color 0.15s ease, box-shadow 0.15s ease;\n}\n.datepicker__disparador:hover {\n  border-color: var(--guinda-vivo);\n}\n.datepicker__disparador:focus-visible {\n  outline: none;\n  border-color: var(--guinda-vivo);\n  box-shadow: 0 0 0 3px var(--guinda-suave);\n}\n.datepicker__disparador--vacio span:first-child {\n  color: #999;\n}\n.datepicker__disparador:disabled {\n  background: var(--gris-fondo);\n  cursor: not-allowed;\n}\n.datepicker__icono {\n  flex-shrink: 0;\n  opacity: 0.7;\n}\n.datepicker__panel {\n  position: absolute;\n  z-index: 200;\n  top: calc(100% + 6px);\n  left: 0;\n  min-width: 280px;\n  background: #fff;\n  border: 1px solid var(--borde);\n  border-radius: 10px;\n  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);\n  padding: 14px;\n  animation: datepicker-entrada 0.15s ease both;\n}\n@media (max-width: 420px) {\n  .datepicker__panel {\n    position: fixed;\n    left: 16px;\n    right: 16px;\n    top: auto;\n    bottom: 16px;\n    min-width: 0;\n  }\n}\n@keyframes datepicker-entrada {\n  from {\n    opacity: 0;\n    transform: translateY(-6px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n.datepicker__cabecera {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  margin-bottom: 10px;\n}\n.datepicker__nav {\n  flex-shrink: 0;\n  width: 30px;\n  height: 30px;\n  border-radius: 50%;\n  border: none;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-size: 1.1rem;\n  line-height: 1;\n  cursor: pointer;\n  transition: background 0.15s ease;\n}\n.datepicker__nav:hover {\n  background: var(--guinda);\n  color: #fff;\n}\n.datepicker__select {\n  flex: 1;\n  min-width: 0;\n  padding: 6px 4px;\n  border: 1px solid var(--borde);\n  border-radius: 6px;\n  background: #fff;\n  font-size: 0.85rem;\n  color: var(--texto);\n  font-weight: 600;\n}\n.datepicker__dias-semana {\n  display: grid;\n  grid-template-columns: repeat(7, 1fr);\n  text-align: center;\n  font-size: 0.72rem;\n  font-weight: 700;\n  color: var(--texto-suave);\n  margin-bottom: 4px;\n}\n.datepicker__semana {\n  display: grid;\n  grid-template-columns: repeat(7, 1fr);\n}\n.datepicker__dia {\n  aspect-ratio: 1;\n  min-height: 34px;\n  border: none;\n  background: transparent;\n  border-radius: 50%;\n  font-size: 0.85rem;\n  color: var(--texto);\n  cursor: pointer;\n  transition:\n    background 0.15s ease,\n    color 0.15s ease,\n    transform 0.1s ease;\n}\n.datepicker__dia:hover:not(:disabled) {\n  background: var(--guinda-suave);\n}\n.datepicker__dia:active:not(:disabled) {\n  transform: scale(0.92);\n}\n.datepicker__dia--fuera {\n  color: #ccc;\n}\n.datepicker__dia--hoy {\n  font-weight: 700;\n  color: var(--guinda-vivo);\n  box-shadow: inset 0 0 0 1px var(--guinda-vivo);\n}\n.datepicker__dia--seleccionado {\n  background: var(--guinda) !important;\n  color: #fff !important;\n  font-weight: 700;\n}\n.datepicker__dia:disabled {\n  color: #ddd;\n  cursor: not-allowed;\n}\n.datepicker__pie {\n  display: flex;\n  justify-content: space-between;\n  margin-top: 10px;\n  padding-top: 10px;\n  border-top: 1px solid var(--borde);\n}\n.datepicker__accion {\n  border: none;\n  background: none;\n  color: var(--guinda-vivo);\n  font-size: 0.8rem;\n  font-weight: 600;\n  cursor: pointer;\n  padding: 4px 8px;\n  border-radius: 4px;\n}\n.datepicker__accion:hover {\n  background: var(--guinda-suave);\n}\n/*# sourceMappingURL=datepicker.css.map */\n"] }]
  }], () => [{ type: ElementRef }], { placeholder: [{
    type: Input
  }], max: [{
    type: Input
  }], min: [{
    type: Input
  }], cambio: [{
    type: Output
  }], onDocClick: [{
    type: HostListener,
    args: ["document:click", ["$event"]]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Datepicker, { className: "Datepicker", filePath: "src/app/shared/datepicker/datepicker.ts", lineNumber: 46 });
})();

// src/app/core/validaciones/reglas-queja.ts
var PATRON_NOMBRE = "[A-Za-z\xC1\xC9\xCD\xD3\xDA\xDC\xD1\xE1\xE9\xED\xF3\xFA\xFC\xF1]+([ '\\-][A-Za-z\xC1\xC9\xCD\xD3\xDA\xDC\xD1\xE1\xE9\xED\xF3\xFA\xFC\xF1]+)*";
var REGEX_NOMBRE = new RegExp(`^${PATRON_NOMBRE}$`);
var NOMBRE_LONGITUD_MINIMA = 2;
var NOMBRE_LONGITUD_MAXIMA = 50;
var REGEX_NUMERO_IDENTIFICACION = /^[0-9]{1,10}$/;
var NUMERO_IDENTIFICACION_LONGITUD_MAXIMA = 10;
var FECHA_NACIMIENTO_MINIMA = "1920-01-01";
function fechaNacimientoMaxima() {
  return `${(/* @__PURE__ */ new Date()).getFullYear() - 1}-12-31`;
}
function hoyIso() {
  return (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
}
function esFechaValida(iso) {
  if (!iso || !/^\d{4}-\d{2}-\d{2}$/.test(iso)) {
    return false;
  }
  const [anio, mes, dia] = iso.split("-").map(Number);
  const fecha = new Date(anio, mes - 1, dia);
  return fecha.getFullYear() === anio && fecha.getMonth() === mes - 1 && fecha.getDate() === dia;
}
var DESCRIPCION_LONGITUD_MINIMA = 20;
var IDENTIFICACION_TIPOS_MIME = ["image/jpeg", "image/png"];
var IDENTIFICACION_EXTENSIONES = [".jpg", ".jpeg", ".png"];
var IDENTIFICACION_TAMANIO_MAXIMO = 3 * 1024 * 1024;
var IDENTIFICACION_CANTIDAD_MAXIMA = 2;
var PREFIJO_IDENTIFICACION = "IDENTIFICACION_";
var EVIDENCIA_EXTENSIONES = [".pdf", ".jpg", ".jpeg", ".png", ".mp4", ".mp3"];
var EVIDENCIA_TAMANIO_MAXIMO = 30 * 1024 * 1024;
var EVIDENCIA_TAMANIO_TOTAL_MAXIMO = 95 * 1024 * 1024;
var AVISO_PRIVACIDAD_VERSION = "1.0";
var CORREO_FORMATO_GENERAL = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)*\.[A-Za-z]{2,}$/;
var CORREO_LOCAL_GOOGLE = /^[A-Za-z0-9.]{6,30}$/;
var DOMINIOS_GOOGLE = ["gmail.com", "googlemail.com"];
var CORREO_LONGITUD_MAXIMA = 254;
function validarCorreo(valor) {
  const correo = (valor ?? "").trim().toLowerCase();
  if (!correo) {
    return "Escribe tu correo electr\xF3nico.";
  }
  if (correo.length > CORREO_LONGITUD_MAXIMA) {
    return "El correo electr\xF3nico es demasiado largo.";
  }
  if (!CORREO_FORMATO_GENERAL.test(correo)) {
    return "El correo no tiene un formato v\xE1lido. Ejemplo: nombre@dominio.com";
  }
  const arroba = correo.lastIndexOf("@");
  const parteLocal = correo.slice(0, arroba);
  const dominio = correo.slice(arroba + 1);
  if (parteLocal.startsWith(".") || parteLocal.endsWith(".")) {
    return "El correo no puede empezar ni terminar con un punto antes de la arroba.";
  }
  if (parteLocal.includes("..")) {
    return "El correo no puede tener dos puntos seguidos.";
  }
  if (DOMINIOS_GOOGLE.includes(dominio) && !CORREO_LOCAL_GOOGLE.test(parteLocal)) {
    return "Una direcci\xF3n de Gmail solo admite letras, n\xFAmeros y puntos antes de la arroba, con un m\xEDnimo de 6 y un m\xE1ximo de 30 caracteres.";
  }
  return null;
}
function validarNombre(valor, etiqueta, obligatorio) {
  const texto = (valor ?? "").trim().replace(/\s+/g, " ");
  if (!texto) {
    return obligatorio ? `Escribe ${etiqueta}.` : null;
  }
  if (texto.length < NOMBRE_LONGITUD_MINIMA) {
    return `${capitalizar(etiqueta)} debe tener al menos ${NOMBRE_LONGITUD_MINIMA} letras.`;
  }
  if (texto.length > NOMBRE_LONGITUD_MAXIMA) {
    return `${capitalizar(etiqueta)} no puede exceder ${NOMBRE_LONGITUD_MAXIMA} caracteres.`;
  }
  if (!REGEX_NOMBRE.test(texto)) {
    return `${capitalizar(etiqueta)} solo admite letras (se aceptan acentos, \xF1, guion y ap\xF3strofe), sin n\xFAmeros ni otros s\xEDmbolos.`;
  }
  return null;
}
function capitalizar(texto) {
  return texto.charAt(0).toUpperCase() + texto.slice(1);
}
function formatearTamanio(bytes) {
  if (bytes < 1024)
    return `${bytes} B`;
  if (bytes < 1024 * 1024)
    return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// src/app/shared/aviso-privacidad/aviso-privacidad.ts
var _c0 = ["cuerpoAviso"];
function AvisoPrivacidad_Conditional_66_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275domElementStart(0, "button", 18);
    \u0275\u0275domListener("click", function AvisoPrivacidad_Conditional_66_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.irAlFinal());
    });
    \u0275\u0275text(1, " Desliza hasta el final para continuar \u2193 ");
    \u0275\u0275domElementEnd();
  }
}
var AvisoPrivacidad = class _AvisoPrivacidad {
  router;
  cdr;
  /** Se emite con la versión aceptada cuando el usuario marca la casilla. */
  aceptado = new EventEmitter();
  cuerpoAviso;
  /** Se habilita cuando el texto se leyó hasta abajo. */
  llegoAlFinal = false;
  aceptaCasilla = false;
  version = AVISO_PRIVACIDAD_VERSION;
  /** Margen en píxeles para dar por leído el texto sin exigir el píxel exacto. */
  MARGEN_FINAL = 12;
  constructor(router, cdr) {
    this.router = router;
    this.cdr = cdr;
  }
  ngAfterViewInit() {
    setTimeout(() => {
      const elemento = this.cuerpoAviso?.nativeElement;
      if (elemento && elemento.scrollHeight <= elemento.clientHeight + this.MARGEN_FINAL) {
        this.llegoAlFinal = true;
        this.cdr.detectChanges();
      }
    });
  }
  onScroll(event) {
    const elemento = event.target;
    const alFinal = elemento.scrollTop + elemento.clientHeight >= elemento.scrollHeight - this.MARGEN_FINAL;
    if (alFinal && !this.llegoAlFinal) {
      this.llegoAlFinal = true;
      this.cdr.detectChanges();
    }
  }
  /** Marcar la casilla cierra el modal, que es justo lo que se pidió. */
  onAceptar(marcada) {
    this.aceptaCasilla = marcada;
    if (marcada) {
      this.aceptado.emit(this.version);
    }
  }
  /** El consentimiento tiene que poder negarse: se sale del formulario. */
  onNoAceptar() {
    this.router.navigate(["/inicio"]);
  }
  irAlFinal() {
    const elemento = this.cuerpoAviso?.nativeElement;
    elemento?.scrollTo({ top: elemento.scrollHeight, behavior: "smooth" });
  }
  static \u0275fac = function AvisoPrivacidad_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _AvisoPrivacidad)(\u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AvisoPrivacidad, selectors: [["app-aviso-privacidad"]], viewQuery: function AvisoPrivacidad_Query(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275viewQuery(_c0, 5);
    }
    if (rf & 2) {
      let _t;
      \u0275\u0275queryRefresh(_t = \u0275\u0275loadQuery()) && (ctx.cuerpoAviso = _t.first);
    }
  }, outputs: { aceptado: "aceptado" }, decls: 74, vars: 6, consts: [["cuerpoAviso", ""], ["role", "dialog", "aria-modal", "true", "aria-labelledby", "aviso-titulo", 1, "aviso-overlay"], [1, "aviso", "card"], [1, "aviso__encabezado"], ["aria-hidden", "true", 1, "aviso__icono"], ["viewBox", "0 0 24 24", "fill", "none", "stroke-width", "1.6", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M12 3l7 3v5c0 4.4-2.9 8.3-7 9.5C7.9 19.3 5 15.4 5 11V6l7-3z"], ["d", "M12 9v4"], ["d", "M12 16h.01"], ["id", "aviso-titulo"], [1, "aviso__subtitulo"], ["tabindex", "0", 1, "aviso__cuerpo", 3, "scroll"], [1, "aviso__fin"], ["type", "button", 1, "aviso__ir-al-final"], [1, "aviso__acciones"], [1, "aviso__casilla"], ["type", "checkbox", 3, "change", "disabled", "checked"], ["type", "button", 1, "aviso__rechazar", 3, "click"], ["type", "button", 1, "aviso__ir-al-final", 3, "click"]], template: function AvisoPrivacidad_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275domElementStart(0, "div", 1)(1, "div", 2)(2, "div", 3)(3, "span", 4);
      \u0275\u0275namespaceSVG();
      \u0275\u0275domElementStart(4, "svg", 5);
      \u0275\u0275domElement(5, "path", 6)(6, "path", 7)(7, "path", 8);
      \u0275\u0275domElementEnd()();
      \u0275\u0275namespaceHTML();
      \u0275\u0275domElementStart(8, "div")(9, "h2", 9);
      \u0275\u0275text(10, "Aviso de Privacidad");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(11, "p", 10);
      \u0275\u0275text(12, " L\xE9elo completo para poder continuar con el registro de tu queja. ");
      \u0275\u0275domElementEnd()()();
      \u0275\u0275domElementStart(13, "div", 11, 0);
      \u0275\u0275domListener("scroll", function AvisoPrivacidad_Template_div_scroll_13_listener($event) {
        return ctx.onScroll($event);
      });
      \u0275\u0275domElementStart(15, "h3");
      \u0275\u0275text(16, "1. Responsable del tratamiento");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(17, "p");
      \u0275\u0275text(18, " La Defensor\xEDa de los Derechos Polit\xE9cnicos (DDP) del Instituto Polit\xE9cnico Nacional es la responsable del tratamiento de los datos personales que proporciones a trav\xE9s de este formulario. ");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(19, "h3");
      \u0275\u0275text(20, "2. Datos que se recaban");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(21, "p");
      \u0275\u0275text(22, "Para atender tu queja se recaban los siguientes datos:");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(23, "ul")(24, "li");
      \u0275\u0275text(25, "De identificaci\xF3n: nombre, apellidos, fecha de nacimiento, n\xFAmero de boleta o de empleado e imagen de tu credencial de la comunidad polit\xE9cnica.");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(26, "li");
      \u0275\u0275text(27, "De contacto: correo electr\xF3nico.");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(28, "li");
      \u0275\u0275text(29, "De la queja: lugar y fecha de los hechos, descripci\xF3n, as\xED como los datos de la persona se\xF1alada y los archivos que adjuntes como evidencia.");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(30, "li");
      \u0275\u0275text(31, "De tu padre, madre o tutor, \xFAnicamente cuando eres menor de edad.");
      \u0275\u0275domElementEnd()();
      \u0275\u0275domElementStart(32, "h3");
      \u0275\u0275text(33, "3. Finalidad");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(34, "p");
      \u0275\u0275text(35, " Tus datos se utilizan exclusivamente para registrar, dar tr\xE1mite y seguimiento a tu queja; para comunicarte el folio y el estado de tu asunto; y para elaborar estad\xEDsticas internas, en cuyo caso la informaci\xF3n se maneja de forma agregada y sin identificarte. ");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(36, "p");
      \u0275\u0275text(37, " No se utilizan con fines de publicidad ni se comercializan, y no se transfieren a terceros salvo cuando la propia atenci\xF3n del asunto lo exija o cuando exista un requerimiento de una autoridad competente. ");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(38, "h3");
      \u0275\u0275text(39, "4. Datos de la persona se\xF1alada");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(40, "p");
      \u0275\u0275text(41, " Al capturar el nombre de la persona que se\xF1alas en tu queja est\xE1s proporcionando datos de un tercero. Esa informaci\xF3n se trata con la misma confidencialidad y se usa \xFAnicamente para el tr\xE1mite del asunto. ");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(42, "h3");
      \u0275\u0275text(43, "5. Confidencialidad y resguardo");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(44, "p");
      \u0275\u0275text(45, " La informaci\xF3n se almacena en los sistemas institucionales y solo la consulta el personal autorizado de la Defensor\xEDa que interviene en la atenci\xF3n de tu queja. Se aplican medidas de seguridad administrativas, t\xE9cnicas y f\xEDsicas para evitar su p\xE9rdida, uso indebido o acceso no autorizado. ");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(46, "h3");
      \u0275\u0275text(47, "6. Derechos ARCO");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(48, "p");
      \u0275\u0275text(49, " Puedes solicitar el acceso, rectificaci\xF3n, cancelaci\xF3n u oposici\xF3n al tratamiento de tus datos personales, as\xED como revocar el consentimiento que otorgas con este aviso. Para ello acude a la Defensor\xEDa o utiliza la secci\xF3n ");
      \u0275\u0275domElementStart(50, "strong");
      \u0275\u0275text(51, "Contacto");
      \u0275\u0275domElementEnd();
      \u0275\u0275text(52, " de este portal, indicando tu nombre y el folio de tu queja. ");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(53, "h3");
      \u0275\u0275text(54, "7. Conservaci\xF3n");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(55, "p");
      \u0275\u0275text(56, " Tus datos se conservan durante el tiempo necesario para la atenci\xF3n del asunto y por el plazo que establezcan las disposiciones institucionales de archivo aplicables. ");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(57, "h3");
      \u0275\u0275text(58, "8. Cambios al aviso");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(59, "p");
      \u0275\u0275text(60, " Este aviso puede actualizarse. La versi\xF3n vigente es la ");
      \u0275\u0275domElementStart(61, "strong");
      \u0275\u0275text(62);
      \u0275\u0275domElementEnd();
      \u0275\u0275text(63, " y siempre estar\xE1 disponible en este portal. Queda registrada la versi\xF3n que aceptaste al momento de presentar tu queja. ");
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(64, "p", 12);
      \u0275\u0275text(65, "\u2014 Fin del aviso \u2014");
      \u0275\u0275domElementEnd()();
      \u0275\u0275conditionalCreate(66, AvisoPrivacidad_Conditional_66_Template, 2, 0, "button", 13);
      \u0275\u0275domElementStart(67, "div", 14)(68, "label", 15)(69, "input", 16);
      \u0275\u0275domListener("change", function AvisoPrivacidad_Template_input_change_69_listener($event) {
        return ctx.onAceptar($event.target.checked);
      });
      \u0275\u0275domElementEnd();
      \u0275\u0275domElementStart(70, "span");
      \u0275\u0275text(71, "He le\xEDdo y acepto el Aviso de Privacidad");
      \u0275\u0275domElementEnd()();
      \u0275\u0275domElementStart(72, "button", 17);
      \u0275\u0275domListener("click", function AvisoPrivacidad_Template_button_click_72_listener() {
        return ctx.onNoAceptar();
      });
      \u0275\u0275text(73, " No acepto ");
      \u0275\u0275domElementEnd()()()();
    }
    if (rf & 2) {
      \u0275\u0275advance(62);
      \u0275\u0275textInterpolate(ctx.version);
      \u0275\u0275advance(4);
      \u0275\u0275conditional(!ctx.llegoAlFinal ? 66 : -1);
      \u0275\u0275advance(2);
      \u0275\u0275classProp("aviso__casilla--bloqueada", !ctx.llegoAlFinal);
      \u0275\u0275advance();
      \u0275\u0275domProperty("disabled", !ctx.llegoAlFinal)("checked", ctx.aceptaCasilla);
    }
  }, dependencies: [CommonModule], styles: ["\n.aviso-overlay[_ngcontent-%COMP%] {\n  position: fixed;\n  inset: 0;\n  z-index: 1200;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 20px;\n  background: rgba(20, 8, 14, 0.62);\n  -webkit-backdrop-filter: blur(2px);\n  backdrop-filter: blur(2px);\n}\n.aviso[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  width: min(720px, 100%);\n  max-height: min(86vh, 760px);\n  padding: 0;\n  overflow: hidden;\n  background: #fff;\n  border-radius: 14px;\n  box-shadow: 0 18px 48px rgba(0, 0, 0, 0.3);\n}\n.aviso__encabezado[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 14px;\n  align-items: flex-start;\n  padding: 22px 26px 16px;\n  border-bottom: 3px solid #6c1d45;\n}\n.aviso__encabezado[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 1.15rem;\n  color: #6c1d45;\n}\n.aviso__subtitulo[_ngcontent-%COMP%] {\n  margin: 4px 0 0;\n  font-size: 0.84rem;\n  color: #666;\n}\n.aviso__icono[_ngcontent-%COMP%] {\n  display: flex;\n  flex-shrink: 0;\n  align-items: center;\n  justify-content: center;\n  width: 42px;\n  height: 42px;\n  color: #fff;\n  background: #6c1d45;\n  border-radius: 50%;\n}\n.aviso__icono[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 22px;\n  height: 22px;\n  stroke: currentColor;\n}\n.aviso__cuerpo[_ngcontent-%COMP%] {\n  flex: 1;\n  min-height: 0;\n  padding: 18px 26px;\n  overflow-y: auto;\n  font-size: 0.88rem;\n  line-height: 1.65;\n  color: #333;\n  scroll-behavior: smooth;\n}\n.aviso__cuerpo[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 18px 0 6px;\n  font-size: 0.82rem;\n  color: #9d2449;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n}\n.aviso__cuerpo[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]:first-child {\n  margin-top: 0;\n}\n.aviso__cuerpo[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0 0 10px;\n}\n.aviso__cuerpo[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  margin: 0 0 10px;\n  padding-left: 20px;\n}\n.aviso__cuerpo[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin-bottom: 5px;\n}\n.aviso__fin[_ngcontent-%COMP%] {\n  padding-top: 12px;\n  margin-top: 18px;\n  font-size: 0.8rem;\n  color: #999;\n  text-align: center;\n  border-top: 1px dashed #ddd;\n}\n.aviso__ir-al-final[_ngcontent-%COMP%] {\n  padding: 8px;\n  font-size: 0.8rem;\n  color: #6c1d45;\n  cursor: pointer;\n  background: #f7eef1;\n  border: 0;\n  border-top: 1px solid #ecd9e1;\n}\n.aviso__acciones[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 12px;\n  align-items: center;\n  justify-content: space-between;\n  padding: 16px 26px 20px;\n  background: #fafafa;\n  border-top: 1px solid #eee;\n}\n.aviso__casilla[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  align-items: center;\n  font-size: 0.9rem;\n  font-weight: 600;\n  color: #1a1a1a;\n  cursor: pointer;\n}\n.aviso__casilla[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  accent-color: #6c1d45;\n  cursor: pointer;\n}\n.aviso__casilla--bloqueada[_ngcontent-%COMP%] {\n  color: #999;\n  cursor: not-allowed;\n}\n.aviso__casilla--bloqueada[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  cursor: not-allowed;\n}\n.aviso__rechazar[_ngcontent-%COMP%] {\n  padding: 8px 16px;\n  font-size: 0.85rem;\n  color: #666;\n  cursor: pointer;\n  background: transparent;\n  border: 1px solid #ccc;\n  border-radius: 8px;\n}\n.aviso__rechazar[_ngcontent-%COMP%]:hover {\n  color: #9d2449;\n  border-color: #9d2449;\n}\n@media (max-width: 560px) {\n  .aviso__acciones[_ngcontent-%COMP%] {\n    flex-direction: column-reverse;\n    align-items: stretch;\n  }\n  .aviso__rechazar[_ngcontent-%COMP%] {\n    width: 100%;\n  }\n}\n/*# sourceMappingURL=aviso-privacidad.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AvisoPrivacidad, [{
    type: Component,
    args: [{ selector: "app-aviso-privacidad", standalone: true, imports: [CommonModule], template: '<div class="aviso-overlay" role="dialog" aria-modal="true" aria-labelledby="aviso-titulo">\n  <div class="aviso card">\n    <div class="aviso__encabezado">\n      <span class="aviso__icono" aria-hidden="true">\n        <svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">\n          <path d="M12 3l7 3v5c0 4.4-2.9 8.3-7 9.5C7.9 19.3 5 15.4 5 11V6l7-3z" />\n          <path d="M12 9v4" />\n          <path d="M12 16h.01" />\n        </svg>\n      </span>\n      <div>\n        <h2 id="aviso-titulo">Aviso de Privacidad</h2>\n        <p class="aviso__subtitulo">\n          L\xE9elo completo para poder continuar con el registro de tu queja.\n        </p>\n      </div>\n    </div>\n\n    <div class="aviso__cuerpo" #cuerpoAviso (scroll)="onScroll($event)" tabindex="0">\n      <h3>1. Responsable del tratamiento</h3>\n      <p>\n        La Defensor\xEDa de los Derechos Polit\xE9cnicos (DDP) del Instituto Polit\xE9cnico Nacional es\n        la responsable del tratamiento de los datos personales que proporciones a trav\xE9s de\n        este formulario.\n      </p>\n\n      <h3>2. Datos que se recaban</h3>\n      <p>Para atender tu queja se recaban los siguientes datos:</p>\n      <ul>\n        <li>De identificaci\xF3n: nombre, apellidos, fecha de nacimiento, n\xFAmero de boleta o de empleado e imagen de tu credencial de la comunidad polit\xE9cnica.</li>\n        <li>De contacto: correo electr\xF3nico.</li>\n        <li>De la queja: lugar y fecha de los hechos, descripci\xF3n, as\xED como los datos de la persona se\xF1alada y los archivos que adjuntes como evidencia.</li>\n        <li>De tu padre, madre o tutor, \xFAnicamente cuando eres menor de edad.</li>\n      </ul>\n\n      <h3>3. Finalidad</h3>\n      <p>\n        Tus datos se utilizan exclusivamente para registrar, dar tr\xE1mite y seguimiento a tu\n        queja; para comunicarte el folio y el estado de tu asunto; y para elaborar\n        estad\xEDsticas internas, en cuyo caso la informaci\xF3n se maneja de forma agregada y sin\n        identificarte.\n      </p>\n      <p>\n        No se utilizan con fines de publicidad ni se comercializan, y no se transfieren a\n        terceros salvo cuando la propia atenci\xF3n del asunto lo exija o cuando exista un\n        requerimiento de una autoridad competente.\n      </p>\n\n      <h3>4. Datos de la persona se\xF1alada</h3>\n      <p>\n        Al capturar el nombre de la persona que se\xF1alas en tu queja est\xE1s proporcionando datos\n        de un tercero. Esa informaci\xF3n se trata con la misma confidencialidad y se usa\n        \xFAnicamente para el tr\xE1mite del asunto.\n      </p>\n\n      <h3>5. Confidencialidad y resguardo</h3>\n      <p>\n        La informaci\xF3n se almacena en los sistemas institucionales y solo la consulta el\n        personal autorizado de la Defensor\xEDa que interviene en la atenci\xF3n de tu queja. Se\n        aplican medidas de seguridad administrativas, t\xE9cnicas y f\xEDsicas para evitar su\n        p\xE9rdida, uso indebido o acceso no autorizado.\n      </p>\n\n      <h3>6. Derechos ARCO</h3>\n      <p>\n        Puedes solicitar el acceso, rectificaci\xF3n, cancelaci\xF3n u oposici\xF3n al tratamiento de\n        tus datos personales, as\xED como revocar el consentimiento que otorgas con este aviso.\n        Para ello acude a la Defensor\xEDa o utiliza la secci\xF3n <strong>Contacto</strong> de este\n        portal, indicando tu nombre y el folio de tu queja.\n      </p>\n\n      <h3>7. Conservaci\xF3n</h3>\n      <p>\n        Tus datos se conservan durante el tiempo necesario para la atenci\xF3n del asunto y por\n        el plazo que establezcan las disposiciones institucionales de archivo aplicables.\n      </p>\n\n      <h3>8. Cambios al aviso</h3>\n      <p>\n        Este aviso puede actualizarse. La versi\xF3n vigente es la <strong>{{ version }}</strong> y\n        siempre estar\xE1 disponible en este portal. Queda registrada la versi\xF3n que aceptaste al\n        momento de presentar tu queja.\n      </p>\n\n      <p class="aviso__fin">\u2014 Fin del aviso \u2014</p>\n    </div>\n\n    @if (!llegoAlFinal) {\n      <button type="button" class="aviso__ir-al-final" (click)="irAlFinal()">\n        Desliza hasta el final para continuar \u2193\n      </button>\n    }\n\n    <div class="aviso__acciones">\n      <label class="aviso__casilla" [class.aviso__casilla--bloqueada]="!llegoAlFinal">\n        <input\n          type="checkbox"\n          [disabled]="!llegoAlFinal"\n          [checked]="aceptaCasilla"\n          (change)="onAceptar($any($event.target).checked)"\n        />\n        <span>He le\xEDdo y acepto el Aviso de Privacidad</span>\n      </label>\n\n      <button type="button" class="aviso__rechazar" (click)="onNoAceptar()">\n        No acepto\n      </button>\n    </div>\n  </div>\n</div>\n', styles: ["/* src/app/shared/aviso-privacidad/aviso-privacidad.scss */\n.aviso-overlay {\n  position: fixed;\n  inset: 0;\n  z-index: 1200;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 20px;\n  background: rgba(20, 8, 14, 0.62);\n  -webkit-backdrop-filter: blur(2px);\n  backdrop-filter: blur(2px);\n}\n.aviso {\n  display: flex;\n  flex-direction: column;\n  width: min(720px, 100%);\n  max-height: min(86vh, 760px);\n  padding: 0;\n  overflow: hidden;\n  background: #fff;\n  border-radius: 14px;\n  box-shadow: 0 18px 48px rgba(0, 0, 0, 0.3);\n}\n.aviso__encabezado {\n  display: flex;\n  gap: 14px;\n  align-items: flex-start;\n  padding: 22px 26px 16px;\n  border-bottom: 3px solid #6c1d45;\n}\n.aviso__encabezado h2 {\n  margin: 0;\n  font-size: 1.15rem;\n  color: #6c1d45;\n}\n.aviso__subtitulo {\n  margin: 4px 0 0;\n  font-size: 0.84rem;\n  color: #666;\n}\n.aviso__icono {\n  display: flex;\n  flex-shrink: 0;\n  align-items: center;\n  justify-content: center;\n  width: 42px;\n  height: 42px;\n  color: #fff;\n  background: #6c1d45;\n  border-radius: 50%;\n}\n.aviso__icono svg {\n  width: 22px;\n  height: 22px;\n  stroke: currentColor;\n}\n.aviso__cuerpo {\n  flex: 1;\n  min-height: 0;\n  padding: 18px 26px;\n  overflow-y: auto;\n  font-size: 0.88rem;\n  line-height: 1.65;\n  color: #333;\n  scroll-behavior: smooth;\n}\n.aviso__cuerpo h3 {\n  margin: 18px 0 6px;\n  font-size: 0.82rem;\n  color: #9d2449;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n}\n.aviso__cuerpo h3:first-child {\n  margin-top: 0;\n}\n.aviso__cuerpo p {\n  margin: 0 0 10px;\n}\n.aviso__cuerpo ul {\n  margin: 0 0 10px;\n  padding-left: 20px;\n}\n.aviso__cuerpo ul li {\n  margin-bottom: 5px;\n}\n.aviso__fin {\n  padding-top: 12px;\n  margin-top: 18px;\n  font-size: 0.8rem;\n  color: #999;\n  text-align: center;\n  border-top: 1px dashed #ddd;\n}\n.aviso__ir-al-final {\n  padding: 8px;\n  font-size: 0.8rem;\n  color: #6c1d45;\n  cursor: pointer;\n  background: #f7eef1;\n  border: 0;\n  border-top: 1px solid #ecd9e1;\n}\n.aviso__acciones {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 12px;\n  align-items: center;\n  justify-content: space-between;\n  padding: 16px 26px 20px;\n  background: #fafafa;\n  border-top: 1px solid #eee;\n}\n.aviso__casilla {\n  display: flex;\n  gap: 10px;\n  align-items: center;\n  font-size: 0.9rem;\n  font-weight: 600;\n  color: #1a1a1a;\n  cursor: pointer;\n}\n.aviso__casilla input {\n  width: 18px;\n  height: 18px;\n  accent-color: #6c1d45;\n  cursor: pointer;\n}\n.aviso__casilla--bloqueada {\n  color: #999;\n  cursor: not-allowed;\n}\n.aviso__casilla--bloqueada input {\n  cursor: not-allowed;\n}\n.aviso__rechazar {\n  padding: 8px 16px;\n  font-size: 0.85rem;\n  color: #666;\n  cursor: pointer;\n  background: transparent;\n  border: 1px solid #ccc;\n  border-radius: 8px;\n}\n.aviso__rechazar:hover {\n  color: #9d2449;\n  border-color: #9d2449;\n}\n@media (max-width: 560px) {\n  .aviso__acciones {\n    flex-direction: column-reverse;\n    align-items: stretch;\n  }\n  .aviso__rechazar {\n    width: 100%;\n  }\n}\n/*# sourceMappingURL=aviso-privacidad.css.map */\n"] }]
  }], () => [{ type: Router }, { type: ChangeDetectorRef }], { aceptado: [{
    type: Output
  }], cuerpoAviso: [{
    type: ViewChild,
    args: ["cuerpoAviso"]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AvisoPrivacidad, { className: "AvisoPrivacidad", filePath: "src/app/shared/aviso-privacidad/aviso-privacidad.ts", lineNumber: 35 });
})();

// src/app/shared/autocompletar-dependencia/autocompletar-dependencia.ts
var _forTrack02 = ($index, $item) => $item.dep.clave;
function AutocompletarDependencia_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275domElementStart(0, "button", 10);
    \u0275\u0275domListener("click", function AutocompletarDependencia_Conditional_7_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.limpiar());
    });
    \u0275\u0275text(1, " \u2715 ");
    \u0275\u0275domElementEnd();
  }
}
function AutocompletarDependencia_Conditional_8_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "li", 11);
    \u0275\u0275text(1);
    \u0275\u0275domElementStart(2, "span");
    \u0275\u0275text(3, "Prueba con las siglas (ESCOM, ESIME, CECyT 9) o con menos palabras.");
    \u0275\u0275domElementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" No hay ninguna dependencia que coincida con \u201C", ctx_r1.texto, "\u201D. ");
  }
}
function AutocompletarDependencia_Conditional_8_For_3_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "span", 18);
    \u0275\u0275text(1);
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    const sug_r5 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(sug_r5.dep.categoria);
  }
}
function AutocompletarDependencia_Conditional_8_For_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275domElementStart(0, "li", 14);
    \u0275\u0275domListener("mouseenter", function AutocompletarDependencia_Conditional_8_For_3_Template_li_mouseenter_0_listener() {
      const \u0275$index_29_r4 = \u0275\u0275restoreView(_r3).$index;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.resaltado = \u0275$index_29_r4);
    })("mousedown", function AutocompletarDependencia_Conditional_8_For_3_Template_li_mousedown_0_listener($event) {
      const sug_r5 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      $event.preventDefault();
      return \u0275\u0275resetView(ctx_r1.seleccionar(sug_r5.dep));
    });
    \u0275\u0275domElementStart(1, "span", 15);
    \u0275\u0275text(2);
    \u0275\u0275domElementEnd();
    \u0275\u0275domElementStart(3, "span", 16)(4, "span", 17);
    \u0275\u0275text(5);
    \u0275\u0275domElementStart(6, "mark");
    \u0275\u0275text(7);
    \u0275\u0275domElementEnd();
    \u0275\u0275text(8);
    \u0275\u0275domElementEnd();
    \u0275\u0275conditionalCreate(9, AutocompletarDependencia_Conditional_8_For_3_Conditional_9_Template, 2, 1, "span", 18);
    \u0275\u0275domElementEnd()();
  }
  if (rf & 2) {
    const sug_r5 = ctx.$implicit;
    const \u0275$index_29_r4 = ctx.$index;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("autocompletar__opcion--resaltada", \u0275$index_29_r4 === ctx_r1.resaltado);
    \u0275\u0275domProperty("id", "opcion-" + \u0275$index_29_r4);
    \u0275\u0275attribute("aria-selected", \u0275$index_29_r4 === ctx_r1.resaltado);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(sug_r5.dep.clave);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(sug_r5.antes);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(sug_r5.coincide);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(sug_r5.despues);
    \u0275\u0275advance();
    \u0275\u0275conditional(sug_r5.dep.categoria ? 9 : -1);
  }
}
function AutocompletarDependencia_Conditional_8_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "li", 13);
    \u0275\u0275text(1);
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" y ", ctx_r1.ocultas, " m\xE1s \u2014 sigue escribiendo para afinar la b\xFAsqueda ");
  }
}
function AutocompletarDependencia_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "ul", 8);
    \u0275\u0275conditionalCreate(1, AutocompletarDependencia_Conditional_8_Conditional_1_Template, 4, 1, "li", 11);
    \u0275\u0275repeaterCreate(2, AutocompletarDependencia_Conditional_8_For_3_Template, 10, 9, "li", 12, _forTrack02);
    \u0275\u0275conditionalCreate(4, AutocompletarDependencia_Conditional_8_Conditional_4_Template, 2, 1, "li", 13);
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.sugerencias.length === 0 ? 1 : -1);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r1.sugerencias);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.ocultas > 0 ? 4 : -1);
  }
}
function AutocompletarDependencia_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "span", 9);
    \u0275\u0275text(1);
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" Escribiste \u201C", ctx_r1.texto, "\u201D pero no elegiste ninguna opci\xF3n de la lista. Vuelve a escribir y selecciona una. ");
  }
}
var MAXIMO_SUGERENCIAS = 8;
var TIPO_PREFERIDO = "Unidad Acad\xE9mica";
var AutocompletarDependencia = class _AutocompletarDependencia {
  elementRef;
  dependencias = [];
  cargando = false;
  placeholder = "Escribe el nombre o las siglas (ej. ESCOM)";
  /** Se emite además del ngModelChange, por si el padre necesita reaccionar a la selección. */
  cambio = new EventEmitter();
  /** Lo que el usuario ve escrito en la caja. */
  texto = "";
  /** La clave realmente seleccionada. Vacía mientras no se elija de la lista. */
  valor = "";
  abierto = false;
  disabled = false;
  /** Índice de la sugerencia resaltada con el teclado; -1 = ninguna. */
  resaltado = -1;
  sugerencias = [];
  /** Cuántas coincidencias quedaron fuera del tope visible. */
  ocultas = 0;
  indice = [];
  /** Clave que llegó por writeValue antes de que el catálogo estuviera cargado. */
  clavePendiente = "";
  onChange = () => {
  };
  onTouched = () => {
  };
  constructor(elementRef) {
    this.elementRef = elementRef;
  }
  ngOnChanges(cambios) {
    if (cambios["dependencias"]) {
      this.construirIndice();
      if (this.clavePendiente) {
        this.mostrarClave(this.clavePendiente);
        this.clavePendiente = "";
      }
    }
  }
  // =======================================================================================
  // ControlValueAccessor
  // =======================================================================================
  writeValue(valor) {
    const clave = valor ?? "";
    if (!clave) {
      this.valor = "";
      this.texto = "";
      return;
    }
    if (this.indice.length === 0) {
      this.clavePendiente = clave;
      this.valor = clave;
      return;
    }
    this.mostrarClave(clave);
  }
  registerOnChange(fn) {
    this.onChange = fn;
  }
  registerOnTouched(fn) {
    this.onTouched = fn;
  }
  setDisabledState(disabled) {
    this.disabled = disabled;
  }
  // =======================================================================================
  // Índice y normalización
  // =======================================================================================
  /**
   * Quita acentos y pasa a minúsculas SIN cambiar la longitud del texto.
   *
   * El truco de `[...s].map(c => c.normalize('NFD')[0])` es a propósito: descomponer la cadena
   * completa con NFD la alarga (una "ó" se vuelve "o" + tilde combinante), y entonces las
   * posiciones dejarían de coincidir con el texto original, que es justo lo que se necesita
   * para resaltar el tramo que coincidió. Normalizando carácter por carácter y quedándose con
   * el primero, cada letra sigue ocupando una posición.
   */
  normalizar(texto) {
    return [...texto].map((caracter) => caracter.normalize("NFD")[0]).join("").toLowerCase();
  }
  construirIndice() {
    this.indice = (this.dependencias ?? []).map((dep) => {
      const nombreNorm = this.normalizar(dep.nombre ?? "");
      return {
        dep,
        nombreNorm,
        claveNorm: this.normalizar(dep.clave ?? ""),
        abrevNorm: this.normalizar(dep.abreviatura ?? ""),
        palabras: nombreNorm.split(/[^a-z0-9]+/).filter((p) => p.length > 0)
      };
    });
  }
  mostrarClave(clave) {
    const encontrada = this.indice.find((e) => e.dep.clave === clave);
    this.valor = clave;
    this.texto = encontrada ? this.etiqueta(encontrada.dep) : clave;
  }
  etiqueta(dep) {
    return dep.nombre;
  }
  // =======================================================================================
  // Búsqueda
  // =======================================================================================
  /**
   * Puntúa qué tan buena es una coincidencia. Los números no significan nada por sí solos;
   * lo que importa es el orden: primero las siglas exactas, luego los prefijos, y hasta el
   * final las coincidencias en medio del texto.
   *
   * Sin esta escala, escribir "ESCOM" pondría igual de arriba a cualquier escuela cuyo nombre
   * contenga "com" — Comercio, Computación, etc. — y la que el usuario quiere quedaría
   * enterrada.
   */
  puntuar(entrada, consulta, tokens) {
    if (entrada.claveNorm === consulta || entrada.abrevNorm === consulta)
      return 100;
    if (entrada.claveNorm.startsWith(consulta) || entrada.abrevNorm.startsWith(consulta))
      return 90;
    if (entrada.nombreNorm.startsWith(consulta))
      return 80;
    if (tokens.length > 1 && tokens.every((t) => entrada.palabras.some((p) => p.startsWith(t)))) {
      return 70;
    }
    if (entrada.nombreNorm.includes(consulta))
      return 60;
    if (entrada.claveNorm.includes(consulta) || entrada.abrevNorm.includes(consulta))
      return 50;
    return 0;
  }
  buscar(consultaCruda) {
    const consulta = this.normalizar(consultaCruda.trim());
    if (!consulta) {
      this.sugerencias = this.indice.slice(0, MAXIMO_SUGERENCIAS).map((e) => ({ dep: e.dep, puntaje: 0, antes: e.dep.nombre, coincide: "", despues: "" }));
      this.ocultas = Math.max(0, this.indice.length - MAXIMO_SUGERENCIAS);
      this.resaltado = -1;
      return;
    }
    const tokens = consulta.split(/\s+/).filter((t) => t.length > 0);
    const coincidencias = this.indice.map((entrada) => ({ entrada, puntaje: this.puntuar(entrada, consulta, tokens) })).filter((c) => c.puntaje > 0).sort((a, b) => {
      if (b.puntaje !== a.puntaje)
        return b.puntaje - a.puntaje;
      const preferidoA = a.entrada.dep.tipo === TIPO_PREFERIDO ? 0 : 1;
      const preferidoB = b.entrada.dep.tipo === TIPO_PREFERIDO ? 0 : 1;
      if (preferidoA !== preferidoB)
        return preferidoA - preferidoB;
      const largo = a.entrada.dep.nombre.length - b.entrada.dep.nombre.length;
      return largo !== 0 ? largo : a.entrada.dep.nombre.localeCompare(b.entrada.dep.nombre, "es");
    });
    this.ocultas = Math.max(0, coincidencias.length - MAXIMO_SUGERENCIAS);
    this.sugerencias = coincidencias.slice(0, MAXIMO_SUGERENCIAS).map((c) => this.conResaltado(c.entrada, consulta, c.puntaje));
    this.resaltado = this.sugerencias.length > 0 ? 0 : -1;
  }
  /** Parte el nombre en tres para poder subrayar el tramo que coincidió, sin usar innerHTML. */
  conResaltado(entrada, consulta, puntaje) {
    const nombre = entrada.dep.nombre;
    const desde = entrada.nombreNorm.indexOf(consulta);
    if (desde < 0) {
      return { dep: entrada.dep, puntaje, antes: nombre, coincide: "", despues: "" };
    }
    return {
      dep: entrada.dep,
      puntaje,
      antes: nombre.slice(0, desde),
      coincide: nombre.slice(desde, desde + consulta.length),
      despues: nombre.slice(desde + consulta.length)
    };
  }
  // =======================================================================================
  // Interacción
  // =======================================================================================
  onEntrada(valorEscrito) {
    this.texto = valorEscrito;
    if (this.valor) {
      this.valor = "";
      this.onChange("");
      this.cambio.emit("");
    }
    this.buscar(valorEscrito);
    this.abierto = true;
  }
  onFoco() {
    if (this.disabled)
      return;
    this.buscar(this.valor ? "" : this.texto);
    this.abierto = true;
  }
  seleccionar(dep) {
    this.valor = dep.clave;
    this.texto = this.etiqueta(dep);
    this.abierto = false;
    this.resaltado = -1;
    this.onChange(dep.clave);
    this.onTouched();
    this.cambio.emit(dep.clave);
  }
  limpiar() {
    this.texto = "";
    this.valor = "";
    this.abierto = false;
    this.onChange("");
    this.cambio.emit("");
    this.enfocarCaja();
  }
  onTecla(evento) {
    if (this.disabled)
      return;
    switch (evento.key) {
      case "ArrowDown":
        evento.preventDefault();
        if (!this.abierto) {
          this.onFoco();
          return;
        }
        this.mover(1);
        return;
      case "ArrowUp":
        evento.preventDefault();
        this.mover(-1);
        return;
      case "Enter":
        if (this.abierto && this.resaltado >= 0 && this.sugerencias[this.resaltado]) {
          evento.preventDefault();
          this.seleccionar(this.sugerencias[this.resaltado].dep);
        }
        return;
      case "Escape":
        if (this.abierto) {
          evento.preventDefault();
          this.abierto = false;
          this.resaltado = -1;
        }
        return;
      case "Tab":
        this.abierto = false;
        this.onTouched();
        return;
      default:
        return;
    }
  }
  mover(paso) {
    if (this.sugerencias.length === 0)
      return;
    const total = this.sugerencias.length;
    this.resaltado = (this.resaltado + paso + total) % total;
    this.desplazarAlResaltado();
  }
  /** Mantiene visible la opción resaltada cuando se navega con las flechas. */
  desplazarAlResaltado() {
    const opcion = this.elementRef.nativeElement.querySelector(`#opcion-${this.resaltado}`);
    opcion?.scrollIntoView({ block: "nearest" });
  }
  enfocarCaja() {
    this.elementRef.nativeElement.querySelector("input")?.focus();
  }
  /** Cerrar al hacer clic fuera — mismo patrón que el datepicker. */
  alClicarFuera(evento) {
    if (!this.abierto)
      return;
    if (!this.elementRef.nativeElement.contains(evento.target)) {
      this.abierto = false;
      this.resaltado = -1;
      this.onTouched();
    }
  }
  /** true cuando hay texto escrito pero ninguna opción elegida todavía. */
  get sinElegir() {
    return this.texto.trim().length > 0 && this.valor === "";
  }
  static \u0275fac = function AutocompletarDependencia_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _AutocompletarDependencia)(\u0275\u0275directiveInject(ElementRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AutocompletarDependencia, selectors: [["app-autocompletar-dependencia"]], hostBindings: function AutocompletarDependencia_HostBindings(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275listener("click", function AutocompletarDependencia_click_HostBindingHandler($event) {
        return ctx.alClicarFuera($event);
      }, \u0275\u0275resolveDocument);
    }
  }, inputs: { dependencias: "dependencias", cargando: "cargando", placeholder: "placeholder" }, outputs: { cambio: "cambio" }, features: [\u0275\u0275ProvidersFeature([
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => _AutocompletarDependencia),
      multi: true
    }
  ]), \u0275\u0275NgOnChangesFeature], decls: 10, vars: 10, consts: [[1, "autocompletar"], [1, "autocompletar__caja"], ["aria-hidden", "true", 1, "autocompletar__lupa"], ["viewBox", "0 0 24 24", "fill", "none", "stroke-width", "1.8", "stroke-linecap", "round"], ["cx", "11", "cy", "11", "r", "7"], ["d", "M16.5 16.5L21 21"], ["type", "text", "role", "combobox", "autocomplete", "off", "aria-autocomplete", "list", "aria-controls", "lista-dependencias", 3, "input", "focus", "keydown", "placeholder", "value", "disabled"], ["type", "button", "aria-label", "Limpiar", 1, "autocompletar__limpiar"], ["id", "lista-dependencias", "role", "listbox", 1, "autocompletar__lista"], [1, "autocompletar__aviso"], ["type", "button", "aria-label", "Limpiar", 1, "autocompletar__limpiar", 3, "click"], [1, "autocompletar__vacio"], ["role", "option", 1, "autocompletar__opcion", 3, "autocompletar__opcion--resaltada", "id"], [1, "autocompletar__mas"], ["role", "option", 1, "autocompletar__opcion", 3, "mouseenter", "mousedown", "id"], [1, "autocompletar__clave"], [1, "autocompletar__texto"], [1, "autocompletar__nombre"], [1, "autocompletar__categoria"]], template: function AutocompletarDependencia_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275domElementStart(0, "div", 0)(1, "div", 1)(2, "span", 2);
      \u0275\u0275namespaceSVG();
      \u0275\u0275domElementStart(3, "svg", 3);
      \u0275\u0275domElement(4, "circle", 4)(5, "path", 5);
      \u0275\u0275domElementEnd()();
      \u0275\u0275namespaceHTML();
      \u0275\u0275domElementStart(6, "input", 6);
      \u0275\u0275domListener("input", function AutocompletarDependencia_Template_input_input_6_listener($event) {
        return ctx.onEntrada($event.target.value);
      })("focus", function AutocompletarDependencia_Template_input_focus_6_listener() {
        return ctx.onFoco();
      })("keydown", function AutocompletarDependencia_Template_input_keydown_6_listener($event) {
        return ctx.onTecla($event);
      });
      \u0275\u0275domElementEnd();
      \u0275\u0275conditionalCreate(7, AutocompletarDependencia_Conditional_7_Template, 2, 0, "button", 7);
      \u0275\u0275domElementEnd();
      \u0275\u0275conditionalCreate(8, AutocompletarDependencia_Conditional_8_Template, 5, 2, "ul", 8);
      \u0275\u0275domElementEnd();
      \u0275\u0275conditionalCreate(9, AutocompletarDependencia_Conditional_9_Template, 2, 1, "span", 9);
    }
    if (rf & 2) {
      \u0275\u0275classProp("autocompletar--abierto", ctx.abierto);
      \u0275\u0275advance(6);
      \u0275\u0275domProperty("placeholder", ctx.cargando ? "Cargando dependencias\u2026" : ctx.placeholder)("value", ctx.texto)("disabled", ctx.disabled || ctx.cargando);
      \u0275\u0275attribute("aria-expanded", ctx.abierto)("aria-activedescendant", ctx.abierto && ctx.resaltado >= 0 ? "opcion-" + ctx.resaltado : null);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.texto ? 7 : -1);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.abierto ? 8 : -1);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.sinElegir && !ctx.abierto ? 9 : -1);
    }
  }, dependencies: [CommonModule, FormsModule], styles: ['\n.autocompletar[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n}\n.autocompletar__caja[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  padding: 0 10px 0 12px;\n  background: #fff;\n  border: 1px solid #ccc;\n  border-radius: 6px;\n  transition: border-color 0.15s ease, box-shadow 0.15s ease;\n}\n.autocompletar__caja[_ngcontent-%COMP%]:focus-within {\n  border-color: #9d2449;\n  box-shadow: 0 0 0 3px rgba(157, 36, 73, 0.12);\n}\n.autocompletar__caja[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  padding: 10px 0;\n  font: inherit;\n  color: #1a1a1a;\n  background: transparent;\n  border: 0;\n  outline: none;\n}\n.autocompletar__caja[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]::placeholder {\n  color: #9a9a9a;\n}\n.autocompletar__caja[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]:disabled {\n  color: #999;\n  cursor: not-allowed;\n}\n.autocompletar--abierto[_ngcontent-%COMP%]   .autocompletar__caja[_ngcontent-%COMP%] {\n  border-color: #9d2449;\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0;\n}\n.autocompletar__lupa[_ngcontent-%COMP%] {\n  display: flex;\n  flex-shrink: 0;\n  color: #9d2449;\n}\n.autocompletar__lupa[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 17px;\n  height: 17px;\n  stroke: currentColor;\n}\n.autocompletar__limpiar[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n  padding: 2px 6px;\n  font-size: 0.8rem;\n  line-height: 1;\n  color: #888;\n  cursor: pointer;\n  background: transparent;\n  border: 0;\n  border-radius: 4px;\n}\n.autocompletar__limpiar[_ngcontent-%COMP%]:hover {\n  color: #9d2449;\n  background: #f7eef1;\n}\n.autocompletar__lista[_ngcontent-%COMP%] {\n  position: absolute;\n  z-index: 40;\n  width: 100%;\n  max-height: 320px;\n  padding: 0;\n  margin: 0;\n  overflow-y: auto;\n  list-style: none;\n  background: #fff;\n  border: 1px solid #9d2449;\n  border-top: 0;\n  border-radius: 0 0 6px 6px;\n  box-shadow: 0 10px 26px rgba(0, 0, 0, 0.14);\n}\n.autocompletar__opcion[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  align-items: flex-start;\n  padding: 9px 12px;\n  cursor: pointer;\n  border-bottom: 1px solid #f2eced;\n}\n.autocompletar__opcion[_ngcontent-%COMP%]:last-child {\n  border-bottom: 0;\n}\n.autocompletar__opcion--resaltada[_ngcontent-%COMP%] {\n  background: #f7eef1;\n}\n.autocompletar__clave[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n  padding: 2px 7px;\n  font-family:\n    ui-monospace,\n    "SFMono-Regular",\n    Menlo,\n    monospace;\n  font-size: 0.7rem;\n  font-weight: 600;\n  color: #6c1d45;\n  letter-spacing: 0.02em;\n  background: #f0e2e8;\n  border-radius: 3px;\n}\n.autocompletar__texto[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  min-width: 0;\n}\n.autocompletar__nombre[_ngcontent-%COMP%] {\n  font-size: 0.88rem;\n  line-height: 1.35;\n  color: #1a1a1a;\n}\n.autocompletar__nombre[_ngcontent-%COMP%]   mark[_ngcontent-%COMP%] {\n  padding: 0;\n  font-weight: 700;\n  color: #9d2449;\n  background: transparent;\n}\n.autocompletar__categoria[_ngcontent-%COMP%] {\n  overflow: hidden;\n  font-size: 0.72rem;\n  color: #8a8a8a;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.autocompletar__vacio[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  padding: 14px 12px;\n  font-size: 0.85rem;\n  color: #666;\n}\n.autocompletar__vacio[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 0.78rem;\n  color: #999;\n}\n.autocompletar__mas[_ngcontent-%COMP%] {\n  padding: 8px 12px;\n  font-size: 0.75rem;\n  color: #8a8a8a;\n  text-align: center;\n  background: #fafafa;\n  border-top: 1px solid #f0f0f0;\n}\n.autocompletar__aviso[_ngcontent-%COMP%] {\n  display: block;\n  margin-top: 4px;\n  font-size: 0.76rem;\n  color: #b06a00;\n}\n/*# sourceMappingURL=autocompletar-dependencia.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AutocompletarDependencia, [{
    type: Component,
    args: [{ selector: "app-autocompletar-dependencia", standalone: true, imports: [CommonModule, FormsModule], providers: [
      {
        provide: NG_VALUE_ACCESSOR,
        useExisting: forwardRef(() => AutocompletarDependencia),
        multi: true
      }
    ], template: `<div class="autocompletar" [class.autocompletar--abierto]="abierto">
  <div class="autocompletar__caja">
    <span class="autocompletar__lupa" aria-hidden="true">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round">
        <circle cx="11" cy="11" r="7" />
        <path d="M16.5 16.5L21 21" />
      </svg>
    </span>

    <input
      type="text"
      role="combobox"
      autocomplete="off"
      aria-autocomplete="list"
      aria-controls="lista-dependencias"
      [attr.aria-expanded]="abierto"
      [attr.aria-activedescendant]="abierto && resaltado >= 0 ? 'opcion-' + resaltado : null"
      [placeholder]="cargando ? 'Cargando dependencias\u2026' : placeholder"
      [value]="texto"
      [disabled]="disabled || cargando"
      (input)="onEntrada($any($event.target).value)"
      (focus)="onFoco()"
      (keydown)="onTecla($event)"
    />

    @if (texto) {
      <button type="button" class="autocompletar__limpiar" (click)="limpiar()" aria-label="Limpiar">
        \u2715
      </button>
    }
  </div>

  @if (abierto) {
    <ul class="autocompletar__lista" id="lista-dependencias" role="listbox">
      @if (sugerencias.length === 0) {
        <li class="autocompletar__vacio">
          No hay ninguna dependencia que coincida con \u201C{{ texto }}\u201D.
          <span>Prueba con las siglas (ESCOM, ESIME, CECyT 9) o con menos palabras.</span>
        </li>
      }

      @for (sug of sugerencias; track sug.dep.clave; let i = $index) {
        <li
          class="autocompletar__opcion"
          [class.autocompletar__opcion--resaltada]="i === resaltado"
          [id]="'opcion-' + i"
          role="option"
          [attr.aria-selected]="i === resaltado"
          (mouseenter)="resaltado = i"
          (mousedown)="$event.preventDefault(); seleccionar(sug.dep)"
        >
          <span class="autocompletar__clave">{{ sug.dep.clave }}</span>
          <span class="autocompletar__texto">
            <span class="autocompletar__nombre">{{ sug.antes
              }}<mark>{{ sug.coincide }}</mark>{{ sug.despues }}</span>
            @if (sug.dep.categoria) {
              <span class="autocompletar__categoria">{{ sug.dep.categoria }}</span>
            }
          </span>
        </li>
      }

      @if (ocultas > 0) {
        <li class="autocompletar__mas">
          y {{ ocultas }} m\xE1s \u2014 sigue escribiendo para afinar la b\xFAsqueda
        </li>
      }
    </ul>
  }
</div>

@if (sinElegir && !abierto) {
  <span class="autocompletar__aviso">
    Escribiste \u201C{{ texto }}\u201D pero no elegiste ninguna opci\xF3n de la lista. Vuelve a escribir y
    selecciona una.
  </span>
}
`, styles: ['/* src/app/shared/autocompletar-dependencia/autocompletar-dependencia.scss */\n.autocompletar {\n  position: relative;\n  width: 100%;\n}\n.autocompletar__caja {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  padding: 0 10px 0 12px;\n  background: #fff;\n  border: 1px solid #ccc;\n  border-radius: 6px;\n  transition: border-color 0.15s ease, box-shadow 0.15s ease;\n}\n.autocompletar__caja:focus-within {\n  border-color: #9d2449;\n  box-shadow: 0 0 0 3px rgba(157, 36, 73, 0.12);\n}\n.autocompletar__caja input {\n  flex: 1;\n  min-width: 0;\n  padding: 10px 0;\n  font: inherit;\n  color: #1a1a1a;\n  background: transparent;\n  border: 0;\n  outline: none;\n}\n.autocompletar__caja input::placeholder {\n  color: #9a9a9a;\n}\n.autocompletar__caja input:disabled {\n  color: #999;\n  cursor: not-allowed;\n}\n.autocompletar--abierto .autocompletar__caja {\n  border-color: #9d2449;\n  border-bottom-left-radius: 0;\n  border-bottom-right-radius: 0;\n}\n.autocompletar__lupa {\n  display: flex;\n  flex-shrink: 0;\n  color: #9d2449;\n}\n.autocompletar__lupa svg {\n  width: 17px;\n  height: 17px;\n  stroke: currentColor;\n}\n.autocompletar__limpiar {\n  flex-shrink: 0;\n  padding: 2px 6px;\n  font-size: 0.8rem;\n  line-height: 1;\n  color: #888;\n  cursor: pointer;\n  background: transparent;\n  border: 0;\n  border-radius: 4px;\n}\n.autocompletar__limpiar:hover {\n  color: #9d2449;\n  background: #f7eef1;\n}\n.autocompletar__lista {\n  position: absolute;\n  z-index: 40;\n  width: 100%;\n  max-height: 320px;\n  padding: 0;\n  margin: 0;\n  overflow-y: auto;\n  list-style: none;\n  background: #fff;\n  border: 1px solid #9d2449;\n  border-top: 0;\n  border-radius: 0 0 6px 6px;\n  box-shadow: 0 10px 26px rgba(0, 0, 0, 0.14);\n}\n.autocompletar__opcion {\n  display: flex;\n  gap: 10px;\n  align-items: flex-start;\n  padding: 9px 12px;\n  cursor: pointer;\n  border-bottom: 1px solid #f2eced;\n}\n.autocompletar__opcion:last-child {\n  border-bottom: 0;\n}\n.autocompletar__opcion--resaltada {\n  background: #f7eef1;\n}\n.autocompletar__clave {\n  flex-shrink: 0;\n  padding: 2px 7px;\n  font-family:\n    ui-monospace,\n    "SFMono-Regular",\n    Menlo,\n    monospace;\n  font-size: 0.7rem;\n  font-weight: 600;\n  color: #6c1d45;\n  letter-spacing: 0.02em;\n  background: #f0e2e8;\n  border-radius: 3px;\n}\n.autocompletar__texto {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  min-width: 0;\n}\n.autocompletar__nombre {\n  font-size: 0.88rem;\n  line-height: 1.35;\n  color: #1a1a1a;\n}\n.autocompletar__nombre mark {\n  padding: 0;\n  font-weight: 700;\n  color: #9d2449;\n  background: transparent;\n}\n.autocompletar__categoria {\n  overflow: hidden;\n  font-size: 0.72rem;\n  color: #8a8a8a;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.autocompletar__vacio {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  padding: 14px 12px;\n  font-size: 0.85rem;\n  color: #666;\n}\n.autocompletar__vacio span {\n  font-size: 0.78rem;\n  color: #999;\n}\n.autocompletar__mas {\n  padding: 8px 12px;\n  font-size: 0.75rem;\n  color: #8a8a8a;\n  text-align: center;\n  background: #fafafa;\n  border-top: 1px solid #f0f0f0;\n}\n.autocompletar__aviso {\n  display: block;\n  margin-top: 4px;\n  font-size: 0.76rem;\n  color: #b06a00;\n}\n/*# sourceMappingURL=autocompletar-dependencia.css.map */\n'] }]
  }], () => [{ type: ElementRef }], { dependencias: [{
    type: Input
  }], cargando: [{
    type: Input
  }], placeholder: [{
    type: Input
  }], cambio: [{
    type: Output
  }], alClicarFuera: [{
    type: HostListener,
    args: ["document:click", ["$event"]]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AutocompletarDependencia, { className: "AutocompletarDependencia", filePath: "src/app/shared/autocompletar-dependencia/autocompletar-dependencia.ts", lineNumber: 80 });
})();

// src/app/core/services/catalogo.service.ts
var CatalogoService = class _CatalogoService {
  http;
  apiUrl = "/api/catalogos";
  constructor(http) {
    this.http = http;
  }
  /** Lista las dependencias activas del catálogo, opcionalmente filtradas por tipo
   * (ej. "Unidad Académica" para no mezclar CECyT/ESIME/etc. con divisiones
   * administrativas internas que no aplican como "lugar de los hechos"). */
  listarDependencias(tipo) {
    const url = tipo ? `${this.apiUrl}/dependencias?tipo=${encodeURIComponent(tipo)}` : `${this.apiUrl}/dependencias`;
    return this.http.get(url);
  }
  static \u0275fac = function CatalogoService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _CatalogoService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _CatalogoService, factory: _CatalogoService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CatalogoService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/core/services/queja-ventanilla.service.ts
var QuejaVentanillaService = class _QuejaVentanillaService {
  http;
  constructor(http) {
    this.http = http;
  }
  registrarQuejaPublica(datos) {
    const formData = new FormData();
    formData.append("nombre", datos.nombre);
    formData.append("apellido1", datos.apellido1);
    if (datos.apellido2) {
      formData.append("apellido2", datos.apellido2);
    }
    formData.append("correo", datos.correo);
    formData.append("fechaNacimiento", datos.fechaNacimiento);
    formData.append("tipoIdentificacion", datos.tipoIdentificacion);
    formData.append("numeroIdentificacion", datos.numeroIdentificacion);
    formData.append("unidadAcademicaClave", datos.unidadAcademicaClave);
    formData.append("fechaHechos", datos.fechaHechos);
    if (datos.nombreDenunciado) {
      formData.append("nombreDenunciado", datos.nombreDenunciado);
    }
    if (datos.apellido1Denunciado) {
      formData.append("apellido1Denunciado", datos.apellido1Denunciado);
    }
    if (datos.apellido2Denunciado) {
      formData.append("apellido2Denunciado", datos.apellido2Denunciado);
    }
    formData.append("descripcion", datos.descripcion);
    formData.append("avisoPrivacidadAceptado", String(datos.avisoPrivacidadAceptado));
    formData.append("avisoPrivacidadVersion", datos.avisoPrivacidadVersion);
    for (const archivo of datos.archivos ?? []) {
      formData.append("archivos", archivo);
    }
    if (datos.tutor) {
      formData.append("tutorNombre", datos.tutor.nombre);
      formData.append("tutorApellido1", datos.tutor.apellido1);
      if (datos.tutor.apellido2) {
        formData.append("tutorApellido2", datos.tutor.apellido2);
      }
      formData.append("tutorParentesco", datos.tutor.parentesco);
      if (datos.tutor.correo) {
        formData.append("tutorCorreo", datos.tutor.correo);
      }
      if (datos.tutor.telefono) {
        formData.append("tutorTelefono", datos.tutor.telefono);
      }
    }
    return this.http.post("/api/quejoso/quejas/registro-publico", formData);
  }
  /** Marca la queja recién creada como recibida en ventanilla (origen MANUAL). */
  marcarVentanilla(folio, datos) {
    return this.http.post(`/api/revision/registro-manual/${encodeURIComponent(folio)}/ventanilla`, datos);
  }
  static \u0275fac = function QuejaVentanillaService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _QuejaVentanillaService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _QuejaVentanillaService, factory: _QuejaVentanillaService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(QuejaVentanillaService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/registro-ventanilla/registro-ventanilla.ts
var _forTrack03 = ($index, $item) => $item.valor;
var _forTrack1 = ($index, $item) => $item.archivo.name;
function RegistroVentanilla_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "app-aviso-privacidad", 15);
    \u0275\u0275listener("aceptado", function RegistroVentanilla_Conditional_0_Template_app_aviso_privacidad_aceptado_0_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onAvisoAceptado($event));
    });
    \u0275\u0275elementEnd();
  }
}
function RegistroVentanilla_Conditional_2_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 22);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.avisoVentanilla);
  }
}
function RegistroVentanilla_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 13)(1, "div", 16);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 17);
    \u0275\u0275element(3, "path", 18)(4, "circle", 19);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(5, "h2");
    \u0275\u0275text(6, "Queja registrada en ventanilla");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "p");
    \u0275\u0275text(8, "Folio asignado:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 20);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "p", 21);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(13, RegistroVentanilla_Conditional_2_Conditional_13_Template, 2, 1, "p", 22);
    \u0275\u0275elementStart(14, "button", 23);
    \u0275\u0275listener("click", function RegistroVentanilla_Conditional_2_Template_button_click_14_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.descargarAcuse());
    });
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(15, "svg", 24);
    \u0275\u0275element(16, "path", 25)(17, "rect", 26)(18, "path", 27);
    \u0275\u0275elementEnd();
    \u0275\u0275text(19, " Imprimir acuse de recibo ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(20, "div", 28)(21, "button", 29);
    \u0275\u0275listener("click", function RegistroVentanilla_Conditional_2_Template_button_click_21_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.atenderAhora());
    });
    \u0275\u0275text(22, "Validarla ahora");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "button", 30);
    \u0275\u0275listener("click", function RegistroVentanilla_Conditional_2_Template_button_click_23_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.registrarOtra());
    });
    \u0275\u0275text(24, "Registrar otra queja");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "a", 31);
    \u0275\u0275text(26, "Ir a la Bandeja de Entrada");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate(ctx_r1.quejaCreada.numeroFolio);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" Entrega a la persona quejosa el acuse con su folio. Con el folio y el correo (", ctx_r1.quejaCreada.correoInstitucional, ") puede consultar el estatus en el portal y, si lo desea, crear su cuenta de seguimiento. ");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.avisoVentanilla ? 13 : -1);
  }
}
function RegistroVentanilla_Conditional_3_For_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 40);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const t_r5 = ctx.$implicit;
    \u0275\u0275property("value", t_r5.valor);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(t_r5.etiqueta);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_36_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorNombre);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_42_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorApellido1);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_49_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorApellido2);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_55_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorCorreo);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_61_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorFechaNacimiento);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_62_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 54);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Entre 1920 y ", ctx_r1.fechaNacimientoMaxima.slice(0, 4), ".");
  }
}
function RegistroVentanilla_Conditional_3_Conditional_63_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
    \u0275\u0275elementStart(1, "strong");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275textInterpolate2(" Est\xE1s presentando esta queja como tutor(a) de ", ctx_r1.nombre, " ", ctx_r1.apellido1, ". Datos de tutor: ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", ctx_r1.tutor.nombre, " ", ctx_r1.tutor.apellido1);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_63_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Datos del tutor/adulto responsable capturados: ");
    \u0275\u0275elementStart(1, "strong");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", ctx_r1.tutor.nombre, " ", ctx_r1.tutor.apellido1);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_63_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 55)(1, "span", 83);
    \u0275\u0275text(2, "\u2713");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 84);
    \u0275\u0275conditionalCreate(4, RegistroVentanilla_Conditional_3_Conditional_63_Conditional_4_Template, 3, 4)(5, RegistroVentanilla_Conditional_3_Conditional_63_Conditional_5_Template, 3, 2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "button", 85);
    \u0275\u0275listener("click", function RegistroVentanilla_Conditional_3_Conditional_63_Template_button_click_6_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.editarTutor());
    });
    \u0275\u0275text(7, "Editar");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r1.esMenorDe14 ? 4 : 5);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_80_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorBoleta);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_81_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 54);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Solo n\xFAmeros, m\xE1ximo ", ctx_r1.boletaLongitudMaxima, " d\xEDgitos.");
  }
}
function RegistroVentanilla_Conditional_3_Conditional_85_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 86);
    \u0275\u0275listener("click", function RegistroVentanilla_Conditional_3_Conditional_85_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r7);
      const inputIdentificacion_r8 = \u0275\u0275reference(2);
      return \u0275\u0275resetView(inputIdentificacion_r8.click());
    });
    \u0275\u0275elementStart(1, "input", 87, 11);
    \u0275\u0275listener("change", function RegistroVentanilla_Conditional_3_Conditional_85_Template_input_change_1_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.onIdentificacionSeleccionada($event));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 72);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(4, "svg", 73);
    \u0275\u0275element(5, "rect", 88)(6, "circle", 89)(7, "path", 90)(8, "path", 91)(9, "path", 92);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(10, "p", 75);
    \u0275\u0275text(11, " Sube una foto o escaneo de tu credencial \u2014 ");
    \u0275\u0275elementStart(12, "strong");
    \u0275\u0275text(13, "haz clic para elegir");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "p", 76);
    \u0275\u0275text(15);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(15);
    \u0275\u0275textInterpolate1(" Solo JPG o PNG \u2014 m\xE1ximo 3MB por imagen \u2014 hasta ", ctx_r1.identificacionCantidadMaxima, " im\xE1genes (frente y reverso) ");
  }
}
function RegistroVentanilla_Conditional_3_Conditional_86_For_2_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "img", 94);
  }
  if (rf & 2) {
    const item_r10 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275property("src", item_r10.url, \u0275\u0275sanitizeUrl)("alt", "Vista previa de " + item_r10.archivo.name);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_86_For_2_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 95);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r10 = \u0275\u0275nextContext().$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.tipoArchivo(item_r10.archivo));
  }
}
function RegistroVentanilla_Conditional_3_Conditional_86_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "figure", 93);
    \u0275\u0275conditionalCreate(1, RegistroVentanilla_Conditional_3_Conditional_86_For_2_Conditional_1_Template, 1, 2, "img", 94)(2, RegistroVentanilla_Conditional_3_Conditional_86_For_2_Conditional_2_Template, 2, 1, "span", 95);
    \u0275\u0275elementStart(3, "figcaption")(4, "span", 96);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 97);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "button", 98);
    \u0275\u0275listener("click", function RegistroVentanilla_Conditional_3_Conditional_86_For_2_Template_button_click_8_listener() {
      const \u0275$index_264_r11 = \u0275\u0275restoreView(_r9).$index;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.quitarIdentificacion(\u0275$index_264_r11));
    });
    \u0275\u0275text(9, "\u2715");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const item_r10 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275conditional(item_r10.url ? 1 : 2);
    \u0275\u0275advance(3);
    \u0275\u0275property("title", item_r10.archivo.name);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(item_r10.archivo.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.formatearTamanio(item_r10.archivo.size));
    \u0275\u0275advance();
    \u0275\u0275attribute("aria-label", "Quitar " + item_r10.archivo.name);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_86_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 61);
    \u0275\u0275repeaterCreate(1, RegistroVentanilla_Conditional_3_Conditional_86_For_2_Template, 10, 5, "figure", 93, _forTrack1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r1.identificaciones);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_87_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorIdentificacion);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_96_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 63);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorDependencias);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_97_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorUnidadAcademica);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_98_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 54);
    \u0275\u0275text(1, " Escribe las siglas o el nombre de tu escuela \u2014 por ejemplo ");
    \u0275\u0275elementStart(2, "strong");
    \u0275\u0275text(3, "ESCOM");
    \u0275\u0275elementEnd();
    \u0275\u0275text(4, " o ");
    \u0275\u0275elementStart(5, "strong");
    \u0275\u0275text(6, "Escuela Superior de C\xF3mputo");
    \u0275\u0275elementEnd();
    \u0275\u0275text(7, ". ");
    \u0275\u0275elementEnd();
  }
}
function RegistroVentanilla_Conditional_3_Conditional_103_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorFechaHechos);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_112_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorNombreDenunciado);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_118_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorApellido1Denunciado);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_125_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorApellido2Denunciado);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_126_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 54);
    \u0275\u0275text(1, "Opcional, si lo conoces.");
    \u0275\u0275elementEnd();
  }
}
function RegistroVentanilla_Conditional_3_Conditional_135_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 48);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorDescripcion);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_151_For_4_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "img", 94);
  }
  if (rf & 2) {
    const item_r14 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275property("src", item_r14.url, \u0275\u0275sanitizeUrl)("alt", "Vista previa de " + item_r14.archivo.name);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_151_For_4_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 95);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r14 = \u0275\u0275nextContext().$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.tipoArchivo(item_r14.archivo));
  }
}
function RegistroVentanilla_Conditional_3_Conditional_151_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "figure", 93);
    \u0275\u0275conditionalCreate(1, RegistroVentanilla_Conditional_3_Conditional_151_For_4_Conditional_1_Template, 1, 2, "img", 94)(2, RegistroVentanilla_Conditional_3_Conditional_151_For_4_Conditional_2_Template, 2, 1, "span", 95);
    \u0275\u0275elementStart(3, "figcaption")(4, "span", 96);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 97);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "button", 98);
    \u0275\u0275listener("click", function RegistroVentanilla_Conditional_3_Conditional_151_For_4_Template_button_click_8_listener() {
      const \u0275$index_422_r15 = \u0275\u0275restoreView(_r13).$index;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.quitarArchivo(\u0275$index_422_r15));
    });
    \u0275\u0275text(9, "\u2715");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const item_r14 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275conditional(item_r14.url ? 1 : 2);
    \u0275\u0275advance(3);
    \u0275\u0275property("title", item_r14.archivo.name);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(item_r14.archivo.name);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.formatearTamanio(item_r14.archivo.size));
    \u0275\u0275advance();
    \u0275\u0275attribute("aria-label", "Quitar " + item_r14.archivo.name);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_151_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 99);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "div", 61);
    \u0275\u0275repeaterCreate(3, RegistroVentanilla_Conditional_3_Conditional_151_For_4_Template, 10, 5, "figure", 93, _forTrack1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.evidencias.length, " archivo(s) adjunto(s) \u2014 revisa que sean los correctos: ");
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.evidencias);
  }
}
function RegistroVentanilla_Conditional_3_Conditional_160_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 82);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" Aviso de privacidad aceptado (v", ctx_r1.avisoPrivacidadVersion, "). ");
  }
}
function RegistroVentanilla_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 32)(1, "h2");
    \u0275\u0275text(2, "Registro Manual (Ventanilla)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p", 33);
    \u0275\u0275text(4, " Captura la queja que la persona presenta en ventanilla con el mismo formulario del portal. Antes de empezar, mu\xE9strale el aviso de privacidad para que lo lea y lo acepte. ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "form", 34);
    \u0275\u0275listener("submit", function RegistroVentanilla_Conditional_3_Template_form_submit_5_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      $event.preventDefault();
      return \u0275\u0275resetView(ctx_r1.enviarQueja());
    });
    \u0275\u0275elementStart(6, "h3", 35);
    \u0275\u0275text(7, "Recepci\xF3n en ventanilla");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "div", 36)(9, "div", 37)(10, "label", 38);
    \u0275\u0275text(11, "Documento recibido:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "select", 39);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_select_ngModelChange_12_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.tipoDocumento, $event) || (ctx_r1.tipoDocumento = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275repeaterCreate(13, RegistroVentanilla_Conditional_3_For_14_Template, 2, 2, "option", 40, _forTrack03);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 37)(16, "label", 41);
    \u0275\u0275text(17, "Fecha de recepci\xF3n f\xEDsica:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "input", 42);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_input_ngModelChange_18_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.fechaRecepcionFisica, $event) || (ctx_r1.fechaRecepcionFisica = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(19, "div", 36)(20, "div", 37)(21, "label", 43);
    \u0275\u0275text(22, "N\xFAmero de oficio (si aplica):");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "input", 44);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_input_ngModelChange_23_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.numeroOficio, $event) || (ctx_r1.numeroOficio = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(24, "div", 37)(25, "label", 45);
    \u0275\u0275text(26, "Ubicaci\xF3n f\xEDsica del expediente (opcional):");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "input", 46);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_input_ngModelChange_27_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.ubicacionFisica, $event) || (ctx_r1.ubicacionFisica = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(28, "h3", 35);
    \u0275\u0275text(29, "Datos del Quejoso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "div", 36)(31, "div", 37)(32, "label");
    \u0275\u0275text(33, "Nombre:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "input", 47, 0);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_input_ngModelChange_34_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.nombre, $event) || (ctx_r1.nombre = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("keypress", function RegistroVentanilla_Conditional_3_Template_input_keypress_34_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.soloLetras($event));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(36, RegistroVentanilla_Conditional_3_Conditional_36_Template, 2, 1, "span", 48);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "div", 37)(38, "label");
    \u0275\u0275text(39, "Primer Apellido:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "input", 49, 1);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_input_ngModelChange_40_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.apellido1, $event) || (ctx_r1.apellido1 = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("keypress", function RegistroVentanilla_Conditional_3_Template_input_keypress_40_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.soloLetras($event));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(42, RegistroVentanilla_Conditional_3_Conditional_42_Template, 2, 1, "span", 48);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(43, "div", 36)(44, "div", 37)(45, "label");
    \u0275\u0275text(46, "Segundo Apellido:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(47, "input", 50, 2);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_input_ngModelChange_47_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.apellido2, $event) || (ctx_r1.apellido2 = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("keypress", function RegistroVentanilla_Conditional_3_Template_input_keypress_47_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.soloLetras($event));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(49, RegistroVentanilla_Conditional_3_Conditional_49_Template, 2, 1, "span", 48);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(50, "div", 37)(51, "label");
    \u0275\u0275text(52, "Correo:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(53, "input", 51, 3);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_input_ngModelChange_53_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.correo, $event) || (ctx_r1.correo = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("blur", function RegistroVentanilla_Conditional_3_Template_input_blur_53_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.verificarCorreoRegistrado());
    });
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(55, RegistroVentanilla_Conditional_3_Conditional_55_Template, 2, 1, "span", 48);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(56, "div", 36)(57, "div", 52)(58, "label");
    \u0275\u0275text(59, "Fecha de nacimiento:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(60, "app-datepicker", 53);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_app_datepicker_ngModelChange_60_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.fechaNacimiento, $event) || (ctx_r1.fechaNacimiento = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("cambio", function RegistroVentanilla_Conditional_3_Template_app_datepicker_cambio_60_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onFechaNacimientoChange());
    });
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(61, RegistroVentanilla_Conditional_3_Conditional_61_Template, 2, 1, "span", 48)(62, RegistroVentanilla_Conditional_3_Conditional_62_Template, 2, 1, "span", 54);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(63, RegistroVentanilla_Conditional_3_Conditional_63_Template, 8, 1, "div", 55);
    \u0275\u0275elementStart(64, "div", 36)(65, "div", 37)(66, "label");
    \u0275\u0275text(67, "Identificaci\xF3n institucional:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(68, "div", 56)(69, "label")(70, "input", 57);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_input_ngModelChange_70_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.identificacion, $event) || (ctx_r1.identificacion = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275text(71, " Alumno");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(72, "label")(73, "input", 58);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_input_ngModelChange_73_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.identificacion, $event) || (ctx_r1.identificacion = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275text(74, " Empleado");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(75, "div", 37)(76, "label");
    \u0275\u0275text(77);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(78, "input", 59, 4);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_input_ngModelChange_78_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.numeroBoletaEmpleado, $event) || (ctx_r1.numeroBoletaEmpleado = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("keypress", function RegistroVentanilla_Conditional_3_Template_input_keypress_78_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.soloDigitos($event));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(80, RegistroVentanilla_Conditional_3_Conditional_80_Template, 2, 1, "span", 48)(81, RegistroVentanilla_Conditional_3_Conditional_81_Template, 2, 1, "span", 54);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(82, "div", 37)(83, "label");
    \u0275\u0275text(84, " Identificaci\xF3n oficial (credencial de la comunidad polit\xE9cnica): ");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(85, RegistroVentanilla_Conditional_3_Conditional_85_Template, 16, 1, "div", 60);
    \u0275\u0275conditionalCreate(86, RegistroVentanilla_Conditional_3_Conditional_86_Template, 3, 0, "div", 61);
    \u0275\u0275conditionalCreate(87, RegistroVentanilla_Conditional_3_Conditional_87_Template, 2, 1, "span", 48);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(88, "h3", 35);
    \u0275\u0275text(89, "Lugar de los hechos");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(90, "div", 36)(91, "div", 37)(92, "label");
    \u0275\u0275text(93, "Lugar donde sucedieron los hechos:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(94, "app-autocompletar-dependencia", 62, 5);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_app_autocompletar_dependencia_ngModelChange_94_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.unidadAcademica, $event) || (ctx_r1.unidadAcademica = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(96, RegistroVentanilla_Conditional_3_Conditional_96_Template, 2, 1, "p", 63);
    \u0275\u0275conditionalCreate(97, RegistroVentanilla_Conditional_3_Conditional_97_Template, 2, 1, "span", 48)(98, RegistroVentanilla_Conditional_3_Conditional_98_Template, 8, 0, "span", 54);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(99, "div", 52)(100, "label");
    \u0275\u0275text(101, "Fecha de los hechos:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(102, "app-datepicker", 64);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_app_datepicker_ngModelChange_102_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.fechaHechos, $event) || (ctx_r1.fechaHechos = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(103, RegistroVentanilla_Conditional_3_Conditional_103_Template, 2, 1, "span", 48);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(104, "h3", 35);
    \u0275\u0275text(105, "Datos del Denunciado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(106, "div", 36)(107, "div", 37)(108, "label");
    \u0275\u0275text(109, "Nombre del denunciado:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(110, "input", 65, 6);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_input_ngModelChange_110_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.nombreDenunciado, $event) || (ctx_r1.nombreDenunciado = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("keypress", function RegistroVentanilla_Conditional_3_Template_input_keypress_110_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.soloLetras($event));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(112, RegistroVentanilla_Conditional_3_Conditional_112_Template, 2, 1, "span", 48);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(113, "div", 37)(114, "label");
    \u0275\u0275text(115, "Primer Apellido del denunciado:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(116, "input", 66, 7);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_input_ngModelChange_116_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.apellido1Denunciado, $event) || (ctx_r1.apellido1Denunciado = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("keypress", function RegistroVentanilla_Conditional_3_Template_input_keypress_116_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.soloLetras($event));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(118, RegistroVentanilla_Conditional_3_Conditional_118_Template, 2, 1, "span", 48);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(119, "div", 36)(120, "div", 37)(121, "label");
    \u0275\u0275text(122, "Segundo Apellido del denunciado:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(123, "input", 67, 8);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_input_ngModelChange_123_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.apellido2Denunciado, $event) || (ctx_r1.apellido2Denunciado = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("keypress", function RegistroVentanilla_Conditional_3_Template_input_keypress_123_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.soloLetras($event));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(125, RegistroVentanilla_Conditional_3_Conditional_125_Template, 2, 1, "span", 48)(126, RegistroVentanilla_Conditional_3_Conditional_126_Template, 2, 0, "span", 54);
    \u0275\u0275elementEnd();
    \u0275\u0275element(127, "div", 37);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(128, "div", 37)(129, "label");
    \u0275\u0275text(130, "Descripci\xF3n de los hechos:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(131, "textarea", 68, 9);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_3_Template_textarea_ngModelChange_131_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.descripcion, $event) || (ctx_r1.descripcion = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(133, "div", 69);
    \u0275\u0275text(134);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(135, RegistroVentanilla_Conditional_3_Conditional_135_Template, 2, 1, "span", 48);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(136, "div", 37)(137, "label");
    \u0275\u0275text(138, "Adjunta archivos que sustenten tu queja (PDF, JPG, PNG, MP4, MP3) \u2014 puedes elegir varios:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(139, "div", 70);
    \u0275\u0275listener("click", function RegistroVentanilla_Conditional_3_Template_div_click_139_listener() {
      \u0275\u0275restoreView(_r4);
      const inputArchivos_r12 = \u0275\u0275reference(141);
      return \u0275\u0275resetView(inputArchivos_r12.click());
    })("dragover", function RegistroVentanilla_Conditional_3_Template_div_dragover_139_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onArrastreSobre($event));
    })("dragleave", function RegistroVentanilla_Conditional_3_Template_div_dragleave_139_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onArrastreSale());
    })("drop", function RegistroVentanilla_Conditional_3_Template_div_drop_139_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onArchivosSoltados($event));
    });
    \u0275\u0275elementStart(140, "input", 71, 10);
    \u0275\u0275listener("change", function RegistroVentanilla_Conditional_3_Template_input_change_140_listener($event) {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onArchivosSeleccionados($event));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(142, "span", 72);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(143, "svg", 73);
    \u0275\u0275element(144, "path", 74);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(145, "p", 75);
    \u0275\u0275text(146, "Arrastra tus archivos aqu\xED o ");
    \u0275\u0275elementStart(147, "strong");
    \u0275\u0275text(148, "haz clic para elegir");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(149, "p", 76);
    \u0275\u0275text(150, "PDF, JPG, PNG, MP4, MP3 \u2014 m\xE1ximo 30MB por archivo, 100MB en total");
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(151, RegistroVentanilla_Conditional_3_Conditional_151_Template, 5, 1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(152, "div", 77)(153, "button", 78);
    \u0275\u0275text(154);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(155, "p", 79);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(156, "svg", 24);
    \u0275\u0275element(157, "rect", 80)(158, "path", 81);
    \u0275\u0275elementEnd();
    \u0275\u0275text(159, " Los datos se manejan de forma confidencial. ");
    \u0275\u0275conditionalCreate(160, RegistroVentanilla_Conditional_3_Conditional_160_Template, 2, 1, "span", 82);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const nombreModel_r16 = \u0275\u0275reference(35);
    const apellido1Model_r17 = \u0275\u0275reference(41);
    const apellido2Model_r18 = \u0275\u0275reference(48);
    const correoModel_r19 = \u0275\u0275reference(54);
    const numeroBoletaEmpleadoModel_r20 = \u0275\u0275reference(79);
    const unidadAcademicaModel_r21 = \u0275\u0275reference(95);
    const nombreDenunciadoModel_r22 = \u0275\u0275reference(111);
    const apellido1DenunciadoModel_r23 = \u0275\u0275reference(117);
    const apellido2DenunciadoModel_r24 = \u0275\u0275reference(124);
    const descripcionModel_r25 = \u0275\u0275reference(132);
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(12);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.tipoDocumento);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r1.tiposDocumento);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.fechaRecepcionFisica);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.numeroOficio);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.ubicacionFisica);
    \u0275\u0275advance(4);
    \u0275\u0275classProp("input-invalid", ctx_r1.errorNombre && (nombreModel_r16.touched || ctx_r1.intentoEnviar));
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.nombre);
    \u0275\u0275property("maxlength", ctx_r1.nombreLongitudMaxima);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.errorNombre && (nombreModel_r16.touched || ctx_r1.intentoEnviar) ? 36 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("input-invalid", ctx_r1.errorApellido1 && (apellido1Model_r17.touched || ctx_r1.intentoEnviar));
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.apellido1);
    \u0275\u0275property("maxlength", ctx_r1.nombreLongitudMaxima);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.errorApellido1 && (apellido1Model_r17.touched || ctx_r1.intentoEnviar) ? 42 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("input-invalid", ctx_r1.errorApellido2 && (apellido2Model_r18.touched || ctx_r1.intentoEnviar));
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.apellido2);
    \u0275\u0275property("maxlength", ctx_r1.nombreLongitudMaxima);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.errorApellido2 && (apellido2Model_r18.touched || ctx_r1.intentoEnviar) ? 49 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("input-invalid", ctx_r1.errorCorreo && (correoModel_r19.touched || ctx_r1.intentoEnviar));
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.correo);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.errorCorreo && (correoModel_r19.touched || ctx_r1.intentoEnviar) ? 55 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("input-invalid", ctx_r1.errorFechaNacimiento && ctx_r1.intentoEnviar);
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.fechaNacimiento);
    \u0275\u0275property("min", ctx_r1.fechaNacimientoMinima)("max", ctx_r1.fechaNacimientoMaxima);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.errorFechaNacimiento && ctx_r1.intentoEnviar ? 61 : 62);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.tutorConfirmado ? 63 : -1);
    \u0275\u0275advance(7);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.identificacion);
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.identificacion);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("input-invalid", ctx_r1.errorBoleta && (numeroBoletaEmpleadoModel_r20.touched || ctx_r1.intentoEnviar));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", ctx_r1.etiquetaNumeroIdentificacion, ":");
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.numeroBoletaEmpleado);
    \u0275\u0275property("placeholder", ctx_r1.etiquetaNumeroIdentificacion)("maxlength", ctx_r1.boletaLongitudMaxima);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.errorBoleta && (numeroBoletaEmpleadoModel_r20.touched || ctx_r1.intentoEnviar) ? 80 : 81);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("input-invalid", ctx_r1.errorIdentificacion && ctx_r1.intentoEnviar);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r1.identificaciones.length < ctx_r1.identificacionCantidadMaxima ? 85 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.identificaciones.length ? 86 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.errorIdentificacion && ctx_r1.intentoEnviar ? 87 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275classProp("input-invalid", ctx_r1.errorUnidadAcademica && (unidadAcademicaModel_r21.touched || ctx_r1.intentoEnviar));
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.unidadAcademica);
    \u0275\u0275property("dependencias", ctx_r1.dependencias)("cargando", ctx_r1.cargandoDependencias);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.errorDependencias ? 96 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.errorUnidadAcademica && (unidadAcademicaModel_r21.touched || ctx_r1.intentoEnviar) && !ctx_r1.errorDependencias ? 97 : !ctx_r1.errorDependencias ? 98 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("input-invalid", ctx_r1.errorFechaHechos && ctx_r1.intentoEnviar);
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.fechaHechos);
    \u0275\u0275property("max", ctx_r1.fechaMaxima);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.errorFechaHechos && ctx_r1.intentoEnviar ? 103 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275classProp("input-invalid", ctx_r1.errorNombreDenunciado && (nombreDenunciadoModel_r22.touched || ctx_r1.intentoEnviar));
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.nombreDenunciado);
    \u0275\u0275property("maxlength", ctx_r1.nombreLongitudMaxima);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.errorNombreDenunciado && (nombreDenunciadoModel_r22.touched || ctx_r1.intentoEnviar) ? 112 : -1);
    \u0275\u0275advance();
    \u0275\u0275classProp("input-invalid", ctx_r1.errorApellido1Denunciado && (apellido1DenunciadoModel_r23.touched || ctx_r1.intentoEnviar));
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.apellido1Denunciado);
    \u0275\u0275property("maxlength", ctx_r1.nombreLongitudMaxima);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.errorApellido1Denunciado && (apellido1DenunciadoModel_r23.touched || ctx_r1.intentoEnviar) ? 118 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("input-invalid", ctx_r1.errorApellido2Denunciado && (apellido2DenunciadoModel_r24.touched || ctx_r1.intentoEnviar));
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.apellido2Denunciado);
    \u0275\u0275property("maxlength", ctx_r1.nombreLongitudMaxima);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.errorApellido2Denunciado && (apellido2DenunciadoModel_r24.touched || ctx_r1.intentoEnviar) ? 125 : 126);
    \u0275\u0275advance(3);
    \u0275\u0275classProp("input-invalid", ctx_r1.errorDescripcion && (descripcionModel_r25.touched || ctx_r1.intentoEnviar));
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.descripcion);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", ctx_r1.descripcion.length, " caracteres ");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.errorDescripcion && (descripcionModel_r25.touched || ctx_r1.intentoEnviar) ? 135 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275classProp("dropzone--activo", ctx_r1.arrastrandoArchivo);
    \u0275\u0275advance(12);
    \u0275\u0275conditional(ctx_r1.evidencias.length ? 151 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r1.cargando);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.cargando ? "Registrando\u2026" : "Registrar Queja", " ");
    \u0275\u0275advance(6);
    \u0275\u0275conditional(ctx_r1.avisoAceptado ? 160 : -1);
  }
}
function RegistroVentanilla_Conditional_4_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 22);
    \u0275\u0275text(1, " Por tratarse de una persona menor de 14 a\xF1os, este tr\xE1mite debe completarlo su padre, madre o tutor legal. Los datos capturados arriba (nombre, correo, etc.) corresponden al menor; aqu\xED abajo captura tus propios datos como responsable. ");
    \u0275\u0275elementEnd();
  }
}
function RegistroVentanilla_Conditional_4_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 22);
    \u0275\u0275text(1, "Se requiere un responsable legal para solicitantes menores de edad.");
    \u0275\u0275elementEnd();
  }
}
function RegistroVentanilla_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 14)(1, "div", 100)(2, "div", 101)(3, "span", 102);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(4, "svg", 73);
    \u0275\u0275element(5, "path", 103)(6, "circle", 104)(7, "path", 105)(8, "path", 106);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(9, "h3");
    \u0275\u0275text(10, "Informaci\xF3n del Tutor / Adulto Responsable");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "button", 107);
    \u0275\u0275listener("click", function RegistroVentanilla_Conditional_4_Template_button_click_11_listener() {
      \u0275\u0275restoreView(_r26);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cancelarTutor());
    });
    \u0275\u0275text(12, "\u2715");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "div", 108);
    \u0275\u0275conditionalCreate(14, RegistroVentanilla_Conditional_4_Conditional_14_Template, 2, 0, "p", 22)(15, RegistroVentanilla_Conditional_4_Conditional_15_Template, 2, 0, "p", 22);
    \u0275\u0275elementStart(16, "div", 37)(17, "label");
    \u0275\u0275text(18, "Nombre(s):");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "input", 109);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_4_Template_input_ngModelChange_19_listener($event) {
      \u0275\u0275restoreView(_r26);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.tutor.nombre, $event) || (ctx_r1.tutor.nombre = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("keypress", function RegistroVentanilla_Conditional_4_Template_input_keypress_19_listener($event) {
      \u0275\u0275restoreView(_r26);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.soloLetras($event));
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(20, "div", 36)(21, "div", 37)(22, "label");
    \u0275\u0275text(23, "Primer Apellido:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "input", 110);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_4_Template_input_ngModelChange_24_listener($event) {
      \u0275\u0275restoreView(_r26);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.tutor.apellido1, $event) || (ctx_r1.tutor.apellido1 = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("keypress", function RegistroVentanilla_Conditional_4_Template_input_keypress_24_listener($event) {
      \u0275\u0275restoreView(_r26);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.soloLetras($event));
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(25, "div", 37)(26, "label");
    \u0275\u0275text(27, "Segundo Apellido:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "input", 111);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_4_Template_input_ngModelChange_28_listener($event) {
      \u0275\u0275restoreView(_r26);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.tutor.apellido2, $event) || (ctx_r1.tutor.apellido2 = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("keypress", function RegistroVentanilla_Conditional_4_Template_input_keypress_28_listener($event) {
      \u0275\u0275restoreView(_r26);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.soloLetras($event));
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(29, "div", 37)(30, "label");
    \u0275\u0275text(31, "Parentesco:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(32, "select", 112);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_4_Template_select_ngModelChange_32_listener($event) {
      \u0275\u0275restoreView(_r26);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.tutor.parentesco, $event) || (ctx_r1.tutor.parentesco = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementStart(33, "option");
    \u0275\u0275text(34, "Padre");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(35, "option");
    \u0275\u0275text(36, "Madre");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "option");
    \u0275\u0275text(38, "Tutor legal");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(39, "div", 36)(40, "div", 37)(41, "label");
    \u0275\u0275text(42, "Correo Electr\xF3nico:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(43, "input", 113);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_4_Template_input_ngModelChange_43_listener($event) {
      \u0275\u0275restoreView(_r26);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.tutor.correo, $event) || (ctx_r1.tutor.correo = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(44, "div", 37)(45, "label");
    \u0275\u0275text(46, "Tel\xE9fono de Contacto (10 d\xEDgitos):");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(47, "input", 114);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroVentanilla_Conditional_4_Template_input_ngModelChange_47_listener($event) {
      \u0275\u0275restoreView(_r26);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.tutor.telefono, $event) || (ctx_r1.tutor.telefono = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275listener("keypress", function RegistroVentanilla_Conditional_4_Template_input_keypress_47_listener($event) {
      \u0275\u0275restoreView(_r26);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.soloDigitos($event));
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(48, "div", 115)(49, "button", 29);
    \u0275\u0275listener("click", function RegistroVentanilla_Conditional_4_Template_button_click_49_listener() {
      \u0275\u0275restoreView(_r26);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.confirmarTutor());
    });
    \u0275\u0275text(50, "Confirmar Datos");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(51, "button", 30);
    \u0275\u0275listener("click", function RegistroVentanilla_Conditional_4_Template_button_click_51_listener() {
      \u0275\u0275restoreView(_r26);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cancelarTutor());
    });
    \u0275\u0275text(52, "Cancelar");
    \u0275\u0275elementEnd()()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(14);
    \u0275\u0275conditional(ctx_r1.esMenorDe14 ? 14 : 15);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.tutor.nombre);
    \u0275\u0275property("maxlength", ctx_r1.nombreLongitudMaxima);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.tutor.apellido1);
    \u0275\u0275property("maxlength", ctx_r1.nombreLongitudMaxima);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.tutor.apellido2);
    \u0275\u0275property("maxlength", ctx_r1.nombreLongitudMaxima);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.tutor.parentesco);
    \u0275\u0275advance(11);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.tutor.correo);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.tutor.telefono);
  }
}
var CARACTER_NOMBRE = /[A-Za-zÁÉÍÓÚÜÑáéíóúüñ '\-]/;
var TIPOS_DOCUMENTO_VENTANILLA = [
  { valor: "FORMATO_QUEJA", etiqueta: "Formato de queja llenado en ventanilla" },
  { valor: "ESCRITO_LIBRE", etiqueta: "Escrito libre" },
  { valor: "OFICIO", etiqueta: "Oficio" },
  { valor: "COMPARECENCIA", etiqueta: "Comparecencia (declaraci\xF3n verbal)" },
  { valor: "OTRO", etiqueta: "Otro" }
];
var RegistroVentanilla = class _RegistroVentanilla {
  catalogoService;
  quejaService;
  toast;
  router;
  cdr;
  // Datos de la recepción física
  tiposDocumento = TIPOS_DOCUMENTO_VENTANILLA;
  tipoDocumento = "FORMATO_QUEJA";
  numeroOficio = "";
  fechaRecepcionFisica = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  ubicacionFisica = "";
  /** Si la queja se creó pero no se pudo marcar como de ventanilla (se avisa en el acuse). */
  avisoVentanilla = "";
  // Datos del quejoso
  nombre = "";
  apellido1 = "";
  apellido2 = "";
  correo = "";
  /** true cuando el correo tecleado ya tiene cuenta de seguimiento. */
  correoYaRegistrado = false;
  verificandoCorreo = false;
  fechaNacimiento = "";
  identificacion = "alumno";
  numeroBoletaEmpleado = "";
  // Datos de la queja
  unidadAcademica = "";
  fechaHechos = "";
  // Catálogo real de dependencias (para "lugar donde sucedieron los hechos") — se muestra
  // completo (las 208), sin filtrar por tipo, por decisión explícita del usuario.
  dependencias = [];
  cargandoDependencias = true;
  errorDependencias = "";
  // Datos del denunciado
  nombreDenunciado = "";
  apellido1Denunciado = "";
  apellido2Denunciado = "";
  descripcion = "";
  /** Archivos que sustentan la queja, con su miniatura. */
  evidencias = [];
  /** Controla el estado visual del dropzone mientras se arrastra un archivo encima. */
  arrastrandoArchivo = false;
  /**
   * Foto o escaneo de la credencial de la comunidad politécnica — hasta 2 imágenes
   * (frente y reverso). Viajan como archivos de evidencia más, renombrados con el prefijo
   * "IDENTIFICACION_": el backend los reconoce por ese prefijo y les aplica reglas más
   * estrictas (solo JPG/PNG, 3MB, máximo 2) que al resto de evidencias, y los guarda con
   * tipo = "IDENTIFICACION" para que el recepcionista los distinga.
   */
  identificaciones = [];
  // Aviso de privacidad — se muestra al entrar y bloquea el formulario hasta que se acepta.
  mostrarAvisoPrivacidad = true;
  avisoPrivacidadVersion = "";
  // Menor de edad / tutor
  mostrarModalTutor = false;
  /** true una vez que se confirmaron los datos del tutor — para mostrar el banner de
   * confirmación persistente que pidió el usuario ("que yo sepa que tengo datos de tutor"). */
  tutorConfirmado = false;
  /** true cuando el quejoso tiene menos de 14 años -- regla de negocio: no se bloquea la
   * queja por completo (el tutor puede presentarla), pero se bloquea el "autoregistro
   * directo": la mensajería deja explícito que debe completarla el padre/madre/tutor, y los
   * datos de tutor son obligatorios sin excepción (ver enviarQueja()). */
  esMenorDe14 = false;
  tutor = {
    nombre: "",
    apellido1: "",
    apellido2: "",
    parentesco: "Padre",
    correo: "",
    telefono: ""
  };
  cargando = false;
  /** true tras el primer intento de envío — a partir de ahí se muestran los mensajes de
   * validación de cada campo, aunque el usuario no lo haya "tocado" todavía. */
  intentoEnviar = false;
  quejaCreada = null;
  // ---- Límites que también ve la plantilla (espejo del backend, ver reglas-queja.ts) ----
  fechaMaxima = hoyIso();
  fechaNacimientoMinima = FECHA_NACIMIENTO_MINIMA;
  fechaNacimientoMaxima = fechaNacimientoMaxima();
  nombreLongitudMaxima = NOMBRE_LONGITUD_MAXIMA;
  boletaLongitudMaxima = NUMERO_IDENTIFICACION_LONGITUD_MAXIMA;
  descripcionLongitudMinima = DESCRIPCION_LONGITUD_MINIMA;
  identificacionCantidadMaxima = IDENTIFICACION_CANTIDAD_MAXIMA;
  constructor(catalogoService, quejaService, toast, router, cdr) {
    this.catalogoService = catalogoService;
    this.quejaService = quejaService;
    this.toast = toast;
    this.router = router;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.catalogoService.listarDependencias().subscribe({
      next: (dependencias) => {
        this.dependencias = dependencias;
        this.cargandoDependencias = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargandoDependencias = false;
        this.errorDependencias = "No se pudo cargar el cat\xE1logo de dependencias. Intenta recargar la p\xE1gina.";
        this.toast.error(this.errorDependencias);
        this.cdr.detectChanges();
      }
    });
  }
  ngOnDestroy() {
    [...this.identificaciones, ...this.evidencias].forEach((item) => this.liberarUrl(item));
  }
  // =========================================================================================
  // Aviso de privacidad
  // =========================================================================================
  onAvisoAceptado(version) {
    this.avisoPrivacidadVersion = version;
    this.mostrarAvisoPrivacidad = false;
    this.cdr.detectChanges();
  }
  get avisoAceptado() {
    return this.avisoPrivacidadVersion !== "";
  }
  // =========================================================================================
  // Filtros de captura — impiden teclear caracteres que el campo no admite
  // =========================================================================================
  /** Bloquea todo lo que no sea letra, espacio, apóstrofe o guion en nombres y apellidos. */
  soloLetras(event) {
    if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !CARACTER_NOMBRE.test(event.key)) {
      event.preventDefault();
    }
  }
  /** Bloquea todo lo que no sea dígito en boleta / número de empleado. */
  soloDigitos(event) {
    if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !/[0-9]/.test(event.key)) {
      event.preventDefault();
    }
  }
  // =========================================================================================
  // Validaciones por campo — el mensaje que se pinta debajo de cada input
  // =========================================================================================
  get errorNombre() {
    return validarNombre(this.nombre, "tu nombre", true);
  }
  get errorApellido1() {
    return validarNombre(this.apellido1, "tu primer apellido", true);
  }
  get errorApellido2() {
    return validarNombre(this.apellido2, "tu segundo apellido", false);
  }
  get errorCorreo() {
    return validarCorreo(this.correo);
  }
  get errorFechaNacimiento() {
    if (!this.fechaNacimiento) {
      return "Selecciona tu fecha de nacimiento.";
    }
    if (!esFechaValida(this.fechaNacimiento)) {
      return "La fecha de nacimiento no es una fecha v\xE1lida. Vuelve a seleccionarla.";
    }
    if (this.fechaNacimiento < this.fechaNacimientoMinima) {
      return "La fecha de nacimiento no puede ser anterior al 1 de enero de 1920.";
    }
    if (this.fechaNacimiento > this.fechaNacimientoMaxima) {
      return `La fecha de nacimiento no puede ser posterior al 31 de diciembre de ${(/* @__PURE__ */ new Date()).getFullYear() - 1}.`;
    }
    return null;
  }
  get errorBoleta() {
    const etiqueta = this.etiquetaNumeroIdentificacion;
    if (!this.numeroBoletaEmpleado) {
      return `Escribe tu ${etiqueta.toLowerCase()}.`;
    }
    if (!REGEX_NUMERO_IDENTIFICACION.test(this.numeroBoletaEmpleado)) {
      return `${etiqueta} solo admite n\xFAmeros, con un m\xE1ximo de ${this.boletaLongitudMaxima} d\xEDgitos.`;
    }
    return null;
  }
  get errorIdentificacion() {
    return this.identificaciones.length === 0 ? "Adjunta la imagen de tu identificaci\xF3n oficial." : null;
  }
  get errorUnidadAcademica() {
    return this.unidadAcademica ? null : "Busca y elige de la lista el lugar donde sucedieron los hechos.";
  }
  get errorFechaHechos() {
    if (!this.fechaHechos) {
      return "Selecciona la fecha de los hechos.";
    }
    if (!esFechaValida(this.fechaHechos)) {
      return "La fecha de los hechos no es una fecha v\xE1lida. Vuelve a seleccionarla.";
    }
    if (this.fechaHechos > this.fechaMaxima) {
      return "La fecha de los hechos no puede ser posterior a hoy.";
    }
    if (this.fechaNacimiento && this.fechaHechos < this.fechaNacimiento) {
      return "La fecha de los hechos no puede ser anterior a tu fecha de nacimiento.";
    }
    return null;
  }
  get errorNombreDenunciado() {
    return validarNombre(this.nombreDenunciado, "el nombre del denunciado", false);
  }
  get errorApellido1Denunciado() {
    return validarNombre(this.apellido1Denunciado, "el primer apellido del denunciado", false);
  }
  get errorApellido2Denunciado() {
    return validarNombre(this.apellido2Denunciado, "el segundo apellido del denunciado", false);
  }
  get errorDescripcion() {
    const texto = this.descripcion.trim();
    if (!texto) {
      return "Describe brevemente los hechos.";
    }
    if (texto.length < this.descripcionLongitudMinima) {
      return `Describe los hechos con al menos ${this.descripcionLongitudMinima} caracteres.`;
    }
    return null;
  }
  /** Todos los errores del formulario, en el orden en que aparecen en pantalla. */
  get erroresFormulario() {
    return [
      this.errorNombre,
      this.errorApellido1,
      this.errorApellido2,
      this.errorCorreo,
      this.errorFechaNacimiento,
      this.errorBoleta,
      this.errorIdentificacion,
      this.errorUnidadAcademica,
      this.errorFechaHechos,
      this.errorNombreDenunciado,
      this.errorApellido1Denunciado,
      this.errorApellido2Denunciado,
      this.errorDescripcion
    ];
  }
  /** Cambia según "alumno"/"empleado" para que el campo tenga el rótulo correcto. */
  get etiquetaNumeroIdentificacion() {
    return this.identificacion === "alumno" ? "N\xFAmero de boleta" : "N\xFAmero de empleado";
  }
  // =========================================================================================
  // Identificación oficial — solo JPG/PNG, 3MB, hasta 2 imágenes
  // =========================================================================================
  onIdentificacionSeleccionada(event) {
    const input = event.target;
    if (!input.files)
      return;
    this.procesarIdentificaciones(Array.from(input.files));
    input.value = "";
  }
  procesarIdentificaciones(nuevos) {
    for (const archivo of nuevos) {
      if (this.identificaciones.length >= IDENTIFICACION_CANTIDAD_MAXIMA) {
        this.toast.error(`Solo puedes adjuntar hasta ${IDENTIFICACION_CANTIDAD_MAXIMA} im\xE1genes de tu identificaci\xF3n.`);
        return;
      }
      if (!this.esImagenPermitida(archivo)) {
        this.toast.error(`"${archivo.name}" no es una imagen. La identificaci\xF3n oficial debe ser JPG o PNG (ya no se acepta PDF).`);
        continue;
      }
      if (archivo.size > IDENTIFICACION_TAMANIO_MAXIMO) {
        this.toast.error(`"${archivo.name}" pesa ${formatearTamanio(archivo.size)}; el m\xE1ximo para la identificaci\xF3n es 3MB.`);
        continue;
      }
      this.identificaciones.push(this.conMiniatura(archivo));
    }
  }
  quitarIdentificacion(indice) {
    const [quitado] = this.identificaciones.splice(indice, 1);
    this.liberarUrl(quitado);
  }
  /** Comprueba tipo MIME y extensión: algunos navegadores no reportan el MIME correctamente. */
  esImagenPermitida(archivo) {
    const extension = "." + (archivo.name.split(".").pop()?.toLowerCase() ?? "");
    return IDENTIFICACION_TIPOS_MIME.includes(archivo.type) || IDENTIFICACION_EXTENSIONES.includes(extension);
  }
  // =========================================================================================
  // Evidencias
  // =========================================================================================
  onArchivosSeleccionados(event) {
    const input = event.target;
    if (!input.files)
      return;
    this.procesarArchivosNuevos(Array.from(input.files));
    input.value = "";
  }
  onArrastreSobre(event) {
    event.preventDefault();
    this.arrastrandoArchivo = true;
  }
  onArrastreSale() {
    this.arrastrandoArchivo = false;
  }
  onArchivosSoltados(event) {
    event.preventDefault();
    this.arrastrandoArchivo = false;
    if (!event.dataTransfer?.files)
      return;
    this.procesarArchivosNuevos(Array.from(event.dataTransfer.files));
  }
  /** Valida tipo, tamaño individual y tamaño total ANTES de agregar cada archivo a la
   * lista — así el usuario se entera al momento (con un toast claro) en vez de enviarlo
   * todo y esperar a que el servidor lo rechace con un 400/413. */
  procesarArchivosNuevos(nuevos) {
    for (const archivo of nuevos) {
      const extension = "." + (archivo.name.split(".").pop()?.toLowerCase() ?? "");
      if (!EVIDENCIA_EXTENSIONES.includes(extension)) {
        this.toast.error(`"${archivo.name}" no es un tipo de archivo permitido. Usa PDF, JPG, PNG, MP4 o MP3.`);
        continue;
      }
      if (archivo.size > EVIDENCIA_TAMANIO_MAXIMO) {
        this.toast.error(`"${archivo.name}" pesa ${formatearTamanio(archivo.size)}; el m\xE1ximo por archivo es 30MB.`);
        continue;
      }
      const tamanioActual = this.evidencias.reduce((total, a) => total + a.archivo.size, 0);
      if (tamanioActual + archivo.size > EVIDENCIA_TAMANIO_TOTAL_MAXIMO) {
        this.toast.error(`No se agreg\xF3 "${archivo.name}": el total de archivos adjuntos no puede superar 100MB.`);
        continue;
      }
      this.evidencias.push(this.conMiniatura(archivo));
    }
  }
  quitarArchivo(indice) {
    const [quitado] = this.evidencias.splice(indice, 1);
    this.liberarUrl(quitado);
  }
  // =========================================================================================
  // Miniaturas
  // =========================================================================================
  conMiniatura(archivo) {
    const esImagen = archivo.type.startsWith("image/");
    return {
      archivo,
      esImagen,
      url: esImagen ? URL.createObjectURL(archivo) : null
    };
  }
  liberarUrl(item) {
    if (item?.url) {
      URL.revokeObjectURL(item.url);
    }
  }
  /** Etiqueta corta del tipo de archivo, para los adjuntos que no son imagen. */
  tipoArchivo(archivo) {
    const extension = (archivo.name.split(".").pop() ?? "").toUpperCase();
    return extension || "ARCHIVO";
  }
  formatearTamanio(bytes) {
    return formatearTamanio(bytes);
  }
  // =========================================================================================
  // Menor de edad / tutor
  // =========================================================================================
  onFechaNacimientoChange() {
    if (!this.fechaNacimiento)
      return;
    if (this.errorFechaNacimiento) {
      this.toast.error(this.errorFechaNacimiento);
      return;
    }
    const edad = this.calcularEdad(this.fechaNacimiento);
    if (edad < 18) {
      this.esMenorDe14 = edad < 14;
      this.tutorConfirmado = false;
      this.mostrarModalTutor = true;
      this.toast.advertencia(this.esMenorDe14 ? "Por tratarse de una persona menor de 14 a\xF1os, este formulario debe completarlo su padre, madre o tutor." : "Por ser menor de edad, necesitamos los datos de un tutor o adulto responsable.");
    } else {
      this.esMenorDe14 = false;
      this.tutorConfirmado = false;
    }
  }
  calcularEdad(fechaISO) {
    const nacimiento = new Date(fechaISO);
    const hoy = /* @__PURE__ */ new Date();
    let edad = hoy.getFullYear() - nacimiento.getFullYear();
    const mes = hoy.getMonth() - nacimiento.getMonth();
    if (mes < 0 || mes === 0 && hoy.getDate() < nacimiento.getDate()) {
      edad--;
    }
    return edad;
  }
  confirmarTutor() {
    if (!this.tutor.nombre || !this.tutor.apellido1 || !this.tutor.parentesco) {
      this.toast.advertencia("Completa al menos nombre, primer apellido y parentesco del tutor.");
      return;
    }
    const errorNombreTutor = validarNombre(this.tutor.nombre, "el nombre del tutor", true) ?? validarNombre(this.tutor.apellido1, "el primer apellido del tutor", true) ?? validarNombre(this.tutor.apellido2, "el segundo apellido del tutor", false);
    if (errorNombreTutor) {
      this.toast.advertencia(errorNombreTutor);
      return;
    }
    if (this.tutor.correo) {
      const errorCorreoTutor = validarCorreo(this.tutor.correo);
      if (errorCorreoTutor) {
        this.toast.advertencia(`Correo del tutor: ${errorCorreoTutor}`);
        return;
      }
    }
    if (this.tutor.telefono && !/^\d{10}$/.test(this.tutor.telefono)) {
      this.toast.advertencia("El tel\xE9fono del tutor debe tener exactamente 10 d\xEDgitos.");
      return;
    }
    this.mostrarModalTutor = false;
    this.tutorConfirmado = true;
    this.toast.exito("Datos del tutor guardados.");
  }
  cancelarTutor() {
    this.mostrarModalTutor = false;
  }
  editarTutor() {
    this.mostrarModalTutor = true;
  }
  // =========================================================================================
  // Envío
  // =========================================================================================
  enviarQueja() {
    this.intentoEnviar = true;
    if (!this.avisoAceptado) {
      this.mostrarAvisoPrivacidad = true;
      this.toast.error("Debes leer y aceptar el aviso de privacidad antes de enviar tu queja.");
      return;
    }
    const primerError = this.erroresFormulario.find((error) => error !== null);
    if (primerError) {
      this.toast.error(primerError);
      return;
    }
    if (this.mostrarModalTutor) {
      this.toast.advertencia("Termina de confirmar o cancelar los datos del tutor antes de continuar.");
      return;
    }
    if (this.calcularEdad(this.fechaNacimiento) < 18 && !this.tutorConfirmado) {
      this.toast.error("Debes completar los datos del tutor o adulto responsable antes de enviar la queja.");
      this.mostrarModalTutor = true;
      return;
    }
    this.cargando = true;
    this.quejaService.registrarQuejaPublica({
      nombre: this.nombre.trim(),
      apellido1: this.apellido1.trim(),
      apellido2: this.apellido2.trim() || void 0,
      correo: this.correo.trim().toLowerCase(),
      fechaNacimiento: this.fechaNacimiento,
      tipoIdentificacion: this.identificacion,
      numeroIdentificacion: this.numeroBoletaEmpleado,
      unidadAcademicaClave: this.unidadAcademica,
      fechaHechos: this.fechaHechos,
      nombreDenunciado: this.nombreDenunciado.trim() || void 0,
      apellido1Denunciado: this.apellido1Denunciado.trim() || void 0,
      apellido2Denunciado: this.apellido2Denunciado.trim() || void 0,
      descripcion: this.descripcion.trim(),
      archivos: this.archivosParaEnviar(),
      avisoPrivacidadAceptado: true,
      avisoPrivacidadVersion: this.avisoPrivacidadVersion,
      tutor: this.tutorConfirmado ? this.tutor : void 0
    }).subscribe({
      next: (queja) => {
        this.marcarComoVentanilla(queja);
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.cargando = false;
        const mensaje = err?.error?.mensaje ?? "No se pudo registrar la queja. Intenta de nuevo.";
        this.toast.error(mensaje);
        this.cdr.detectChanges();
      }
    });
  }
  /**
   * Las credenciales viajan renombradas con el prefijo IDENTIFICACION_ dentro de la misma
   * lista de archivos: es lo que le permite al backend aplicarles reglas más estrictas y
   * guardarlas con tipo = "IDENTIFICACION" sin cambiar el contrato multipart del endpoint.
   */
  archivosParaEnviar() {
    const credenciales = this.identificaciones.map((item) => new File([item.archivo], `${PREFIJO_IDENTIFICACION}${item.archivo.name}`, {
      type: item.archivo.type
    }));
    return [...credenciales, ...this.evidencias.map((item) => item.archivo)];
  }
  /** Abre una ventana con un acuse imprimible (el usuario lo guarda como PDF desde el
   * diálogo de impresión del navegador — no hay generación de PDF en servidor todavía). */
  descargarAcuse() {
    if (!this.quejaCreada)
      return;
    const ventana = window.open("", "_blank", "width=650,height=800");
    if (!ventana) {
      this.toast.error("Tu navegador bloque\xF3 la ventana de impresi\xF3n. Habilita las ventanas emergentes para descargar el acuse.");
      return;
    }
    const q = this.quejaCreada;
    const folio = this.escaparHtml(q.numeroFolio);
    const correo = this.escaparHtml(q.correoInstitucional);
    const motivo = q.motivo ? this.escaparHtml(q.motivo) : "";
    const nombreCompleto = [q.nombreQuejoso, q.apellido1Quejoso, q.apellido2Quejoso].filter(Boolean).map((v) => this.escaparHtml(v)).join(" ");
    const fechaNacimiento = q.fechaNacimientoQuejoso ? this.formatearFecha(q.fechaNacimientoQuejoso) : "";
    const tipoIdentificacion = q.tipoIdentificacionQuejoso === "empleado" ? "Personal administrativo (empleado)" : "Alumno";
    const identificacion = q.numeroIdentificacionQuejoso ? `${q.tipoIdentificacionQuejoso === "empleado" ? "N\xFAm. de empleado" : "N\xFAm. de boleta"}: ${this.escaparHtml(q.numeroIdentificacionQuejoso)}` : "";
    const unidadAcademica = q.unidadAcademicaClave ? this.escaparHtml(q.unidadAcademicaClave) : "";
    const fechaHechos = q.fechaHechos ? this.formatearFecha(q.fechaHechos) : "";
    const denunciado = [q.nombreDenunciado, q.apellido1Denunciado, q.apellido2Denunciado].filter(Boolean).map((v) => this.escaparHtml(v)).join(" ");
    const descripcion = q.descripcion ? this.escaparHtml(q.descripcion).replace(/\n/g, "<br>") : "";
    const fechaEmision = (/* @__PURE__ */ new Date()).toLocaleString("es-MX", {
      dateStyle: "long",
      timeStyle: "short"
    });
    const nombresEvidencias = [
      ...this.identificaciones.map((item) => `${PREFIJO_IDENTIFICACION}${item.archivo.name}`),
      ...this.evidencias.map((item) => item.archivo.name)
    ];
    const evidenciasHtml = nombresEvidencias.length ? `<ul class="lista">${nombresEvidencias.map((n) => `<li>${this.escaparHtml(n)}</li>`).join("")}</ul>` : '<p class="vacio">Sin archivos adjuntos.</p>';
    const fila = (etiqueta, valor) => valor ? `<tr><td>${etiqueta}</td><td>${valor}</td></tr>` : "";
    const tutorHtml = this.tutorConfirmado ? `
        <h2 class="seccion">Tutor / adulto responsable</h2>
        <table>
          ${fila("Nombre", this.escaparHtml([this.tutor.nombre, this.tutor.apellido1, this.tutor.apellido2].filter(Boolean).join(" ")))}
          ${fila("Parentesco", this.escaparHtml(this.tutor.parentesco))}
          ${fila("Correo", this.tutor.correo ? this.escaparHtml(this.tutor.correo) : "")}
          ${fila("Tel\xE9fono", this.tutor.telefono ? this.escaparHtml(this.tutor.telefono) : "")}
        </table>` : "";
    ventana.document.write(`
      <html>
        <head>
          <title>Acuse de Recibo - ${folio}</title>
          <style>
            * { box-sizing: border-box; }
            body {
              font-family: 'Segoe UI', Arial, sans-serif; padding: 0; margin: 0; color: #1a1a1a;
              background: #f5f5f5;
            }
            .hoja { max-width: 680px; margin: 24px auto; background: #fff; padding: 40px 44px; }
            .membrete {
              display: flex; align-items: center; gap: 14px; border-bottom: 3px solid #6c1d45;
              padding-bottom: 16px; margin-bottom: 24px;
            }
            .membrete .escudo {
              width: 44px; height: 44px; border-radius: 50%; background: #6c1d45; color: #fff;
              display: flex; align-items: center; justify-content: center; font-weight: 700;
              font-size: 1.1rem; flex-shrink: 0;
            }
            .membrete h1 { color: #6c1d45; font-size: 1.15rem; margin: 0; line-height: 1.3; }
            .membrete p { margin: 2px 0 0; font-size: 0.8rem; color: #666; }
            .titulo-doc {
              text-align: center; text-transform: uppercase; letter-spacing: 1px;
              font-size: 0.85rem; color: #666; margin-bottom: 4px;
            }
            .folio {
              font-size: 1.7rem; font-weight: 700; letter-spacing: 1.5px; margin: 8px 0 8px;
              border: 2px solid #6c1d45; padding: 14px; text-align: center; border-radius: 10px;
              color: #6c1d45; background: #f7eef1;
            }
            .estatus {
              display: block; width: fit-content; margin: 0 auto 28px; padding: 4px 14px;
              border-radius: 999px; font-size: 0.72rem; font-weight: 700; text-transform: uppercase;
              letter-spacing: 0.04em; background: #e3f2fd; color: #1565c0;
            }
            h2.seccion {
              font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.6px; color: #9d2449;
              border-bottom: 1px solid #eee; padding-bottom: 6px; margin: 22px 0 8px;
            }
            table { width: 100%; border-collapse: collapse; }
            td { padding: 7px 4px; border-bottom: 1px solid #f0f0f0; font-size: 0.88rem; }
            td:first-child { font-weight: 600; width: 220px; color: #444; }
            .descripcion {
              font-size: 0.88rem; line-height: 1.6; background: #fafafa; border: 1px solid #eee;
              border-radius: 6px; padding: 12px 14px; margin: 0; white-space: pre-line;
            }
            .lista { margin: 0; padding-left: 18px; font-size: 0.85rem; line-height: 1.7; }
            .vacio { font-size: 0.85rem; color: #999; margin: 4px 0; }
            .pie {
              margin-top: 34px; font-size: 0.75rem; color: #666; border-top: 1px dashed #ccc;
              padding-top: 14px; line-height: 1.5;
            }
            .emision { margin-top: 6px; font-size: 0.72rem; color: #999; }
            @media print {
              body { background: #fff; }
              .hoja { margin: 0; padding: 20px; }
            }
          </style>
        </head>
        <body>
          <div class="hoja">
            <div class="membrete">
              <div class="escudo">DDP</div>
              <div>
                <h1>Defensor\xEDa de los Derechos Polit\xE9cnicos</h1>
                <p>Instituto Polit\xE9cnico Nacional</p>
              </div>
            </div>

            <p class="titulo-doc">Acuse de recibo de queja</p>
            <div class="folio">${folio}</div>
            <span class="estatus">Recibida</span>

            <h2 class="seccion">Datos del quejoso</h2>
            <table>
              ${fila("Nombre", nombreCompleto)}
              ${fila("Correo", correo)}
              ${fila("Fecha de nacimiento", fechaNacimiento)}
              ${fila("Calidad", this.escaparHtml(tipoIdentificacion))}
              ${fila("Identificaci\xF3n", identificacion)}
            </table>

            <h2 class="seccion">Lugar de los hechos</h2>
            <table>
              ${fila("Motivo", motivo)}
              ${fila("Lugar de los hechos", unidadAcademica)}
              ${fila("Fecha de los hechos", fechaHechos)}
              ${fila("Persona denunciada", denunciado)}
            </table>

            ${descripcion ? `<h2 class="seccion">Descripci\xF3n de los hechos</h2><p class="descripcion">${descripcion}</p>` : ""}

            <h2 class="seccion">Evidencias adjuntas</h2>
            ${evidenciasHtml}

            ${tutorHtml}

            <p class="pie">
              Guarda este acuse. Necesitar\xE1s el <strong>folio</strong> y el <strong>correo
              registrado</strong> para dar seguimiento a tu tr\xE1mite en cualquier momento desde
              "Consultar folio". Las quejas sobre hechos ocurridos hace m\xE1s de 90 d\xEDas no ser\xE1n
              procesadas.
            </p>
            <p class="emision">
              Documento generado el ${fechaEmision}.
              Aviso de privacidad aceptado, versi\xF3n ${this.escaparHtml(this.avisoPrivacidadVersion)}.
            </p>
          </div>
        </body>
      </html>
    `);
    ventana.document.close();
    ventana.focus();
    setTimeout(() => ventana.print(), 300);
  }
  escaparHtml(valor) {
    const div = document.createElement("div");
    div.textContent = valor;
    return div.innerHTML;
  }
  /** "2026-08-23" -> "23/08/2026" -- las fechas llegan en formato ISO (yyyy-mm-dd); se
   * muestran así en el acuse porque es el formato que espera cualquier persona que lo lea. */
  formatearFecha(fechaISO) {
    const partes = fechaISO.split("-");
    if (partes.length !== 3)
      return this.escaparHtml(fechaISO);
    const [anio, mes, dia] = partes;
    return `${dia}/${mes}/${anio}`;
  }
  /**
   * Al salir del campo de correo revisa si ya existe una cuenta con ese correo. Si existe,
   * el formulario muestra el aviso para que el quejoso inicie sesion y levante la queja
   * desde su panel (asi la queja queda ligada a su cuenta). No bloquea el envio.
   */
  /** En el portal avisaba si el correo ya tenía cuenta; en ventanilla no aplica. */
  verificarCorreoRegistrado() {
    this.correoYaRegistrado = false;
  }
  /** Segundo paso: guarda los datos del documento físico en la queja ya creada. */
  marcarComoVentanilla(queja) {
    this.quejaService.marcarVentanilla(queja.numeroFolio, {
      tipoDocumento: this.tipoDocumento,
      numeroOficio: this.numeroOficio.trim() || void 0,
      fechaRecepcionFisica: this.fechaRecepcionFisica,
      ubicacionFisica: this.ubicacionFisica.trim() || void 0
    }).subscribe({
      next: () => this.terminarRegistro(queja, ""),
      error: () => this.terminarRegistro(queja, "La queja qued\xF3 registrada, pero no se pudieron guardar los datos del documento f\xEDsico.")
    });
  }
  terminarRegistro(queja, aviso) {
    this.cargando = false;
    this.quejaCreada = queja;
    this.avisoVentanilla = aviso;
    this.toast.exito(`Queja registrada con el folio ${queja.numeroFolio}.`);
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.cdr.detectChanges();
  }
  /** Atenderla de inmediato: abre la validación (queda a nombre de quien la capturó). */
  atenderAhora() {
    if (this.quejaCreada) {
      this.router.navigate(["/validacion", this.quejaCreada.numeroFolio]);
    }
  }
  /** Limpia la pantalla para capturar otra queja. */
  registrarOtra() {
    window.location.reload();
  }
  static \u0275fac = function RegistroVentanilla_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _RegistroVentanilla)(\u0275\u0275directiveInject(CatalogoService), \u0275\u0275directiveInject(QuejaVentanillaService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _RegistroVentanilla, selectors: [["app-registro-ventanilla"]], decls: 5, vars: 3, consts: [["nombreModel", "ngModel"], ["apellido1Model", "ngModel"], ["apellido2Model", "ngModel"], ["correoModel", "ngModel"], ["numeroBoletaEmpleadoModel", "ngModel"], ["unidadAcademicaModel", "ngModel"], ["nombreDenunciadoModel", "ngModel"], ["apellido1DenunciadoModel", "ngModel"], ["apellido2DenunciadoModel", "ngModel"], ["descripcionModel", "ngModel"], ["inputArchivos", ""], ["inputIdentificacion", ""], [1, "contenedor"], [1, "card", "exito"], [1, "modal-overlay"], [3, "aceptado"], [1, "icono-exito"], ["viewBox", "0 0 24 24", "fill", "none", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M9 12l2 2 4-4"], ["cx", "12", "cy", "12", "r", "9"], [1, "folio"], [1, "nota"], [1, "aviso-inline"], ["type", "button", 1, "btn-secondary", "btn-acuse", 3, "click"], ["viewBox", "0 0 24 24", "fill", "none", "stroke-width", "1.8", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M6 9V3h12v6"], ["x", "4", "y", "9", "width", "16", "height", "8", "rx", "1.5"], ["d", "M6 17v4h12v-4"], [1, "acciones-ventanilla"], ["type", "button", 1, "btn-primary", 3, "click"], ["type", "button", 1, "btn-secondary", 3, "click"], ["routerLink", "/", 1, "link-invitado"], [1, "encabezado-formulario"], [1, "encabezado-formulario__subtitulo"], [1, "card", "formulario-queja", 3, "submit"], [1, "paso"], [1, "fila"], [1, "input-group"], ["for", "tipoDocumento"], ["id", "tipoDocumento", "name", "tipoDocumento", 3, "ngModelChange", "ngModel"], [3, "value"], ["for", "fechaRecepcionFisica"], ["id", "fechaRecepcionFisica", "type", "date", "name", "fechaRecepcionFisica", 3, "ngModelChange", "ngModel"], ["for", "numeroOficio"], ["id", "numeroOficio", "type", "text", "name", "numeroOficio", "maxlength", "60", 3, "ngModelChange", "ngModel"], ["for", "ubicacionFisica"], ["id", "ubicacionFisica", "type", "text", "name", "ubicacionFisica", "maxlength", "120", "placeholder", "Ej. Archivero 2, gaveta B", 3, "ngModelChange", "ngModel"], ["type", "text", "name", "nombre", "autocomplete", "given-name", "required", "", 3, "ngModelChange", "keypress", "ngModel", "maxlength"], [1, "mensaje-campo"], ["type", "text", "name", "apellido1", "autocomplete", "family-name", "required", "", 3, "ngModelChange", "keypress", "ngModel", "maxlength"], ["type", "text", "name", "apellido2", 3, "ngModelChange", "keypress", "ngModel", "maxlength"], ["type", "email", "name", "correo", "maxlength", "254", "autocomplete", "email", "required", "", 3, "ngModelChange", "blur", "ngModel"], [1, "input-group", "input-fecha"], ["name", "fechaNacimiento", 3, "ngModelChange", "cambio", "ngModel", "min", "max"], [1, "mensaje-ayuda"], [1, "banner-tutor"], [1, "radios"], ["type", "radio", "name", "identificacion", "value", "alumno", 3, "ngModelChange", "ngModel"], ["type", "radio", "name", "identificacion", "value", "empleado", 3, "ngModelChange", "ngModel"], ["type", "text", "name", "numeroBoletaEmpleado", "inputmode", "numeric", "required", "", 3, "ngModelChange", "keypress", "ngModel", "placeholder", "maxlength"], [1, "dropzone"], [1, "galeria-archivos"], ["name", "unidadAcademica", "required", "", 3, "ngModelChange", "ngModel", "dependencias", "cargando"], [1, "error"], ["name", "fechaHechos", 3, "ngModelChange", "ngModel", "max"], ["type", "text", "name", "nombreDenunciado", 3, "ngModelChange", "keypress", "ngModel", "maxlength"], ["type", "text", "name", "apellido1Denunciado", 3, "ngModelChange", "keypress", "ngModel", "maxlength"], ["type", "text", "name", "apellido2Denunciado", 3, "ngModelChange", "keypress", "ngModel", "maxlength"], ["rows", "5", "name", "descripcion", "required", "", 3, "ngModelChange", "ngModel"], [1, "contador-caracteres"], [1, "dropzone", 3, "click", "dragover", "dragleave", "drop"], ["type", "file", "multiple", "", "accept", ".pdf,.jpg,.jpeg,.png,.mp4,.mp3", "hidden", "", 3, "change"], [1, "dropzone__icono"], ["viewBox", "0 0 24 24", "fill", "none", "stroke-width", "1.6", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M16.5 6.5l-8 8a3 3 0 0 0 4.24 4.24l8.5-8.5a5 5 0 0 0-7.07-7.07l-8.5 8.5a7 7 0 0 0 9.9 9.9"], [1, "dropzone__texto"], [1, "dropzone__hint"], [1, "envio-formulario"], ["type", "submit", 1, "btn-primary", "btn-enviar-queja", 3, "disabled"], [1, "envio-formulario__nota"], ["x", "4", "y", "10", "width", "16", "height", "10", "rx", "2"], ["d", "M8 10V7a4 4 0 0 1 8 0v3"], [1, "envio-formulario__aviso"], [1, "banner-tutor__icono"], [1, "banner-tutor__texto"], ["type", "button", 1, "banner-tutor__editar", 3, "click"], [1, "dropzone", 3, "click"], ["type", "file", "multiple", "", "accept", "image/jpeg,image/png", "hidden", "", 3, "change"], ["x", "2.5", "y", "5", "width", "19", "height", "14", "rx", "2.5"], ["cx", "8.5", "cy", "11.5", "r", "2.2"], ["d", "M5 16c.6-1.7 2-2.6 3.5-2.6s2.9.9 3.5 2.6"], ["d", "M14.5 9.5h4"], ["d", "M14.5 13h4"], [1, "miniatura"], [3, "src", "alt"], [1, "miniatura__extension"], [1, "miniatura__nombre", 3, "title"], [1, "archivo-peso"], ["type", "button", 1, "miniatura__quitar", 3, "click"], [1, "galeria-titulo"], [1, "modal", "card"], [1, "modal-header"], ["aria-hidden", "true", 1, "modal-header__icono"], ["d", "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"], ["cx", "9", "cy", "7", "r", "4"], ["d", "M22 21v-2a4 4 0 0 0-3-3.87"], ["d", "M16 3.13a4 4 0 0 1 0 7.75"], ["type", "button", "aria-label", "Cerrar", 1, "modal-cerrar", 3, "click"], [1, "modal-body"], ["type", "text", "name", "tutorNombre", "required", "", 3, "ngModelChange", "keypress", "ngModel", "maxlength"], ["type", "text", "name", "tutorApellido1", "required", "", 3, "ngModelChange", "keypress", "ngModel", "maxlength"], ["type", "text", "name", "tutorApellido2", 3, "ngModelChange", "keypress", "ngModel", "maxlength"], ["name", "tutorParentesco", "required", "", 3, "ngModelChange", "ngModel"], ["type", "email", "name", "tutorCorreo", "maxlength", "254", 3, "ngModelChange", "ngModel"], ["type", "tel", "name", "tutorTelefono", "maxlength", "10", "inputmode", "numeric", 3, "ngModelChange", "keypress", "ngModel"], [1, "modal-acciones"]], template: function RegistroVentanilla_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275conditionalCreate(0, RegistroVentanilla_Conditional_0_Template, 1, 0, "app-aviso-privacidad");
      \u0275\u0275elementStart(1, "div", 12);
      \u0275\u0275conditionalCreate(2, RegistroVentanilla_Conditional_2_Template, 27, 3, "div", 13)(3, RegistroVentanilla_Conditional_3_Template, 161, 82);
      \u0275\u0275elementEnd();
      \u0275\u0275conditionalCreate(4, RegistroVentanilla_Conditional_4_Template, 53, 10, "div", 14);
    }
    if (rf & 2) {
      \u0275\u0275conditional(ctx.mostrarAvisoPrivacidad ? 0 : -1);
      \u0275\u0275advance(2);
      \u0275\u0275conditional(ctx.quejaCreada ? 2 : 3);
      \u0275\u0275advance(2);
      \u0275\u0275conditional(ctx.mostrarModalTutor ? 4 : -1);
    }
  }, dependencies: [
    CommonModule,
    FormsModule,
    \u0275NgNoValidate,
    NgSelectOption,
    \u0275NgSelectMultipleOption,
    DefaultValueAccessor,
    SelectControlValueAccessor,
    RadioControlValueAccessor,
    NgControlStatus,
    NgControlStatusGroup,
    RequiredValidator,
    MaxLengthValidator,
    NgModel,
    NgForm,
    RouterLink,
    Datepicker,
    AvisoPrivacidad,
    AutocompletarDependencia
  ], styles: ['@charset "UTF-8";\n\n\n.contenedor[_ngcontent-%COMP%] {\n  max-width: 960px;\n  margin: 30px auto;\n  padding: 0 20px 40px;\n}\n.contenedor[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  text-align: center;\n}\n.contenedor[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-size: 1rem;\n  color: var(--guinda);\n  border-bottom: 1px solid var(--borde);\n  padding-bottom: 8px;\n  margin-top: 32px;\n}\n.contenedor[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%] {\n  padding: 36px 48px;\n  border-radius: 10px;\n  border-top: 4px solid var(--guinda);\n  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.09);\n}\n.encabezado-formulario[_ngcontent-%COMP%] {\n  text-align: center;\n  max-width: 640px;\n  margin: 0 auto 8px;\n}\n.encabezado-formulario[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin-bottom: 8px;\n}\n.encabezado-formulario__subtitulo[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 0.92rem;\n  margin: 0 0 24px;\n}\n@media (min-width: 900px) {\n  .fila--3[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr 1fr 1fr;\n  }\n}\n.exito[_ngcontent-%COMP%] {\n  max-width: 480px;\n  margin: 40px auto;\n  text-align: center;\n  animation: _ngcontent-%COMP%_exito-entrada 0.4s ease both;\n  border-top-color: var(--exito) !important;\n}\n.exito[_ngcontent-%COMP%]   .icono-exito[_ngcontent-%COMP%] {\n  width: 64px;\n  height: 64px;\n  margin: 0 auto 8px;\n  border-radius: 50%;\n  background: #e8f5e9;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  animation: _ngcontent-%COMP%_icono-rebote 0.5s cubic-bezier(0.34, 1.56, 0.64, 1) 0.15s both;\n}\n.exito[_ngcontent-%COMP%]   .icono-exito[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 30px;\n  height: 30px;\n  stroke: var(--exito);\n}\n.exito[_ngcontent-%COMP%]   .folio[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      var(--guinda-suave),\n      #fff);\n  border: 1px solid var(--guinda-suave);\n  border-radius: 8px;\n  padding: 14px;\n  font-size: 1.3rem;\n  font-weight: 700;\n  letter-spacing: 1px;\n  color: var(--guinda);\n  margin: 12px 0;\n}\n.exito[_ngcontent-%COMP%]   .nota[_ngcontent-%COMP%] {\n  font-size: 0.85rem;\n  color: var(--texto-suave);\n  margin-bottom: 20px;\n}\n.exito[_ngcontent-%COMP%]   .btn-primary[_ngcontent-%COMP%] {\n  display: inline-block;\n  text-decoration: none;\n}\n.exito[_ngcontent-%COMP%]   .btn-acuse[_ngcontent-%COMP%] {\n  width: 100%;\n  margin-bottom: 24px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n}\n.exito[_ngcontent-%COMP%]   .btn-acuse[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 17px;\n  height: 17px;\n  stroke: currentColor;\n  flex-shrink: 0;\n}\n@keyframes _ngcontent-%COMP%_exito-entrada {\n  from {\n    opacity: 0;\n    transform: translateY(12px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n@keyframes _ngcontent-%COMP%_icono-rebote {\n  from {\n    opacity: 0;\n    transform: scale(0.4);\n  }\n  to {\n    opacity: 1;\n    transform: scale(1);\n  }\n}\n.seguimiento[_ngcontent-%COMP%] {\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  padding: 20px;\n  text-align: center;\n  animation: _ngcontent-%COMP%_exito-entrada 0.4s ease 0.1s both;\n  transition: box-shadow 0.15s ease, transform 0.15s ease;\n}\n.seguimiento[_ngcontent-%COMP%]:hover {\n  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.06);\n}\n.seguimiento__icono[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  margin: 0 auto 10px;\n  border-radius: 50%;\n  background: var(--guinda-suave);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.seguimiento__icono[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 20px;\n  height: 20px;\n  stroke: var(--guinda-vivo);\n}\n.seguimiento[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  border: none;\n  padding: 0;\n  margin: 0 0 8px;\n  font-size: 1rem;\n}\n.seguimiento[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 0.85rem;\n  color: var(--texto-suave);\n  margin: 0 0 16px;\n}\n.seguimiento[_ngcontent-%COMP%]   .btn-primary[_ngcontent-%COMP%] {\n  display: inline-block;\n  text-decoration: none;\n  margin-bottom: 10px;\n}\n.seguimiento[_ngcontent-%COMP%]   .link-invitado[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n}\n.seguimiento[_ngcontent-%COMP%]   .link-invitado[_ngcontent-%COMP%]:hover {\n  color: var(--guinda-vivo);\n}\n.formulario-queja[_ngcontent-%COMP%] {\n  counter-reset: paso;\n}\n.formulario-queja[_ngcontent-%COMP%]   h3.paso[_ngcontent-%COMP%] {\n  counter-increment: paso;\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.formulario-queja[_ngcontent-%COMP%]   h3.paso[_ngcontent-%COMP%]::before {\n  content: counter(paso);\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 24px;\n  height: 24px;\n  flex-shrink: 0;\n  border-radius: 50%;\n  background: var(--guinda);\n  color: #fff;\n  font-size: 0.75rem;\n  font-weight: 700;\n}\n.aviso-pendiente[_ngcontent-%COMP%] {\n  background: #fdecea;\n  border: 1px solid #f5c6cb;\n  border-radius: 6px;\n  padding: 16px;\n  font-size: 0.9rem;\n}\n.fila[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  gap: 20px;\n}\n@media (max-width: 600px) {\n  .fila[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n}\n.radios[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 16px;\n  margin-top: 8px;\n}\n.radios[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  font-weight: normal;\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n.archivo-nombre[_ngcontent-%COMP%] {\n  font-size: 0.85rem;\n  color: var(--texto-suave);\n  margin-top: 6px;\n}\n.input-invalid[_ngcontent-%COMP%]   input[_ngcontent-%COMP%], \n.input-invalid[_ngcontent-%COMP%]   select[_ngcontent-%COMP%], \n.input-invalid[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {\n  border-color: var(--peligro) !important;\n  background: #fff8f8 !important;\n}\n.mensaje-campo[_ngcontent-%COMP%] {\n  display: block;\n  margin-top: 4px;\n  font-size: 0.78rem;\n  color: var(--peligro);\n}\n.dropzone[_ngcontent-%COMP%] {\n  border: 2px dashed var(--borde);\n  border-radius: 8px;\n  padding: 26px 20px;\n  text-align: center;\n  cursor: pointer;\n  background: var(--gris-fondo);\n  transition: border-color 0.15s ease, background 0.15s ease;\n}\n.dropzone[_ngcontent-%COMP%]:hover {\n  border-color: var(--guinda-vivo);\n}\n.dropzone[_ngcontent-%COMP%] {\n}\n.dropzone--activo[_ngcontent-%COMP%] {\n  border-color: var(--advertencia);\n  background: #fdf6e3;\n}\n.dropzone__icono[_ngcontent-%COMP%] {\n  width: 44px;\n  height: 44px;\n  margin: 0 auto 10px;\n  border-radius: 50%;\n  background: var(--guinda-suave);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.dropzone__icono[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 22px;\n  height: 22px;\n  stroke: var(--guinda-vivo);\n}\n.dropzone__icono--exito[_ngcontent-%COMP%] {\n  background: #e8f5e9;\n}\n.dropzone__icono--exito[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  stroke: var(--exito);\n}\n.dropzone__texto[_ngcontent-%COMP%] {\n  margin: 0 0 4px;\n  font-size: 0.9rem;\n  color: var(--texto);\n}\n.dropzone__texto[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: var(--guinda-vivo);\n}\n.dropzone__hint[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 0.78rem;\n  color: var(--texto-suave);\n}\n.archivo-peso[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 0.78rem;\n}\n.lista-archivos[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 10px 0 0;\n  padding: 0;\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n}\n.lista-archivos[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: var(--gris-fondo);\n  border: 1px solid var(--borde);\n  border-radius: 4px;\n  padding: 6px 10px;\n  font-size: 0.85rem;\n}\n.lista-archivos[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.lista-archivos[_ngcontent-%COMP%]   .quitar[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  color: var(--peligro);\n  font-weight: 700;\n  padding: 0 4px;\n  flex-shrink: 0;\n  cursor: pointer;\n}\n.lista-archivos[_ngcontent-%COMP%]   .quitar[_ngcontent-%COMP%]:hover {\n  opacity: 0.7;\n}\n.banner-tutor[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: var(--guinda-suave);\n  border-left: 3px solid var(--guinda-vivo);\n  border-radius: 6px;\n  padding: 10px 14px;\n  margin: -8px 0 18px;\n  font-size: 0.85rem;\n}\n.banner-tutor__icono[_ngcontent-%COMP%] {\n  color: var(--exito);\n  font-weight: 700;\n}\n.banner-tutor__texto[_ngcontent-%COMP%] {\n  flex: 1;\n  color: var(--negro-inst);\n}\n.banner-tutor__editar[_ngcontent-%COMP%] {\n  background: none;\n  border: 1px solid var(--guinda-vivo);\n  color: var(--guinda-vivo);\n  border-radius: 4px;\n  padding: 4px 10px;\n  font-size: 0.8rem;\n  cursor: pointer;\n  flex-shrink: 0;\n}\n.banner-tutor__editar[_ngcontent-%COMP%]:hover {\n  background: var(--guinda-vivo);\n  color: #fff;\n}\n.modal-overlay[_ngcontent-%COMP%] {\n  position: fixed;\n  inset: 0;\n  background: rgba(0, 0, 0, 0.5);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  z-index: 150;\n  padding: 20px;\n}\n.modal[_ngcontent-%COMP%] {\n  max-width: 480px;\n  width: 100%;\n  max-height: 90vh;\n  overflow-y: auto;\n  border-radius: 10px;\n  box-shadow: 0 10px 34px rgba(0, 0, 0, 0.32);\n  padding: 0;\n}\n.modal-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: var(--guinda, #6c1d45);\n  color: #fff;\n  padding: 16px 20px;\n  border-radius: 10px 10px 0 0;\n}\n.modal-header__icono[_ngcontent-%COMP%] {\n  width: 34px;\n  height: 34px;\n  flex-shrink: 0;\n  border-radius: 50%;\n  background: rgba(255, 255, 255, 0.15);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.modal-header__icono[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  stroke: #fff;\n}\n.modal-header[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  flex: 1;\n  margin: 0;\n  border: none;\n  padding: 0;\n  color: #fff;\n  font-size: 1rem;\n}\n.modal-header[_ngcontent-%COMP%]   .modal-cerrar[_ngcontent-%COMP%] {\n  background: rgba(255, 255, 255, 0.15);\n  border: none;\n  color: #fff;\n  width: 26px;\n  height: 26px;\n  border-radius: 50%;\n  font-size: 0.85rem;\n  cursor: pointer;\n}\n.modal-header[_ngcontent-%COMP%]   .modal-cerrar[_ngcontent-%COMP%]:hover {\n  background: rgba(255, 255, 255, 0.28);\n}\n.modal-body[_ngcontent-%COMP%] {\n  padding: 20px 24px 24px;\n}\n.aviso-inline[_ngcontent-%COMP%] {\n  background: var(--guinda-suave);\n  border-left: 3px solid var(--guinda-vivo);\n  padding: 8px 12px;\n  border-radius: 4px;\n  font-size: 0.8rem;\n  margin-bottom: 16px;\n}\n.modal-acciones[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  margin-top: 10px;\n}\n.modal-acciones[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  flex: 1;\n}\n.envio-formulario[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-top: 28px;\n  padding-top: 24px;\n  border-top: 1px solid var(--borde);\n}\n.btn-enviar-queja[_ngcontent-%COMP%] {\n  min-width: 240px;\n  padding: 14px 32px;\n  font-size: 1rem;\n  font-weight: 700;\n}\n.envio-formulario__nota[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  margin: 12px 0 0;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.envio-formulario__nota[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 15px;\n  height: 15px;\n  stroke: var(--texto-suave);\n  flex-shrink: 0;\n}\n.mensaje-ayuda[_ngcontent-%COMP%] {\n  display: block;\n  margin-top: 4px;\n  font-size: 0.74rem;\n  color: #8a8a8a;\n}\n.contador-caracteres[_ngcontent-%COMP%] {\n  margin-top: 4px;\n  font-size: 0.72rem;\n  color: #999;\n  text-align: right;\n}\n.galeria-titulo[_ngcontent-%COMP%] {\n  margin: 12px 0 6px;\n  font-size: 0.8rem;\n  font-weight: 600;\n  color: #555;\n}\n.galeria-archivos[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));\n  gap: 12px;\n  margin-top: 10px;\n}\n.miniatura[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  margin: 0;\n  overflow: hidden;\n  background: #fafafa;\n  border: 1px solid #e3e3e3;\n  border-radius: 10px;\n  transition: border-color 0.15s ease, box-shadow 0.15s ease;\n}\n.miniatura[_ngcontent-%COMP%]:hover {\n  border-color: #c9a2b4;\n  box-shadow: 0 2px 10px rgba(108, 29, 69, 0.12);\n}\n.miniatura[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  display: block;\n  width: 100%;\n  height: 104px;\n  object-fit: cover;\n  background: #efefef;\n}\n.miniatura__extension[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 104px;\n  font-size: 0.9rem;\n  font-weight: 700;\n  color: #6c1d45;\n  letter-spacing: 0.06em;\n  background: #f3e7ec;\n}\n.miniatura[_ngcontent-%COMP%]   figcaption[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  padding: 7px 9px 9px;\n}\n.miniatura__nombre[_ngcontent-%COMP%] {\n  overflow: hidden;\n  font-size: 0.75rem;\n  color: #333;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.miniatura__quitar[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 6px;\n  right: 6px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 24px;\n  height: 24px;\n  font-size: 0.72rem;\n  line-height: 1;\n  color: #fff;\n  cursor: pointer;\n  background: rgba(28, 10, 18, 0.68);\n  border: 0;\n  border-radius: 50%;\n}\n.miniatura__quitar[_ngcontent-%COMP%]:hover {\n  background: #9d2449;\n}\n.envio-formulario__aviso[_ngcontent-%COMP%] {\n  display: block;\n  margin-top: 3px;\n  font-size: 0.72rem;\n  color: #7a7a7a;\n}\n.aviso-correo-registrado[_ngcontent-%COMP%] {\n  margin-top: 8px;\n  padding: 10px 12px;\n  border-radius: 6px;\n  border: 1px solid #f0c36d;\n  background: #fff8e6;\n  color: #7a5b12;\n  font-size: 0.84rem;\n  line-height: 1.45;\n}\n.aviso-correo-registrado[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 2px;\n}\n.aviso-correo-registrado[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  display: inline-block;\n  margin-top: 6px;\n  font-weight: 600;\n  color: #7a5b12;\n  text-decoration: underline;\n}\n.acciones-ventanilla[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: center;\n  align-items: center;\n  gap: 12px;\n  margin-top: 20px;\n}\n/*# sourceMappingURL=registro-ventanilla.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RegistroVentanilla, [{
    type: Component,
    args: [{ selector: "app-registro-ventanilla", standalone: true, imports: [
      CommonModule,
      FormsModule,
      RouterLink,
      Datepicker,
      AvisoPrivacidad,
      AutocompletarDependencia
    ], template: `@if (mostrarAvisoPrivacidad) {
  <app-aviso-privacidad (aceptado)="onAvisoAceptado($event)"></app-aviso-privacidad>
}

<div class="contenedor">
  @if (quejaCreada) {
    <div class="card exito">
      <div class="icono-exito">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M9 12l2 2 4-4" />
          <circle cx="12" cy="12" r="9" />
        </svg>
      </div>
      <h2>Queja registrada en ventanilla</h2>
      <p>Folio asignado:</p>
      <div class="folio">{{ quejaCreada.numeroFolio }}</div>
      <p class="nota">
        Entrega a la persona quejosa el acuse con su folio. Con el folio y el correo
        ({{ quejaCreada.correoInstitucional }}) puede consultar el estatus en el portal y, si lo desea,
        crear su cuenta de seguimiento.
      </p>
      @if (avisoVentanilla) {
        <p class="aviso-inline">{{ avisoVentanilla }}</p>
      }

      <button type="button" class="btn-secondary btn-acuse" (click)="descargarAcuse()">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <path d="M6 9V3h12v6" />
          <rect x="4" y="9" width="16" height="8" rx="1.5" />
          <path d="M6 17v4h12v-4" />
        </svg>
        Imprimir acuse de recibo
      </button>

      <div class="acciones-ventanilla">
        <button type="button" class="btn-primary" (click)="atenderAhora()">Validarla ahora</button>
        <button type="button" class="btn-secondary" (click)="registrarOtra()">Registrar otra queja</button>
        <a routerLink="/" class="link-invitado">Ir a la Bandeja de Entrada</a>
      </div>
    </div>
  } @else {

  <div class="encabezado-formulario">
    <h2>Registro Manual (Ventanilla)</h2>
    <p class="encabezado-formulario__subtitulo">
      Captura la queja que la persona presenta en ventanilla con el mismo formulario del portal. Antes de
      empezar, mu\xE9strale el aviso de privacidad para que lo lea y lo acepte.
    </p>
  </div>

    <form (submit)="$event.preventDefault(); enviarQueja()" class="card formulario-queja">
      <h3 class="paso">Recepci\xF3n en ventanilla</h3>
      <div class="fila">
        <div class="input-group">
          <label for="tipoDocumento">Documento recibido:</label>
          <select id="tipoDocumento" [(ngModel)]="tipoDocumento" name="tipoDocumento">
            @for (t of tiposDocumento; track t.valor) {
              <option [value]="t.valor">{{ t.etiqueta }}</option>
            }
          </select>
        </div>
        <div class="input-group">
          <label for="fechaRecepcionFisica">Fecha de recepci\xF3n f\xEDsica:</label>
          <input id="fechaRecepcionFisica" type="date" [(ngModel)]="fechaRecepcionFisica" name="fechaRecepcionFisica" />
        </div>
      </div>
      <div class="fila">
        <div class="input-group">
          <label for="numeroOficio">N\xFAmero de oficio (si aplica):</label>
          <input id="numeroOficio" type="text" [(ngModel)]="numeroOficio" name="numeroOficio" maxlength="60" />
        </div>
        <div class="input-group">
          <label for="ubicacionFisica">Ubicaci\xF3n f\xEDsica del expediente (opcional):</label>
          <input id="ubicacionFisica" type="text" [(ngModel)]="ubicacionFisica" name="ubicacionFisica" maxlength="120"
                 placeholder="Ej. Archivero 2, gaveta B" />
        </div>
      </div>

      <h3 class="paso">Datos del Quejoso</h3>
      <div class="fila">
        <div class="input-group" [class.input-invalid]="errorNombre && (nombreModel.touched || intentoEnviar)">
          <label>Nombre:</label>
          <input
            type="text"
            [(ngModel)]="nombre"
            name="nombre"
            #nombreModel="ngModel"
            (keypress)="soloLetras($event)"
            [maxlength]="nombreLongitudMaxima"
            autocomplete="given-name"
            required
          />
          @if (errorNombre && (nombreModel.touched || intentoEnviar)) {
            <span class="mensaje-campo">{{ errorNombre }}</span>
          }
        </div>
        <div class="input-group" [class.input-invalid]="errorApellido1 && (apellido1Model.touched || intentoEnviar)">
          <label>Primer Apellido:</label>
          <input
            type="text"
            [(ngModel)]="apellido1"
            name="apellido1"
            #apellido1Model="ngModel"
            (keypress)="soloLetras($event)"
            [maxlength]="nombreLongitudMaxima"
            autocomplete="family-name"
            required
          />
          @if (errorApellido1 && (apellido1Model.touched || intentoEnviar)) {
            <span class="mensaje-campo">{{ errorApellido1 }}</span>
          }
        </div>
      </div>
      <div class="fila">
        <div class="input-group" [class.input-invalid]="errorApellido2 && (apellido2Model.touched || intentoEnviar)">
          <label>Segundo Apellido:</label>
          <input
            type="text"
            [(ngModel)]="apellido2"
            name="apellido2"
            #apellido2Model="ngModel"
            (keypress)="soloLetras($event)"
            [maxlength]="nombreLongitudMaxima"
          />
          @if (errorApellido2 && (apellido2Model.touched || intentoEnviar)) {
            <span class="mensaje-campo">{{ errorApellido2 }}</span>
          }
        </div>
        <div class="input-group" [class.input-invalid]="errorCorreo && (correoModel.touched || intentoEnviar)">
          <label>Correo:</label>
          <input
            type="email"
            [(ngModel)]="correo"
            name="correo"
            #correoModel="ngModel"
            maxlength="254"
            autocomplete="email"
            required
            (blur)="verificarCorreoRegistrado()"
          />
          @if (errorCorreo && (correoModel.touched || intentoEnviar)) {
            <span class="mensaje-campo">{{ errorCorreo }}</span>
          }
        </div>
      </div>
      <div class="fila">
        <div class="input-group input-fecha" [class.input-invalid]="errorFechaNacimiento && intentoEnviar">
          <label>Fecha de nacimiento:</label>
          <app-datepicker
            [(ngModel)]="fechaNacimiento"
            name="fechaNacimiento"
            [min]="fechaNacimientoMinima"
            [max]="fechaNacimientoMaxima"
            (cambio)="onFechaNacimientoChange()"
          ></app-datepicker>
          @if (errorFechaNacimiento && intentoEnviar) {
            <span class="mensaje-campo">{{ errorFechaNacimiento }}</span>
          } @else {
            <span class="mensaje-ayuda">Entre 1920 y {{ fechaNacimientoMaxima.slice(0, 4) }}.</span>
          }
        </div>
      </div>

      @if (tutorConfirmado) {
        <div class="banner-tutor">
          <span class="banner-tutor__icono">\u2713</span>
          <span class="banner-tutor__texto">
            @if (esMenorDe14) {
              Est\xE1s presentando esta queja como tutor(a) de {{ nombre }} {{ apellido1 }}. Datos de tutor: <strong>{{ tutor.nombre }} {{ tutor.apellido1 }}</strong>
            } @else {
              Datos del tutor/adulto responsable capturados: <strong>{{ tutor.nombre }} {{ tutor.apellido1 }}</strong>
            }
          </span>
          <button type="button" class="banner-tutor__editar" (click)="editarTutor()">Editar</button>
        </div>
      }

      <div class="fila">
        <div class="input-group">
          <label>Identificaci\xF3n institucional:</label>
          <div class="radios">
            <label><input type="radio" name="identificacion" value="alumno" [(ngModel)]="identificacion" /> Alumno</label>
            <label><input type="radio" name="identificacion" value="empleado" [(ngModel)]="identificacion" /> Empleado</label>
          </div>
        </div>
        <div class="input-group" [class.input-invalid]="errorBoleta && (numeroBoletaEmpleadoModel.touched || intentoEnviar)">
          <label>{{ etiquetaNumeroIdentificacion }}:</label>
          <input
            type="text"
            [(ngModel)]="numeroBoletaEmpleado"
            name="numeroBoletaEmpleado"
            #numeroBoletaEmpleadoModel="ngModel"
            [placeholder]="etiquetaNumeroIdentificacion"
            (keypress)="soloDigitos($event)"
            [maxlength]="boletaLongitudMaxima"
            inputmode="numeric"
            required
          />
          @if (errorBoleta && (numeroBoletaEmpleadoModel.touched || intentoEnviar)) {
            <span class="mensaje-campo">{{ errorBoleta }}</span>
          } @else {
            <span class="mensaje-ayuda">Solo n\xFAmeros, m\xE1ximo {{ boletaLongitudMaxima }} d\xEDgitos.</span>
          }
        </div>
      </div>

      <div class="input-group" [class.input-invalid]="errorIdentificacion && intentoEnviar">
        <label>
          Identificaci\xF3n oficial (credencial de la comunidad polit\xE9cnica):
        </label>

        @if (identificaciones.length < identificacionCantidadMaxima) {
          <div class="dropzone" (click)="inputIdentificacion.click()">
            <input
              #inputIdentificacion
              type="file"
              multiple
              accept="image/jpeg,image/png"
              (change)="onIdentificacionSeleccionada($event)"
              hidden
            />
            <span class="dropzone__icono">
              <svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                <rect x="2.5" y="5" width="19" height="14" rx="2.5" />
                <circle cx="8.5" cy="11.5" r="2.2" />
                <path d="M5 16c.6-1.7 2-2.6 3.5-2.6s2.9.9 3.5 2.6" />
                <path d="M14.5 9.5h4" />
                <path d="M14.5 13h4" />
              </svg>
            </span>
            <p class="dropzone__texto">
              Sube una foto o escaneo de tu credencial \u2014 <strong>haz clic para elegir</strong>
            </p>
            <p class="dropzone__hint">
              Solo JPG o PNG \u2014 m\xE1ximo 3MB por imagen \u2014 hasta {{ identificacionCantidadMaxima }} im\xE1genes (frente y reverso)
            </p>
          </div>
        }

        @if (identificaciones.length) {
          <div class="galeria-archivos">
            @for (item of identificaciones; track item.archivo.name; let i = $index) {
              <figure class="miniatura">
                @if (item.url) {
                  <img [src]="item.url" [alt]="'Vista previa de ' + item.archivo.name" />
                } @else {
                  <span class="miniatura__extension">{{ tipoArchivo(item.archivo) }}</span>
                }
                <figcaption>
                  <span class="miniatura__nombre" [title]="item.archivo.name">{{ item.archivo.name }}</span>
                  <span class="archivo-peso">{{ formatearTamanio(item.archivo.size) }}</span>
                </figcaption>
                <button
                  type="button"
                  class="miniatura__quitar"
                  (click)="quitarIdentificacion(i)"
                  [attr.aria-label]="'Quitar ' + item.archivo.name"
                >\u2715</button>
              </figure>
            }
          </div>
        }

        @if (errorIdentificacion && intentoEnviar) {
          <span class="mensaje-campo">{{ errorIdentificacion }}</span>
        }
      </div>

      <h3 class="paso">Lugar de los hechos</h3>
      <div class="fila">
        <div class="input-group" [class.input-invalid]="errorUnidadAcademica && (unidadAcademicaModel.touched || intentoEnviar)">
          <label>Lugar donde sucedieron los hechos:</label>
          <app-autocompletar-dependencia
            [(ngModel)]="unidadAcademica"
            name="unidadAcademica"
            #unidadAcademicaModel="ngModel"
            [dependencias]="dependencias"
            [cargando]="cargandoDependencias"
            required
          ></app-autocompletar-dependencia>
          @if (errorDependencias) {
            <p class="error">{{ errorDependencias }}</p>
          }
          @if (errorUnidadAcademica && (unidadAcademicaModel.touched || intentoEnviar) && !errorDependencias) {
            <span class="mensaje-campo">{{ errorUnidadAcademica }}</span>
          } @else if (!errorDependencias) {
            <span class="mensaje-ayuda">
              Escribe las siglas o el nombre de tu escuela \u2014 por ejemplo <strong>ESCOM</strong> o
              <strong>Escuela Superior de C\xF3mputo</strong>.
            </span>
          }
        </div>
        <div class="input-group input-fecha" [class.input-invalid]="errorFechaHechos && intentoEnviar">
          <label>Fecha de los hechos:</label>
          <app-datepicker
            [(ngModel)]="fechaHechos"
            name="fechaHechos"
            [max]="fechaMaxima"
          ></app-datepicker>
          @if (errorFechaHechos && intentoEnviar) {
            <span class="mensaje-campo">{{ errorFechaHechos }}</span>
          }
        </div>
      </div>

      <h3 class="paso">Datos del Denunciado</h3>
      <div class="fila">
        <div class="input-group" [class.input-invalid]="errorNombreDenunciado && (nombreDenunciadoModel.touched || intentoEnviar)">
          <label>Nombre del denunciado:</label>
          <input
            type="text"
            [(ngModel)]="nombreDenunciado"
            name="nombreDenunciado"
            #nombreDenunciadoModel="ngModel"
            (keypress)="soloLetras($event)"
            [maxlength]="nombreLongitudMaxima"
          />
          @if (errorNombreDenunciado && (nombreDenunciadoModel.touched || intentoEnviar)) {
            <span class="mensaje-campo">{{ errorNombreDenunciado }}</span>
          }
        </div>
        <div class="input-group" [class.input-invalid]="errorApellido1Denunciado && (apellido1DenunciadoModel.touched || intentoEnviar)">
          <label>Primer Apellido del denunciado:</label>
          <input
            type="text"
            [(ngModel)]="apellido1Denunciado"
            name="apellido1Denunciado"
            #apellido1DenunciadoModel="ngModel"
            (keypress)="soloLetras($event)"
            [maxlength]="nombreLongitudMaxima"
          />
          @if (errorApellido1Denunciado && (apellido1DenunciadoModel.touched || intentoEnviar)) {
            <span class="mensaje-campo">{{ errorApellido1Denunciado }}</span>
          }
        </div>
      </div>
      <div class="fila">
        <div class="input-group" [class.input-invalid]="errorApellido2Denunciado && (apellido2DenunciadoModel.touched || intentoEnviar)">
          <label>Segundo Apellido del denunciado:</label>
          <input
            type="text"
            [(ngModel)]="apellido2Denunciado"
            name="apellido2Denunciado"
            #apellido2DenunciadoModel="ngModel"
            (keypress)="soloLetras($event)"
            [maxlength]="nombreLongitudMaxima"
          />
          @if (errorApellido2Denunciado && (apellido2DenunciadoModel.touched || intentoEnviar)) {
            <span class="mensaje-campo">{{ errorApellido2Denunciado }}</span>
          } @else {
            <span class="mensaje-ayuda">Opcional, si lo conoces.</span>
          }
        </div>
        <div class="input-group"></div>
      </div>

      <div class="input-group" [class.input-invalid]="errorDescripcion && (descripcionModel.touched || intentoEnviar)">
        <label>Descripci\xF3n de los hechos:</label>
        <textarea
          rows="5"
          [(ngModel)]="descripcion"
          name="descripcion"
          #descripcionModel="ngModel"
          required
        ></textarea>
        <div class="contador-caracteres">
          {{ descripcion.length }} caracteres
        </div>
        @if (errorDescripcion && (descripcionModel.touched || intentoEnviar)) {
          <span class="mensaje-campo">{{ errorDescripcion }}</span>
        }
      </div>

      <div class="input-group">
        <label>Adjunta archivos que sustenten tu queja (PDF, JPG, PNG, MP4, MP3) \u2014 puedes elegir varios:</label>

        <div
          class="dropzone"
          [class.dropzone--activo]="arrastrandoArchivo"
          (click)="inputArchivos.click()"
          (dragover)="onArrastreSobre($event)"
          (dragleave)="onArrastreSale()"
          (drop)="onArchivosSoltados($event)"
        >
          <input
            #inputArchivos
            type="file"
            multiple
            accept=".pdf,.jpg,.jpeg,.png,.mp4,.mp3"
            (change)="onArchivosSeleccionados($event)"
            hidden
          />
          <span class="dropzone__icono">
            <svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
              <path d="M16.5 6.5l-8 8a3 3 0 0 0 4.24 4.24l8.5-8.5a5 5 0 0 0-7.07-7.07l-8.5 8.5a7 7 0 0 0 9.9 9.9" />
            </svg>
          </span>
          <p class="dropzone__texto">Arrastra tus archivos aqu\xED o <strong>haz clic para elegir</strong></p>
          <p class="dropzone__hint">PDF, JPG, PNG, MP4, MP3 \u2014 m\xE1ximo 30MB por archivo, 100MB en total</p>
        </div>

        @if (evidencias.length) {
          <p class="galeria-titulo">
            {{ evidencias.length }} archivo(s) adjunto(s) \u2014 revisa que sean los correctos:
          </p>
          <div class="galeria-archivos">
            @for (item of evidencias; track item.archivo.name; let i = $index) {
              <figure class="miniatura">
                @if (item.url) {
                  <img [src]="item.url" [alt]="'Vista previa de ' + item.archivo.name" />
                } @else {
                  <span class="miniatura__extension">{{ tipoArchivo(item.archivo) }}</span>
                }
                <figcaption>
                  <span class="miniatura__nombre" [title]="item.archivo.name">{{ item.archivo.name }}</span>
                  <span class="archivo-peso">{{ formatearTamanio(item.archivo.size) }}</span>
                </figcaption>
                <button
                  type="button"
                  class="miniatura__quitar"
                  (click)="quitarArchivo(i)"
                  [attr.aria-label]="'Quitar ' + item.archivo.name"
                >\u2715</button>
              </figure>
            }
          </div>
        }
      </div>

      <div class="envio-formulario">
        <button type="submit" class="btn-primary btn-enviar-queja" [disabled]="cargando">
          {{ cargando ? 'Registrando\u2026' : 'Registrar Queja' }}
        </button>
        <p class="envio-formulario__nota">
          <svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <rect x="4" y="10" width="16" height="10" rx="2" />
            <path d="M8 10V7a4 4 0 0 1 8 0v3" />
          </svg>
          Los datos se manejan de forma confidencial.
          @if (avisoAceptado) {
            <span class="envio-formulario__aviso">
              Aviso de privacidad aceptado (v{{ avisoPrivacidadVersion }}).
            </span>
          }
        </p>
      </div>
    </form>
  }
</div>



@if (mostrarModalTutor) {
  <div class="modal-overlay">
    <div class="modal card">
      <div class="modal-header">
        <span class="modal-header__icono" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
            <circle cx="9" cy="7" r="4" />
            <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
            <path d="M16 3.13a4 4 0 0 1 0 7.75" />
          </svg>
        </span>
        <h3>Informaci\xF3n del Tutor / Adulto Responsable</h3>
        <button type="button" class="modal-cerrar" (click)="cancelarTutor()" aria-label="Cerrar">\u2715</button>
      </div>

      <div class="modal-body">
      @if (esMenorDe14) {
        <p class="aviso-inline">
          Por tratarse de una persona menor de 14 a\xF1os, este tr\xE1mite debe completarlo su padre,
          madre o tutor legal. Los datos capturados arriba (nombre, correo, etc.) corresponden al
          menor; aqu\xED abajo captura tus propios datos como responsable.
        </p>
      } @else {
        <p class="aviso-inline">Se requiere un responsable legal para solicitantes menores de edad.</p>
      }

      <div class="input-group">
        <label>Nombre(s):</label>
        <input type="text" [(ngModel)]="tutor.nombre" name="tutorNombre" (keypress)="soloLetras($event)" [maxlength]="nombreLongitudMaxima" required />
      </div>
      <div class="fila">
        <div class="input-group">
          <label>Primer Apellido:</label>
          <input type="text" [(ngModel)]="tutor.apellido1" name="tutorApellido1" (keypress)="soloLetras($event)" [maxlength]="nombreLongitudMaxima" required />
        </div>
        <div class="input-group">
          <label>Segundo Apellido:</label>
          <input type="text" [(ngModel)]="tutor.apellido2" name="tutorApellido2" (keypress)="soloLetras($event)" [maxlength]="nombreLongitudMaxima" />
        </div>
      </div>
      <div class="input-group">
        <label>Parentesco:</label>
        <select [(ngModel)]="tutor.parentesco" name="tutorParentesco" required>
          <option>Padre</option>
          <option>Madre</option>
          <option>Tutor legal</option>
        </select>
      </div>
      <div class="fila">
        <div class="input-group">
          <label>Correo Electr\xF3nico:</label>
          <input type="email" [(ngModel)]="tutor.correo" name="tutorCorreo" maxlength="254" />
        </div>
        <div class="input-group">
          <label>Tel\xE9fono de Contacto (10 d\xEDgitos):</label>
          <input
            type="tel"
            [(ngModel)]="tutor.telefono"
            name="tutorTelefono"
            (keypress)="soloDigitos($event)"
            maxlength="10"
            inputmode="numeric"
          />
        </div>
      </div>

      <div class="modal-acciones">
        <button type="button" class="btn-primary" (click)="confirmarTutor()">Confirmar Datos</button>
        <button type="button" class="btn-secondary" (click)="cancelarTutor()">Cancelar</button>
      </div>
      </div>
    </div>
  </div>
}
`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/registro-ventanilla/registro-ventanilla.scss */\n.contenedor {\n  max-width: 960px;\n  margin: 30px auto;\n  padding: 0 20px 40px;\n}\n.contenedor h2 {\n  text-align: center;\n}\n.contenedor h3 {\n  font-size: 1rem;\n  color: var(--guinda);\n  border-bottom: 1px solid var(--borde);\n  padding-bottom: 8px;\n  margin-top: 32px;\n}\n.contenedor .card {\n  padding: 36px 48px;\n  border-radius: 10px;\n  border-top: 4px solid var(--guinda);\n  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.09);\n}\n.encabezado-formulario {\n  text-align: center;\n  max-width: 640px;\n  margin: 0 auto 8px;\n}\n.encabezado-formulario h2 {\n  margin-bottom: 8px;\n}\n.encabezado-formulario__subtitulo {\n  color: var(--texto-suave);\n  font-size: 0.92rem;\n  margin: 0 0 24px;\n}\n@media (min-width: 900px) {\n  .fila--3 {\n    grid-template-columns: 1fr 1fr 1fr;\n  }\n}\n.exito {\n  max-width: 480px;\n  margin: 40px auto;\n  text-align: center;\n  animation: exito-entrada 0.4s ease both;\n  border-top-color: var(--exito) !important;\n}\n.exito .icono-exito {\n  width: 64px;\n  height: 64px;\n  margin: 0 auto 8px;\n  border-radius: 50%;\n  background: #e8f5e9;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  animation: icono-rebote 0.5s cubic-bezier(0.34, 1.56, 0.64, 1) 0.15s both;\n}\n.exito .icono-exito svg {\n  width: 30px;\n  height: 30px;\n  stroke: var(--exito);\n}\n.exito .folio {\n  background:\n    linear-gradient(\n      135deg,\n      var(--guinda-suave),\n      #fff);\n  border: 1px solid var(--guinda-suave);\n  border-radius: 8px;\n  padding: 14px;\n  font-size: 1.3rem;\n  font-weight: 700;\n  letter-spacing: 1px;\n  color: var(--guinda);\n  margin: 12px 0;\n}\n.exito .nota {\n  font-size: 0.85rem;\n  color: var(--texto-suave);\n  margin-bottom: 20px;\n}\n.exito .btn-primary {\n  display: inline-block;\n  text-decoration: none;\n}\n.exito .btn-acuse {\n  width: 100%;\n  margin-bottom: 24px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n}\n.exito .btn-acuse svg {\n  width: 17px;\n  height: 17px;\n  stroke: currentColor;\n  flex-shrink: 0;\n}\n@keyframes exito-entrada {\n  from {\n    opacity: 0;\n    transform: translateY(12px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n@keyframes icono-rebote {\n  from {\n    opacity: 0;\n    transform: scale(0.4);\n  }\n  to {\n    opacity: 1;\n    transform: scale(1);\n  }\n}\n.seguimiento {\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  padding: 20px;\n  text-align: center;\n  animation: exito-entrada 0.4s ease 0.1s both;\n  transition: box-shadow 0.15s ease, transform 0.15s ease;\n}\n.seguimiento:hover {\n  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.06);\n}\n.seguimiento__icono {\n  width: 40px;\n  height: 40px;\n  margin: 0 auto 10px;\n  border-radius: 50%;\n  background: var(--guinda-suave);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.seguimiento__icono svg {\n  width: 20px;\n  height: 20px;\n  stroke: var(--guinda-vivo);\n}\n.seguimiento h3 {\n  border: none;\n  padding: 0;\n  margin: 0 0 8px;\n  font-size: 1rem;\n}\n.seguimiento p {\n  font-size: 0.85rem;\n  color: var(--texto-suave);\n  margin: 0 0 16px;\n}\n.seguimiento .btn-primary {\n  display: inline-block;\n  text-decoration: none;\n  margin-bottom: 10px;\n}\n.seguimiento .link-invitado {\n  display: block;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n}\n.seguimiento .link-invitado:hover {\n  color: var(--guinda-vivo);\n}\n.formulario-queja {\n  counter-reset: paso;\n}\n.formulario-queja h3.paso {\n  counter-increment: paso;\n  display: flex;\n  align-items: center;\n  gap: 10px;\n}\n.formulario-queja h3.paso::before {\n  content: counter(paso);\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 24px;\n  height: 24px;\n  flex-shrink: 0;\n  border-radius: 50%;\n  background: var(--guinda);\n  color: #fff;\n  font-size: 0.75rem;\n  font-weight: 700;\n}\n.aviso-pendiente {\n  background: #fdecea;\n  border: 1px solid #f5c6cb;\n  border-radius: 6px;\n  padding: 16px;\n  font-size: 0.9rem;\n}\n.fila {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  gap: 20px;\n}\n@media (max-width: 600px) {\n  .fila {\n    grid-template-columns: 1fr;\n  }\n}\n.radios {\n  display: flex;\n  gap: 16px;\n  margin-top: 8px;\n}\n.radios label {\n  font-weight: normal;\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n.archivo-nombre {\n  font-size: 0.85rem;\n  color: var(--texto-suave);\n  margin-top: 6px;\n}\n.input-invalid input,\n.input-invalid select,\n.input-invalid textarea {\n  border-color: var(--peligro) !important;\n  background: #fff8f8 !important;\n}\n.mensaje-campo {\n  display: block;\n  margin-top: 4px;\n  font-size: 0.78rem;\n  color: var(--peligro);\n}\n.dropzone {\n  border: 2px dashed var(--borde);\n  border-radius: 8px;\n  padding: 26px 20px;\n  text-align: center;\n  cursor: pointer;\n  background: var(--gris-fondo);\n  transition: border-color 0.15s ease, background 0.15s ease;\n}\n.dropzone:hover {\n  border-color: var(--guinda-vivo);\n}\n.dropzone {\n}\n.dropzone--activo {\n  border-color: var(--advertencia);\n  background: #fdf6e3;\n}\n.dropzone__icono {\n  width: 44px;\n  height: 44px;\n  margin: 0 auto 10px;\n  border-radius: 50%;\n  background: var(--guinda-suave);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.dropzone__icono svg {\n  width: 22px;\n  height: 22px;\n  stroke: var(--guinda-vivo);\n}\n.dropzone__icono--exito {\n  background: #e8f5e9;\n}\n.dropzone__icono--exito svg {\n  stroke: var(--exito);\n}\n.dropzone__texto {\n  margin: 0 0 4px;\n  font-size: 0.9rem;\n  color: var(--texto);\n}\n.dropzone__texto strong {\n  color: var(--guinda-vivo);\n}\n.dropzone__hint {\n  margin: 0;\n  font-size: 0.78rem;\n  color: var(--texto-suave);\n}\n.archivo-peso {\n  color: var(--texto-suave);\n  font-size: 0.78rem;\n}\n.lista-archivos {\n  list-style: none;\n  margin: 10px 0 0;\n  padding: 0;\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n}\n.lista-archivos li {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: var(--gris-fondo);\n  border: 1px solid var(--borde);\n  border-radius: 4px;\n  padding: 6px 10px;\n  font-size: 0.85rem;\n}\n.lista-archivos li span {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.lista-archivos .quitar {\n  background: none;\n  border: none;\n  color: var(--peligro);\n  font-weight: 700;\n  padding: 0 4px;\n  flex-shrink: 0;\n  cursor: pointer;\n}\n.lista-archivos .quitar:hover {\n  opacity: 0.7;\n}\n.banner-tutor {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: var(--guinda-suave);\n  border-left: 3px solid var(--guinda-vivo);\n  border-radius: 6px;\n  padding: 10px 14px;\n  margin: -8px 0 18px;\n  font-size: 0.85rem;\n}\n.banner-tutor__icono {\n  color: var(--exito);\n  font-weight: 700;\n}\n.banner-tutor__texto {\n  flex: 1;\n  color: var(--negro-inst);\n}\n.banner-tutor__editar {\n  background: none;\n  border: 1px solid var(--guinda-vivo);\n  color: var(--guinda-vivo);\n  border-radius: 4px;\n  padding: 4px 10px;\n  font-size: 0.8rem;\n  cursor: pointer;\n  flex-shrink: 0;\n}\n.banner-tutor__editar:hover {\n  background: var(--guinda-vivo);\n  color: #fff;\n}\n.modal-overlay {\n  position: fixed;\n  inset: 0;\n  background: rgba(0, 0, 0, 0.5);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  z-index: 150;\n  padding: 20px;\n}\n.modal {\n  max-width: 480px;\n  width: 100%;\n  max-height: 90vh;\n  overflow-y: auto;\n  border-radius: 10px;\n  box-shadow: 0 10px 34px rgba(0, 0, 0, 0.32);\n  padding: 0;\n}\n.modal-header {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: var(--guinda, #6c1d45);\n  color: #fff;\n  padding: 16px 20px;\n  border-radius: 10px 10px 0 0;\n}\n.modal-header__icono {\n  width: 34px;\n  height: 34px;\n  flex-shrink: 0;\n  border-radius: 50%;\n  background: rgba(255, 255, 255, 0.15);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.modal-header__icono svg {\n  width: 18px;\n  height: 18px;\n  stroke: #fff;\n}\n.modal-header h3 {\n  flex: 1;\n  margin: 0;\n  border: none;\n  padding: 0;\n  color: #fff;\n  font-size: 1rem;\n}\n.modal-header .modal-cerrar {\n  background: rgba(255, 255, 255, 0.15);\n  border: none;\n  color: #fff;\n  width: 26px;\n  height: 26px;\n  border-radius: 50%;\n  font-size: 0.85rem;\n  cursor: pointer;\n}\n.modal-header .modal-cerrar:hover {\n  background: rgba(255, 255, 255, 0.28);\n}\n.modal-body {\n  padding: 20px 24px 24px;\n}\n.aviso-inline {\n  background: var(--guinda-suave);\n  border-left: 3px solid var(--guinda-vivo);\n  padding: 8px 12px;\n  border-radius: 4px;\n  font-size: 0.8rem;\n  margin-bottom: 16px;\n}\n.modal-acciones {\n  display: flex;\n  gap: 12px;\n  margin-top: 10px;\n}\n.modal-acciones button {\n  flex: 1;\n}\n.envio-formulario {\n  text-align: center;\n  margin-top: 28px;\n  padding-top: 24px;\n  border-top: 1px solid var(--borde);\n}\n.btn-enviar-queja {\n  min-width: 240px;\n  padding: 14px 32px;\n  font-size: 1rem;\n  font-weight: 700;\n}\n.envio-formulario__nota {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  margin: 12px 0 0;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.envio-formulario__nota svg {\n  width: 15px;\n  height: 15px;\n  stroke: var(--texto-suave);\n  flex-shrink: 0;\n}\n.mensaje-ayuda {\n  display: block;\n  margin-top: 4px;\n  font-size: 0.74rem;\n  color: #8a8a8a;\n}\n.contador-caracteres {\n  margin-top: 4px;\n  font-size: 0.72rem;\n  color: #999;\n  text-align: right;\n}\n.galeria-titulo {\n  margin: 12px 0 6px;\n  font-size: 0.8rem;\n  font-weight: 600;\n  color: #555;\n}\n.galeria-archivos {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));\n  gap: 12px;\n  margin-top: 10px;\n}\n.miniatura {\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  margin: 0;\n  overflow: hidden;\n  background: #fafafa;\n  border: 1px solid #e3e3e3;\n  border-radius: 10px;\n  transition: border-color 0.15s ease, box-shadow 0.15s ease;\n}\n.miniatura:hover {\n  border-color: #c9a2b4;\n  box-shadow: 0 2px 10px rgba(108, 29, 69, 0.12);\n}\n.miniatura img {\n  display: block;\n  width: 100%;\n  height: 104px;\n  object-fit: cover;\n  background: #efefef;\n}\n.miniatura__extension {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 104px;\n  font-size: 0.9rem;\n  font-weight: 700;\n  color: #6c1d45;\n  letter-spacing: 0.06em;\n  background: #f3e7ec;\n}\n.miniatura figcaption {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  padding: 7px 9px 9px;\n}\n.miniatura__nombre {\n  overflow: hidden;\n  font-size: 0.75rem;\n  color: #333;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.miniatura__quitar {\n  position: absolute;\n  top: 6px;\n  right: 6px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 24px;\n  height: 24px;\n  font-size: 0.72rem;\n  line-height: 1;\n  color: #fff;\n  cursor: pointer;\n  background: rgba(28, 10, 18, 0.68);\n  border: 0;\n  border-radius: 50%;\n}\n.miniatura__quitar:hover {\n  background: #9d2449;\n}\n.envio-formulario__aviso {\n  display: block;\n  margin-top: 3px;\n  font-size: 0.72rem;\n  color: #7a7a7a;\n}\n.aviso-correo-registrado {\n  margin-top: 8px;\n  padding: 10px 12px;\n  border-radius: 6px;\n  border: 1px solid #f0c36d;\n  background: #fff8e6;\n  color: #7a5b12;\n  font-size: 0.84rem;\n  line-height: 1.45;\n}\n.aviso-correo-registrado strong {\n  display: block;\n  margin-bottom: 2px;\n}\n.aviso-correo-registrado a {\n  display: inline-block;\n  margin-top: 6px;\n  font-weight: 600;\n  color: #7a5b12;\n  text-decoration: underline;\n}\n.acciones-ventanilla {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: center;\n  align-items: center;\n  gap: 12px;\n  margin-top: 20px;\n}\n/*# sourceMappingURL=registro-ventanilla.css.map */\n'] }]
  }], () => [{ type: CatalogoService }, { type: QuejaVentanillaService }, { type: ToastService }, { type: Router }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(RegistroVentanilla, { className: "RegistroVentanilla", filePath: "src/app/pages/registro-ventanilla/registro-ventanilla.ts", lineNumber: 71 });
})();
export {
  RegistroVentanilla,
  TIPOS_DOCUMENTO_VENTANILLA
};
//# sourceMappingURL=chunk-7E4JR4CL.js.map
