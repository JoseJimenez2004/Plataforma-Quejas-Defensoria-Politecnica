import {
  HttpClient,
  HttpParams,
  Injectable,
  setClassMetadata,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-JXAMNPEM.js";

// src/app/core/services/seguimiento.service.ts
var SeguimientoService = class _SeguimientoService {
  http;
  apiUrl = "/api/admin/seguimiento";
  constructor(http) {
    this.http = http;
  }
  tablero() {
    return this.http.get(`${this.apiUrl}/tablero`);
  }
  filtros() {
    return this.http.get(`${this.apiUrl}/filtros`);
  }
  quejas(filtro, pagina, tamanio = 15) {
    let params = new HttpParams().set("pagina", pagina).set("tamanio", tamanio);
    for (const [clave, valor] of Object.entries(filtro)) {
      if (valor) {
        params = params.set(clave, valor);
      }
    }
    return this.http.get(`${this.apiUrl}/quejas`, { params });
  }
  detalle(folio) {
    return this.http.get(`${this.apiUrl}/quejas/${encodeURIComponent(folio)}`);
  }
  evidencia(folio, id) {
    return this.http.get(`${this.apiUrl}/quejas/${encodeURIComponent(folio)}/evidencias/${id}`, { responseType: "blob" });
  }
  unidades(texto = "") {
    const params = texto.trim() ? new HttpParams().set("q", texto.trim()) : void 0;
    return this.http.get(`${this.apiUrl}/unidades`, { params });
  }
  static \u0275fac = function SeguimientoService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _SeguimientoService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _SeguimientoService, factory: _SeguimientoService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SeguimientoService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

export {
  SeguimientoService
};
//# sourceMappingURL=chunk-75OY42UO.js.map
