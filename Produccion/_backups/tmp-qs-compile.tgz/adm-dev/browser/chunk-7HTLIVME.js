import {
  AuthAdminService
} from "./chunk-4N3TKIMC.js";
import {
  SeguimientoService
} from "./chunk-75OY42UO.js";
import {
  RouterLink
} from "./chunk-MQC2YFSD.js";
import {
  etiquetaRol
} from "./chunk-LVQZVV2Y.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DatePipe,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassMap,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵpureFunction1,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵstyleProp,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2
} from "./chunk-JXAMNPEM.js";

// src/app/pages/dashboard/dashboard.ts
var _c0 = () => ({ etapa: "RECEPCION" });
var _c1 = () => ({ etapa: "CON_QUEJOSO" });
var _c2 = () => ({ etapa: "PRIMER_CONTACTO" });
var _c3 = () => ({ etapa: "SUBDEFENSORIA" });
var _c4 = () => ({ etapa: "CERRADA" });
var _c5 = () => ({ abogado: "SIN_ASIGNAR", etapa: "PRIMER_CONTACTO" });
var _c6 = (a0) => ({ etapa: a0 });
var _c7 = (a0) => ({ estatus: a0 });
var _c8 = (a0) => ({ mes: a0 });
var _c9 = (a0) => ({ unidad: a0 });
var _c10 = () => ["/quejas"];
var _c11 = (a0) => ({ recepcionista: a0 });
var _c12 = (a0) => ({ abogado: a0 });
var _c13 = (a0) => ["/quejas", a0];
var _forTrack0 = ($index, $item) => $item.clave;
var _forTrack1 = ($index, $item) => $item.correo;
var _forTrack2 = ($index, $item) => $item.nombre;
var _forTrack3 = ($index, $item) => $item.folio;
function Dashboard_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 7);
    \u0275\u0275text(1, "Cargando panel\u2026");
    \u0275\u0275elementEnd();
  }
}
function Dashboard_Conditional_13_For_59_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 47);
  }
  if (rf & 2) {
    const e_r1 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275classMap("etapa-" + e_r1.clave);
    \u0275\u0275styleProp("flex-grow", e_r1.total);
    \u0275\u0275property("title", e_r1.etiqueta + ": " + e_r1.total);
  }
}
function Dashboard_Conditional_13_For_59_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, Dashboard_Conditional_13_For_59_Conditional_0_Template, 1, 5, "span", 46);
  }
  if (rf & 2) {
    const e_r1 = ctx.$implicit;
    \u0275\u0275conditional(e_r1.total > 0 ? 0 : -1);
  }
}
function Dashboard_Conditional_13_For_62_For_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li")(1, "a", 36)(2, "span");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "b");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const s_r2 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction1(3, _c7, s_r2.clave));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(s_r2.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(s_r2.total);
  }
}
function Dashboard_Conditional_13_For_62_ForEmpty_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li", 51);
    \u0275\u0275text(1, "Sin quejas");
    \u0275\u0275elementEnd();
  }
}
function Dashboard_Conditional_13_For_62_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div")(1, "a", 48)(2, "span", 49);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "strong");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 50);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "ul");
    \u0275\u0275repeaterCreate(9, Dashboard_Conditional_13_For_62_For_10_Template, 6, 5, "li", null, _forTrack0, false, Dashboard_Conditional_13_For_62_ForEmpty_11_Template, 2, 0, "li", 51);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const e_r3 = ctx.$implicit;
    const ctx_r3 = \u0275\u0275nextContext(2);
    \u0275\u0275classMap("flujo-etapa etapa-" + e_r3.clave);
    \u0275\u0275advance();
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction1(7, _c6, e_r3.clave));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(e_r3.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(e_r3.total);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", ctx_r3.pct(e_r3.total, ctx_r3.totalEtapas), "%");
    \u0275\u0275advance(2);
    \u0275\u0275repeater(e_r3.estatus);
  }
}
function Dashboard_Conditional_13_For_78_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "a", 29)(1, "span", 52);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 53);
    \u0275\u0275element(4, "span", 26)(5, "span", 27);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 54);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const m_r5 = ctx.$implicit;
    const ctx_r3 = \u0275\u0275nextContext(2);
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction1(8, _c8, m_r5.clave))("title", m_r5.etiqueta + ": " + m_r5.recibidas + " recibidas, " + m_r5.atendidas + " atendidas");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(m_r5.recibidas || "");
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("height", ctx_r3.pct(m_r5.recibidas, ctx_r3.maxMes), "%");
    \u0275\u0275advance();
    \u0275\u0275styleProp("height", ctx_r3.pct(m_r5.atendidas, ctx_r3.maxMes), "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(m_r5.etiqueta);
  }
}
function Dashboard_Conditional_13_Conditional_88_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 7);
    \u0275\u0275text(1, "A\xFAn no hay quejas.");
    \u0275\u0275elementEnd();
  }
}
function Dashboard_Conditional_13_For_91_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li")(1, "a", 55)(2, "span", 56);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 57);
    \u0275\u0275element(5, "span");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 58)(7, "b");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const u_r6 = ctx.$implicit;
    const ctx_r3 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction1(7, _c9, u_r6.clave))("title", u_r6.nombre || u_r6.clave);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r3.nombreUnidad(u_r6));
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", ctx_r3.pct(u_r6.total, ctx_r3.maxUnidad), "%");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(u_r6.enTramite);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" / ", u_r6.total);
  }
}
function Dashboard_Conditional_13_For_118_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 60);
  }
}
function Dashboard_Conditional_13_For_118_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr", 35)(1, "td", 59);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td", 34);
    \u0275\u0275conditionalCreate(4, Dashboard_Conditional_13_For_118_Conditional_4_Template, 1, 0, "span", 60);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "td", 34);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "td", 34)(9, "b");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "td", 34);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "td", 34);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const r_r7 = ctx.$implicit;
    \u0275\u0275property("routerLink", \u0275\u0275pureFunction0(9, _c10))("queryParams", \u0275\u0275pureFunction1(10, _c11, r_r7.correo));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(r_r7.nombre);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(r_r7.abiertasAhora ? 4 : -1);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(r_r7.abiertasAhora);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(r_r7.atendidasHoy);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(r_r7.atendidas);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(r_r7.turnadas);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(r_r7.conObservaciones);
  }
}
function Dashboard_Conditional_13_ForEmpty_119_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 61);
    \u0275\u0275text(2, "No hay recepcionistas activas.");
    \u0275\u0275elementEnd()();
  }
}
function Dashboard_Conditional_13_For_131_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "em");
    \u0275\u0275text(1, "\xB7 Titular");
    \u0275\u0275elementEnd();
  }
}
function Dashboard_Conditional_13_For_131_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li")(1, "a", 36)(2, "span", 56);
    \u0275\u0275text(3);
    \u0275\u0275conditionalCreate(4, Dashboard_Conditional_13_For_131_Conditional_4_Template, 2, 0, "em");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 57);
    \u0275\u0275element(6, "span");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "span", 58)(8, "b");
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const a_r8 = ctx.$implicit;
    const ctx_r3 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction1(7, _c12, a_r8.nombre));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", a_r8.nombre, " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(a_r8.rol === "DEFENSOR" ? 4 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", ctx_r3.pct(a_r8.enTramite, ctx_r3.maxAbogado), "%");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(a_r8.enTramite);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" en tr\xE1mite \xB7 ", a_r8.cerradas, " cerradas");
  }
}
function Dashboard_Conditional_13_ForEmpty_132_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li", 7);
    \u0275\u0275text(1, "No hay abogados dados de alta.");
    \u0275\u0275elementEnd();
  }
}
function Dashboard_Conditional_13_Conditional_141_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 7);
    \u0275\u0275text(1, "Ninguna queja ha sido regresada con observaciones.");
    \u0275\u0275elementEnd();
  }
}
function Dashboard_Conditional_13_For_144_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li")(1, "span", 62);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 63);
    \u0275\u0275element(4, "span");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "b");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const m_r9 = ctx.$implicit;
    const ctx_r3 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(m_r9.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", ctx_r3.pct(m_r9.total, ctx_r3.maxMotivo), "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(m_r9.total);
  }
}
function Dashboard_Conditional_13_For_156_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li")(1, "a", 64)(2, "span", 65)(3, "b");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275text(5);
    \u0275\u0275elementStart(6, "span", 66);
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "date");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "span", 67);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const r_r10 = ctx.$implicit;
    const ctx_r3 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("routerLink", \u0275\u0275pureFunction1(9, _c13, r_r10.folio));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(r_r10.folio);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" \xB7 ", r_r10.quejoso, " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", \u0275\u0275pipeBind2(8, 6, r_r10.fecha, "dd/MM/yy"), " \xB7 ", r_r10.recepcionista || "\u2014");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r3.motivoCorto(r_r10.motivo));
  }
}
function Dashboard_Conditional_13_ForEmpty_157_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li", 7);
    \u0275\u0275text(1, "No hay quejas esperando correcci\xF3n.");
    \u0275\u0275elementEnd();
  }
}
function Dashboard_Conditional_13_For_167_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const r_r11 = ctx.$implicit;
    const ctx_r3 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2("", r_r11.total, " ", ctx_r3.etiquetaRol(r_r11.clave));
  }
}
function Dashboard_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 8)(1, "a", 9)(2, "span", 10);
    \u0275\u0275text(3, "Quejas recibidas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "strong");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 11);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "a", 12)(9, "span", 10);
    \u0275\u0275text(10, "En Recepci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "strong");
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span", 11);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "a", 13)(16, "span", 10);
    \u0275\u0275text(17, "Con el quejoso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "strong");
    \u0275\u0275text(19);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "span", 11);
    \u0275\u0275text(21);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(22, "a", 14)(23, "span", 10);
    \u0275\u0275text(24, "En Primer Contacto");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "strong");
    \u0275\u0275text(26);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "span", 11);
    \u0275\u0275text(28, "turnadas, en an\xE1lisis o procedentes");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(29, "a", 15)(30, "span", 10);
    \u0275\u0275text(31, "En Subdefensor\xEDa");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(32, "strong");
    \u0275\u0275text(33);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "span", 11);
    \u0275\u0275text(35, "en investigaci\xF3n, oficios o acuerdos");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(36, "a", 16)(37, "span", 10);
    \u0275\u0275text(38, "Cerradas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(39, "strong");
    \u0275\u0275text(40);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(41, "span", 11);
    \u0275\u0275text(42, "concluidas, improcedentes, remitidas o canceladas");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(43, "div", 17)(44, "span", 10);
    \u0275\u0275text(45, "Respuesta de Recepci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "strong");
    \u0275\u0275text(47);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(48, "span", 11);
    \u0275\u0275text(49);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(50, "div", 18)(51, "div", 19)(52, "div")(53, "h3");
    \u0275\u0275text(54, "\xBFD\xF3nde est\xE1n las quejas?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(55, "p");
    \u0275\u0275text(56, "Cada queja seg\xFAn el \xE1rea que la tiene ahora. Haz clic en una etapa o en un estatus para ver cu\xE1les son.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(57, "div", 20);
    \u0275\u0275repeaterCreate(58, Dashboard_Conditional_13_For_59_Template, 1, 1, null, null, _forTrack0);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(60, "div", 21);
    \u0275\u0275repeaterCreate(61, Dashboard_Conditional_13_For_62_Template, 12, 9, "div", 22, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(63, "div", 23)(64, "div", 24)(65, "div", 19)(66, "div")(67, "h3");
    \u0275\u0275text(68, "Quejas por mes");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(69, "p");
    \u0275\u0275text(70, "\xDAltimos 12 meses \xB7 clic en un mes para ver sus quejas");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(71, "span", 25);
    \u0275\u0275element(72, "i", 26);
    \u0275\u0275text(73, "Recibidas ");
    \u0275\u0275element(74, "i", 27);
    \u0275\u0275text(75, "Atendidas por Recepci\xF3n");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(76, "div", 28);
    \u0275\u0275repeaterCreate(77, Dashboard_Conditional_13_For_78_Template, 8, 10, "a", 29, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(79, "div", 24)(80, "div", 19)(81, "div")(82, "h3");
    \u0275\u0275text(83, "Unidades con m\xE1s quejas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(84, "p");
    \u0275\u0275text(85, "En tr\xE1mite / total \xB7 clic para ver sus quejas");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(86, "a", 30);
    \u0275\u0275text(87, "Ver todas \u2192");
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(88, Dashboard_Conditional_13_Conditional_88_Template, 2, 0, "p", 7);
    \u0275\u0275elementStart(89, "ul", 31);
    \u0275\u0275repeaterCreate(90, Dashboard_Conditional_13_For_91_Template, 10, 9, "li", null, _forTrack0);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(92, "div", 23)(93, "div", 24)(94, "div", 19)(95, "div")(96, "h3");
    \u0275\u0275text(97, "Recepci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(98, "p");
    \u0275\u0275text(99, "Qui\xE9n atiende qu\xE9 \xB7 clic para ver las quejas de cada recepcionista");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(100, "div", 32)(101, "table", 33)(102, "thead")(103, "tr")(104, "th");
    \u0275\u0275text(105, "Recepcionista");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(106, "th", 34);
    \u0275\u0275text(107, "Abiertas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(108, "th", 34);
    \u0275\u0275text(109, "Hoy");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(110, "th", 34);
    \u0275\u0275text(111, "Atendidas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(112, "th", 34);
    \u0275\u0275text(113, "Turnadas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(114, "th", 34);
    \u0275\u0275text(115, "Observ.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(116, "tbody");
    \u0275\u0275repeaterCreate(117, Dashboard_Conditional_13_For_118_Template, 15, 12, "tr", 35, _forTrack1, false, Dashboard_Conditional_13_ForEmpty_119_Template, 3, 0, "tr");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(120, "div", 24)(121, "div", 19)(122, "div")(123, "h3");
    \u0275\u0275text(124, "Abogados");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(125, "p");
    \u0275\u0275text(126, "Carga de trabajo \xB7 clic para ver las quejas de cada abogado");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(127, "a", 36);
    \u0275\u0275text(128, "Sin abogado \u2192");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(129, "ul", 37);
    \u0275\u0275repeaterCreate(130, Dashboard_Conditional_13_For_131_Template, 11, 9, "li", null, _forTrack2, false, Dashboard_Conditional_13_ForEmpty_132_Template, 2, 0, "li", 7);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(133, "div", 23)(134, "div", 24)(135, "div", 19)(136, "div")(137, "h3");
    \u0275\u0275text(138, "\xBFPor qu\xE9 se rechazan?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(139, "p");
    \u0275\u0275text(140, "Motivos m\xE1s frecuentes al regresar una queja con observaciones");
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(141, Dashboard_Conditional_13_Conditional_141_Template, 2, 0, "p", 7);
    \u0275\u0275elementStart(142, "ul", 38);
    \u0275\u0275repeaterCreate(143, Dashboard_Conditional_13_For_144_Template, 7, 4, "li", null, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(145, "div", 24)(146, "div", 19)(147, "div")(148, "h3");
    \u0275\u0275text(149, "Esperando correcci\xF3n del quejoso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(150, "p");
    \u0275\u0275text(151, "Las regresadas m\xE1s recientes");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(152, "a", 36);
    \u0275\u0275text(153, "Ver todas \u2192");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(154, "ul", 39);
    \u0275\u0275repeaterCreate(155, Dashboard_Conditional_13_For_156_Template, 11, 11, "li", null, _forTrack3, false, Dashboard_Conditional_13_ForEmpty_157_Template, 2, 0, "li", 7);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(158, "div", 40)(159, "a", 41)(160, "span", 42);
    \u0275\u0275text(161);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(162, "span")(163, "b");
    \u0275\u0275text(164, "Personal de la Defensor\xEDa");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(165, "span", 43);
    \u0275\u0275repeaterCreate(166, Dashboard_Conditional_13_For_167_Template, 2, 2, "span", null, _forTrack0);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(168, "a", 44)(169, "span", 42);
    \u0275\u0275text(170);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(171, "span")(172, "b");
    \u0275\u0275text(173, "Dependencias y Unidades Acad\xE9micas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(174, "span", 43)(175, "span");
    \u0275\u0275text(176, "Cat\xE1logo del IPN");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(177, "a", 45)(178, "span", 42);
    \u0275\u0275text(179, "?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(180, "span")(181, "b");
    \u0275\u0275text(182, "Preguntas Frecuentes");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(183, "span", 43)(184, "span");
    \u0275\u0275text(185, "Las que responde el asistente del portal");
    \u0275\u0275elementEnd()()()()();
  }
  if (rf & 2) {
    const t_r12 = ctx;
    const ctx_r3 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(t_r12.kpis.total);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", t_r12.kpis.ultimos30, " en los \xFAltimos 30 d\xEDas");
    \u0275\u0275advance();
    \u0275\u0275classProp("alerta", t_r12.kpis.sinTomarMas3Dias > 0);
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction0(28, _c0));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(t_r12.kpis.enRecepcion);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", t_r12.kpis.sinTomarMas3Dias, " sin tomar desde hace m\xE1s de 3 d\xEDas");
    \u0275\u0275advance();
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction0(29, _c1));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(t_r12.kpis.conQuejoso);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("esperando correcci\xF3n \xB7 ", t_r12.kpis.rechazadasAlgunaVez, " rechazadas alguna vez");
    \u0275\u0275advance();
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction0(30, _c2));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(t_r12.kpis.enPrimerContacto);
    \u0275\u0275advance(3);
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction0(31, _c3));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(t_r12.kpis.enSubdefensoria);
    \u0275\u0275advance(3);
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction0(32, _c4));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(t_r12.kpis.cerradas);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(ctx_r3.duracion(t_r12.kpis.horasPromedioRecepcion));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", t_r12.kpis.atendidasRecepcion, " atendidas \xB7 ", t_r12.kpis.respuestasDenunciado, " respuestas de denunciados");
    \u0275\u0275advance(9);
    \u0275\u0275repeater(t_r12.etapas);
    \u0275\u0275advance(3);
    \u0275\u0275repeater(t_r12.etapas);
    \u0275\u0275advance(16);
    \u0275\u0275repeater(t_r12.porMes);
    \u0275\u0275advance(11);
    \u0275\u0275conditional(t_r12.unidades.length === 0 ? 88 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(t_r12.unidades);
    \u0275\u0275advance(27);
    \u0275\u0275repeater(t_r12.recepcion);
    \u0275\u0275advance(10);
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction0(33, _c5));
    \u0275\u0275advance(3);
    \u0275\u0275repeater(t_r12.abogados);
    \u0275\u0275advance(11);
    \u0275\u0275conditional(t_r12.motivosRechazo.length === 0 ? 141 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(t_r12.motivosRechazo);
    \u0275\u0275advance(9);
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction0(34, _c1));
    \u0275\u0275advance(3);
    \u0275\u0275repeater(t_r12.rechazosRecientes);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(t_r12.personal.total);
    \u0275\u0275advance(5);
    \u0275\u0275repeater(t_r12.personal.porRol);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(t_r12.personal.dependencias);
  }
}
var Dashboard = class _Dashboard {
  seguimiento;
  auth;
  toast;
  cdr;
  etiquetaRol = etiquetaRol;
  tablero = null;
  cargando = true;
  fechaHoy = (() => {
    const t = new Intl.DateTimeFormat("es-MX", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(/* @__PURE__ */ new Date());
    return t.charAt(0).toUpperCase() + t.slice(1);
  })();
  constructor(seguimiento, auth, toast, cdr) {
    this.seguimiento = seguimiento;
    this.auth = auth;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.seguimiento.tablero().subscribe({
      next: (t) => {
        this.tablero = t;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.toast.error("No se pudo cargar el panel general.");
        this.cdr.detectChanges();
      }
    });
  }
  get titulo() {
    return this.auth.usuarioActual()?.rol === "DEFENSOR" ? "Panel de la Defensora" : "Panel general";
  }
  /** Porcentaje entero (para anchos de barras). */
  pct(parte, total) {
    return total > 0 ? Math.max(parte > 0 ? 2 : 0, Math.round(parte / total * 100)) : 0;
  }
  get maxMes() {
    return Math.max(1, ...(this.tablero?.porMes ?? []).flatMap((m) => [m.recibidas, m.atendidas]));
  }
  get maxUnidad() {
    return Math.max(1, ...(this.tablero?.unidades ?? []).map((u) => u.total));
  }
  get maxAbogado() {
    return Math.max(1, ...(this.tablero?.abogados ?? []).map((a) => a.enTramite));
  }
  get maxMotivo() {
    return Math.max(1, ...(this.tablero?.motivosRechazo ?? []).map((m) => m.total));
  }
  get totalEtapas() {
    return (this.tablero?.etapas ?? []).reduce((s, e) => s + e.total, 0);
  }
  nombreUnidad(u) {
    return u.abreviatura || u.nombre || u.clave;
  }
  duracion(horas) {
    if (horas === null || horas === void 0) {
      return "\u2014";
    }
    if (horas < 1) {
      return `${Math.max(1, Math.round(horas * 60))} min`;
    }
    return horas < 48 ? `${Math.round(horas)} h` : `${(horas / 24).toFixed(1)} d\xEDas`;
  }
  /** Primer motivo, corto, para la lista de rechazos recientes. */
  motivoCorto(motivo) {
    const primero = (motivo ?? "").split(";")[0].trim();
    return primero.length > 110 ? primero.slice(0, 107) + "\u2026" : primero;
  }
  static \u0275fac = function Dashboard_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Dashboard)(\u0275\u0275directiveInject(SeguimientoService), \u0275\u0275directiveInject(AuthAdminService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Dashboard, selectors: [["app-dashboard"]], decls: 14, vars: 3, consts: [[1, "seg-pagina"], [1, "seg-encabezado"], [1, "seg-sub"], ["routerLink", "/quejas", 1, "seg-btn"], ["width", "18", "height", "18", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["cx", "11", "cy", "11", "r", "7"], ["d", "m21 21-4.3-4.3"], [1, "seg-vacio"], [1, "seg-kpis"], ["routerLink", "/quejas", 1, "seg-kpi", "clic"], [1, "titulo"], [1, "detalle"], ["routerLink", "/quejas", 1, "seg-kpi", "clic", "etapa-RECEPCION", 3, "queryParams"], ["routerLink", "/quejas", 1, "seg-kpi", "clic", "etapa-CON_QUEJOSO", 3, "queryParams"], ["routerLink", "/quejas", 1, "seg-kpi", "clic", "etapa-PRIMER_CONTACTO", 3, "queryParams"], ["routerLink", "/quejas", 1, "seg-kpi", "clic", "etapa-SUBDEFENSORIA", 3, "queryParams"], ["routerLink", "/quejas", 1, "seg-kpi", "clic", "etapa-CERRADA", 3, "queryParams"], ["title", "Promedio de los \xFAltimos 30 d\xEDas entre que llega la queja y Recepci\xF3n la turna o la regresa", 1, "seg-kpi"], [1, "seg-panel", "bloque"], [1, "seg-panel-cabeza"], ["role", "img", "aria-label", "Distribuci\xF3n de quejas por etapa", 1, "flujo-barra"], [1, "flujo-etapas"], [3, "class"], [1, "seg-grid-2"], [1, "seg-panel"], [1, "leyenda"], [1, "recibidas"], [1, "atendidas"], [1, "meses"], ["routerLink", "/quejas", 1, "mes", 3, "queryParams", "title"], ["routerLink", "/unidades"], [1, "ranking"], [1, "seg-tabla-envoltura"], [1, "seg-tabla"], [1, "num"], [1, "clic", 3, "routerLink", "queryParams"], ["routerLink", "/quejas", 3, "queryParams"], [1, "ranking", "abogados"], [1, "motivos"], [1, "rechazos"], [1, "admin-accesos"], ["routerLink", "/usuarios-roles", 1, "seg-panel", "acceso"], [1, "acceso-num"], [1, "acceso-roles"], ["routerLink", "/catalogo-dependencias", 1, "seg-panel", "acceso"], ["routerLink", "/chatbot", 1, "seg-panel", "acceso"], [3, "class", "flex-grow", "title"], [3, "title"], ["routerLink", "/quejas", 1, "flujo-cabeza", 3, "queryParams"], [1, "flujo-nombre"], [1, "flujo-pct"], [1, "vacio"], [1, "mes-valor"], [1, "mes-barras"], [1, "mes-etiqueta"], ["routerLink", "/quejas", 3, "queryParams", "title"], [1, "ranking-nombre"], [1, "seg-barra"], [1, "ranking-num"], [1, "fuerte"], [1, "punto-activo"], ["colspan", "6", 1, "seg-vacio"], [1, "motivo-texto"], [1, "seg-barra", "etapa-CON_QUEJOSO"], [3, "routerLink"], [1, "rechazo-cabeza"], [1, "suave"], [1, "rechazo-motivo"]], template: function Dashboard_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "section", 0)(1, "div", 1)(2, "div")(3, "h2");
      \u0275\u0275text(4);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(5, "p", 2);
      \u0275\u0275text(6);
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(7, "a", 3);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(8, "svg", 4);
      \u0275\u0275element(9, "circle", 5)(10, "path", 6);
      \u0275\u0275elementEnd();
      \u0275\u0275text(11, " Buscar una queja ");
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(12, Dashboard_Conditional_12_Template, 2, 0, "p", 7)(13, Dashboard_Conditional_13_Template, 186, 35);
      \u0275\u0275elementEnd();
    }
    if (rf & 2) {
      let tmp_2_0;
      \u0275\u0275advance(4);
      \u0275\u0275textInterpolate(ctx.titulo);
      \u0275\u0275advance(2);
      \u0275\u0275textInterpolate1("", ctx.fechaHoy, " \xB7 Todo lo que pasa con las quejas, de Recepci\xF3n a la conclusi\xF3n.");
      \u0275\u0275advance(6);
      \u0275\u0275conditional(ctx.cargando ? 12 : (tmp_2_0 = ctx.tablero) ? 13 : -1, tmp_2_0);
    }
  }, dependencies: [CommonModule, RouterLink, DatePipe], styles: ['@charset "UTF-8";\n\n\n.bloque[_ngcontent-%COMP%] {\n  margin-bottom: 18px;\n}\n.flujo-barra[_ngcontent-%COMP%] {\n  display: flex;\n  height: 14px;\n  gap: 3px;\n  margin-bottom: 14px;\n  border-radius: 999px;\n  overflow: hidden;\n}\n.flujo-barra[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  min-width: 6px;\n  background: var(--acento);\n}\n.flujo-etapas[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(5, minmax(0, 1fr));\n  gap: 12px;\n}\n@media (max-width: 1100px) {\n  .flujo-etapas[_ngcontent-%COMP%] {\n    grid-template-columns: repeat(2, minmax(0, 1fr));\n  }\n}\n.flujo-etapa[_ngcontent-%COMP%] {\n  padding: 10px 12px;\n  border-top: 4px solid var(--acento);\n  border-radius: 10px;\n  background: var(--suave);\n}\n.flujo-etapa[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 8px 0 0;\n  padding: 0;\n  display: grid;\n  gap: 2px;\n}\n.flujo-etapa[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  gap: 8px;\n  padding: 3px 6px;\n  border-radius: 6px;\n  color: var(--texto);\n  font-size: 12.5px;\n  text-decoration: none;\n}\n.flujo-etapa[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  background: rgba(255, 255, 255, 0.7);\n}\n.flujo-etapa[_ngcontent-%COMP%]   .vacio[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 12px;\n  padding: 3px 6px;\n}\n.flujo-cabeza[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 1fr auto;\n  align-items: baseline;\n  color: var(--texto-etapa);\n  text-decoration: none;\n}\n.flujo-cabeza[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  font-size: 26px;\n  font-weight: 900;\n}\n.flujo-cabeza[_ngcontent-%COMP%]:hover   .flujo-nombre[_ngcontent-%COMP%] {\n  text-decoration: underline;\n}\n.flujo-nombre[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 800;\n}\n.flujo-pct[_ngcontent-%COMP%] {\n  grid-column: 1/-1;\n  font-size: 11.5px;\n  opacity: 0.8;\n}\n.leyenda[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  color: var(--texto-suave);\n  font-size: 12px;\n  white-space: nowrap;\n}\n.leyenda[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  display: inline-block;\n  width: 10px;\n  height: 10px;\n  border-radius: 2px;\n  margin-left: 6px;\n}\n.leyenda[_ngcontent-%COMP%]   i.recibidas[_ngcontent-%COMP%] {\n  background: var(--guinda);\n}\n.leyenda[_ngcontent-%COMP%]   i.atendidas[_ngcontent-%COMP%] {\n  background: #d7b3c4;\n}\n.meses[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(12, minmax(0, 1fr));\n  gap: 6px;\n  height: 210px;\n}\n.mes[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 4px;\n  min-width: 0;\n  color: var(--texto-suave);\n  text-decoration: none;\n}\n.mes[_ngcontent-%COMP%]:hover   .mes-etiqueta[_ngcontent-%COMP%] {\n  color: var(--guinda);\n  font-weight: 700;\n}\n.mes-valor[_ngcontent-%COMP%] {\n  height: 16px;\n  color: var(--negro-inst);\n  font-size: 11.5px;\n  font-weight: 700;\n}\n.mes-barras[_ngcontent-%COMP%] {\n  flex: 1;\n  width: 100%;\n  display: flex;\n  align-items: flex-end;\n  justify-content: center;\n  gap: 2px;\n  border-bottom: 1px solid #e4e6ea;\n}\n.mes-barras[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  width: 40%;\n  max-width: 16px;\n  min-height: 0;\n  border-radius: 3px 3px 0 0;\n}\n.mes-barras[_ngcontent-%COMP%]   span.recibidas[_ngcontent-%COMP%] {\n  background: var(--guinda);\n}\n.mes-barras[_ngcontent-%COMP%]   span.atendidas[_ngcontent-%COMP%] {\n  background: #d7b3c4;\n}\n.mes-etiqueta[_ngcontent-%COMP%] {\n  font-size: 11px;\n  white-space: nowrap;\n}\n.ranking[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 4px;\n}\n.ranking[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(110px, 0.9fr) minmax(80px, 1.4fr) auto;\n  align-items: center;\n  gap: 12px;\n  padding: 7px 8px;\n  border-radius: 8px;\n  color: var(--texto);\n  text-decoration: none;\n}\n.ranking[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  background: var(--guinda-suave);\n}\n.ranking.abogados[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  grid-template-columns: minmax(150px, 1fr) minmax(70px, 1fr) auto;\n}\n.ranking[_ngcontent-%COMP%]   em[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-style: normal;\n  font-size: 12px;\n}\n.ranking-nombre[_ngcontent-%COMP%] {\n  overflow: hidden;\n  font-size: 13.5px;\n  font-weight: 600;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n}\n.ranking-num[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 12.5px;\n  white-space: nowrap;\n}\n.ranking-num[_ngcontent-%COMP%]   b[_ngcontent-%COMP%] {\n  color: var(--negro-inst);\n}\n.punto-activo[_ngcontent-%COMP%] {\n  display: inline-block;\n  width: 7px;\n  height: 7px;\n  margin-right: 6px;\n  border-radius: 50%;\n  background: #2f6fed;\n}\n.motivos[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 10px;\n}\n.motivos[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) 90px 28px;\n  align-items: center;\n  gap: 10px;\n  font-size: 13px;\n}\n.motivos[_ngcontent-%COMP%]   b[_ngcontent-%COMP%] {\n  text-align: right;\n}\n.motivo-texto[_ngcontent-%COMP%] {\n  line-height: 1.35;\n}\n.rechazos[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 6px;\n}\n.rechazos[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  display: block;\n  padding: 8px 10px;\n  border-left: 3px solid #e5a3a3;\n  border-radius: 0 8px 8px 0;\n  background: #fdf6f6;\n  color: var(--texto);\n  text-decoration: none;\n}\n.rechazos[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  background: #fbeaea;\n}\n.rechazo-cabeza[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 13px;\n}\n.rechazo-cabeza[_ngcontent-%COMP%]   .suave[_ngcontent-%COMP%] {\n  display: block;\n  color: var(--texto-suave);\n  font-size: 12px;\n}\n.rechazo-motivo[_ngcontent-%COMP%] {\n  display: block;\n  margin-top: 2px;\n  color: #8a2a2a;\n  font-size: 12.5px;\n}\n.admin-accesos[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n  gap: 18px;\n}\n.acceso[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 16px;\n  color: var(--texto);\n  text-decoration: none;\n  border: 1px solid transparent;\n}\n.acceso[_ngcontent-%COMP%]:hover {\n  border-color: #e6c9d6;\n}\n.acceso[_ngcontent-%COMP%]   b[_ngcontent-%COMP%] {\n  display: block;\n  color: var(--guinda);\n  font-size: 15px;\n}\n.acceso-num[_ngcontent-%COMP%] {\n  display: grid;\n  place-items: center;\n  min-width: 56px;\n  height: 56px;\n  padding: 0 8px;\n  border-radius: 12px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-size: 22px;\n  font-weight: 900;\n}\n.acceso-roles[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 4px 10px;\n  margin-top: 2px;\n  color: var(--texto-suave);\n  font-size: 12.5px;\n}\n/*# sourceMappingURL=dashboard.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Dashboard, [{
    type: Component,
    args: [{ selector: "app-dashboard", standalone: true, imports: [CommonModule, RouterLink], template: `<section class="seg-pagina">
  <div class="seg-encabezado">
    <div>
      <h2>{{ titulo }}</h2>
      <p class="seg-sub">{{ fechaHoy }} \xB7 Todo lo que pasa con las quejas, de Recepci\xF3n a la conclusi\xF3n.</p>
    </div>
    <a routerLink="/quejas" class="seg-btn">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><path d="m21 21-4.3-4.3"></path></svg>
      Buscar una queja
    </a>
  </div>

  @if (cargando) {
    <p class="seg-vacio">Cargando panel\u2026</p>
  } @else if (tablero; as t) {
    <!-- ================= Indicadores ================= -->
    <div class="seg-kpis">
      <a class="seg-kpi clic" routerLink="/quejas">
        <span class="titulo">Quejas recibidas</span>
        <strong>{{ t.kpis.total }}</strong>
        <span class="detalle">{{ t.kpis.ultimos30 }} en los \xFAltimos 30 d\xEDas</span>
      </a>
      <a class="seg-kpi clic etapa-RECEPCION" [class.alerta]="t.kpis.sinTomarMas3Dias > 0"
         routerLink="/quejas" [queryParams]="{ etapa: 'RECEPCION' }">
        <span class="titulo">En Recepci\xF3n</span>
        <strong>{{ t.kpis.enRecepcion }}</strong>
        <span class="detalle">{{ t.kpis.sinTomarMas3Dias }} sin tomar desde hace m\xE1s de 3 d\xEDas</span>
      </a>
      <a class="seg-kpi clic etapa-CON_QUEJOSO" routerLink="/quejas" [queryParams]="{ etapa: 'CON_QUEJOSO' }">
        <span class="titulo">Con el quejoso</span>
        <strong>{{ t.kpis.conQuejoso }}</strong>
        <span class="detalle">esperando correcci\xF3n \xB7 {{ t.kpis.rechazadasAlgunaVez }} rechazadas alguna vez</span>
      </a>
      <a class="seg-kpi clic etapa-PRIMER_CONTACTO" routerLink="/quejas" [queryParams]="{ etapa: 'PRIMER_CONTACTO' }">
        <span class="titulo">En Primer Contacto</span>
        <strong>{{ t.kpis.enPrimerContacto }}</strong>
        <span class="detalle">turnadas, en an\xE1lisis o procedentes</span>
      </a>
      <a class="seg-kpi clic etapa-SUBDEFENSORIA" routerLink="/quejas" [queryParams]="{ etapa: 'SUBDEFENSORIA' }">
        <span class="titulo">En Subdefensor\xEDa</span>
        <strong>{{ t.kpis.enSubdefensoria }}</strong>
        <span class="detalle">en investigaci\xF3n, oficios o acuerdos</span>
      </a>
      <a class="seg-kpi clic etapa-CERRADA" routerLink="/quejas" [queryParams]="{ etapa: 'CERRADA' }">
        <span class="titulo">Cerradas</span>
        <strong>{{ t.kpis.cerradas }}</strong>
        <span class="detalle">concluidas, improcedentes, remitidas o canceladas</span>
      </a>
      <div class="seg-kpi" title="Promedio de los \xFAltimos 30 d\xEDas entre que llega la queja y Recepci\xF3n la turna o la regresa">
        <span class="titulo">Respuesta de Recepci\xF3n</span>
        <strong>{{ duracion(t.kpis.horasPromedioRecepcion) }}</strong>
        <span class="detalle">{{ t.kpis.atendidasRecepcion }} atendidas \xB7 {{ t.kpis.respuestasDenunciado }} respuestas de denunciados</span>
      </div>
    </div>

    <!-- ================= D\xF3nde est\xE1n ================= -->
    <div class="seg-panel bloque">
      <div class="seg-panel-cabeza">
        <div>
          <h3>\xBFD\xF3nde est\xE1n las quejas?</h3>
          <p>Cada queja seg\xFAn el \xE1rea que la tiene ahora. Haz clic en una etapa o en un estatus para ver cu\xE1les son.</p>
        </div>
      </div>
      <div class="flujo-barra" role="img" aria-label="Distribuci\xF3n de quejas por etapa">
        @for (e of t.etapas; track e.clave) {
          @if (e.total > 0) {
            <span [class]="'etapa-' + e.clave" [style.flex-grow]="e.total" [title]="e.etiqueta + ': ' + e.total"></span>
          }
        }
      </div>
      <div class="flujo-etapas">
        @for (e of t.etapas; track e.clave) {
          <div [class]="'flujo-etapa etapa-' + e.clave">
            <a class="flujo-cabeza" routerLink="/quejas" [queryParams]="{ etapa: e.clave }">
              <span class="flujo-nombre">{{ e.etiqueta }}</span>
              <strong>{{ e.total }}</strong>
              <span class="flujo-pct">{{ pct(e.total, totalEtapas) }}%</span>
            </a>
            <ul>
              @for (s of e.estatus; track s.clave) {
                <li>
                  <a routerLink="/quejas" [queryParams]="{ estatus: s.clave }">
                    <span>{{ s.etiqueta }}</span><b>{{ s.total }}</b>
                  </a>
                </li>
              } @empty {
                <li class="vacio">Sin quejas</li>
              }
            </ul>
          </div>
        }
      </div>
    </div>

    <!-- ================= Meses y unidades ================= -->
    <div class="seg-grid-2">
      <div class="seg-panel">
        <div class="seg-panel-cabeza">
          <div>
            <h3>Quejas por mes</h3>
            <p>\xDAltimos 12 meses \xB7 clic en un mes para ver sus quejas</p>
          </div>
          <span class="leyenda"><i class="recibidas"></i>Recibidas <i class="atendidas"></i>Atendidas por Recepci\xF3n</span>
        </div>
        <div class="meses">
          @for (m of t.porMes; track m.clave) {
            <a class="mes" routerLink="/quejas" [queryParams]="{ mes: m.clave }" [title]="m.etiqueta + ': ' + m.recibidas + ' recibidas, ' + m.atendidas + ' atendidas'">
              <span class="mes-valor">{{ m.recibidas || '' }}</span>
              <span class="mes-barras">
                <span class="recibidas" [style.height.%]="pct(m.recibidas, maxMes)"></span>
                <span class="atendidas" [style.height.%]="pct(m.atendidas, maxMes)"></span>
              </span>
              <span class="mes-etiqueta">{{ m.etiqueta }}</span>
            </a>
          }
        </div>
      </div>

      <div class="seg-panel">
        <div class="seg-panel-cabeza">
          <div>
            <h3>Unidades con m\xE1s quejas</h3>
            <p>En tr\xE1mite / total \xB7 clic para ver sus quejas</p>
          </div>
          <a routerLink="/unidades">Ver todas \u2192</a>
        </div>
        @if (t.unidades.length === 0) {
          <p class="seg-vacio">A\xFAn no hay quejas.</p>
        }
        <ul class="ranking">
          @for (u of t.unidades; track u.clave) {
            <li>
              <a routerLink="/quejas" [queryParams]="{ unidad: u.clave }" [title]="u.nombre || u.clave">
                <span class="ranking-nombre">{{ nombreUnidad(u) }}</span>
                <span class="seg-barra"><span [style.width.%]="pct(u.total, maxUnidad)"></span></span>
                <span class="ranking-num"><b>{{ u.enTramite }}</b> / {{ u.total }}</span>
              </a>
            </li>
          }
        </ul>
      </div>
    </div>

    <!-- ================= Personas ================= -->
    <div class="seg-grid-2">
      <div class="seg-panel">
        <div class="seg-panel-cabeza">
          <div>
            <h3>Recepci\xF3n</h3>
            <p>Qui\xE9n atiende qu\xE9 \xB7 clic para ver las quejas de cada recepcionista</p>
          </div>
        </div>
        <div class="seg-tabla-envoltura">
          <table class="seg-tabla">
            <thead>
              <tr><th>Recepcionista</th><th class="num">Abiertas</th><th class="num">Hoy</th><th class="num">Atendidas</th><th class="num">Turnadas</th><th class="num">Observ.</th></tr>
            </thead>
            <tbody>
              @for (r of t.recepcion; track r.correo) {
                <tr class="clic" [routerLink]="['/quejas']" [queryParams]="{ recepcionista: r.correo }">
                  <td class="fuerte">{{ r.nombre }}</td>
                  <td class="num">@if (r.abiertasAhora) { <span class="punto-activo"></span> }{{ r.abiertasAhora }}</td>
                  <td class="num">{{ r.atendidasHoy }}</td>
                  <td class="num"><b>{{ r.atendidas }}</b></td>
                  <td class="num">{{ r.turnadas }}</td>
                  <td class="num">{{ r.conObservaciones }}</td>
                </tr>
              } @empty {
                <tr><td colspan="6" class="seg-vacio">No hay recepcionistas activas.</td></tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <div class="seg-panel">
        <div class="seg-panel-cabeza">
          <div>
            <h3>Abogados</h3>
            <p>Carga de trabajo \xB7 clic para ver las quejas de cada abogado</p>
          </div>
          <a routerLink="/quejas" [queryParams]="{ abogado: 'SIN_ASIGNAR', etapa: 'PRIMER_CONTACTO' }">Sin abogado \u2192</a>
        </div>
        <ul class="ranking abogados">
          @for (a of t.abogados; track a.nombre) {
            <li>
              <a routerLink="/quejas" [queryParams]="{ abogado: a.nombre }">
                <span class="ranking-nombre">{{ a.nombre }} @if (a.rol === 'DEFENSOR') { <em>\xB7 Titular</em> }</span>
                <span class="seg-barra"><span [style.width.%]="pct(a.enTramite, maxAbogado)"></span></span>
                <span class="ranking-num"><b>{{ a.enTramite }}</b> en tr\xE1mite \xB7 {{ a.cerradas }} cerradas</span>
              </a>
            </li>
          } @empty {
            <li class="seg-vacio">No hay abogados dados de alta.</li>
          }
        </ul>
      </div>
    </div>

    <!-- ================= Rechazos ================= -->
    <div class="seg-grid-2">
      <div class="seg-panel">
        <div class="seg-panel-cabeza">
          <div>
            <h3>\xBFPor qu\xE9 se rechazan?</h3>
            <p>Motivos m\xE1s frecuentes al regresar una queja con observaciones</p>
          </div>
        </div>
        @if (t.motivosRechazo.length === 0) {
          <p class="seg-vacio">Ninguna queja ha sido regresada con observaciones.</p>
        }
        <ul class="motivos">
          @for (m of t.motivosRechazo; track m.clave) {
            <li>
              <span class="motivo-texto">{{ m.etiqueta }}</span>
              <span class="seg-barra etapa-CON_QUEJOSO"><span [style.width.%]="pct(m.total, maxMotivo)"></span></span>
              <b>{{ m.total }}</b>
            </li>
          }
        </ul>
      </div>

      <div class="seg-panel">
        <div class="seg-panel-cabeza">
          <div>
            <h3>Esperando correcci\xF3n del quejoso</h3>
            <p>Las regresadas m\xE1s recientes</p>
          </div>
          <a routerLink="/quejas" [queryParams]="{ etapa: 'CON_QUEJOSO' }">Ver todas \u2192</a>
        </div>
        <ul class="rechazos">
          @for (r of t.rechazosRecientes; track r.folio) {
            <li>
              <a [routerLink]="['/quejas', r.folio]">
                <span class="rechazo-cabeza"><b>{{ r.folio }}</b> \xB7 {{ r.quejoso }}
                  <span class="suave">{{ r.fecha | date: 'dd/MM/yy' }} \xB7 {{ r.recepcionista || '\u2014' }}</span></span>
                <span class="rechazo-motivo">{{ motivoCorto(r.motivo) }}</span>
              </a>
            </li>
          } @empty {
            <li class="seg-vacio">No hay quejas esperando correcci\xF3n.</li>
          }
        </ul>
      </div>
    </div>

    <!-- ================= Administraci\xF3n ================= -->
    <div class="admin-accesos">
      <a class="seg-panel acceso" routerLink="/usuarios-roles">
        <span class="acceso-num">{{ t.personal.total }}</span>
        <span>
          <b>Personal de la Defensor\xEDa</b>
          <span class="acceso-roles">
            @for (r of t.personal.porRol; track r.clave) { <span>{{ r.total }} {{ etiquetaRol(r.clave) }}</span> }
          </span>
        </span>
      </a>
      <a class="seg-panel acceso" routerLink="/catalogo-dependencias">
        <span class="acceso-num">{{ t.personal.dependencias }}</span>
        <span><b>Dependencias y Unidades Acad\xE9micas</b><span class="acceso-roles"><span>Cat\xE1logo del IPN</span></span></span>
      </a>
      <a class="seg-panel acceso" routerLink="/chatbot">
        <span class="acceso-num">?</span>
        <span><b>Preguntas Frecuentes</b><span class="acceso-roles"><span>Las que responde el asistente del portal</span></span></span>
      </a>
    </div>
  }
</section>
`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/dashboard/dashboard.scss */\n.bloque {\n  margin-bottom: 18px;\n}\n.flujo-barra {\n  display: flex;\n  height: 14px;\n  gap: 3px;\n  margin-bottom: 14px;\n  border-radius: 999px;\n  overflow: hidden;\n}\n.flujo-barra span {\n  min-width: 6px;\n  background: var(--acento);\n}\n.flujo-etapas {\n  display: grid;\n  grid-template-columns: repeat(5, minmax(0, 1fr));\n  gap: 12px;\n}\n@media (max-width: 1100px) {\n  .flujo-etapas {\n    grid-template-columns: repeat(2, minmax(0, 1fr));\n  }\n}\n.flujo-etapa {\n  padding: 10px 12px;\n  border-top: 4px solid var(--acento);\n  border-radius: 10px;\n  background: var(--suave);\n}\n.flujo-etapa ul {\n  list-style: none;\n  margin: 8px 0 0;\n  padding: 0;\n  display: grid;\n  gap: 2px;\n}\n.flujo-etapa li a {\n  display: flex;\n  justify-content: space-between;\n  gap: 8px;\n  padding: 3px 6px;\n  border-radius: 6px;\n  color: var(--texto);\n  font-size: 12.5px;\n  text-decoration: none;\n}\n.flujo-etapa li a:hover {\n  background: rgba(255, 255, 255, 0.7);\n}\n.flujo-etapa .vacio {\n  color: var(--texto-suave);\n  font-size: 12px;\n  padding: 3px 6px;\n}\n.flujo-cabeza {\n  display: grid;\n  grid-template-columns: 1fr auto;\n  align-items: baseline;\n  color: var(--texto-etapa);\n  text-decoration: none;\n}\n.flujo-cabeza strong {\n  font-size: 26px;\n  font-weight: 900;\n}\n.flujo-cabeza:hover .flujo-nombre {\n  text-decoration: underline;\n}\n.flujo-nombre {\n  font-size: 13px;\n  font-weight: 800;\n}\n.flujo-pct {\n  grid-column: 1/-1;\n  font-size: 11.5px;\n  opacity: 0.8;\n}\n.leyenda {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  color: var(--texto-suave);\n  font-size: 12px;\n  white-space: nowrap;\n}\n.leyenda i {\n  display: inline-block;\n  width: 10px;\n  height: 10px;\n  border-radius: 2px;\n  margin-left: 6px;\n}\n.leyenda i.recibidas {\n  background: var(--guinda);\n}\n.leyenda i.atendidas {\n  background: #d7b3c4;\n}\n.meses {\n  display: grid;\n  grid-template-columns: repeat(12, minmax(0, 1fr));\n  gap: 6px;\n  height: 210px;\n}\n.mes {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 4px;\n  min-width: 0;\n  color: var(--texto-suave);\n  text-decoration: none;\n}\n.mes:hover .mes-etiqueta {\n  color: var(--guinda);\n  font-weight: 700;\n}\n.mes-valor {\n  height: 16px;\n  color: var(--negro-inst);\n  font-size: 11.5px;\n  font-weight: 700;\n}\n.mes-barras {\n  flex: 1;\n  width: 100%;\n  display: flex;\n  align-items: flex-end;\n  justify-content: center;\n  gap: 2px;\n  border-bottom: 1px solid #e4e6ea;\n}\n.mes-barras span {\n  width: 40%;\n  max-width: 16px;\n  min-height: 0;\n  border-radius: 3px 3px 0 0;\n}\n.mes-barras span.recibidas {\n  background: var(--guinda);\n}\n.mes-barras span.atendidas {\n  background: #d7b3c4;\n}\n.mes-etiqueta {\n  font-size: 11px;\n  white-space: nowrap;\n}\n.ranking {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 4px;\n}\n.ranking a {\n  display: grid;\n  grid-template-columns: minmax(110px, 0.9fr) minmax(80px, 1.4fr) auto;\n  align-items: center;\n  gap: 12px;\n  padding: 7px 8px;\n  border-radius: 8px;\n  color: var(--texto);\n  text-decoration: none;\n}\n.ranking a:hover {\n  background: var(--guinda-suave);\n}\n.ranking.abogados a {\n  grid-template-columns: minmax(150px, 1fr) minmax(70px, 1fr) auto;\n}\n.ranking em {\n  color: var(--texto-suave);\n  font-style: normal;\n  font-size: 12px;\n}\n.ranking-nombre {\n  overflow: hidden;\n  font-size: 13.5px;\n  font-weight: 600;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n}\n.ranking-num {\n  color: var(--texto-suave);\n  font-size: 12.5px;\n  white-space: nowrap;\n}\n.ranking-num b {\n  color: var(--negro-inst);\n}\n.punto-activo {\n  display: inline-block;\n  width: 7px;\n  height: 7px;\n  margin-right: 6px;\n  border-radius: 50%;\n  background: #2f6fed;\n}\n.motivos {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 10px;\n}\n.motivos li {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) 90px 28px;\n  align-items: center;\n  gap: 10px;\n  font-size: 13px;\n}\n.motivos b {\n  text-align: right;\n}\n.motivo-texto {\n  line-height: 1.35;\n}\n.rechazos {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 6px;\n}\n.rechazos a {\n  display: block;\n  padding: 8px 10px;\n  border-left: 3px solid #e5a3a3;\n  border-radius: 0 8px 8px 0;\n  background: #fdf6f6;\n  color: var(--texto);\n  text-decoration: none;\n}\n.rechazos a:hover {\n  background: #fbeaea;\n}\n.rechazo-cabeza {\n  display: block;\n  font-size: 13px;\n}\n.rechazo-cabeza .suave {\n  display: block;\n  color: var(--texto-suave);\n  font-size: 12px;\n}\n.rechazo-motivo {\n  display: block;\n  margin-top: 2px;\n  color: #8a2a2a;\n  font-size: 12.5px;\n}\n.admin-accesos {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));\n  gap: 18px;\n}\n.acceso {\n  display: flex;\n  align-items: center;\n  gap: 16px;\n  color: var(--texto);\n  text-decoration: none;\n  border: 1px solid transparent;\n}\n.acceso:hover {\n  border-color: #e6c9d6;\n}\n.acceso b {\n  display: block;\n  color: var(--guinda);\n  font-size: 15px;\n}\n.acceso-num {\n  display: grid;\n  place-items: center;\n  min-width: 56px;\n  height: 56px;\n  padding: 0 8px;\n  border-radius: 12px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-size: 22px;\n  font-weight: 900;\n}\n.acceso-roles {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 4px 10px;\n  margin-top: 2px;\n  color: var(--texto-suave);\n  font-size: 12.5px;\n}\n/*# sourceMappingURL=dashboard.css.map */\n'] }]
  }], () => [{ type: SeguimientoService }, { type: AuthAdminService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Dashboard, { className: "Dashboard", filePath: "src/app/pages/dashboard/dashboard.ts", lineNumber: 22 });
})();
export {
  Dashboard
};
//# sourceMappingURL=chunk-7HTLIVME.js.map
