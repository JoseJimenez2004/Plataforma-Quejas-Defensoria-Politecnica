import {
  AuthAdminService,
  irALoginPersonal
} from "./chunk-4N3TKIMC.js";
import {
  Router,
  RouterLink,
  RouterLinkActive,
  RouterOutlet
} from "./chunk-MQC2YFSD.js";
import {
  etiquetaRol,
  iniciales
} from "./chunk-LVQZVV2Y.js";
import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel
} from "./chunk-A2QHADRU.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DatePipe,
  HostListener,
  HttpClient,
  Injectable,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵdomElement,
  ɵɵdomElementEnd,
  ɵɵdomElementStart,
  ɵɵdomListener,
  ɵɵdomProperty,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵresolveDocument,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-JXAMNPEM.js";

// src/app/shared/campana-notificaciones/campana-notificaciones.ts
var _forTrack0 = ($index, $item) => $item.id;
function CampanaNotificaciones_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "span", 5);
    \u0275\u0275text(1);
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.noLeidas > 99 ? "99+" : ctx_r0.noLeidas);
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275domElementStart(0, "button", 11);
    \u0275\u0275domListener("click", function CampanaNotificaciones_Conditional_6_Conditional_4_Template_button_click_0_listener($event) {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.marcarTodas($event));
    });
    \u0275\u0275text(1, "Marcar todas como le\xEDdas");
    \u0275\u0275domElementEnd();
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "p", 10);
    \u0275\u0275text(1, "Cargando\u2026");
    \u0275\u0275domElementEnd();
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "p", 10);
    \u0275\u0275text(1, "No se pudieron cargar las notificaciones.");
    \u0275\u0275domElementEnd();
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "p", 10);
    \u0275\u0275text(1, "No tienes notificaciones.");
    \u0275\u0275domElementEnd();
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_8_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275domElementStart(0, "li", 13);
    \u0275\u0275domListener("click", function CampanaNotificaciones_Conditional_6_Conditional_8_For_2_Template_li_click_0_listener($event) {
      const n_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.marcarLeida(n_r4, $event));
    });
    \u0275\u0275domElementStart(1, "span", 14);
    \u0275\u0275text(2);
    \u0275\u0275domElementEnd();
    \u0275\u0275domElementStart(3, "span", 15);
    \u0275\u0275text(4);
    \u0275\u0275domElementEnd();
    \u0275\u0275domElementStart(5, "span", 16);
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "date");
    \u0275\u0275domElementEnd()();
  }
  if (rf & 2) {
    const n_r4 = ctx.$implicit;
    \u0275\u0275classProp("no-leida", !n_r4.leida);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(n_r4.titulo);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(n_r4.mensaje);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(7, 5, n_r4.fechaCreacion, "dd/MM/yyyy HH:mm"));
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "ul");
    \u0275\u0275repeaterCreate(1, CampanaNotificaciones_Conditional_6_Conditional_8_For_2_Template, 8, 8, "li", 12, _forTrack0);
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.notificaciones);
  }
}
function CampanaNotificaciones_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "div", 7);
    \u0275\u0275domListener("click", function CampanaNotificaciones_Conditional_6_Template_div_click_0_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275domElementStart(1, "div", 8)(2, "strong");
    \u0275\u0275text(3, "Notificaciones");
    \u0275\u0275domElementEnd();
    \u0275\u0275conditionalCreate(4, CampanaNotificaciones_Conditional_6_Conditional_4_Template, 2, 0, "button", 9);
    \u0275\u0275domElementEnd();
    \u0275\u0275conditionalCreate(5, CampanaNotificaciones_Conditional_6_Conditional_5_Template, 2, 0, "p", 10)(6, CampanaNotificaciones_Conditional_6_Conditional_6_Template, 2, 0, "p", 10)(7, CampanaNotificaciones_Conditional_6_Conditional_7_Template, 2, 0, "p", 10)(8, CampanaNotificaciones_Conditional_6_Conditional_8_Template, 3, 0, "ul");
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r0.noLeidas > 0 ? 4 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.cargando ? 5 : !ctx_r0.disponible ? 6 : ctx_r0.notificaciones.length === 0 ? 7 : 8);
  }
}
var CampanaNotificaciones = class _CampanaNotificaciones {
  http;
  cdr;
  apiUrl = "/api/notificaciones";
  intervaloMs = 6e4;
  temporizador = null;
  noLeidas = 0;
  abierta = false;
  cargando = false;
  disponible = true;
  notificaciones = [];
  constructor(http, cdr) {
    this.http = http;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.contar();
    this.temporizador = setInterval(() => this.contar(), this.intervaloMs);
  }
  ngOnDestroy() {
    if (this.temporizador) {
      clearInterval(this.temporizador);
    }
  }
  cerrar() {
    if (this.abierta) {
      this.abierta = false;
      this.cdr.detectChanges();
    }
  }
  alternar(evento) {
    evento.stopPropagation();
    this.abierta = !this.abierta;
    if (this.abierta) {
      this.cargarLista();
    }
    this.cdr.detectChanges();
  }
  marcarLeida(n, evento) {
    evento.stopPropagation();
    if (n.leida) {
      return;
    }
    this.http.put(`${this.apiUrl}/${n.id}/leida`, {}).subscribe({
      next: () => {
        n.leida = true;
        this.noLeidas = Math.max(0, this.noLeidas - 1);
        this.cdr.detectChanges();
      },
      error: () => {
      }
    });
  }
  marcarTodas(evento) {
    evento.stopPropagation();
    this.notificaciones.filter((n) => !n.leida).forEach((n) => this.marcarLeida(n, evento));
  }
  contar() {
    this.http.get(`${this.apiUrl}/mias/no-leidas`).subscribe({
      next: (r) => {
        this.disponible = true;
        this.noLeidas = r?.noLeidas ?? 0;
        this.cdr.detectChanges();
      },
      // Si notificaciones-service no responde, la campana simplemente no muestra conteo.
      error: () => {
        this.disponible = false;
        this.cdr.detectChanges();
      }
    });
  }
  cargarLista() {
    this.cargando = true;
    this.http.get(`${this.apiUrl}/mias`).subscribe({
      next: (lista) => {
        this.notificaciones = (lista ?? []).slice(0, 30);
        this.noLeidas = this.notificaciones.filter((n) => !n.leida).length;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.disponible = false;
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function CampanaNotificaciones_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _CampanaNotificaciones)(\u0275\u0275directiveInject(HttpClient), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _CampanaNotificaciones, selectors: [["app-campana-notificaciones"]], hostBindings: function CampanaNotificaciones_HostBindings(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275listener("click", function CampanaNotificaciones_click_HostBindingHandler() {
        return ctx.cerrar();
      }, \u0275\u0275resolveDocument);
    }
  }, decls: 7, vars: 4, consts: [[1, "campana"], ["type", "button", 1, "campana-boton", 3, "click", "title"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"], ["d", "M10.3 21a1.94 1.94 0 0 0 3.4 0"], [1, "campana-conteo"], [1, "campana-panel"], [1, "campana-panel", 3, "click"], [1, "campana-encabezado"], ["type", "button", 1, "campana-todas"], [1, "campana-vacio"], ["type", "button", 1, "campana-todas", 3, "click"], [3, "no-leida"], [3, "click"], [1, "titulo"], [1, "mensaje"], [1, "fecha"]], template: function CampanaNotificaciones_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275domElementStart(0, "div", 0)(1, "button", 1);
      \u0275\u0275domListener("click", function CampanaNotificaciones_Template_button_click_1_listener($event) {
        return ctx.alternar($event);
      });
      \u0275\u0275namespaceSVG();
      \u0275\u0275domElementStart(2, "svg", 2);
      \u0275\u0275domElement(3, "path", 3)(4, "path", 4);
      \u0275\u0275domElementEnd();
      \u0275\u0275conditionalCreate(5, CampanaNotificaciones_Conditional_5_Template, 2, 1, "span", 5);
      \u0275\u0275domElementEnd();
      \u0275\u0275conditionalCreate(6, CampanaNotificaciones_Conditional_6_Template, 9, 2, "div", 6);
      \u0275\u0275domElementEnd();
    }
    if (rf & 2) {
      \u0275\u0275advance();
      \u0275\u0275domProperty("title", ctx.disponible ? "Notificaciones" : "Notificaciones no disponibles por ahora");
      \u0275\u0275attribute("aria-label", ctx.noLeidas ? ctx.noLeidas + " notificaciones sin leer" : "Notificaciones");
      \u0275\u0275advance(4);
      \u0275\u0275conditional(ctx.noLeidas > 0 ? 5 : -1);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.abierta ? 6 : -1);
    }
  }, dependencies: [CommonModule, DatePipe], styles: ["\n.campana[_ngcontent-%COMP%] {\n  position: relative;\n}\n.campana-boton[_ngcontent-%COMP%] {\n  position: relative;\n  width: 40px;\n  height: 40px;\n  display: grid;\n  place-items: center;\n  border: none;\n  border-radius: 50%;\n  background: transparent;\n  color: var(--texto-suave, #666);\n  cursor: pointer;\n}\n.campana-boton[_ngcontent-%COMP%]:hover {\n  background: var(--guinda-suave, #f7eef1);\n  color: var(--guinda, #6c1d45);\n}\n.campana-boton[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 21px;\n  height: 21px;\n}\n.campana-conteo[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 3px;\n  right: 2px;\n  min-width: 18px;\n  height: 18px;\n  padding: 0 5px;\n  border-radius: 9px;\n  background: var(--peligro, #c62828);\n  color: #fff;\n  font-size: 0.68rem;\n  font-weight: 700;\n  line-height: 18px;\n  text-align: center;\n}\n.campana-panel[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  top: 46px;\n  z-index: 50;\n  width: min(360px, 90vw);\n  max-height: 420px;\n  overflow-y: auto;\n  border-radius: 10px;\n  background: #fff;\n  box-shadow: 0 12px 32px rgba(16, 24, 40, 0.18);\n}\n.campana-panel[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n.campana-panel[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 2px;\n  padding: 10px 14px;\n  border-top: 1px solid #eee;\n  cursor: pointer;\n}\n.campana-panel[_ngcontent-%COMP%]   li.no-leida[_ngcontent-%COMP%] {\n  background: var(--guinda-suave, #f7eef1);\n}\n.campana-encabezado[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px 14px;\n}\n.campana-todas[_ngcontent-%COMP%] {\n  border: none;\n  background: none;\n  color: var(--guinda-vivo, #9d2449);\n  font-size: 0.78rem;\n  font-weight: 600;\n  cursor: pointer;\n}\n.titulo[_ngcontent-%COMP%] {\n  font-weight: 600;\n  font-size: 0.86rem;\n}\n.mensaje[_ngcontent-%COMP%] {\n  font-size: 0.82rem;\n  color: var(--texto, #333);\n}\n.fecha[_ngcontent-%COMP%] {\n  font-size: 0.72rem;\n  color: var(--texto-suave, #666);\n}\n.campana-vacio[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 18px 14px;\n  font-size: 0.85rem;\n  color: var(--texto-suave, #666);\n}\n/*# sourceMappingURL=campana-notificaciones.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CampanaNotificaciones, [{
    type: Component,
    args: [{ selector: "app-campana-notificaciones", standalone: true, imports: [CommonModule], template: `<div class="campana">
  <button type="button" class="campana-boton" (click)="alternar($event)"
          [attr.aria-label]="noLeidas ? noLeidas + ' notificaciones sin leer' : 'Notificaciones'"
          [title]="disponible ? 'Notificaciones' : 'Notificaciones no disponibles por ahora'">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
    @if (noLeidas > 0) {
      <span class="campana-conteo">{{ noLeidas > 99 ? '99+' : noLeidas }}</span>
    }
  </button>

  @if (abierta) {
    <div class="campana-panel" (click)="$event.stopPropagation()">
      <div class="campana-encabezado">
        <strong>Notificaciones</strong>
        @if (noLeidas > 0) {
          <button type="button" class="campana-todas" (click)="marcarTodas($event)">Marcar todas como le\xEDdas</button>
        }
      </div>
      @if (cargando) {
        <p class="campana-vacio">Cargando\u2026</p>
      } @else if (!disponible) {
        <p class="campana-vacio">No se pudieron cargar las notificaciones.</p>
      } @else if (notificaciones.length === 0) {
        <p class="campana-vacio">No tienes notificaciones.</p>
      } @else {
        <ul>
          @for (n of notificaciones; track n.id) {
            <li [class.no-leida]="!n.leida" (click)="marcarLeida(n, $event)">
              <span class="titulo">{{ n.titulo }}</span>
              <span class="mensaje">{{ n.mensaje }}</span>
              <span class="fecha">{{ n.fechaCreacion | date: 'dd/MM/yyyy HH:mm' }}</span>
            </li>
          }
        </ul>
      }
    </div>
  }
</div>
`, styles: ["/* src/app/shared/campana-notificaciones/campana-notificaciones.scss */\n.campana {\n  position: relative;\n}\n.campana-boton {\n  position: relative;\n  width: 40px;\n  height: 40px;\n  display: grid;\n  place-items: center;\n  border: none;\n  border-radius: 50%;\n  background: transparent;\n  color: var(--texto-suave, #666);\n  cursor: pointer;\n}\n.campana-boton:hover {\n  background: var(--guinda-suave, #f7eef1);\n  color: var(--guinda, #6c1d45);\n}\n.campana-boton svg {\n  width: 21px;\n  height: 21px;\n}\n.campana-conteo {\n  position: absolute;\n  top: 3px;\n  right: 2px;\n  min-width: 18px;\n  height: 18px;\n  padding: 0 5px;\n  border-radius: 9px;\n  background: var(--peligro, #c62828);\n  color: #fff;\n  font-size: 0.68rem;\n  font-weight: 700;\n  line-height: 18px;\n  text-align: center;\n}\n.campana-panel {\n  position: absolute;\n  right: 0;\n  top: 46px;\n  z-index: 50;\n  width: min(360px, 90vw);\n  max-height: 420px;\n  overflow-y: auto;\n  border-radius: 10px;\n  background: #fff;\n  box-shadow: 0 12px 32px rgba(16, 24, 40, 0.18);\n}\n.campana-panel ul {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n.campana-panel li {\n  display: grid;\n  gap: 2px;\n  padding: 10px 14px;\n  border-top: 1px solid #eee;\n  cursor: pointer;\n}\n.campana-panel li.no-leida {\n  background: var(--guinda-suave, #f7eef1);\n}\n.campana-encabezado {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px 14px;\n}\n.campana-todas {\n  border: none;\n  background: none;\n  color: var(--guinda-vivo, #9d2449);\n  font-size: 0.78rem;\n  font-weight: 600;\n  cursor: pointer;\n}\n.titulo {\n  font-weight: 600;\n  font-size: 0.86rem;\n}\n.mensaje {\n  font-size: 0.82rem;\n  color: var(--texto, #333);\n}\n.fecha {\n  font-size: 0.72rem;\n  color: var(--texto-suave, #666);\n}\n.campana-vacio {\n  margin: 0;\n  padding: 18px 14px;\n  font-size: 0.85rem;\n  color: var(--texto-suave, #666);\n}\n/*# sourceMappingURL=campana-notificaciones.css.map */\n"] }]
  }], () => [{ type: HttpClient }, { type: ChangeDetectorRef }], { cerrar: [{
    type: HostListener,
    args: ["document:click"]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(CampanaNotificaciones, { className: "CampanaNotificaciones", filePath: "src/app/shared/campana-notificaciones/campana-notificaciones.ts", lineNumber: 30 });
})();

// src/app/core/services/perfil.service.ts
var PerfilService = class _PerfilService {
  http;
  apiUrl = "/api/admin/perfil";
  constructor(http) {
    this.http = http;
  }
  cambiarPassword(datos) {
    return this.http.put(`${this.apiUrl}/password`, datos);
  }
  static \u0275fac = function PerfilService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _PerfilService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _PerfilService, factory: _PerfilService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PerfilService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/admin-layout/admin-layout.ts
var _c0 = () => ({ exact: true });
function AdminLayout_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 53);
    \u0275\u0275listener("click", function AdminLayout_Conditional_23_Template_div_click_0_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(1, "button", 54);
    \u0275\u0275listener("click", function AdminLayout_Conditional_23_Template_button_click_1_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.abrirModalPassword());
    });
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 11);
    \u0275\u0275element(3, "circle", 55)(4, "path", 56)(5, "path", 57)(6, "path", 58);
    \u0275\u0275elementEnd();
    \u0275\u0275text(7, " Cambiar contrase\xF1a ");
    \u0275\u0275elementEnd()();
  }
}
function AdminLayout_Conditional_89_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 77);
    \u0275\u0275listener("click", function AdminLayout_Conditional_89_Conditional_5_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.cerrarModalPassword());
    });
    \u0275\u0275text(1, "\u2715");
    \u0275\u0275elementEnd();
  }
}
function AdminLayout_Conditional_89_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 62);
    \u0275\u0275text(1, " Tu cuenta tiene una contrase\xF1a temporal. Debes establecer una nueva antes de continuar usando la consola. ");
    \u0275\u0275elementEnd();
  }
}
function AdminLayout_Conditional_89_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 73);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorPassword);
  }
}
function AdminLayout_Conditional_89_Conditional_45_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 78);
    \u0275\u0275listener("click", function AdminLayout_Conditional_89_Conditional_45_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.cerrarModalPassword());
    });
    \u0275\u0275text(1, "Cancelar");
    \u0275\u0275elementEnd();
  }
}
function AdminLayout_Conditional_89_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 52)(1, "div", 59);
    \u0275\u0275listener("click", function AdminLayout_Conditional_89_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 60)(3, "h3");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(5, AdminLayout_Conditional_89_Conditional_5_Template, 2, 0, "button", 61);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(6, AdminLayout_Conditional_89_Conditional_6_Template, 2, 0, "p", 62);
    \u0275\u0275elementStart(7, "div", 63)(8, "label");
    \u0275\u0275text(9, "Contrase\xF1a actual");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "div", 64)(11, "input", 65);
    \u0275\u0275twoWayListener("ngModelChange", function AdminLayout_Conditional_89_Template_input_ngModelChange_11_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordActual, $event) || (ctx_r1.passwordActual = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "button", 66);
    \u0275\u0275listener("click", function AdminLayout_Conditional_89_Template_button_click_12_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.mostrarActual = !ctx_r1.mostrarActual);
    });
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(14, "div", 63)(15, "label");
    \u0275\u0275text(16, "Contrase\xF1a nueva");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "div", 64)(18, "input", 67);
    \u0275\u0275twoWayListener("ngModelChange", function AdminLayout_Conditional_89_Template_input_ngModelChange_18_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordNueva, $event) || (ctx_r1.passwordNueva = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "button", 66);
    \u0275\u0275listener("click", function AdminLayout_Conditional_89_Template_button_click_19_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.mostrarNueva = !ctx_r1.mostrarNueva);
    });
    \u0275\u0275text(20);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "ul", 68)(22, "li")(23, "span", 69);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(24, "svg", 70);
    \u0275\u0275element(25, "polyline", 71);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(26, " Al menos 8 caracteres ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(27, "li")(28, "span", 69);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(29, "svg", 70);
    \u0275\u0275element(30, "polyline", 71);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(31, " Una letra may\xFAscula ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(32, "li")(33, "span", 69);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(34, "svg", 70);
    \u0275\u0275element(35, "polyline", 71);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(36, " Un n\xFAmero ");
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(37, "div", 63)(38, "label");
    \u0275\u0275text(39, "Confirmar contrase\xF1a nueva");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "input", 72);
    \u0275\u0275twoWayListener("ngModelChange", function AdminLayout_Conditional_89_Template_input_ngModelChange_40_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordConfirmar, $event) || (ctx_r1.passwordConfirmar = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(41, AdminLayout_Conditional_89_Conditional_41_Template, 2, 1, "p", 73);
    \u0275\u0275elementStart(42, "div", 74)(43, "button", 75);
    \u0275\u0275listener("click", function AdminLayout_Conditional_89_Template_button_click_43_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.guardarPassword());
    });
    \u0275\u0275text(44);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(45, AdminLayout_Conditional_89_Conditional_45_Template, 2, 0, "button", 76);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.cambioObligatorio ? "Actualiza tu contrase\xF1a temporal" : "Cambiar mi contrase\xF1a");
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx_r1.cambioObligatorio ? 5 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.cambioObligatorio ? 6 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275property("type", ctx_r1.mostrarActual ? "text" : "password");
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordActual);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.mostrarActual ? "\u{1F648}" : "\u{1F441}\uFE0F");
    \u0275\u0275advance(5);
    \u0275\u0275property("type", ctx_r1.mostrarNueva ? "text" : "password");
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordNueva);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.mostrarNueva ? "\u{1F648}" : "\u{1F441}\uFE0F");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleLongitud);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleMayuscula);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleNumero);
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordConfirmar);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.errorPassword ? 41 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r1.guardandoPassword);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.guardandoPassword ? "Guardando\u2026" : "Actualizar Contrase\xF1a", " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx_r1.cambioObligatorio ? 45 : -1);
  }
}
var AdminLayout = class _AdminLayout {
  authService;
  perfilService;
  router;
  toast;
  cdr;
  etiquetaRol = etiquetaRol;
  anio = (/* @__PURE__ */ new Date()).getFullYear();
  /** "Panel de la Defensora" para el rol DEFENSOR; "Panel de Administración" para la cuenta técnica. */
  get tituloPanel() {
    return this.authService.usuarioActual()?.rol === "DEFENSOR" ? "Panel de la Defensora" : "Panel de Administraci\xF3n";
  }
  menuAbierto = false;
  mostrarModalPassword = false;
  cambioObligatorio = false;
  passwordActual = "";
  passwordNueva = "";
  passwordConfirmar = "";
  mostrarActual = false;
  mostrarNueva = false;
  guardandoPassword = false;
  errorPassword = "";
  constructor(authService, perfilService, router, toast, cdr) {
    this.authService = authService;
    this.perfilService = perfilService;
    this.router = router;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    const usuario = this.authService.usuarioActual();
    if (usuario?.forzarCambioPassword) {
      this.cambioObligatorio = true;
      this.abrirModalPassword();
    }
  }
  get nombreUsuario() {
    return this.authService.usuarioActual()?.nombre ?? "";
  }
  get rolUsuario() {
    const rol = this.authService.usuarioActual()?.rol;
    return rol ? this.etiquetaRol(rol) : "";
  }
  get inicialesUsuario() {
    return iniciales(this.nombreUsuario);
  }
  cerrarMenuAlHacerClickFuera() {
    this.menuAbierto = false;
  }
  alternarMenu(evento) {
    evento.stopPropagation();
    this.menuAbierto = !this.menuAbierto;
  }
  abrirModalPassword() {
    this.menuAbierto = false;
    this.passwordActual = "";
    this.passwordNueva = "";
    this.passwordConfirmar = "";
    this.errorPassword = "";
    this.mostrarModalPassword = true;
  }
  cerrarModalPassword() {
    if (this.cambioObligatorio) {
      this.toast.advertencia("Debes actualizar tu contrase\xF1a temporal antes de continuar.");
      return;
    }
    this.mostrarModalPassword = false;
  }
  get cumpleLongitud() {
    return this.passwordNueva.length >= 8;
  }
  get cumpleMayuscula() {
    return /[A-Z]/.test(this.passwordNueva);
  }
  get cumpleNumero() {
    return /\d/.test(this.passwordNueva);
  }
  get cumpleCoinciden() {
    return this.passwordNueva.length > 0 && this.passwordNueva === this.passwordConfirmar;
  }
  guardarPassword() {
    this.errorPassword = "";
    if (!this.passwordActual) {
      this.errorPassword = "Ingresa tu contrase\xF1a actual.";
      return;
    }
    if (!this.cumpleLongitud || !this.cumpleMayuscula || !this.cumpleNumero) {
      this.errorPassword = "La nueva contrase\xF1a no cumple los requisitos.";
      return;
    }
    if (!this.cumpleCoinciden) {
      this.errorPassword = "La confirmaci\xF3n no coincide con la nueva contrase\xF1a.";
      return;
    }
    const datos = {
      passwordActual: this.passwordActual,
      passwordNueva: this.passwordNueva
    };
    this.guardandoPassword = true;
    this.perfilService.cambiarPassword(datos).subscribe({
      next: () => {
        this.guardandoPassword = false;
        this.cambioObligatorio = false;
        this.mostrarModalPassword = false;
        this.authService.marcarPasswordActualizada();
        this.toast.exito("Contrase\xF1a actualizada correctamente.");
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.guardandoPassword = false;
        this.errorPassword = err?.error?.mensaje ?? "No se pudo actualizar la contrase\xF1a.";
        this.cdr.detectChanges();
      }
    });
  }
  cerrarSesion() {
    this.authService.logout();
    irALoginPersonal();
  }
  static \u0275fac = function AdminLayout_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _AdminLayout)(\u0275\u0275directiveInject(AuthAdminService), \u0275\u0275directiveInject(PerfilService), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AdminLayout, selectors: [["app-admin-layout"]], hostBindings: function AdminLayout_HostBindings(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275listener("click", function AdminLayout_click_HostBindingHandler() {
        return ctx.cerrarMenuAlHacerClickFuera();
      }, \u0275\u0275resolveDocument);
    }
  }, decls: 90, vars: 10, consts: [[1, "app-shell"], [1, "header"], [1, "brand"], [1, "logo-mark"], [1, "user-area"], [1, "dropdown"], [1, "perfil-boton", 3, "click"], [1, "avatar"], [1, "perfil-texto"], [1, "perfil-nombre"], [1, "perfil-rol"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["points", "6 9 12 15 18 9"], [1, "dropdown-menu"], [1, "logout-btn", 3, "click"], [1, "app-body"], [1, "sidebar"], [1, "nav-seccion"], ["routerLink", "/", "routerLinkActive", "active", 3, "routerLinkActiveOptions"], ["x", "3", "y", "3", "width", "7", "height", "9", "rx", "1"], ["x", "14", "y", "3", "width", "7", "height", "5", "rx", "1"], ["x", "14", "y", "12", "width", "7", "height", "9", "rx", "1"], ["x", "3", "y", "16", "width", "7", "height", "5", "rx", "1"], ["routerLink", "/quejas", "routerLinkActive", "active"], ["d", "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"], ["points", "14 2 14 8 20 8"], ["d", "M8 13h8M8 17h5"], ["routerLink", "/unidades", "routerLinkActive", "active"], ["d", "M3 21h18"], ["d", "M5 21V7l7-4 7 4v14"], ["d", "M10 21v-5h4v5"], ["routerLink", "/usuarios-roles", "routerLinkActive", "active"], ["d", "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"], ["cx", "9", "cy", "7", "r", "4"], ["d", "M23 21v-2a4 4 0 0 0-3-3.87"], ["d", "M16 3.13a4 4 0 0 1 0 7.75"], ["routerLink", "/catalogo-dependencias", "routerLinkActive", "active"], ["d", "M9 9h1"], ["d", "M9 13h1"], ["d", "M14 9h1"], ["d", "M14 13h1"], ["routerLink", "/plantillas", "routerLinkActive", "active"], ["x1", "8", "y1", "13", "x2", "16", "y2", "13"], ["x1", "8", "y1", "17", "x2", "16", "y2", "17"], ["routerLink", "/chatbot", "routerLinkActive", "active"], ["d", "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"], ["d", "M8 9h8"], ["d", "M8 13h5"], ["routerLink", "/seguridad-respaldos", "routerLinkActive", "active"], ["d", "M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6z"], [1, "app-content"], [1, "footer"], [1, "modal-overlay"], [1, "dropdown-menu", 3, "click"], [3, "click"], ["cx", "7.5", "cy", "15.5", "r", "5.5"], ["d", "M21 2l-9.6 9.6"], ["d", "M15.5 7.5L18 5"], ["d", "M17 3l4 4"], [1, "modal", "card", 3, "click"], [1, "modal-header"], ["aria-label", "Cerrar", 1, "modal-cerrar"], [1, "aviso-inline"], [1, "input-group"], [1, "campo-password"], ["name", "passwordActual", 3, "ngModelChange", "type", "ngModel"], ["type", "button", 1, "alternar-password", 3, "click"], ["name", "passwordNueva", 3, "ngModelChange", "type", "ngModel"], [1, "requisitos-password"], [1, "marca"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "3", "stroke-linecap", "round", "stroke-linejoin", "round"], ["points", "20 6 9 17 4 12"], ["type", "password", "name", "passwordConfirmar", 3, "ngModelChange", "ngModel"], [1, "mensaje-campo"], [1, "modal-acciones"], [1, "btn-primary", 3, "click", "disabled"], [1, "btn-secondary"], ["aria-label", "Cerrar", 1, "modal-cerrar", 3, "click"], [1, "btn-secondary", 3, "click"]], template: function AdminLayout_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "header", 1)(2, "div", 2)(3, "div", 3);
      \u0275\u0275text(4, "IPN");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(5, "div")(6, "h1");
      \u0275\u0275text(7, "Defensor\xEDa de los Derechos Polit\xE9cnicos");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(8, "p");
      \u0275\u0275text(9);
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(10, "div", 4);
      \u0275\u0275element(11, "app-campana-notificaciones");
      \u0275\u0275elementStart(12, "div", 5)(13, "button", 6);
      \u0275\u0275listener("click", function AdminLayout_Template_button_click_13_listener($event) {
        return ctx.alternarMenu($event);
      });
      \u0275\u0275elementStart(14, "span", 7);
      \u0275\u0275text(15);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(16, "span", 8)(17, "span", 9);
      \u0275\u0275text(18);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(19, "span", 10);
      \u0275\u0275text(20);
      \u0275\u0275elementEnd()();
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(21, "svg", 11);
      \u0275\u0275element(22, "polyline", 12);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(23, AdminLayout_Conditional_23_Template, 8, 0, "div", 13);
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(24, "button", 14);
      \u0275\u0275listener("click", function AdminLayout_Template_button_click_24_listener() {
        return ctx.cerrarSesion();
      });
      \u0275\u0275text(25, "Cerrar sesi\xF3n");
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(26, "div", 15)(27, "aside", 16)(28, "nav")(29, "span", 17);
      \u0275\u0275text(30, "Seguimiento");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(31, "a", 18);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(32, "svg", 11);
      \u0275\u0275element(33, "rect", 19)(34, "rect", 20)(35, "rect", 21)(36, "rect", 22);
      \u0275\u0275elementEnd();
      \u0275\u0275text(37, " Panel general ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(38, "a", 23);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(39, "svg", 11);
      \u0275\u0275element(40, "path", 24)(41, "polyline", 25)(42, "path", 26);
      \u0275\u0275elementEnd();
      \u0275\u0275text(43, " Quejas ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(44, "a", 27);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(45, "svg", 11);
      \u0275\u0275element(46, "path", 28)(47, "path", 29)(48, "path", 30);
      \u0275\u0275elementEnd();
      \u0275\u0275text(49, " Quejas por unidad ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(50, "span", 17);
      \u0275\u0275text(51, "Administraci\xF3n");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(52, "a", 31);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(53, "svg", 11);
      \u0275\u0275element(54, "path", 32)(55, "circle", 33)(56, "path", 34)(57, "path", 35);
      \u0275\u0275elementEnd();
      \u0275\u0275text(58, " Personal de la Defensor\xEDa ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(59, "a", 36);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(60, "svg", 11);
      \u0275\u0275element(61, "path", 28)(62, "path", 29)(63, "path", 37)(64, "path", 38)(65, "path", 39)(66, "path", 40);
      \u0275\u0275elementEnd();
      \u0275\u0275text(67, " Dependencias y Unidades ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(68, "a", 41);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(69, "svg", 11);
      \u0275\u0275element(70, "path", 24)(71, "polyline", 25)(72, "line", 42)(73, "line", 43);
      \u0275\u0275elementEnd();
      \u0275\u0275text(74, " Plantillas Oficiales ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(75, "a", 44);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(76, "svg", 11);
      \u0275\u0275element(77, "path", 45)(78, "path", 46)(79, "path", 47);
      \u0275\u0275elementEnd();
      \u0275\u0275text(80, " Preguntas Frecuentes ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(81, "a", 48);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(82, "svg", 11);
      \u0275\u0275element(83, "path", 49);
      \u0275\u0275elementEnd();
      \u0275\u0275text(84, " Seguridad y Respaldos ");
      \u0275\u0275elementEnd()()();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(85, "main", 50);
      \u0275\u0275element(86, "router-outlet");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(87, "footer", 51);
      \u0275\u0275text(88);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(89, AdminLayout_Conditional_89_Template, 46, 20, "div", 52);
    }
    if (rf & 2) {
      \u0275\u0275advance(9);
      \u0275\u0275textInterpolate(ctx.tituloPanel);
      \u0275\u0275advance(4);
      \u0275\u0275attribute("aria-expanded", ctx.menuAbierto);
      \u0275\u0275advance(2);
      \u0275\u0275textInterpolate(ctx.inicialesUsuario);
      \u0275\u0275advance(3);
      \u0275\u0275textInterpolate(ctx.nombreUsuario);
      \u0275\u0275advance(2);
      \u0275\u0275textInterpolate(ctx.rolUsuario);
      \u0275\u0275advance(3);
      \u0275\u0275conditional(ctx.menuAbierto ? 23 : -1);
      \u0275\u0275advance(8);
      \u0275\u0275property("routerLinkActiveOptions", \u0275\u0275pureFunction0(9, _c0));
      \u0275\u0275advance(57);
      \u0275\u0275textInterpolate1("\xA9 ", ctx.anio, " - Defensor\xEDa de los Derechos Polit\xE9cnicos");
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.mostrarModalPassword ? 89 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, DefaultValueAccessor, NgControlStatus, NgModel, RouterLink, RouterLinkActive, RouterOutlet, CampanaNotificaciones], styles: ['@charset "UTF-8";\n\n\n[_nghost-%COMP%] {\n  display: block;\n  min-height: 100vh;\n}\n.app-shell[_ngcontent-%COMP%] {\n  min-height: 100vh;\n  display: flex;\n  flex-direction: column;\n  background: #f4f5f7;\n}\n.header[_ngcontent-%COMP%] {\n  position: fixed;\n  inset: 0 0 auto 0;\n  z-index: 1000;\n  height: 72px;\n  background: #fff;\n  border-bottom: 1px solid var(--borde);\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n  padding: 0 28px;\n}\n.brand[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 14px;\n  min-width: 0;\n}\n.brand[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 18px;\n  color: var(--guinda);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.brand[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 2px 0 0;\n  font-size: 13px;\n  color: var(--texto-suave);\n}\n.logo-mark[_ngcontent-%COMP%] {\n  width: 44px;\n  height: 44px;\n  flex-shrink: 0;\n  border-radius: 10px;\n  background: var(--guinda);\n  color: #fff;\n  display: grid;\n  place-items: center;\n  font-weight: 700;\n}\n.user-area[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.logout-btn[_ngcontent-%COMP%] {\n  border: none;\n  background: var(--guinda);\n  color: #fff;\n  padding: 9px 16px;\n  border-radius: 6px;\n  font-weight: 600;\n  white-space: nowrap;\n}\n.logout-btn[_ngcontent-%COMP%]:hover {\n  background: var(--guinda-oscuro);\n}\n.perfil-boton[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: none;\n  border: none;\n  padding: 5px 8px;\n  border-radius: 8px;\n}\n.perfil-boton[_ngcontent-%COMP%]:hover {\n  background: var(--gris-fondo);\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-texto[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  line-height: 1.2;\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-nombre[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: var(--texto);\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-rol[_ngcontent-%COMP%] {\n  font-size: 12px;\n  color: var(--guinda-vivo);\n  font-weight: 600;\n}\n.perfil-boton[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.app-body[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  margin-top: 72px;\n}\n.sidebar[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 72px;\n  left: 0;\n  bottom: 40px;\n  width: 250px;\n  overflow-y: auto;\n  background: #fff;\n  border-right: 1px solid var(--borde);\n  padding: 22px 14px;\n  z-index: 900;\n}\n.sidebar[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.sidebar[_ngcontent-%COMP%]   .nav-seccion[_ngcontent-%COMP%] {\n  margin: 14px 14px 4px;\n  color: #9a9fa8;\n  font-size: 11px;\n  font-weight: 700;\n  letter-spacing: 0.06em;\n  text-transform: uppercase;\n}\n.sidebar[_ngcontent-%COMP%]   .nav-seccion[_ngcontent-%COMP%]:first-child {\n  margin-top: 0;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 12px 14px;\n  border-radius: 8px;\n  color: var(--texto);\n  text-decoration: none;\n  font-weight: 500;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  flex-shrink: 0;\n  opacity: 0.7;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover, \n.sidebar[_ngcontent-%COMP%]   a.active[_ngcontent-%COMP%] {\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover   svg[_ngcontent-%COMP%], \n.sidebar[_ngcontent-%COMP%]   a.active[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  opacity: 1;\n}\n.app-content[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 0;\n  margin-left: 250px;\n  padding: 32px 32px 72px 40px;\n  min-height: calc(100vh - 72px);\n}\n.footer[_ngcontent-%COMP%] {\n  position: fixed;\n  inset: auto 0 0 0;\n  z-index: 1000;\n  height: 40px;\n  background: #3b0a22;\n  color: #fff;\n  display: grid;\n  place-items: center;\n  font-size: 12px;\n}\n@media (max-width: 900px) {\n  .brand[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n    font-size: 15px;\n  }\n  .perfil-texto[_ngcontent-%COMP%] {\n    display: none !important;\n  }\n  .app-body[_ngcontent-%COMP%] {\n    flex-direction: column;\n  }\n  .sidebar[_ngcontent-%COMP%] {\n    position: static;\n    width: auto;\n    padding: 10px 12px;\n    border-right: none;\n    border-bottom: 1px solid var(--borde);\n  }\n  .sidebar[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%] {\n    flex-direction: row;\n    overflow-x: auto;\n  }\n  .sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n    white-space: nowrap;\n  }\n  .sidebar[_ngcontent-%COMP%]   .nav-seccion[_ngcontent-%COMP%] {\n    display: none;\n  }\n  .app-content[_ngcontent-%COMP%] {\n    margin-left: 0;\n    padding: 20px 16px 64px;\n  }\n}\n@media (max-width: 600px) {\n  .header[_ngcontent-%COMP%] {\n    padding: 0 12px;\n  }\n  .brand[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:last-child {\n    display: none;\n  }\n}\n/*# sourceMappingURL=admin-layout.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AdminLayout, [{
    type: Component,
    args: [{ selector: "app-admin-layout", standalone: true, imports: [CommonModule, FormsModule, RouterLink, RouterLinkActive, RouterOutlet, CampanaNotificaciones], template: `<!-- Mismo armaz\xF3n que Recepci\xF3n y Primer Contacto (2026-10-16): encabezado blanco con marca IPN,
     men\xFA lateral claro y pie guinda. -->
<div class="app-shell">
  <header class="header">
    <div class="brand">
      <div class="logo-mark">IPN</div>
      <div>
        <h1>Defensor\xEDa de los Derechos Polit\xE9cnicos</h1>
        <p>{{ tituloPanel }}</p>
      </div>
    </div>

    <div class="user-area">
      <app-campana-notificaciones></app-campana-notificaciones>

      <div class="dropdown">
        <button class="perfil-boton" (click)="alternarMenu($event)" [attr.aria-expanded]="menuAbierto">
          <span class="avatar">{{ inicialesUsuario }}</span>
          <span class="perfil-texto">
            <span class="perfil-nombre">{{ nombreUsuario }}</span>
            <span class="perfil-rol">{{ rolUsuario }}</span>
          </span>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
        </button>

        @if (menuAbierto) {
          <div class="dropdown-menu" (click)="$event.stopPropagation()">
            <button (click)="abrirModalPassword()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="5.5"></circle><path d="M21 2l-9.6 9.6"></path><path d="M15.5 7.5L18 5"></path><path d="M17 3l4 4"></path></svg>
              Cambiar contrase\xF1a
            </button>
          </div>
        }
      </div>

      <button class="logout-btn" (click)="cerrarSesion()">Cerrar sesi\xF3n</button>
    </div>
  </header>

  <div class="app-body">
    <aside class="sidebar">
      <nav>
        <span class="nav-seccion">Seguimiento</span>
        <a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{ exact: true }">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9" rx="1"></rect><rect x="14" y="3" width="7" height="5" rx="1"></rect><rect x="14" y="12" width="7" height="9" rx="1"></rect><rect x="3" y="16" width="7" height="5" rx="1"></rect></svg>
          Panel general
        </a>
        <a routerLink="/quejas" routerLinkActive="active">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><path d="M8 13h8M8 17h5"></path></svg>
          Quejas
        </a>
        <a routerLink="/unidades" routerLinkActive="active">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"></path><path d="M5 21V7l7-4 7 4v14"></path><path d="M10 21v-5h4v5"></path></svg>
          Quejas por unidad
        </a>

        <span class="nav-seccion">Administraci\xF3n</span>
        <a routerLink="/usuarios-roles" routerLinkActive="active">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
          Personal de la Defensor\xEDa
        </a>
        <a routerLink="/catalogo-dependencias" routerLinkActive="active">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"></path><path d="M5 21V7l7-4 7 4v14"></path><path d="M9 9h1"></path><path d="M9 13h1"></path><path d="M14 9h1"></path><path d="M14 13h1"></path></svg>
          Dependencias y Unidades
        </a>
        <a routerLink="/plantillas" routerLinkActive="active">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="8" y1="13" x2="16" y2="13"></line><line x1="8" y1="17" x2="16" y2="17"></line></svg>
          Plantillas Oficiales
        </a>
        <a routerLink="/chatbot" routerLinkActive="active">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path><path d="M8 9h8"></path><path d="M8 13h5"></path></svg>
          Preguntas Frecuentes
        </a>
        <a routerLink="/seguridad-respaldos" routerLinkActive="active">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6z"></path></svg>
          Seguridad y Respaldos
        </a>
      </nav>
    </aside>

    <main class="app-content">
      <router-outlet />
    </main>
  </div>

  <footer class="footer">\xA9 {{ anio }} - Defensor\xEDa de los Derechos Polit\xE9cnicos</footer>
</div>

@if (mostrarModalPassword) {
  <div class="modal-overlay">
    <div class="modal card" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>{{ cambioObligatorio ? 'Actualiza tu contrase\xF1a temporal' : 'Cambiar mi contrase\xF1a' }}</h3>
        @if (!cambioObligatorio) {
          <button class="modal-cerrar" (click)="cerrarModalPassword()" aria-label="Cerrar">\u2715</button>
        }
      </div>

      @if (cambioObligatorio) {
        <p class="aviso-inline">
          Tu cuenta tiene una contrase\xF1a temporal. Debes establecer una nueva antes de continuar
          usando la consola.
        </p>
      }

      <div class="input-group">
        <label>Contrase\xF1a actual</label>
        <div class="campo-password">
          <input
            [type]="mostrarActual ? 'text' : 'password'"
            [(ngModel)]="passwordActual"
            name="passwordActual"
          />
          <button
            type="button"
            class="alternar-password"
            (click)="mostrarActual = !mostrarActual"
          >{{ mostrarActual ? '\u{1F648}' : '\u{1F441}\uFE0F' }}</button>
        </div>
      </div>

      <div class="input-group">
        <label>Contrase\xF1a nueva</label>
        <div class="campo-password">
          <input
            [type]="mostrarNueva ? 'text' : 'password'"
            [(ngModel)]="passwordNueva"
            name="passwordNueva"
          />
          <button
            type="button"
            class="alternar-password"
            (click)="mostrarNueva = !mostrarNueva"
          >{{ mostrarNueva ? '\u{1F648}' : '\u{1F441}\uFE0F' }}</button>
        </div>
      </div>

      <ul class="requisitos-password">
        <li [class.cumplido]="cumpleLongitud">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Al menos 8 caracteres
        </li>
        <li [class.cumplido]="cumpleMayuscula">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Una letra may\xFAscula
        </li>
        <li [class.cumplido]="cumpleNumero">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Un n\xFAmero
        </li>
      </ul>

      <div class="input-group">
        <label>Confirmar contrase\xF1a nueva</label>
        <input type="password" [(ngModel)]="passwordConfirmar" name="passwordConfirmar" />
      </div>

      @if (errorPassword) {
        <p class="mensaje-campo">{{ errorPassword }}</p>
      }

      <div class="modal-acciones">
        <button class="btn-primary" (click)="guardarPassword()" [disabled]="guardandoPassword">
          {{ guardandoPassword ? 'Guardando\u2026' : 'Actualizar Contrase\xF1a' }}
        </button>
        @if (!cambioObligatorio) {
          <button class="btn-secondary" (click)="cerrarModalPassword()">Cancelar</button>
        }
      </div>
    </div>
  </div>
}
`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/admin-layout/admin-layout.scss */\n:host {\n  display: block;\n  min-height: 100vh;\n}\n.app-shell {\n  min-height: 100vh;\n  display: flex;\n  flex-direction: column;\n  background: #f4f5f7;\n}\n.header {\n  position: fixed;\n  inset: 0 0 auto 0;\n  z-index: 1000;\n  height: 72px;\n  background: #fff;\n  border-bottom: 1px solid var(--borde);\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n  padding: 0 28px;\n}\n.brand {\n  display: flex;\n  align-items: center;\n  gap: 14px;\n  min-width: 0;\n}\n.brand h1 {\n  margin: 0;\n  font-size: 18px;\n  color: var(--guinda);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.brand p {\n  margin: 2px 0 0;\n  font-size: 13px;\n  color: var(--texto-suave);\n}\n.logo-mark {\n  width: 44px;\n  height: 44px;\n  flex-shrink: 0;\n  border-radius: 10px;\n  background: var(--guinda);\n  color: #fff;\n  display: grid;\n  place-items: center;\n  font-weight: 700;\n}\n.user-area {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.logout-btn {\n  border: none;\n  background: var(--guinda);\n  color: #fff;\n  padding: 9px 16px;\n  border-radius: 6px;\n  font-weight: 600;\n  white-space: nowrap;\n}\n.logout-btn:hover {\n  background: var(--guinda-oscuro);\n}\n.perfil-boton {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: none;\n  border: none;\n  padding: 5px 8px;\n  border-radius: 8px;\n}\n.perfil-boton:hover {\n  background: var(--gris-fondo);\n}\n.perfil-boton .perfil-texto {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  line-height: 1.2;\n}\n.perfil-boton .perfil-nombre {\n  font-size: 14px;\n  color: var(--texto);\n}\n.perfil-boton .perfil-rol {\n  font-size: 12px;\n  color: var(--guinda-vivo);\n  font-weight: 600;\n}\n.perfil-boton svg {\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.app-body {\n  flex: 1;\n  display: flex;\n  margin-top: 72px;\n}\n.sidebar {\n  position: fixed;\n  top: 72px;\n  left: 0;\n  bottom: 40px;\n  width: 250px;\n  overflow-y: auto;\n  background: #fff;\n  border-right: 1px solid var(--borde);\n  padding: 22px 14px;\n  z-index: 900;\n}\n.sidebar nav {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.sidebar .nav-seccion {\n  margin: 14px 14px 4px;\n  color: #9a9fa8;\n  font-size: 11px;\n  font-weight: 700;\n  letter-spacing: 0.06em;\n  text-transform: uppercase;\n}\n.sidebar .nav-seccion:first-child {\n  margin-top: 0;\n}\n.sidebar a {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 12px 14px;\n  border-radius: 8px;\n  color: var(--texto);\n  text-decoration: none;\n  font-weight: 500;\n}\n.sidebar a svg {\n  width: 18px;\n  height: 18px;\n  flex-shrink: 0;\n  opacity: 0.7;\n}\n.sidebar a:hover,\n.sidebar a.active {\n  background: var(--guinda-suave);\n  color: var(--guinda);\n}\n.sidebar a:hover svg,\n.sidebar a.active svg {\n  opacity: 1;\n}\n.app-content {\n  flex: 1;\n  min-width: 0;\n  margin-left: 250px;\n  padding: 32px 32px 72px 40px;\n  min-height: calc(100vh - 72px);\n}\n.footer {\n  position: fixed;\n  inset: auto 0 0 0;\n  z-index: 1000;\n  height: 40px;\n  background: #3b0a22;\n  color: #fff;\n  display: grid;\n  place-items: center;\n  font-size: 12px;\n}\n@media (max-width: 900px) {\n  .brand h1 {\n    font-size: 15px;\n  }\n  .perfil-texto {\n    display: none !important;\n  }\n  .app-body {\n    flex-direction: column;\n  }\n  .sidebar {\n    position: static;\n    width: auto;\n    padding: 10px 12px;\n    border-right: none;\n    border-bottom: 1px solid var(--borde);\n  }\n  .sidebar nav {\n    flex-direction: row;\n    overflow-x: auto;\n  }\n  .sidebar a {\n    white-space: nowrap;\n  }\n  .sidebar .nav-seccion {\n    display: none;\n  }\n  .app-content {\n    margin-left: 0;\n    padding: 20px 16px 64px;\n  }\n}\n@media (max-width: 600px) {\n  .header {\n    padding: 0 12px;\n  }\n  .brand > div:last-child {\n    display: none;\n  }\n}\n/*# sourceMappingURL=admin-layout.css.map */\n'] }]
  }], () => [{ type: AuthAdminService }, { type: PerfilService }, { type: Router }, { type: ToastService }, { type: ChangeDetectorRef }], { cerrarMenuAlHacerClickFuera: [{
    type: HostListener,
    args: ["document:click"]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AdminLayout, { className: "AdminLayout", filePath: "src/app/pages/admin-layout/admin-layout.ts", lineNumber: 20 });
})();
export {
  AdminLayout
};
//# sourceMappingURL=chunk-OOZPKW2U.js.map
