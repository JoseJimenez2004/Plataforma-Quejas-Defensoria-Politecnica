import {
  SeguimientoService
} from "./chunk-75OY42UO.js";
import {
  Router,
  RouterLink
} from "./chunk-MQC2YFSD.js";
import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel
} from "./chunk-A2QHADRU.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DatePipe,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstyleProp,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-JXAMNPEM.js";

// src/app/pages/unidades/unidades.ts
var _forTrack0 = ($index, $item) => $item.clave;
function Unidades_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 12);
    \u0275\u0275text(1, "Cargando\u2026");
    \u0275\u0275elementEnd();
  }
}
function Unidades_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 12);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("No hay quejas registradas", ctx_r0.texto ? ' para "' + ctx_r0.texto + '"' : "", ".");
  }
}
function Unidades_Conditional_20_For_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "tr", 17);
    \u0275\u0275listener("click", function Unidades_Conditional_20_For_16_Template_tr_click_0_listener() {
      const u_r3 = \u0275\u0275restoreView(_r2).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.abrir(u_r3));
    });
    \u0275\u0275elementStart(1, "td")(2, "span", 18);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 19);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "td", 20)(7, "span", 21);
    \u0275\u0275element(8, "span");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "b");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "td", 15);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "td", 15);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "td", 15);
    \u0275\u0275text(16);
    \u0275\u0275pipe(17, "date");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const u_r3 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(u_r3.abreviatura || u_r3.clave);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", u_r3.nombre || "Clave sin registrar en el cat\xE1logo", "", u_r3.tipo ? " \xB7 " + u_r3.tipo : "");
    \u0275\u0275advance(3);
    \u0275\u0275styleProp("width", ctx_r0.pct(u_r3.total), "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(u_r3.total);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(u_r3.enTramite);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(u_r3.cerradas);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(17, 9, u_r3.ultimaQueja, "dd/MM/yy"));
  }
}
function Unidades_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 13)(1, "table", 14)(2, "thead")(3, "tr")(4, "th");
    \u0275\u0275text(5, "Dependencia / unidad acad\xE9mica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "th");
    \u0275\u0275text(7, "Quejas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "th", 15);
    \u0275\u0275text(9, "En tr\xE1mite");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "th", 15);
    \u0275\u0275text(11, "Cerradas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "th", 15);
    \u0275\u0275text(13, "\xDAltima");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(14, "tbody");
    \u0275\u0275repeaterCreate(15, Unidades_Conditional_20_For_16_Template, 18, 12, "tr", 16, _forTrack0);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(15);
    \u0275\u0275repeater(ctx_r0.unidades);
  }
}
var Unidades = class _Unidades {
  seguimiento;
  router;
  toast;
  cdr;
  unidades = [];
  texto = "";
  cargando = true;
  busquedaId = null;
  constructor(seguimiento, router, toast, cdr) {
    this.seguimiento = seguimiento;
    this.router = router;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.cargar();
  }
  ngOnDestroy() {
    if (this.busquedaId !== null) {
      clearTimeout(this.busquedaId);
    }
  }
  buscar() {
    if (this.busquedaId !== null) {
      clearTimeout(this.busquedaId);
    }
    this.busquedaId = setTimeout(() => this.cargar(), 300);
  }
  get maximo() {
    return Math.max(1, ...this.unidades.map((u) => u.total));
  }
  get totalQuejas() {
    return this.unidades.reduce((s, u) => s + u.total, 0);
  }
  pct(n) {
    return Math.max(n > 0 ? 2 : 0, Math.round(n / this.maximo * 100));
  }
  abrir(u) {
    this.router.navigate(["/quejas"], { queryParams: { unidad: u.clave } });
  }
  cargar() {
    this.cargando = true;
    this.seguimiento.unidades(this.texto).subscribe({
      next: (u) => {
        this.unidades = u;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.toast.error("No se pudieron cargar las unidades.");
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function Unidades_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Unidades)(\u0275\u0275directiveInject(SeguimientoService), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Unidades, selectors: [["app-unidades"]], decls: 21, vars: 4, consts: [[1, "seg-pagina"], [1, "seg-encabezado"], [1, "seg-sub"], ["routerLink", "/catalogo-dependencias", 1, "seg-btn", "sec"], [1, "seg-panel"], [1, "cabeza"], [1, "buscador"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["cx", "11", "cy", "11", "r", "7"], ["d", "m21 21-4.3-4.3"], ["type", "search", "placeholder", "Nombre o siglas (ej. ESCOM)", "aria-label", "Buscar unidad", 3, "ngModelChange", "ngModel"], [1, "resumen"], [1, "seg-vacio"], [1, "seg-tabla-envoltura"], [1, "seg-tabla"], [1, "num"], [1, "clic"], [1, "clic", 3, "click"], [1, "fuerte"], [1, "suave"], [1, "col-barra"], [1, "seg-barra"]], template: function Unidades_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "section", 0)(1, "div", 1)(2, "div")(3, "h2");
      \u0275\u0275text(4, "Quejas por dependencia o unidad acad\xE9mica");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(5, "p", 2);
      \u0275\u0275text(6, "D\xF3nde ocurrieron los hechos. Haz clic en una para ver sus quejas.");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(7, "a", 3);
      \u0275\u0275text(8, "Cat\xE1logo de dependencias");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(9, "div", 4)(10, "div", 5)(11, "div", 6);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(12, "svg", 7);
      \u0275\u0275element(13, "circle", 8)(14, "path", 9);
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(15, "input", 10);
      \u0275\u0275twoWayListener("ngModelChange", function Unidades_Template_input_ngModelChange_15_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.texto, $event) || (ctx.texto = $event);
        return $event;
      });
      \u0275\u0275listener("ngModelChange", function Unidades_Template_input_ngModelChange_15_listener() {
        return ctx.buscar();
      });
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(16, "span", 11);
      \u0275\u0275text(17);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(18, Unidades_Conditional_18_Template, 2, 0, "p", 12)(19, Unidades_Conditional_19_Template, 2, 1, "p", 12)(20, Unidades_Conditional_20_Template, 17, 0, "div", 13);
      \u0275\u0275elementEnd()();
    }
    if (rf & 2) {
      \u0275\u0275advance(15);
      \u0275\u0275twoWayProperty("ngModel", ctx.texto);
      \u0275\u0275advance(2);
      \u0275\u0275textInterpolate2("", ctx.unidades.length, " con quejas \xB7 ", ctx.totalQuejas, " quejas");
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.cargando && ctx.unidades.length === 0 ? 18 : ctx.unidades.length === 0 ? 19 : 20);
    }
  }, dependencies: [CommonModule, FormsModule, DefaultValueAccessor, NgControlStatus, NgModel, RouterLink, DatePipe], styles: ["\n.cabeza[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  flex-wrap: wrap;\n  gap: 10px;\n  margin-bottom: 8px;\n}\n.buscador[_ngcontent-%COMP%] {\n  position: relative;\n  flex: 0 1 340px;\n}\n.buscador[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 50%;\n  left: 10px;\n  width: 16px;\n  height: 16px;\n  transform: translateY(-50%);\n  color: var(--texto-suave);\n}\n.buscador[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 9px 10px 9px 34px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font: inherit;\n  font-size: 14px;\n}\n.resumen[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.col-barra[_ngcontent-%COMP%] {\n  min-width: 200px;\n}\n.col-barra[_ngcontent-%COMP%]   .seg-barra[_ngcontent-%COMP%] {\n  display: inline-block;\n  width: calc(100% - 40px);\n  vertical-align: middle;\n}\n.col-barra[_ngcontent-%COMP%]   b[_ngcontent-%COMP%] {\n  display: inline-block;\n  width: 32px;\n  text-align: right;\n}\n/*# sourceMappingURL=unidades.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Unidades, [{
    type: Component,
    args: [{ selector: "app-unidades", standalone: true, imports: [CommonModule, FormsModule, RouterLink], template: `<section class="seg-pagina">
  <div class="seg-encabezado">
    <div>
      <h2>Quejas por dependencia o unidad acad\xE9mica</h2>
      <p class="seg-sub">D\xF3nde ocurrieron los hechos. Haz clic en una para ver sus quejas.</p>
    </div>
    <a routerLink="/catalogo-dependencias" class="seg-btn sec">Cat\xE1logo de dependencias</a>
  </div>

  <div class="seg-panel">
    <div class="cabeza">
      <div class="buscador">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><path d="m21 21-4.3-4.3"></path></svg>
        <input type="search" [(ngModel)]="texto" (ngModelChange)="buscar()" placeholder="Nombre o siglas (ej. ESCOM)" aria-label="Buscar unidad" />
      </div>
      <span class="resumen">{{ unidades.length }} con quejas \xB7 {{ totalQuejas }} quejas</span>
    </div>

    @if (cargando && unidades.length === 0) {
      <p class="seg-vacio">Cargando\u2026</p>
    } @else if (unidades.length === 0) {
      <p class="seg-vacio">No hay quejas registradas{{ texto ? ' para "' + texto + '"' : '' }}.</p>
    } @else {
      <div class="seg-tabla-envoltura">
        <table class="seg-tabla">
          <thead>
            <tr><th>Dependencia / unidad acad\xE9mica</th><th>Quejas</th><th class="num">En tr\xE1mite</th><th class="num">Cerradas</th><th class="num">\xDAltima</th></tr>
          </thead>
          <tbody>
            @for (u of unidades; track u.clave) {
              <tr class="clic" (click)="abrir(u)">
                <td>
                  <span class="fuerte">{{ u.abreviatura || u.clave }}</span>
                  <span class="suave">{{ u.nombre || 'Clave sin registrar en el cat\xE1logo' }}{{ u.tipo ? ' \xB7 ' + u.tipo : '' }}</span>
                </td>
                <td class="col-barra">
                  <span class="seg-barra"><span [style.width.%]="pct(u.total)"></span></span>
                  <b>{{ u.total }}</b>
                </td>
                <td class="num">{{ u.enTramite }}</td>
                <td class="num">{{ u.cerradas }}</td>
                <td class="num">{{ u.ultimaQueja | date: 'dd/MM/yy' }}</td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    }
  </div>
</section>
`, styles: ["/* src/app/pages/unidades/unidades.scss */\n.cabeza {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  flex-wrap: wrap;\n  gap: 10px;\n  margin-bottom: 8px;\n}\n.buscador {\n  position: relative;\n  flex: 0 1 340px;\n}\n.buscador svg {\n  position: absolute;\n  top: 50%;\n  left: 10px;\n  width: 16px;\n  height: 16px;\n  transform: translateY(-50%);\n  color: var(--texto-suave);\n}\n.buscador input {\n  width: 100%;\n  padding: 9px 10px 9px 34px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font: inherit;\n  font-size: 14px;\n}\n.resumen {\n  color: var(--texto-suave);\n  font-size: 13px;\n}\n.col-barra {\n  min-width: 200px;\n}\n.col-barra .seg-barra {\n  display: inline-block;\n  width: calc(100% - 40px);\n  vertical-align: middle;\n}\n.col-barra b {\n  display: inline-block;\n  width: 32px;\n  text-align: right;\n}\n/*# sourceMappingURL=unidades.css.map */\n"] }]
  }], () => [{ type: SeguimientoService }, { type: Router }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Unidades, { className: "Unidades", filePath: "src/app/pages/unidades/unidades.ts", lineNumber: 18 });
})();
export {
  Unidades
};
//# sourceMappingURL=chunk-FQQGURFE.js.map
