import {
  SeguimientoService
} from "./chunk-75OY42UO.js";
import {
  ActivatedRoute,
  RouterLink
} from "./chunk-MQC2YFSD.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DatePipe,
  Location,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassMap,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction1,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵrepeaterTrackByIndex,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2
} from "./chunk-JXAMNPEM.js";

// src/app/pages/queja-detalle/queja-detalle.ts
var _c0 = (a0) => ({ unidad: a0 });
var _c1 = (a0) => ({ abogado: a0 });
var _forTrack0 = ($index, $item) => $item.id;
function QuejaDetalle_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 1);
    \u0275\u0275text(1, "Cargando queja\u2026");
    \u0275\u0275elementEnd();
  }
}
function QuejaDetalle_Conditional_2_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div")(1, "dt");
    \u0275\u0275text(2, "Tel\xE9fono");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "dd");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const q_r3 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(q_r3.telefono);
  }
}
function QuejaDetalle_Conditional_2_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div")(1, "dt");
    \u0275\u0275text(2, "Nacimiento");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "dd");
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "date");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const q_r3 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(5, 1, q_r3.fechaNacimiento, "dd/MM/yyyy"));
  }
}
function QuejaDetalle_Conditional_2_Conditional_46_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "a", 9);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const q_r3 = \u0275\u0275nextContext();
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction1(2, _c0, q_r3.unidadClave));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(q_r3.unidadNombre || q_r3.unidadClave);
  }
}
function QuejaDetalle_Conditional_2_Conditional_47_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " \u2014 ");
  }
}
function QuejaDetalle_Conditional_2_Conditional_66_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 1);
    \u0275\u0275text(1, "La queja no tiene archivos.");
    \u0275\u0275elementEnd();
  }
}
function QuejaDetalle_Conditional_2_For_69_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "li")(1, "span", 15);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 16);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 17);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "button", 18);
    \u0275\u0275listener("click", function QuejaDetalle_Conditional_2_For_69_Template_button_click_7_listener() {
      const e_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.verArchivo(e_r5.id));
    });
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const e_r5 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(e_r5.tipo === "IDENTIFICACION" ? "Credencial" : "Evidencia");
    \u0275\u0275advance();
    \u0275\u0275property("title", e_r5.nombre);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(e_r5.nombre);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.peso(e_r5.tamanio));
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r1.abriendo === e_r5.id);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.abriendo === e_r5.id ? "\u2026" : "Ver", " ");
  }
}
function QuejaDetalle_Conditional_2_Conditional_90_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "a", 9);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const q_r3 = \u0275\u0275nextContext();
    \u0275\u0275property("queryParams", \u0275\u0275pureFunction1(2, _c1, q_r3.abogado));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(q_r3.abogado);
  }
}
function QuejaDetalle_Conditional_2_Conditional_91_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Sin asignar ");
  }
}
function QuejaDetalle_Conditional_2_Conditional_92_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div")(1, "dt");
    \u0275\u0275text(2, "Folio Primer Contacto");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "dd");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const q_r3 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(q_r3.folioPrimerContacto);
  }
}
function QuejaDetalle_Conditional_2_Conditional_98_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 10);
    \u0275\u0275text(1, "Comentarios de Recepci\xF3n al turnar");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "p", 19);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const q_r3 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(q_r3.comentariosRecepcion);
  }
}
function QuejaDetalle_Conditional_2_Conditional_99_For_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const m_r6 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(m_r6);
  }
}
function QuejaDetalle_Conditional_2_Conditional_99_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 19);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.observaciones);
  }
}
function QuejaDetalle_Conditional_2_Conditional_99_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 13)(1, "h3");
    \u0275\u0275text(2, "Observaciones al quejoso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "ul");
    \u0275\u0275repeaterCreate(4, QuejaDetalle_Conditional_2_Conditional_99_For_5_Template, 2, 1, "li", null, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(6, QuejaDetalle_Conditional_2_Conditional_99_Conditional_6_Template, 2, 1, "p", 19);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275repeater(ctx_r1.motivos);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.observaciones ? 6 : -1);
  }
}
function QuejaDetalle_Conditional_2_For_105_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 21);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const e_r7 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(e_r7.detalle);
  }
}
function QuejaDetalle_Conditional_2_For_105_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li")(1, "span", 20);
    \u0275\u0275text(2);
    \u0275\u0275pipe(3, "date");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "b");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(6, QuejaDetalle_Conditional_2_For_105_Conditional_6_Template, 2, 1, "span", 21);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const e_r7 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(e_r7.fecha ? \u0275\u0275pipeBind2(3, 3, e_r7.fecha, "dd/MM/yy HH:mm") : "Actual");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(e_r7.titulo);
    \u0275\u0275advance();
    \u0275\u0275conditional(e_r7.detalle ? 6 : -1);
  }
}
function QuejaDetalle_Conditional_2_Conditional_106_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div")(1, "dt");
    \u0275\u0275text(2, "Oficio");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "dd");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const q_r3 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(q_r3.numeroOficio);
  }
}
function QuejaDetalle_Conditional_2_Conditional_106_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div")(1, "dt");
    \u0275\u0275text(2, "Expediente f\xEDsico");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "dd");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const q_r3 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(q_r3.ubicacionFisica);
  }
}
function QuejaDetalle_Conditional_2_Conditional_106_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 7)(1, "h3");
    \u0275\u0275text(2, "Recepci\xF3n en ventanilla");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "dl", 8)(4, "div")(5, "dt");
    \u0275\u0275text(6, "Documento");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "dd");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div")(10, "dt");
    \u0275\u0275text(11, "Recepci\xF3n f\xEDsica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "dd");
    \u0275\u0275text(13);
    \u0275\u0275pipe(14, "date");
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(15, QuejaDetalle_Conditional_2_Conditional_106_Conditional_15_Template, 5, 1, "div");
    \u0275\u0275conditionalCreate(16, QuejaDetalle_Conditional_2_Conditional_106_Conditional_16_Template, 5, 1, "div");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const q_r3 = \u0275\u0275nextContext();
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(q_r3.tipoDocumentoFisico || "\u2014");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(q_r3.fechaRecepcionFisica ? \u0275\u0275pipeBind2(14, 4, q_r3.fechaRecepcionFisica, "dd/MM/yyyy") : "\u2014");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(q_r3.numeroOficio ? 15 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(q_r3.ubicacionFisica ? 16 : -1);
  }
}
function QuejaDetalle_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 2)(1, "div")(2, "h2");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 3)(5, "span");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "span");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275text(9);
    \u0275\u0275pipe(10, "date");
    \u0275\u0275elementStart(11, "em");
    \u0275\u0275text(12, "Solo lectura");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(13, "button", 4);
    \u0275\u0275listener("click", function QuejaDetalle_Conditional_2_Template_button_click_13_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.regresar());
    });
    \u0275\u0275text(14, "\u2190 Regresar");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 5)(16, "div", 6)(17, "div", 7)(18, "h3");
    \u0275\u0275text(19, "Persona quejosa");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "dl", 8)(21, "div")(22, "dt");
    \u0275\u0275text(23, "Nombre");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "dd");
    \u0275\u0275text(25);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(26, "div")(27, "dt");
    \u0275\u0275text(28, "Correo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "dd");
    \u0275\u0275text(30);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(31, QuejaDetalle_Conditional_2_Conditional_31_Template, 5, 1, "div");
    \u0275\u0275elementStart(32, "div")(33, "dt");
    \u0275\u0275text(34);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(35, "dd");
    \u0275\u0275text(36);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(37, QuejaDetalle_Conditional_2_Conditional_37_Template, 6, 4, "div");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(38, "div", 7)(39, "h3");
    \u0275\u0275text(40, "Hechos");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(41, "dl", 8)(42, "div")(43, "dt");
    \u0275\u0275text(44, "Lugar");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(45, "dd");
    \u0275\u0275conditionalCreate(46, QuejaDetalle_Conditional_2_Conditional_46_Template, 2, 4, "a", 9)(47, QuejaDetalle_Conditional_2_Conditional_47_Template, 1, 0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(48, "div")(49, "dt");
    \u0275\u0275text(50, "Fecha de los hechos");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(51, "dd");
    \u0275\u0275text(52);
    \u0275\u0275pipe(53, "date");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(54, "div")(55, "dt");
    \u0275\u0275text(56, "Persona se\xF1alada");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(57, "dd");
    \u0275\u0275text(58);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(59, "p", 10);
    \u0275\u0275text(60, "Descripci\xF3n de los hechos");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(61, "p", 11);
    \u0275\u0275text(62);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(63, "div", 7)(64, "h3");
    \u0275\u0275text(65);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(66, QuejaDetalle_Conditional_2_Conditional_66_Template, 2, 0, "p", 1);
    \u0275\u0275elementStart(67, "ul", 12);
    \u0275\u0275repeaterCreate(68, QuejaDetalle_Conditional_2_For_69_Template, 9, 6, "li", null, _forTrack0);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(70, "div", 6)(71, "div", 7)(72, "h3");
    \u0275\u0275text(73, "Seguimiento");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(74, "dl", 8)(75, "div")(76, "dt");
    \u0275\u0275text(77, "\xC1rea actual");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(78, "dd")(79, "span");
    \u0275\u0275text(80);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(81, "div")(82, "dt");
    \u0275\u0275text(83);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(84, "dd");
    \u0275\u0275text(85);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(86, "div")(87, "dt");
    \u0275\u0275text(88, "Abogado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(89, "dd");
    \u0275\u0275conditionalCreate(90, QuejaDetalle_Conditional_2_Conditional_90_Template, 2, 4, "a", 9)(91, QuejaDetalle_Conditional_2_Conditional_91_Template, 1, 0);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(92, QuejaDetalle_Conditional_2_Conditional_92_Template, 5, 1, "div");
    \u0275\u0275elementStart(93, "div")(94, "dt");
    \u0275\u0275text(95, "Respuestas del denunciado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(96, "dd");
    \u0275\u0275text(97);
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(98, QuejaDetalle_Conditional_2_Conditional_98_Template, 4, 1);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(99, QuejaDetalle_Conditional_2_Conditional_99_Template, 7, 1, "div", 13);
    \u0275\u0275elementStart(100, "div", 7)(101, "h3");
    \u0275\u0275text(102, "L\xEDnea de tiempo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(103, "ol", 14);
    \u0275\u0275repeaterCreate(104, QuejaDetalle_Conditional_2_For_105_Template, 7, 6, "li", null, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(106, QuejaDetalle_Conditional_2_Conditional_106_Template, 17, 7, "div", 7);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const q_r3 = ctx;
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(q_r3.folio);
    \u0275\u0275advance(2);
    \u0275\u0275classMap("seg-chip etapa-" + q_r3.etapa);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(q_r3.etapaEtiqueta);
    \u0275\u0275advance();
    \u0275\u0275classMap("seg-chip etapa-" + q_r3.etapa);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(q_r3.estatusEtiqueta);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2(" \xB7 Recibida ", \u0275\u0275pipeBind2(10, 32, q_r3.fechaCreacion, "dd/MM/yyyy 'a las' HH:mm"), " por ", q_r3.origen === "Ventanilla" ? "ventanilla" : "el portal", " \xB7 ");
    \u0275\u0275advance(16);
    \u0275\u0275textInterpolate(q_r3.quejoso || "\u2014");
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(q_r3.correo || "\u2014");
    \u0275\u0275advance();
    \u0275\u0275conditional(q_r3.telefono ? 31 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(q_r3.tipoIdentificacion === "empleado" ? "N\xFAm. de empleado" : "Boleta");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(q_r3.numeroIdentificacion || "\u2014");
    \u0275\u0275advance();
    \u0275\u0275conditional(q_r3.fechaNacimiento ? 37 : -1);
    \u0275\u0275advance(9);
    \u0275\u0275conditional(q_r3.unidadClave ? 46 : 47);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(q_r3.fechaHechos ? \u0275\u0275pipeBind2(53, 35, q_r3.fechaHechos, "dd/MM/yyyy") : "\u2014");
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(q_r3.denunciado || "No especificada");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(q_r3.descripcion || "Sin descripci\xF3n.");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Archivos (", q_r3.evidencias.length, ")");
    \u0275\u0275advance();
    \u0275\u0275conditional(q_r3.evidencias.length === 0 ? 66 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(q_r3.evidencias);
    \u0275\u0275advance(11);
    \u0275\u0275classMap("seg-chip etapa-" + q_r3.etapa);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(q_r3.etapaEtiqueta);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(q_r3.atendiendoAhora ? "La atiende ahora" : "Recepcionista");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(q_r3.recepcionista || "Nadie la ha tomado");
    \u0275\u0275advance(5);
    \u0275\u0275conditional(q_r3.abogado ? 90 : 91);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(q_r3.folioPrimerContacto ? 92 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(q_r3.respuestasDenunciado);
    \u0275\u0275advance();
    \u0275\u0275conditional(q_r3.comentariosRecepcion ? 98 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(q_r3.motivoRechazo ? 99 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275repeater(q_r3.linea);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(q_r3.origen === "Ventanilla" ? 106 : -1);
  }
}
var QuejaDetalle = class _QuejaDetalle {
  route;
  location;
  seguimiento;
  toast;
  cdr;
  queja = null;
  cargando = true;
  abriendo = null;
  constructor(route, location, seguimiento, toast, cdr) {
    this.route = route;
    this.location = location;
    this.seguimiento = seguimiento;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    const folio = this.route.snapshot.paramMap.get("folio") ?? "";
    this.seguimiento.detalle(folio).subscribe({
      next: (q) => {
        this.queja = q;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.cargando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo cargar la queja.");
        this.cdr.detectChanges();
      }
    });
  }
  regresar() {
    this.location.back();
  }
  /** El archivo exige el token, así que se descarga como blob y se abre en otra pestaña. */
  verArchivo(id) {
    if (!this.queja) {
      return;
    }
    this.abriendo = id;
    this.seguimiento.evidencia(this.queja.folio, id).subscribe({
      next: (blob) => {
        this.abriendo = null;
        window.open(URL.createObjectURL(blob), "_blank");
        this.cdr.detectChanges();
      },
      error: () => {
        this.abriendo = null;
        this.toast.error("No se pudo abrir el archivo.");
        this.cdr.detectChanges();
      }
    });
  }
  peso(bytes) {
    if (!bytes) {
      return "";
    }
    return bytes < 1024 * 1024 ? `${Math.ceil(bytes / 1024)} KB` : `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  }
  /** Motivos (antes de la línea en blanco) y observaciones detalladas del rechazo. */
  get motivos() {
    return (this.queja?.motivoRechazo ?? "").split("\n\n")[0].split(";").map((m) => m.trim()).filter(Boolean);
  }
  get observaciones() {
    const partes = (this.queja?.motivoRechazo ?? "").split("\n\n");
    return partes.slice(1).join("\n\n").trim();
  }
  static \u0275fac = function QuejaDetalle_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _QuejaDetalle)(\u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(Location), \u0275\u0275directiveInject(SeguimientoService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _QuejaDetalle, selectors: [["app-queja-detalle"]], decls: 3, vars: 1, consts: [[1, "seg-pagina"], [1, "seg-vacio"], [1, "seg-encabezado"], [1, "seg-sub"], ["type", "button", 1, "seg-btn", "sec", 3, "click"], [1, "detalle"], [1, "columna"], [1, "seg-panel"], [1, "datos"], ["routerLink", "/quejas", 3, "queryParams"], [1, "etiqueta"], [1, "descripcion"], [1, "archivos"], [1, "seg-panel", "rechazo"], [1, "linea"], [1, "archivo-tipo"], [1, "archivo-nombre", 3, "title"], [1, "archivo-peso"], ["type", "button", 1, "seg-btn", "sec", "chico", 3, "click", "disabled"], [1, "nota"], [1, "linea-fecha"], [1, "linea-detalle"]], template: function QuejaDetalle_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "section", 0);
      \u0275\u0275conditionalCreate(1, QuejaDetalle_Conditional_1_Template, 2, 0, "p", 1)(2, QuejaDetalle_Conditional_2_Template, 107, 38);
      \u0275\u0275elementEnd();
    }
    if (rf & 2) {
      let tmp_0_0;
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.cargando ? 1 : (tmp_0_0 = ctx.queja) ? 2 : -1, tmp_0_0);
    }
  }, dependencies: [CommonModule, RouterLink, DatePipe], styles: ['\n.seg-sub[_ngcontent-%COMP%]   .seg-chip[_ngcontent-%COMP%] {\n  margin-right: 4px;\n}\n.detalle[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(0, 1.5fr) minmax(0, 1fr);\n  gap: 18px;\n  align-items: start;\n}\n@media (max-width: 1100px) {\n  .detalle[_ngcontent-%COMP%] {\n    grid-template-columns: minmax(0, 1fr);\n  }\n}\n.columna[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 18px;\n}\nh3[_ngcontent-%COMP%] {\n  margin: 0 0 12px;\n  color: var(--guinda);\n  font-size: 16px;\n}\n.datos[_ngcontent-%COMP%] {\n  margin: 0;\n  display: grid;\n  gap: 6px;\n}\n.datos[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 150px minmax(0, 1fr);\n  gap: 10px;\n  font-size: 14px;\n}\n.datos[_ngcontent-%COMP%]   dt[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.datos[_ngcontent-%COMP%]   dd[_ngcontent-%COMP%] {\n  margin: 0;\n  overflow-wrap: anywhere;\n}\n.etiqueta[_ngcontent-%COMP%] {\n  margin: 14px 0 4px;\n  color: var(--texto-suave);\n  font-size: 12px;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n}\n.descripcion[_ngcontent-%COMP%], \n.nota[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 12px 14px;\n  border-radius: 8px;\n  background: #f9fafb;\n  font-size: 14px;\n  line-height: 1.6;\n  white-space: pre-wrap;\n}\n.archivos[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 6px;\n}\n.archivos[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: auto minmax(0, 1fr) auto auto;\n  align-items: center;\n  gap: 10px;\n  padding: 8px 10px;\n  border-radius: 8px;\n  background: #f9fafb;\n  font-size: 13.5px;\n}\n.archivo-tipo[_ngcontent-%COMP%] {\n  padding: 2px 8px;\n  border-radius: 999px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-size: 11.5px;\n  font-weight: 700;\n}\n.archivo-nombre[_ngcontent-%COMP%] {\n  overflow: hidden;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n}\n.archivo-peso[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 12px;\n}\n.rechazo[_ngcontent-%COMP%] {\n  border-left: 4px solid #e5a3a3;\n}\n.rechazo[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  margin: 0 0 10px;\n  padding-left: 18px;\n  color: #8a2a2a;\n  font-size: 14px;\n}\n.linea[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0 0 0 16px;\n  border-left: 2px solid #ece7ea;\n  display: grid;\n  gap: 12px;\n}\n.linea[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  font-size: 14px;\n}\n.linea[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]::before {\n  content: "";\n  position: absolute;\n  left: -22px;\n  top: 4px;\n  width: 10px;\n  height: 10px;\n  border-radius: 50%;\n  background: var(--guinda);\n}\n.linea-fecha[_ngcontent-%COMP%], \n.linea-detalle[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 12.5px;\n}\n/*# sourceMappingURL=queja-detalle.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(QuejaDetalle, [{
    type: Component,
    args: [{ selector: "app-queja-detalle", standalone: true, imports: [CommonModule, RouterLink], template: `<section class="seg-pagina">
  @if (cargando) {
    <p class="seg-vacio">Cargando queja\u2026</p>
  } @else if (queja; as q) {
    <div class="seg-encabezado">
      <div>
        <h2>{{ q.folio }}</h2>
        <p class="seg-sub">
          <span [class]="'seg-chip etapa-' + q.etapa">{{ q.etapaEtiqueta }}</span>
          <span [class]="'seg-chip etapa-' + q.etapa">{{ q.estatusEtiqueta }}</span>
          \xB7 Recibida {{ q.fechaCreacion | date: "dd/MM/yyyy 'a las' HH:mm" }} por {{ q.origen === 'Ventanilla' ? 'ventanilla' : 'el portal' }}
          \xB7 <em>Solo lectura</em>
        </p>
      </div>
      <button type="button" class="seg-btn sec" (click)="regresar()">\u2190 Regresar</button>
    </div>

    <div class="detalle">
      <div class="columna">
        <div class="seg-panel">
          <h3>Persona quejosa</h3>
          <dl class="datos">
            <div><dt>Nombre</dt><dd>{{ q.quejoso || '\u2014' }}</dd></div>
            <div><dt>Correo</dt><dd>{{ q.correo || '\u2014' }}</dd></div>
            @if (q.telefono) { <div><dt>Tel\xE9fono</dt><dd>{{ q.telefono }}</dd></div> }
            <div><dt>{{ q.tipoIdentificacion === 'empleado' ? 'N\xFAm. de empleado' : 'Boleta' }}</dt><dd>{{ q.numeroIdentificacion || '\u2014' }}</dd></div>
            @if (q.fechaNacimiento) { <div><dt>Nacimiento</dt><dd>{{ q.fechaNacimiento | date: 'dd/MM/yyyy' }}</dd></div> }
          </dl>
        </div>

        <div class="seg-panel">
          <h3>Hechos</h3>
          <dl class="datos">
            <div>
              <dt>Lugar</dt>
              <dd>
                @if (q.unidadClave) { <a routerLink="/quejas" [queryParams]="{ unidad: q.unidadClave }">{{ q.unidadNombre || q.unidadClave }}</a> }
                @else { \u2014 }
              </dd>
            </div>
            <div><dt>Fecha de los hechos</dt><dd>{{ q.fechaHechos ? (q.fechaHechos | date: 'dd/MM/yyyy') : '\u2014' }}</dd></div>
            <div><dt>Persona se\xF1alada</dt><dd>{{ q.denunciado || 'No especificada' }}</dd></div>
          </dl>
          <p class="etiqueta">Descripci\xF3n de los hechos</p>
          <p class="descripcion">{{ q.descripcion || 'Sin descripci\xF3n.' }}</p>
        </div>

        <div class="seg-panel">
          <h3>Archivos ({{ q.evidencias.length }})</h3>
          @if (q.evidencias.length === 0) {
            <p class="seg-vacio">La queja no tiene archivos.</p>
          }
          <ul class="archivos">
            @for (e of q.evidencias; track e.id) {
              <li>
                <span class="archivo-tipo">{{ e.tipo === 'IDENTIFICACION' ? 'Credencial' : 'Evidencia' }}</span>
                <span class="archivo-nombre" [title]="e.nombre">{{ e.nombre }}</span>
                <span class="archivo-peso">{{ peso(e.tamanio) }}</span>
                <button type="button" class="seg-btn sec chico" (click)="verArchivo(e.id)" [disabled]="abriendo === e.id">
                  {{ abriendo === e.id ? '\u2026' : 'Ver' }}
                </button>
              </li>
            }
          </ul>
        </div>
      </div>

      <div class="columna">
        <div class="seg-panel">
          <h3>Seguimiento</h3>
          <dl class="datos">
            <div><dt>\xC1rea actual</dt><dd><span [class]="'seg-chip etapa-' + q.etapa">{{ q.etapaEtiqueta }}</span></dd></div>
            <div>
              <dt>{{ q.atendiendoAhora ? 'La atiende ahora' : 'Recepcionista' }}</dt>
              <dd>{{ q.recepcionista || 'Nadie la ha tomado' }}</dd>
            </div>
            <div>
              <dt>Abogado</dt>
              <dd>
                @if (q.abogado) { <a routerLink="/quejas" [queryParams]="{ abogado: q.abogado }">{{ q.abogado }}</a> }
                @else { Sin asignar }
              </dd>
            </div>
            @if (q.folioPrimerContacto) { <div><dt>Folio Primer Contacto</dt><dd>{{ q.folioPrimerContacto }}</dd></div> }
            <div><dt>Respuestas del denunciado</dt><dd>{{ q.respuestasDenunciado }}</dd></div>
          </dl>
          @if (q.comentariosRecepcion) {
            <p class="etiqueta">Comentarios de Recepci\xF3n al turnar</p>
            <p class="nota">{{ q.comentariosRecepcion }}</p>
          }
        </div>

        @if (q.motivoRechazo) {
          <div class="seg-panel rechazo">
            <h3>Observaciones al quejoso</h3>
            <ul>
              @for (m of motivos; track m) { <li>{{ m }}</li> }
            </ul>
            @if (observaciones) { <p class="nota">{{ observaciones }}</p> }
          </div>
        }

        <div class="seg-panel">
          <h3>L\xEDnea de tiempo</h3>
          <ol class="linea">
            @for (e of q.linea; track $index) {
              <li>
                <span class="linea-fecha">{{ e.fecha ? (e.fecha | date: 'dd/MM/yy HH:mm') : 'Actual' }}</span>
                <b>{{ e.titulo }}</b>
                @if (e.detalle) { <span class="linea-detalle">{{ e.detalle }}</span> }
              </li>
            }
          </ol>
        </div>

        @if (q.origen === 'Ventanilla') {
          <div class="seg-panel">
            <h3>Recepci\xF3n en ventanilla</h3>
            <dl class="datos">
              <div><dt>Documento</dt><dd>{{ q.tipoDocumentoFisico || '\u2014' }}</dd></div>
              <div><dt>Recepci\xF3n f\xEDsica</dt><dd>{{ q.fechaRecepcionFisica ? (q.fechaRecepcionFisica | date: 'dd/MM/yyyy') : '\u2014' }}</dd></div>
              @if (q.numeroOficio) { <div><dt>Oficio</dt><dd>{{ q.numeroOficio }}</dd></div> }
              @if (q.ubicacionFisica) { <div><dt>Expediente f\xEDsico</dt><dd>{{ q.ubicacionFisica }}</dd></div> }
            </dl>
          </div>
        }
      </div>
    </div>
  }
</section>
`, styles: ['/* src/app/pages/queja-detalle/queja-detalle.scss */\n.seg-sub .seg-chip {\n  margin-right: 4px;\n}\n.detalle {\n  display: grid;\n  grid-template-columns: minmax(0, 1.5fr) minmax(0, 1fr);\n  gap: 18px;\n  align-items: start;\n}\n@media (max-width: 1100px) {\n  .detalle {\n    grid-template-columns: minmax(0, 1fr);\n  }\n}\n.columna {\n  display: grid;\n  gap: 18px;\n}\nh3 {\n  margin: 0 0 12px;\n  color: var(--guinda);\n  font-size: 16px;\n}\n.datos {\n  margin: 0;\n  display: grid;\n  gap: 6px;\n}\n.datos div {\n  display: grid;\n  grid-template-columns: 150px minmax(0, 1fr);\n  gap: 10px;\n  font-size: 14px;\n}\n.datos dt {\n  color: var(--texto-suave);\n}\n.datos dd {\n  margin: 0;\n  overflow-wrap: anywhere;\n}\n.etiqueta {\n  margin: 14px 0 4px;\n  color: var(--texto-suave);\n  font-size: 12px;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n}\n.descripcion,\n.nota {\n  margin: 0;\n  padding: 12px 14px;\n  border-radius: 8px;\n  background: #f9fafb;\n  font-size: 14px;\n  line-height: 1.6;\n  white-space: pre-wrap;\n}\n.archivos {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 6px;\n}\n.archivos li {\n  display: grid;\n  grid-template-columns: auto minmax(0, 1fr) auto auto;\n  align-items: center;\n  gap: 10px;\n  padding: 8px 10px;\n  border-radius: 8px;\n  background: #f9fafb;\n  font-size: 13.5px;\n}\n.archivo-tipo {\n  padding: 2px 8px;\n  border-radius: 999px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-size: 11.5px;\n  font-weight: 700;\n}\n.archivo-nombre {\n  overflow: hidden;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n}\n.archivo-peso {\n  color: var(--texto-suave);\n  font-size: 12px;\n}\n.rechazo {\n  border-left: 4px solid #e5a3a3;\n}\n.rechazo ul {\n  margin: 0 0 10px;\n  padding-left: 18px;\n  color: #8a2a2a;\n  font-size: 14px;\n}\n.linea {\n  list-style: none;\n  margin: 0;\n  padding: 0 0 0 16px;\n  border-left: 2px solid #ece7ea;\n  display: grid;\n  gap: 12px;\n}\n.linea li {\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  font-size: 14px;\n}\n.linea li::before {\n  content: "";\n  position: absolute;\n  left: -22px;\n  top: 4px;\n  width: 10px;\n  height: 10px;\n  border-radius: 50%;\n  background: var(--guinda);\n}\n.linea-fecha,\n.linea-detalle {\n  color: var(--texto-suave);\n  font-size: 12.5px;\n}\n/*# sourceMappingURL=queja-detalle.css.map */\n'] }]
  }], () => [{ type: ActivatedRoute }, { type: Location }, { type: SeguimientoService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(QuejaDetalle, { className: "QuejaDetalle", filePath: "src/app/pages/queja-detalle/queja-detalle.ts", lineNumber: 17 });
})();
export {
  QuejaDetalle
};
//# sourceMappingURL=chunk-XQWM7SM6.js.map
