import {
  SeguimientoService
} from "./chunk-75OY42UO.js";
import {
  ActivatedRoute,
  Router,
  RouterLink
} from "./chunk-MQC2YFSD.js";
import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel,
  NgSelectOption,
  SelectControlValueAccessor,
  ɵNgSelectMultipleOption
} from "./chunk-A2QHADRU.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DatePipe,
  ToastService,
  __spreadValues,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassMap,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵrepeaterTrackByIndex,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-JXAMNPEM.js";

// src/app/pages/quejas/quejas.ts
var _c0 = () => [];
var _forTrack0 = ($index, $item) => $item.clave;
var _forTrack1 = ($index, $item) => $item.correo;
var _forTrack2 = ($index, $item) => $item.folio;
function Quejas_For_22_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 13);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const e_r1 = ctx.$implicit;
    \u0275\u0275property("value", e_r1.clave);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(e_r1.etiqueta);
  }
}
function Quejas_For_29_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 13);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const u_r2 = ctx.$implicit;
    \u0275\u0275property("value", u_r2.clave);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2("", u_r2.abreviatura || u_r2.nombre || u_r2.clave, " (", u_r2.total, ")");
  }
}
function Quejas_For_38_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 13);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const a_r3 = ctx.$implicit;
    \u0275\u0275property("value", a_r3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(a_r3);
  }
}
function Quejas_For_45_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 13);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const r_r4 = ctx.$implicit;
    \u0275\u0275property("value", r_r4.correo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(r_r4.nombre);
  }
}
function Quejas_Conditional_49_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 20);
    \u0275\u0275listener("click", function Quejas_Conditional_49_Conditional_1_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r6 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r6.aplicar({ estatus: "" }));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r6 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Estatus: ", ctx_r6.etiquetaEstatus, " \xD7");
  }
}
function Quejas_Conditional_49_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 16);
    \u0275\u0275conditionalCreate(1, Quejas_Conditional_49_Conditional_1_Template, 2, 1, "button", 18);
    \u0275\u0275elementStart(2, "button", 19);
    \u0275\u0275listener("click", function Quejas_Conditional_49_Template_button_click_2_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r6 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r6.limpiar());
    });
    \u0275\u0275text(3, "Quitar todos los filtros");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r6 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r6.filtro.estatus ? 1 : -1);
  }
}
function Quejas_Conditional_50_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 17);
    \u0275\u0275text(1, "Cargando quejas\u2026");
    \u0275\u0275elementEnd();
  }
}
function Quejas_Conditional_51_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 17);
    \u0275\u0275text(1, "No hay quejas con estos filtros.");
    \u0275\u0275elementEnd();
  }
}
function Quejas_Conditional_52_For_20_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 27);
    \u0275\u0275text(1, "Ventanilla");
    \u0275\u0275elementEnd();
  }
}
function Quejas_Conditional_52_For_20_Conditional_19_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 30);
  }
}
function Quejas_Conditional_52_For_20_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, Quejas_Conditional_52_For_20_Conditional_19_Conditional_0_Template, 1, 0, "span", 30);
    \u0275\u0275text(1);
  }
  if (rf & 2) {
    const f_r9 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275conditional(f_r9.atendiendoAhora ? 0 : -1);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", f_r9.recepcionista, " ");
  }
}
function Quejas_Conditional_52_For_20_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 27);
    \u0275\u0275text(1, "Nadie la ha tomado");
    \u0275\u0275elementEnd();
  }
}
function Quejas_Conditional_52_For_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "tr", 25);
    \u0275\u0275listener("click", function Quejas_Conditional_52_For_20_Template_tr_click_0_listener() {
      const f_r9 = \u0275\u0275restoreView(_r8).$implicit;
      const ctx_r6 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r6.abrir(f_r9.folio));
    });
    \u0275\u0275elementStart(1, "td")(2, "span", 26);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(4, Quejas_Conditional_52_For_20_Conditional_4_Template, 2, 0, "span", 27);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "td", 28);
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "date");
    \u0275\u0275elementStart(8, "span", 27);
    \u0275\u0275text(9);
    \u0275\u0275pipe(10, "date");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "td");
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "td");
    \u0275\u0275text(14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "td")(16, "span", 29);
    \u0275\u0275text(17);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "td");
    \u0275\u0275conditionalCreate(19, Quejas_Conditional_52_For_20_Conditional_19_Template, 2, 2)(20, Quejas_Conditional_52_For_20_Conditional_20_Template, 2, 0, "span", 27);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "td");
    \u0275\u0275text(22);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const f_r9 = ctx.$implicit;
    \u0275\u0275property("title", "Ver la queja " + f_r9.folio);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(f_r9.folio);
    \u0275\u0275advance();
    \u0275\u0275conditional(f_r9.origen === "Ventanilla" ? 4 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(7, 13, f_r9.fecha, "dd/MM/yy"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(10, 16, f_r9.fecha, "HH:mm"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(f_r9.quejoso);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(f_r9.unidadNombre || f_r9.unidadClave || "\u2014");
    \u0275\u0275advance(2);
    \u0275\u0275classMap("seg-chip etapa-" + f_r9.etapa);
    \u0275\u0275property("title", f_r9.estatusEtiqueta);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(f_r9.estatusEtiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(f_r9.recepcionista ? 19 : 20);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(f_r9.abogado || "\u2014");
  }
}
function Quejas_Conditional_52_Conditional_24_For_4_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "\u2026");
    \u0275\u0275elementEnd();
  }
}
function Quejas_Conditional_52_Conditional_24_For_4_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 34);
    \u0275\u0275listener("click", function Quejas_Conditional_52_Conditional_24_For_4_Conditional_1_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r11);
      const p_r12 = \u0275\u0275nextContext().$implicit;
      const ctx_r6 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r6.irAPagina(p_r12));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r12 = \u0275\u0275nextContext().$implicit;
    const ctx_r6 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("actual", p_r12 === ctx_r6.pagina);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(p_r12 + 1);
  }
}
function Quejas_Conditional_52_Conditional_24_For_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, Quejas_Conditional_52_Conditional_24_For_4_Conditional_0_Template, 2, 0, "span")(1, Quejas_Conditional_52_Conditional_24_For_4_Conditional_1_Template, 2, 3, "button", 33);
  }
  if (rf & 2) {
    const p_r12 = ctx.$implicit;
    \u0275\u0275conditional(p_r12 === null ? 0 : 1);
  }
}
function Quejas_Conditional_52_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "nav")(1, "button", 31);
    \u0275\u0275listener("click", function Quejas_Conditional_52_Conditional_24_Template_button_click_1_listener() {
      \u0275\u0275restoreView(_r10);
      const ctx_r6 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r6.irAPagina(ctx_r6.pagina - 1));
    });
    \u0275\u0275text(2, "\u2039");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(3, Quejas_Conditional_52_Conditional_24_For_4_Template, 2, 1, null, null, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275elementStart(5, "button", 32);
    \u0275\u0275listener("click", function Quejas_Conditional_52_Conditional_24_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r10);
      const ctx_r6 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r6.irAPagina(ctx_r6.pagina + 1));
    });
    \u0275\u0275text(6, "\u203A");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r6 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r6.pagina === 0);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r6.paginasVisibles);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r6.pagina >= ctx_r6.datos.totalPaginas - 1);
  }
}
function Quejas_Conditional_52_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 21)(1, "table", 22)(2, "thead")(3, "tr")(4, "th");
    \u0275\u0275text(5, "Folio");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "th");
    \u0275\u0275text(7, "Lleg\xF3");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "th");
    \u0275\u0275text(9, "Quejoso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "th");
    \u0275\u0275text(11, "Unidad");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "th");
    \u0275\u0275text(13, "D\xF3nde va");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "th");
    \u0275\u0275text(15, "Recepcionista");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "th");
    \u0275\u0275text(17, "Abogado");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(18, "tbody");
    \u0275\u0275repeaterCreate(19, Quejas_Conditional_52_For_20_Template, 23, 19, "tr", 23, _forTrack2);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "div", 24)(22, "span");
    \u0275\u0275text(23);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(24, Quejas_Conditional_52_Conditional_24_Template, 7, 2, "nav");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r6 = \u0275\u0275nextContext();
    \u0275\u0275classProp("recargando", ctx_r6.cargando);
    \u0275\u0275advance(19);
    \u0275\u0275repeater(ctx_r6.datos.filas);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r6.rango);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r6.datos.totalPaginas > 1 ? 24 : -1);
  }
}
var TAMANIO = 15;
var Quejas = class _Quejas {
  seguimiento;
  route;
  router;
  toast;
  cdr;
  filtro = {};
  texto = "";
  pagina = 0;
  datos = null;
  cargando = true;
  opciones = null;
  unidades = [];
  sub;
  busquedaId = null;
  constructor(seguimiento, route, router, toast, cdr) {
    this.seguimiento = seguimiento;
    this.route = route;
    this.router = router;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.seguimiento.filtros().subscribe({ next: (f) => {
      this.opciones = f;
      this.cdr.detectChanges();
    } });
    this.seguimiento.unidades().subscribe({ next: (u) => {
      this.unidades = u;
      this.cdr.detectChanges();
    } });
    this.sub = this.route.queryParamMap.subscribe((p) => {
      this.filtro = {
        etapa: p.get("etapa") ?? "",
        estatus: p.get("estatus") ?? "",
        unidad: p.get("unidad") ?? "",
        abogado: p.get("abogado") ?? "",
        recepcionista: p.get("recepcionista") ?? "",
        mes: p.get("mes") ?? "",
        q: p.get("q") ?? ""
      };
      this.texto = this.filtro.q ?? "";
      this.pagina = Number(p.get("pagina") ?? 0) || 0;
      this.cargar();
    });
  }
  ngOnDestroy() {
    this.sub?.unsubscribe();
    if (this.busquedaId !== null) {
      clearTimeout(this.busquedaId);
    }
  }
  /** Cambia un filtro (o varios) y lo refleja en la URL; vuelve a la página 1. */
  aplicar(cambios) {
    const siguiente = __spreadValues(__spreadValues({}, this.filtro), cambios);
    const query = {};
    for (const [k, v] of Object.entries(siguiente)) {
      query[k] = v ? String(v) : null;
    }
    query["pagina"] = null;
    this.router.navigate([], { relativeTo: this.route, queryParams: query });
  }
  buscar() {
    if (this.busquedaId !== null) {
      clearTimeout(this.busquedaId);
    }
    this.busquedaId = setTimeout(() => this.aplicar({ q: this.texto.trim() }), 350);
  }
  limpiar() {
    this.router.navigate([], { relativeTo: this.route, queryParams: {} });
  }
  irAPagina(p) {
    if (!this.datos || p < 0 || p >= this.datos.totalPaginas) {
      return;
    }
    this.router.navigate([], { relativeTo: this.route, queryParams: { pagina: p || null }, queryParamsHandling: "merge" });
  }
  get hayFiltros() {
    return Object.values(this.filtro).some((v) => !!v);
  }
  /** Etiquetas de los filtros activos que no tienen selector visible (estatus y mes desde el panel). */
  get etiquetaEstatus() {
    return this.filtro.estatus ? this.filtro.estatus.replace(/_/g, " ").toLowerCase() : "";
  }
  get paginasVisibles() {
    const total = this.datos?.totalPaginas ?? 0;
    const r = [];
    for (let i = 0; i < total; i++) {
      if (i === 0 || i === total - 1 || Math.abs(i - this.pagina) <= 1) {
        r.push(i);
      } else if (r[r.length - 1] !== null) {
        r.push(null);
      }
    }
    return r;
  }
  get rango() {
    if (!this.datos || this.datos.totalElementos === 0) {
      return "";
    }
    const desde = this.datos.pagina * this.datos.tamanio + 1;
    return `Mostrando ${desde}\u2013${desde + this.datos.filas.length - 1} de ${this.datos.totalElementos}`;
  }
  nombreUnidad(clave) {
    const u = this.unidades.find((x) => x.clave === clave);
    return u ? u.abreviatura || u.nombre || u.clave : clave ?? "";
  }
  abrir(folio) {
    this.router.navigate(["/quejas", folio]);
  }
  cargar() {
    this.cargando = true;
    this.seguimiento.quejas(this.filtro, this.pagina, TAMANIO).subscribe({
      next: (d) => {
        this.datos = d;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.toast.error("No se pudieron cargar las quejas.");
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function Quejas_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Quejas)(\u0275\u0275directiveInject(SeguimientoService), \u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Quejas, selectors: [["app-quejas"]], decls: 53, vars: 11, consts: [[1, "seg-pagina"], [1, "seg-encabezado"], [1, "seg-sub"], ["routerLink", "/", 1, "seg-btn", "sec"], [1, "seg-panel"], [1, "filtros"], [1, "buscador"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["cx", "11", "cy", "11", "r", "7"], ["d", "m21 21-4.3-4.3"], ["type", "search", "placeholder", "Folio, quejoso, denunciado o abogado", "aria-label", "Buscar quejas", 3, "ngModelChange", "ngModel"], [3, "ngModelChange", "ngModel"], ["value", ""], [3, "value"], ["value", "SIN_ASIGNAR"], ["type", "month", 3, "ngModelChange", "ngModel"], [1, "activos"], [1, "seg-vacio"], ["type", "button", 1, "activo"], ["type", "button", 1, "limpiar", 3, "click"], ["type", "button", 1, "activo", 3, "click"], [1, "seg-tabla-envoltura"], [1, "seg-tabla"], [1, "clic", 3, "title"], [1, "seg-paginado"], [1, "clic", 3, "click", "title"], [1, "fuerte"], [1, "suave"], [1, "nowrap"], [3, "title"], ["title", "La est\xE1 atendiendo ahora", 1, "punto-activo"], ["type", "button", "aria-label", "Anterior", 3, "click", "disabled"], ["type", "button", "aria-label", "Siguiente", 3, "click", "disabled"], ["type", "button", 3, "actual"], ["type", "button", 3, "click"]], template: function Quejas_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "section", 0)(1, "div", 1)(2, "div")(3, "h2");
      \u0275\u0275text(4, "Quejas");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(5, "p", 2);
      \u0275\u0275text(6, "Todas las quejas del sistema, la m\xE1s reciente arriba. Abre una para ver su expediente (solo lectura).");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(7, "a", 3);
      \u0275\u0275text(8, "\u2190 Panel general");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(9, "div", 4)(10, "div", 5)(11, "div", 6);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(12, "svg", 7);
      \u0275\u0275element(13, "circle", 8)(14, "path", 9);
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(15, "input", 10);
      \u0275\u0275twoWayListener("ngModelChange", function Quejas_Template_input_ngModelChange_15_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.texto, $event) || (ctx.texto = $event);
        return $event;
      });
      \u0275\u0275listener("ngModelChange", function Quejas_Template_input_ngModelChange_15_listener() {
        return ctx.buscar();
      });
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(16, "label");
      \u0275\u0275text(17, "Etapa ");
      \u0275\u0275elementStart(18, "select", 11);
      \u0275\u0275listener("ngModelChange", function Quejas_Template_select_ngModelChange_18_listener($event) {
        return ctx.aplicar({ etapa: $event, estatus: "" });
      });
      \u0275\u0275elementStart(19, "option", 12);
      \u0275\u0275text(20, "Todas");
      \u0275\u0275elementEnd();
      \u0275\u0275repeaterCreate(21, Quejas_For_22_Template, 2, 2, "option", 13, _forTrack0);
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(23, "label");
      \u0275\u0275text(24, "Unidad / dependencia ");
      \u0275\u0275elementStart(25, "select", 11);
      \u0275\u0275listener("ngModelChange", function Quejas_Template_select_ngModelChange_25_listener($event) {
        return ctx.aplicar({ unidad: $event });
      });
      \u0275\u0275elementStart(26, "option", 12);
      \u0275\u0275text(27, "Todas");
      \u0275\u0275elementEnd();
      \u0275\u0275repeaterCreate(28, Quejas_For_29_Template, 2, 3, "option", 13, _forTrack0);
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(30, "label");
      \u0275\u0275text(31, "Abogado ");
      \u0275\u0275elementStart(32, "select", 11);
      \u0275\u0275listener("ngModelChange", function Quejas_Template_select_ngModelChange_32_listener($event) {
        return ctx.aplicar({ abogado: $event });
      });
      \u0275\u0275elementStart(33, "option", 12);
      \u0275\u0275text(34, "Todos");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(35, "option", 14);
      \u0275\u0275text(36, "Sin abogado asignado");
      \u0275\u0275elementEnd();
      \u0275\u0275repeaterCreate(37, Quejas_For_38_Template, 2, 2, "option", 13, \u0275\u0275repeaterTrackByIdentity);
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(39, "label");
      \u0275\u0275text(40, "Recepcionista ");
      \u0275\u0275elementStart(41, "select", 11);
      \u0275\u0275listener("ngModelChange", function Quejas_Template_select_ngModelChange_41_listener($event) {
        return ctx.aplicar({ recepcionista: $event });
      });
      \u0275\u0275elementStart(42, "option", 12);
      \u0275\u0275text(43, "Todas");
      \u0275\u0275elementEnd();
      \u0275\u0275repeaterCreate(44, Quejas_For_45_Template, 2, 2, "option", 13, _forTrack1);
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(46, "label");
      \u0275\u0275text(47, "Mes de llegada ");
      \u0275\u0275elementStart(48, "input", 15);
      \u0275\u0275listener("ngModelChange", function Quejas_Template_input_ngModelChange_48_listener($event) {
        return ctx.aplicar({ mes: $event });
      });
      \u0275\u0275elementEnd()()();
      \u0275\u0275conditionalCreate(49, Quejas_Conditional_49_Template, 4, 1, "div", 16);
      \u0275\u0275conditionalCreate(50, Quejas_Conditional_50_Template, 2, 0, "p", 17)(51, Quejas_Conditional_51_Template, 2, 0, "p", 17)(52, Quejas_Conditional_52_Template, 25, 4);
      \u0275\u0275elementEnd()();
    }
    if (rf & 2) {
      \u0275\u0275advance(15);
      \u0275\u0275twoWayProperty("ngModel", ctx.texto);
      \u0275\u0275advance(3);
      \u0275\u0275property("ngModel", ctx.filtro.etapa);
      \u0275\u0275advance(3);
      \u0275\u0275repeater((ctx.opciones == null ? null : ctx.opciones.etapas) ?? \u0275\u0275pureFunction0(8, _c0));
      \u0275\u0275advance(4);
      \u0275\u0275property("ngModel", ctx.filtro.unidad);
      \u0275\u0275advance(3);
      \u0275\u0275repeater(ctx.unidades);
      \u0275\u0275advance(4);
      \u0275\u0275property("ngModel", ctx.filtro.abogado);
      \u0275\u0275advance(5);
      \u0275\u0275repeater((ctx.opciones == null ? null : ctx.opciones.abogados) ?? \u0275\u0275pureFunction0(9, _c0));
      \u0275\u0275advance(4);
      \u0275\u0275property("ngModel", ctx.filtro.recepcionista);
      \u0275\u0275advance(3);
      \u0275\u0275repeater((ctx.opciones == null ? null : ctx.opciones.recepcionistas) ?? \u0275\u0275pureFunction0(10, _c0));
      \u0275\u0275advance(4);
      \u0275\u0275property("ngModel", ctx.filtro.mes);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.hayFiltros ? 49 : -1);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.cargando && !ctx.datos ? 50 : ctx.datos && ctx.datos.filas.length === 0 ? 51 : ctx.datos ? 52 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, NgSelectOption, \u0275NgSelectMultipleOption, DefaultValueAccessor, SelectControlValueAccessor, NgControlStatus, NgModel, RouterLink, DatePipe], styles: ["\n.filtros[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: flex-end;\n  gap: 10px 14px;\n  margin-bottom: 10px;\n}\n.filtros[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 3px;\n  color: var(--texto-suave);\n  font-size: 12px;\n  font-weight: 700;\n}\n.filtros[_ngcontent-%COMP%]   select[_ngcontent-%COMP%], \n.filtros[_ngcontent-%COMP%]   input[type=month][_ngcontent-%COMP%] {\n  min-width: 150px;\n  max-width: 230px;\n  padding: 7px 8px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  background: #fff;\n  font: inherit;\n  font-size: 13.5px;\n  font-weight: 400;\n  color: var(--texto);\n}\n.buscador[_ngcontent-%COMP%] {\n  position: relative;\n  flex: 1 1 260px;\n}\n.buscador[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 50%;\n  left: 10px;\n  width: 16px;\n  height: 16px;\n  transform: translateY(-50%);\n  color: var(--texto-suave);\n}\n.buscador[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 9px 10px 9px 34px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font: inherit;\n  font-size: 14px;\n}\n.activos[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin-bottom: 6px;\n}\n.activos[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  border: none;\n  font: inherit;\n  font-size: 13px;\n  cursor: pointer;\n}\n.activos[_ngcontent-%COMP%]   .activo[_ngcontent-%COMP%] {\n  padding: 4px 10px;\n  border-radius: 999px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-weight: 700;\n}\n.activos[_ngcontent-%COMP%]   .limpiar[_ngcontent-%COMP%] {\n  background: none;\n  color: var(--guinda);\n  text-decoration: underline;\n}\n.recargando[_ngcontent-%COMP%] {\n  opacity: 0.6;\n}\n.nowrap[_ngcontent-%COMP%] {\n  white-space: nowrap;\n}\n.punto-activo[_ngcontent-%COMP%] {\n  display: inline-block;\n  width: 7px;\n  height: 7px;\n  margin-right: 4px;\n  border-radius: 50%;\n  background: #2f6fed;\n}\n/*# sourceMappingURL=quejas.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Quejas, [{
    type: Component,
    args: [{ selector: "app-quejas", standalone: true, imports: [CommonModule, FormsModule, RouterLink], template: `<section class="seg-pagina">
  <div class="seg-encabezado">
    <div>
      <h2>Quejas</h2>
      <p class="seg-sub">Todas las quejas del sistema, la m\xE1s reciente arriba. Abre una para ver su expediente (solo lectura).</p>
    </div>
    <a routerLink="/" class="seg-btn sec">\u2190 Panel general</a>
  </div>

  <div class="seg-panel">
    <div class="filtros">
      <div class="buscador">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><path d="m21 21-4.3-4.3"></path></svg>
        <input type="search" [(ngModel)]="texto" (ngModelChange)="buscar()" placeholder="Folio, quejoso, denunciado o abogado" aria-label="Buscar quejas" />
      </div>

      <label>Etapa
        <select [ngModel]="filtro.etapa" (ngModelChange)="aplicar({ etapa: $event, estatus: '' })">
          <option value="">Todas</option>
          @for (e of opciones?.etapas ?? []; track e.clave) { <option [value]="e.clave">{{ e.etiqueta }}</option> }
        </select>
      </label>

      <label>Unidad / dependencia
        <select [ngModel]="filtro.unidad" (ngModelChange)="aplicar({ unidad: $event })">
          <option value="">Todas</option>
          @for (u of unidades; track u.clave) { <option [value]="u.clave">{{ u.abreviatura || u.nombre || u.clave }} ({{ u.total }})</option> }
        </select>
      </label>

      <label>Abogado
        <select [ngModel]="filtro.abogado" (ngModelChange)="aplicar({ abogado: $event })">
          <option value="">Todos</option>
          <option value="SIN_ASIGNAR">Sin abogado asignado</option>
          @for (a of opciones?.abogados ?? []; track a) { <option [value]="a">{{ a }}</option> }
        </select>
      </label>

      <label>Recepcionista
        <select [ngModel]="filtro.recepcionista" (ngModelChange)="aplicar({ recepcionista: $event })">
          <option value="">Todas</option>
          @for (r of opciones?.recepcionistas ?? []; track r.correo) { <option [value]="r.correo">{{ r.nombre }}</option> }
        </select>
      </label>

      <label>Mes de llegada
        <input type="month" [ngModel]="filtro.mes" (ngModelChange)="aplicar({ mes: $event })" />
      </label>
    </div>

    @if (hayFiltros) {
      <div class="activos">
        @if (filtro.estatus) {
          <button type="button" class="activo" (click)="aplicar({ estatus: '' })">Estatus: {{ etiquetaEstatus }} \xD7</button>
        }
        <button type="button" class="limpiar" (click)="limpiar()">Quitar todos los filtros</button>
      </div>
    }

    @if (cargando && !datos) {
      <p class="seg-vacio">Cargando quejas\u2026</p>
    } @else if (datos && datos.filas.length === 0) {
      <p class="seg-vacio">No hay quejas con estos filtros.</p>
    } @else if (datos) {
      <div class="seg-tabla-envoltura" [class.recargando]="cargando">
        <table class="seg-tabla">
          <thead>
            <tr>
              <th>Folio</th>
              <th>Lleg\xF3</th>
              <th>Quejoso</th>
              <th>Unidad</th>
              <th>D\xF3nde va</th>
              <th>Recepcionista</th>
              <th>Abogado</th>
            </tr>
          </thead>
          <tbody>
            @for (f of datos.filas; track f.folio) {
              <tr class="clic" (click)="abrir(f.folio)" [title]="'Ver la queja ' + f.folio">
                <td>
                  <span class="fuerte">{{ f.folio }}</span>
                  @if (f.origen === 'Ventanilla') { <span class="suave">Ventanilla</span> }
                </td>
                <td class="nowrap">{{ f.fecha | date: 'dd/MM/yy' }}<span class="suave">{{ f.fecha | date: 'HH:mm' }}</span></td>
                <td>{{ f.quejoso }}</td>
                <td>{{ f.unidadNombre || f.unidadClave || '\u2014' }}</td>
                <td><span [class]="'seg-chip etapa-' + f.etapa" [title]="f.estatusEtiqueta">{{ f.estatusEtiqueta }}</span></td>
                <td>
                  @if (f.recepcionista) {
                    @if (f.atendiendoAhora) { <span class="punto-activo" title="La est\xE1 atendiendo ahora"></span> }
                    {{ f.recepcionista }}
                  } @else { <span class="suave">Nadie la ha tomado</span> }
                </td>
                <td>{{ f.abogado || '\u2014' }}</td>
              </tr>
            }
          </tbody>
        </table>
      </div>
      <div class="seg-paginado">
        <span>{{ rango }}</span>
        @if (datos.totalPaginas > 1) {
          <nav>
            <button type="button" (click)="irAPagina(pagina - 1)" [disabled]="pagina === 0" aria-label="Anterior">\u2039</button>
            @for (p of paginasVisibles; track $index) {
              @if (p === null) { <span>\u2026</span> }
              @else { <button type="button" [class.actual]="p === pagina" (click)="irAPagina(p)">{{ p + 1 }}</button> }
            }
            <button type="button" (click)="irAPagina(pagina + 1)" [disabled]="pagina >= datos.totalPaginas - 1" aria-label="Siguiente">\u203A</button>
          </nav>
        }
      </div>
    }
  </div>
</section>
`, styles: ["/* src/app/pages/quejas/quejas.scss */\n.filtros {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: flex-end;\n  gap: 10px 14px;\n  margin-bottom: 10px;\n}\n.filtros label {\n  display: flex;\n  flex-direction: column;\n  gap: 3px;\n  color: var(--texto-suave);\n  font-size: 12px;\n  font-weight: 700;\n}\n.filtros select,\n.filtros input[type=month] {\n  min-width: 150px;\n  max-width: 230px;\n  padding: 7px 8px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  background: #fff;\n  font: inherit;\n  font-size: 13.5px;\n  font-weight: 400;\n  color: var(--texto);\n}\n.buscador {\n  position: relative;\n  flex: 1 1 260px;\n}\n.buscador svg {\n  position: absolute;\n  top: 50%;\n  left: 10px;\n  width: 16px;\n  height: 16px;\n  transform: translateY(-50%);\n  color: var(--texto-suave);\n}\n.buscador input {\n  width: 100%;\n  padding: 9px 10px 9px 34px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font: inherit;\n  font-size: 14px;\n}\n.activos {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin-bottom: 6px;\n}\n.activos button {\n  border: none;\n  font: inherit;\n  font-size: 13px;\n  cursor: pointer;\n}\n.activos .activo {\n  padding: 4px 10px;\n  border-radius: 999px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-weight: 700;\n}\n.activos .limpiar {\n  background: none;\n  color: var(--guinda);\n  text-decoration: underline;\n}\n.recargando {\n  opacity: 0.6;\n}\n.nowrap {\n  white-space: nowrap;\n}\n.punto-activo {\n  display: inline-block;\n  width: 7px;\n  height: 7px;\n  margin-right: 4px;\n  border-radius: 50%;\n  background: #2f6fed;\n}\n/*# sourceMappingURL=quejas.css.map */\n"] }]
  }], () => [{ type: SeguimientoService }, { type: ActivatedRoute }, { type: Router }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Quejas, { className: "Quejas", filePath: "src/app/pages/quejas/quejas.ts", lineNumber: 25 });
})();
export {
  Quejas
};
//# sourceMappingURL=chunk-CUMY4EQX.js.map
