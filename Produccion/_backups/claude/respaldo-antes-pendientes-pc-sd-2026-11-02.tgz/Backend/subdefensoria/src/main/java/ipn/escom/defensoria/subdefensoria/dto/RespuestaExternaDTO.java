package ipn.escom.defensoria.subdefensoria.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RespuestaExternaDTO {

    private Long id;
    private Long expedienteId;
    private Long oficioId;
    private String folio;
    private String canalRecepcion;
    private String numeroOficioRespuestaUA;
    private String archivoPdfPath;
    private String resumen;
    private String fechaRecepcion;
    /** Estatus del expediente despues de registrar esta respuesta (normalmente ELABORO_ACUERDO). */
    private String estatusExpediente;

    /* Archivo de la respuesta (oficio escaneado o PDF), si se adjuntó. */
    private boolean tieneArchivo;
    private String archivoNombre;
}
