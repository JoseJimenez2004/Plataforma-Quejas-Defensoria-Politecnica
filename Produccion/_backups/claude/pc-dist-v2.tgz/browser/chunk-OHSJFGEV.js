import{a as ge,b as k,c as fe,d as T,e as B,f as w,g as z,h as X}from"./chunk-QKSEDOBQ.js";import{$ as ue,I as ce,S as R,T as I,U as A,V as O,aa as pe,b as de,ca as P}from"./chunk-AOZRCRFD.js";import{q as me}from"./chunk-NMBGDNAI.js";import{$ as K,Aa as ee,Ab as ae,Bb as v,Cb as x,Eb as r,Fb as t,Fc as S,Gb as re,Hb as E,Ib as D,Jb as h,Jc as H,Nb as U,Rb as $,Tb as p,Va as s,Y as C,Z as J,aa as M,ba as _,bb as ne,cb as g,cc as Q,dc as oe,ec as se,fc as a,ga as q,gc as m,ha as G,hc as y,ib as b,ic as le,jb as te,oa as W,pa as Y,wb as ie,xb as c,yb as u,zb as L}from"./chunk-RUVVR6EI.js";function Me(e,i){e&1&&h(0,"div",2)}var Ee=new K("MAT_PROGRESS_BAR_DEFAULT_OPTIONS");var be=(()=>{class e{_elementRef=_(ee);_ngZone=_(Y);_changeDetectorRef=_(S);_renderer=_(ne);_cleanupTransitionEnd;constructor(){let n=ce(),o=_(Ee,{optional:!0});this._isNoopAnimation=n==="di-disabled",n==="reduced-motion"&&this._elementRef.nativeElement.classList.add("mat-progress-bar-reduced-motion"),o&&(o.color&&(this.color=this._defaultColor=o.color),this.mode=o.mode||this.mode)}_isNoopAnimation;get color(){return this._color||this._defaultColor}set color(n){this._color=n}_color;_defaultColor="primary";get value(){return this._value}set value(n){this._value=_e(n||0),this._changeDetectorRef.markForCheck()}_value=0;get bufferValue(){return this._bufferValue||0}set bufferValue(n){this._bufferValue=_e(n||0),this._changeDetectorRef.markForCheck()}_bufferValue=0;animationEnd=new W;get mode(){return this._mode}set mode(n){this._mode=n,this._changeDetectorRef.markForCheck()}_mode="determinate";ngAfterViewInit(){this._ngZone.runOutsideAngular(()=>{this._cleanupTransitionEnd=this._renderer.listen(this._elementRef.nativeElement,"transitionend",this._transitionendHandler)})}ngOnDestroy(){this._cleanupTransitionEnd?.()}_getPrimaryBarTransform(){return`scaleX(${this._isIndeterminate()?1:this.value/100})`}_getBufferBarFlexBasis(){return`${this.mode==="buffer"?this.bufferValue:100}%`}_isIndeterminate(){return this.mode==="indeterminate"||this.mode==="query"}_transitionendHandler=n=>{this.animationEnd.observers.length===0||!n.target||!n.target.classList.contains("mdc-linear-progress__primary-bar")||(this.mode==="determinate"||this.mode==="buffer")&&this._ngZone.run(()=>this.animationEnd.next({value:this.value}))};static \u0275fac=function(o){return new(o||e)};static \u0275cmp=b({type:e,selectors:[["mat-progress-bar"]],hostAttrs:["role","progressbar","aria-valuemin","0","aria-valuemax","100","tabindex","-1",1,"mat-mdc-progress-bar","mdc-linear-progress"],hostVars:10,hostBindings:function(o,l){o&2&&(ie("aria-valuenow",l._isIndeterminate()?null:l.value)("mode",l.mode),se("mat-"+l.color),oe("_mat-animation-noopable",l._isNoopAnimation)("mdc-linear-progress--animation-ready",!l._isNoopAnimation)("mdc-linear-progress--indeterminate",l._isIndeterminate()))},inputs:{color:"color",value:[2,"value","value",H],bufferValue:[2,"bufferValue","bufferValue",H],mode:"mode"},outputs:{animationEnd:"animationEnd"},exportAs:["matProgressBar"],decls:7,vars:5,consts:[["aria-hidden","true",1,"mdc-linear-progress__buffer"],[1,"mdc-linear-progress__buffer-bar"],[1,"mdc-linear-progress__buffer-dots"],["aria-hidden","true",1,"mdc-linear-progress__bar","mdc-linear-progress__primary-bar"],[1,"mdc-linear-progress__bar-inner"],["aria-hidden","true",1,"mdc-linear-progress__bar","mdc-linear-progress__secondary-bar"]],template:function(o,l){o&1&&(E(0,"div",0),h(1,"div",1),c(2,Me,1,0,"div",2),D(),E(3,"div",3),h(4,"span",4),D(),E(5,"div",5),h(6,"span",4),D()),o&2&&(s(),Q("flex-basis",l._getBufferBarFlexBasis()),s(),u(l.mode==="buffer"?2:-1),s(),Q("transform",l._getPrimaryBarTransform()))},styles:[`.mat-mdc-progress-bar {
  --mat-progress-bar-animation-multiplier: 1;
  display: block;
  text-align: start;
}
.mat-mdc-progress-bar[mode=query] {
  transform: scaleX(-1);
}
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__buffer-dots,
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__primary-bar,
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__secondary-bar,
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__bar-inner.mdc-linear-progress__bar-inner {
  animation: none;
}
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__primary-bar,
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__buffer-bar {
  transition: transform 1ms;
}

.mat-progress-bar-reduced-motion {
  --mat-progress-bar-animation-multiplier: 2;
}

.mdc-linear-progress {
  position: relative;
  width: 100%;
  transform: translateZ(0);
  outline: 1px solid transparent;
  overflow-x: hidden;
  transition: opacity 250ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  height: max(var(--mat-progress-bar-track-height, 4px), var(--mat-progress-bar-active-indicator-height, 4px));
}
@media (forced-colors: active) {
  .mdc-linear-progress {
    outline-color: CanvasText;
  }
}

.mdc-linear-progress__bar {
  position: absolute;
  top: 0;
  bottom: 0;
  margin: auto 0;
  width: 100%;
  animation: none;
  transform-origin: top left;
  transition: transform 250ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  height: var(--mat-progress-bar-active-indicator-height, 4px);
}
.mdc-linear-progress--indeterminate .mdc-linear-progress__bar {
  transition: none;
}
[dir=rtl] .mdc-linear-progress__bar {
  right: 0;
  transform-origin: center right;
}

.mdc-linear-progress__bar-inner {
  display: inline-block;
  position: absolute;
  width: 100%;
  animation: none;
  border-top-style: solid;
  border-color: var(--mat-progress-bar-active-indicator-color, var(--mat-sys-primary));
  border-top-width: var(--mat-progress-bar-active-indicator-height, 4px);
}

.mdc-linear-progress__buffer {
  display: flex;
  position: absolute;
  top: 0;
  bottom: 0;
  margin: auto 0;
  width: 100%;
  overflow: hidden;
  height: var(--mat-progress-bar-track-height, 4px);
  border-radius: var(--mat-progress-bar-track-shape, var(--mat-sys-corner-none));
}

.mdc-linear-progress__buffer-dots {
  background-image: radial-gradient(circle, var(--mat-progress-bar-track-color, var(--mat-sys-surface-variant)) calc(var(--mat-progress-bar-track-height, 4px) / 2), transparent 0);
  background-repeat: repeat-x;
  background-size: calc(calc(var(--mat-progress-bar-track-height, 4px) / 2) * 5);
  background-position: left;
  flex: auto;
  transform: rotate(180deg);
  animation: mdc-linear-progress-buffering calc(250ms * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
@media (forced-colors: active) {
  .mdc-linear-progress__buffer-dots {
    background-color: ButtonBorder;
  }
}
[dir=rtl] .mdc-linear-progress__buffer-dots {
  animation: mdc-linear-progress-buffering-reverse calc(250ms * var(--mat-progress-bar-animation-multiplier)) infinite linear;
  transform: rotate(0);
}

.mdc-linear-progress__buffer-bar {
  flex: 0 1 100%;
  transition: flex-basis 250ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  background-color: var(--mat-progress-bar-track-color, var(--mat-sys-surface-variant));
}

.mdc-linear-progress__primary-bar {
  transform: scaleX(0);
}
.mdc-linear-progress--indeterminate .mdc-linear-progress__primary-bar {
  left: -145.166611%;
}
.mdc-linear-progress--indeterminate.mdc-linear-progress--animation-ready .mdc-linear-progress__primary-bar {
  animation: mdc-linear-progress-primary-indeterminate-translate calc(2s * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
.mdc-linear-progress--indeterminate.mdc-linear-progress--animation-ready .mdc-linear-progress__primary-bar > .mdc-linear-progress__bar-inner {
  animation: mdc-linear-progress-primary-indeterminate-scale calc(2s * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
[dir=rtl] .mdc-linear-progress.mdc-linear-progress--animation-ready .mdc-linear-progress__primary-bar {
  animation-name: mdc-linear-progress-primary-indeterminate-translate-reverse;
}
[dir=rtl] .mdc-linear-progress.mdc-linear-progress--indeterminate .mdc-linear-progress__primary-bar {
  right: -145.166611%;
  left: auto;
}

.mdc-linear-progress__secondary-bar {
  display: none;
}
.mdc-linear-progress--indeterminate .mdc-linear-progress__secondary-bar {
  left: -54.888891%;
  display: block;
}
.mdc-linear-progress--indeterminate.mdc-linear-progress--animation-ready .mdc-linear-progress__secondary-bar {
  animation: mdc-linear-progress-secondary-indeterminate-translate calc(2s * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
.mdc-linear-progress--indeterminate.mdc-linear-progress--animation-ready .mdc-linear-progress__secondary-bar > .mdc-linear-progress__bar-inner {
  animation: mdc-linear-progress-secondary-indeterminate-scale calc(2s * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
[dir=rtl] .mdc-linear-progress.mdc-linear-progress--animation-ready .mdc-linear-progress__secondary-bar {
  animation-name: mdc-linear-progress-secondary-indeterminate-translate-reverse;
}
[dir=rtl] .mdc-linear-progress.mdc-linear-progress--indeterminate .mdc-linear-progress__secondary-bar {
  right: -54.888891%;
  left: auto;
}

@keyframes mdc-linear-progress-buffering {
  from {
    transform: rotate(180deg) translateX(calc(var(--mat-progress-bar-track-height, 4px) * -2.5));
  }
}
@keyframes mdc-linear-progress-primary-indeterminate-translate {
  0% {
    transform: translateX(0);
  }
  20% {
    animation-timing-function: cubic-bezier(0.5, 0, 0.701732, 0.495819);
    transform: translateX(0);
  }
  59.15% {
    animation-timing-function: cubic-bezier(0.302435, 0.381352, 0.55, 0.956352);
    transform: translateX(83.67142%);
  }
  100% {
    transform: translateX(200.611057%);
  }
}
@keyframes mdc-linear-progress-primary-indeterminate-scale {
  0% {
    transform: scaleX(0.08);
  }
  36.65% {
    animation-timing-function: cubic-bezier(0.334731, 0.12482, 0.785844, 1);
    transform: scaleX(0.08);
  }
  69.15% {
    animation-timing-function: cubic-bezier(0.06, 0.11, 0.6, 1);
    transform: scaleX(0.661479);
  }
  100% {
    transform: scaleX(0.08);
  }
}
@keyframes mdc-linear-progress-secondary-indeterminate-translate {
  0% {
    animation-timing-function: cubic-bezier(0.15, 0, 0.515058, 0.409685);
    transform: translateX(0);
  }
  25% {
    animation-timing-function: cubic-bezier(0.31033, 0.284058, 0.8, 0.733712);
    transform: translateX(37.651913%);
  }
  48.35% {
    animation-timing-function: cubic-bezier(0.4, 0.627035, 0.6, 0.902026);
    transform: translateX(84.386165%);
  }
  100% {
    transform: translateX(160.277782%);
  }
}
@keyframes mdc-linear-progress-secondary-indeterminate-scale {
  0% {
    animation-timing-function: cubic-bezier(0.205028, 0.057051, 0.57661, 0.453971);
    transform: scaleX(0.08);
  }
  19.15% {
    animation-timing-function: cubic-bezier(0.152313, 0.196432, 0.648374, 1.004315);
    transform: scaleX(0.457104);
  }
  44.15% {
    animation-timing-function: cubic-bezier(0.257759, -0.003163, 0.211762, 1.38179);
    transform: scaleX(0.72796);
  }
  100% {
    transform: scaleX(0.08);
  }
}
@keyframes mdc-linear-progress-primary-indeterminate-translate-reverse {
  0% {
    transform: translateX(0);
  }
  20% {
    animation-timing-function: cubic-bezier(0.5, 0, 0.701732, 0.495819);
    transform: translateX(0);
  }
  59.15% {
    animation-timing-function: cubic-bezier(0.302435, 0.381352, 0.55, 0.956352);
    transform: translateX(-83.67142%);
  }
  100% {
    transform: translateX(-200.611057%);
  }
}
@keyframes mdc-linear-progress-secondary-indeterminate-translate-reverse {
  0% {
    animation-timing-function: cubic-bezier(0.15, 0, 0.515058, 0.409685);
    transform: translateX(0);
  }
  25% {
    animation-timing-function: cubic-bezier(0.31033, 0.284058, 0.8, 0.733712);
    transform: translateX(-37.651913%);
  }
  48.35% {
    animation-timing-function: cubic-bezier(0.4, 0.627035, 0.6, 0.902026);
    transform: translateX(-84.386165%);
  }
  100% {
    transform: translateX(-160.277782%);
  }
}
@keyframes mdc-linear-progress-buffering-reverse {
  from {
    transform: translateX(-10px);
  }
}
`],encapsulation:2,changeDetection:0})}return e})();function _e(e,i=0,n=100){return Math.max(i,Math.min(n,e))}var ve=(()=>{class e{static \u0275fac=function(o){return new(o||e)};static \u0275mod=te({type:e});static \u0275inj=J({imports:[de]})}return e})();var Se=["golpe","golpe\xF3","agred","amenaz","acos","hostig","humill","insult","grit","discrimin","ofens","violen","abus","intimid","burl","exhib","reprob","castig","extors","sexual","miedo","lesion","empuj","represal","toc","oblig","despid","in\xFAtil","inutil","denigr","excluy","neg\xF3","nego"];function xe(e){let i=(e??"").replace(/\s+/g," ").trim();if(!i)return{resumen:"",frasesImpacto:[]};let n=i.split(/(?<=[.!?;])\s+/).map(d=>d.trim()).filter(d=>d.length>12);if(n.length===0)return{resumen:Z(i,380),frasesImpacto:[]};let o=n.map((d,f)=>({oracion:d,indice:f,puntos:Re(d)})),l=o.filter(d=>d.puntos>0).sort((d,f)=>f.puntos-d.puntos||d.indice-f.indice),V=[o[0]];l.length>0&&l[0].indice!==0?V.push(l[0]):o.length>1&&V.push(o[1]);let Ce=V.sort((d,f)=>d.indice-f.indice).map(d=>d.oracion).join(" ");return{resumen:Z(Ce,380),frasesImpacto:l.slice(0,3).map(d=>Z(d.oracion,220))}}function Re(e){let i=e.toLowerCase();return Se.reduce((n,o)=>n+(i.includes(o)?1:0),0)}function Z(e,i){return e.length<=i?e:e.slice(0,i-1).trimEnd()+"\u2026"}var F=class e{constructor(i){this.api=i}api;resumir(i){return this.api.post("/resumen",{texto:i})}static \u0275fac=function(n){return new(n||e)(M(P))};static \u0275prov=C({token:e,factory:e.\u0275fac,providedIn:"root"})};function Be(e,i){if(e&1&&a(0),e&2){let n=p();y(" \xB7 ",n.data.asunto," ")}}function we(e,i){e&1&&(r(0,"p",2),a(1,"La queja no tiene narrativa para resumir."),t())}function ze(e,i){e&1&&(r(0,"div",3),re(1,"mat-progress-bar",6),r(2,"p")(3,"strong"),a(4,"Generando el resumen con el modelo\u2026"),t(),a(5," Puede tardar hasta 2 minutos. Si cierras este cuadro, el resumen se seguir\xE1 generando y aparecer\xE1 de inmediato la pr\xF3xima vez. "),t()())}function Xe(e,i){e&1&&(r(0,"p",2),a(1,"El modelo no devolvi\xF3 fragmentos."),t())}function je(e,i){if(e&1&&(r(0,"li")(1,"mat-icon"),a(2,"format_quote"),t(),r(3,"span"),a(4),t()()),e&2){let n=i.$implicit;s(4),m(n)}}function Fe(e,i){if(e&1&&(r(0,"ul",10),v(1,je,5,1,"li",null,L),t()),e&2){let n=p(2);s(),x(n.modelo.fragmentos)}}function Ne(e,i){if(e&1&&(r(0,"div",7)(1,"mat-icon"),a(2,"rate_review"),t(),r(3,"span")(4,"strong"),a(5,"Borrador del modelo."),t(),a(6," Es una sugerencia para apoyar el an\xE1lisis: rev\xEDsalo contra la narrativa antes de usarlo. "),t()(),r(7,"section")(8,"span",8),a(9,"Resumen propuesto"),t(),r(10,"p",9),a(11),t()(),r(12,"section")(13,"span",8),a(14,"Fragmentos clave de la queja"),t(),c(15,Xe,2,0,"p",2)(16,Fe,3,0,"ul",10),t()),e&2){let n=p();s(11),m(n.modelo.resumen),s(4),u(n.modelo.fragmentos.length===0?15:16)}}function Ve(e,i){e&1&&(r(0,"div",11)(1,"mat-icon"),a(2,"science"),t(),r(3,"span")(4,"strong"),a(5,"Simulado."),t(),a(6," El modelo de resumen no est\xE1 disponible en este momento; este resumen es una aproximaci\xF3n calculada en el navegador. "),t()())}function qe(e,i){e&1&&(r(0,"p",2),a(1,"No se identificaron frases de impacto en la narrativa."),t())}function Ge(e,i){if(e&1&&(r(0,"li")(1,"mat-icon"),a(2,"format_quote"),t(),r(3,"span"),a(4),t()()),e&2){let n=i.$implicit;s(4),m(n)}}function Le(e,i){if(e&1&&(r(0,"ul",10),v(1,Ge,5,1,"li",null,L),t()),e&2){let n=p(2);s(),x(n.simulado.frasesImpacto)}}function Ue(e,i){if(e&1&&(c(0,Ve,7,0,"div",11),r(1,"section")(2,"span",8),a(3,"Resumen propuesto"),t(),r(4,"p",9),a(5),t()(),r(6,"section")(7,"span",8),a(8,"Frases de impacto"),t(),c(9,qe,2,0,"p",2)(10,Le,3,0,"ul",10),t()),e&2){let n=p();u(n.sinModelo?0:-1),s(5),m(n.simulado.resumen),s(4),u(n.simulado.frasesImpacto.length===0?9:10)}}var N=class e{constructor(i,n,o){this.data=i;this.resumenService=n;this.cdr=o;this.simulado=xe(i.texto)}data;resumenService;cdr;simulado;modelo=null;cargando=!1;sinModelo=!1;peticion;ngOnInit(){!this.simulado.resumen||!this.data.texto||(this.cargando=!0,this.peticion=this.resumenService.resumir(this.data.texto).subscribe({next:i=>{this.modelo=i,this.cargando=!1,this.cdr.detectChanges()},error:()=>{this.sinModelo=!0,this.cargando=!1,this.cdr.detectChanges()}}))}ngOnDestroy(){this.peticion?.unsubscribe()}static \u0275fac=function(n){return new(n||e)(g(k),g(F),g(S))};static \u0275cmp=b({type:e,selectors:[["app-resumen-dialog"]],decls:14,vars:3,consts:[["mat-dialog-title",""],[1,"encabezado"],[1,"vacio"],[1,"generando"],["align","end"],["mat-flat-button","","mat-dialog-close","",1,"primary-btn"],["mode","indeterminate"],[1,"simulado","revision"],[1,"etiqueta"],[1,"resumen"],[1,"frases"],[1,"simulado"]],template:function(n,o){n&1&&(r(0,"h2",0),a(1,"Resumen de la queja"),t(),r(2,"mat-dialog-content")(3,"p",1)(4,"strong"),a(5),t(),c(6,Be,1,1),t(),c(7,we,2,0,"p",2)(8,ze,6,0,"div",3)(9,Ne,17,2)(10,Ue,11,3),t(),r(11,"mat-dialog-actions",4)(12,"button",5),a(13,"Cerrar"),t()()),n&2&&(s(5),m(o.data.folio),s(),u(o.data.asunto?6:-1),s(),u(o.simulado.resumen?o.cargando?8:o.modelo?9:10:7))},dependencies:[X,T,B,z,w,I,R,O,A,ve,be],styles:[".encabezado[_ngcontent-%COMP%]{margin:0 0 12px;color:var(--texto-suave)}.encabezado[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--negro-inst)}.simulado[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:8px;padding:10px 14px;border-radius:10px;background:#fff4e5;color:#7a4800;font-size:13px;margin-bottom:16px}.simulado.revision[_ngcontent-%COMP%]{background:#eef4ff;color:#1e3a8a}.generando[_ngcontent-%COMP%]{display:grid;gap:12px;margin:8px 0 4px}.generando[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;color:var(--texto-suave);font-size:13px;line-height:1.5}.generando[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{display:block;color:var(--negro-inst);font-size:14px}section[_ngcontent-%COMP%]{margin-top:14px}.etiqueta[_ngcontent-%COMP%]{display:block;color:var(--guinda);font-size:12px;font-weight:900;text-transform:uppercase;letter-spacing:.05em}.resumen[_ngcontent-%COMP%]{margin:6px 0 0;color:var(--negro-inst);line-height:1.5}.frases[_ngcontent-%COMP%]{list-style:none;margin:8px 0 0;padding:0;display:grid;gap:8px}.frases[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{display:flex;gap:8px;padding:10px 12px;border-left:4px solid var(--guinda);border-radius:8px;background:var(--guinda-suave);color:var(--negro-inst);font-style:italic}.frases[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{color:var(--guinda);flex-shrink:0}.vacio[_ngcontent-%COMP%]{color:var(--texto-suave)}.primary-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important;border-radius:999px!important;font-weight:800}"]})};function $e(e,i){if(e&1&&a(0),e&2){let n=p();y(" \xB7 Similitud ",n.a.similitud,"% ")}}function Qe(e,i){if(e&1&&(r(0,"span",9),a(1),t()),e&2){let n=i.$implicit;s(),m(n)}}function He(e,i){if(e&1&&(r(0,"div",2),v(1,Qe,2,1,"span",9,ae),t()),e&2){let n=p();s(),x(n.a.coincidencias)}}function Ze(e,i){if(e&1&&(r(0,"div")(1,"span"),a(2,"Resultado"),t(),r(3,"strong"),a(4),t()()),e&2){let n=p();s(4),m(n.a.resultado)}}function Je(e,i){if(e&1&&(r(0,"div")(1,"span"),a(2,"Guardado por"),t(),r(3,"strong"),a(4),t()(),r(5,"div")(6,"span"),a(7,"Encontrado con"),t(),r(8,"strong"),a(9),t()()),e&2){let n=p();s(4),le("",n.a.analistaNombre," \xB7 ",n.formatearFechaHora(n.a.fechaRegistro)),s(5),m(n.fuente)}}function Ke(e,i){if(e&1){let n=U();r(0,"button",10),$("click",function(){q(n);let l=p();return G(l.verResumen())}),r(1,"mat-icon"),a(2,"summarize"),t(),a(3," Resumen "),t()}}function We(e,i){if(e&1){let n=U();r(0,"button",10),$("click",function(){q(n);let l=p();return G(l.verExpediente())}),r(1,"mat-icon"),a(2,"open_in_new"),t(),a(3," Ver expediente "),t()}}var he=class e{constructor(i,n,o,l){this.a=i;this.dialogRef=n;this.dialog=o;this.router=l}a;dialogRef;dialog;router;formatearFecha=ue;formatearFechaHora=pe;get narrativa(){return this.a.descripcion||this.a.extracto||""}get origen(){return this.a.origen==="HISTORICO"?"Caso hist\xF3rico":"Queja del sistema"}get fuente(){switch(this.a.fuente){case"MANUAL":return"B\xFAsqueda manual";case"MODELO":return"Modelo";case"REGLAS_PROVISIONAL":return"Motor provisional";default:return this.a.fuente??""}}verResumen(){this.dialog.open(N,{width:"640px",data:{folio:this.a.folioQueja,asunto:this.a.asunto,texto:this.narrativa}})}verExpediente(){this.dialogRef.close(),this.router.navigate(["/expediente",this.a.folioPrimerContacto])}static \u0275fac=function(n){return new(n||e)(g(k),g(ge),g(fe),g(me))};static \u0275cmp=b({type:e,selectors:[["app-antecedente-detalle-dialog"]],decls:47,vars:15,consts:[["mat-dialog-title",""],[1,"encabezado"],[1,"coincidencias"],[1,"grid"],[1,"etiqueta"],[1,"narrativa"],["align","end"],["mat-stroked-button",""],["mat-flat-button","","mat-dialog-close","",1,"primary-btn"],[1,"coincidencia"],["mat-stroked-button","",3,"click"]],template:function(n,o){n&1&&(r(0,"h2",0),a(1),t(),r(2,"mat-dialog-content")(3,"p",1)(4,"strong"),a(5),t(),a(6),c(7,$e,1,1),t(),c(8,He,3,0,"div",2),r(9,"div",3)(10,"div")(11,"span"),a(12,"Quejoso"),t(),r(13,"strong"),a(14),t()(),r(15,"div")(16,"span"),a(17,"Denunciado"),t(),r(18,"strong"),a(19),t()(),r(20,"div")(21,"span"),a(22,"Fecha"),t(),r(23,"strong"),a(24),t()(),r(25,"div")(26,"span"),a(27,"Unidad acad\xE9mica"),t(),r(28,"strong"),a(29),t()(),r(30,"div")(31,"span"),a(32,"Estatus"),t(),r(33,"strong"),a(34),t()(),c(35,Ze,5,1,"div"),c(36,Je,10,3),t(),r(37,"section")(38,"span",4),a(39,"Narrativa de los hechos"),t(),r(40,"p",5),a(41),t()()(),r(42,"mat-dialog-actions",6),c(43,Ke,4,0,"button",7),c(44,We,4,0,"button",7),r(45,"button",8),a(46,"Cerrar"),t()()),n&2&&(s(),m(o.a.asunto||"Queja sin asunto"),s(4),m(o.a.folioQueja),s(),y(" \xB7 ",o.origen," "),s(),u(o.a.similitud!=null?7:-1),s(),u(o.a.coincidencias!=null&&o.a.coincidencias.length?8:-1),s(6),m(o.a.nombreQuejoso||"\u2014"),s(5),m(o.a.nombreDenunciado||"\u2014"),s(5),m(o.formatearFecha(o.a.fecha)||"\u2014"),s(5),m(o.a.unidadAcademica||"\u2014"),s(5),m(o.a.estatus||"\u2014"),s(),u(o.a.resultado?35:-1),s(),u(o.a.analistaNombre?36:-1),s(5),m(o.narrativa||"Sin narrativa registrada."),s(2),u(o.narrativa?43:-1),s(),u(o.a.folioPrimerContacto?44:-1))},dependencies:[X,T,B,z,w,I,R,O,A],styles:[".encabezado[_ngcontent-%COMP%]{margin:0 0 10px;color:var(--texto-suave)}.encabezado[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--negro-inst)}.coincidencias[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px}.coincidencia[_ngcontent-%COMP%]{padding:2px 10px;border-radius:999px;background:var(--guinda-suave);color:var(--guinda);font-size:12px;font-weight:700}.grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:10px}.grid[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{display:grid;gap:2px;padding:10px 12px;border:1px solid var(--borde);border-radius:10px;background:#fbfbfc}.grid[_ngcontent-%COMP%]   span[_ngcontent-%COMP%], .etiqueta[_ngcontent-%COMP%]{color:var(--texto-suave);font-size:12px;font-weight:900;text-transform:uppercase}.grid[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--negro-inst)}section[_ngcontent-%COMP%]{margin-top:16px}.narrativa[_ngcontent-%COMP%]{margin:6px 0 0;color:var(--negro-inst);line-height:1.5;white-space:pre-line}.primary-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important;border-radius:999px!important;font-weight:800}@media(max-width:700px){.grid[_ngcontent-%COMP%]{grid-template-columns:1fr}}"]})};var ye=class e{constructor(i){this.api=i}api;buscar(i){return this.api.get(`/antecedentes/${encodeURIComponent(i)}`)}buscarManual(i,n,o){let l=new URLSearchParams;return n.trim()&&l.set("quejoso",n.trim()),o.trim()&&l.set("denunciado",o.trim()),this.api.get(`/antecedentes/${encodeURIComponent(i)}/manual?${l.toString()}`)}guardados(i){return this.api.get(`/antecedentes/${encodeURIComponent(i)}/guardados`)}guardar(i,n){return this.api.post(`/antecedentes/${encodeURIComponent(i)}/guardados`,{antecedentes:n})}quitar(i,n){return this.api.delete(`/antecedentes/${encodeURIComponent(i)}/guardados/${n}`)}static \u0275fac=function(n){return new(n||e)(M(P))};static \u0275prov=C({token:e,factory:e.\u0275fac,providedIn:"root"})};export{be as a,ve as b,xe as c,F as d,N as e,he as f,ye as g};
