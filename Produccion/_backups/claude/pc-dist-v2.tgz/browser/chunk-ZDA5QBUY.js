import{a as qt,d as Zt,e as Yt,f as Jt,g as en}from"./chunk-L5X7N3PP.js";import{a as ln,b as cn,e as dn,f as mn,g as bn}from"./chunk-OHSJFGEV.js";import{a as tn,b as nn}from"./chunk-UL2V62AU.js";import{a as vt,b as yt}from"./chunk-E247WON3.js";import{c as rn,h as sn}from"./chunk-QKSEDOBQ.js";import{a as un}from"./chunk-WEQ6ZQEC.js";import{c as we}from"./chunk-ZJQENDBV.js";import{a as Gt,b as Xt,c as Kt}from"./chunk-S4T445ON.js";import{C as an,D as on,f as Ht,g as Wt,l as $t,n as Ut,o as Fe}from"./chunk-5ZJJJVUL.js";import{a as Ce,b as Pt,c as At,f as Dt,g as Rt,h as Ot,i as Bt,j as Lt,p as Ft,s as zt,t as jt,w as Vt,z as Nt}from"./chunk-HTFXFXSQ.js";import{$ as Qt,J as q,N as Z,P as ae,Q as wt,R as Tt,S as Mt,T as It,U as St,V as Et,a as me,b as te,e as Le,i as ue,j as xt,k as ne,p as kt,v as ke,x as Ct,y as U}from"./chunk-AOZRCRFD.js";import{c as ht,o as _t,q as ft}from"./chunk-NMBGDNAI.js";import{$ as E,$a as ye,A as tt,Aa as R,Ab as $,Ac as de,B as ge,Ba as st,Bb as O,C as nt,Cb as B,Db as p,Eb as o,Fb as s,Fc as D,G as at,Gb as I,Ic as g,Jc as ee,Mb as De,Nb as S,Ob as mt,P as it,Q as pe,R as ot,Rb as b,S as ie,Tb as u,Ub as Q,Va as c,Vb as G,Wb as Y,X as he,Xb as j,Yb as k,Z as X,Zb as C,_a as ve,ba as m,bb as Ae,bc as L,cb as N,cc as xe,dc as f,e as W,eb as lt,ec as J,fc as l,g as Ye,ga as h,gc as w,ha as _,hc as A,i as be,ia as rt,ib as P,ic as Re,jb as K,jc as Oe,ka as Ee,kb as F,kc as ut,lc as se,mc as le,n as Je,nb as re,nc as ce,oa as T,ob as z,oc as V,p as et,pa as oe,pb as ct,pc as Be,qc as bt,rc as gt,ta as Pe,uc as pt,vb as dt,wb as x,xa as _e,xb as v,ya as fe,yb as y}from"./chunk-RUVVR6EI.js";var En=["switch"],Pn=["*"];function An(a,r){a&1&&(o(0,"span",11),rt(),o(1,"svg",13),I(2,"path",14),s(),o(3,"svg",15),I(4,"path",16),s()())}var Dn=new E("mat-slide-toggle-default-options",{providedIn:"root",factory:()=>({disableToggleValue:!1,hideIcon:!1,disabledInteractive:!1})}),Te=class{source;checked;constructor(r,e){this.source=r,this.checked=e}},je=(()=>{class a{_elementRef=m(R);_focusMonitor=m(ue);_changeDetectorRef=m(D);defaults=m(Dn);_onChange=e=>{};_onTouched=()=>{};_validatorOnChange=()=>{};_uniqueId;_checked=!1;_createChangeEvent(e){return new Te(this,e)}_labelId;get buttonId(){return`${this.id||this._uniqueId}-button`}_switchElement;focus(){this._switchElement.nativeElement.focus()}_noopAnimations=q();_focused=!1;name=null;id;labelPosition="after";ariaLabel=null;ariaLabelledby=null;ariaDescribedby;required=!1;color;disabled=!1;disableRipple=!1;tabIndex=0;get checked(){return this._checked}set checked(e){this._checked=e,this._changeDetectorRef.markForCheck()}hideIcon;disabledInteractive;change=new T;toggleChange=new T;get inputId(){return`${this.id||this._uniqueId}-input`}constructor(){m(ne).load(ae);let e=m(new de("tabindex"),{optional:!0}),t=this.defaults;this.tabIndex=e==null?0:parseInt(e)||0,this.color=t.color||"accent",this.id=this._uniqueId=m(U).getId("mat-mdc-slide-toggle-"),this.hideIcon=t.hideIcon??!1,this.disabledInteractive=t.disabledInteractive??!1,this._labelId=this._uniqueId+"-label"}ngAfterContentInit(){this._focusMonitor.monitor(this._elementRef,!0).subscribe(e=>{e==="keyboard"||e==="program"?(this._focused=!0,this._changeDetectorRef.markForCheck()):e||Promise.resolve().then(()=>{this._focused=!1,this._onTouched(),this._changeDetectorRef.markForCheck()})})}ngOnChanges(e){e.required&&this._validatorOnChange()}ngOnDestroy(){this._focusMonitor.stopMonitoring(this._elementRef)}writeValue(e){this.checked=!!e}registerOnChange(e){this._onChange=e}registerOnTouched(e){this._onTouched=e}validate(e){return this.required&&e.value!==!0?{required:!0}:null}registerOnValidatorChange(e){this._validatorOnChange=e}setDisabledState(e){this.disabled=e,this._changeDetectorRef.markForCheck()}toggle(){this.checked=!this.checked,this._onChange(this.checked)}_emitChangeEvent(){this._onChange(this.checked),this.change.emit(this._createChangeEvent(this.checked))}_handleClick(){this.disabled||(this.toggleChange.emit(),this.defaults.disableToggleValue||(this.checked=!this.checked,this._onChange(this.checked),this.change.emit(new Te(this,this.checked))))}_getAriaLabelledBy(){return this.ariaLabelledby?this.ariaLabelledby:this.ariaLabel?null:this._labelId}static \u0275fac=function(t){return new(t||a)};static \u0275cmp=P({type:a,selectors:[["mat-slide-toggle"]],viewQuery:function(t,n){if(t&1&&j(En,5),t&2){let i;k(i=C())&&(n._switchElement=i.first)}},hostAttrs:[1,"mat-mdc-slide-toggle"],hostVars:13,hostBindings:function(t,n){t&2&&(mt("id",n.id),x("tabindex",null)("aria-label",null)("name",null)("aria-labelledby",null),J(n.color?"mat-"+n.color:""),f("mat-mdc-slide-toggle-focused",n._focused)("mat-mdc-slide-toggle-checked",n.checked)("_mat-animation-noopable",n._noopAnimations))},inputs:{name:"name",id:"id",labelPosition:"labelPosition",ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],ariaDescribedby:[0,"aria-describedby","ariaDescribedby"],required:[2,"required","required",g],color:"color",disabled:[2,"disabled","disabled",g],disableRipple:[2,"disableRipple","disableRipple",g],tabIndex:[2,"tabIndex","tabIndex",e=>e==null?0:ee(e)],checked:[2,"checked","checked",g],hideIcon:[2,"hideIcon","hideIcon",g],disabledInteractive:[2,"disabledInteractive","disabledInteractive",g]},outputs:{change:"change",toggleChange:"toggleChange"},exportAs:["matSlideToggle"],features:[V([{provide:Ce,useExisting:he(()=>a),multi:!0},{provide:At,useExisting:a,multi:!0}]),_e],ngContentSelectors:Pn,decls:14,vars:27,consts:[["switch",""],["mat-internal-form-field","",3,"labelPosition"],["role","switch","type","button",1,"mdc-switch",3,"click","tabIndex","disabled"],[1,"mat-mdc-slide-toggle-touch-target"],[1,"mdc-switch__track"],[1,"mdc-switch__handle-track"],[1,"mdc-switch__handle"],[1,"mdc-switch__shadow"],[1,"mdc-elevation-overlay"],[1,"mdc-switch__ripple"],["mat-ripple","",1,"mat-mdc-slide-toggle-ripple","mat-focus-indicator",3,"matRippleTrigger","matRippleDisabled","matRippleCentered"],[1,"mdc-switch__icons"],[1,"mdc-label",3,"click","for"],["viewBox","0 0 24 24","aria-hidden","true",1,"mdc-switch__icon","mdc-switch__icon--on"],["d","M19.69,5.23L8.96,15.96l-4.23-4.23L2.96,13.5l6,6L21.46,7L19.69,5.23z"],["viewBox","0 0 24 24","aria-hidden","true",1,"mdc-switch__icon","mdc-switch__icon--off"],["d","M20 13H4v-2h16v2z"]],template:function(t,n){if(t&1&&(Q(),o(0,"div",1)(1,"button",2,0),b("click",function(){return n._handleClick()}),I(3,"div",3)(4,"span",4),o(5,"span",5)(6,"span",6)(7,"span",7),I(8,"span",8),s(),o(9,"span",9),I(10,"span",10),s(),v(11,An,5,0,"span",11),s()()(),o(12,"label",12),b("click",function(d){return d.stopPropagation()}),G(13),s()()),t&2){let i=L(2);p("labelPosition",n.labelPosition),c(),f("mdc-switch--selected",n.checked)("mdc-switch--unselected",!n.checked)("mdc-switch--checked",n.checked)("mdc-switch--disabled",n.disabled)("mat-mdc-slide-toggle-disabled-interactive",n.disabledInteractive),p("tabIndex",n.disabled&&!n.disabledInteractive?-1:n.tabIndex)("disabled",n.disabled&&!n.disabledInteractive),x("id",n.buttonId)("name",n.name)("aria-label",n.ariaLabel)("aria-labelledby",n._getAriaLabelledBy())("aria-describedby",n.ariaDescribedby)("aria-required",n.required||null)("aria-checked",n.checked)("aria-disabled",n.disabled&&n.disabledInteractive?"true":null),c(9),p("matRippleTrigger",i)("matRippleDisabled",n.disableRipple||n.disabled)("matRippleCentered",!0),c(),y(n.hideIcon?-1:11),c(),p("for",n.buttonId),x("id",n._labelId)}},dependencies:[Z,Yt],styles:[`.mdc-switch {
  align-items: center;
  background: none;
  border: none;
  cursor: pointer;
  display: inline-flex;
  flex-shrink: 0;
  margin: 0;
  outline: none;
  overflow: visible;
  padding: 0;
  position: relative;
  width: var(--mat-slide-toggle-track-width, 52px);
}
.mdc-switch.mdc-switch--disabled {
  cursor: default;
  pointer-events: none;
}
.mdc-switch.mat-mdc-slide-toggle-disabled-interactive {
  pointer-events: auto;
}

.mdc-switch__track {
  overflow: hidden;
  position: relative;
  width: 100%;
  height: var(--mat-slide-toggle-track-height, 32px);
  border-radius: var(--mat-slide-toggle-track-shape, var(--mat-sys-corner-full));
}
.mdc-switch--disabled.mdc-switch .mdc-switch__track {
  opacity: var(--mat-slide-toggle-disabled-track-opacity, 0.12);
}
.mdc-switch__track::before, .mdc-switch__track::after {
  border: 1px solid transparent;
  border-radius: inherit;
  box-sizing: border-box;
  content: "";
  height: 100%;
  left: 0;
  position: absolute;
  width: 100%;
  border-width: var(--mat-slide-toggle-track-outline-width, 2px);
  border-color: var(--mat-slide-toggle-track-outline-color, var(--mat-sys-outline));
}
.mdc-switch--selected .mdc-switch__track::before, .mdc-switch--selected .mdc-switch__track::after {
  border-width: var(--mat-slide-toggle-selected-track-outline-width, 2px);
  border-color: var(--mat-slide-toggle-selected-track-outline-color, transparent);
}
.mdc-switch--disabled .mdc-switch__track::before, .mdc-switch--disabled .mdc-switch__track::after {
  border-width: var(--mat-slide-toggle-disabled-unselected-track-outline-width, 2px);
  border-color: var(--mat-slide-toggle-disabled-unselected-track-outline-color, var(--mat-sys-on-surface));
}
@media (forced-colors: active) {
  .mdc-switch__track {
    border-color: currentColor;
  }
}
.mdc-switch__track::before {
  transition: transform 75ms 0ms cubic-bezier(0, 0, 0.2, 1);
  transform: translateX(0);
  background: var(--mat-slide-toggle-unselected-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch--selected .mdc-switch__track::before {
  transition: transform 75ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  transform: translateX(100%);
}
[dir=rtl] .mdc-switch--selected .mdc-switch--selected .mdc-switch__track::before {
  transform: translateX(-100%);
}
.mdc-switch--selected .mdc-switch__track::before {
  opacity: var(--mat-slide-toggle-hidden-track-opacity, 0);
  transition: var(--mat-slide-toggle-hidden-track-transition, opacity 75ms);
}
.mdc-switch--unselected .mdc-switch__track::before {
  opacity: var(--mat-slide-toggle-visible-track-opacity, 1);
  transition: var(--mat-slide-toggle-visible-track-transition, opacity 75ms);
}
.mdc-switch:enabled:hover:not(:focus):not(:active) .mdc-switch__track::before {
  background: var(--mat-slide-toggle-unselected-hover-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch:enabled:focus:not(:active) .mdc-switch__track::before {
  background: var(--mat-slide-toggle-unselected-focus-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch:enabled:active .mdc-switch__track::before {
  background: var(--mat-slide-toggle-unselected-pressed-track-color, var(--mat-sys-surface-variant));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:hover:not(:focus):not(:active) .mdc-switch__track::before, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:focus:not(:active) .mdc-switch__track::before, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:active .mdc-switch__track::before, .mdc-switch.mdc-switch--disabled .mdc-switch__track::before {
  background: var(--mat-slide-toggle-disabled-unselected-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch__track::after {
  transform: translateX(-100%);
  background: var(--mat-slide-toggle-selected-track-color, var(--mat-sys-primary));
}
[dir=rtl] .mdc-switch__track::after {
  transform: translateX(100%);
}
.mdc-switch--selected .mdc-switch__track::after {
  transform: translateX(0);
}
.mdc-switch--selected .mdc-switch__track::after {
  opacity: var(--mat-slide-toggle-visible-track-opacity, 1);
  transition: var(--mat-slide-toggle-visible-track-transition, opacity 75ms);
}
.mdc-switch--unselected .mdc-switch__track::after {
  opacity: var(--mat-slide-toggle-hidden-track-opacity, 0);
  transition: var(--mat-slide-toggle-hidden-track-transition, opacity 75ms);
}
.mdc-switch:enabled:hover:not(:focus):not(:active) .mdc-switch__track::after {
  background: var(--mat-slide-toggle-selected-hover-track-color, var(--mat-sys-primary));
}
.mdc-switch:enabled:focus:not(:active) .mdc-switch__track::after {
  background: var(--mat-slide-toggle-selected-focus-track-color, var(--mat-sys-primary));
}
.mdc-switch:enabled:active .mdc-switch__track::after {
  background: var(--mat-slide-toggle-selected-pressed-track-color, var(--mat-sys-primary));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:hover:not(:focus):not(:active) .mdc-switch__track::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:focus:not(:active) .mdc-switch__track::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:active .mdc-switch__track::after, .mdc-switch.mdc-switch--disabled .mdc-switch__track::after {
  background: var(--mat-slide-toggle-disabled-selected-track-color, var(--mat-sys-on-surface));
}

.mdc-switch__handle-track {
  height: 100%;
  pointer-events: none;
  position: absolute;
  top: 0;
  transition: transform 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
  left: 0;
  right: auto;
  transform: translateX(0);
  width: calc(100% - var(--mat-slide-toggle-handle-width));
}
[dir=rtl] .mdc-switch__handle-track {
  left: auto;
  right: 0;
}
.mdc-switch--selected .mdc-switch__handle-track {
  transform: translateX(100%);
}
[dir=rtl] .mdc-switch--selected .mdc-switch__handle-track {
  transform: translateX(-100%);
}

.mdc-switch__handle {
  display: flex;
  pointer-events: auto;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  left: 0;
  right: auto;
  transition: width 75ms cubic-bezier(0.4, 0, 0.2, 1), height 75ms cubic-bezier(0.4, 0, 0.2, 1), margin 75ms cubic-bezier(0.4, 0, 0.2, 1);
  width: var(--mat-slide-toggle-handle-width);
  height: var(--mat-slide-toggle-handle-height);
  border-radius: var(--mat-slide-toggle-handle-shape, var(--mat-sys-corner-full));
}
[dir=rtl] .mdc-switch__handle {
  left: auto;
  right: 0;
}
.mat-mdc-slide-toggle .mdc-switch--unselected .mdc-switch__handle {
  width: var(--mat-slide-toggle-unselected-handle-size, 16px);
  height: var(--mat-slide-toggle-unselected-handle-size, 16px);
  margin: var(--mat-slide-toggle-unselected-handle-horizontal-margin, 0 8px);
}
.mat-mdc-slide-toggle .mdc-switch--unselected .mdc-switch__handle:has(.mdc-switch__icons) {
  margin: var(--mat-slide-toggle-unselected-with-icon-handle-horizontal-margin, 0 4px);
}
.mat-mdc-slide-toggle .mdc-switch--selected .mdc-switch__handle {
  width: var(--mat-slide-toggle-selected-handle-size, 24px);
  height: var(--mat-slide-toggle-selected-handle-size, 24px);
  margin: var(--mat-slide-toggle-selected-handle-horizontal-margin, 0 24px);
}
.mat-mdc-slide-toggle .mdc-switch--selected .mdc-switch__handle:has(.mdc-switch__icons) {
  margin: var(--mat-slide-toggle-selected-with-icon-handle-horizontal-margin, 0 24px);
}
.mat-mdc-slide-toggle .mdc-switch__handle:has(.mdc-switch__icons) {
  width: var(--mat-slide-toggle-with-icon-handle-size, 24px);
  height: var(--mat-slide-toggle-with-icon-handle-size, 24px);
}
.mat-mdc-slide-toggle .mdc-switch:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  width: var(--mat-slide-toggle-pressed-handle-size, 28px);
  height: var(--mat-slide-toggle-pressed-handle-size, 28px);
}
.mat-mdc-slide-toggle .mdc-switch--selected:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  margin: var(--mat-slide-toggle-selected-pressed-handle-horizontal-margin, 0 22px);
}
.mat-mdc-slide-toggle .mdc-switch--unselected:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  margin: var(--mat-slide-toggle-unselected-pressed-handle-horizontal-margin, 0 2px);
}
.mdc-switch--disabled.mdc-switch--selected .mdc-switch__handle::after {
  opacity: var(--mat-slide-toggle-disabled-selected-handle-opacity, 1);
}
.mdc-switch--disabled.mdc-switch--unselected .mdc-switch__handle::after {
  opacity: var(--mat-slide-toggle-disabled-unselected-handle-opacity, 0.38);
}
.mdc-switch__handle::before, .mdc-switch__handle::after {
  border: 1px solid transparent;
  border-radius: inherit;
  box-sizing: border-box;
  content: "";
  width: 100%;
  height: 100%;
  left: 0;
  position: absolute;
  top: 0;
  transition: background-color 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1), border-color 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
  z-index: -1;
}
@media (forced-colors: active) {
  .mdc-switch__handle::before, .mdc-switch__handle::after {
    border-color: currentColor;
  }
}
.mdc-switch--selected:enabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-handle-color, var(--mat-sys-on-primary));
}
.mdc-switch--selected:enabled:hover:not(:focus):not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-hover-handle-color, var(--mat-sys-primary-container));
}
.mdc-switch--selected:enabled:focus:not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-focus-handle-color, var(--mat-sys-primary-container));
}
.mdc-switch--selected:enabled:active .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-pressed-handle-color, var(--mat-sys-primary-container));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--selected:hover:not(:focus):not(:active) .mdc-switch__handle::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--selected:focus:not(:active) .mdc-switch__handle::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--selected:active .mdc-switch__handle::after, .mdc-switch--selected.mdc-switch--disabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-disabled-selected-handle-color, var(--mat-sys-surface));
}
.mdc-switch--unselected:enabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-handle-color, var(--mat-sys-outline));
}
.mdc-switch--unselected:enabled:hover:not(:focus):not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-hover-handle-color, var(--mat-sys-on-surface-variant));
}
.mdc-switch--unselected:enabled:focus:not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-focus-handle-color, var(--mat-sys-on-surface-variant));
}
.mdc-switch--unselected:enabled:active .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-pressed-handle-color, var(--mat-sys-on-surface-variant));
}
.mdc-switch--unselected.mdc-switch--disabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-disabled-unselected-handle-color, var(--mat-sys-on-surface));
}
.mdc-switch__handle::before {
  background: var(--mat-slide-toggle-handle-surface-color);
}

.mdc-switch__shadow {
  border-radius: inherit;
  bottom: 0;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
}
.mdc-switch:enabled .mdc-switch__shadow {
  box-shadow: var(--mat-slide-toggle-handle-elevation-shadow);
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:hover:not(:focus):not(:active) .mdc-switch__shadow, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:focus:not(:active) .mdc-switch__shadow, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:active .mdc-switch__shadow, .mdc-switch.mdc-switch--disabled .mdc-switch__shadow {
  box-shadow: var(--mat-slide-toggle-disabled-handle-elevation-shadow);
}

.mdc-switch__ripple {
  left: 50%;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  z-index: -1;
  width: var(--mat-slide-toggle-state-layer-size, 40px);
  height: var(--mat-slide-toggle-state-layer-size, 40px);
}
.mdc-switch__ripple::after {
  content: "";
  opacity: 0;
}
.mdc-switch--disabled .mdc-switch__ripple::after {
  display: none;
}
.mat-mdc-slide-toggle-disabled-interactive .mdc-switch__ripple::after {
  display: block;
}
.mdc-switch:hover .mdc-switch__ripple::after {
  transition: 75ms opacity cubic-bezier(0, 0, 0.2, 1);
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:enabled:focus .mdc-switch__ripple::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:enabled:active .mdc-switch__ripple::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:enabled:hover:not(:focus) .mdc-switch__ripple::after, .mdc-switch--unselected:enabled:hover:not(:focus) .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-slide-toggle-unselected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mdc-switch--unselected:enabled:focus .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-slide-toggle-unselected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mdc-switch--unselected:enabled:active .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-unselected-pressed-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-slide-toggle-unselected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  transition: opacity 75ms linear;
}
.mdc-switch--selected:enabled:hover:not(:focus) .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-selected-hover-state-layer-color, var(--mat-sys-primary));
  opacity: var(--mat-slide-toggle-selected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mdc-switch--selected:enabled:focus .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-selected-focus-state-layer-color, var(--mat-sys-primary));
  opacity: var(--mat-slide-toggle-selected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mdc-switch--selected:enabled:active .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-selected-pressed-state-layer-color, var(--mat-sys-primary));
  opacity: var(--mat-slide-toggle-selected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  transition: opacity 75ms linear;
}

.mdc-switch__icons {
  position: relative;
  height: 100%;
  width: 100%;
  z-index: 1;
  transform: translateZ(0);
}
.mdc-switch--disabled.mdc-switch--unselected .mdc-switch__icons {
  opacity: var(--mat-slide-toggle-disabled-unselected-icon-opacity, 0.38);
}
.mdc-switch--disabled.mdc-switch--selected .mdc-switch__icons {
  opacity: var(--mat-slide-toggle-disabled-selected-icon-opacity, 0.38);
}

.mdc-switch__icon {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  opacity: 0;
  transition: opacity 30ms 0ms cubic-bezier(0.4, 0, 1, 1);
}
.mdc-switch--unselected .mdc-switch__icon {
  width: var(--mat-slide-toggle-unselected-icon-size, 16px);
  height: var(--mat-slide-toggle-unselected-icon-size, 16px);
  fill: var(--mat-slide-toggle-unselected-icon-color, var(--mat-sys-surface-variant));
}
.mdc-switch--unselected.mdc-switch--disabled .mdc-switch__icon {
  fill: var(--mat-slide-toggle-disabled-unselected-icon-color, var(--mat-sys-surface-variant));
}
.mdc-switch--selected .mdc-switch__icon {
  width: var(--mat-slide-toggle-selected-icon-size, 16px);
  height: var(--mat-slide-toggle-selected-icon-size, 16px);
  fill: var(--mat-slide-toggle-selected-icon-color, var(--mat-sys-on-primary-container));
}
.mdc-switch--selected.mdc-switch--disabled .mdc-switch__icon {
  fill: var(--mat-slide-toggle-disabled-selected-icon-color, var(--mat-sys-on-surface));
}

.mdc-switch--selected .mdc-switch__icon--on,
.mdc-switch--unselected .mdc-switch__icon--off {
  opacity: 1;
  transition: opacity 45ms 30ms cubic-bezier(0, 0, 0.2, 1);
}

.mat-mdc-slide-toggle {
  -webkit-user-select: none;
  user-select: none;
  display: inline-block;
  -webkit-tap-highlight-color: transparent;
  outline: 0;
}
.mat-mdc-slide-toggle .mat-mdc-slide-toggle-ripple,
.mat-mdc-slide-toggle .mdc-switch__ripple::after {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
}
.mat-mdc-slide-toggle .mat-mdc-slide-toggle-ripple:not(:empty),
.mat-mdc-slide-toggle .mdc-switch__ripple::after:not(:empty) {
  transform: translateZ(0);
}
.mat-mdc-slide-toggle.mat-mdc-slide-toggle-focused .mat-focus-indicator::before {
  content: "";
}
.mat-mdc-slide-toggle .mat-internal-form-field {
  color: var(--mat-slide-toggle-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-slide-toggle-label-text-font, var(--mat-sys-body-medium-font));
  line-height: var(--mat-slide-toggle-label-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-slide-toggle-label-text-size, var(--mat-sys-body-medium-size));
  letter-spacing: var(--mat-slide-toggle-label-text-tracking, var(--mat-sys-body-medium-tracking));
  font-weight: var(--mat-slide-toggle-label-text-weight, var(--mat-sys-body-medium-weight));
}
.mat-mdc-slide-toggle .mat-ripple-element {
  opacity: 0.12;
}
.mat-mdc-slide-toggle .mat-focus-indicator::before {
  border-radius: 50%;
}
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle-track,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__icon,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle::before,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle::after,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__track::before,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__track::after {
  transition: none;
}
.mat-mdc-slide-toggle .mdc-switch:enabled + .mdc-label {
  cursor: pointer;
}
.mat-mdc-slide-toggle .mdc-switch--disabled + label {
  color: var(--mat-slide-toggle-disabled-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-slide-toggle label:empty {
  display: none;
}

.mat-mdc-slide-toggle-touch-target {
  position: absolute;
  top: 50%;
  left: 50%;
  height: var(--mat-slide-toggle-touch-target-size, 48px);
  width: 100%;
  transform: translate(-50%, -50%);
  display: var(--mat-slide-toggle-touch-target-display, block);
}
[dir=rtl] .mat-mdc-slide-toggle-touch-target {
  left: auto;
  right: 50%;
  transform: translate(50%, -50%);
}
`],encapsulation:2,changeDetection:0})}return a})(),gn=(()=>{class a{static \u0275fac=function(t){return new(t||a)};static \u0275mod=K({type:a});static \u0275inj=X({imports:[je,te]})}return a})();var zn=["button"],jn=["*"];function Vn(a,r){if(a&1&&(o(0,"div",2),I(1,"mat-pseudo-checkbox",6),s()),a&2){let e=u();c(),p("disabled",e.disabled)}}var pn=new E("MAT_BUTTON_TOGGLE_DEFAULT_OPTIONS",{providedIn:"root",factory:()=>({hideSingleSelectionIndicator:!1,hideMultipleSelectionIndicator:!1,disabledInteractive:!1})}),hn=new E("MatButtonToggleGroup"),Nn={provide:Ce,useExisting:he(()=>Qe),multi:!0},Me=class{source;value;constructor(r,e){this.source=r,this.value=e}},Qe=(()=>{class a{_changeDetector=m(D);_dir=m(me,{optional:!0});_multiple=!1;_disabled=!1;_disabledInteractive=!1;_selectionModel;_rawValue;_controlValueAccessorChangeFn=()=>{};_onTouched=()=>{};_buttonToggles;appearance;get name(){return this._name}set name(e){this._name=e,this._markButtonsForCheck()}_name=m(U).getId("mat-button-toggle-group-");vertical=!1;get value(){let e=this._selectionModel?this._selectionModel.selected:[];return this.multiple?e.map(t=>t.value):e[0]?e[0].value:void 0}set value(e){this._setSelectionByValue(e),this.valueChange.emit(this.value)}valueChange=new T;get selected(){let e=this._selectionModel?this._selectionModel.selected:[];return this.multiple?e:e[0]||null}get multiple(){return this._multiple}set multiple(e){this._multiple=e,this._markButtonsForCheck()}get disabled(){return this._disabled}set disabled(e){this._disabled=e,this._markButtonsForCheck()}get disabledInteractive(){return this._disabledInteractive}set disabledInteractive(e){this._disabledInteractive=e,this._markButtonsForCheck()}get dir(){return this._dir&&this._dir.value==="rtl"?"rtl":"ltr"}change=new T;get hideSingleSelectionIndicator(){return this._hideSingleSelectionIndicator}set hideSingleSelectionIndicator(e){this._hideSingleSelectionIndicator=e,this._markButtonsForCheck()}_hideSingleSelectionIndicator;get hideMultipleSelectionIndicator(){return this._hideMultipleSelectionIndicator}set hideMultipleSelectionIndicator(e){this._hideMultipleSelectionIndicator=e,this._markButtonsForCheck()}_hideMultipleSelectionIndicator;constructor(){let e=m(pn,{optional:!0});this.appearance=e&&e.appearance?e.appearance:"standard",this._hideSingleSelectionIndicator=e?.hideSingleSelectionIndicator??!1,this._hideMultipleSelectionIndicator=e?.hideMultipleSelectionIndicator??!1}ngOnInit(){this._selectionModel=new qt(this.multiple,void 0,!1)}ngAfterContentInit(){this._selectionModel.select(...this._buttonToggles.filter(e=>e.checked)),this.multiple||this._initializeTabIndex()}writeValue(e){this.value=e,this._changeDetector.markForCheck()}registerOnChange(e){this._controlValueAccessorChangeFn=e}registerOnTouched(e){this._onTouched=e}setDisabledState(e){this.disabled=e}_keydown(e){if(this.multiple||this.disabled||ke(e))return;let n=e.target.id,i=this._buttonToggles.toArray().findIndex(M=>M.buttonId===n),d=null;switch(e.keyCode){case 32:case 13:d=this._buttonToggles.get(i)||null;break;case 38:d=this._getNextButton(i,-1);break;case 37:d=this._getNextButton(i,this.dir==="ltr"?-1:1);break;case 40:d=this._getNextButton(i,1);break;case 39:d=this._getNextButton(i,this.dir==="ltr"?1:-1);break;default:return}d&&(e.preventDefault(),d._onButtonClick(),d.focus())}_emitChangeEvent(e){let t=new Me(e,this.value);this._rawValue=t.value,this._controlValueAccessorChangeFn(t.value),this.change.emit(t)}_syncButtonToggle(e,t,n=!1,i=!1){!this.multiple&&this.selected&&!e.checked&&(this.selected.checked=!1),this._selectionModel?t?this._selectionModel.select(e):this._selectionModel.deselect(e):i=!0,i?Promise.resolve().then(()=>this._updateModelValue(e,n)):this._updateModelValue(e,n)}_isSelected(e){return this._selectionModel&&this._selectionModel.isSelected(e)}_isPrechecked(e){return typeof this._rawValue>"u"?!1:this.multiple&&Array.isArray(this._rawValue)?this._rawValue.some(t=>e.value!=null&&t===e.value):e.value===this._rawValue}_initializeTabIndex(){if(this._buttonToggles.forEach(e=>{e.tabIndex=-1}),this.selected)this.selected.tabIndex=0;else for(let e=0;e<this._buttonToggles.length;e++){let t=this._buttonToggles.get(e);if(!t.disabled){t.tabIndex=0;break}}}_getNextButton(e,t){let n=this._buttonToggles;for(let i=1;i<=n.length;i++){let d=(e+t*i+n.length)%n.length,M=n.get(d);if(M&&!M.disabled)return M}return null}_setSelectionByValue(e){if(this._rawValue=e,!this._buttonToggles)return;let t=this._buttonToggles.toArray();if(this.multiple&&e?(Array.isArray(e),this._clearSelection(),e.forEach(n=>this._selectValue(n,t))):(this._clearSelection(),this._selectValue(e,t)),!this.multiple&&t.every(n=>n.tabIndex===-1)){for(let n of t)if(!n.disabled){n.tabIndex=0;break}}}_clearSelection(){this._selectionModel.clear(),this._buttonToggles.forEach(e=>{e.checked=!1,this.multiple||(e.tabIndex=-1)})}_selectValue(e,t){for(let n of t)if(n.value===e){n.checked=!0,this._selectionModel.select(n),this.multiple||(n.tabIndex=0);break}}_updateModelValue(e,t){t&&this._emitChangeEvent(e),this.valueChange.emit(this.value)}_markButtonsForCheck(){this._buttonToggles?.forEach(e=>e._markForCheck())}static \u0275fac=function(t){return new(t||a)};static \u0275dir=F({type:a,selectors:[["mat-button-toggle-group"]],contentQueries:function(t,n,i){if(t&1&&Y(i,Ie,5),t&2){let d;k(d=C())&&(n._buttonToggles=d)}},hostAttrs:[1,"mat-button-toggle-group"],hostVars:6,hostBindings:function(t,n){t&1&&b("keydown",function(d){return n._keydown(d)}),t&2&&(x("role",n.multiple?"group":"radiogroup")("aria-disabled",n.disabled),f("mat-button-toggle-vertical",n.vertical)("mat-button-toggle-group-appearance-standard",n.appearance==="standard"))},inputs:{appearance:"appearance",name:"name",vertical:[2,"vertical","vertical",g],value:"value",multiple:[2,"multiple","multiple",g],disabled:[2,"disabled","disabled",g],disabledInteractive:[2,"disabledInteractive","disabledInteractive",g],hideSingleSelectionIndicator:[2,"hideSingleSelectionIndicator","hideSingleSelectionIndicator",g],hideMultipleSelectionIndicator:[2,"hideMultipleSelectionIndicator","hideMultipleSelectionIndicator",g]},outputs:{valueChange:"valueChange",change:"change"},exportAs:["matButtonToggleGroup"],features:[V([Nn,{provide:hn,useExisting:a}])]})}return a})(),Ie=(()=>{class a{_changeDetectorRef=m(D);_elementRef=m(R);_focusMonitor=m(ue);_idGenerator=m(U);_animationDisabled=q();_checked=!1;ariaLabel;ariaLabelledby=null;_buttonElement;buttonToggleGroup;get buttonId(){return`${this.id}-button`}id;name;value;get tabIndex(){return this._tabIndex()}set tabIndex(e){this._tabIndex.set(e)}_tabIndex;disableRipple=!1;get appearance(){return this.buttonToggleGroup?this.buttonToggleGroup.appearance:this._appearance}set appearance(e){this._appearance=e}_appearance;get checked(){return this.buttonToggleGroup?this.buttonToggleGroup._isSelected(this):this._checked}set checked(e){e!==this._checked&&(this._checked=e,this.buttonToggleGroup&&this.buttonToggleGroup._syncButtonToggle(this,this._checked),this._changeDetectorRef.markForCheck())}get disabled(){return this._disabled||this.buttonToggleGroup&&this.buttonToggleGroup.disabled}set disabled(e){this._disabled=e}_disabled=!1;get disabledInteractive(){return this._disabledInteractive||this.buttonToggleGroup!==null&&this.buttonToggleGroup.disabledInteractive}set disabledInteractive(e){this._disabledInteractive=e}_disabledInteractive;change=new T;constructor(){m(ne).load(ae);let e=m(hn,{optional:!0}),t=m(new de("tabindex"),{optional:!0})||"",n=m(pn,{optional:!0});this._tabIndex=Pe(parseInt(t)||0),this.buttonToggleGroup=e,this._appearance=n&&n.appearance?n.appearance:"standard",this._disabledInteractive=n?.disabledInteractive??!1}ngOnInit(){let e=this.buttonToggleGroup;this.id=this.id||this._idGenerator.getId("mat-button-toggle-"),e&&(e._isPrechecked(this)?this.checked=!0:e._isSelected(this)!==this._checked&&e._syncButtonToggle(this,this._checked))}ngAfterViewInit(){this._animationDisabled||this._elementRef.nativeElement.classList.add("mat-button-toggle-animations-enabled"),this._focusMonitor.monitor(this._elementRef,!0)}ngOnDestroy(){let e=this.buttonToggleGroup;this._focusMonitor.stopMonitoring(this._elementRef),e&&e._isSelected(this)&&e._syncButtonToggle(this,!1,!1,!0)}focus(e){this._buttonElement.nativeElement.focus(e)}_onButtonClick(){if(this.disabled)return;let e=this.isSingleSelector()?!0:!this._checked;if(e!==this._checked&&(this._checked=e,this.buttonToggleGroup&&(this.buttonToggleGroup._syncButtonToggle(this,this._checked,!0),this.buttonToggleGroup._onTouched())),this.isSingleSelector()){let t=this.buttonToggleGroup._buttonToggles.find(n=>n.tabIndex===0);t&&(t.tabIndex=-1),this.tabIndex=0}this.change.emit(new Me(this,this.value))}_markForCheck(){this._changeDetectorRef.markForCheck()}_getButtonName(){return this.isSingleSelector()?this.buttonToggleGroup.name:this.name||null}isSingleSelector(){return this.buttonToggleGroup&&!this.buttonToggleGroup.multiple}static \u0275fac=function(t){return new(t||a)};static \u0275cmp=P({type:a,selectors:[["mat-button-toggle"]],viewQuery:function(t,n){if(t&1&&j(zn,5),t&2){let i;k(i=C())&&(n._buttonElement=i.first)}},hostAttrs:["role","presentation",1,"mat-button-toggle"],hostVars:14,hostBindings:function(t,n){t&1&&b("focus",function(){return n.focus()}),t&2&&(x("aria-label",null)("aria-labelledby",null)("id",n.id)("name",null),f("mat-button-toggle-standalone",!n.buttonToggleGroup)("mat-button-toggle-checked",n.checked)("mat-button-toggle-disabled",n.disabled)("mat-button-toggle-disabled-interactive",n.disabledInteractive)("mat-button-toggle-appearance-standard",n.appearance==="standard"))},inputs:{ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],id:"id",name:"name",value:"value",tabIndex:"tabIndex",disableRipple:[2,"disableRipple","disableRipple",g],appearance:"appearance",checked:[2,"checked","checked",g],disabled:[2,"disabled","disabled",g],disabledInteractive:[2,"disabledInteractive","disabledInteractive",g]},outputs:{change:"change"},exportAs:["matButtonToggle"],ngContentSelectors:jn,decls:7,vars:13,consts:[["button",""],["type","button",1,"mat-button-toggle-button","mat-focus-indicator",3,"click","id","disabled"],[1,"mat-button-toggle-checkbox-wrapper"],[1,"mat-button-toggle-label-content"],[1,"mat-button-toggle-focus-overlay"],["matRipple","",1,"mat-button-toggle-ripple",3,"matRippleTrigger","matRippleDisabled"],["state","checked","aria-hidden","true","appearance","minimal",3,"disabled"]],template:function(t,n){if(t&1&&(Q(),o(0,"button",1,0),b("click",function(){return n._onButtonClick()}),v(2,Vn,2,1,"div",2),o(3,"span",3),G(4),s()(),I(5,"span",4)(6,"span",5)),t&2){let i=L(1);p("id",n.buttonId)("disabled",n.disabled&&!n.disabledInteractive||null),x("role",n.isSingleSelector()?"radio":"button")("tabindex",n.disabled&&!n.disabledInteractive?-1:n.tabIndex)("aria-pressed",n.isSingleSelector()?null:n.checked)("aria-checked",n.isSingleSelector()?n.checked:null)("name",n._getButtonName())("aria-label",n.ariaLabel)("aria-labelledby",n.ariaLabelledby)("aria-disabled",n.disabled&&n.disabledInteractive?"true":null),c(2),y(n.buttonToggleGroup&&(!n.buttonToggleGroup.multiple&&!n.buttonToggleGroup.hideSingleSelectionIndicator||n.buttonToggleGroup.multiple&&!n.buttonToggleGroup.hideMultipleSelectionIndicator)?2:-1),c(4),p("matRippleTrigger",i)("matRippleDisabled",n.disableRipple||n.disabled)}},dependencies:[Z,Zt],styles:[`.mat-button-toggle-standalone,
.mat-button-toggle-group {
  position: relative;
  display: inline-flex;
  flex-direction: row;
  white-space: nowrap;
  overflow: hidden;
  -webkit-tap-highlight-color: transparent;
  border-radius: var(--mat-button-toggle-legacy-shape);
  transform: translateZ(0);
}
.mat-button-toggle-standalone:not([class*=mat-elevation-z]),
.mat-button-toggle-group:not([class*=mat-elevation-z]) {
  box-shadow: 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12);
}
@media (forced-colors: active) {
  .mat-button-toggle-standalone,
  .mat-button-toggle-group {
    outline: solid 1px;
  }
}

.mat-button-toggle-standalone.mat-button-toggle-appearance-standard,
.mat-button-toggle-group-appearance-standard {
  border-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
  border: solid 1px var(--mat-button-toggle-divider-color, var(--mat-sys-outline));
}
.mat-button-toggle-standalone.mat-button-toggle-appearance-standard .mat-pseudo-checkbox,
.mat-button-toggle-group-appearance-standard .mat-pseudo-checkbox {
  --mat-pseudo-checkbox-minimal-selected-checkmark-color: var(--mat-button-toggle-selected-state-text-color, var(--mat-sys-on-secondary-container));
}
.mat-button-toggle-standalone.mat-button-toggle-appearance-standard:not([class*=mat-elevation-z]),
.mat-button-toggle-group-appearance-standard:not([class*=mat-elevation-z]) {
  box-shadow: none;
}
@media (forced-colors: active) {
  .mat-button-toggle-standalone.mat-button-toggle-appearance-standard,
  .mat-button-toggle-group-appearance-standard {
    outline: 0;
  }
}

.mat-button-toggle-vertical {
  flex-direction: column;
}
.mat-button-toggle-vertical .mat-button-toggle-label-content {
  display: block;
}

.mat-button-toggle {
  white-space: nowrap;
  position: relative;
  color: var(--mat-button-toggle-legacy-text-color);
  font-family: var(--mat-button-toggle-legacy-label-text-font);
  font-size: var(--mat-button-toggle-legacy-label-text-size);
  line-height: var(--mat-button-toggle-legacy-label-text-line-height);
  font-weight: var(--mat-button-toggle-legacy-label-text-weight);
  letter-spacing: var(--mat-button-toggle-legacy-label-text-tracking);
  --mat-pseudo-checkbox-minimal-selected-checkmark-color: var(--mat-button-toggle-legacy-selected-state-text-color);
}
.mat-button-toggle.cdk-keyboard-focused .mat-button-toggle-focus-overlay {
  opacity: var(--mat-button-toggle-legacy-focus-state-layer-opacity);
}
.mat-button-toggle .mat-icon svg {
  vertical-align: top;
}

.mat-button-toggle-checkbox-wrapper {
  display: inline-block;
  justify-content: flex-start;
  align-items: center;
  width: 0;
  height: 18px;
  line-height: 18px;
  overflow: hidden;
  box-sizing: border-box;
  position: absolute;
  top: 50%;
  left: 16px;
  transform: translate3d(0, -50%, 0);
}
[dir=rtl] .mat-button-toggle-checkbox-wrapper {
  left: auto;
  right: 16px;
}
.mat-button-toggle-appearance-standard .mat-button-toggle-checkbox-wrapper {
  left: 12px;
}
[dir=rtl] .mat-button-toggle-appearance-standard .mat-button-toggle-checkbox-wrapper {
  left: auto;
  right: 12px;
}
.mat-button-toggle-checked .mat-button-toggle-checkbox-wrapper {
  width: 18px;
}
.mat-button-toggle-animations-enabled .mat-button-toggle-checkbox-wrapper {
  transition: width 150ms 45ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-button-toggle-vertical .mat-button-toggle-checkbox-wrapper {
  transition: none;
}

.mat-button-toggle-checked {
  color: var(--mat-button-toggle-legacy-selected-state-text-color);
  background-color: var(--mat-button-toggle-legacy-selected-state-background-color);
}

.mat-button-toggle-disabled {
  pointer-events: none;
  color: var(--mat-button-toggle-legacy-disabled-state-text-color);
  background-color: var(--mat-button-toggle-legacy-disabled-state-background-color);
  --mat-pseudo-checkbox-minimal-disabled-selected-checkmark-color: var(--mat-button-toggle-legacy-disabled-state-text-color);
}
.mat-button-toggle-disabled.mat-button-toggle-checked {
  background-color: var(--mat-button-toggle-legacy-disabled-selected-state-background-color);
}

.mat-button-toggle-disabled-interactive {
  pointer-events: auto;
}

.mat-button-toggle-appearance-standard {
  color: var(--mat-button-toggle-text-color, var(--mat-sys-on-surface));
  background-color: var(--mat-button-toggle-background-color, transparent);
  font-family: var(--mat-button-toggle-label-text-font, var(--mat-sys-label-large-font));
  font-size: var(--mat-button-toggle-label-text-size, var(--mat-sys-label-large-size));
  line-height: var(--mat-button-toggle-label-text-line-height, var(--mat-sys-label-large-line-height));
  font-weight: var(--mat-button-toggle-label-text-weight, var(--mat-sys-label-large-weight));
  letter-spacing: var(--mat-button-toggle-label-text-tracking, var(--mat-sys-label-large-tracking));
}
.mat-button-toggle-group-appearance-standard .mat-button-toggle-appearance-standard + .mat-button-toggle-appearance-standard {
  border-left: solid 1px var(--mat-button-toggle-divider-color, var(--mat-sys-outline));
}
[dir=rtl] .mat-button-toggle-group-appearance-standard .mat-button-toggle-appearance-standard + .mat-button-toggle-appearance-standard {
  border-left: none;
  border-right: solid 1px var(--mat-button-toggle-divider-color, var(--mat-sys-outline));
}
.mat-button-toggle-group-appearance-standard.mat-button-toggle-vertical .mat-button-toggle-appearance-standard + .mat-button-toggle-appearance-standard {
  border-left: none;
  border-right: none;
  border-top: solid 1px var(--mat-button-toggle-divider-color, var(--mat-sys-outline));
}
.mat-button-toggle-appearance-standard.mat-button-toggle-checked {
  color: var(--mat-button-toggle-selected-state-text-color, var(--mat-sys-on-secondary-container));
  background-color: var(--mat-button-toggle-selected-state-background-color, var(--mat-sys-secondary-container));
}
.mat-button-toggle-appearance-standard.mat-button-toggle-disabled {
  color: var(--mat-button-toggle-disabled-state-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  background-color: var(--mat-button-toggle-disabled-state-background-color, transparent);
}
.mat-button-toggle-appearance-standard.mat-button-toggle-disabled .mat-pseudo-checkbox {
  --mat-pseudo-checkbox-minimal-disabled-selected-checkmark-color: var(--mat-button-toggle-disabled-selected-state-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-button-toggle-appearance-standard.mat-button-toggle-disabled.mat-button-toggle-checked {
  color: var(--mat-button-toggle-disabled-selected-state-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  background-color: var(--mat-button-toggle-disabled-selected-state-background-color, color-mix(in srgb, var(--mat-sys-on-surface) 12%, transparent));
}
.mat-button-toggle-appearance-standard .mat-button-toggle-focus-overlay {
  background-color: var(--mat-button-toggle-state-layer-color, var(--mat-sys-on-surface));
}
.mat-button-toggle-appearance-standard:hover .mat-button-toggle-focus-overlay {
  opacity: var(--mat-button-toggle-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mat-button-toggle-appearance-standard.cdk-keyboard-focused .mat-button-toggle-focus-overlay {
  opacity: var(--mat-button-toggle-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
@media (hover: none) {
  .mat-button-toggle-appearance-standard:hover .mat-button-toggle-focus-overlay {
    display: none;
  }
}

.mat-button-toggle-label-content {
  -webkit-user-select: none;
  user-select: none;
  display: inline-block;
  padding: 0 16px;
  line-height: var(--mat-button-toggle-legacy-height);
  position: relative;
}
.mat-button-toggle-appearance-standard .mat-button-toggle-label-content {
  padding: 0 12px;
  line-height: var(--mat-button-toggle-height, 40px);
}

.mat-button-toggle-label-content > * {
  vertical-align: middle;
}

.mat-button-toggle-focus-overlay {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: inherit;
  pointer-events: none;
  opacity: 0;
  background-color: var(--mat-button-toggle-legacy-state-layer-color);
}

@media (forced-colors: active) {
  .mat-button-toggle-checked .mat-button-toggle-focus-overlay {
    border-bottom: solid 500px;
    opacity: 0.5;
    height: 0;
  }
  .mat-button-toggle-checked:hover .mat-button-toggle-focus-overlay {
    opacity: 0.6;
  }
  .mat-button-toggle-checked.mat-button-toggle-appearance-standard .mat-button-toggle-focus-overlay {
    border-bottom: solid 500px;
  }
}
.mat-button-toggle .mat-button-toggle-ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}

.mat-button-toggle-button {
  border: 0;
  background: none;
  color: inherit;
  padding: 0;
  margin: 0;
  font: inherit;
  outline: none;
  width: 100%;
  cursor: pointer;
}
.mat-button-toggle-animations-enabled .mat-button-toggle-button {
  transition: padding 150ms 45ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-button-toggle-vertical .mat-button-toggle-button {
  transition: none;
}
.mat-button-toggle-disabled .mat-button-toggle-button {
  cursor: default;
}
.mat-button-toggle-button::-moz-focus-inner {
  border: 0;
}
.mat-button-toggle-checked .mat-button-toggle-button:has(.mat-button-toggle-checkbox-wrapper) {
  padding-left: 30px;
}
[dir=rtl] .mat-button-toggle-checked .mat-button-toggle-button:has(.mat-button-toggle-checkbox-wrapper) {
  padding-left: 0;
  padding-right: 30px;
}

.mat-button-toggle-standalone.mat-button-toggle-appearance-standard {
  --mat-focus-indicator-border-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
}

.mat-button-toggle-group-appearance-standard:not(.mat-button-toggle-vertical) .mat-button-toggle:last-of-type .mat-button-toggle-button::before {
  border-top-right-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
  border-bottom-right-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
}
.mat-button-toggle-group-appearance-standard:not(.mat-button-toggle-vertical) .mat-button-toggle:first-of-type .mat-button-toggle-button::before {
  border-top-left-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
  border-bottom-left-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
}

.mat-button-toggle-group-appearance-standard.mat-button-toggle-vertical .mat-button-toggle:last-of-type .mat-button-toggle-button::before {
  border-bottom-right-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
  border-bottom-left-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
}
.mat-button-toggle-group-appearance-standard.mat-button-toggle-vertical .mat-button-toggle:first-of-type .mat-button-toggle-button::before {
  border-top-right-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
  border-top-left-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
}
`],encapsulation:2,changeDetection:0})}return a})(),_n=(()=>{class a{static \u0275fac=function(t){return new(t||a)};static \u0275mod=K({type:a});static \u0275inj=X({imports:[Tt,Ie,te]})}return a})();var $e=["*"];function Gn(a,r){a&1&&G(0)}var qn=["tabListContainer"],Hn=["tabList"],Wn=["tabListInner"],$n=["nextPaginator"],Un=["previousPaginator"],Zn=["content"];function Xn(a,r){}var Kn=["tabBodyWrapper"],Yn=["tabHeader"];function Jn(a,r){}function ea(a,r){if(a&1&&z(0,Jn,0,0,"ng-template",12),a&2){let e=u().$implicit;p("cdkPortalOutlet",e.templateLabel)}}function ta(a,r){if(a&1&&l(0),a&2){let e=u().$implicit;w(e.textLabel)}}function na(a,r){if(a&1){let e=S();o(0,"div",7,2),b("click",function(){let n=h(e),i=n.$implicit,d=n.$index,M=u(),H=L(1);return _(M._handleClick(i,H,d))})("cdkFocusChange",function(n){let i=h(e).$index,d=u();return _(d._tabFocusChanged(n,i))}),I(2,"span",8)(3,"div",9),o(4,"span",10)(5,"span",11),v(6,ea,1,1,null,12)(7,ta,1,1),s()()()}if(a&2){let e=r.$implicit,t=r.$index,n=L(1),i=u();J(e.labelClass),f("mdc-tab--active",i.selectedIndex===t),p("id",i._getTabLabelId(e,t))("disabled",e.disabled)("fitInkBarToContent",i.fitInkBarToContent),x("tabIndex",i._getTabIndex(t))("aria-posinset",t+1)("aria-setsize",i._tabs.length)("aria-controls",i._getTabContentId(t))("aria-selected",i.selectedIndex===t)("aria-label",e.ariaLabel||null)("aria-labelledby",!e.ariaLabel&&e.ariaLabelledby?e.ariaLabelledby:null),c(3),p("matRippleTrigger",n)("matRippleDisabled",e.disabled||i.disableRipple),c(3),y(e.templateLabel?6:7)}}function aa(a,r){a&1&&G(0)}function ia(a,r){if(a&1){let e=S();o(0,"mat-tab-body",13),b("_onCentered",function(){h(e);let n=u();return _(n._removeTabBodyWrapperHeight())})("_onCentering",function(n){h(e);let i=u();return _(i._setTabBodyWrapperHeight(n))})("_beforeCentering",function(n){h(e);let i=u();return _(i._bodyCentered(n))}),s()}if(a&2){let e=r.$implicit,t=r.$index,n=u();J(e.bodyClass),p("id",n._getTabContentId(t))("content",e.content)("position",e.position)("animationDuration",n.animationDuration)("preserveContent",n.preserveContent),x("tabindex",n.contentTabIndex!=null&&n.selectedIndex===t?n.contentTabIndex:null)("aria-labelledby",n._getTabLabelId(e,t))("aria-hidden",n.selectedIndex!==t)}}var oa=new E("MatTabContent"),ra=(()=>{class a{template=m(ye);constructor(){}static \u0275fac=function(t){return new(t||a)};static \u0275dir=F({type:a,selectors:[["","matTabContent",""]],features:[V([{provide:oa,useExisting:a}])]})}return a})(),sa=new E("MatTabLabel"),xn=new E("MAT_TAB"),Ue=(()=>{class a extends Ut{_closestTab=m(xn,{optional:!0});static \u0275fac=(()=>{let e;return function(n){return(e||(e=fe(a)))(n||a)}})();static \u0275dir=F({type:a,selectors:[["","mat-tab-label",""],["","matTabLabel",""]],features:[V([{provide:sa,useExisting:a}]),re]})}return a})(),kn=new E("MAT_TAB_GROUP"),Ze=(()=>{class a{_viewContainerRef=m(lt);_closestTabGroup=m(kn,{optional:!0});disabled=!1;get templateLabel(){return this._templateLabel}set templateLabel(e){this._setTemplateLabelInput(e)}_templateLabel;_explicitContent=void 0;_implicitContent;textLabel="";ariaLabel;ariaLabelledby;labelClass;bodyClass;id=null;_contentPortal=null;get content(){return this._contentPortal}_stateChanges=new be;position=null;origin=null;isActive=!1;constructor(){m(ne).load(ae)}ngOnChanges(e){(e.hasOwnProperty("textLabel")||e.hasOwnProperty("disabled"))&&this._stateChanges.next()}ngOnDestroy(){this._stateChanges.complete()}ngOnInit(){this._contentPortal=new $t(this._explicitContent||this._implicitContent,this._viewContainerRef)}_setTemplateLabelInput(e){e&&e._closestTab===this&&(this._templateLabel=e)}static \u0275fac=function(t){return new(t||a)};static \u0275cmp=P({type:a,selectors:[["mat-tab"]],contentQueries:function(t,n,i){if(t&1&&Y(i,Ue,5)(i,ra,7,ye),t&2){let d;k(d=C())&&(n.templateLabel=d.first),k(d=C())&&(n._explicitContent=d.first)}},viewQuery:function(t,n){if(t&1&&j(ye,7),t&2){let i;k(i=C())&&(n._implicitContent=i.first)}},hostAttrs:["hidden",""],hostVars:1,hostBindings:function(t,n){t&2&&x("id",null)},inputs:{disabled:[2,"disabled","disabled",g],textLabel:[0,"label","textLabel"],ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],labelClass:"labelClass",bodyClass:"bodyClass",id:"id"},exportAs:["matTab"],features:[V([{provide:xn,useExisting:a}]),_e],ngContentSelectors:$e,decls:1,vars:0,template:function(t,n){t&1&&(Q(),ct(0,Gn,1,0,"ng-template"))},encapsulation:2})}return a})(),Ge="mdc-tab-indicator--active",fn="mdc-tab-indicator--no-transition",qe=class{_items;_currentItem;constructor(r){this._items=r}hide(){this._items.forEach(r=>r.deactivateInkBar()),this._currentItem=void 0}alignToElement(r){let e=this._items.find(n=>n.elementRef.nativeElement===r),t=this._currentItem;if(e!==t&&(t?.deactivateInkBar(),e)){let n=t?.elementRef.nativeElement.getBoundingClientRect?.();e.activateInkBar(n),this._currentItem=e}}},la=(()=>{class a{_elementRef=m(R);_inkBarElement=null;_inkBarContentElement=null;_fitToContent=!1;get fitInkBarToContent(){return this._fitToContent}set fitInkBarToContent(e){this._fitToContent!==e&&(this._fitToContent=e,this._inkBarElement&&this._appendInkBarElement())}activateInkBar(e){let t=this._elementRef.nativeElement;if(!e||!t.getBoundingClientRect||!this._inkBarContentElement){t.classList.add(Ge);return}let n=t.getBoundingClientRect(),i=e.width/n.width,d=e.left-n.left;t.classList.add(fn),this._inkBarContentElement.style.setProperty("transform",`translateX(${d}px) scaleX(${i})`),t.getBoundingClientRect(),t.classList.remove(fn),t.classList.add(Ge),this._inkBarContentElement.style.setProperty("transform","")}deactivateInkBar(){this._elementRef.nativeElement.classList.remove(Ge)}ngOnInit(){this._createInkBarElement()}ngOnDestroy(){this._inkBarElement?.remove(),this._inkBarElement=this._inkBarContentElement=null}_createInkBarElement(){let e=this._elementRef.nativeElement.ownerDocument||document,t=this._inkBarElement=e.createElement("span"),n=this._inkBarContentElement=e.createElement("span");t.className="mdc-tab-indicator",n.className="mdc-tab-indicator__content mdc-tab-indicator__content--underline",t.appendChild(this._inkBarContentElement),this._appendInkBarElement()}_appendInkBarElement(){this._inkBarElement;let e=this._fitToContent?this._elementRef.nativeElement.querySelector(".mdc-tab__content"):this._elementRef.nativeElement;e.appendChild(this._inkBarElement)}static \u0275fac=function(t){return new(t||a)};static \u0275dir=F({type:a,inputs:{fitInkBarToContent:[2,"fitInkBarToContent","fitInkBarToContent",g]}})}return a})();var Cn=(()=>{class a extends la{elementRef=m(R);disabled=!1;focus(){this.elementRef.nativeElement.focus()}getOffsetLeft(){return this.elementRef.nativeElement.offsetLeft}getOffsetWidth(){return this.elementRef.nativeElement.offsetWidth}static \u0275fac=(()=>{let e;return function(n){return(e||(e=fe(a)))(n||a)}})();static \u0275dir=F({type:a,selectors:[["","matTabLabelWrapper",""]],hostVars:3,hostBindings:function(t,n){t&2&&(x("aria-disabled",!!n.disabled),f("mat-mdc-tab-disabled",n.disabled))},inputs:{disabled:[2,"disabled","disabled",g]},features:[re]})}return a})(),vn={passive:!0},ca=650,da=100,ma=(()=>{class a{_elementRef=m(R);_changeDetectorRef=m(D);_viewportRuler=m(Wt);_dir=m(me,{optional:!0});_ngZone=m(oe);_platform=m(Le);_sharedResizeObserver=m(zt);_injector=m(Ee);_renderer=m(Ae);_animationsDisabled=q();_eventCleanups;_scrollDistance=0;_selectedIndexChanged=!1;_destroyed=new be;_showPaginationControls=!1;_disableScrollAfter=!0;_disableScrollBefore=!0;_tabLabelCount;_scrollDistanceChanged=!1;_keyManager;_currentTextContent;_stopScrolling=new be;disablePagination=!1;get selectedIndex(){return this._selectedIndex}set selectedIndex(e){let t=isNaN(e)?0:e;this._selectedIndex!=t&&(this._selectedIndexChanged=!0,this._selectedIndex=t,this._keyManager&&this._keyManager.updateActiveItem(t))}_selectedIndex=0;selectFocusedIndex=new T;indexFocused=new T;constructor(){this._eventCleanups=this._ngZone.runOutsideAngular(()=>[this._renderer.listen(this._elementRef.nativeElement,"mouseleave",()=>this._stopInterval())])}ngAfterViewInit(){this._eventCleanups.push(this._renderer.listen(this._previousPaginator.nativeElement,"touchstart",()=>this._handlePaginatorPress("before"),vn),this._renderer.listen(this._nextPaginator.nativeElement,"touchstart",()=>this._handlePaginatorPress("after"),vn))}ngAfterContentInit(){let e=this._dir?this._dir.change:et("ltr"),t=this._sharedResizeObserver.observe(this._elementRef.nativeElement).pipe(at(32),ie(this._destroyed)),n=this._viewportRuler.change(150).pipe(ie(this._destroyed)),i=()=>{this.updatePagination(),this._alignInkBarToSelectedTab()};this._keyManager=new Ct(this._items).withHorizontalOrientation(this._getLayoutDirection()).withHomeAndEnd().withWrap().skipPredicate(()=>!1),this._keyManager.updateActiveItem(Math.max(this._selectedIndex,0)),ve(i,{injector:this._injector}),ge(e,n,t,this._items.changes,this._itemsResized()).pipe(ie(this._destroyed)).subscribe(()=>{this._ngZone.run(()=>{Promise.resolve().then(()=>{this._scrollDistance=Math.max(0,Math.min(this._getMaxScrollDistance(),this._scrollDistance)),i()})}),this._keyManager?.withHorizontalOrientation(this._getLayoutDirection())}),this._keyManager.change.subscribe(d=>{this.indexFocused.emit(d),this._setTabFocus(d)})}_itemsResized(){return typeof ResizeObserver!="function"?Je:this._items.changes.pipe(pe(this._items),ot(e=>new Ye(t=>this._ngZone.runOutsideAngular(()=>{let n=new ResizeObserver(i=>t.next(i));return e.forEach(i=>n.observe(i.elementRef.nativeElement)),()=>{n.disconnect()}}))),it(1),nt(e=>e.some(t=>t.contentRect.width>0&&t.contentRect.height>0)))}ngAfterContentChecked(){this._tabLabelCount!=this._items.length&&(this.updatePagination(),this._tabLabelCount=this._items.length,this._changeDetectorRef.markForCheck()),this._selectedIndexChanged&&(this._scrollToLabel(this._selectedIndex),this._checkScrollingControls(),this._alignInkBarToSelectedTab(),this._selectedIndexChanged=!1,this._changeDetectorRef.markForCheck()),this._scrollDistanceChanged&&(this._updateTabScrollPosition(),this._scrollDistanceChanged=!1,this._changeDetectorRef.markForCheck())}ngOnDestroy(){this._eventCleanups.forEach(e=>e()),this._keyManager?.destroy(),this._destroyed.next(),this._destroyed.complete(),this._stopScrolling.complete()}_handleKeydown(e){if(!ke(e))switch(e.keyCode){case 13:case 32:if(this.focusIndex!==this.selectedIndex){let t=this._items.get(this.focusIndex);t&&!t.disabled&&(this.selectFocusedIndex.emit(this.focusIndex),this._itemSelected(e))}break;default:this._keyManager?.onKeydown(e)}}_onContentChanges(){let e=this._elementRef.nativeElement.textContent;e!==this._currentTextContent&&(this._currentTextContent=e||"",this._ngZone.run(()=>{this.updatePagination(),this._alignInkBarToSelectedTab(),this._changeDetectorRef.markForCheck()}))}updatePagination(){this._checkPaginationEnabled(),this._checkScrollingControls(),this._updateTabScrollPosition()}get focusIndex(){return this._keyManager?this._keyManager.activeItemIndex:0}set focusIndex(e){!this._isValidIndex(e)||this.focusIndex===e||!this._keyManager||this._keyManager.setActiveItem(e)}_isValidIndex(e){return this._items?!!this._items.toArray()[e]:!0}_setTabFocus(e){if(this._showPaginationControls&&this._scrollToLabel(e),this._items&&this._items.length){this._items.toArray()[e].focus();let t=this._tabListContainer.nativeElement;this._getLayoutDirection()=="ltr"?t.scrollLeft=0:t.scrollLeft=t.scrollWidth-t.offsetWidth}}_getLayoutDirection(){return this._dir&&this._dir.value==="rtl"?"rtl":"ltr"}_updateTabScrollPosition(){if(this.disablePagination)return;let e=this.scrollDistance,t=this._getLayoutDirection()==="ltr"?-e:e;this._tabList.nativeElement.style.transform=`translateX(${Math.round(t)}px)`,(this._platform.TRIDENT||this._platform.EDGE)&&(this._tabListContainer.nativeElement.scrollLeft=0)}get scrollDistance(){return this._scrollDistance}set scrollDistance(e){this._scrollTo(e)}_scrollHeader(e){let t=this._tabListContainer.nativeElement.offsetWidth,n=(e=="before"?-1:1)*t/3;return this._scrollTo(this._scrollDistance+n)}_handlePaginatorClick(e){this._stopInterval(),this._scrollHeader(e)}_scrollToLabel(e){if(this.disablePagination)return;let t=this._items?this._items.toArray()[e]:null;if(!t)return;let n=this._tabListContainer.nativeElement.offsetWidth,{offsetLeft:i,offsetWidth:d}=t.elementRef.nativeElement,M,H;this._getLayoutDirection()=="ltr"?(M=i,H=M+d):(H=this._tabListInner.nativeElement.offsetWidth-i,M=H-d);let Se=this.scrollDistance,Ke=this.scrollDistance+n;M<Se?this.scrollDistance-=Se-M:H>Ke&&(this.scrollDistance+=Math.min(H-Ke,M-Se))}_checkPaginationEnabled(){if(this.disablePagination)this._showPaginationControls=!1;else{let e=this._tabListInner.nativeElement.scrollWidth,t=this._elementRef.nativeElement.offsetWidth,n=e-t>=5;n||(this.scrollDistance=0),n!==this._showPaginationControls&&(this._showPaginationControls=n,this._changeDetectorRef.markForCheck())}}_checkScrollingControls(){this.disablePagination?this._disableScrollAfter=this._disableScrollBefore=!0:(this._disableScrollBefore=this.scrollDistance==0,this._disableScrollAfter=this.scrollDistance==this._getMaxScrollDistance(),this._changeDetectorRef.markForCheck())}_getMaxScrollDistance(){let e=this._tabListInner.nativeElement.scrollWidth,t=this._tabListContainer.nativeElement.offsetWidth;return e-t||0}_alignInkBarToSelectedTab(){let e=this._items&&this._items.length?this._items.toArray()[this.selectedIndex]:null,t=e?e.elementRef.nativeElement:null;t?this._inkBar.alignToElement(t):this._inkBar.hide()}_stopInterval(){this._stopScrolling.next()}_handlePaginatorPress(e,t){t&&t.button!=null&&t.button!==0||(this._stopInterval(),tt(ca,da).pipe(ie(ge(this._stopScrolling,this._destroyed))).subscribe(()=>{let{maxScrollDistance:n,distance:i}=this._scrollHeader(e);(i===0||i>=n)&&this._stopInterval()}))}_scrollTo(e){if(this.disablePagination)return{maxScrollDistance:0,distance:0};let t=this._getMaxScrollDistance();return this._scrollDistance=Math.max(0,Math.min(t,e)),this._scrollDistanceChanged=!0,this._checkScrollingControls(),{maxScrollDistance:t,distance:this._scrollDistance}}static \u0275fac=function(t){return new(t||a)};static \u0275dir=F({type:a,inputs:{disablePagination:[2,"disablePagination","disablePagination",g],selectedIndex:[2,"selectedIndex","selectedIndex",ee]},outputs:{selectFocusedIndex:"selectFocusedIndex",indexFocused:"indexFocused"}})}return a})(),ua=(()=>{class a extends ma{_items;_tabListContainer;_tabList;_tabListInner;_nextPaginator;_previousPaginator;_inkBar;ariaLabel;ariaLabelledby;disableRipple=!1;ngAfterContentInit(){this._inkBar=new qe(this._items),super.ngAfterContentInit()}_itemSelected(e){e.preventDefault()}static \u0275fac=(()=>{let e;return function(n){return(e||(e=fe(a)))(n||a)}})();static \u0275cmp=P({type:a,selectors:[["mat-tab-header"]],contentQueries:function(t,n,i){if(t&1&&Y(i,Cn,4),t&2){let d;k(d=C())&&(n._items=d)}},viewQuery:function(t,n){if(t&1&&j(qn,7)(Hn,7)(Wn,7)($n,5)(Un,5),t&2){let i;k(i=C())&&(n._tabListContainer=i.first),k(i=C())&&(n._tabList=i.first),k(i=C())&&(n._tabListInner=i.first),k(i=C())&&(n._nextPaginator=i.first),k(i=C())&&(n._previousPaginator=i.first)}},hostAttrs:[1,"mat-mdc-tab-header"],hostVars:4,hostBindings:function(t,n){t&2&&f("mat-mdc-tab-header-pagination-controls-enabled",n._showPaginationControls)("mat-mdc-tab-header-rtl",n._getLayoutDirection()=="rtl")},inputs:{ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],disableRipple:[2,"disableRipple","disableRipple",g]},features:[re],ngContentSelectors:$e,decls:13,vars:10,consts:[["previousPaginator",""],["tabListContainer",""],["tabList",""],["tabListInner",""],["nextPaginator",""],["mat-ripple","",1,"mat-mdc-tab-header-pagination","mat-mdc-tab-header-pagination-before",3,"click","mousedown","touchend","matRippleDisabled"],[1,"mat-mdc-tab-header-pagination-chevron"],[1,"mat-mdc-tab-label-container",3,"keydown"],["role","tablist",1,"mat-mdc-tab-list",3,"cdkObserveContent"],[1,"mat-mdc-tab-labels"],["mat-ripple","",1,"mat-mdc-tab-header-pagination","mat-mdc-tab-header-pagination-after",3,"mousedown","click","touchend","matRippleDisabled"]],template:function(t,n){t&1&&(Q(),o(0,"div",5,0),b("click",function(){return n._handlePaginatorClick("before")})("mousedown",function(d){return n._handlePaginatorPress("before",d)})("touchend",function(){return n._stopInterval()}),I(2,"div",6),s(),o(3,"div",7,1),b("keydown",function(d){return n._handleKeydown(d)}),o(5,"div",8,2),b("cdkObserveContent",function(){return n._onContentChanges()}),o(7,"div",9,3),G(9),s()()(),o(10,"div",10,4),b("mousedown",function(d){return n._handlePaginatorPress("after",d)})("click",function(){return n._handlePaginatorClick("after")})("touchend",function(){return n._stopInterval()}),I(12,"div",6),s()),t&2&&(f("mat-mdc-tab-header-pagination-disabled",n._disableScrollBefore),p("matRippleDisabled",n._disableScrollBefore||n.disableRipple),c(3),f("_mat-animation-noopable",n._animationsDisabled),c(2),x("aria-label",n.ariaLabel||null)("aria-labelledby",n.ariaLabelledby||null),c(5),f("mat-mdc-tab-header-pagination-disabled",n._disableScrollAfter),p("matRippleDisabled",n._disableScrollAfter||n.disableRipple))},dependencies:[Z,kt],styles:[`.mat-mdc-tab-header {
  display: flex;
  overflow: hidden;
  position: relative;
  flex-shrink: 0;
}

.mdc-tab-indicator .mdc-tab-indicator__content {
  transition-duration: var(--mat-tab-animation-duration, 250ms);
}

.mat-mdc-tab-header-pagination {
  -webkit-user-select: none;
  user-select: none;
  position: relative;
  display: none;
  justify-content: center;
  align-items: center;
  min-width: 32px;
  cursor: pointer;
  z-index: 2;
  -webkit-tap-highlight-color: transparent;
  touch-action: none;
  box-sizing: content-box;
  outline: 0;
}
.mat-mdc-tab-header-pagination::-moz-focus-inner {
  border: 0;
}
.mat-mdc-tab-header-pagination .mat-ripple-element {
  opacity: 0.12;
  background-color: var(--mat-tab-inactive-ripple-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab-header-pagination-controls-enabled .mat-mdc-tab-header-pagination {
  display: flex;
}

.mat-mdc-tab-header-pagination-before,
.mat-mdc-tab-header-rtl .mat-mdc-tab-header-pagination-after {
  padding-left: 4px;
}
.mat-mdc-tab-header-pagination-before .mat-mdc-tab-header-pagination-chevron,
.mat-mdc-tab-header-rtl .mat-mdc-tab-header-pagination-after .mat-mdc-tab-header-pagination-chevron {
  transform: rotate(-135deg);
}

.mat-mdc-tab-header-rtl .mat-mdc-tab-header-pagination-before,
.mat-mdc-tab-header-pagination-after {
  padding-right: 4px;
}
.mat-mdc-tab-header-rtl .mat-mdc-tab-header-pagination-before .mat-mdc-tab-header-pagination-chevron,
.mat-mdc-tab-header-pagination-after .mat-mdc-tab-header-pagination-chevron {
  transform: rotate(45deg);
}

.mat-mdc-tab-header-pagination-chevron {
  border-style: solid;
  border-width: 2px 2px 0 0;
  height: 8px;
  width: 8px;
  border-color: var(--mat-tab-pagination-icon-color, var(--mat-sys-on-surface));
}

.mat-mdc-tab-header-pagination-disabled {
  box-shadow: none;
  cursor: default;
  pointer-events: none;
}
.mat-mdc-tab-header-pagination-disabled .mat-mdc-tab-header-pagination-chevron {
  opacity: 0.4;
}

.mat-mdc-tab-list {
  flex-grow: 1;
  position: relative;
  transition: transform 500ms cubic-bezier(0.35, 0, 0.25, 1);
}
._mat-animation-noopable .mat-mdc-tab-list {
  transition: none;
}

.mat-mdc-tab-label-container {
  display: flex;
  flex-grow: 1;
  overflow: hidden;
  z-index: 1;
  border-bottom-style: solid;
  border-bottom-width: var(--mat-tab-divider-height, 1px);
  border-bottom-color: var(--mat-tab-divider-color, var(--mat-sys-surface-variant));
}
.mat-mdc-tab-group-inverted-header .mat-mdc-tab-label-container {
  border-bottom: none;
  border-top-style: solid;
  border-top-width: var(--mat-tab-divider-height, 1px);
  border-top-color: var(--mat-tab-divider-color, var(--mat-sys-surface-variant));
}

.mat-mdc-tab-labels {
  display: flex;
  flex: 1 0 auto;
}
[mat-align-tabs=center] > .mat-mdc-tab-header .mat-mdc-tab-labels {
  justify-content: center;
}
[mat-align-tabs=end] > .mat-mdc-tab-header .mat-mdc-tab-labels {
  justify-content: flex-end;
}
.cdk-drop-list .mat-mdc-tab-labels, .mat-mdc-tab-labels.cdk-drop-list {
  min-height: var(--mat-tab-container-height, 48px);
}

.mat-mdc-tab::before {
  margin: 5px;
}
@media (forced-colors: active) {
  .mat-mdc-tab[aria-disabled=true] {
    color: GrayText;
  }
}
`],encapsulation:2})}return a})(),ba=new E("MAT_TABS_CONFIG"),yn=(()=>{class a extends Fe{_host=m(He);_ngZone=m(oe);_centeringSub=W.EMPTY;_leavingSub=W.EMPTY;constructor(){super()}ngOnInit(){super.ngOnInit(),this._centeringSub=this._host._beforeCentering.pipe(pe(this._host._isCenterPosition())).subscribe(e=>{this._host._content&&e&&!this.hasAttached()&&this._ngZone.run(()=>{Promise.resolve().then(),this.attach(this._host._content)})}),this._leavingSub=this._host._afterLeavingCenter.subscribe(()=>{this._host.preserveContent||this._ngZone.run(()=>this.detach())})}ngOnDestroy(){super.ngOnDestroy(),this._centeringSub.unsubscribe(),this._leavingSub.unsubscribe()}static \u0275fac=function(t){return new(t||a)};static \u0275dir=F({type:a,selectors:[["","matTabBodyHost",""]],features:[re]})}return a})(),He=(()=>{class a{_elementRef=m(R);_dir=m(me,{optional:!0});_ngZone=m(oe);_injector=m(Ee);_renderer=m(Ae);_diAnimationsDisabled=q();_eventCleanups;_initialized=!1;_fallbackTimer;_positionIndex;_dirChangeSubscription=W.EMPTY;_position;_previousPosition;_onCentering=new T;_beforeCentering=new T;_afterLeavingCenter=new T;_onCentered=new T(!0);_portalHost;_contentElement;_content;animationDuration="500ms";preserveContent=!1;set position(e){this._positionIndex=e,this._computePositionAnimationState()}constructor(){if(this._dir){let e=m(D);this._dirChangeSubscription=this._dir.change.subscribe(t=>{this._computePositionAnimationState(t),e.markForCheck()})}}ngOnInit(){this._bindTransitionEvents(),this._position==="center"&&(this._setActiveClass(!0),ve(()=>this._onCentering.emit(this._elementRef.nativeElement.clientHeight),{injector:this._injector})),this._initialized=!0}ngOnDestroy(){clearTimeout(this._fallbackTimer),this._eventCleanups?.forEach(e=>e()),this._dirChangeSubscription.unsubscribe()}_bindTransitionEvents(){this._ngZone.runOutsideAngular(()=>{let e=this._elementRef.nativeElement,t=n=>{n.target===this._contentElement?.nativeElement&&(this._elementRef.nativeElement.classList.remove("mat-tab-body-animating"),n.type==="transitionend"&&this._transitionDone())};this._eventCleanups=[this._renderer.listen(e,"transitionstart",n=>{n.target===this._contentElement?.nativeElement&&(this._elementRef.nativeElement.classList.add("mat-tab-body-animating"),this._transitionStarted())}),this._renderer.listen(e,"transitionend",t),this._renderer.listen(e,"transitioncancel",t)]})}_transitionStarted(){clearTimeout(this._fallbackTimer);let e=this._position==="center";this._beforeCentering.emit(e),e&&this._onCentering.emit(this._elementRef.nativeElement.clientHeight)}_transitionDone(){this._position==="center"?this._onCentered.emit():this._previousPosition==="center"&&this._afterLeavingCenter.emit()}_setActiveClass(e){this._elementRef.nativeElement.classList.toggle("mat-mdc-tab-body-active",e)}_getLayoutDirection(){return this._dir&&this._dir.value==="rtl"?"rtl":"ltr"}_isCenterPosition(){return this._positionIndex===0}_computePositionAnimationState(e=this._getLayoutDirection()){this._previousPosition=this._position,this._positionIndex<0?this._position=e=="ltr"?"left":"right":this._positionIndex>0?this._position=e=="ltr"?"right":"left":this._position="center",this._animationsDisabled()?this._simulateTransitionEvents():this._initialized&&(this._position==="center"||this._previousPosition==="center")&&(clearTimeout(this._fallbackTimer),this._fallbackTimer=this._ngZone.runOutsideAngular(()=>setTimeout(()=>this._simulateTransitionEvents(),100)))}_simulateTransitionEvents(){this._transitionStarted(),ve(()=>this._transitionDone(),{injector:this._injector})}_animationsDisabled(){return this._diAnimationsDisabled||this.animationDuration==="0ms"||this.animationDuration==="0s"}static \u0275fac=function(t){return new(t||a)};static \u0275cmp=P({type:a,selectors:[["mat-tab-body"]],viewQuery:function(t,n){if(t&1&&j(yn,5)(Zn,5),t&2){let i;k(i=C())&&(n._portalHost=i.first),k(i=C())&&(n._contentElement=i.first)}},hostAttrs:[1,"mat-mdc-tab-body"],hostVars:1,hostBindings:function(t,n){t&2&&x("inert",n._position==="center"?null:"")},inputs:{_content:[0,"content","_content"],animationDuration:"animationDuration",preserveContent:"preserveContent",position:"position"},outputs:{_onCentering:"_onCentering",_beforeCentering:"_beforeCentering",_onCentered:"_onCentered"},decls:3,vars:6,consts:[["content",""],["cdkScrollable","",1,"mat-mdc-tab-body-content"],["matTabBodyHost",""]],template:function(t,n){t&1&&(o(0,"div",1,0),z(2,Xn,0,0,"ng-template",2),s()),t&2&&f("mat-tab-body-content-left",n._position==="left")("mat-tab-body-content-right",n._position==="right")("mat-tab-body-content-can-animate",n._position==="center"||n._previousPosition==="center")},dependencies:[yn,Ht],styles:[`.mat-mdc-tab-body {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  display: block;
  overflow: hidden;
  outline: 0;
  flex-basis: 100%;
}
.mat-mdc-tab-body.mat-mdc-tab-body-active {
  position: relative;
  overflow-x: hidden;
  overflow-y: auto;
  z-index: 1;
  flex-grow: 1;
}
.mat-mdc-tab-group.mat-mdc-tab-group-dynamic-height .mat-mdc-tab-body.mat-mdc-tab-body-active {
  overflow-y: hidden;
}

.mat-mdc-tab-body-content {
  height: 100%;
  overflow: auto;
  transform: none;
  visibility: hidden;
}
.mat-tab-body-animating > .mat-mdc-tab-body-content, .mat-mdc-tab-body-active > .mat-mdc-tab-body-content {
  visibility: visible;
}
.mat-tab-body-animating > .mat-mdc-tab-body-content {
  min-height: 1px;
}
.mat-mdc-tab-group-dynamic-height .mat-mdc-tab-body-content {
  overflow: hidden;
}

.mat-tab-body-content-can-animate {
  transition: transform var(--mat-tab-animation-duration) 1ms cubic-bezier(0.35, 0, 0.25, 1);
}
.mat-mdc-tab-body-wrapper._mat-animation-noopable .mat-tab-body-content-can-animate {
  transition: none;
}

.mat-tab-body-content-left {
  transform: translate3d(-100%, 0, 0);
}

.mat-tab-body-content-right {
  transform: translate3d(100%, 0, 0);
}
`],encapsulation:2})}return a})(),wn=(()=>{class a{_elementRef=m(R);_changeDetectorRef=m(D);_ngZone=m(oe);_tabsSubscription=W.EMPTY;_tabLabelSubscription=W.EMPTY;_tabBodySubscription=W.EMPTY;_diAnimationsDisabled=q();_allTabs;_tabBodies;_tabBodyWrapper;_tabHeader;_tabs=new st;_indexToSelect=0;_lastFocusedTabIndex=null;_tabBodyWrapperHeight=0;color;get fitInkBarToContent(){return this._fitInkBarToContent}set fitInkBarToContent(e){this._fitInkBarToContent=e,this._changeDetectorRef.markForCheck()}_fitInkBarToContent=!1;stretchTabs=!0;alignTabs=null;dynamicHeight=!1;get selectedIndex(){return this._selectedIndex}set selectedIndex(e){this._indexToSelect=isNaN(e)?null:e}_selectedIndex=null;headerPosition="above";get animationDuration(){return this._animationDuration}set animationDuration(e){let t=e+"";this._animationDuration=/^\d+$/.test(t)?e+"ms":t}_animationDuration;get contentTabIndex(){return this._contentTabIndex}set contentTabIndex(e){this._contentTabIndex=isNaN(e)?null:e}_contentTabIndex=null;disablePagination=!1;disableRipple=!1;preserveContent=!1;get backgroundColor(){return this._backgroundColor}set backgroundColor(e){let t=this._elementRef.nativeElement.classList;t.remove("mat-tabs-with-background",`mat-background-${this.backgroundColor}`),e&&t.add("mat-tabs-with-background",`mat-background-${e}`),this._backgroundColor=e}_backgroundColor;ariaLabel;ariaLabelledby;selectedIndexChange=new T;focusChange=new T;animationDone=new T;selectedTabChange=new T(!0);_groupId;_isServer=!m(Le).isBrowser;constructor(){let e=m(ba,{optional:!0});this._groupId=m(U).getId("mat-tab-group-"),this.animationDuration=e&&e.animationDuration?e.animationDuration:"500ms",this.disablePagination=e&&e.disablePagination!=null?e.disablePagination:!1,this.dynamicHeight=e&&e.dynamicHeight!=null?e.dynamicHeight:!1,e?.contentTabIndex!=null&&(this.contentTabIndex=e.contentTabIndex),this.preserveContent=!!e?.preserveContent,this.fitInkBarToContent=e&&e.fitInkBarToContent!=null?e.fitInkBarToContent:!1,this.stretchTabs=e&&e.stretchTabs!=null?e.stretchTabs:!0,this.alignTabs=e&&e.alignTabs!=null?e.alignTabs:null}ngAfterContentChecked(){let e=this._indexToSelect=this._clampTabIndex(this._indexToSelect);if(this._selectedIndex!=e){let t=this._selectedIndex==null;if(!t){this.selectedTabChange.emit(this._createChangeEvent(e));let n=this._tabBodyWrapper.nativeElement;n.style.minHeight=n.clientHeight+"px"}Promise.resolve().then(()=>{this._tabs.forEach((n,i)=>n.isActive=i===e),t||(this.selectedIndexChange.emit(e),this._tabBodyWrapper.nativeElement.style.minHeight="")})}this._tabs.forEach((t,n)=>{t.position=n-e,this._selectedIndex!=null&&t.position==0&&!t.origin&&(t.origin=e-this._selectedIndex)}),this._selectedIndex!==e&&(this._selectedIndex=e,this._lastFocusedTabIndex=null,this._changeDetectorRef.markForCheck())}ngAfterContentInit(){this._subscribeToAllTabChanges(),this._subscribeToTabLabels(),this._tabsSubscription=this._tabs.changes.subscribe(()=>{let e=this._clampTabIndex(this._indexToSelect);if(e===this._selectedIndex){let t=this._tabs.toArray(),n;for(let i=0;i<t.length;i++)if(t[i].isActive){this._indexToSelect=this._selectedIndex=i,this._lastFocusedTabIndex=null,n=t[i];break}!n&&t[e]&&Promise.resolve().then(()=>{t[e].isActive=!0,this.selectedTabChange.emit(this._createChangeEvent(e))})}this._changeDetectorRef.markForCheck()})}ngAfterViewInit(){this._tabBodySubscription=this._tabBodies.changes.subscribe(()=>this._bodyCentered(!0))}_subscribeToAllTabChanges(){this._allTabs.changes.pipe(pe(this._allTabs)).subscribe(e=>{this._tabs.reset(e.filter(t=>t._closestTabGroup===this||!t._closestTabGroup)),this._tabs.notifyOnChanges()})}ngOnDestroy(){this._tabs.destroy(),this._tabsSubscription.unsubscribe(),this._tabLabelSubscription.unsubscribe(),this._tabBodySubscription.unsubscribe()}realignInkBar(){this._tabHeader&&this._tabHeader._alignInkBarToSelectedTab()}updatePagination(){this._tabHeader&&this._tabHeader.updatePagination()}focusTab(e){let t=this._tabHeader;t&&(t.focusIndex=e)}_focusChanged(e){this._lastFocusedTabIndex=e,this.focusChange.emit(this._createChangeEvent(e))}_createChangeEvent(e){let t=new We;return t.index=e,this._tabs&&this._tabs.length&&(t.tab=this._tabs.toArray()[e]),t}_subscribeToTabLabels(){this._tabLabelSubscription&&this._tabLabelSubscription.unsubscribe(),this._tabLabelSubscription=ge(...this._tabs.map(e=>e._stateChanges)).subscribe(()=>this._changeDetectorRef.markForCheck())}_clampTabIndex(e){return Math.min(this._tabs.length-1,Math.max(e||0,0))}_getTabLabelId(e,t){return e.id||`${this._groupId}-label-${t}`}_getTabContentId(e){return`${this._groupId}-content-${e}`}_setTabBodyWrapperHeight(e){if(!this.dynamicHeight||!this._tabBodyWrapperHeight){this._tabBodyWrapperHeight=e;return}let t=this._tabBodyWrapper.nativeElement;t.style.height=this._tabBodyWrapperHeight+"px",this._tabBodyWrapper.nativeElement.offsetHeight&&(t.style.height=e+"px")}_removeTabBodyWrapperHeight(){let e=this._tabBodyWrapper.nativeElement;this._tabBodyWrapperHeight=e.clientHeight,e.style.height="",this._ngZone.run(()=>this.animationDone.emit())}_handleClick(e,t,n){t.focusIndex=n,e.disabled||(this.selectedIndex=n)}_getTabIndex(e){let t=this._lastFocusedTabIndex??this.selectedIndex;return e===t?0:-1}_tabFocusChanged(e,t){e&&e!=="mouse"&&e!=="touch"&&(this._tabHeader.focusIndex=t)}_bodyCentered(e){e&&this._tabBodies?.forEach((t,n)=>t._setActiveClass(n===this._selectedIndex))}_animationsDisabled(){return this._diAnimationsDisabled||this.animationDuration==="0"||this.animationDuration==="0ms"}static \u0275fac=function(t){return new(t||a)};static \u0275cmp=P({type:a,selectors:[["mat-tab-group"]],contentQueries:function(t,n,i){if(t&1&&Y(i,Ze,5),t&2){let d;k(d=C())&&(n._allTabs=d)}},viewQuery:function(t,n){if(t&1&&j(Kn,5)(Yn,5)(He,5),t&2){let i;k(i=C())&&(n._tabBodyWrapper=i.first),k(i=C())&&(n._tabHeader=i.first),k(i=C())&&(n._tabBodies=i)}},hostAttrs:[1,"mat-mdc-tab-group"],hostVars:11,hostBindings:function(t,n){t&2&&(x("mat-align-tabs",n.alignTabs),J("mat-"+(n.color||"primary")),xe("--mat-tab-animation-duration",n.animationDuration),f("mat-mdc-tab-group-dynamic-height",n.dynamicHeight)("mat-mdc-tab-group-inverted-header",n.headerPosition==="below")("mat-mdc-tab-group-stretch-tabs",n.stretchTabs))},inputs:{color:"color",fitInkBarToContent:[2,"fitInkBarToContent","fitInkBarToContent",g],stretchTabs:[2,"mat-stretch-tabs","stretchTabs",g],alignTabs:[0,"mat-align-tabs","alignTabs"],dynamicHeight:[2,"dynamicHeight","dynamicHeight",g],selectedIndex:[2,"selectedIndex","selectedIndex",ee],headerPosition:"headerPosition",animationDuration:"animationDuration",contentTabIndex:[2,"contentTabIndex","contentTabIndex",ee],disablePagination:[2,"disablePagination","disablePagination",g],disableRipple:[2,"disableRipple","disableRipple",g],preserveContent:[2,"preserveContent","preserveContent",g],backgroundColor:"backgroundColor",ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"]},outputs:{selectedIndexChange:"selectedIndexChange",focusChange:"focusChange",animationDone:"animationDone",selectedTabChange:"selectedTabChange"},exportAs:["matTabGroup"],features:[V([{provide:kn,useExisting:a}])],ngContentSelectors:$e,decls:9,vars:8,consts:[["tabHeader",""],["tabBodyWrapper",""],["tabNode",""],[3,"indexFocused","selectFocusedIndex","selectedIndex","disableRipple","disablePagination","aria-label","aria-labelledby"],["role","tab","matTabLabelWrapper","","cdkMonitorElementFocus","",1,"mdc-tab","mat-mdc-tab","mat-focus-indicator",3,"id","mdc-tab--active","class","disabled","fitInkBarToContent"],[1,"mat-mdc-tab-body-wrapper"],["role","tabpanel",3,"id","class","content","position","animationDuration","preserveContent"],["role","tab","matTabLabelWrapper","","cdkMonitorElementFocus","",1,"mdc-tab","mat-mdc-tab","mat-focus-indicator",3,"click","cdkFocusChange","id","disabled","fitInkBarToContent"],[1,"mdc-tab__ripple"],["mat-ripple","",1,"mat-mdc-tab-ripple",3,"matRippleTrigger","matRippleDisabled"],[1,"mdc-tab__content"],[1,"mdc-tab__text-label"],[3,"cdkPortalOutlet"],["role","tabpanel",3,"_onCentered","_onCentering","_beforeCentering","id","content","position","animationDuration","preserveContent"]],template:function(t,n){t&1&&(Q(),o(0,"mat-tab-header",3,0),b("indexFocused",function(d){return n._focusChanged(d)})("selectFocusedIndex",function(d){return n.selectedIndex=d}),O(2,na,8,17,"div",4,$),s(),v(4,aa,1,0),o(5,"div",5,1),O(7,ia,1,10,"mat-tab-body",6,$),s()),t&2&&(p("selectedIndex",n.selectedIndex||0)("disableRipple",n.disableRipple)("disablePagination",n.disablePagination),dt("aria-label",n.ariaLabel)("aria-labelledby",n.ariaLabelledby),c(2),B(n._tabs),c(2),y(n._isServer?4:-1),c(),f("_mat-animation-noopable",n._animationsDisabled()),c(2),B(n._tabs))},dependencies:[ua,Cn,xt,Z,Fe,He],styles:[`.mdc-tab {
  min-width: 90px;
  padding: 0 24px;
  display: flex;
  flex: 1 0 auto;
  justify-content: center;
  box-sizing: border-box;
  border: none;
  outline: none;
  text-align: center;
  white-space: nowrap;
  cursor: pointer;
  z-index: 1;
  touch-action: manipulation;
}

.mdc-tab__content {
  display: flex;
  align-items: center;
  justify-content: center;
  height: inherit;
  pointer-events: none;
}

.mdc-tab__text-label {
  transition: 150ms color linear;
  display: inline-block;
  line-height: 1;
  z-index: 2;
}

.mdc-tab--active .mdc-tab__text-label {
  transition-delay: 100ms;
}

._mat-animation-noopable .mdc-tab__text-label {
  transition: none;
}

.mdc-tab-indicator {
  display: flex;
  position: absolute;
  top: 0;
  left: 0;
  justify-content: center;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 1;
}

.mdc-tab-indicator__content {
  transition: var(--mat-tab-animation-duration, 250ms) transform cubic-bezier(0.4, 0, 0.2, 1);
  transform-origin: left;
  opacity: 0;
}

.mdc-tab-indicator__content--underline {
  align-self: flex-end;
  box-sizing: border-box;
  width: 100%;
  border-top-style: solid;
}

.mdc-tab-indicator--active .mdc-tab-indicator__content {
  opacity: 1;
}

._mat-animation-noopable .mdc-tab-indicator__content, .mdc-tab-indicator--no-transition .mdc-tab-indicator__content {
  transition: none;
}

.mat-mdc-tab-ripple.mat-mdc-tab-ripple {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  pointer-events: none;
}

.mat-mdc-tab {
  -webkit-tap-highlight-color: transparent;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-decoration: none;
  background: none;
  height: var(--mat-tab-container-height, 48px);
  font-family: var(--mat-tab-label-text-font, var(--mat-sys-title-small-font));
  font-size: var(--mat-tab-label-text-size, var(--mat-sys-title-small-size));
  letter-spacing: var(--mat-tab-label-text-tracking, var(--mat-sys-title-small-tracking));
  line-height: var(--mat-tab-label-text-line-height, var(--mat-sys-title-small-line-height));
  font-weight: var(--mat-tab-label-text-weight, var(--mat-sys-title-small-weight));
}
.mat-mdc-tab.mdc-tab {
  flex-grow: 0;
}
.mat-mdc-tab .mdc-tab-indicator__content--underline {
  border-color: var(--mat-tab-active-indicator-color, var(--mat-sys-primary));
  border-top-width: var(--mat-tab-active-indicator-height, 2px);
  border-radius: var(--mat-tab-active-indicator-shape, 0);
}
.mat-mdc-tab:hover .mdc-tab__text-label {
  color: var(--mat-tab-inactive-hover-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab:focus .mdc-tab__text-label {
  color: var(--mat-tab-inactive-focus-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab.mdc-tab--active .mdc-tab__text-label {
  color: var(--mat-tab-active-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab.mdc-tab--active .mdc-tab__ripple::before,
.mat-mdc-tab.mdc-tab--active .mat-ripple-element {
  background-color: var(--mat-tab-active-ripple-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab.mdc-tab--active:hover .mdc-tab__text-label {
  color: var(--mat-tab-active-hover-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab.mdc-tab--active:hover .mdc-tab-indicator__content--underline {
  border-color: var(--mat-tab-active-hover-indicator-color, var(--mat-sys-primary));
}
.mat-mdc-tab.mdc-tab--active:focus .mdc-tab__text-label {
  color: var(--mat-tab-active-focus-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab.mdc-tab--active:focus .mdc-tab-indicator__content--underline {
  border-color: var(--mat-tab-active-focus-indicator-color, var(--mat-sys-primary));
}
.mat-mdc-tab.mat-mdc-tab-disabled {
  opacity: 0.4;
  pointer-events: none;
}
.mat-mdc-tab.mat-mdc-tab-disabled .mdc-tab__content {
  pointer-events: none;
}
.mat-mdc-tab.mat-mdc-tab-disabled .mdc-tab__ripple::before,
.mat-mdc-tab.mat-mdc-tab-disabled .mat-ripple-element {
  background-color: var(--mat-tab-disabled-ripple-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-tab .mdc-tab__ripple::before {
  content: "";
  display: block;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  opacity: 0;
  pointer-events: none;
  background-color: var(--mat-tab-inactive-ripple-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab .mdc-tab__text-label {
  color: var(--mat-tab-inactive-label-text-color, var(--mat-sys-on-surface));
  display: inline-flex;
  align-items: center;
}
.mat-mdc-tab .mdc-tab__content {
  position: relative;
  pointer-events: auto;
}
.mat-mdc-tab:hover .mdc-tab__ripple::before {
  opacity: 0.04;
}
.mat-mdc-tab.cdk-program-focused .mdc-tab__ripple::before, .mat-mdc-tab.cdk-keyboard-focused .mdc-tab__ripple::before {
  opacity: 0.12;
}
.mat-mdc-tab .mat-ripple-element {
  opacity: 0.12;
  background-color: var(--mat-tab-inactive-ripple-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab-group.mat-mdc-tab-group-stretch-tabs > .mat-mdc-tab-header .mat-mdc-tab {
  flex-grow: 1;
}

.mat-mdc-tab-group {
  display: flex;
  flex-direction: column;
  max-width: 100%;
}
.mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header, .mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header-pagination {
  background-color: var(--mat-tab-background-color);
}
.mat-mdc-tab-group.mat-tabs-with-background.mat-primary > .mat-mdc-tab-header .mat-mdc-tab .mdc-tab__text-label {
  color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-tabs-with-background.mat-primary > .mat-mdc-tab-header .mdc-tab-indicator__content--underline {
  border-color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-tabs-with-background:not(.mat-primary) > .mat-mdc-tab-header .mat-mdc-tab:not(.mdc-tab--active) .mdc-tab__text-label {
  color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-tabs-with-background:not(.mat-primary) > .mat-mdc-tab-header .mat-mdc-tab:not(.mdc-tab--active) .mdc-tab-indicator__content--underline {
  border-color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header .mat-mdc-tab-header-pagination-chevron,
.mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header .mat-focus-indicator::before, .mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header-pagination .mat-mdc-tab-header-pagination-chevron,
.mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header-pagination .mat-focus-indicator::before {
  border-color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header .mat-ripple-element, .mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header .mdc-tab__ripple::before, .mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header-pagination .mat-ripple-element, .mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header-pagination .mdc-tab__ripple::before {
  background-color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header .mat-mdc-tab-header-pagination-chevron, .mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header-pagination .mat-mdc-tab-header-pagination-chevron {
  color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-mdc-tab-group-inverted-header {
  flex-direction: column-reverse;
}
.mat-mdc-tab-group.mat-mdc-tab-group-inverted-header .mdc-tab-indicator__content--underline {
  align-self: flex-start;
}

.mat-mdc-tab-body-wrapper {
  position: relative;
  overflow: hidden;
  display: flex;
  transition: height 500ms cubic-bezier(0.35, 0, 0.25, 1);
}
.mat-mdc-tab-body-wrapper._mat-animation-noopable {
  transition: none !important;
  animation: none !important;
}
`],encapsulation:2})}return a})(),We=class{index;tab};var Tn=(()=>{class a{static \u0275fac=function(t){return new(t||a)};static \u0275mod=K({type:a});static \u0275inj=X({imports:[te]})}return a})();function Xe(a){return`${a.origen}:${a.folioQueja}`}var In=()=>[],pa=a=>({$implicit:a,fuente:"MANUAL"}),ha=(a,r)=>({$implicit:a,fuente:r}),_a=(a,r)=>r.id;function Sn(a,r){return this.clave(r)}function fa(a,r){a&1&&(o(0,"p",12),l(1," Todav\xEDa no hay antecedentes guardados. M\xE1rcalos en la b\xFAsqueda manual o en la del modelo y usa \u201CGuardar seleccionados\u201D. "),s())}function va(a,r){if(a&1&&l(0),a&2){let e=u().$implicit;A(" \xB7 ",e.similitud,"% ")}}function ya(a,r){if(a&1){let e=S();o(0,"button",36),b("click",function(){h(e);let n=u().$implicit,i=u(2);return _(i.abrirExpediente(n.folioPrimerContacto))}),o(1,"mat-icon"),l(2,"open_in_new"),s()()}}function xa(a,r){if(a&1){let e=S();o(0,"div",27)(1,"div",28),b("click",function(){let n=h(e).$implicit,i=u(2);return _(i.verDetalle(n))}),o(2,"strong"),l(3),s(),o(4,"span",29),l(5),s(),o(6,"span",30),l(7),v(8,va,1,1),s(),o(9,"span",31),l(10),s(),o(11,"span",32),l(12),s()(),o(13,"div",33),v(14,ya,3,0,"button",34),o(15,"button",35),b("click",function(){let n=h(e).$implicit,i=u(2);return _(i.quitarGuardado(n))}),o(16,"mat-icon"),l(17,"delete_outline"),s()()()()}if(a&2){let e=r.$implicit,t=u(2);c(3),w(e.folioQueja),c(),f("historico",e.origen==="HISTORICO"),c(),A(" ",t.etiquetaOrigen(e.origen)," "),c(2),A("",t.etiquetaFuente(e.fuente)," "),c(),y(e.similitud!=null?8:-1),c(2),w(e.asunto||"Sin asunto"),c(2),ut(" Quejoso: ",e.nombreQuejoso||"\u2014"," \xB7 Denunciado: ",e.nombreDenunciado||"\u2014"," \xB7 Guard\xF3 ",e.analistaNombre||"\u2014",", ",t.formatearFecha(e.fechaRegistro)," "),c(2),y(e.folioPrimerContacto?14:-1)}}function ka(a,r){if(a&1&&(o(0,"div",13),O(1,xa,18,12,"div",27,_a),s()),a&2){let e=u();c(),B(e.guardados)}}function Ca(a,r){a&1&&(o(0,"mat-icon",37),l(1,"person_search"),s(),l(2," B\xFAsqueda manual "))}function wa(a,r){a&1&&I(0,"mat-progress-bar",23)}function Ta(a,r){if(a&1&&(o(0,"div",24)(1,"mat-icon"),l(2,"error_outline"),s(),o(3,"span"),l(4),s()()),a&2){let e=u();c(4),w(e.errorManual)}}function Ma(a,r){if(a&1&&(o(0,"div",38)(1,"mat-icon"),l(2,"info"),s(),o(3,"span"),l(4),s()()),a&2){let e=r.$implicit;c(4),w(e)}}function Ia(a,r){a&1&&De(0)}function Sa(a,r){if(a&1&&z(0,Ia,1,0,"ng-container",41),a&2){let e=r.$implicit;u(2);let t=L(69);p("ngTemplateOutlet",t)("ngTemplateOutletContext",bt(2,pa,e))}}function Ea(a,r){a&1&&(o(0,"mat-card",40)(1,"mat-icon"),l(2,"search_off"),s(),o(3,"p"),l(4,"No se encontraron quejas con esos nombres."),s()())}function Pa(a,r){if(a&1&&(O(0,Ma,5,1,"div",38,$),o(2,"div",39),O(3,Sa,1,4,"ng-container",null,Sn,!0,Ea,5,0,"mat-card",40),s()),a&2){let e=u();B(e.manual.avisos??Be(1,In)),c(3),B(e.manual.resultados)}}function Aa(a,r){a&1&&(o(0,"mat-icon",37),l(1,"psychology"),s(),l(2," Con el modelo "))}function Da(a,r){a&1&&(o(0,"mat-card",25)(1,"mat-icon",42),l(2,"psychology"),s(),o(3,"div")(4,"strong"),l(5,"Buscando antecedentes\u2026"),s(),o(6,"p"),l(7,"Comparando la narrativa de la queja con otras quejas."),s(),I(8,"mat-progress-bar",23),s()())}function Ra(a,r){if(a&1){let e=S();o(0,"mat-card",25)(1,"mat-icon",43),l(2,"error_outline"),s(),o(3,"div")(4,"strong"),l(5,"No fue posible completar la b\xFAsqueda."),s(),o(6,"p"),l(7,"Intenta de nuevo con \u201CVolver a buscar\u201D."),s()(),o(8,"button",4),b("click",function(){h(e);let n=u();return _(n.buscarConModelo())}),o(9,"mat-icon"),l(10,"refresh"),s(),l(11," Volver a buscar "),s()()}}function Oa(a,r){if(a&1&&(o(0,"div",38)(1,"mat-icon"),l(2,"info"),s(),o(3,"span"),l(4),s()()),a&2){let e=r.$implicit;c(4),w(e)}}function Ba(a,r){if(a&1){let e=S();o(0,"mat-slide-toggle",56),ce("ngModelChange",function(n){h(e);let i=u(2);return le(i.soloMismoQuejoso,n)||(i.soloMismoQuejoso=n),_(n)}),l(1,"Solo del mismo quejoso"),s()}if(a&2){let e=u(2);se("ngModel",e.soloMismoQuejoso)}}function La(a,r){a&1&&De(0)}function Fa(a,r){if(a&1&&z(0,La,1,0,"ng-container",41),a&2){let e=r.$implicit,t=u(2),n=L(69);p("ngTemplateOutlet",n)("ngTemplateOutletContext",gt(2,ha,e,t.modelo.motor))}}function za(a,r){a&1&&l(0," Ning\xFAn antecedente cumple los filtros seleccionados. ")}function ja(a,r){a&1&&l(0," No hay quejas de la misma persona con hechos parecidos. ")}function Va(a,r){a&1&&l(0," No se encontraron quejas del mismo quejoso ni del mismo denunciado. ")}function Na(a,r){a&1&&l(0," No se encontraron quejas con hechos parecidos. ")}function Qa(a,r){if(a&1&&(o(0,"mat-card",40)(1,"mat-icon"),l(2,"verified"),s(),o(3,"p"),v(4,za,1,0)(5,ja,1,0)(6,Va,1,0)(7,Na,1,0),s()()),a&2){let e=u(2);c(4),y(e.lista(e.categoria).length>0?4:e.categoria==="fuertes"?5:e.categoria==="involucrados"?6:7)}}function Ga(a,r){if(a&1){let e=S();O(0,Oa,5,1,"div",38,$),o(2,"div",44)(3,"mat-icon"),l(4),s(),o(5,"span")(6,"strong"),l(7),s(),l(8),s(),o(9,"button",45),b("click",function(){h(e);let n=u();return _(n.buscarConModelo())}),o(10,"mat-icon"),l(11,"refresh"),s(),l(12," Volver a buscar "),s()(),o(13,"div",46)(14,"button",47),b("click",function(){h(e);let n=u();return _(n.categoria="fuertes")}),o(15,"span",48),l(16),s(),o(17,"span",49)(18,"strong"),l(19,"Coincidencias fuertes"),s(),o(20,"small"),l(21,"Misma persona y hechos parecidos: revisar primero"),s()()(),o(22,"button",50),b("click",function(){h(e);let n=u();return _(n.categoria="involucrados")}),o(23,"span",48),l(24),s(),o(25,"span",49)(26,"strong"),l(27,"Por involucrados"),s(),o(28,"small"),l(29,"Mismo quejoso y/o denunciado"),s()()(),o(30,"button",50),b("click",function(){h(e);let n=u();return _(n.categoria="hechos")}),o(31,"span",48),l(32),s(),o(33,"span",49)(34,"strong"),l(35,"Por hechos"),s(),o(36,"small"),l(37,"Narrativa parecida, aunque sean otras personas"),s()()()(),o(38,"div",51)(39,"div",52),v(40,Ba,2,1,"mat-slide-toggle",53),o(41,"mat-button-toggle-group",54),ce("ngModelChange",function(n){h(e);let i=u();return le(i.similitudMinima,n)||(i.similitudMinima=n),_(n)}),o(42,"mat-button-toggle",55),l(43,"Todas"),s(),o(44,"mat-button-toggle",55),l(45,"\u2265 40%"),s(),o(46,"mat-button-toggle",55),l(47,"\u2265 70%"),s()()()(),o(48,"div",39),O(49,Fa,1,5,"ng-container",null,Sn,!0,Qa,8,1,"mat-card",40),s()}if(a&2){let e=u();B(e.modelo.avisos??Be(23,In)),c(2),f("provisional",e.esProvisional),c(2),w(e.esProvisional?"construction":"psychology"),c(3),A("",e.esProvisional?"Motor provisional":"Modelo de b\xFAsqueda","."),c(),A(" ",e.modelo.descripcionMotor," Los resultados apoyan la revisi\xF3n: no determinan si una queja est\xE1 duplicada. "),c(6),f("activa",e.categoria==="fuertes"),x("aria-selected",e.categoria==="fuertes"),c(2),w(e.lista("fuertes").length),c(6),f("activa",e.categoria==="involucrados"),x("aria-selected",e.categoria==="involucrados"),c(2),w(e.lista("involucrados").length),c(6),f("activa",e.categoria==="hechos"),x("aria-selected",e.categoria==="hechos"),c(2),w(e.lista("hechos").length),c(8),y(e.categoria==="involucrados"?40:-1),c(),se("ngModel",e.similitudMinima),c(),p("value",0),c(2),p("value",40),c(2),p("value",70),c(3),B(e.resultadosModelo)}}function qa(a,r){if(a&1){let e=S();o(0,"div",26)(1,"mat-icon"),l(2,"checklist"),s(),o(3,"span")(4,"strong"),l(5),s(),l(6),s(),o(7,"button",57),b("click",function(){h(e);let n=u();return _(n.limpiarSeleccion())}),l(8,"Limpiar"),s(),o(9,"button",58),b("click",function(){h(e);let n=u();return _(n.guardarSeleccion())}),o(10,"mat-icon"),l(11,"bookmark_add"),s(),l(12," Guardar seleccionados "),s()()}if(a&2){let e=u();c(5),w(e.seleccion.size),c(),A(" seleccionado",e.seleccion.size===1?"":"s"," (de cualquier pesta\xF1a) "),c(),p("disabled",e.guardando),c(2),p("disabled",e.guardando)}}function Ha(a,r){a&1&&(o(0,"mat-icon",61),l(1,"bookmark_added"),s())}function Wa(a,r){if(a&1){let e=S();o(0,"mat-checkbox",74),b("change",function(){h(e);let n=u(),i=n.$implicit,d=n.fuente,M=u();return _(M.alternarSeleccion(i,d))}),s()}if(a&2){let e=u().$implicit,t=u();p("checked",t.estaSeleccionado(e))}}function $a(a,r){if(a&1&&(o(0,"div",63)(1,"span",75),l(2),s(),o(3,"div",76),I(4,"div"),s(),o(5,"span",77),l(6),s()()),a&2){let e=u().$implicit,t=u();c(2),A("",e.similitud,"%"),c(2),xe("width",e.similitud,"%"),c(2),A("Similitud ",t.nivel(e.similitud))}}function Ua(a,r){if(a&1&&(o(0,"span",68)(1,"mat-icon"),l(2,"priority_high"),s(),l(3),s()),a&2){let e=u().$implicit;c(3),w(e.razonCoincidencia)}}function Za(a,r){if(a&1&&(o(0,"p"),l(1),s()),a&2){let e=u().$implicit;c(),w(e.extracto)}}function Xa(a,r){if(a&1&&(o(0,"span",71),l(1),s()),a&2){let e=r.$implicit;f("fuerte",e.startsWith("Quejoso:")||e.startsWith("Denunciado:")||e.startsWith("Identificaci\xF3n")||e.startsWith("Correo"))("por-verificar",e.includes("por verificar")),c(),w(e)}}function Ka(a,r){if(a&1&&(o(0,"span",71),l(1),s()),a&2){let e=u().$implicit;c(),A("Hechos con ",e.diasDiferencia," d\xEDas de diferencia")}}function Ya(a,r){if(a&1){let e=S();o(0,"button",4),b("click",function(){h(e);let n=u().$implicit,i=u();return _(i.abrirExpediente(n.folioPrimerContacto))}),o(1,"mat-icon"),l(2,"open_in_new"),s(),l(3," Ver expediente "),s()}}function Ja(a,r){if(a&1){let e=S();o(0,"mat-card",59)(1,"div",60),v(2,Ha,2,0,"mat-icon",61)(3,Wa,1,1,"mat-checkbox",62),s(),v(4,$a,7,4,"div",63),o(5,"div",64)(6,"div",65)(7,"strong",66),b("click",function(){let n=h(e).$implicit,i=u();return _(i.verDetalle(n))}),l(8),s(),o(9,"span",29),l(10),s(),o(11,"span",67),l(12),s()(),o(13,"span",32),l(14),s(),o(15,"span",32),l(16),s(),v(17,Ua,4,1,"span",68),v(18,Za,2,1,"p"),o(19,"div",69),O(20,Xa,2,5,"span",70,$),v(22,Ka,2,1,"span",71),s()(),o(23,"div",72)(24,"button",4),b("click",function(){let n=h(e).$implicit,i=u();return _(i.verDetalle(n))}),o(25,"mat-icon"),l(26,"visibility"),s(),l(27," Ver detalle "),s(),o(28,"button",4),b("click",function(){let n=h(e).$implicit,i=u();return _(i.verResumen(n))}),o(29,"mat-icon"),l(30,"summarize"),s(),l(31," Resumen "),s(),v(32,Ya,4,0,"button",73),s()()}if(a&2){let e=r.$implicit,t=r.fuente,n=u();f("manual",t==="MANUAL")("seleccionado",n.estaSeleccionado(e)),x("data-nivel",t==="MANUAL"?null:n.nivel(e.similitud)),c(2),y(n.estaGuardado(e)?2:3),c(2),y(t!=="MANUAL"?4:-1),c(4),w(e.asunto||"Sin asunto"),c(),f("historico",e.origen==="HISTORICO"),c(),A(" ",n.etiquetaOrigen(e.origen)," "),c(2),w(n.etiquetaQueja(e.estatus)),c(2),Oe(" ",e.folioQueja," \xB7 ",n.formatearFecha(e.fecha)," \xB7 ",e.unidadAcademica||"Sin unidad"," "),c(2),Re(" Quejoso: ",e.nombreQuejoso||"\u2014"," \xB7 Denunciado: ",e.nombreDenunciado||"\u2014"," "),c(),y(e.razonCoincidencia?17:-1),c(),y(e.extracto?18:-1),c(2),B(e.coincidencias),c(2),y(e.diasDiferencia!=null?22:-1),c(10),y(e.folioPrimerContacto?32:-1)}}var ei={RECIBIDA:"Recibida",EN_VALIDACION:"En validaci\xF3n",RECHAZADA:"Rechazada",CORREGIDA:"Corregida",CANCELADA:"Cancelada",TURNADA:"Turnada",EN_ANALISIS:"En an\xE1lisis",PROCEDENTE:"Procedente",IMPROCEDENTE:"Improcedente",REMITIDA:"Remitida",CONCLUIDA:"Concluida"},ti={MANUAL:"B\xFAsqueda manual",MODELO:"Modelo",REGLAS_PROVISIONAL:"Motor provisional"},Mn=class a{constructor(r,e,t,n,i,d,M){this.route=r;this.router=e;this.antecedentesService=t;this.expedienteService=n;this.dialog=i;this.snackBar=d;this.cdr=M;this.folio=this.route.snapshot.paramMap.get("id")??""}route;router;antecedentesService;expedienteService;dialog;snackBar;cdr;folio="";expediente;nombreQuejoso="";nombreDenunciado="";manual;buscandoManual=!1;errorManual="";modelo;buscandoModelo=!1;errorModelo=!1;soloMismoQuejoso=!1;similitudMinima=0;categoria="involucrados";seleccion=new Map;guardados=[];guardando=!1;formatearFecha=Qt;ngOnInit(){this.expedienteService.obtenerPorFolio(this.folio).subscribe({next:r=>{this.expediente=this.expedienteService.mapearADetalle(r),this.cdr.detectChanges()}}),this.cargarGuardados(),this.buscarConModelo()}usarQuejosoDeLaQueja(){this.nombreQuejoso=this.expediente?.quejoso?.nombre??""}buscarManual(){if(!this.nombreQuejoso.trim()&&!this.nombreDenunciado.trim()){this.errorManual="Escribe el nombre del quejoso, del denunciado o de ambos.";return}this.buscandoManual=!0,this.errorManual="",this.cdr.detectChanges(),this.antecedentesService.buscarManual(this.folio,this.nombreQuejoso,this.nombreDenunciado).subscribe({next:r=>{this.manual=r,this.buscandoManual=!1,this.cdr.detectChanges()},error:r=>{this.buscandoManual=!1,this.errorManual=we(r,"No fue posible completar la b\xFAsqueda."),this.cdr.detectChanges()}})}buscarConModelo(){this.buscandoModelo=!0,this.errorModelo=!1,this.cdr.detectChanges(),this.antecedentesService.buscar(this.folio).subscribe({next:r=>{this.modelo=r,this.categoria=this.lista("fuertes").length>0?"fuertes":this.lista("involucrados").length>0?"involucrados":"hechos",this.buscandoModelo=!1,this.cdr.detectChanges()},error:()=>{this.buscandoModelo=!1,this.errorModelo=!0,this.cdr.detectChanges()}})}lista(r){switch(r){case"fuertes":return this.modelo?.coincidenciasFuertes??[];case"hechos":return this.modelo?.porHechos??[];default:return this.modelo?.porInvolucrados??this.modelo?.resultados??[]}}get resultadosModelo(){return this.lista(this.categoria).filter(r=>(this.categoria!=="involucrados"||!this.soloMismoQuejoso||r.mismoQuejoso)&&r.similitud>=this.similitudMinima)}get esProvisional(){return this.modelo?.motor==="REGLAS_PROVISIONAL"}clave(r){return Xe(r)}estaSeleccionado(r){return this.seleccion.has(this.clave(r))}estaGuardado(r){let e=this.clave(r);return this.guardados.some(t=>Xe(t)===e)}alternarSeleccion(r,e){let t=this.clave(r);this.seleccion.has(t)?this.seleccion.delete(t):this.seleccion.set(t,{antecedente:r,fuente:e})}limpiarSeleccion(){this.seleccion.clear()}guardarSeleccion(){if(this.seleccion.size===0)return;let r=[...this.seleccion.values()].map(({antecedente:e,fuente:t})=>({origen:e.origen,folioQueja:e.folioQueja,fuente:t,similitud:t==="MANUAL"?null:e.similitud,asunto:e.asunto,fecha:e.fecha,nombreQuejoso:e.nombreQuejoso,nombreDenunciado:e.nombreDenunciado,unidadAcademica:e.unidadAcademica,estatus:e.estatus,folioPrimerContacto:e.folioPrimerContacto,extracto:e.extracto,descripcion:e.descripcion,resultado:e.resultado}));this.guardando=!0,this.antecedentesService.guardar(this.folio,r).subscribe({next:e=>{this.guardados=e,this.guardando=!1;let t=this.seleccion.size;this.seleccion.clear(),this.cdr.detectChanges(),this.snackBar.open(`${t} antecedente${t===1?"":"s"} guardado${t===1?"":"s"} en el expediente.`,"Cerrar",{duration:3e3})},error:e=>{this.guardando=!1,this.cdr.detectChanges(),this.snackBar.open(we(e,"No fue posible guardar los antecedentes."),"Cerrar",{duration:3500})}})}quitarGuardado(r){r.id&&confirm(`\xBFQuitar ${r.folioQueja} de los antecedentes del expediente?`)&&this.antecedentesService.quitar(this.folio,r.id).subscribe({next:()=>{this.guardados=this.guardados.filter(e=>e.id!==r.id),this.cdr.detectChanges()},error:e=>{this.snackBar.open(we(e,"No fue posible quitar el antecedente."),"Cerrar",{duration:3500})}})}cargarGuardados(){this.antecedentesService.guardados(this.folio).subscribe({next:r=>{this.guardados=r,this.cdr.detectChanges()}})}verResumenQuejaAnalizada(){this.abrirResumen({folio:this.expediente?.folioOrigen??this.folio,asunto:this.expediente?.asunto,texto:this.expediente?.narrativa})}verResumen(r){this.abrirResumen({folio:r.folioQueja,asunto:r.asunto,texto:r.descripcion??r.extracto})}verDetalle(r){this.dialog.open(mn,{width:"720px",data:r})}abrirResumen(r){this.dialog.open(dn,{width:"640px",data:r})}nivel(r){return r>=70?"alta":r>=40?"media":"baja"}etiquetaQueja(r){return r?ei[r]??r:"Sin estatus"}etiquetaOrigen(r){return r==="HISTORICO"?"Hist\xF3rico":"Sistema"}etiquetaFuente(r){return ti[r]??r}abrirExpediente(r){r&&this.router.navigate(["/expediente",r])}volver(){this.router.navigate(["/expediente",this.folio])}static \u0275fac=function(e){return new(e||a)(N(_t),N(ft),N(bn),N(un),N(rn),N(an),N(D))};static \u0275cmp=P({type:a,selectors:[["app-antecedentes"]],decls:70,vars:16,consts:[["tarjeta",""],[1,"page"],[1,"page-header"],[1,"header-actions"],["mat-stroked-button","",3,"click"],[1,"card","referencia"],[1,"referencia-icon"],[1,"referencia-texto"],[1,"eyebrow"],[1,"card","guardados"],[1,"guardados-titulo"],[1,"contador"],[1,"ayuda"],[1,"lista-guardados"],["animationDuration","0ms",1,"pestanas"],["mat-tab-label",""],[1,"tab-contenido"],[1,"form-manual",3,"ngSubmit"],["appearance","outline"],["matInput","","name","quejoso","autocomplete","off",3,"ngModelChange","ngModel"],["mat-icon-button","","matSuffix","","type","button","matTooltip","Usar el quejoso de esta queja",3,"click"],["matInput","","name","denunciado","autocomplete","off",3,"ngModelChange","ngModel"],["mat-flat-button","","type","submit",1,"primary-btn",3,"disabled"],["mode","indeterminate"],[1,"aviso","error"],[1,"card","estado-busqueda"],[1,"barra-seleccion"],[1,"guardado"],["matTooltip","Ver detalle de la queja",1,"guardado-datos","clicable",3,"click"],[1,"chip","origen"],[1,"chip"],[1,"guardado-asunto"],[1,"meta"],[1,"guardado-acciones"],["mat-icon-button","","matTooltip","Ver expediente"],["mat-icon-button","","matTooltip","Quitar de los antecedentes",3,"click"],["mat-icon-button","","matTooltip","Ver expediente",3,"click"],[1,"tab-icon"],[1,"aviso"],[1,"resultados"],[1,"card","vacio"],[4,"ngTemplateOutlet","ngTemplateOutletContext"],[1,"pulso"],[1,"error-icon"],[1,"motor"],["mat-stroked-button","",1,"motor-boton",3,"click"],["role","tablist","aria-label","Tipo de antecedente",1,"categorias"],["type","button","role","tab",1,"categoria","fuertes",3,"click"],[1,"numero"],[1,"categoria-texto"],["type","button","role","tab",1,"categoria",3,"click"],[1,"barra"],[1,"filtros"],[3,"ngModel"],["aria-label","Similitud m\xEDnima",3,"ngModelChange","ngModel"],[3,"value"],[3,"ngModelChange","ngModel"],["mat-stroked-button","",3,"click","disabled"],["mat-flat-button","",1,"primary-btn",3,"click","disabled"],[1,"card","resultado"],[1,"marca"],["matTooltip","Ya est\xE1 guardado en el expediente",1,"ya-guardado"],["aria-label","Seleccionar como antecedente",3,"checked"],[1,"similitud"],[1,"contenido"],[1,"titulo"],["matTooltip","Ver detalle de la queja",1,"clicable",3,"click"],[1,"estatus-queja"],[1,"razon"],[1,"coincidencias"],[1,"coincidencia",3,"fuerte","por-verificar"],[1,"coincidencia"],[1,"acciones"],["mat-stroked-button",""],["aria-label","Seleccionar como antecedente",3,"change","checked"],[1,"porcentaje"],[1,"barra-similitud"],[1,"nivel"]],template:function(e,t){if(e&1){let n=S();o(0,"section",1)(1,"div",2)(2,"div")(3,"h2"),l(4,"B\xFAsqueda de antecedentes"),s(),o(5,"p"),l(6),s()(),o(7,"div",3)(8,"button",4),b("click",function(){return t.volver()}),o(9,"mat-icon"),l(10,"arrow_back"),s(),l(11," Volver al expediente "),s()()(),o(12,"mat-card",5)(13,"mat-icon",6),l(14,"description"),s(),o(15,"div",7)(16,"span",8),l(17,"Queja analizada"),s(),o(18,"strong"),l(19),s(),o(20,"p"),l(21),s()(),o(22,"button",4),b("click",function(){return t.verResumenQuejaAnalizada()}),o(23,"mat-icon"),l(24,"summarize"),s(),l(25," Resumen "),s()(),o(26,"mat-card",9)(27,"div",10)(28,"mat-icon"),l(29,"bookmarks"),s(),o(30,"strong"),l(31,"Antecedentes guardados en el expediente"),s(),o(32,"span",11),l(33),s()(),v(34,fa,2,0,"p",12)(35,ka,3,0,"div",13),s(),o(36,"mat-tab-group",14)(37,"mat-tab"),z(38,Ca,3,0,"ng-template",15),o(39,"div",16)(40,"form",17),b("ngSubmit",function(){return t.buscarManual()}),o(41,"mat-form-field",18)(42,"mat-label"),l(43,"Nombre del quejoso"),s(),o(44,"input",19),ce("ngModelChange",function(d){return h(n),le(t.nombreQuejoso,d)||(t.nombreQuejoso=d),_(d)}),s(),o(45,"button",20),b("click",function(){return t.usarQuejosoDeLaQueja()}),o(46,"mat-icon"),l(47,"person"),s()()(),o(48,"mat-form-field",18)(49,"mat-label"),l(50,"Nombre del denunciado"),s(),o(51,"input",21),ce("ngModelChange",function(d){return h(n),le(t.nombreDenunciado,d)||(t.nombreDenunciado=d),_(d)}),s()(),o(52,"button",22)(53,"mat-icon"),l(54,"search"),s(),l(55," Buscar "),s()(),o(56,"p",12),l(57," Busca en las quejas del sistema y en los casos hist\xF3ricos. No importan may\xFAsculas ni acentos; puedes escribir solo una parte del nombre. "),s(),v(58,wa,1,0,"mat-progress-bar",23)(59,Ta,5,1,"div",24)(60,Pa,6,2),s()(),o(61,"mat-tab"),z(62,Aa,3,0,"ng-template",15),o(63,"div",16),v(64,Da,9,0,"mat-card",25)(65,Ra,12,0,"mat-card",25)(66,Ga,52,24),s()()(),v(67,qa,13,4,"div",26),s(),z(68,Ja,33,21,"ng-template",null,0,pt)}e&2&&(f("con-seleccion",t.seleccion.size>0),c(6),Oe(" Expediente ",t.folio," \xB7 Queja ",t.expediente==null?null:t.expediente.folioOrigen," \xB7 ",(t.expediente==null?null:t.expediente.asunto)||"Sin asunto"," "),c(13),Re("",t.expediente==null||t.expediente.quejoso==null?null:t.expediente.quejoso.nombre," \xB7 ",t.expediente==null||t.expediente.quejoso==null?null:t.expediente.quejoso.unidadAcademica),c(2),w(t.expediente==null?null:t.expediente.narrativa),c(12),w(t.guardados.length),c(),y(t.guardados.length===0?34:35),c(10),se("ngModel",t.nombreQuejoso),c(7),se("ngModel",t.nombreDenunciado),c(),p("disabled",t.buscandoManual),c(6),y(t.buscandoManual?58:t.errorManual?59:t.manual?60:-1),c(6),y(t.buscandoModelo?64:t.errorModelo?65:t.modelo?66:-1),c(3),y(t.seleccion.size>0?67:-1))},dependencies:[ht,Ft,Lt,Pt,Dt,Rt,Bt,Ot,yt,vt,It,Mt,wt,Et,St,gn,je,_n,Qe,Ie,cn,ln,nn,tn,Tn,Ue,Ze,wn,en,Jt,Gt,Nt,jt,Vt,Kt,Xt,sn,on],styles:[".page[_ngcontent-%COMP%]{max-width:1280px}.page-header[_ngcontent-%COMP%]{margin-bottom:var(--space-5);display:flex;justify-content:space-between;align-items:center;gap:var(--space-5)}.page-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{margin:0;color:var(--guinda);font-size:28px;font-weight:800}.page-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-1) 0 0;color:var(--texto-suave)}.header-actions[_ngcontent-%COMP%]{display:flex;gap:var(--space-2)}button[_ngcontent-%COMP%]{border-radius:8px!important;font-weight:700!important}.primary-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important}.card[_ngcontent-%COMP%]{border-radius:14px;box-shadow:0 2px 8px #0f172a14;padding:var(--space-4);background:#fff}.eyebrow[_ngcontent-%COMP%]{display:block;color:var(--guinda);text-transform:uppercase;font-size:var(--font-size-xs);font-weight:900;letter-spacing:.05em}.referencia[_ngcontent-%COMP%]{display:flex;flex-direction:row;gap:var(--space-3);margin-bottom:var(--space-4);background:var(--guinda-suave)}.referencia-icon[_ngcontent-%COMP%]{color:var(--guinda)}.referencia[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-1) 0 0;color:var(--texto);font-size:var(--font-size-sm)}.estado-busqueda[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:center;gap:var(--space-4);padding:var(--space-5)}.estado-busqueda[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{flex:1}.estado-busqueda[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-1) 0 var(--space-3);color:var(--texto-suave)}.estado-busqueda[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:40px;width:40px;height:40px;color:var(--guinda)}.estado-busqueda[_ngcontent-%COMP%]   .error-icon[_ngcontent-%COMP%]{color:var(--peligro)}.pulso[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_pulso 1.2s ease-in-out infinite}@keyframes _ngcontent-%COMP%_pulso{50%{opacity:.35}}.motor[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:var(--space-2);padding:var(--space-3) var(--space-4);border-radius:10px;background:#e0f2fe;color:#075985;font-size:var(--font-size-sm);margin-bottom:var(--space-4)}.motor.provisional[_ngcontent-%COMP%]{background:#fff4e5;color:#7a4800}.categorias[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:var(--space-3);margin-bottom:var(--space-4)}.categoria[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) var(--space-4);border:2px solid var(--borde, #e5e7eb);border-radius:10px;background:#fff;text-align:left;cursor:pointer;font:inherit;color:var(--texto)}.categoria[_ngcontent-%COMP%]:hover{border-color:var(--guinda-suave)}.categoria.activa[_ngcontent-%COMP%]{border-color:var(--guinda);background:var(--guinda-suave)}.categoria[_ngcontent-%COMP%]:focus-visible{outline:3px solid var(--guinda);outline-offset:2px}.categoria-texto[_ngcontent-%COMP%]{display:grid;gap:2px}.categoria-texto[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:var(--texto-suave);font-size:var(--font-size-xs)}.razon[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-1);color:var(--guinda);font-size:var(--font-size-sm);font-weight:700}.razon[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:18px;width:18px;height:18px}.barra[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:var(--space-4);margin-bottom:var(--space-4)}.resumen[_ngcontent-%COMP%]{display:flex;gap:var(--space-5)}.resumen[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{display:flex;align-items:baseline;gap:var(--space-2);color:var(--texto-suave);font-size:var(--font-size-sm)}.numero[_ngcontent-%COMP%]{font-size:var(--font-size-2xl);font-weight:900;color:var(--guinda)}.filtros[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-4)}.resultados[_ngcontent-%COMP%]{display:grid;gap:var(--space-3)}.resultado[_ngcontent-%COMP%]{display:grid;grid-template-columns:32px 120px 1fr auto;gap:var(--space-4);align-items:start;border-left:5px solid var(--borde)}.resultado[data-nivel=alta][_ngcontent-%COMP%]{border-left-color:var(--guinda)}.resultado[data-nivel=media][_ngcontent-%COMP%]{border-left-color:var(--advertencia)}.similitud[_ngcontent-%COMP%]{display:grid;gap:var(--space-1)}.porcentaje[_ngcontent-%COMP%]{font-size:var(--font-size-2xl);font-weight:900;color:var(--negro-inst)}.barra-similitud[_ngcontent-%COMP%]{height:6px;border-radius:var(--radius-pill);background:#f1f1f3;overflow:hidden}.barra-similitud[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{height:100%;background:var(--texto-suave)}.resultado[data-nivel=alta][_ngcontent-%COMP%]   .barra-similitud[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{background:var(--guinda)}.resultado[data-nivel=media][_ngcontent-%COMP%]   .barra-similitud[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{background:var(--advertencia)}.nivel[_ngcontent-%COMP%]{font-size:var(--font-size-xs);color:var(--texto-suave);text-transform:capitalize}.contenido[_ngcontent-%COMP%]{min-width:0}.titulo[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-2)}.titulo[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:var(--font-size-md);color:var(--negro-inst)}.estatus-queja[_ngcontent-%COMP%]{padding:1px 8px;border-radius:var(--radius-pill);background:#f3f4f6;color:var(--texto-suave);font-size:var(--font-size-xs);font-weight:700}.meta[_ngcontent-%COMP%]{display:block;margin-top:2px;color:var(--texto-suave);font-size:var(--font-size-xs)}.contenido[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-2) 0;font-size:var(--font-size-sm);color:var(--texto)}.coincidencias[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;gap:var(--space-1)}.coincidencia[_ngcontent-%COMP%]{padding:2px 10px;border-radius:var(--radius-pill);background:#f3f4f6;color:var(--texto);font-size:var(--font-size-xs);font-weight:600}.coincidencia.fuerte[_ngcontent-%COMP%]{background:var(--guinda-suave);color:var(--guinda)}.coincidencia.por-verificar[_ngcontent-%COMP%]{background:#fff4e5;color:#7a4800}.acciones[_ngcontent-%COMP%]{display:grid;gap:var(--space-2);justify-items:end}.registrado[_ngcontent-%COMP%]{display:flex;align-items:center;gap:4px;color:var(--exito);font-size:var(--font-size-sm);font-weight:700}.vacio[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:center;gap:var(--space-3);color:var(--texto-suave)}.vacio[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{color:var(--exito)}.resultado.manual[_ngcontent-%COMP%]{grid-template-columns:32px 1fr auto}.resultado.seleccionado[_ngcontent-%COMP%]{outline:2px solid var(--guinda)}.marca[_ngcontent-%COMP%]{padding-top:4px}.ya-guardado[_ngcontent-%COMP%]{color:var(--exito)}.referencia[_ngcontent-%COMP%]{align-items:flex-start}.referencia-texto[_ngcontent-%COMP%]{flex:1;min-width:0}.guardados[_ngcontent-%COMP%]{margin-bottom:var(--space-4)}.guardados-titulo[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-2);color:var(--guinda)}.contador[_ngcontent-%COMP%]{min-width:24px;padding:0 8px;border-radius:var(--radius-pill);background:var(--guinda);color:#fff;font-size:var(--font-size-xs);font-weight:800;text-align:center}.lista-guardados[_ngcontent-%COMP%]{display:grid;gap:var(--space-2);margin-top:var(--space-3)}.guardado[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;gap:var(--space-3);padding:var(--space-2) var(--space-3);border:1px solid var(--borde);border-radius:10px}.guardado-datos[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;align-items:center;gap:4px var(--space-2);min-width:0}.guardado-asunto[_ngcontent-%COMP%]{color:var(--texto);font-size:var(--font-size-sm)}.guardado-datos[_ngcontent-%COMP%]   .meta[_ngcontent-%COMP%]{flex-basis:100%}.guardado-acciones[_ngcontent-%COMP%]{display:flex;flex-shrink:0}.ayuda[_ngcontent-%COMP%]{margin:var(--space-2) 0 0;color:var(--texto-suave);font-size:var(--font-size-sm)}.chip[_ngcontent-%COMP%]{padding:1px 8px;border-radius:var(--radius-pill);background:#f3f4f6;color:var(--texto-suave);font-size:var(--font-size-xs);font-weight:700}.chip.origen[_ngcontent-%COMP%]{background:#e0f2fe;color:#075985}.chip.origen.historico[_ngcontent-%COMP%]{background:#ede9fe;color:#5b21b6}.pestanas[_ngcontent-%COMP%]{margin-bottom:var(--space-4)}.tab-icon[_ngcontent-%COMP%]{margin-right:6px}.tab-contenido[_ngcontent-%COMP%]{padding-top:var(--space-4)}.form-manual[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;align-items:flex-start;gap:var(--space-3)}.form-manual[_ngcontent-%COMP%]   mat-form-field[_ngcontent-%COMP%]{flex:1 1 260px}.form-manual[_ngcontent-%COMP%]   button[type=submit][_ngcontent-%COMP%]{height:56px}.aviso[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:var(--space-2);padding:var(--space-3) var(--space-4);margin:var(--space-3) 0;border-radius:10px;background:#fff4e5;color:#7a4800;font-size:var(--font-size-sm)}.aviso.error[_ngcontent-%COMP%]{background:#fdecec;color:var(--peligro)}.motor-boton[_ngcontent-%COMP%]{margin-left:auto;flex-shrink:0}.titulo[_ngcontent-%COMP%]{flex-wrap:wrap}.page.con-seleccion[_ngcontent-%COMP%]{padding-bottom:88px}.barra-seleccion[_ngcontent-%COMP%]{position:sticky;bottom:var(--space-3);display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) var(--space-4);border-radius:14px;background:#fff;box-shadow:0 6px 24px #0f172a2e;border:1px solid var(--guinda);z-index:5}.barra-seleccion[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{flex:1}.barra-seleccion[_ngcontent-%COMP%] > mat-icon[_ngcontent-%COMP%]{color:var(--guinda)}@media(max-width:1000px){.page-header[_ngcontent-%COMP%]{flex-direction:column;align-items:flex-start}.resultado[_ngcontent-%COMP%], .resultado.manual[_ngcontent-%COMP%]{grid-template-columns:1fr}.referencia[_ngcontent-%COMP%]{flex-wrap:wrap}.acciones[_ngcontent-%COMP%]{justify-items:start}}.clicable[_ngcontent-%COMP%]{cursor:pointer}.titulo[_ngcontent-%COMP%]   strong.clicable[_ngcontent-%COMP%]:hover, .guardado-datos.clicable[_ngcontent-%COMP%]:hover   strong[_ngcontent-%COMP%]{color:var(--guinda);text-decoration:underline}"]})};export{Mn as Antecedentes};
