import{a as un,b as pn,c as fn}from"./chunk-224W6HMT.js";import{b as Te,c as on,f as _n,g as yn}from"./chunk-L5X7N3PP.js";import{a as wn,b as Cn}from"./chunk-UL2V62AU.js";import{a as Mt,b as Et}from"./chunk-E247WON3.js";import{a as Jt}from"./chunk-TVFLJJKH.js";import{a as Zt,b as Xt}from"./chunk-HTHRFMCI.js";import{a as en,b as hn,c as gn}from"./chunk-S4T445ON.js";import{C as xn,D as vn,a as tn,b as Ee,c as nn,d as an,g as rn,h as sn,j as ln,l as dn,o as cn,p as mn}from"./chunk-5ZJJJVUL.js";import{b as Vt,f as Ut,i as Qt,p as $t,t as Wt,v as qt,z as Kt}from"./chunk-HTFXFXSQ.js";import{J as Nt,P as Bt,S as jt,T as Ht,U as zt,V as Lt,W as Gt,Z as Yt,a as St,b as Me,e as Tt,g as Ot,i as Ft,k as At,v as It,x as Pt,y as ye}from"./chunk-AOZRCRFD.js";import{q as kt}from"./chunk-NMBGDNAI.js";import{$ as W,$a as B,Aa as N,Ab as he,Ac as Se,B as me,Ba as Ct,Bb as ge,C as ue,Cb as _e,D as ut,Db as j,Eb as d,Fb as l,Fc as J,G as pt,Gb as He,Gc as de,H as ft,Hb as Re,Ib as ze,Ic as v,Jb as vt,Jc as Rt,Kb as H,Lb as z,Mb as S,Nb as ie,Q as je,R as ht,Rb as L,S as ee,Tb as D,Ub as ae,Va as m,Vb as R,Wb as le,Xb as Le,Yb as M,Z,Zb as E,_a as pe,ba as s,bb as xt,cb as fe,cc as ke,dc as V,e as xe,eb as G,ec as bt,fc as u,ga as te,gc as U,ha as ne,hc as q,i as b,ia as gt,ib as F,j as re,jb as Y,jc as Dt,ka as _t,kb as f,l as lt,la as be,lc as Ve,m as dt,mc as Ue,n as ct,nb as _,nc as Qe,oa as $,ob as k,oc as x,p as se,pa as yt,r as mt,t as ve,ta as wt,u as K,wb as De,xa as X,xb as A,ya as O,yb as I}from"./chunk-RUVVR6EI.js";var $e=new W("CdkAccordion"),bn=(()=>{class n{_stateChanges=new b;_openCloseAllActions=new b;id=s(ye).getId("cdk-accordion-");multi=!1;openAll(){this.multi&&this._openCloseAllActions.next(!0)}closeAll(){this._openCloseAllActions.next(!1)}ngOnChanges(e){this._stateChanges.next(e)}ngOnDestroy(){this._stateChanges.complete(),this._openCloseAllActions.complete()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["cdk-accordion"],["","cdkAccordion",""]],inputs:{multi:[2,"multi","multi",v]},exportAs:["cdkAccordion"],features:[x([{provide:$e,useExisting:n}]),X]})}return n})(),Dn=(()=>{class n{accordion=s($e,{optional:!0,skipSelf:!0});_changeDetectorRef=s(J);_expansionDispatcher=s(Te);_openCloseAllSubscription=xe.EMPTY;closed=new $;opened=new $;destroyed=new $;expandedChange=new $;id=s(ye).getId("cdk-accordion-child-");get expanded(){return this._expanded}set expanded(e){if(this._expanded!==e){if(this._expanded=e,this.expandedChange.emit(e),e){this.opened.emit();let t=this.accordion?this.accordion.id:this.id;this._expansionDispatcher.notify(this.id,t)}else this.closed.emit();this._changeDetectorRef.markForCheck()}}_expanded=!1;get disabled(){return this._disabled()}set disabled(e){this._disabled.set(e)}_disabled=wt(!1);_removeUniqueSelectionListener=()=>{};constructor(){}ngOnInit(){this._removeUniqueSelectionListener=this._expansionDispatcher.listen((e,t)=>{this.accordion&&!this.accordion.multi&&this.accordion.id===t&&this.id!==e&&(this.expanded=!1)}),this.accordion&&(this._openCloseAllSubscription=this._subscribeToOpenCloseAllActions())}ngOnDestroy(){this.opened.complete(),this.closed.complete(),this.destroyed.emit(),this.destroyed.complete(),this._removeUniqueSelectionListener(),this._openCloseAllSubscription.unsubscribe()}toggle(){this.disabled||(this.expanded=!this.expanded)}close(){this.disabled||(this.expanded=!1)}open(){this.disabled||(this.expanded=!0)}_subscribeToOpenCloseAllActions(){return this.accordion._openCloseAllActions.subscribe(e=>{this.disabled||(this.expanded=e)})}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["cdk-accordion-item"],["","cdkAccordionItem",""]],inputs:{expanded:[2,"expanded","expanded",v],disabled:[2,"disabled","disabled",v]},outputs:{closed:"closed",opened:"opened",destroyed:"destroyed",expandedChange:"expandedChange"},exportAs:["cdkAccordionItem"],features:[x([{provide:$e,useValue:void 0}])]})}return n})(),Rn=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=Y({type:n});static \u0275inj=Z({})}return n})();var Jn=["body"],ei=["bodyWrapper"],ti=[[["mat-expansion-panel-header"]],"*",[["mat-action-row"]]],ni=["mat-expansion-panel-header","*","mat-action-row"];function ii(n,a){}var ai=[[["mat-panel-title"]],[["mat-panel-description"]],"*"],oi=["mat-panel-title","mat-panel-description","*"];function ri(n,a){n&1&&(Re(0,"span",1),gt(),Re(1,"svg",2),vt(2,"path",3),ze()())}var We=new W("MAT_ACCORDION"),kn=new W("MAT_EXPANSION_PANEL"),si=(()=>{class n{_template=s(B);_expansionPanel=s(kn,{optional:!0});constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["ng-template","matExpansionPanelContent",""]]})}return n})(),Sn=new W("MAT_EXPANSION_PANEL_DEFAULT_OPTIONS"),qe=(()=>{class n extends Dn{_viewContainerRef=s(G);_animationsDisabled=Nt();_document=s(be);_ngZone=s(yt);_elementRef=s(N);_renderer=s(xt);_cleanupTransitionEnd;get hideToggle(){return this._hideToggle||this.accordion&&this.accordion.hideToggle}set hideToggle(e){this._hideToggle=e}_hideToggle=!1;get togglePosition(){return this._togglePosition||this.accordion&&this.accordion.togglePosition}set togglePosition(e){this._togglePosition=e}_togglePosition;afterExpand=new $;afterCollapse=new $;_inputChanges=new b;accordion=s(We,{optional:!0,skipSelf:!0});_lazyContent;_body;_bodyWrapper;_portal;_headerId=s(ye).getId("mat-expansion-panel-header-");constructor(){super();let e=s(Sn,{optional:!0});this._expansionDispatcher=s(Te),e&&(this.hideToggle=e.hideToggle)}_hasSpacing(){return this.accordion?this.expanded&&this.accordion.displayMode==="default":!1}_getExpandedState(){return this.expanded?"expanded":"collapsed"}toggle(){this.expanded=!this.expanded}close(){this.expanded=!1}open(){this.expanded=!0}ngAfterContentInit(){this._lazyContent&&this._lazyContent._expansionPanel===this&&this.opened.pipe(je(null),ue(()=>this.expanded&&!this._portal),ft(1)).subscribe(()=>{this._portal=new dn(this._lazyContent._template,this._viewContainerRef)}),this._setupAnimationEvents()}ngOnChanges(e){this._inputChanges.next(e)}ngOnDestroy(){super.ngOnDestroy(),this._cleanupTransitionEnd?.(),this._inputChanges.complete()}_containsFocus(){if(this._body){let e=this._document.activeElement,t=this._body.nativeElement;return e===t||t.contains(e)}return!1}_transitionEndListener=({target:e,propertyName:t})=>{e===this._bodyWrapper?.nativeElement&&t==="grid-template-rows"&&this._ngZone.run(()=>{this.expanded?this.afterExpand.emit():this.afterCollapse.emit()})};_setupAnimationEvents(){this._ngZone.runOutsideAngular(()=>{this._animationsDisabled?(this.opened.subscribe(()=>this._ngZone.run(()=>this.afterExpand.emit())),this.closed.subscribe(()=>this._ngZone.run(()=>this.afterCollapse.emit()))):setTimeout(()=>{let e=this._elementRef.nativeElement;this._cleanupTransitionEnd=this._renderer.listen(e,"transitionend",this._transitionEndListener),e.classList.add("mat-expansion-panel-animations-enabled")},200)})}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=F({type:n,selectors:[["mat-expansion-panel"]],contentQueries:function(t,i,o){if(t&1&&le(o,si,5),t&2){let r;M(r=E())&&(i._lazyContent=r.first)}},viewQuery:function(t,i){if(t&1&&Le(Jn,5)(ei,5),t&2){let o;M(o=E())&&(i._body=o.first),M(o=E())&&(i._bodyWrapper=o.first)}},hostAttrs:[1,"mat-expansion-panel"],hostVars:4,hostBindings:function(t,i){t&2&&V("mat-expanded",i.expanded)("mat-expansion-panel-spacing",i._hasSpacing())},inputs:{hideToggle:[2,"hideToggle","hideToggle",v],togglePosition:"togglePosition"},outputs:{afterExpand:"afterExpand",afterCollapse:"afterCollapse"},exportAs:["matExpansionPanel"],features:[x([{provide:We,useValue:void 0},{provide:kn,useExisting:n}]),_,X],ngContentSelectors:ni,decls:9,vars:4,consts:[["bodyWrapper",""],["body",""],[1,"mat-expansion-panel-content-wrapper"],["role","region",1,"mat-expansion-panel-content",3,"id"],[1,"mat-expansion-panel-body"],[3,"cdkPortalOutlet"]],template:function(t,i){t&1&&(ae(ti),R(0),d(1,"div",2,0)(3,"div",3,1)(5,"div",4),R(6,1),k(7,ii,0,0,"ng-template",5),l(),R(8,2),l()()),t&2&&(m(),De("inert",i.expanded?null:""),m(2),j("id",i.id),De("aria-labelledby",i._headerId),m(4),j("cdkPortalOutlet",i._portal))},dependencies:[cn],styles:[`.mat-expansion-panel {
  box-sizing: content-box;
  display: block;
  margin: 0;
  overflow: hidden;
}
.mat-expansion-panel.mat-expansion-panel-animations-enabled {
  transition: margin 225ms cubic-bezier(0.4, 0, 0.2, 1), box-shadow 280ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-expansion-panel {
  position: relative;
  background: var(--mat-expansion-container-background-color, var(--mat-sys-surface));
  color: var(--mat-expansion-container-text-color, var(--mat-sys-on-surface));
  border-radius: var(--mat-expansion-container-shape, 12px);
}
.mat-expansion-panel:not([class*=mat-elevation-z]) {
  box-shadow: var(--mat-expansion-container-elevation-shadow, 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12));
}
.mat-accordion .mat-expansion-panel:not(.mat-expanded), .mat-accordion .mat-expansion-panel:not(.mat-expansion-panel-spacing) {
  border-radius: 0;
}
.mat-accordion .mat-expansion-panel:first-of-type {
  border-top-right-radius: var(--mat-expansion-container-shape, 12px);
  border-top-left-radius: var(--mat-expansion-container-shape, 12px);
}
.mat-accordion .mat-expansion-panel:last-of-type {
  border-bottom-right-radius: var(--mat-expansion-container-shape, 12px);
  border-bottom-left-radius: var(--mat-expansion-container-shape, 12px);
}
@media (forced-colors: active) {
  .mat-expansion-panel {
    outline: solid 1px;
  }
}

.mat-expansion-panel-content-wrapper {
  display: grid;
  grid-template-rows: 0fr;
  grid-template-columns: 100%;
}
.mat-expansion-panel-animations-enabled .mat-expansion-panel-content-wrapper {
  transition: grid-template-rows 225ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-expansion-panel.mat-expanded > .mat-expansion-panel-content-wrapper {
  grid-template-rows: 1fr;
}
@supports not (grid-template-rows: 0fr) {
  .mat-expansion-panel-content-wrapper {
    height: 0;
  }
  .mat-expansion-panel.mat-expanded > .mat-expansion-panel-content-wrapper {
    height: auto;
  }
}
@media print {
  .mat-expansion-panel-content-wrapper {
    height: 0;
  }
  .mat-expansion-panel.mat-expanded > .mat-expansion-panel-content-wrapper {
    height: auto;
  }
}

.mat-expansion-panel-content {
  display: flex;
  flex-direction: column;
  overflow: visible;
  min-height: 0;
  visibility: hidden;
}
.mat-expansion-panel-animations-enabled .mat-expansion-panel-content {
  transition: visibility 190ms linear;
}
.mat-expansion-panel.mat-expanded > .mat-expansion-panel-content-wrapper > .mat-expansion-panel-content {
  visibility: visible;
}
.mat-expansion-panel-content {
  font-family: var(--mat-expansion-container-text-font, var(--mat-sys-body-large-font));
  font-size: var(--mat-expansion-container-text-size, var(--mat-sys-body-large-size));
  font-weight: var(--mat-expansion-container-text-weight, var(--mat-sys-body-large-weight));
  line-height: var(--mat-expansion-container-text-line-height, var(--mat-sys-body-large-line-height));
  letter-spacing: var(--mat-expansion-container-text-tracking, var(--mat-sys-body-large-tracking));
}

.mat-expansion-panel-body {
  padding: 0 24px 16px;
}

.mat-expansion-panel-spacing {
  margin: 16px 0;
}
.mat-accordion > .mat-expansion-panel-spacing:first-child, .mat-accordion > *:first-child:not(.mat-expansion-panel) .mat-expansion-panel-spacing {
  margin-top: 0;
}
.mat-accordion > .mat-expansion-panel-spacing:last-child, .mat-accordion > *:last-child:not(.mat-expansion-panel) .mat-expansion-panel-spacing {
  margin-bottom: 0;
}

.mat-action-row {
  border-top-style: solid;
  border-top-width: 1px;
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  padding: 16px 8px 16px 24px;
  border-top-color: var(--mat-expansion-actions-divider-color, var(--mat-sys-outline));
}
.mat-action-row .mat-button-base,
.mat-action-row .mat-mdc-button-base {
  margin-left: 8px;
}
[dir=rtl] .mat-action-row .mat-button-base,
[dir=rtl] .mat-action-row .mat-mdc-button-base {
  margin-left: 0;
  margin-right: 8px;
}
`],encapsulation:2,changeDetection:0})}return n})();var Ke=(()=>{class n{panel=s(qe,{host:!0});_element=s(N);_focusMonitor=s(Ft);_changeDetectorRef=s(J);_parentChangeSubscription=xe.EMPTY;constructor(){s(At).load(Bt);let e=this.panel,t=s(Sn,{optional:!0}),i=s(new Se("tabindex"),{optional:!0}),o=e.accordion?e.accordion._stateChanges.pipe(ue(r=>!!(r.hideToggle||r.togglePosition))):ct;this.tabIndex=parseInt(i||"")||0,this._parentChangeSubscription=me(e.opened,e.closed,o,e._inputChanges.pipe(ue(r=>!!(r.hideToggle||r.disabled||r.togglePosition)))).subscribe(()=>this._changeDetectorRef.markForCheck()),e.closed.pipe(ue(()=>e._containsFocus())).subscribe(()=>this._focusMonitor.focusVia(this._element,"program")),t&&(this.expandedHeight=t.expandedHeight,this.collapsedHeight=t.collapsedHeight)}expandedHeight;collapsedHeight;tabIndex=0;get disabled(){return this.panel.disabled}_toggle(){this.disabled||this.panel.toggle()}_isExpanded(){return this.panel.expanded}_getExpandedState(){return this.panel._getExpandedState()}_getPanelId(){return this.panel.id}_getTogglePosition(){return this.panel.togglePosition}_showToggle(){return!this.panel.hideToggle&&!this.panel.disabled}_getHeaderHeight(){let e=this._isExpanded();return e&&this.expandedHeight?this.expandedHeight:!e&&this.collapsedHeight?this.collapsedHeight:null}_keydown(e){switch(e.keyCode){case 32:case 13:It(e)||(e.preventDefault(),this._toggle());break;default:this.panel.accordion&&this.panel.accordion._handleHeaderKeydown(e);return}}focus(e,t){e?this._focusMonitor.focusVia(this._element,e,t):this._element.nativeElement.focus(t)}ngAfterViewInit(){this._focusMonitor.monitor(this._element).subscribe(e=>{e&&this.panel.accordion&&this.panel.accordion._handleHeaderFocus(this)})}ngOnDestroy(){this._parentChangeSubscription.unsubscribe(),this._focusMonitor.stopMonitoring(this._element)}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=F({type:n,selectors:[["mat-expansion-panel-header"]],hostAttrs:["role","button",1,"mat-expansion-panel-header","mat-focus-indicator"],hostVars:13,hostBindings:function(t,i){t&1&&L("click",function(){return i._toggle()})("keydown",function(r){return i._keydown(r)}),t&2&&(De("id",i.panel._headerId)("tabindex",i.disabled?-1:i.tabIndex)("aria-controls",i._getPanelId())("aria-expanded",i._isExpanded())("aria-disabled",i.panel.disabled),ke("height",i._getHeaderHeight()),V("mat-expanded",i._isExpanded())("mat-expansion-toggle-indicator-after",i._getTogglePosition()==="after")("mat-expansion-toggle-indicator-before",i._getTogglePosition()==="before"))},inputs:{expandedHeight:"expandedHeight",collapsedHeight:"collapsedHeight",tabIndex:[2,"tabIndex","tabIndex",e=>e==null?0:Rt(e)]},ngContentSelectors:oi,decls:5,vars:3,consts:[[1,"mat-content"],[1,"mat-expansion-indicator"],["xmlns","http://www.w3.org/2000/svg","viewBox","0 -960 960 960","aria-hidden","true","focusable","false"],["d","M480-345 240-585l56-56 184 184 184-184 56 56-240 240Z"]],template:function(t,i){t&1&&(ae(ai),Re(0,"span",0),R(1),R(2,1),R(3,2),ze(),A(4,ri,3,0,"span",1)),t&2&&(V("mat-content-hide-toggle",!i._showToggle()),m(4),I(i._showToggle()?4:-1))},styles:[`.mat-expansion-panel-header {
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 0 24px;
  border-radius: inherit;
}
.mat-expansion-panel-animations-enabled .mat-expansion-panel-header {
  transition: height 225ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-expansion-panel-header::before {
  border-radius: inherit;
}
.mat-expansion-panel-header {
  height: var(--mat-expansion-header-collapsed-state-height, 48px);
  font-family: var(--mat-expansion-header-text-font, var(--mat-sys-title-medium-font));
  font-size: var(--mat-expansion-header-text-size, var(--mat-sys-title-medium-size));
  font-weight: var(--mat-expansion-header-text-weight, var(--mat-sys-title-medium-weight));
  line-height: var(--mat-expansion-header-text-line-height, var(--mat-sys-title-medium-line-height));
  letter-spacing: var(--mat-expansion-header-text-tracking, var(--mat-sys-title-medium-tracking));
}
.mat-expansion-panel-header.mat-expanded {
  height: var(--mat-expansion-header-expanded-state-height, 64px);
}
.mat-expansion-panel-header[aria-disabled=true] {
  color: var(--mat-expansion-header-disabled-state-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-expansion-panel-header:not([aria-disabled=true]) {
  cursor: pointer;
}
.mat-expansion-panel:not(.mat-expanded) .mat-expansion-panel-header:not([aria-disabled=true]):hover {
  background: var(--mat-expansion-header-hover-state-layer-color, color-mix(in srgb, var(--mat-sys-on-surface) calc(var(--mat-sys-hover-state-layer-opacity) * 100%), transparent));
}
@media (hover: none) {
  .mat-expansion-panel:not(.mat-expanded) .mat-expansion-panel-header:not([aria-disabled=true]):hover {
    background: var(--mat-expansion-container-background-color, var(--mat-sys-surface));
  }
}
.mat-expansion-panel .mat-expansion-panel-header:not([aria-disabled=true]).cdk-keyboard-focused, .mat-expansion-panel .mat-expansion-panel-header:not([aria-disabled=true]).cdk-program-focused {
  background: var(--mat-expansion-header-focus-state-layer-color, color-mix(in srgb, var(--mat-sys-on-surface) calc(var(--mat-sys-focus-state-layer-opacity) * 100%), transparent));
}
.mat-expansion-panel-header._mat-animation-noopable {
  transition: none;
}
.mat-expansion-panel-header:focus, .mat-expansion-panel-header:hover {
  outline: none;
}
.mat-expansion-panel-header.mat-expanded:focus, .mat-expansion-panel-header.mat-expanded:hover {
  background: inherit;
}
.mat-expansion-panel-header.mat-expansion-toggle-indicator-before {
  flex-direction: row-reverse;
}
.mat-expansion-panel-header.mat-expansion-toggle-indicator-before .mat-expansion-indicator {
  margin: 0 16px 0 0;
}
[dir=rtl] .mat-expansion-panel-header.mat-expansion-toggle-indicator-before .mat-expansion-indicator {
  margin: 0 0 0 16px;
}

.mat-content {
  display: flex;
  flex: 1;
  flex-direction: row;
  overflow: hidden;
}
.mat-content.mat-content-hide-toggle {
  margin-right: 8px;
}
[dir=rtl] .mat-content.mat-content-hide-toggle {
  margin-right: 0;
  margin-left: 8px;
}
.mat-expansion-toggle-indicator-before .mat-content.mat-content-hide-toggle {
  margin-left: 24px;
  margin-right: 0;
}
[dir=rtl] .mat-expansion-toggle-indicator-before .mat-content.mat-content-hide-toggle {
  margin-right: 24px;
  margin-left: 0;
}

.mat-expansion-panel-header-title {
  color: var(--mat-expansion-header-text-color, var(--mat-sys-on-surface));
}

.mat-expansion-panel-header-title,
.mat-expansion-panel-header-description {
  display: flex;
  flex-grow: 1;
  flex-basis: 0;
  margin-right: 16px;
  align-items: center;
}
[dir=rtl] .mat-expansion-panel-header-title,
[dir=rtl] .mat-expansion-panel-header-description {
  margin-right: 0;
  margin-left: 16px;
}
.mat-expansion-panel-header[aria-disabled=true] .mat-expansion-panel-header-title,
.mat-expansion-panel-header[aria-disabled=true] .mat-expansion-panel-header-description {
  color: inherit;
}

.mat-expansion-panel-header-description {
  flex-grow: 2;
  color: var(--mat-expansion-header-description-color, var(--mat-sys-on-surface-variant));
}

.mat-expansion-panel-animations-enabled .mat-expansion-indicator {
  transition: transform 225ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-expansion-panel-header.mat-expanded .mat-expansion-indicator {
  transform: rotate(180deg);
}
.mat-expansion-indicator::after {
  border-style: solid;
  border-width: 0 2px 2px 0;
  content: "";
  padding: 3px;
  transform: rotate(45deg);
  vertical-align: middle;
  color: var(--mat-expansion-header-indicator-color, var(--mat-sys-on-surface-variant));
  display: var(--mat-expansion-legacy-header-indicator-display, none);
}
.mat-expansion-indicator svg {
  width: 24px;
  height: 24px;
  margin: 0 -8px;
  vertical-align: middle;
  fill: var(--mat-expansion-header-indicator-color, var(--mat-sys-on-surface-variant));
  display: var(--mat-expansion-header-indicator-display, inline-block);
}

@media (forced-colors: active) {
  .mat-expansion-panel-content {
    border-top: 1px solid;
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }
}
`],encapsulation:2,changeDetection:0})}return n})();var Mn=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["mat-panel-title"]],hostAttrs:[1,"mat-expansion-panel-header-title"]})}return n})(),En=(()=>{class n extends bn{_keyManager;_ownHeaders=new Ct;_headers;hideToggle=!1;displayMode="default";togglePosition="after";ngAfterContentInit(){this._headers.changes.pipe(je(this._headers)).subscribe(e=>{this._ownHeaders.reset(e.filter(t=>t.panel.accordion===this)),this._ownHeaders.notifyOnChanges()}),this._keyManager=new Pt(this._ownHeaders).withWrap().withHomeAndEnd()}_handleHeaderKeydown(e){this._keyManager.onKeydown(e)}_handleHeaderFocus(e){this._keyManager.updateActiveItem(e)}ngOnDestroy(){super.ngOnDestroy(),this._keyManager?.destroy(),this._ownHeaders.destroy()}static \u0275fac=(()=>{let e;return function(i){return(e||(e=O(n)))(i||n)}})();static \u0275dir=f({type:n,selectors:[["mat-accordion"]],contentQueries:function(t,i,o){if(t&1&&le(o,Ke,5),t&2){let r;M(r=E())&&(i._headers=r)}},hostAttrs:[1,"mat-accordion"],hostVars:2,hostBindings:function(t,i){t&2&&V("mat-accordion-multi",i.multi)},inputs:{hideToggle:[2,"hideToggle","hideToggle",v],displayMode:"displayMode",togglePosition:"togglePosition"},exportAs:["matAccordion"],features:[x([{provide:We,useExisting:n}]),_]})}return n})(),Tn=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=Y({type:n});static \u0275inj=Z({imports:[Rn,mn,Me]})}return n})();var di=[[["caption"]],[["colgroup"],["col"]],"*"],ci=["caption","colgroup, col","*"];function mi(n,a){n&1&&R(0,2)}function ui(n,a){n&1&&(d(0,"thead",0),S(1,1),l(),d(2,"tbody",0),S(3,2)(4,3),l(),d(5,"tfoot",0),S(6,4),l())}function pi(n,a){n&1&&S(0,1)(1,2)(2,3)(3,4)}var Q=new W("CDK_TABLE");var Ie=(()=>{class n{template=s(B);constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["","cdkCellDef",""]]})}return n})(),Pe=(()=>{class n{template=s(B);constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["","cdkHeaderCellDef",""]]})}return n})(),An=(()=>{class n{template=s(B);constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["","cdkFooterCellDef",""]]})}return n})(),ce=(()=>{class n{_table=s(Q,{optional:!0});_hasStickyChanged=!1;get name(){return this._name}set name(e){this._setNameInput(e)}_name;get sticky(){return this._sticky}set sticky(e){e!==this._sticky&&(this._sticky=e,this._hasStickyChanged=!0)}_sticky=!1;get stickyEnd(){return this._stickyEnd}set stickyEnd(e){e!==this._stickyEnd&&(this._stickyEnd=e,this._hasStickyChanged=!0)}_stickyEnd=!1;cell;headerCell;footerCell;cssClassFriendlyName;_columnCssClassName;constructor(){}hasStickyChanged(){let e=this._hasStickyChanged;return this.resetStickyChanged(),e}resetStickyChanged(){this._hasStickyChanged=!1}_updateColumnCssClassName(){this._columnCssClassName=[`cdk-column-${this.cssClassFriendlyName}`]}_setNameInput(e){e&&(this._name=e,this.cssClassFriendlyName=e.replace(/[^a-z0-9_-]/gi,"-"),this._updateColumnCssClassName())}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["","cdkColumnDef",""]],contentQueries:function(t,i,o){if(t&1&&le(o,Ie,5)(o,Pe,5)(o,An,5),t&2){let r;M(r=E())&&(i.cell=r.first),M(r=E())&&(i.headerCell=r.first),M(r=E())&&(i.footerCell=r.first)}},inputs:{name:[0,"cdkColumnDef","name"],sticky:[2,"sticky","sticky",v],stickyEnd:[2,"stickyEnd","stickyEnd",v]}})}return n})(),Ae=class{constructor(a,e){e.nativeElement.classList.add(...a._columnCssClassName)}},In=(()=>{class n extends Ae{constructor(){super(s(ce),s(N))}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["cdk-header-cell"],["th","cdk-header-cell",""]],hostAttrs:["role","columnheader",1,"cdk-header-cell"],features:[_]})}return n})();var Pn=(()=>{class n extends Ae{constructor(){let e=s(ce),t=s(N);super(e,t);let i=e._table?._getCellRole();i&&t.nativeElement.setAttribute("role",i)}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["cdk-cell"],["td","cdk-cell",""]],hostAttrs:[1,"cdk-cell"],features:[_]})}return n})();var Xe=(()=>{class n{template=s(B);_differs=s(de);columns;_columnsDiffer;constructor(){}ngOnChanges(e){if(!this._columnsDiffer){let t=e.columns&&e.columns.currentValue||[];this._columnsDiffer=this._differs.find(t).create(),this._columnsDiffer.diff(t)}}getColumnsDiff(){return this._columnsDiffer.diff(this.columns)}extractCellTemplate(e){return this instanceof Ce?e.headerCell.template:this instanceof Ge?e.footerCell.template:e.cell.template}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,features:[X]})}return n})(),Ce=(()=>{class n extends Xe{_table=s(Q,{optional:!0});_hasStickyChanged=!1;get sticky(){return this._sticky}set sticky(e){e!==this._sticky&&(this._sticky=e,this._hasStickyChanged=!0)}_sticky=!1;constructor(){super(s(B),s(de))}ngOnChanges(e){super.ngOnChanges(e)}hasStickyChanged(){let e=this._hasStickyChanged;return this.resetStickyChanged(),e}resetStickyChanged(){this._hasStickyChanged=!1}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["","cdkHeaderRowDef",""]],inputs:{columns:[0,"cdkHeaderRowDef","columns"],sticky:[2,"cdkHeaderRowDefSticky","sticky",v]},features:[_,X]})}return n})(),Ge=(()=>{class n extends Xe{_table=s(Q,{optional:!0});_hasStickyChanged=!1;get sticky(){return this._sticky}set sticky(e){e!==this._sticky&&(this._sticky=e,this._hasStickyChanged=!0)}_sticky=!1;constructor(){super(s(B),s(de))}ngOnChanges(e){super.ngOnChanges(e)}hasStickyChanged(){let e=this._hasStickyChanged;return this.resetStickyChanged(),e}resetStickyChanged(){this._hasStickyChanged=!1}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["","cdkFooterRowDef",""]],inputs:{columns:[0,"cdkFooterRowDef","columns"],sticky:[2,"cdkFooterRowDefSticky","sticky",v]},features:[_,X]})}return n})(),Ne=(()=>{class n extends Xe{_table=s(Q,{optional:!0});when;constructor(){super(s(B),s(de))}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["","cdkRowDef",""]],inputs:{columns:[0,"cdkRowDefColumns","columns"],when:[0,"cdkRowDefWhen","when"]},features:[_]})}return n})(),oe=(()=>{class n{_viewContainer=s(G);cells;context;static mostRecentCellOutlet=null;constructor(){n.mostRecentCellOutlet=this}ngOnDestroy(){n.mostRecentCellOutlet===this&&(n.mostRecentCellOutlet=null)}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["","cdkCellOutlet",""]]})}return n})(),Ye=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275cmp=F({type:n,selectors:[["cdk-header-row"],["tr","cdk-header-row",""]],hostAttrs:["role","row",1,"cdk-header-row"],decls:1,vars:0,consts:[["cdkCellOutlet",""]],template:function(t,i){t&1&&S(0,0)},dependencies:[oe],encapsulation:2})}return n})();var Je=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275cmp=F({type:n,selectors:[["cdk-row"],["tr","cdk-row",""]],hostAttrs:["role","row",1,"cdk-row"],decls:1,vars:0,consts:[["cdkCellOutlet",""]],template:function(t,i){t&1&&S(0,0)},dependencies:[oe],encapsulation:2})}return n})(),Nn=(()=>{class n{templateRef=s(B);_contentClassNames=["cdk-no-data-row","cdk-row"];_cellClassNames=["cdk-cell","cdk-no-data-cell"];_cellSelector="td, cdk-cell, [cdk-cell], .cdk-cell";constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["ng-template","cdkNoDataRow",""]]})}return n})(),On=["top","bottom","left","right"],Ze=class{_isNativeHtmlTable;_stickCellCss;_isBrowser;_needsPositionStickyOnElement;direction;_positionListener;_tableInjector;_elemSizeCache=new WeakMap;_resizeObserver=globalThis?.ResizeObserver?new globalThis.ResizeObserver(a=>this._updateCachedSizes(a)):null;_updatedStickyColumnsParamsToReplay=[];_stickyColumnsReplayTimeout=null;_cachedCellWidths=[];_borderCellCss;_destroyed=!1;constructor(a,e,t=!0,i=!0,o,r,c){this._isNativeHtmlTable=a,this._stickCellCss=e,this._isBrowser=t,this._needsPositionStickyOnElement=i,this.direction=o,this._positionListener=r,this._tableInjector=c,this._borderCellCss={top:`${e}-border-elem-top`,bottom:`${e}-border-elem-bottom`,left:`${e}-border-elem-left`,right:`${e}-border-elem-right`}}clearStickyPositioning(a,e){(e.includes("left")||e.includes("right"))&&this._removeFromStickyColumnReplayQueue(a);let t=[];for(let i of a)i.nodeType===i.ELEMENT_NODE&&t.push(i,...Array.from(i.children));pe({write:()=>{for(let i of t)this._removeStickyStyle(i,e)}},{injector:this._tableInjector})}updateStickyColumns(a,e,t,i=!0,o=!0){if(!a.length||!this._isBrowser||!(e.some(P=>P)||t.some(P=>P))){this._positionListener?.stickyColumnsUpdated({sizes:[]}),this._positionListener?.stickyEndColumnsUpdated({sizes:[]});return}let r=a[0],c=r.children.length,p=this.direction==="rtl",h=p?"right":"left",g=p?"left":"right",y=e.lastIndexOf(!0),w=t.indexOf(!0),C,ot,rt;o&&this._updateStickyColumnReplayQueue({rows:[...a],stickyStartStates:[...e],stickyEndStates:[...t]}),pe({earlyRead:()=>{C=this._getCellWidths(r,i),ot=this._getStickyStartColumnPositions(C,e),rt=this._getStickyEndColumnPositions(C,t)},write:()=>{for(let P of a)for(let T=0;T<c;T++){let st=P.children[T];e[T]&&this._addStickyStyle(st,h,ot[T],T===y),t[T]&&this._addStickyStyle(st,g,rt[T],T===w)}this._positionListener&&C.some(P=>!!P)&&(this._positionListener.stickyColumnsUpdated({sizes:y===-1?[]:C.slice(0,y+1).map((P,T)=>e[T]?P:null)}),this._positionListener.stickyEndColumnsUpdated({sizes:w===-1?[]:C.slice(w).map((P,T)=>t[T+w]?P:null).reverse()}))}},{injector:this._tableInjector})}stickRows(a,e,t){if(!this._isBrowser)return;let i=t==="bottom"?a.slice().reverse():a,o=t==="bottom"?e.slice().reverse():e,r=[],c=[],p=[];pe({earlyRead:()=>{for(let h=0,g=0;h<i.length;h++){if(!o[h])continue;r[h]=g;let y=i[h];p[h]=this._isNativeHtmlTable?Array.from(y.children):[y];let w=this._retrieveElementSize(y).height;g+=w,c[h]=w}},write:()=>{let h=o.lastIndexOf(!0);for(let g=0;g<i.length;g++){if(!o[g])continue;let y=r[g],w=g===h;for(let C of p[g])this._addStickyStyle(C,t,y,w)}t==="top"?this._positionListener?.stickyHeaderRowsUpdated({sizes:c,offsets:r,elements:p}):this._positionListener?.stickyFooterRowsUpdated({sizes:c,offsets:r,elements:p})}},{injector:this._tableInjector})}updateStickyFooterContainer(a,e){this._isNativeHtmlTable&&pe({write:()=>{let t=a.querySelector("tfoot");t&&(e.some(i=>!i)?this._removeStickyStyle(t,["bottom"]):this._addStickyStyle(t,"bottom",0,!1))}},{injector:this._tableInjector})}destroy(){this._stickyColumnsReplayTimeout&&clearTimeout(this._stickyColumnsReplayTimeout),this._resizeObserver?.disconnect(),this._destroyed=!0}_removeStickyStyle(a,e){if(!a.classList.contains(this._stickCellCss))return;for(let i of e)a.style[i]="",a.classList.remove(this._borderCellCss[i]);On.some(i=>e.indexOf(i)===-1&&a.style[i])?a.style.zIndex=this._getCalculatedZIndex(a):(a.style.zIndex="",this._needsPositionStickyOnElement&&(a.style.position=""),a.classList.remove(this._stickCellCss))}_addStickyStyle(a,e,t,i){a.classList.add(this._stickCellCss),i&&a.classList.add(this._borderCellCss[e]),a.style[e]=`${t}px`,a.style.zIndex=this._getCalculatedZIndex(a),this._needsPositionStickyOnElement&&(a.style.cssText+="position: -webkit-sticky; position: sticky; ")}_getCalculatedZIndex(a){let e={top:100,bottom:10,left:1,right:1},t=0;for(let i of On)a.style[i]&&(t+=e[i]);return t?`${t}`:""}_getCellWidths(a,e=!0){if(!e&&this._cachedCellWidths.length)return this._cachedCellWidths;let t=[],i=a.children;for(let o=0;o<i.length;o++){let r=i[o];t.push(this._retrieveElementSize(r).width)}return this._cachedCellWidths=t,t}_getStickyStartColumnPositions(a,e){let t=[],i=0;for(let o=0;o<a.length;o++)e[o]&&(t[o]=i,i+=a[o]);return t}_getStickyEndColumnPositions(a,e){let t=[],i=0;for(let o=a.length;o>0;o--)e[o]&&(t[o]=i,i+=a[o]);return t}_retrieveElementSize(a){let e=this._elemSizeCache.get(a);if(e)return e;let t=a.getBoundingClientRect(),i={width:t.width,height:t.height};return this._resizeObserver&&(this._elemSizeCache.set(a,i),this._resizeObserver.observe(a,{box:"border-box"})),i}_updateStickyColumnReplayQueue(a){this._removeFromStickyColumnReplayQueue(a.rows),this._stickyColumnsReplayTimeout||this._updatedStickyColumnsParamsToReplay.push(a)}_removeFromStickyColumnReplayQueue(a){let e=new Set(a);for(let t of this._updatedStickyColumnsParamsToReplay)t.rows=t.rows.filter(i=>!e.has(i));this._updatedStickyColumnsParamsToReplay=this._updatedStickyColumnsParamsToReplay.filter(t=>!!t.rows.length)}_updateCachedSizes(a){let e=!1;for(let t of a){let i=t.borderBoxSize?.length?{width:t.borderBoxSize[0].inlineSize,height:t.borderBoxSize[0].blockSize}:{width:t.contentRect.width,height:t.contentRect.height};i.width!==this._elemSizeCache.get(t.target)?.width&&fi(t.target)&&(e=!0),this._elemSizeCache.set(t.target,i)}e&&this._updatedStickyColumnsParamsToReplay.length&&(this._stickyColumnsReplayTimeout&&clearTimeout(this._stickyColumnsReplayTimeout),this._stickyColumnsReplayTimeout=setTimeout(()=>{if(!this._destroyed){for(let t of this._updatedStickyColumnsParamsToReplay)this.updateStickyColumns(t.rows,t.stickyStartStates,t.stickyEndStates,!0,!1);this._updatedStickyColumnsParamsToReplay=[],this._stickyColumnsReplayTimeout=null}},0))}};function fi(n){return["cdk-cell","cdk-header-cell","cdk-footer-cell"].some(a=>n.classList.contains(a))}var we=new W("STICKY_POSITIONING_LISTENER");var et=(()=>{class n{viewContainer=s(G);elementRef=s(N);constructor(){let e=s(Q);e._rowOutlet=this,e._outletAssigned()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["","rowOutlet",""]]})}return n})(),tt=(()=>{class n{viewContainer=s(G);elementRef=s(N);constructor(){let e=s(Q);e._headerRowOutlet=this,e._outletAssigned()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["","headerRowOutlet",""]]})}return n})(),nt=(()=>{class n{viewContainer=s(G);elementRef=s(N);constructor(){let e=s(Q);e._footerRowOutlet=this,e._outletAssigned()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["","footerRowOutlet",""]]})}return n})(),it=(()=>{class n{viewContainer=s(G);elementRef=s(N);constructor(){let e=s(Q);e._noDataRowOutlet=this,e._outletAssigned()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=f({type:n,selectors:[["","noDataRowOutlet",""]]})}return n})(),at=(()=>{class n{_differs=s(de);_changeDetectorRef=s(J);_elementRef=s(N);_dir=s(St,{optional:!0});_platform=s(Tt);_viewRepeater;_viewportRuler=s(rn);_injector=s(_t);_virtualScrollViewport=s(sn,{optional:!0,host:!0});_positionListener=s(we,{optional:!0})||s(we,{optional:!0,skipSelf:!0});_document=s(be);_data;_renderedRange;_onDestroy=new b;_renderRows;_renderChangeSubscription=null;_columnDefsByName=new Map;_rowDefs;_headerRowDefs;_footerRowDefs;_dataDiffer;_defaultRowDef=null;_customColumnDefs=new Set;_customRowDefs=new Set;_customHeaderRowDefs=new Set;_customFooterRowDefs=new Set;_customNoDataRow=null;_headerRowDefChanged=!0;_footerRowDefChanged=!0;_stickyColumnStylesNeedReset=!0;_forceRecalculateCellWidths=!0;_cachedRenderRowsMap=new Map;_isNativeHtmlTable;_stickyStyler;stickyCssClass="cdk-table-sticky";needsPositionStickyOnElement=!0;_isServer;_isShowingNoDataRow=!1;_hasAllOutlets=!1;_hasInitialized=!1;_headerRowStickyUpdates=new b;_footerRowStickyUpdates=new b;_disableVirtualScrolling=!1;_getCellRole(){if(this._cellRoleInternal===void 0){let e=this._elementRef.nativeElement.getAttribute("role");return e==="grid"||e==="treegrid"?"gridcell":"cell"}return this._cellRoleInternal}_cellRoleInternal=void 0;get trackBy(){return this._trackByFn}set trackBy(e){this._trackByFn=e}_trackByFn;get dataSource(){return this._dataSource}set dataSource(e){this._dataSource!==e&&(this._switchDataSource(e),this._changeDetectorRef.markForCheck())}_dataSource;_dataSourceChanges=new b;_dataStream=new b;get multiTemplateDataRows(){return this._multiTemplateDataRows}set multiTemplateDataRows(e){this._multiTemplateDataRows=e,this._rowOutlet&&this._rowOutlet.viewContainer.length&&(this._forceRenderDataRows(),this.updateStickyColumnStyles())}_multiTemplateDataRows=!1;get fixedLayout(){return this._virtualScrollEnabled()?!0:this._fixedLayout}set fixedLayout(e){this._fixedLayout=e,this._forceRecalculateCellWidths=!0,this._stickyColumnStylesNeedReset=!0}_fixedLayout=!1;recycleRows=!1;contentChanged=new $;viewChange=new re({start:0,end:Number.MAX_VALUE});_rowOutlet;_headerRowOutlet;_footerRowOutlet;_noDataRowOutlet;_contentColumnDefs;_contentRowDefs;_contentHeaderRowDefs;_contentFooterRowDefs;_noDataRow;constructor(){s(new Se("role"),{optional:!0})||this._elementRef.nativeElement.setAttribute("role","table"),this._isServer=!this._platform.isBrowser,this._isNativeHtmlTable=this._elementRef.nativeElement.nodeName==="TABLE",this._dataDiffer=this._differs.find([]).create((t,i)=>this.trackBy?this.trackBy(i.dataIndex,i.data):i)}ngOnInit(){this._setupStickyStyler(),this._viewportRuler.change().pipe(ee(this._onDestroy)).subscribe(()=>{this._forceRecalculateCellWidths=!0})}ngAfterContentInit(){this._viewRepeater=this.recycleRows||this._virtualScrollEnabled()?new an:new on,this._virtualScrollEnabled()&&this._setupVirtualScrolling(this._virtualScrollViewport),this._hasInitialized=!0}ngAfterContentChecked(){this._canRender()&&this._render()}ngOnDestroy(){this._stickyStyler?.destroy(),[this._rowOutlet?.viewContainer,this._headerRowOutlet?.viewContainer,this._footerRowOutlet?.viewContainer,this._cachedRenderRowsMap,this._customColumnDefs,this._customRowDefs,this._customHeaderRowDefs,this._customFooterRowDefs,this._columnDefsByName].forEach(e=>{e?.clear()}),this._headerRowDefs=[],this._footerRowDefs=[],this._defaultRowDef=null,this._headerRowStickyUpdates.complete(),this._footerRowStickyUpdates.complete(),this._onDestroy.next(),this._onDestroy.complete(),Ee(this.dataSource)&&this.dataSource.disconnect(this)}renderRows(){this._renderRows=this._getAllRenderRows();let e=this._dataDiffer.diff(this._renderRows);if(!e){this._updateNoDataRow(),this.contentChanged.next();return}let t=this._rowOutlet.viewContainer;this._viewRepeater.applyChanges(e,t,(i,o,r)=>this._getEmbeddedViewArgs(i.item,r),i=>i.item.data,i=>{i.operation===nn.INSERTED&&i.context&&this._renderCellTemplateForItem(i.record.item.rowDef,i.context)}),this._updateRowIndexContext(),e.forEachIdentityChange(i=>{let o=t.get(i.currentIndex);o.context.$implicit=i.item.data}),this._updateNoDataRow(),this.contentChanged.next(),this.updateStickyColumnStyles()}addColumnDef(e){this._customColumnDefs.add(e)}removeColumnDef(e){this._customColumnDefs.delete(e)}addRowDef(e){this._customRowDefs.add(e)}removeRowDef(e){this._customRowDefs.delete(e)}addHeaderRowDef(e){this._customHeaderRowDefs.add(e),this._headerRowDefChanged=!0}removeHeaderRowDef(e){this._customHeaderRowDefs.delete(e),this._headerRowDefChanged=!0}addFooterRowDef(e){this._customFooterRowDefs.add(e),this._footerRowDefChanged=!0}removeFooterRowDef(e){this._customFooterRowDefs.delete(e),this._footerRowDefChanged=!0}setNoDataRow(e){this._customNoDataRow=e}updateStickyHeaderRowStyles(){let e=this._getRenderedRows(this._headerRowOutlet);if(this._isNativeHtmlTable){let i=Fn(this._headerRowOutlet,"thead");i&&(i.style.display=e.length?"":"none")}let t=this._headerRowDefs.map(i=>i.sticky);this._stickyStyler.clearStickyPositioning(e,["top"]),this._stickyStyler.stickRows(e,t,"top"),this._headerRowDefs.forEach(i=>i.resetStickyChanged())}updateStickyFooterRowStyles(){let e=this._getRenderedRows(this._footerRowOutlet);if(this._isNativeHtmlTable){let i=Fn(this._footerRowOutlet,"tfoot");i&&(i.style.display=e.length?"":"none")}let t=this._footerRowDefs.map(i=>i.sticky);this._stickyStyler.clearStickyPositioning(e,["bottom"]),this._stickyStyler.stickRows(e,t,"bottom"),this._stickyStyler.updateStickyFooterContainer(this._elementRef.nativeElement,t),this._footerRowDefs.forEach(i=>i.resetStickyChanged())}updateStickyColumnStyles(){let e=this._getRenderedRows(this._headerRowOutlet),t=this._getRenderedRows(this._rowOutlet),i=this._getRenderedRows(this._footerRowOutlet);(this._isNativeHtmlTable&&!this.fixedLayout||this._stickyColumnStylesNeedReset)&&(this._stickyStyler.clearStickyPositioning([...e,...t,...i],["left","right"]),this._stickyColumnStylesNeedReset=!1),e.forEach((o,r)=>{this._addStickyColumnStyles([o],this._headerRowDefs[r])}),this._rowDefs.forEach(o=>{let r=[];for(let c=0;c<t.length;c++)this._renderRows[c].rowDef===o&&r.push(t[c]);this._addStickyColumnStyles(r,o)}),i.forEach((o,r)=>{this._addStickyColumnStyles([o],this._footerRowDefs[r])}),Array.from(this._columnDefsByName.values()).forEach(o=>o.resetStickyChanged())}stickyColumnsUpdated(e){this._positionListener?.stickyColumnsUpdated(e)}stickyEndColumnsUpdated(e){this._positionListener?.stickyEndColumnsUpdated(e)}stickyHeaderRowsUpdated(e){this._headerRowStickyUpdates.next(e),this._positionListener?.stickyHeaderRowsUpdated(e)}stickyFooterRowsUpdated(e){this._footerRowStickyUpdates.next(e),this._positionListener?.stickyFooterRowsUpdated(e)}_outletAssigned(){!this._hasAllOutlets&&this._rowOutlet&&this._headerRowOutlet&&this._footerRowOutlet&&this._noDataRowOutlet&&(this._hasAllOutlets=!0,this._canRender()&&this._render())}_canRender(){return this._hasAllOutlets&&this._hasInitialized}_render(){this._cacheRowDefs(),this._cacheColumnDefs(),!this._headerRowDefs.length&&!this._footerRowDefs.length&&this._rowDefs.length;let t=this._renderUpdatedColumns()||this._headerRowDefChanged||this._footerRowDefChanged;this._stickyColumnStylesNeedReset=this._stickyColumnStylesNeedReset||t,this._forceRecalculateCellWidths=t,this._headerRowDefChanged&&(this._forceRenderHeaderRows(),this._headerRowDefChanged=!1),this._footerRowDefChanged&&(this._forceRenderFooterRows(),this._footerRowDefChanged=!1),this.dataSource&&this._rowDefs.length>0&&!this._renderChangeSubscription?this._observeRenderChanges():this._stickyColumnStylesNeedReset&&this.updateStickyColumnStyles(),this._checkStickyStates()}_getAllRenderRows(){if(!Array.isArray(this._data)||!this._renderedRange)return[];let e=[],t=Math.min(this._data.length,this._renderedRange.end),i=this._cachedRenderRowsMap;this._cachedRenderRowsMap=new Map;for(let o=this._renderedRange.start;o<t;o++){let r=this._data[o],c=this._getRenderRowsForData(r,o,i.get(r));this._cachedRenderRowsMap.has(r)||this._cachedRenderRowsMap.set(r,new WeakMap);for(let p=0;p<c.length;p++){let h=c[p],g=this._cachedRenderRowsMap.get(h.data);g.has(h.rowDef)?g.get(h.rowDef).push(h):g.set(h.rowDef,[h]),e.push(h)}}return e}_getRenderRowsForData(e,t,i){return this._getRowDefs(e,t).map(r=>{let c=i&&i.has(r)?i.get(r):[];if(c.length){let p=c.shift();return p.dataIndex=t,p}else return{data:e,rowDef:r,dataIndex:t}})}_cacheColumnDefs(){this._columnDefsByName.clear(),Fe(this._getOwnDefs(this._contentColumnDefs),this._customColumnDefs).forEach(t=>{this._columnDefsByName.has(t.name),this._columnDefsByName.set(t.name,t)})}_cacheRowDefs(){this._headerRowDefs=Fe(this._getOwnDefs(this._contentHeaderRowDefs),this._customHeaderRowDefs),this._footerRowDefs=Fe(this._getOwnDefs(this._contentFooterRowDefs),this._customFooterRowDefs),this._rowDefs=Fe(this._getOwnDefs(this._contentRowDefs),this._customRowDefs);let e=this._rowDefs.filter(t=>!t.when);this._defaultRowDef=e[0]}_renderUpdatedColumns(){let e=(r,c)=>{let p=!!c.getColumnsDiff();return r||p},t=this._rowDefs.reduce(e,!1);t&&this._forceRenderDataRows();let i=this._headerRowDefs.reduce(e,!1);i&&this._forceRenderHeaderRows();let o=this._footerRowDefs.reduce(e,!1);return o&&this._forceRenderFooterRows(),t||i||o}_switchDataSource(e){this._data=[],Ee(this.dataSource)&&this.dataSource.disconnect(this),this._renderChangeSubscription&&(this._renderChangeSubscription.unsubscribe(),this._renderChangeSubscription=null),e||(this._dataDiffer&&this._dataDiffer.diff([]),this._rowOutlet&&this._rowOutlet.viewContainer.clear()),this._dataSource=e}_observeRenderChanges(){if(!this.dataSource)return;let e;Ee(this.dataSource)?e=this.dataSource.connect(this):mt(this.dataSource)?e=this.dataSource:Array.isArray(this.dataSource)&&(e=se(this.dataSource)),this._renderChangeSubscription=K([e,this.viewChange]).pipe(ee(this._onDestroy)).subscribe(([t,i])=>{this._data=t||[],this._renderedRange=i,this._dataStream.next(t),this.renderRows()})}_forceRenderHeaderRows(){this._headerRowOutlet.viewContainer.length>0&&this._headerRowOutlet.viewContainer.clear(),this._headerRowDefs.forEach((e,t)=>this._renderRow(this._headerRowOutlet,e,t)),this.updateStickyHeaderRowStyles()}_forceRenderFooterRows(){this._footerRowOutlet.viewContainer.length>0&&this._footerRowOutlet.viewContainer.clear(),this._footerRowDefs.forEach((e,t)=>this._renderRow(this._footerRowOutlet,e,t)),this.updateStickyFooterRowStyles()}_addStickyColumnStyles(e,t){let i=Array.from(t?.columns||[]).map(c=>{let p=this._columnDefsByName.get(c);return p}),o=i.map(c=>c.sticky),r=i.map(c=>c.stickyEnd);this._stickyStyler.updateStickyColumns(e,o,r,!this.fixedLayout||this._forceRecalculateCellWidths)}_getRenderedRows(e){let t=[];for(let i=0;i<e.viewContainer.length;i++){let o=e.viewContainer.get(i);t.push(o.rootNodes[0])}return t}_getRowDefs(e,t){if(this._rowDefs.length===1)return[this._rowDefs[0]];let i=[];if(this.multiTemplateDataRows)i=this._rowDefs.filter(o=>!o.when||o.when(t,e));else{let o=this._rowDefs.find(r=>r.when&&r.when(t,e))||this._defaultRowDef;o&&i.push(o)}return i.length,i}_getEmbeddedViewArgs(e,t){let i=e.rowDef,o={$implicit:e.data};return{templateRef:i.template,context:o,index:t}}_renderRow(e,t,i,o={}){let r=e.viewContainer.createEmbeddedView(t.template,o,i);return this._renderCellTemplateForItem(t,o),r}_renderCellTemplateForItem(e,t){for(let i of this._getCellTemplates(e))oe.mostRecentCellOutlet&&oe.mostRecentCellOutlet._viewContainer.createEmbeddedView(i,t);this._changeDetectorRef.markForCheck()}_updateRowIndexContext(){let e=this._rowOutlet.viewContainer;for(let t=0,i=e.length;t<i;t++){let r=e.get(t).context;r.count=i,r.first=t===0,r.last=t===i-1,r.even=t%2===0,r.odd=!r.even,this.multiTemplateDataRows?(r.dataIndex=this._renderRows[t].dataIndex,r.renderIndex=t):r.index=this._renderRows[t].dataIndex}}_getCellTemplates(e){return!e||!e.columns?[]:Array.from(e.columns,t=>{let i=this._columnDefsByName.get(t);return e.extractCellTemplate(i)})}_forceRenderDataRows(){this._dataDiffer.diff([]),this._rowOutlet.viewContainer.clear(),this.renderRows()}_checkStickyStates(){let e=(t,i)=>t||i.hasStickyChanged();this._headerRowDefs.reduce(e,!1)&&this.updateStickyHeaderRowStyles(),this._footerRowDefs.reduce(e,!1)&&this.updateStickyFooterRowStyles(),Array.from(this._columnDefsByName.values()).reduce(e,!1)&&(this._stickyColumnStylesNeedReset=!0,this.updateStickyColumnStyles())}_setupStickyStyler(){let e=this._dir?this._dir.value:"ltr",t=this._injector;this._stickyStyler=new Ze(this._isNativeHtmlTable,this.stickyCssClass,this._platform.isBrowser,this.needsPositionStickyOnElement,e,this,t),(this._dir?this._dir.change:se()).pipe(ee(this._onDestroy)).subscribe(i=>{this._stickyStyler.direction=i,this.updateStickyColumnStyles()})}_setupVirtualScrolling(e){let t=typeof requestAnimationFrame<"u"?dt:lt;this.viewChange.next({start:0,end:0}),e.renderedRangeStream.pipe(ut(0,t),ee(this._onDestroy)).subscribe(this.viewChange),e.attach({dataStream:this._dataStream,measureRangeSize:(i,o)=>this._measureRangeSize(i,o)}),K([e.renderedContentOffset,this._headerRowStickyUpdates]).pipe(ee(this._onDestroy)).subscribe(([i,o])=>{if(!(!o.sizes||!o.offsets||!o.elements))for(let r=0;r<o.elements.length;r++){let c=o.elements[r];if(c){let p=o.offsets[r],h=i!==0?Math.max(i-p,p):-p;for(let g of c)g.style.top=`${-h}px`}}}),K([e.renderedContentOffset,this._footerRowStickyUpdates]).pipe(ee(this._onDestroy)).subscribe(([i,o])=>{if(!(!o.sizes||!o.offsets||!o.elements))for(let r=0;r<o.elements.length;r++){let c=o.elements[r];if(c)for(let p of c)p.style.bottom=`${i+o.offsets[r]}px`}})}_getOwnDefs(e){return e.filter(t=>!t._table||t._table===this)}_updateNoDataRow(){let e=this._customNoDataRow||this._noDataRow;if(!e)return;let t=this._rowOutlet.viewContainer.length===0;if(t===this._isShowingNoDataRow)return;let i=this._noDataRowOutlet.viewContainer;if(t){let o=i.createEmbeddedView(e.templateRef),r=o.rootNodes[0];if(o.rootNodes.length===1&&r?.nodeType===this._document.ELEMENT_NODE){r.setAttribute("role","row"),r.classList.add(...e._contentClassNames);let c=r.querySelectorAll(e._cellSelector);for(let p=0;p<c.length;p++)c[p].classList.add(...e._cellClassNames)}}else i.clear();this._isShowingNoDataRow=t,this._changeDetectorRef.markForCheck()}_measureRangeSize(e,t){if(e.start>=e.end||t!=="vertical")return 0;let i=this.viewChange.value,o=this._rowOutlet.viewContainer;e.start<i.start||e.end>i.end;let r=e.start-i.start,c=e.end-e.start,p,h;for(let w=0;w<c;w++){let C=o.get(w+r);if(C&&C.rootNodes.length){p=h=C.rootNodes[0];break}}for(let w=c-1;w>-1;w--){let C=o.get(w+r);if(C&&C.rootNodes.length){h=C.rootNodes[C.rootNodes.length-1];break}}let g=p?.getBoundingClientRect?.(),y=h?.getBoundingClientRect?.();return g&&y?y.bottom-g.top:0}_virtualScrollEnabled(){return!this._disableVirtualScrolling&&this._virtualScrollViewport!=null}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=F({type:n,selectors:[["cdk-table"],["table","cdk-table",""]],contentQueries:function(t,i,o){if(t&1&&le(o,Nn,5)(o,ce,5)(o,Ne,5)(o,Ce,5)(o,Ge,5),t&2){let r;M(r=E())&&(i._noDataRow=r.first),M(r=E())&&(i._contentColumnDefs=r),M(r=E())&&(i._contentRowDefs=r),M(r=E())&&(i._contentHeaderRowDefs=r),M(r=E())&&(i._contentFooterRowDefs=r)}},hostAttrs:[1,"cdk-table"],hostVars:2,hostBindings:function(t,i){t&2&&V("cdk-table-fixed-layout",i.fixedLayout)},inputs:{trackBy:"trackBy",dataSource:"dataSource",multiTemplateDataRows:[2,"multiTemplateDataRows","multiTemplateDataRows",v],fixedLayout:[2,"fixedLayout","fixedLayout",v],recycleRows:[2,"recycleRows","recycleRows",v]},outputs:{contentChanged:"contentChanged"},exportAs:["cdkTable"],features:[x([{provide:Q,useExisting:n},{provide:we,useValue:null}])],ngContentSelectors:ci,decls:5,vars:2,consts:[["role","rowgroup"],["headerRowOutlet",""],["rowOutlet",""],["noDataRowOutlet",""],["footerRowOutlet",""]],template:function(t,i){t&1&&(ae(di),R(0),R(1,1),A(2,mi,1,0),A(3,ui,7,0)(4,pi,4,0)),t&2&&(m(2),I(i._isServer?2:-1),m(),I(i._isNativeHtmlTable?3:4))},dependencies:[tt,et,it,nt],styles:[`.cdk-table-fixed-layout {
  table-layout: fixed;
}
`],encapsulation:2})}return n})();function Fe(n,a){return n.concat(Array.from(a))}function Fn(n,a){let e=a.toUpperCase(),t=n.viewContainer.element.nativeElement;for(;t;){let i=t.nodeType===1?t.nodeName:null;if(i===e)return t;if(i==="TABLE")break;t=t.parentNode}return null}var Bn=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=Y({type:n});static \u0275inj=Z({imports:[ln]})}return n})();var hi=[[["caption"]],[["colgroup"],["col"]],"*"],gi=["caption","colgroup, col","*"];function _i(n,a){n&1&&R(0,2)}function yi(n,a){n&1&&(d(0,"thead",0),S(1,1),l(),d(2,"tbody",2),S(3,3)(4,4),l(),d(5,"tfoot",0),S(6,5),l())}function wi(n,a){n&1&&S(0,1)(1,3)(2,4)(3,5)}var jn=(()=>{class n extends at{stickyCssClass="mat-mdc-table-sticky";needsPositionStickyOnElement=!1;static \u0275fac=(()=>{let e;return function(i){return(e||(e=O(n)))(i||n)}})();static \u0275cmp=F({type:n,selectors:[["mat-table"],["table","mat-table",""]],hostAttrs:[1,"mat-mdc-table","mdc-data-table__table"],hostVars:2,hostBindings:function(t,i){t&2&&V("mat-table-fixed-layout",i.fixedLayout)},exportAs:["matTable"],features:[x([{provide:at,useExisting:n},{provide:Q,useExisting:n},{provide:we,useValue:null}]),_],ngContentSelectors:gi,decls:5,vars:2,consts:[["role","rowgroup"],["headerRowOutlet",""],["role","rowgroup",1,"mdc-data-table__content"],["rowOutlet",""],["noDataRowOutlet",""],["footerRowOutlet",""]],template:function(t,i){t&1&&(ae(hi),R(0),R(1,1),A(2,_i,1,0),A(3,yi,7,0)(4,wi,4,0)),t&2&&(m(2),I(i._isServer?2:-1),m(),I(i._isNativeHtmlTable?3:4))},dependencies:[tt,et,it,nt],styles:[`.mat-mdc-table-sticky {
  position: sticky !important;
}

mat-table {
  display: block;
}

mat-header-row {
  min-height: var(--mat-table-header-container-height, 56px);
}

mat-row {
  min-height: var(--mat-table-row-item-container-height, 52px);
}

mat-footer-row {
  min-height: var(--mat-table-footer-container-height, 52px);
}

mat-row, mat-header-row, mat-footer-row {
  display: flex;
  border-width: 0;
  border-bottom-width: 1px;
  border-style: solid;
  align-items: center;
  box-sizing: border-box;
}

mat-cell:first-of-type, mat-header-cell:first-of-type, mat-footer-cell:first-of-type {
  padding-left: 24px;
}
[dir=rtl] mat-cell:first-of-type:not(:only-of-type), [dir=rtl] mat-header-cell:first-of-type:not(:only-of-type), [dir=rtl] mat-footer-cell:first-of-type:not(:only-of-type) {
  padding-left: 0;
  padding-right: 24px;
}
mat-cell:last-of-type, mat-header-cell:last-of-type, mat-footer-cell:last-of-type {
  padding-right: 24px;
}
[dir=rtl] mat-cell:last-of-type:not(:only-of-type), [dir=rtl] mat-header-cell:last-of-type:not(:only-of-type), [dir=rtl] mat-footer-cell:last-of-type:not(:only-of-type) {
  padding-right: 0;
  padding-left: 24px;
}

mat-cell, mat-header-cell, mat-footer-cell {
  flex: 1;
  display: flex;
  align-items: center;
  overflow: hidden;
  word-wrap: break-word;
  min-height: inherit;
}

.mat-mdc-table {
  min-width: 100%;
  border: 0;
  border-spacing: 0;
  table-layout: auto;
  white-space: normal;
  background-color: var(--mat-table-background-color, var(--mat-sys-surface));
}

.mat-table-fixed-layout {
  table-layout: fixed;
}

.mdc-data-table__cell {
  box-sizing: border-box;
  overflow: hidden;
  text-align: start;
  text-overflow: ellipsis;
}

.mdc-data-table__cell,
.mdc-data-table__header-cell {
  padding: 0 16px;
}

.mat-mdc-header-row {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  height: var(--mat-table-header-container-height, 56px);
  color: var(--mat-table-header-headline-color, var(--mat-sys-on-surface, rgba(0, 0, 0, 0.87)));
  font-family: var(--mat-table-header-headline-font, var(--mat-sys-title-small-font, Roboto, sans-serif));
  line-height: var(--mat-table-header-headline-line-height, var(--mat-sys-title-small-line-height));
  font-size: var(--mat-table-header-headline-size, var(--mat-sys-title-small-size, 14px));
  font-weight: var(--mat-table-header-headline-weight, var(--mat-sys-title-small-weight, 500));
}

.mat-mdc-row {
  height: var(--mat-table-row-item-container-height, 52px);
  color: var(--mat-table-row-item-label-text-color, var(--mat-sys-on-surface, rgba(0, 0, 0, 0.87)));
}

.mat-mdc-row,
.mdc-data-table__content {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  font-family: var(--mat-table-row-item-label-text-font, var(--mat-sys-body-medium-font, Roboto, sans-serif));
  line-height: var(--mat-table-row-item-label-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-table-row-item-label-text-size, var(--mat-sys-body-medium-size, 14px));
  font-weight: var(--mat-table-row-item-label-text-weight, var(--mat-sys-body-medium-weight));
}

.mat-mdc-footer-row {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  height: var(--mat-table-footer-container-height, 52px);
  color: var(--mat-table-row-item-label-text-color, var(--mat-sys-on-surface, rgba(0, 0, 0, 0.87)));
  font-family: var(--mat-table-footer-supporting-text-font, var(--mat-sys-body-medium-font, Roboto, sans-serif));
  line-height: var(--mat-table-footer-supporting-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-table-footer-supporting-text-size, var(--mat-sys-body-medium-size, 14px));
  font-weight: var(--mat-table-footer-supporting-text-weight, var(--mat-sys-body-medium-weight));
  letter-spacing: var(--mat-table-footer-supporting-text-tracking, var(--mat-sys-body-medium-tracking));
}

.mat-mdc-header-cell {
  border-bottom-color: var(--mat-table-row-item-outline-color, var(--mat-sys-outline, rgba(0, 0, 0, 0.12)));
  border-bottom-width: var(--mat-table-row-item-outline-width, 1px);
  border-bottom-style: solid;
  letter-spacing: var(--mat-table-header-headline-tracking, var(--mat-sys-title-small-tracking));
  font-weight: inherit;
  line-height: inherit;
  box-sizing: border-box;
  text-overflow: ellipsis;
  overflow: hidden;
  outline: none;
  text-align: start;
}
.mdc-data-table__row:last-child > .mat-mdc-header-cell {
  border-bottom: none;
}

.mat-mdc-cell {
  border-bottom-color: var(--mat-table-row-item-outline-color, var(--mat-sys-outline, rgba(0, 0, 0, 0.12)));
  border-bottom-width: var(--mat-table-row-item-outline-width, 1px);
  border-bottom-style: solid;
  letter-spacing: var(--mat-table-row-item-label-text-tracking, var(--mat-sys-body-medium-tracking));
  line-height: inherit;
}
.mdc-data-table__row:last-child > .mat-mdc-cell {
  border-bottom: none;
}

.mat-mdc-footer-cell {
  letter-spacing: var(--mat-table-row-item-label-text-tracking, var(--mat-sys-body-medium-tracking));
}

mat-row.mat-mdc-row,
mat-header-row.mat-mdc-header-row,
mat-footer-row.mat-mdc-footer-row {
  border-bottom: none;
}

.mat-mdc-table tbody,
.mat-mdc-table tfoot,
.mat-mdc-table thead,
.mat-mdc-cell,
.mat-mdc-footer-cell,
.mat-mdc-header-row,
.mat-mdc-row,
.mat-mdc-footer-row,
.mat-mdc-table .mat-mdc-header-cell {
  background: inherit;
}

.mat-mdc-table mat-header-row.mat-mdc-header-row,
.mat-mdc-table mat-row.mat-mdc-row,
.mat-mdc-table mat-footer-row.mat-mdc-footer-cell {
  height: unset;
}

mat-header-cell.mat-mdc-header-cell,
mat-cell.mat-mdc-cell,
mat-footer-cell.mat-mdc-footer-cell {
  align-self: stretch;
}
`],encapsulation:2})}return n})(),Hn=(()=>{class n extends Ie{static \u0275fac=(()=>{let e;return function(i){return(e||(e=O(n)))(i||n)}})();static \u0275dir=f({type:n,selectors:[["","matCellDef",""]],features:[x([{provide:Ie,useExisting:n}]),_]})}return n})(),zn=(()=>{class n extends Pe{static \u0275fac=(()=>{let e;return function(i){return(e||(e=O(n)))(i||n)}})();static \u0275dir=f({type:n,selectors:[["","matHeaderCellDef",""]],features:[x([{provide:Pe,useExisting:n}]),_]})}return n})();var Ln=(()=>{class n extends ce{get name(){return this._name}set name(e){this._setNameInput(e)}_updateColumnCssClassName(){super._updateColumnCssClassName(),this._columnCssClassName.push(`mat-column-${this.cssClassFriendlyName}`)}static \u0275fac=(()=>{let e;return function(i){return(e||(e=O(n)))(i||n)}})();static \u0275dir=f({type:n,selectors:[["","matColumnDef",""]],inputs:{name:[0,"matColumnDef","name"]},features:[x([{provide:ce,useExisting:n}]),_]})}return n})(),Vn=(()=>{class n extends In{static \u0275fac=(()=>{let e;return function(i){return(e||(e=O(n)))(i||n)}})();static \u0275dir=f({type:n,selectors:[["mat-header-cell"],["th","mat-header-cell",""]],hostAttrs:["role","columnheader",1,"mat-mdc-header-cell","mdc-data-table__header-cell"],features:[_]})}return n})();var Un=(()=>{class n extends Pn{static \u0275fac=(()=>{let e;return function(i){return(e||(e=O(n)))(i||n)}})();static \u0275dir=f({type:n,selectors:[["mat-cell"],["td","mat-cell",""]],hostAttrs:[1,"mat-mdc-cell","mdc-data-table__cell"],features:[_]})}return n})();var Qn=(()=>{class n extends Ce{static \u0275fac=(()=>{let e;return function(i){return(e||(e=O(n)))(i||n)}})();static \u0275dir=f({type:n,selectors:[["","matHeaderRowDef",""]],inputs:{columns:[0,"matHeaderRowDef","columns"],sticky:[2,"matHeaderRowDefSticky","sticky",v]},features:[x([{provide:Ce,useExisting:n}]),_]})}return n})();var $n=(()=>{class n extends Ne{static \u0275fac=(()=>{let e;return function(i){return(e||(e=O(n)))(i||n)}})();static \u0275dir=f({type:n,selectors:[["","matRowDef",""]],inputs:{columns:[0,"matRowDefColumns","columns"],when:[0,"matRowDefWhen","when"]},features:[x([{provide:Ne,useExisting:n}]),_]})}return n})(),Wn=(()=>{class n extends Ye{static \u0275fac=(()=>{let e;return function(i){return(e||(e=O(n)))(i||n)}})();static \u0275cmp=F({type:n,selectors:[["mat-header-row"],["tr","mat-header-row",""]],hostAttrs:["role","row",1,"mat-mdc-header-row","mdc-data-table__header-row"],exportAs:["matHeaderRow"],features:[x([{provide:Ye,useExisting:n}]),_],decls:1,vars:0,consts:[["cdkCellOutlet",""]],template:function(t,i){t&1&&S(0,0)},dependencies:[oe],encapsulation:2})}return n})();var qn=(()=>{class n extends Je{static \u0275fac=(()=>{let e;return function(i){return(e||(e=O(n)))(i||n)}})();static \u0275cmp=F({type:n,selectors:[["mat-row"],["tr","mat-row",""]],hostAttrs:["role","row",1,"mat-mdc-row","mdc-data-table__row"],exportAs:["matRow"],features:[x([{provide:Je,useExisting:n}]),_],decls:1,vars:0,consts:[["cdkCellOutlet",""]],template:function(t,i){t&1&&S(0,0)},dependencies:[oe],encapsulation:2})}return n})();var Kn=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=Y({type:n});static \u0275inj=Z({imports:[Bn,Me]})}return n})(),Ci=9007199254740991,Be=class extends tn{_data;_renderData=new re([]);_filter=new re("");_internalPageChanges=new b;_renderChangesSubscription=null;filteredData;get data(){return this._data.value}set data(a){a=Array.isArray(a)?a:[],this._data.next(a),this._renderChangesSubscription||this._filterData(a)}get filter(){return this._filter.value}set filter(a){this._filter.next(a),this._renderChangesSubscription||this._filterData(this.data)}get sort(){return this._sort}set sort(a){this._sort=a,this._updateChangeSubscription()}_sort;get paginator(){return this._paginator}set paginator(a){this._paginator=a,this._updateChangeSubscription()}_paginator;sortingDataAccessor=(a,e)=>{let t=a[e];if(Ot(t)){let i=Number(t);return i<Ci?i:t}return t};sortData=(a,e)=>{let t=e.active,i=e.direction;return!t||i==""?a:a.sort((o,r)=>{let c=this.sortingDataAccessor(o,t),p=this.sortingDataAccessor(r,t),h=typeof c,g=typeof p;h!==g&&(h==="number"&&(c+=""),g==="number"&&(p+=""));let y=0;return c!=null&&p!=null?c>p?y=1:c<p&&(y=-1):c!=null?y=1:p!=null&&(y=-1),y*(i=="asc"?1:-1)})};filterPredicate=(a,e)=>{let t=e.trim().toLowerCase();return Object.values(a).some(i=>`${i}`.toLowerCase().includes(t))};constructor(a=[]){super(),this._data=new re(a),this._updateChangeSubscription()}_updateChangeSubscription(){let a=this._sort?me(this._sort.sortChange,this._sort.initialized):se(null),e=this._paginator?me(this._paginator.page,this._internalPageChanges,this._paginator.initialized):se(null),t=this._data,i=K([t,this._filter]).pipe(ve(([c])=>this._filterData(c))),o=K([i,a]).pipe(ve(([c])=>this._orderData(c))),r=K([o,e]).pipe(ve(([c])=>this._pageData(c)));this._renderChangesSubscription?.unsubscribe(),this._renderChangesSubscription=r.subscribe(c=>this._renderData.next(c))}_filterData(a){return this.filteredData=this.filter==null||this.filter===""?a:a.filter(e=>this.filterPredicate(e,this.filter)),this.paginator&&this._updatePaginator(this.filteredData.length),this.filteredData}_orderData(a){return this.sort?this.sortData(a.slice(),this.sort):a}_pageData(a){if(!this.paginator)return a;let e=this.paginator.pageIndex*this.paginator.pageSize;return a.slice(e,e+this.paginator.pageSize)}_updatePaginator(a){Promise.resolve().then(()=>{let e=this.paginator;if(e&&(e.length=a,e.pageIndex>0)){let t=Math.ceil(e.length/e.pageSize)-1||0,i=Math.min(e.pageIndex,t);i!==e.pageIndex&&(e.pageIndex=i,this._internalPageChanges.next())}})}connect(){return this._renderChangesSubscription||this._updateChangeSubscription(),this._renderData}disconnect(){this._renderChangesSubscription?.unsubscribe(),this._renderChangesSubscription=null}};function vi(n,a){if(n&1){let e=ie();d(0,"button",35),L("click",function(){te(e);let i=D();return ne(i.limpiarFiltros())}),u(1),l()}if(n&2){let e=D();m(),q(" Limpiar (",e.totalFiltrosActivos,") ")}}function bi(n,a){if(n&1){let e=ie();d(0,"div",8)(1,"mat-checkbox",36),L("change",function(){let i=te(e).$implicit,o=D();return ne(o.toggleValor("prioridades",i))}),u(2),l(),d(3,"span",37),u(4),l()()}if(n&2){let e=a.$implicit,t=D();m(),j("checked",t.estaSeleccionado("prioridades",e)),m(),q(" ",e," "),m(2),U(t.contarCoincidencias("prioridad",e))}}function Di(n,a){if(n&1){let e=ie();d(0,"div",8)(1,"mat-checkbox",36),L("change",function(){let i=te(e).$implicit,o=D();return ne(o.toggleValor("temas",i))}),u(2),l(),d(3,"span",37),u(4),l()()}if(n&2){let e=a.$implicit,t=D();m(),j("checked",t.estaSeleccionado("temas",e)),m(),q(" ",e," "),m(2),U(t.contarCoincidencias("tema",e))}}function Ri(n,a){if(n&1){let e=ie();d(0,"div",8)(1,"mat-checkbox",36),L("change",function(){let i=te(e).$implicit,o=D();return ne(o.toggleValor("escuelas",i))}),u(2),l(),d(3,"span",37),u(4),l()()}if(n&2){let e=a.$implicit,t=D();m(),j("checked",t.estaSeleccionado("escuelas",e)),m(),q(" ",e," "),m(2),U(t.contarCoincidencias("unidadAcademica",e))}}function ki(n,a){if(n&1){let e=ie();d(0,"div",8)(1,"mat-checkbox",36),L("change",function(){let i=te(e).$implicit,o=D();return ne(o.toggleValor("estatus",i))}),u(2),l(),d(3,"span",37),u(4),l()()}if(n&2){let e=a.$implicit,t=D();m(),j("checked",t.estaSeleccionado("estatus",e)),m(),q(" ",t.etiquetaEstatus(e)," "),m(2),U(t.contarCoincidencias("estatusCodigo",e))}}function Si(n,a){n&1&&(d(0,"th",38),u(1,"Folio"),l())}function Mi(n,a){if(n&1&&(d(0,"td",39),u(1),l()),n&2){let e=a.$implicit;m(),U(e.folio)}}function Ei(n,a){n&1&&(d(0,"th",38),u(1,"Fecha ingreso"),l())}function Ti(n,a){if(n&1&&(d(0,"td",39),u(1),l()),n&2){let e=a.$implicit;m(),U(e.fechaRecepcion)}}function Oi(n,a){n&1&&(d(0,"th",38),u(1,"Quejoso"),l())}function Fi(n,a){if(n&1&&(d(0,"td",39),u(1),l()),n&2){let e=a.$implicit;m(),U(e.nombreQuejoso)}}function Ai(n,a){n&1&&(d(0,"th",38),u(1,"Escuela"),l())}function Ii(n,a){if(n&1&&(d(0,"td",39),u(1),l()),n&2){let e=a.$implicit;m(),U(e.unidadAcademica)}}function Pi(n,a){n&1&&(d(0,"th",38),u(1,"Tema"),l())}function Ni(n,a){if(n&1&&(d(0,"td",39),u(1),l()),n&2){let e=a.$implicit;m(),U(e.tema)}}function Bi(n,a){n&1&&(d(0,"th",38),u(1,"Prioridad"),l())}function ji(n,a){if(n&1&&(d(0,"td",39)(1,"mat-chip"),u(2),l()()),n&2){let e=a.$implicit;m(),V("chip-high",e.prioridad==="Alta")("chip-medium",e.prioridad==="Media")("chip-low",e.prioridad==="Baja"),m(),q(" ",e.prioridad," ")}}function Hi(n,a){n&1&&(d(0,"th",38),u(1,"Estatus"),l())}function zi(n,a){n&1&&(d(0,"span",40)(1,"mat-icon"),u(2,"event"),l()())}function Li(n,a){if(n&1&&(d(0,"td",39)(1,"span"),u(2),l(),A(3,zi,3,0,"span",40),l()),n&2){let e=a.$implicit,t=D();m(),bt("estatus-chip "+t.claseEstatus(e.estatusCodigo)),m(),U(e.estatus),m(),I(e.tieneCitaActiva?3:-1)}}function Vi(n,a){n&1&&(d(0,"th",38),u(1,"Acciones"),l())}function Ui(n,a){if(n&1){let e=ie();d(0,"td",39)(1,"button",41),L("click",function(){let i=te(e).$implicit,o=D();return ne(o.analizar(i))}),d(2,"mat-icon"),u(3,"visibility"),l(),u(4," Analizar "),l()()}}function Qi(n,a){n&1&&He(0,"tr",42)}function $i(n,a){n&1&&He(0,"tr",43)}function Wi(n,a){n&1&&(d(0,"p",34),u(1,"No hay expedientes que coincidan con los filtros aplicados."),l())}var Zn=["TURNADA","EN_ANALISIS","PROCEDENTE","IMPROCEDENTE","REMITIDA"],Xn=class n{constructor(a,e,t,i){this.router=a;this.bandejaService=e;this.snackBar=t;this.cdr=i}router;bandejaService;snackBar;cdr;displayedColumns=["folio","fechaRecepcion","nombreQuejoso","unidadAcademica","tema","prioridad","estatus","acciones"];expedientes=new Be([]);expedientesOriginal=[];prioridades=["Alta","Media","Baja"];etiquetaEstatus=Gt;claseEstatus=Yt;filtros={texto:"",orden:"recientes",prioridades:[],temas:[],escuelas:[],estatus:[]};cambios$=new b;suscripcion;ngOnInit(){this.suscripcion=this.cambios$.pipe(pt(250),ht(()=>this.bandejaService.filtrar(this.construirFiltro()))).subscribe({next:a=>{this.expedientes.data=a,this.cdr.detectChanges()},error:()=>{this.snackBar.open("No fue posible aplicar los filtros.","Cerrar",{duration:3e3})}}),this.cargarBandeja()}ngOnDestroy(){this.suscripcion?.unsubscribe()}cargarBandeja(){this.bandejaService.obtenerBandeja().subscribe({next:a=>{this.expedientesOriginal=a,this.expedientes.data=a,this.cdr.detectChanges()},error:()=>{this.cdr.detectChanges(),this.snackBar.open("No fue posible cargar la bandeja de an\xE1lisis.","Cerrar",{duration:3e3})}})}get temas(){return this.valoresDe("tema")}get escuelas(){return this.valoresDe("unidadAcademica")}get estatusDisponibles(){return Array.from(new Set(this.expedientesOriginal.map(a=>a.estatusCodigo))).filter(Boolean).sort((a,e)=>Zn.indexOf(a)-Zn.indexOf(e))}get totalFiltrosActivos(){return this.filtros.prioridades.length+this.filtros.temas.length+this.filtros.escuelas.length+this.filtros.estatus.length}estaSeleccionado(a,e){return this.filtros[a].includes(e)}toggleValor(a,e){let t=this.filtros[a],i=t.indexOf(e);i===-1?t.push(e):t.splice(i,1),this.aplicarFiltros()}contarCoincidencias(a,e){return this.expedientesOriginal.filter(t=>t[a]===e).length}aplicarFiltros(){this.cambios$.next()}limpiarFiltros(){this.filtros={texto:"",orden:"recientes",prioridades:[],temas:[],escuelas:[],estatus:[]},this.aplicarFiltros()}analizar(a){this.router.navigate(["/expediente",a.folio])}construirFiltro(){return{texto:this.filtros.texto.trim()||void 0,prioridades:this.filtros.prioridades.map(a=>a.toUpperCase()),estatusLista:this.filtros.estatus,unidadesAcademicas:this.filtros.escuelas,temas:this.filtros.temas,orden:this.filtros.orden}}valoresDe(a){return Array.from(new Set(this.expedientesOriginal.map(e=>e[a]).filter(Boolean))).sort((e,t)=>e.localeCompare(t,"es"))}static \u0275fac=function(e){return new(e||n)(fe(kt),fe(Jt),fe(xn),fe(J))};static \u0275cmp=F({type:n,selectors:[["app-bandeja-analisis"]],decls:86,vars:10,consts:[[1,"page"],[1,"page-header"],[1,"bandeja-layout"],[1,"filters-panel"],[1,"filters-panel-header"],["mat-button","",1,"clear-link"],["multi","",1,"filters-accordion"],["expanded",""],[1,"facet-option"],[1,"facet-scroll"],[1,"results-column"],[1,"search-card"],["appearance","outline",1,"search-field"],["matInput","","placeholder","Ej. PC-A1B2C3D4, FOL-12345678 o Juan Paco",3,"ngModelChange","ngModel"],["matPrefix",""],["appearance","outline",1,"order-field"],[3,"ngModelChange","selectionChange","ngModel"],["value","recientes"],["value","antiguos"],[1,"results-count"],[1,"table-card"],["mat-table","",1,"mat-elevation-z0",3,"dataSource"],["matColumnDef","folio"],["mat-header-cell","",4,"matHeaderCellDef"],["mat-cell","",4,"matCellDef"],["matColumnDef","fechaRecepcion"],["matColumnDef","nombreQuejoso"],["matColumnDef","unidadAcademica"],["matColumnDef","tema"],["matColumnDef","prioridad"],["matColumnDef","estatus"],["matColumnDef","acciones"],["mat-header-row","",4,"matHeaderRowDef"],["mat-row","",4,"matRowDef","matRowDefColumns"],[1,"empty-state"],["mat-button","",1,"clear-link",3,"click"],[3,"change","checked"],[1,"facet-count"],["mat-header-cell",""],["mat-cell",""],["matTooltip","Tiene una cita programada o confirmada",1,"cita-indicador"],["mat-flat-button","",1,"action-btn",3,"click"],["mat-header-row",""],["mat-row",""]],template:function(e,t){e&1&&(d(0,"section",0)(1,"div",1)(2,"div")(3,"h2"),u(4,"Bandeja de An\xE1lisis"),l(),d(5,"p"),u(6,"Expedientes recibidos para revisi\xF3n de Primer Contacto."),l()()(),d(7,"div",2)(8,"mat-card",3)(9,"div",4)(10,"h3"),u(11,"Filtros"),l(),A(12,vi,2,1,"button",5),l(),d(13,"mat-accordion",6)(14,"mat-expansion-panel",7)(15,"mat-expansion-panel-header")(16,"mat-panel-title"),u(17,"Prioridad"),l()(),ge(18,bi,5,3,"div",8,he),l(),d(20,"mat-expansion-panel",7)(21,"mat-expansion-panel-header")(22,"mat-panel-title"),u(23,"Tema de violaci\xF3n"),l()(),ge(24,Di,5,3,"div",8,he),l(),d(26,"mat-expansion-panel")(27,"mat-expansion-panel-header")(28,"mat-panel-title"),u(29,"Escuela"),l()(),d(30,"div",9),ge(31,Ri,5,3,"div",8,he),l()(),d(33,"mat-expansion-panel")(34,"mat-expansion-panel-header")(35,"mat-panel-title"),u(36,"Estatus"),l()(),ge(37,ki,5,3,"div",8,he),l()()(),d(39,"div",10)(40,"mat-card",11)(41,"mat-form-field",12)(42,"mat-label"),u(43,"Buscar por folio, folio de la queja o nombre"),l(),d(44,"input",13),Qe("ngModelChange",function(o){return Ue(t.filtros.texto,o)||(t.filtros.texto=o),o}),L("ngModelChange",function(){return t.aplicarFiltros()}),l(),d(45,"mat-icon",14),u(46,"search"),l()(),d(47,"mat-form-field",15)(48,"mat-label"),u(49,"Ordenar por"),l(),d(50,"mat-select",16),Qe("ngModelChange",function(o){return Ue(t.filtros.orden,o)||(t.filtros.orden=o),o}),L("selectionChange",function(){return t.aplicarFiltros()}),d(51,"mat-option",17),u(52,"M\xE1s recientes"),l(),d(53,"mat-option",18),u(54,"M\xE1s antiguos"),l()()()(),d(55,"p",19),u(56),l(),d(57,"mat-card",20)(58,"table",21),H(59,22),k(60,Si,2,0,"th",23)(61,Mi,2,1,"td",24),z(),H(62,25),k(63,Ei,2,0,"th",23)(64,Ti,2,1,"td",24),z(),H(65,26),k(66,Oi,2,0,"th",23)(67,Fi,2,1,"td",24),z(),H(68,27),k(69,Ai,2,0,"th",23)(70,Ii,2,1,"td",24),z(),H(71,28),k(72,Pi,2,0,"th",23)(73,Ni,2,1,"td",24),z(),H(74,29),k(75,Bi,2,0,"th",23)(76,ji,3,7,"td",24),z(),H(77,30),k(78,Hi,2,0,"th",23)(79,Li,4,4,"td",24),z(),H(80,31),k(81,Vi,2,0,"th",23)(82,Ui,5,0,"td",24),z(),k(83,Qi,1,0,"tr",32)(84,$i,1,0,"tr",33),l(),A(85,Wi,2,0,"p",34),l()()()()),e&2&&(m(12),I(t.totalFiltrosActivos>0?12:-1),m(6),_e(t.prioridades),m(6),_e(t.temas),m(7),_e(t.escuelas),m(6),_e(t.estatusDisponibles),m(7),Ve("ngModel",t.filtros.texto),m(6),Ve("ngModel",t.filtros.orden),m(6),Dt(" ",t.expedientes.data.length," expediente",t.expedientes.data.length===1?"":"s"," encontrado",t.expedientes.data.length===1?"":"s"," "),m(2),j("dataSource",t.expedientes),m(25),j("matHeaderRowDef",t.displayedColumns),m(),j("matRowDefColumns",t.displayedColumns),m(),I(t.expedientes.data.length===0?85:-1))},dependencies:[$t,Vt,Ut,Qt,Et,Mt,en,Kt,Wt,qt,fn,pn,un,gn,hn,yn,_n,Tn,En,qe,Ke,Mn,Kn,jn,zn,Qn,Ln,Hn,$n,Vn,Un,Wn,qn,Ht,jt,Lt,zt,Xt,Zt,Cn,wn,vn],styles:[".page[_ngcontent-%COMP%]{max-width:1280px}.page-header[_ngcontent-%COMP%]{margin-bottom:var(--space-5)}.page-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{margin:0;color:var(--guinda);font-size:28px;font-weight:800}.page-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-1) 0 0;color:var(--texto-suave)}.bandeja-layout[_ngcontent-%COMP%]{display:grid;grid-template-columns:260px 1fr;gap:var(--space-5);align-items:start}.filters-panel[_ngcontent-%COMP%]{border-radius:14px;box-shadow:0 2px 8px #0f172a14;padding:var(--space-4);position:sticky;top:calc(72px + var(--space-5));background:#fff}.filters-panel-header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;margin-bottom:var(--space-2)}.filters-panel-header[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{margin:0;font-size:var(--font-size-lg);font-weight:900;color:var(--negro-inst)}.clear-link[_ngcontent-%COMP%]{color:var(--guinda)!important;font-weight:700;font-size:var(--font-size-sm);min-width:0;padding:0 var(--space-2)}.filters-accordion[_ngcontent-%COMP%]   .mat-expansion-panel[_ngcontent-%COMP%]{box-shadow:none!important;border-bottom:1px solid #f1f1f3}.filters-accordion[_ngcontent-%COMP%]   .mat-expansion-panel[_ngcontent-%COMP%]:last-child{border-bottom:none}.filters-accordion[_ngcontent-%COMP%]   mat-panel-title[_ngcontent-%COMP%]{font-weight:800;color:var(--negro-inst);font-size:var(--font-size-base)}.facet-option[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;gap:var(--space-2);padding:var(--space-1) 0}.facet-option[_ngcontent-%COMP%]   mat-checkbox[_ngcontent-%COMP%]{font-size:var(--font-size-sm)}.facet-count[_ngcontent-%COMP%]{color:#9ca3af;font-size:var(--font-size-xs);font-weight:700}.facet-scroll[_ngcontent-%COMP%]{max-height:220px;overflow-y:auto;padding-right:var(--space-1)}.results-column[_ngcontent-%COMP%]{display:grid;gap:var(--space-4);min-width:0}.search-card[_ngcontent-%COMP%]{border-radius:14px;box-shadow:0 2px 8px #0f172a14;padding:var(--space-4);display:grid;grid-template-columns:1fr 220px;align-items:start;gap:var(--space-4);background:#fff}.search-field[_ngcontent-%COMP%], .order-field[_ngcontent-%COMP%]{width:100%}.search-card[_ngcontent-%COMP%]     .mat-mdc-form-field-subscript-wrapper{display:none}.results-count[_ngcontent-%COMP%]{margin:0;color:var(--texto-suave);font-size:var(--font-size-sm);font-weight:700}.table-card[_ngcontent-%COMP%]{overflow-x:auto;border-radius:14px;box-shadow:0 2px 8px #0f172a14;padding:0;background:#fff}table[_ngcontent-%COMP%]{width:100%;min-width:900px}th[_ngcontent-%COMP%]{background:var(--negro-inst)!important;color:#fff;font-weight:800}td[_ngcontent-%COMP%], th[_ngcontent-%COMP%]{padding:var(--space-4)!important}tr[_ngcontent-%COMP%]:hover   td[_ngcontent-%COMP%]{background:#f9fafb}mat-chip[_ngcontent-%COMP%]{font-weight:700}.chip-high[_ngcontent-%COMP%]{background:#ffebee!important;color:var(--peligro)!important}.chip-medium[_ngcontent-%COMP%]{background:#fdf6e3!important;color:var(--advertencia)!important}.chip-low[_ngcontent-%COMP%]{background:#e8f5e9!important;color:var(--exito)!important}.status[_ngcontent-%COMP%]{font-weight:700;color:var(--texto)}.action-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important;font-weight:700;border-radius:8px;padding:0 var(--space-4)}.empty-state[_ngcontent-%COMP%]{text-align:center;color:var(--texto-suave);padding:var(--space-6);margin:0}@media(max-width:1000px){.bandeja-layout[_ngcontent-%COMP%]{grid-template-columns:1fr}.filters-panel[_ngcontent-%COMP%]{position:static}.search-card[_ngcontent-%COMP%]{grid-template-columns:1fr}}"]})};export{Xn as BandejaAnalisis};
