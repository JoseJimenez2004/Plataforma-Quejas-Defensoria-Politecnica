import { ChangeDetectorRef, Component, HostListener, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

import { AuthAdminService } from '../../core/services/auth-admin.service';
import { PerfilService } from '../../core/services/perfil.service';
import { ToastService } from '../../core/services/toast.service';
import { CambiarPasswordRequest, etiquetaRol, etiquetaRolPersona, iniciales } from '../../core/models/admin.models';
import { irALoginPersonal } from '../../core/sesion/sesion-personal';
import { CampanaNotificaciones } from '../../shared/campana-notificaciones/campana-notificaciones';

@Component({
  selector: 'app-admin-layout',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, RouterLinkActive, RouterOutlet, CampanaNotificaciones],
  templateUrl: './admin-layout.html',
  styleUrl: './admin-layout.scss',
})
export class AdminLayout implements OnInit {
  readonly etiquetaRol = etiquetaRol;
  readonly anio = new Date().getFullYear();

  /** "Panel de la Defensora" para el rol DEFENSOR; "Panel de Administración" para la cuenta técnica. */
  get tituloPanel(): string {
    return this.authService.usuarioActual()?.rol === 'DEFENSOR' ? 'Panel de la Defensora' : 'Panel de Administración';
  }

  menuAbierto = false;
  mostrarModalPassword = false;
  cambioObligatorio = false;

  passwordActual = '';
  passwordNueva = '';
  passwordConfirmar = '';
  mostrarActual = false;
  mostrarNueva = false;
  guardandoPassword = false;
  errorPassword = '';

  constructor(
    public authService: AuthAdminService,
    private perfilService: PerfilService,
    private router: Router,
    private toast: ToastService,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    const usuario = this.authService.usuarioActual();
    if (usuario?.forzarCambioPassword) {
      this.cambioObligatorio = true;
      this.abrirModalPassword();
    }
  }

  get nombreUsuario(): string {
    return this.authService.usuarioActual()?.nombre ?? '';
  }

  get rolUsuario(): string {
    const rol = this.authService.usuarioActual()?.rol;
    return rol ? etiquetaRolPersona(rol, this.nombreUsuario) : '';
  }

  get inicialesUsuario(): string {
    return iniciales(this.nombreUsuario);
  }

  @HostListener('document:click')
  cerrarMenuAlHacerClickFuera(): void {
    this.menuAbierto = false;
  }

  alternarMenu(evento: Event): void {
    evento.stopPropagation();
    this.menuAbierto = !this.menuAbierto;
  }

  abrirModalPassword(): void {
    this.menuAbierto = false;
    this.passwordActual = '';
    this.passwordNueva = '';
    this.passwordConfirmar = '';
    this.errorPassword = '';
    this.mostrarModalPassword = true;
  }

  cerrarModalPassword(): void {
    if (this.cambioObligatorio) {
      this.toast.advertencia('Debes actualizar tu contraseña temporal antes de continuar.');
      return;
    }
    this.mostrarModalPassword = false;
  }

  get cumpleLongitud(): boolean {
    return this.passwordNueva.length >= 8;
  }

  get cumpleMayuscula(): boolean {
    return /[A-Z]/.test(this.passwordNueva);
  }

  get cumpleNumero(): boolean {
    return /\d/.test(this.passwordNueva);
  }

  get cumpleCoinciden(): boolean {
    return this.passwordNueva.length > 0 && this.passwordNueva === this.passwordConfirmar;
  }

  guardarPassword(): void {
    this.errorPassword = '';

    if (!this.passwordActual) {
      this.errorPassword = 'Ingresa tu contraseña actual.';
      return;
    }
    if (!this.cumpleLongitud || !this.cumpleMayuscula || !this.cumpleNumero) {
      this.errorPassword = 'La nueva contraseña no cumple los requisitos.';
      return;
    }
    if (!this.cumpleCoinciden) {
      this.errorPassword = 'La confirmación no coincide con la nueva contraseña.';
      return;
    }

    const datos: CambiarPasswordRequest = {
      passwordActual: this.passwordActual,
      passwordNueva: this.passwordNueva,
    };

    this.guardandoPassword = true;
    this.perfilService.cambiarPassword(datos).subscribe({
      next: () => {
        this.guardandoPassword = false;
        this.cambioObligatorio = false;
        this.mostrarModalPassword = false;
        this.authService.marcarPasswordActualizada();
        this.toast.exito('Contraseña actualizada correctamente.');
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.guardandoPassword = false;
        this.errorPassword = err?.error?.mensaje ?? 'No se pudo actualizar la contraseña.';
        this.cdr.detectChanges();
      },
    });
  }

  cerrarSesion(): void {
    this.authService.logout();
    irALoginPersonal();
  }
}
