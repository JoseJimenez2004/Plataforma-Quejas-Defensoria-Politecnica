import{$ as E,$a as He,$b as np,A as Im,Aa as B,Ab as Ke,Ac as xt,B as ut,Ba as di,Bb as te,Bc as cp,C as Ce,Ca as jm,Cb as ne,Cc as lp,D as So,Da as Wi,Db as P,Dc as Oo,E as va,Ea as Vm,Eb as s,Ec as dp,F as ya,Fa as wa,Fb as r,Fc as Z,G as On,Ga as Da,Gb as H,Gc as mi,H as it,Ha as Ea,Hb as Te,Hc as up,I as jl,Ia as ts,Ib as Be,Ic as R,J as xa,Ja as Sa,Jb as yt,Jc as lt,K as li,Ka as ka,Kb as pn,Kc as mp,L as Vl,La as zm,Lb as hn,Lc as rs,M as zl,Ma as Um,Mb as ot,N as Am,Na as Hm,Nb as T,O as ko,Oa as $m,Ob as jt,P as Ca,Pa as Gm,Pb as Yt,Q as tt,Qa as qm,Qb as rt,R as at,Ra as Wm,Rb as _,S as pe,Sa as Bt,Sb as os,T as Rm,Ta as Qm,Tb as h,U as _t,Ua as ns,Ub as ye,V as oe,Va as d,Vb as ee,W as Mo,Wa as Ma,Wb as st,X as It,Xa as Ym,Xb as Ae,Y as D,Ya as is,Yb as j,Z as G,Za as Hl,Zb as V,_ as Tm,_a as Pe,_b as tp,a as M,aa as U,ab as vt,ac as Ql,b as Re,ba as m,bb as Se,bc as ct,ca as Hi,cb as S,cc as Gt,d as $e,da as Om,db as $l,dc as k,e as Le,ea as bt,eb as Xe,ec as ve,f as Sm,fa as $t,fb as as,fc as l,g as Ht,ga as x,gb as Xm,gc as g,h as km,ha as C,hb as Gl,hc as N,i as F,ia as Zn,ib as A,ic as qe,j as et,ja as Pm,jb as q,jc as Nn,k as Fl,ka as re,kb as I,kc as ip,l as Nl,la as X,lb as ql,lc as he,m as Ll,ma as $i,mb as Km,mc as fe,n as mt,na as Fm,nb as ie,nc as ge,o as Lt,oa as z,ob as _e,oc as ce,p as K,pa as W,pb as Zm,pc as Yl,q as Zr,qa as Gi,qb as Wl,qc as ap,r as ba,ra as Io,rb as ui,rc as op,s as Mm,sa as Nm,sb as Ao,sc as Ro,t as Q,ta as le,tb as Jm,tc as To,u as nn,ua as Lm,ub as Pn,uc as Ia,v as Kn,va as Bm,vb as ep,vc as rp,w as Bl,wa as qi,wb as Y,wc as Xl,x as Jr,xa as we,xb as v,xc as ke,y as Tn,ya as De,yb as y,yc as Vt,z as es,za as Ul,zb as Fn,zc as sp}from"./chunk-5QK2ZE4A.js";var pp=null;function an(){return pp}function Kl(n){pp??=n}var Po=class{},Aa=(()=>{class n{historyGo(e){throw new Error("")}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:()=>m(hp),providedIn:"platform"})}return n})();var hp=(()=>{class n extends Aa{_location;_history;_doc=m(X);constructor(){super(),this._location=window.location,this._history=window.history}getBaseHrefFromDOM(){return an().getBaseHref(this._doc)}onPopState(e){let t=an().getGlobalEventTarget(this._doc,"window");return t.addEventListener("popstate",e,!1),()=>t.removeEventListener("popstate",e)}onHashChange(e){let t=an().getGlobalEventTarget(this._doc,"window");return t.addEventListener("hashchange",e,!1),()=>t.removeEventListener("hashchange",e)}get href(){return this._location.href}get protocol(){return this._location.protocol}get hostname(){return this._location.hostname}get port(){return this._location.port}get pathname(){return this._location.pathname}get search(){return this._location.search}get hash(){return this._location.hash}set pathname(e){this._location.pathname=e}pushState(e,t,a){this._history.pushState(e,t,a)}replaceState(e,t,a){this._history.replaceState(e,t,a)}forward(){this._history.forward()}back(){this._history.back()}historyGo(e=0){this._history.go(e)}getState(){return this._history.state}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:()=>new n,providedIn:"platform"})}return n})();function _p(n,i){return n?i?n.endsWith("/")?i.startsWith("/")?n+i.slice(1):n+i:i.startsWith("/")?n+i:`${n}/${i}`:n:i}function fp(n){let i=n.search(/#|\?|$/);return n[i-1]==="/"?n.slice(0,i-1)+n.slice(i):n}function pi(n){return n&&n[0]!=="?"?`?${n}`:n}var Ra=(()=>{class n{historyGo(e){throw new Error("")}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:()=>m(M0),providedIn:"root"})}return n})(),k0=new E(""),M0=(()=>{class n extends Ra{_platformLocation;_baseHref;_removeListenerFns=[];constructor(e,t){super(),this._platformLocation=e,this._baseHref=t??this._platformLocation.getBaseHrefFromDOM()??m(X).location?.origin??""}ngOnDestroy(){for(;this._removeListenerFns.length;)this._removeListenerFns.pop()()}onPopState(e){this._removeListenerFns.push(this._platformLocation.onPopState(e),this._platformLocation.onHashChange(e))}getBaseHref(){return this._baseHref}prepareExternalUrl(e){return _p(this._baseHref,e)}path(e=!1){let t=this._platformLocation.pathname+pi(this._platformLocation.search),a=this._platformLocation.hash;return a&&e?`${t}${a}`:t}pushState(e,t,a,o){let c=this.prepareExternalUrl(a+pi(o));this._platformLocation.pushState(e,t,c)}replaceState(e,t,a,o){let c=this.prepareExternalUrl(a+pi(o));this._platformLocation.replaceState(e,t,c)}forward(){this._platformLocation.forward()}back(){this._platformLocation.back()}getState(){return this._platformLocation.getState()}historyGo(e=0){this._platformLocation.historyGo?.(e)}static \u0275fac=function(t){return new(t||n)(U(Aa),U(k0,8))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var hi=(()=>{class n{_subject=new F;_basePath;_locationStrategy;_urlChangeListeners=[];_urlChangeSubscription=null;constructor(e){this._locationStrategy=e;let t=this._locationStrategy.getBaseHref();this._basePath=R0(fp(gp(t))),this._locationStrategy.onPopState(a=>{this._subject.next({url:this.path(!0),pop:!0,state:a.state,type:a.type})})}ngOnDestroy(){this._urlChangeSubscription?.unsubscribe(),this._urlChangeListeners=[]}path(e=!1){return this.normalize(this._locationStrategy.path(e))}getState(){return this._locationStrategy.getState()}isCurrentPathEqualTo(e,t=""){return this.path()==this.normalize(e+pi(t))}normalize(e){return n.stripTrailingSlash(A0(this._basePath,gp(e)))}prepareExternalUrl(e){return e&&e[0]!=="/"&&(e="/"+e),this._locationStrategy.prepareExternalUrl(e)}go(e,t="",a=null){this._locationStrategy.pushState(a,"",e,t),this._notifyUrlChangeListeners(this.prepareExternalUrl(e+pi(t)),a)}replaceState(e,t="",a=null){this._locationStrategy.replaceState(a,"",e,t),this._notifyUrlChangeListeners(this.prepareExternalUrl(e+pi(t)),a)}forward(){this._locationStrategy.forward()}back(){this._locationStrategy.back()}historyGo(e=0){this._locationStrategy.historyGo?.(e)}onUrlChange(e){return this._urlChangeListeners.push(e),this._urlChangeSubscription??=this.subscribe(t=>{this._notifyUrlChangeListeners(t.url,t.state)}),()=>{let t=this._urlChangeListeners.indexOf(e);this._urlChangeListeners.splice(t,1),this._urlChangeListeners.length===0&&(this._urlChangeSubscription?.unsubscribe(),this._urlChangeSubscription=null)}}_notifyUrlChangeListeners(e="",t){this._urlChangeListeners.forEach(a=>a(e,t))}subscribe(e,t,a){return this._subject.subscribe({next:e,error:t??void 0,complete:a??void 0})}static normalizeQueryParams=pi;static joinWithSlash=_p;static stripTrailingSlash=fp;static \u0275fac=function(t){return new(t||n)(U(Ra))};static \u0275prov=D({token:n,factory:()=>I0(),providedIn:"root"})}return n})();function I0(){return new hi(U(Ra))}function A0(n,i){if(!n||!i.startsWith(n))return i;let e=i.substring(n.length);return e===""||["/",";","?","#"].includes(e[0])?e:i}function gp(n){return n.replace(/\/index\.html$/,"")}function R0(n){if(new RegExp("^(https?:)?//").test(n)){let[,e]=n.split(/\/\/[^\/]+/);return e}return n}var id=(function(n){return n[n.Decimal=0]="Decimal",n[n.Percent=1]="Percent",n[n.Currency=2]="Currency",n[n.Scientific=3]="Scientific",n})(id||{});var At=(function(n){return n[n.Format=0]="Format",n[n.Standalone=1]="Standalone",n})(At||{}),Fe=(function(n){return n[n.Narrow=0]="Narrow",n[n.Abbreviated=1]="Abbreviated",n[n.Wide=2]="Wide",n[n.Short=3]="Short",n})(Fe||{}),qt=(function(n){return n[n.Short=0]="Short",n[n.Medium=1]="Medium",n[n.Long=2]="Long",n[n.Full=3]="Full",n})(qt||{}),Wt={Decimal:0,Group:1,List:2,PercentSign:3,PlusSign:4,MinusSign:5,Exponential:6,SuperscriptingExponent:7,PerMille:8,Infinity:9,NaN:10,TimeSeparator:11,CurrencyDecimal:12,CurrencyGroup:13};function yp(n){return Yt(n)[rt.LocaleId]}function xp(n,i,e){let t=Yt(n),a=[t[rt.DayPeriodsFormat],t[rt.DayPeriodsStandalone]],o=on(a,i);return on(o,e)}function Cp(n,i,e){let t=Yt(n),a=[t[rt.DaysFormat],t[rt.DaysStandalone]],o=on(a,i);return on(o,e)}function wp(n,i,e){let t=Yt(n),a=[t[rt.MonthsFormat],t[rt.MonthsStandalone]],o=on(a,i);return on(o,e)}function Dp(n,i){let t=Yt(n)[rt.Eras];return on(t,i)}function Fo(n,i){let e=Yt(n);return on(e[rt.DateFormat],i)}function No(n,i){let e=Yt(n);return on(e[rt.TimeFormat],i)}function Lo(n,i){let t=Yt(n)[rt.DateTimeFormat];return on(t,i)}function Ln(n,i){let e=Yt(n),t=e[rt.NumberSymbols][i];if(typeof t>"u"){if(i===Wt.CurrencyDecimal)return e[rt.NumberSymbols][Wt.Decimal];if(i===Wt.CurrencyGroup)return e[rt.NumberSymbols][Wt.Group]}return t}function Ep(n,i){return Yt(n)[rt.NumberFormats][i]}function Sp(n){if(!n[rt.ExtraData])throw new oe(2303,!1)}function kp(n){let i=Yt(n);return Sp(i),(i[rt.ExtraData][2]||[]).map(t=>typeof t=="string"?Zl(t):[Zl(t[0]),Zl(t[1])])}function Mp(n,i,e){let t=Yt(n);Sp(t);let a=[t[rt.ExtraData][0],t[rt.ExtraData][1]],o=on(a,i)||[];return on(o,e)||[]}function on(n,i){for(let e=i;e>-1;e--)if(typeof n[e]<"u")return n[e];throw new oe(2304,!1)}function Zl(n){let[i,e]=n.split(":");return{hours:+i,minutes:+e}}var T0=/^(\d{4,})-?(\d\d)-?(\d\d)(?:T(\d\d)(?::?(\d\d)(?::?(\d\d)(?:\.(\d+))?)?)?(Z|([+-])(\d\d):?(\d\d))?)?$/,ss={},O0=/((?:[^BEGHLMOSWYZabcdhmswyz']+)|(?:'(?:[^']|'')*')|(?:G{1,5}|y{1,4}|Y{1,4}|M{1,5}|L{1,5}|w{1,2}|W{1}|d{1,2}|E{1,6}|c{1,6}|a{1,5}|b{1,5}|B{1,5}|h{1,2}|H{1,2}|m{1,2}|s{1,2}|S{1,3}|z{1,4}|Z{1,5}|O{1,4}))([\s\S]*)/,P0=256;function Ip(n,i,e,t){let a=$0(n);F0(i),i=Jn(e,i)||i;let c=[],u;for(;i;)if(u=O0.exec(i),u){c=c.concat(u.slice(1));let b=c.pop();if(!b)break;i=b}else{c.push(i);break}let p=a.getTimezoneOffset();t&&(p=Rp(t,p),a=H0(a,t));let f="";return c.forEach(b=>{let w=z0(b);f+=w?w(a,e,p):b==="''"?"'":b.replace(/(^'|'$)/g,"").replace(/''/g,"'")}),f}function F0(n){if(n.length>P0)throw new oe(2300,!1)}function ms(n,i,e){let t=new Date(0);return t.setFullYear(n,i,e),t.setHours(0,0,0),t}function Jn(n,i){let e=yp(n);if(ss[e]??={},ss[e][i])return ss[e][i];let t="";switch(i){case"shortDate":t=Fo(n,qt.Short);break;case"mediumDate":t=Fo(n,qt.Medium);break;case"longDate":t=Fo(n,qt.Long);break;case"fullDate":t=Fo(n,qt.Full);break;case"shortTime":t=No(n,qt.Short);break;case"mediumTime":t=No(n,qt.Medium);break;case"longTime":t=No(n,qt.Long);break;case"fullTime":t=No(n,qt.Full);break;case"short":let a=Jn(n,"shortTime"),o=Jn(n,"shortDate");t=cs(Lo(n,qt.Short),[a,o]);break;case"medium":let c=Jn(n,"mediumTime"),u=Jn(n,"mediumDate");t=cs(Lo(n,qt.Medium),[c,u]);break;case"long":let p=Jn(n,"longTime"),f=Jn(n,"longDate");t=cs(Lo(n,qt.Long),[p,f]);break;case"full":let b=Jn(n,"fullTime"),w=Jn(n,"fullDate");t=cs(Lo(n,qt.Full),[b,w]);break}return t&&(ss[e][i]=t),t}function cs(n,i){return i&&(n=n.replace(/\{([^}]+)}/g,function(e,t){return i!=null&&t in i?i[t]:e})),n}function fn(n,i,e="-",t,a){let o="";(n<0||a&&n<=0)&&(a?n=-n+1:(n=-n,o=e));let c=String(n);for(;c.length<i;)c="0"+c;return t&&(c=c.slice(c.length-i)),o+c}function N0(n,i){return fn(n,3).substring(0,i)}function dt(n,i,e=0,t=!1,a=!1){return function(o,c){let u=L0(n,o);if((e>0||u>-e)&&(u+=e),n===3)u===0&&e===-12&&(u=12);else if(n===6)return N0(u,i);let p=Ln(c,Wt.MinusSign);return fn(u,i,p,t,a)}}function L0(n,i){switch(n){case 0:return i.getFullYear();case 1:return i.getMonth();case 2:return i.getDate();case 3:return i.getHours();case 4:return i.getMinutes();case 5:return i.getSeconds();case 6:return i.getMilliseconds();case 7:return i.getDay();default:throw new oe(2301,!1)}}function je(n,i,e=At.Format,t=!1){return function(a,o){return B0(a,o,n,i,e,t)}}function B0(n,i,e,t,a,o){switch(e){case 2:return wp(i,a,t)[n.getMonth()];case 1:return Cp(i,a,t)[n.getDay()];case 0:let c=n.getHours(),u=n.getMinutes();if(o){let f=kp(i),b=Mp(i,a,t),w=f.findIndex(L=>{if(Array.isArray(L)){let[$,ae]=L,me=c>=$.hours&&u>=$.minutes,J=c<ae.hours||c===ae.hours&&u<ae.minutes;if($.hours<ae.hours){if(me&&J)return!0}else if(me||J)return!0}else if(L.hours===c&&L.minutes===u)return!0;return!1});if(w!==-1)return b[w]}return xp(i,a,t)[c<12?0:1];case 3:return Dp(i,t)[n.getFullYear()<=0?0:1];default:let p=e;throw new oe(2302,!1)}}function ls(n){return function(i,e,t){let a=-1*t,o=Ln(e,Wt.MinusSign),c=a>0?Math.floor(a/60):Math.ceil(a/60);switch(n){case 0:return(a>=0?"+":"")+fn(c,2,o)+fn(Math.abs(a%60),2,o);case 1:return"GMT"+(a>=0?"+":"")+fn(c,1,o);case 2:return"GMT"+(a>=0?"+":"")+fn(c,2,o)+":"+fn(Math.abs(a%60),2,o);case 3:return t===0?"Z":(a>=0?"+":"")+fn(c,2,o)+":"+fn(Math.abs(a%60),2,o);default:throw new oe(2310,!1)}}}var j0=0,us=4;function V0(n){let i=ms(n,j0,1).getDay();return ms(n,0,1+(i<=us?us:us+7)-i)}function Ap(n){let i=n.getDay(),e=i===0?-3:us-i;return ms(n.getFullYear(),n.getMonth(),n.getDate()+e)}function Jl(n,i=!1){return function(e,t){let a;if(i){let o=new Date(e.getFullYear(),e.getMonth(),1).getDay()-1,c=e.getDate();a=1+Math.floor((c+o)/7)}else{let o=Ap(e),c=V0(o.getFullYear()),u=o.getTime()-c.getTime();a=1+Math.round(u/6048e5)}return fn(a,n,Ln(t,Wt.MinusSign))}}function ds(n,i=!1){return function(e,t){let o=Ap(e).getFullYear();return fn(o,n,Ln(t,Wt.MinusSign),i)}}var ed={};function z0(n){if(ed[n])return ed[n];let i;switch(n){case"G":case"GG":case"GGG":i=je(3,Fe.Abbreviated);break;case"GGGG":i=je(3,Fe.Wide);break;case"GGGGG":i=je(3,Fe.Narrow);break;case"y":i=dt(0,1,0,!1,!0);break;case"yy":i=dt(0,2,0,!0,!0);break;case"yyy":i=dt(0,3,0,!1,!0);break;case"yyyy":i=dt(0,4,0,!1,!0);break;case"Y":i=ds(1);break;case"YY":i=ds(2,!0);break;case"YYY":i=ds(3);break;case"YYYY":i=ds(4);break;case"M":case"L":i=dt(1,1,1);break;case"MM":case"LL":i=dt(1,2,1);break;case"MMM":i=je(2,Fe.Abbreviated);break;case"MMMM":i=je(2,Fe.Wide);break;case"MMMMM":i=je(2,Fe.Narrow);break;case"LLL":i=je(2,Fe.Abbreviated,At.Standalone);break;case"LLLL":i=je(2,Fe.Wide,At.Standalone);break;case"LLLLL":i=je(2,Fe.Narrow,At.Standalone);break;case"w":i=Jl(1);break;case"ww":i=Jl(2);break;case"W":i=Jl(1,!0);break;case"d":i=dt(2,1);break;case"dd":i=dt(2,2);break;case"c":case"cc":i=dt(7,1);break;case"ccc":i=je(1,Fe.Abbreviated,At.Standalone);break;case"cccc":i=je(1,Fe.Wide,At.Standalone);break;case"ccccc":i=je(1,Fe.Narrow,At.Standalone);break;case"cccccc":i=je(1,Fe.Short,At.Standalone);break;case"E":case"EE":case"EEE":i=je(1,Fe.Abbreviated);break;case"EEEE":i=je(1,Fe.Wide);break;case"EEEEE":i=je(1,Fe.Narrow);break;case"EEEEEE":i=je(1,Fe.Short);break;case"a":case"aa":case"aaa":i=je(0,Fe.Abbreviated);break;case"aaaa":i=je(0,Fe.Wide);break;case"aaaaa":i=je(0,Fe.Narrow);break;case"b":case"bb":case"bbb":i=je(0,Fe.Abbreviated,At.Standalone,!0);break;case"bbbb":i=je(0,Fe.Wide,At.Standalone,!0);break;case"bbbbb":i=je(0,Fe.Narrow,At.Standalone,!0);break;case"B":case"BB":case"BBB":i=je(0,Fe.Abbreviated,At.Format,!0);break;case"BBBB":i=je(0,Fe.Wide,At.Format,!0);break;case"BBBBB":i=je(0,Fe.Narrow,At.Format,!0);break;case"h":i=dt(3,1,-12);break;case"hh":i=dt(3,2,-12);break;case"H":i=dt(3,1);break;case"HH":i=dt(3,2);break;case"m":i=dt(4,1);break;case"mm":i=dt(4,2);break;case"s":i=dt(5,1);break;case"ss":i=dt(5,2);break;case"S":i=dt(6,1);break;case"SS":i=dt(6,2);break;case"SSS":i=dt(6,3);break;case"Z":case"ZZ":case"ZZZ":i=ls(0);break;case"ZZZZZ":i=ls(3);break;case"O":case"OO":case"OOO":case"z":case"zz":case"zzz":i=ls(1);break;case"OOOO":case"ZZZZ":case"zzzz":i=ls(2);break;default:return null}return ed[n]=i,i}function Rp(n,i){n=n.replace(/:/g,"");let e=Date.parse("Jan 01, 1970 00:00:00 "+n)/6e4;return isNaN(e)?i:e}function U0(n,i){return n=new Date(n.getTime()),n.setMinutes(n.getMinutes()+i),n}function H0(n,i,e){let a=n.getTimezoneOffset(),o=Rp(i,a);return U0(n,-1*(o-a))}function $0(n){if(bp(n))return n;if(typeof n=="number"&&!isNaN(n))return new Date(n);if(typeof n=="string"){if(n=n.trim(),/^(\d{4}(-\d{1,2}(-\d{1,2})?)?)$/.test(n)){let[a,o=1,c=1]=n.split("-").map(u=>+u);return ms(a,o-1,c)}let e=parseFloat(n);if(!isNaN(n-e))return new Date(e);let t;if(t=n.match(T0))return G0(t)}let i=new Date(n);if(!bp(i))throw new oe(2311,!1);return i}function G0(n){let i=new Date(0),e=0,t=0,a=n[8]?i.setUTCFullYear:i.setFullYear,o=n[8]?i.setUTCHours:i.setHours;n[9]&&(e=Number(n[9]+n[10]),t=Number(n[9]+n[11])),a.call(i,Number(n[1]),Number(n[2])-1,Number(n[3]));let c=Number(n[4]||0)-e,u=Number(n[5]||0)-t,p=Number(n[6]||0),f=Math.floor(parseFloat("0."+(n[7]||0))*1e3);return o.call(i,c,u,p,f),i}function bp(n){return n instanceof Date&&!isNaN(n.valueOf())}var q0=/^(\d+)?\.((\d+)(-(\d+))?)?$/,vp=22,ps=".",Bo="0",W0=";",Q0=",",td="#";function Y0(n,i,e,t,a,o,c=!1){let u="",p=!1;if(!isFinite(n))u=Ln(e,Wt.Infinity);else{let f=Z0(n);c&&(f=K0(f));let b=i.minInt,w=i.minFrac,L=i.maxFrac;if(o){let Ie=o.match(q0);if(Ie===null)throw new oe(2306,!1);let gt=Ie[1],Ye=Ie[3],ci=Ie[5];gt!=null&&(b=nd(gt)),Ye!=null&&(w=nd(Ye)),ci!=null?L=nd(ci):Ye!=null&&w>L&&(L=w);let Xn=100;if(b>Xn||w>Xn||L>Xn)throw new oe(2306,!1)}J0(f,w,L);let $=f.digits,ae=f.integerLen,me=f.exponent,J=[];for(p=$.every(Ie=>!Ie);ae<b;ae++)$.unshift(0);for(;ae<0;ae++)$.unshift(0);ae>0?J=$.splice(ae,$.length):(J=$,$=[0]);let se=[];for($.length>=i.lgSize&&se.unshift($.splice(-i.lgSize,$.length).join(""));$.length>i.gSize;)se.unshift($.splice(-i.gSize,$.length).join(""));$.length&&se.unshift($.join("")),u=se.join(Ln(e,t)),J.length&&(u+=Ln(e,a)+J.join("")),me&&(u+=Ln(e,Wt.Exponential)+"+"+me)}return n<0&&!p?u=i.negPre+u+i.negSuf:u=i.posPre+u+i.posSuf,u}function Tp(n,i,e){let t=Ep(i,id.Decimal),a=X0(t,Ln(i,Wt.MinusSign));return Y0(n,a,i,Wt.Group,Wt.Decimal,e)}function X0(n,i="-"){let e={minInt:1,minFrac:0,maxFrac:0,posPre:"",posSuf:"",negPre:"",negSuf:"",gSize:0,lgSize:0},t=n.split(W0),a=t[0],o=t[1],c=a.indexOf(ps)!==-1?a.split(ps):[a.substring(0,a.lastIndexOf(Bo)+1),a.substring(a.lastIndexOf(Bo)+1)],u=c[0],p=c[1]||"";e.posPre=u.substring(0,u.indexOf(td));for(let b=0;b<p.length;b++){let w=p.charAt(b);w===Bo?e.minFrac=e.maxFrac=b+1:w===td?e.maxFrac=b+1:e.posSuf+=w}let f=u.split(Q0);if(e.gSize=f[1]?f[1].length:0,e.lgSize=f[2]||f[1]?(f[2]||f[1]).length:0,o){let b=a.length-e.posPre.length-e.posSuf.length,w=o.indexOf(td);e.negPre=o.substring(0,w).replace(/'/g,""),e.negSuf=o.slice(w+b).replace(/'/g,"")}else e.negPre=i+e.posPre,e.negSuf=e.posSuf;return e}function K0(n){if(n.digits[0]===0)return n;let i=n.digits.length-n.integerLen;return n.exponent?n.exponent+=2:(i===0?n.digits.push(0,0):i===1&&n.digits.push(0),n.integerLen+=2),n}function Z0(n){let i=Math.abs(n)+"",e=0,t,a,o,c,u;for((a=i.indexOf(ps))>-1&&(i=i.replace(ps,"")),(o=i.search(/e/i))>0?(a<0&&(a=o),a+=+i.slice(o+1),i=i.substring(0,o)):a<0&&(a=i.length),o=0;i.charAt(o)===Bo;o++);if(o===(u=i.length))t=[0],a=1;else{for(u--;i.charAt(u)===Bo;)u--;for(a-=o,t=[],c=0;o<=u;o++,c++)t[c]=Number(i.charAt(o))}return a>vp&&(t=t.splice(0,vp-1),e=a-1,a=1),{digits:t,exponent:e,integerLen:a}}function J0(n,i,e){if(i>e)throw new oe(2307,!1);let t=n.digits,a=t.length-n.integerLen,o=Math.min(Math.max(i,a),e),c=o+n.integerLen,u=t[c];if(c>0){t.splice(Math.max(n.integerLen,c));for(let w=c;w<t.length;w++)t[w]=0}else{a=Math.max(0,a),n.integerLen=1,t.length=Math.max(1,c=o+1),t[0]=0;for(let w=1;w<c;w++)t[w]=0}if(u>=5)if(c-1<0){for(let w=0;w>c;w--)t.unshift(0),n.integerLen++;t.unshift(1),n.integerLen++}else t[c-1]++;for(;a<Math.max(0,o);a++)t.push(0);let p=o!==0,f=i+n.integerLen,b=t.reduceRight(function(w,L,$,ae){return L=L+w,ae[$]=L<10?L:L-10,p&&(ae[$]===0&&$>=f?ae.pop():p=!1),L>=10?1:0},0);b&&(t.unshift(b),n.integerLen++)}function nd(n){let i=parseInt(n);if(isNaN(i))throw new oe(2305,!1);return i}var Qi=(()=>{class n{_viewContainerRef;_viewRef=null;ngTemplateOutletContext=null;ngTemplateOutlet=null;ngTemplateOutletInjector=null;injector=m(re);constructor(e){this._viewContainerRef=e}ngOnChanges(e){if(this._shouldRecreateView(e)){let t=this._viewContainerRef;if(this._viewRef&&t.remove(t.indexOf(this._viewRef)),!this.ngTemplateOutlet){this._viewRef=null;return}let a=this._createContextForwardProxy();this._viewRef=t.createEmbeddedView(this.ngTemplateOutlet,a,{injector:this._getInjector()})}}_getInjector(){return this.ngTemplateOutletInjector==="outlet"?this.injector:this.ngTemplateOutletInjector??void 0}_shouldRecreateView(e){return!!e.ngTemplateOutlet||!!e.ngTemplateOutletInjector}_createContextForwardProxy(){return new Proxy({},{set:(e,t,a)=>this.ngTemplateOutletContext?Reflect.set(this.ngTemplateOutletContext,t,a):!1,get:(e,t,a)=>{if(this.ngTemplateOutletContext)return Reflect.get(this.ngTemplateOutletContext,t,a)}})}static \u0275fac=function(t){return new(t||n)(S(Xe))};static \u0275dir=I({type:n,selectors:[["","ngTemplateOutlet",""]],inputs:{ngTemplateOutletContext:"ngTemplateOutletContext",ngTemplateOutlet:"ngTemplateOutlet",ngTemplateOutletInjector:"ngTemplateOutletInjector"},features:[we]})}return n})();function Op(n,i){return new oe(2100,!1)}var eb="mediumDate",Pp=new E(""),Fp=new E(""),ad=(()=>{class n{locale;defaultTimezone;defaultOptions;constructor(e,t,a){this.locale=e,this.defaultTimezone=t,this.defaultOptions=a}transform(e,t,a,o){if(e==null||e===""||e!==e)return null;try{let c=t??this.defaultOptions?.dateFormat??eb,u=a??this.defaultOptions?.timezone??this.defaultTimezone??void 0;return Ip(e,c,o||this.locale,u)}catch(c){throw Op(n,c.message)}}static \u0275fac=function(t){return new(t||n)(S(Xl,16),S(Pp,24),S(Fp,24))};static \u0275pipe=ql({name:"date",type:n,pure:!0})}return n})();var od=(()=>{class n{_locale;constructor(e){this._locale=e}transform(e,t,a){if(!tb(e))return null;a||=this._locale;try{let o=nb(e);return Tp(o,a,t)}catch(o){throw Op(n,o.message)}}static \u0275fac=function(t){return new(t||n)(S(Xl,16))};static \u0275pipe=ql({name:"number",type:n,pure:!0})}return n})();function tb(n){return!(n==null||n===""||n!==n)}function nb(n){if(typeof n=="string"&&!isNaN(Number(n)-parseFloat(n)))return Number(n);if(typeof n!="number")throw new oe(2309,!1);return n}function jo(n,i){i=encodeURIComponent(i);for(let e of n.split(";")){let t=e.indexOf("="),[a,o]=t==-1?[e,""]:[e.slice(0,t),e.slice(t+1)];if(a.trim()===i)return decodeURIComponent(o)}return null}var Yi=class{};var rd="browser";function Np(n){return n===rd}var Vo=class{_doc;constructor(i){this._doc=i}manager},hs=(()=>{class n extends Vo{constructor(e){super(e)}supports(e){return!0}addEventListener(e,t,a,o){return e.addEventListener(t,a,o),()=>this.removeEventListener(e,t,a,o)}removeEventListener(e,t,a,o){return e.removeEventListener(t,a,o)}static \u0275fac=function(t){return new(t||n)(U(X))};static \u0275prov=D({token:n,factory:n.\u0275fac})}return n})(),_s=new E(""),dd=(()=>{class n{_zone;_plugins;_eventNameToPlugin=new Map;constructor(e,t){this._zone=t,e.forEach(c=>{c.manager=this});let a=e.filter(c=>!(c instanceof hs));this._plugins=a.slice().reverse();let o=e.find(c=>c instanceof hs);o&&this._plugins.push(o)}addEventListener(e,t,a,o){return this._findPluginFor(t).addEventListener(e,t,a,o)}getZone(){return this._zone}_findPluginFor(e){let t=this._eventNameToPlugin.get(e);if(t)return t;if(t=this._plugins.find(o=>o.supports(e)),!t)throw new oe(5101,!1);return this._eventNameToPlugin.set(e,t),t}static \u0275fac=function(t){return new(t||n)(U(_s),U(W))};static \u0275prov=D({token:n,factory:n.\u0275fac})}return n})(),sd="ng-app-id";function Lp(n){for(let i of n)i.remove()}function Bp(n,i){let e=i.createElement("style");return e.textContent=n,e}function rb(n,i,e,t){let a=n.head?.querySelectorAll(`style[${sd}="${i}"],link[${sd}="${i}"]`);if(a)for(let o of a)o.removeAttribute(sd),o instanceof HTMLLinkElement?t.set(o.href.slice(o.href.lastIndexOf("/")+1),{usage:0,elements:[o]}):o.textContent&&e.set(o.textContent,{usage:0,elements:[o]})}function ld(n,i){let e=i.createElement("link");return e.setAttribute("rel","stylesheet"),e.setAttribute("href",n),e}var ud=(()=>{class n{doc;appId;nonce;inline=new Map;external=new Map;hosts=new Set;constructor(e,t,a,o={}){this.doc=e,this.appId=t,this.nonce=a,rb(e,t,this.inline,this.external),this.hosts.add(e.head)}addStyles(e,t){for(let a of e)this.addUsage(a,this.inline,Bp);t?.forEach(a=>this.addUsage(a,this.external,ld))}removeStyles(e,t){for(let a of e)this.removeUsage(a,this.inline);t?.forEach(a=>this.removeUsage(a,this.external))}addUsage(e,t,a){let o=t.get(e);o?o.usage++:t.set(e,{usage:1,elements:[...this.hosts].map(c=>this.addElement(c,a(e,this.doc)))})}removeUsage(e,t){let a=t.get(e);a&&(a.usage--,a.usage<=0&&(Lp(a.elements),t.delete(e)))}ngOnDestroy(){for(let[,{elements:e}]of[...this.inline,...this.external])Lp(e);this.hosts.clear()}addHost(e){this.hosts.add(e);for(let[t,{elements:a}]of this.inline)a.push(this.addElement(e,Bp(t,this.doc)));for(let[t,{elements:a}]of this.external)a.push(this.addElement(e,ld(t,this.doc)))}removeHost(e){this.hosts.delete(e)}addElement(e,t){return this.nonce&&t.setAttribute("nonce",this.nonce),e.appendChild(t)}static \u0275fac=function(t){return new(t||n)(U(X),U(Wi),U(Ea,8),U(wa))};static \u0275prov=D({token:n,factory:n.\u0275fac})}return n})(),cd={svg:"http://www.w3.org/2000/svg",xhtml:"http://www.w3.org/1999/xhtml",xlink:"http://www.w3.org/1999/xlink",xml:"http://www.w3.org/XML/1998/namespace",xmlns:"http://www.w3.org/2000/xmlns/",math:"http://www.w3.org/1998/Math/MathML"},md=/%COMP%/g;var Vp="%COMP%",sb=`_nghost-${Vp}`,cb=`_ngcontent-${Vp}`,lb=!0,db=new E("",{factory:()=>lb});function ub(n){return cb.replace(md,n)}function mb(n){return sb.replace(md,n)}function zp(n,i){return i.map(e=>e.replace(md,n))}var Ho=(()=>{class n{eventManager;sharedStylesHost;appId;removeStylesOnCompDestroy;doc;ngZone;nonce;tracingService;rendererByCompId=new Map;defaultRenderer;constructor(e,t,a,o,c,u,p=null,f=null){this.eventManager=e,this.sharedStylesHost=t,this.appId=a,this.removeStylesOnCompDestroy=o,this.doc=c,this.ngZone=u,this.nonce=p,this.tracingService=f,this.defaultRenderer=new zo(e,c,u,this.tracingService)}createRenderer(e,t){if(!e||!t)return this.defaultRenderer;let a=this.getOrCreateRenderer(e,t);return a instanceof gs?a.applyToHost(e):a instanceof Uo&&a.applyStyles(),a}getOrCreateRenderer(e,t){let a=this.rendererByCompId,o=a.get(t.id);if(!o){let c=this.doc,u=this.ngZone,p=this.eventManager,f=this.sharedStylesHost,b=this.removeStylesOnCompDestroy,w=this.tracingService;switch(t.encapsulation){case ts.Emulated:o=new gs(p,f,t,this.appId,b,c,u,w);break;case ts.ShadowDom:return new fs(p,e,t,c,u,this.nonce,w,f);case ts.ExperimentalIsolatedShadowDom:return new fs(p,e,t,c,u,this.nonce,w);default:o=new Uo(p,f,t,b,c,u,w);break}a.set(t.id,o)}return o}ngOnDestroy(){this.rendererByCompId.clear()}componentReplaced(e){this.rendererByCompId.delete(e)}static \u0275fac=function(t){return new(t||n)(U(dd),U(ud),U(Wi),U(db),U(X),U(W),U(Ea),U(is,8))};static \u0275prov=D({token:n,factory:n.\u0275fac})}return n})(),zo=class{eventManager;doc;ngZone;tracingService;data=Object.create(null);throwOnSyntheticProps=!0;constructor(i,e,t,a){this.eventManager=i,this.doc=e,this.ngZone=t,this.tracingService=a}destroy(){}destroyNode=null;createElement(i,e){return e?this.doc.createElementNS(cd[e]||e,i):this.doc.createElement(i)}createComment(i){return this.doc.createComment(i)}createText(i){return this.doc.createTextNode(i)}appendChild(i,e){(jp(i)?i.content:i).appendChild(e)}insertBefore(i,e,t){i&&(jp(i)?i.content:i).insertBefore(e,t)}removeChild(i,e){e.remove()}selectRootElement(i,e){let t=typeof i=="string"?this.doc.querySelector(i):i;if(!t)throw new oe(-5104,!1);return e||(t.textContent=""),t}parentNode(i){return i.parentNode}nextSibling(i){return i.nextSibling}setAttribute(i,e,t,a){if(a){e=a+":"+e;let o=cd[a];o?i.setAttributeNS(o,e,t):i.setAttribute(e,t)}else i.setAttribute(e,t)}removeAttribute(i,e,t){if(t){let a=cd[t];a?i.removeAttributeNS(a,e):i.removeAttribute(`${t}:${e}`)}else i.removeAttribute(e)}addClass(i,e){i.classList.add(e)}removeClass(i,e){i.classList.remove(e)}setStyle(i,e,t,a){a&(Ma.DashCase|Ma.Important)?i.style.setProperty(e,t,a&Ma.Important?"important":""):i.style[e]=t}removeStyle(i,e,t){t&Ma.DashCase?i.style.removeProperty(e):i.style[e]=""}setProperty(i,e,t){i!=null&&(i[e]=t)}setValue(i,e){i.nodeValue=e}listen(i,e,t,a){if(typeof i=="string"&&(i=an().getGlobalEventTarget(this.doc,i),!i))throw new oe(5102,!1);let o=this.decoratePreventDefault(t);return this.tracingService?.wrapEventListener&&(o=this.tracingService.wrapEventListener(i,e,o)),this.eventManager.addEventListener(i,e,o,a)}decoratePreventDefault(i){return e=>{if(e==="__ngUnwrap__")return i;i(e)===!1&&e.preventDefault()}}};function jp(n){return n.tagName==="TEMPLATE"&&n.content!==void 0}var fs=class extends zo{hostEl;sharedStylesHost;shadowRoot;constructor(i,e,t,a,o,c,u,p){super(i,a,o,u),this.hostEl=e,this.sharedStylesHost=p,this.shadowRoot=e.attachShadow({mode:"open"}),this.sharedStylesHost&&this.sharedStylesHost.addHost(this.shadowRoot);let f=t.styles;f=zp(t.id,f);for(let w of f){let L=document.createElement("style");c&&L.setAttribute("nonce",c),L.textContent=w,this.shadowRoot.appendChild(L)}let b=t.getExternalStyles?.();if(b)for(let w of b){let L=ld(w,a);c&&L.setAttribute("nonce",c),this.shadowRoot.appendChild(L)}}nodeOrShadowRoot(i){return i===this.hostEl?this.shadowRoot:i}appendChild(i,e){return super.appendChild(this.nodeOrShadowRoot(i),e)}insertBefore(i,e,t){return super.insertBefore(this.nodeOrShadowRoot(i),e,t)}removeChild(i,e){return super.removeChild(null,e)}parentNode(i){return this.nodeOrShadowRoot(super.parentNode(this.nodeOrShadowRoot(i)))}destroy(){this.sharedStylesHost&&this.sharedStylesHost.removeHost(this.shadowRoot)}},Uo=class extends zo{sharedStylesHost;removeStylesOnCompDestroy;styles;styleUrls;constructor(i,e,t,a,o,c,u,p){super(i,o,c,u),this.sharedStylesHost=e,this.removeStylesOnCompDestroy=a;let f=t.styles;this.styles=p?zp(p,f):f,this.styleUrls=t.getExternalStyles?.(p)}applyStyles(){this.sharedStylesHost.addStyles(this.styles,this.styleUrls)}destroy(){this.removeStylesOnCompDestroy&&Ym.size===0&&this.sharedStylesHost.removeStyles(this.styles,this.styleUrls)}},gs=class extends Uo{contentAttr;hostAttr;constructor(i,e,t,a,o,c,u,p){let f=a+"-"+t.id;super(i,e,t,o,c,u,p,f),this.contentAttr=ub(f),this.hostAttr=mb(f)}applyToHost(i){this.applyStyles(),this.setAttribute(i,this.hostAttr,"")}createElement(i,e){let t=super.createElement(i,e);return super.setAttribute(t,this.contentAttr,""),t}};var bs=class n extends Po{supportsDOMEvents=!0;static makeCurrent(){Kl(new n)}onAndCancel(i,e,t,a){return i.addEventListener(e,t,a),()=>{i.removeEventListener(e,t,a)}}dispatchEvent(i,e){i.dispatchEvent(e)}remove(i){i.remove()}createElement(i,e){return e=e||this.getDefaultDocument(),e.createElement(i)}createHtmlDocument(){return document.implementation.createHTMLDocument("fakeTitle")}getDefaultDocument(){return document}isElementNode(i){return i.nodeType===Node.ELEMENT_NODE}isShadowRoot(i){return i instanceof DocumentFragment}getGlobalEventTarget(i,e){return e==="window"?window:e==="document"?i:e==="body"?i.body:null}getBaseHref(i){let e=hb();return e==null?null:fb(e)}resetBaseElement(){$o=null}getUserAgent(){return window.navigator.userAgent}getCookie(i){return jo(document.cookie,i)}},$o=null;function hb(){return $o=$o||document.head.querySelector("base"),$o?$o.getAttribute("href"):null}function fb(n){return new URL(n,document.baseURI).pathname}var gb=(()=>{class n{build(){return new XMLHttpRequest}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac})}return n})(),Up=["alt","control","meta","shift"],_b={"\b":"Backspace","	":"Tab","\x7F":"Delete","\x1B":"Escape",Del:"Delete",Esc:"Escape",Left:"ArrowLeft",Right:"ArrowRight",Up:"ArrowUp",Down:"ArrowDown",Menu:"ContextMenu",Scroll:"ScrollLock",Win:"OS"},bb={alt:n=>n.altKey,control:n=>n.ctrlKey,meta:n=>n.metaKey,shift:n=>n.shiftKey},Hp=(()=>{class n extends Vo{constructor(e){super(e)}supports(e){return n.parseEventName(e)!=null}addEventListener(e,t,a,o){let c=n.parseEventName(t),u=n.eventCallback(c.fullKey,a,this.manager.getZone());return this.manager.getZone().runOutsideAngular(()=>an().onAndCancel(e,c.domEventName,u,o))}static parseEventName(e){let t=e.toLowerCase().split("."),a=t.shift();if(t.length===0||!(a==="keydown"||a==="keyup"))return null;let o=n._normalizeKey(t.pop()),c="",u=t.indexOf("code");if(u>-1&&(t.splice(u,1),c="code."),Up.forEach(f=>{let b=t.indexOf(f);b>-1&&(t.splice(b,1),c+=f+".")}),c+=o,t.length!=0||o.length===0)return null;let p={};return p.domEventName=a,p.fullKey=c,p}static matchEventFullKeyCode(e,t){let a=_b[e.key]||e.key,o="";return t.indexOf("code.")>-1&&(a=e.code,o="code."),a==null||!a?!1:(a=a.toLowerCase(),a===" "?a="space":a==="."&&(a="dot"),Up.forEach(c=>{if(c!==a){let u=bb[c];u(e)&&(o+=c+".")}}),o+=a,o===t)}static eventCallback(e,t,a){return o=>{n.matchEventFullKeyCode(o,e)&&a.runGuarded(()=>t(o))}}static _normalizeKey(e){return e==="esc"?"escape":e}static \u0275fac=function(t){return new(t||n)(U(X))};static \u0275prov=D({token:n,factory:n.\u0275fac})}return n})();function pd(n,i,e){return $e(this,null,function*(){let t=M({rootComponent:n},vb(i,e));return up(t)})}function vb(n,i){return{platformRef:i?.platformRef,appProviders:[...Db,...n?.providers??[]],platformProviders:wb}}function yb(){bs.makeCurrent()}function xb(){return new Gi}function Cb(){return jm(document),document}var wb=[{provide:wa,useValue:rd},{provide:Vm,useValue:yb,multi:!0},{provide:X,useFactory:Cb}];var Db=[{provide:Om,useValue:"root"},{provide:Gi,useFactory:xb},{provide:_s,useClass:hs,multi:!0},{provide:_s,useClass:Hp,multi:!0},Ho,ud,dd,{provide:vt,useExisting:Ho},{provide:Yi,useClass:gb},[]];var gi=class n{headers;normalizedNames=new Map;lazyInit;lazyUpdate=null;constructor(i){i?typeof i=="string"?this.lazyInit=()=>{this.headers=new Map,i.split(`
`).forEach(e=>{let t=e.indexOf(":");if(t>0){let a=e.slice(0,t),o=e.slice(t+1).trim();this.addHeaderEntry(a,o)}})}:typeof Headers<"u"&&i instanceof Headers?(this.headers=new Map,i.forEach((e,t)=>{this.addHeaderEntry(t,e)})):this.lazyInit=()=>{this.headers=new Map,Object.entries(i).forEach(([e,t])=>{this.setHeaderEntries(e,t)})}:this.headers=new Map}has(i){return this.init(),this.headers.has(i.toLowerCase())}get(i){this.init();let e=this.headers.get(i.toLowerCase());return e&&e.length>0?e[0]:null}keys(){return this.init(),Array.from(this.normalizedNames.values())}getAll(i){return this.init(),this.headers.get(i.toLowerCase())||null}append(i,e){return this.clone({name:i,value:e,op:"a"})}set(i,e){return this.clone({name:i,value:e,op:"s"})}delete(i,e){return this.clone({name:i,value:e,op:"d"})}maybeSetNormalizedName(i,e){this.normalizedNames.has(e)||this.normalizedNames.set(e,i)}init(){this.lazyInit&&(this.lazyInit instanceof n?this.copyFrom(this.lazyInit):this.lazyInit(),this.lazyInit=null,this.lazyUpdate&&(this.lazyUpdate.forEach(i=>this.applyUpdate(i)),this.lazyUpdate=null))}copyFrom(i){i.init(),Array.from(i.headers.keys()).forEach(e=>{this.headers.set(e,i.headers.get(e)),this.normalizedNames.set(e,i.normalizedNames.get(e))})}clone(i){let e=new n;return e.lazyInit=this.lazyInit&&this.lazyInit instanceof n?this.lazyInit:this,e.lazyUpdate=(this.lazyUpdate||[]).concat([i]),e}applyUpdate(i){let e=i.name.toLowerCase();switch(i.op){case"a":case"s":let t=i.value;if(typeof t=="string"&&(t=[t]),t.length===0)return;this.maybeSetNormalizedName(i.name,e);let a=(i.op==="a"?this.headers.get(e):void 0)||[];a.push(...t),this.headers.set(e,a);break;case"d":let o=i.value;if(!o)this.headers.delete(e),this.normalizedNames.delete(e);else{let c=this.headers.get(e);if(!c)return;c=c.filter(u=>o.indexOf(u)===-1),c.length===0?(this.headers.delete(e),this.normalizedNames.delete(e)):this.headers.set(e,c)}break}}addHeaderEntry(i,e){let t=i.toLowerCase();this.maybeSetNormalizedName(i,t),this.headers.has(t)?this.headers.get(t).push(e):this.headers.set(t,[e])}setHeaderEntries(i,e){let t=(Array.isArray(e)?e:[e]).map(o=>o.toString()),a=i.toLowerCase();this.headers.set(a,t),this.maybeSetNormalizedName(i,a)}forEach(i){this.init(),Array.from(this.normalizedNames.keys()).forEach(e=>i(this.normalizedNames.get(e),this.headers.get(e)))}};var ys=class{map=new Map;set(i,e){return this.map.set(i,e),this}get(i){return this.map.has(i)||this.map.set(i,i.defaultValue()),this.map.get(i)}delete(i){return this.map.delete(i),this}has(i){return this.map.has(i)}keys(){return this.map.keys()}},xs=class{encodeKey(i){return $p(i)}encodeValue(i){return $p(i)}decodeKey(i){return decodeURIComponent(i)}decodeValue(i){return decodeURIComponent(i)}};function Eb(n,i){let e=new Map;return n.length>0&&n.replace(/^\?/,"").split("&").forEach(a=>{let o=a.indexOf("="),[c,u]=o==-1?[i.decodeKey(a),""]:[i.decodeKey(a.slice(0,o)),i.decodeValue(a.slice(o+1))],p=e.get(c)||[];p.push(u),e.set(c,p)}),e}var Sb=/%(\d[a-f0-9])/gi,kb={40:"@","3A":":",24:"$","2C":",","3B":";","3D":"=","3F":"?","2F":"/"};function $p(n){return encodeURIComponent(n).replace(Sb,(i,e)=>kb[e]??i)}function vs(n){return`${n}`}var gn=class n{map;encoder;updates=null;cloneFrom=null;constructor(i={}){if(this.encoder=i.encoder||new xs,i.fromString){if(i.fromObject)throw new oe(2805,!1);this.map=Eb(i.fromString,this.encoder)}else i.fromObject?(this.map=new Map,Object.keys(i.fromObject).forEach(e=>{let t=i.fromObject[e],a=Array.isArray(t)?t.map(vs):[vs(t)];this.map.set(e,a)})):this.map=null}has(i){return this.init(),this.map.has(i)}get(i){this.init();let e=this.map.get(i);return e?e[0]:null}getAll(i){return this.init(),this.map.get(i)||null}keys(){return this.init(),Array.from(this.map.keys())}append(i,e){return this.clone({param:i,value:e,op:"a"})}appendAll(i){let e=[];return Object.keys(i).forEach(t=>{let a=i[t];Array.isArray(a)?a.forEach(o=>{e.push({param:t,value:o,op:"a"})}):e.push({param:t,value:a,op:"a"})}),this.clone(e)}set(i,e){return this.clone({param:i,value:e,op:"s"})}delete(i,e){return this.clone({param:i,value:e,op:"d"})}toString(){return this.init(),this.keys().map(i=>{let e=this.encoder.encodeKey(i);return this.map.get(i).map(t=>e+"="+this.encoder.encodeValue(t)).join("&")}).filter(i=>i!=="").join("&")}clone(i){let e=new n({encoder:this.encoder});return e.cloneFrom=this.cloneFrom||this,e.updates=(this.updates||[]).concat(i),e}init(){this.map===null&&(this.map=new Map),this.cloneFrom!==null&&(this.cloneFrom.init(),this.cloneFrom.keys().forEach(i=>this.map.set(i,this.cloneFrom.map.get(i))),this.updates.forEach(i=>{switch(i.op){case"a":case"s":let e=(i.op==="a"?this.map.get(i.param):void 0)||[];e.push(vs(i.value)),this.map.set(i.param,e);break;case"d":if(i.value!==void 0){let t=this.map.get(i.param)||[],a=t.indexOf(vs(i.value));a!==-1&&t.splice(a,1),t.length>0?this.map.set(i.param,t):this.map.delete(i.param)}else{this.map.delete(i.param);break}}}),this.cloneFrom=this.updates=null)}};function Mb(n){switch(n){case"DELETE":case"GET":case"HEAD":case"OPTIONS":case"JSONP":return!1;default:return!0}}function Gp(n){return typeof ArrayBuffer<"u"&&n instanceof ArrayBuffer}function qp(n){return typeof Blob<"u"&&n instanceof Blob}function Wp(n){return typeof FormData<"u"&&n instanceof FormData}function Ib(n){return typeof URLSearchParams<"u"&&n instanceof URLSearchParams}var Qp="Content-Type",Yp="Accept",Xp="text/plain",Kp="application/json",Ab=`${Kp}, ${Xp}, */*`,Ta=class n{url;body=null;headers;context;reportProgress=!1;withCredentials=!1;credentials;keepalive=!1;cache;priority;mode;redirect;referrer;integrity;referrerPolicy;responseType="json";method;params;urlWithParams;transferCache;timeout;constructor(i,e,t,a){this.url=e,this.method=i.toUpperCase();let o;if(Mb(this.method)||a?(this.body=t!==void 0?t:null,o=a):o=t,o){if(this.reportProgress=!!o.reportProgress,this.withCredentials=!!o.withCredentials,this.keepalive=!!o.keepalive,o.responseType&&(this.responseType=o.responseType),o.headers&&(this.headers=o.headers),o.context&&(this.context=o.context),o.params&&(this.params=o.params),o.priority&&(this.priority=o.priority),o.cache&&(this.cache=o.cache),o.credentials&&(this.credentials=o.credentials),typeof o.timeout=="number"){if(o.timeout<1||!Number.isInteger(o.timeout))throw new oe(2822,"");this.timeout=o.timeout}o.mode&&(this.mode=o.mode),o.redirect&&(this.redirect=o.redirect),o.integrity&&(this.integrity=o.integrity),o.referrer!==void 0&&(this.referrer=o.referrer),o.referrerPolicy&&(this.referrerPolicy=o.referrerPolicy),this.transferCache=o.transferCache}if(this.headers??=new gi,this.context??=new ys,!this.params)this.params=new gn,this.urlWithParams=e;else{let c=this.params.toString();if(c.length===0)this.urlWithParams=e;else{let u=e.indexOf("?"),p=u===-1?"?":u<e.length-1?"&":"";this.urlWithParams=e+p+c}}}serializeBody(){return this.body===null?null:typeof this.body=="string"||Gp(this.body)||qp(this.body)||Wp(this.body)||Ib(this.body)?this.body:this.body instanceof gn?this.body.toString():typeof this.body=="object"||typeof this.body=="boolean"||Array.isArray(this.body)?JSON.stringify(this.body):this.body.toString()}detectContentTypeHeader(){return this.body===null||Wp(this.body)?null:qp(this.body)?this.body.type||null:Gp(this.body)?null:typeof this.body=="string"?Xp:this.body instanceof gn?"application/x-www-form-urlencoded;charset=UTF-8":typeof this.body=="object"||typeof this.body=="number"||typeof this.body=="boolean"?Kp:null}clone(i={}){let e=i.method||this.method,t=i.url||this.url,a=i.responseType||this.responseType,o=i.keepalive??this.keepalive,c=i.priority||this.priority,u=i.cache||this.cache,p=i.mode||this.mode,f=i.redirect||this.redirect,b=i.credentials||this.credentials,w=i.referrer??this.referrer,L=i.integrity||this.integrity,$=i.referrerPolicy||this.referrerPolicy,ae=i.transferCache??this.transferCache,me=i.timeout??this.timeout,J=i.body!==void 0?i.body:this.body,se=i.withCredentials??this.withCredentials,Ie=i.reportProgress??this.reportProgress,gt=i.headers||this.headers,Ye=i.params||this.params,ci=i.context??this.context;return i.setHeaders!==void 0&&(gt=Object.keys(i.setHeaders).reduce((Xn,Ui)=>Xn.set(Ui,i.setHeaders[Ui]),gt)),i.setParams&&(Ye=Object.keys(i.setParams).reduce((Xn,Ui)=>Xn.set(Ui,i.setParams[Ui]),Ye)),new n(e,t,J,{params:Ye,headers:gt,context:ci,reportProgress:Ie,responseType:a,withCredentials:se,transferCache:ae,keepalive:o,cache:u,priority:c,timeout:me,mode:p,redirect:f,credentials:b,referrer:w,integrity:L,referrerPolicy:$})}},Xi=(function(n){return n[n.Sent=0]="Sent",n[n.UploadProgress=1]="UploadProgress",n[n.ResponseHeader=2]="ResponseHeader",n[n.DownloadProgress=3]="DownloadProgress",n[n.Response=4]="Response",n[n.User=5]="User",n})(Xi||{}),Oa=class{headers;status;statusText;url;ok;type;redirected;responseType;constructor(i,e=200,t="OK"){this.headers=i.headers||new gi,this.status=i.status!==void 0?i.status:e,this.statusText=i.statusText||t,this.url=i.url||null,this.redirected=i.redirected,this.responseType=i.responseType,this.ok=this.status>=200&&this.status<300}},Cs=class n extends Oa{constructor(i={}){super(i)}type=Xi.ResponseHeader;clone(i={}){return new n({headers:i.headers||this.headers,status:i.status!==void 0?i.status:this.status,statusText:i.statusText||this.statusText,url:i.url||this.url||void 0})}},Go=class n extends Oa{body;constructor(i={}){super(i),this.body=i.body!==void 0?i.body:null}type=Xi.Response;clone(i={}){return new n({body:i.body!==void 0?i.body:this.body,headers:i.headers||this.headers,status:i.status!==void 0?i.status:this.status,statusText:i.statusText||this.statusText,url:i.url||this.url||void 0,redirected:i.redirected??this.redirected,responseType:i.responseType??this.responseType})}},fi=class extends Oa{name="HttpErrorResponse";message;error;ok=!1;constructor(i){super(i,0,"Unknown Error"),this.status>=200&&this.status<300?this.message=`Http failure during parsing for ${i.url||"(unknown url)"}`:this.message=`Http failure response for ${i.url||"(unknown url)"}: ${i.status} ${i.statusText}`,this.error=i.error||null}},Rb=200,Tb=204;var Ob=new E("");var Pb=/^\)\]\}',?\n/;var fd=(()=>{class n{xhrFactory;tracingService=m(is,{optional:!0});constructor(e){this.xhrFactory=e}maybePropagateTrace(e){return this.tracingService?.propagate?this.tracingService.propagate(e):e}handle(e){if(e.method==="JSONP")throw new oe(-2800,!1);let t=this.xhrFactory;return K(null).pipe(at(()=>new Ht(o=>{let c=t.build();if(c.open(e.method,e.urlWithParams),e.withCredentials&&(c.withCredentials=!0),e.headers.forEach((J,se)=>c.setRequestHeader(J,se.join(","))),e.headers.has(Yp)||c.setRequestHeader(Yp,Ab),!e.headers.has(Qp)){let J=e.detectContentTypeHeader();J!==null&&c.setRequestHeader(Qp,J)}if(e.timeout&&(c.timeout=e.timeout),e.responseType){let J=e.responseType.toLowerCase();c.responseType=J!=="json"?J:"text"}let u=e.serializeBody(),p=null,f=()=>{if(p!==null)return p;let J=c.statusText||"OK",se=new gi(c.getAllResponseHeaders()),Ie=c.responseURL||e.url;return p=new Cs({headers:se,status:c.status,statusText:J,url:Ie}),p},b=this.maybePropagateTrace(()=>{let{headers:J,status:se,statusText:Ie,url:gt}=f(),Ye=null;se!==Tb&&(Ye=typeof c.response>"u"?c.responseText:c.response),se===0&&(se=Ye?Rb:0);let ci=se>=200&&se<300;if(e.responseType==="json"&&typeof Ye=="string"){let Xn=Ye;Ye=Ye.replace(Pb,"");try{Ye=Ye!==""?JSON.parse(Ye):null}catch(Ui){Ye=Xn,ci&&(ci=!1,Ye={error:Ui,text:Ye})}}ci?(o.next(new Go({body:Ye,headers:J,status:se,statusText:Ie,url:gt||void 0})),o.complete()):o.error(new fi({error:Ye,headers:J,status:se,statusText:Ie,url:gt||void 0}))}),w=this.maybePropagateTrace(J=>{let{url:se}=f(),Ie=new fi({error:J,status:c.status||0,statusText:c.statusText||"Unknown Error",url:se||void 0});o.error(Ie)}),L=w;e.timeout&&(L=this.maybePropagateTrace(J=>{let{url:se}=f(),Ie=new fi({error:new DOMException("Request timed out","TimeoutError"),status:c.status||0,statusText:c.statusText||"Request timeout",url:se||void 0});o.error(Ie)}));let $=!1,ae=this.maybePropagateTrace(J=>{$||(o.next(f()),$=!0);let se={type:Xi.DownloadProgress,loaded:J.loaded};J.lengthComputable&&(se.total=J.total),e.responseType==="text"&&c.responseText&&(se.partialText=c.responseText),o.next(se)}),me=this.maybePropagateTrace(J=>{let se={type:Xi.UploadProgress,loaded:J.loaded};J.lengthComputable&&(se.total=J.total),o.next(se)});return c.addEventListener("load",b),c.addEventListener("error",w),c.addEventListener("timeout",L),c.addEventListener("abort",w),e.reportProgress&&(c.addEventListener("progress",ae),u!==null&&c.upload&&c.upload.addEventListener("progress",me)),c.send(u),o.next({type:Xi.Sent}),()=>{c.removeEventListener("error",w),c.removeEventListener("abort",w),c.removeEventListener("load",b),c.removeEventListener("timeout",L),e.reportProgress&&(c.removeEventListener("progress",ae),u!==null&&c.upload&&c.upload.removeEventListener("progress",me)),c.readyState!==c.DONE&&c.abort()}})))}static \u0275fac=function(t){return new(t||n)(U(Yi))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();function Fb(n,i){return i(n)}function Nb(n,i,e){return(t,a)=>$t(e,()=>i(t,o=>n(o,a)))}var gd=new E("",{factory:()=>[]}),Zp=new E(""),Jp=new E("",{factory:()=>!0});var _d=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:function(t){let a=null;return t?a=new(t||n):a=U(fd),a},providedIn:"root"})}return n})();var ws=(()=>{class n{backend;injector;chain=null;pendingTasks=m(Bm);contributeToStability=m(Jp);constructor(e,t){this.backend=e,this.injector=t}handle(e){if(this.chain===null){let t=Array.from(new Set([...this.injector.get(gd),...this.injector.get(Zp,[])]));this.chain=t.reduceRight((a,o)=>Nb(a,o,this.injector),Fb)}if(this.contributeToStability){let t=this.pendingTasks.add();return this.chain(e,a=>this.backend.handle(a)).pipe(xa(t))}else return this.chain(e,t=>this.backend.handle(t))}static \u0275fac=function(t){return new(t||n)(U(_d),U(bt))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),bd=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:function(t){let a=null;return t?a=new(t||n):a=U(ws),a},providedIn:"root"})}return n})();function hd(n,i){return{body:i,headers:n.headers,context:n.context,observe:n.observe,params:n.params,reportProgress:n.reportProgress,responseType:n.responseType,withCredentials:n.withCredentials,credentials:n.credentials,transferCache:n.transferCache,timeout:n.timeout,keepalive:n.keepalive,priority:n.priority,cache:n.cache,mode:n.mode,redirect:n.redirect,integrity:n.integrity,referrer:n.referrer,referrerPolicy:n.referrerPolicy}}var _i=(()=>{class n{handler;constructor(e){this.handler=e}request(e,t,a={}){let o;if(e instanceof Ta)o=e;else{let p;a.headers instanceof gi?p=a.headers:p=new gi(a.headers);let f;a.params&&(a.params instanceof gn?f=a.params:f=new gn({fromObject:a.params})),o=new Ta(e,t,a.body!==void 0?a.body:null,{headers:p,context:a.context,params:f,reportProgress:a.reportProgress,responseType:a.responseType||"json",withCredentials:a.withCredentials,transferCache:a.transferCache,keepalive:a.keepalive,priority:a.priority,cache:a.cache,mode:a.mode,redirect:a.redirect,credentials:a.credentials,referrer:a.referrer,referrerPolicy:a.referrerPolicy,integrity:a.integrity,timeout:a.timeout})}let c=K(o).pipe(ya(p=>this.handler.handle(p)));if(e instanceof Ta||a.observe==="events")return c;let u=c.pipe(Ce(p=>p instanceof Go));switch(a.observe||"body"){case"body":switch(o.responseType){case"arraybuffer":return u.pipe(Q(p=>{if(p.body!==null&&!(p.body instanceof ArrayBuffer))throw new oe(2806,!1);return p.body}));case"blob":return u.pipe(Q(p=>{if(p.body!==null&&!(p.body instanceof Blob))throw new oe(2807,!1);return p.body}));case"text":return u.pipe(Q(p=>{if(p.body!==null&&typeof p.body!="string")throw new oe(2808,!1);return p.body}));default:return u.pipe(Q(p=>p.body))}case"response":return u;default:throw new oe(2809,!1)}}delete(e,t={}){return this.request("DELETE",e,t)}get(e,t={}){return this.request("GET",e,t)}head(e,t={}){return this.request("HEAD",e,t)}jsonp(e,t){return this.request("JSONP",e,{params:new gn().append(t,"JSONP_CALLBACK"),observe:"body",responseType:"json"})}options(e,t={}){return this.request("OPTIONS",e,t)}patch(e,t,a={}){return this.request("PATCH",e,hd(a,t))}post(e,t,a={}){return this.request("POST",e,hd(a,t))}put(e,t,a={}){return this.request("PUT",e,hd(a,t))}static \u0275fac=function(t){return new(t||n)(U(bd))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var Lb=new E("",{factory:()=>!0}),Bb="XSRF-TOKEN",jb=new E("",{factory:()=>Bb}),Vb="X-XSRF-TOKEN",zb=new E("",{factory:()=>Vb}),Ub=(()=>{class n{cookieName=m(jb);doc=m(X);lastCookieString="";lastToken=null;parseCount=0;getToken(){let e=this.doc.cookie||"";return e!==this.lastCookieString&&(this.parseCount++,this.lastToken=jo(e,this.cookieName),this.lastCookieString=e),this.lastToken}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),eh=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:function(t){let a=null;return t?a=new(t||n):a=U(Ub),a},providedIn:"root"})}return n})();function Hb(n,i){if(!m(Lb)||n.method==="GET"||n.method==="HEAD")return i(n);try{let a=m(Aa).href,{origin:o}=new URL(a),{origin:c}=new URL(n.url,o);if(o!==c)return i(n)}catch(a){return i(n)}let e=m(eh).getToken(),t=m(zb);return e!=null&&!n.headers.has(t)&&(n=n.clone({headers:n.headers.set(t,e)})),i(n)}var vd=(function(n){return n[n.Interceptors=0]="Interceptors",n[n.LegacyInterceptors=1]="LegacyInterceptors",n[n.CustomXsrfConfiguration=2]="CustomXsrfConfiguration",n[n.NoXsrfProtection=3]="NoXsrfProtection",n[n.JsonpSupport=4]="JsonpSupport",n[n.RequestsMadeViaParent=5]="RequestsMadeViaParent",n[n.Fetch=6]="Fetch",n})(vd||{});function $b(n,i){return{\u0275kind:n,\u0275providers:i}}function yd(...n){let i=[_i,ws,{provide:bd,useExisting:ws},{provide:_d,useFactory:()=>m(Ob,{optional:!0})??m(fd)},{provide:gd,useValue:Hb,multi:!0}];for(let e of n)i.push(...e.\u0275providers);return Hi(i)}function xd(n){return $b(vd.Interceptors,n.map(i=>({provide:gd,useValue:i,multi:!0})))}var th=(()=>{class n{_doc;constructor(e){this._doc=e}getTitle(){return this._doc.title}setTitle(e){this._doc.title=e||""}static \u0275fac=function(t){return new(t||n)(U(X))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var qo=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:function(t){let a=null;return t?a=new(t||n):a=U(Qb),a},providedIn:"root"})}return n})(),Qb=(()=>{class n extends qo{_doc;constructor(e){super(),this._doc=e}sanitize(e,t){if(t==null)return null;switch(e){case Bt.NONE:return t;case Bt.HTML:return ka(t,"HTML")?Sa(t):Wm(this._doc,String(t)).toString();case Bt.STYLE:return ka(t,"Style")?Sa(t):t;case Bt.SCRIPT:if(ka(t,"Script"))return Sa(t);throw new oe(5200,!1);case Bt.URL:return ka(t,"URL")?Sa(t):qm(String(t));case Bt.RESOURCE_URL:if(ka(t,"ResourceURL"))return Sa(t);throw new oe(5201,!1);default:throw new oe(5202,!1)}}bypassSecurityTrustHtml(e){return zm(e)}bypassSecurityTrustStyle(e){return Um(e)}bypassSecurityTrustScript(e){return Hm(e)}bypassSecurityTrustUrl(e){return $m(e)}bypassSecurityTrustResourceUrl(e){return Gm(e)}static \u0275fac=function(t){return new(t||n)(U(X))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var ue="primary",sr=Symbol("RouteTitle"),kd=class{params;constructor(i){this.params=i||{}}has(i){return Object.prototype.hasOwnProperty.call(this.params,i)}get(i){if(this.has(i)){let e=this.params[i];return Array.isArray(e)?e[0]:e}return null}getAll(i){if(this.has(i)){let e=this.params[i];return Array.isArray(e)?e:[e]}return[]}get keys(){return Object.keys(this.params)}};function Zi(n){return new kd(n)}function wd(n,i,e){for(let t=0;t<n.length;t++){let a=n[t],o=i[t];if(a[0]===":")e[a.substring(1)]=o;else if(a!==o.path)return!1}return!0}function lh(n,i,e){let t=e.path.split("/"),a=t.indexOf("**");if(a===-1){if(t.length>n.length||e.pathMatch==="full"&&(i.hasChildren()||t.length<n.length))return null;let p={},f=n.slice(0,t.length);return wd(t,f,p)?{consumed:f,posParams:p}:null}if(a!==t.lastIndexOf("**"))return null;let o=t.slice(0,a),c=t.slice(a+1);if(o.length+c.length>n.length||e.pathMatch==="full"&&i.hasChildren()&&e.path!=="**")return null;let u={};return!wd(o,n.slice(0,o.length),u)||!wd(c,n.slice(n.length-c.length),u)?null:{consumed:n,posParams:u}}function Is(n){return new Promise((i,e)=>{n.pipe(li()).subscribe({next:t=>i(t),error:t=>e(t)})})}function Yb(n,i){if(n.length!==i.length)return!1;for(let e=0;e<n.length;++e)if(!Bn(n[e],i[e]))return!1;return!0}function Bn(n,i){let e=n?Md(n):void 0,t=i?Md(i):void 0;if(!e||!t||e.length!=t.length)return!1;let a;for(let o=0;o<e.length;o++)if(a=e[o],!dh(n[a],i[a]))return!1;return!0}function Md(n){return[...Object.keys(n),...Object.getOwnPropertySymbols(n)]}function dh(n,i){if(Array.isArray(n)&&Array.isArray(i)){if(n.length!==i.length)return!1;let e=[...n].sort(),t=[...i].sort();return e.every((a,o)=>t[o]===a)}else return n===i}function Xb(n){return n.length>0?n[n.length-1]:null}function ta(n){return ba(n)?n:Ao(n)?Lt(Promise.resolve(n)):K(n)}function uh(n){return ba(n)?Is(n):Promise.resolve(n)}var Kb={exact:ph,subset:hh},mh={exact:Zb,subset:Jb,ignored:()=>!0},Ud={paths:"exact",fragment:"ignored",matrixParams:"ignored",queryParams:"exact"},Zo={paths:"subset",fragment:"ignored",matrixParams:"ignored",queryParams:"subset"};function Hd(n,i,e){let t=n instanceof zt?n:i.parseUrl(n);return Vt(()=>Id(i.lastSuccessfulNavigation()?.finalUrl??new zt,t,M(M({},Zo),e)))}function Id(n,i,e){return Kb[e.paths](n.root,i.root,e.matrixParams)&&mh[e.queryParams](n.queryParams,i.queryParams)&&!(e.fragment==="exact"&&n.fragment!==i.fragment)}function Zb(n,i){return Bn(n,i)}function ph(n,i,e){if(!Ki(n.segments,i.segments)||!Ss(n.segments,i.segments,e)||n.numberOfChildren!==i.numberOfChildren)return!1;for(let t in i.children)if(!n.children[t]||!ph(n.children[t],i.children[t],e))return!1;return!0}function Jb(n,i){return Object.keys(i).length<=Object.keys(n).length&&Object.keys(i).every(e=>dh(n[e],i[e]))}function hh(n,i,e){return fh(n,i,i.segments,e)}function fh(n,i,e,t){if(n.segments.length>e.length){let a=n.segments.slice(0,e.length);return!(!Ki(a,e)||i.hasChildren()||!Ss(a,e,t))}else if(n.segments.length===e.length){if(!Ki(n.segments,e)||!Ss(n.segments,e,t))return!1;for(let a in i.children)if(!n.children[a]||!hh(n.children[a],i.children[a],t))return!1;return!0}else{let a=e.slice(0,n.segments.length),o=e.slice(n.segments.length);return!Ki(n.segments,a)||!Ss(n.segments,a,t)||!n.children[ue]?!1:fh(n.children[ue],i,o,t)}}function Ss(n,i,e){return i.every((t,a)=>mh[e](n[a].parameters,t.parameters))}var zt=class{root;queryParams;fragment;_queryParamMap;constructor(i=new Me([],{}),e={},t=null){this.root=i,this.queryParams=e,this.fragment=t}get queryParamMap(){return this._queryParamMap??=Zi(this.queryParams),this._queryParamMap}toString(){return nv.serialize(this)}},Me=class{segments;children;parent=null;constructor(i,e){this.segments=i,this.children=e,Object.values(e).forEach(t=>t.parent=this)}hasChildren(){return this.numberOfChildren>0}get numberOfChildren(){return Object.keys(this.children).length}toString(){return ks(this)}},bi=class{path;parameters;_parameterMap;constructor(i,e){this.path=i,this.parameters=e}get parameterMap(){return this._parameterMap??=Zi(this.parameters),this._parameterMap}toString(){return _h(this)}};function ev(n,i){return Ki(n,i)&&n.every((e,t)=>Bn(e.parameters,i[t].parameters))}function Ki(n,i){return n.length!==i.length?!1:n.every((e,t)=>e.path===i[t].path)}function tv(n,i){let e=[];return Object.entries(n.children).forEach(([t,a])=>{t===ue&&(e=e.concat(i(a,t)))}),Object.entries(n.children).forEach(([t,a])=>{t!==ue&&(e=e.concat(i(a,t)))}),e}var Ua=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:()=>new vi,providedIn:"root"})}return n})(),vi=class{parse(i){let e=new Rd(i);return new zt(e.parseRootSegment(),e.parseQueryParams(),e.parseFragment())}serialize(i){let e=`/${Wo(i.root,!0)}`,t=ov(i.queryParams),a=typeof i.fragment=="string"?`#${iv(i.fragment)}`:"";return`${e}${t}${a}`}},nv=new vi;function ks(n){return n.segments.map(i=>_h(i)).join("/")}function Wo(n,i){if(!n.hasChildren())return ks(n);if(i){let e=n.children[ue]?Wo(n.children[ue],!1):"",t=[];return Object.entries(n.children).forEach(([a,o])=>{a!==ue&&t.push(`${a}:${Wo(o,!1)}`)}),t.length>0?`${e}(${t.join("//")})`:e}else{let e=tv(n,(t,a)=>a===ue?[Wo(n.children[ue],!1)]:[`${a}:${Wo(t,!1)}`]);return Object.keys(n.children).length===1&&n.children[ue]!=null?`${ks(n)}/${e[0]}`:`${ks(n)}/(${e.join("//")})`}}function gh(n){return encodeURIComponent(n).replace(/%40/g,"@").replace(/%3A/gi,":").replace(/%24/g,"$").replace(/%2C/gi,",")}function Ds(n){return gh(n).replace(/%3B/gi,";")}function iv(n){return encodeURI(n)}function Ad(n){return gh(n).replace(/\(/g,"%28").replace(/\)/g,"%29").replace(/%26/gi,"&")}function Ms(n){return decodeURIComponent(n)}function ih(n){return Ms(n.replace(/\+/g,"%20"))}function _h(n){return`${Ad(n.path)}${av(n.parameters)}`}function av(n){return Object.entries(n).map(([i,e])=>`;${Ad(i)}=${Ad(e)}`).join("")}function ov(n){let i=Object.entries(n).map(([e,t])=>Array.isArray(t)?t.map(a=>`${Ds(e)}=${Ds(a)}`).join("&"):`${Ds(e)}=${Ds(t)}`).filter(e=>e);return i.length?`?${i.join("&")}`:""}var rv=/^[^\/()?;#]+/;function Dd(n){let i=n.match(rv);return i?i[0]:""}var sv=/^[^\/()?;=#]+/;function cv(n){let i=n.match(sv);return i?i[0]:""}var lv=/^[^=?&#]+/;function dv(n){let i=n.match(lv);return i?i[0]:""}var uv=/^[^&#]+/;function mv(n){let i=n.match(uv);return i?i[0]:""}var Rd=class{url;remaining;constructor(i){this.url=i,this.remaining=i}parseRootSegment(){for(;this.consumeOptional("/"););return this.remaining===""||this.peekStartsWith("?")||this.peekStartsWith("#")?new Me([],{}):new Me([],this.parseChildren())}parseQueryParams(){let i={};if(this.consumeOptional("?"))do this.parseQueryParam(i);while(this.consumeOptional("&"));return i}parseFragment(){return this.consumeOptional("#")?decodeURIComponent(this.remaining):null}parseChildren(i=0){if(i>50)throw new oe(4010,!1);if(this.remaining==="")return{};this.consumeOptional("/");let e=[];for(this.peekStartsWith("(")||e.push(this.parseSegment());this.peekStartsWith("/")&&!this.peekStartsWith("//")&&!this.peekStartsWith("/(");)this.capture("/"),e.push(this.parseSegment());let t={};this.peekStartsWith("/(")&&(this.capture("/"),t=this.parseParens(!0,i));let a={};return this.peekStartsWith("(")&&(a=this.parseParens(!1,i)),(e.length>0||Object.keys(t).length>0)&&(a[ue]=new Me(e,t)),a}parseSegment(){let i=Dd(this.remaining);if(i===""&&this.peekStartsWith(";"))throw new oe(4009,!1);return this.capture(i),new bi(Ms(i),this.parseMatrixParams())}parseMatrixParams(){let i={};for(;this.consumeOptional(";");)this.parseParam(i);return i}parseParam(i){let e=cv(this.remaining);if(!e)return;this.capture(e);let t="";if(this.consumeOptional("=")){let a=Dd(this.remaining);a&&(t=a,this.capture(t))}i[Ms(e)]=Ms(t)}parseQueryParam(i){let e=dv(this.remaining);if(!e)return;this.capture(e);let t="";if(this.consumeOptional("=")){let c=mv(this.remaining);c&&(t=c,this.capture(t))}let a=ih(e),o=ih(t);if(i.hasOwnProperty(a)){let c=i[a];Array.isArray(c)||(c=[c],i[a]=c),c.push(o)}else i[a]=o}parseParens(i,e){let t={};for(this.capture("(");!this.consumeOptional(")")&&this.remaining.length>0;){let a=Dd(this.remaining),o=this.remaining[a.length];if(o!=="/"&&o!==")"&&o!==";")throw new oe(4010,!1);let c;a.indexOf(":")>-1?(c=a.slice(0,a.indexOf(":")),this.capture(c),this.capture(":")):i&&(c=ue);let u=this.parseChildren(e+1);t[c??ue]=Object.keys(u).length===1&&u[ue]?u[ue]:new Me([],u),this.consumeOptional("//")}return t}peekStartsWith(i){return this.remaining.startsWith(i)}consumeOptional(i){return this.peekStartsWith(i)?(this.remaining=this.remaining.substring(i.length),!0):!1}capture(i){if(!this.consumeOptional(i))throw new oe(4011,!1)}};function bh(n){return n.segments.length>0?new Me([],{[ue]:n}):n}function vh(n){let i={};for(let[t,a]of Object.entries(n.children)){let o=vh(a);if(t===ue&&o.segments.length===0&&o.hasChildren())for(let[c,u]of Object.entries(o.children))i[c]=u;else(o.segments.length>0||o.hasChildren())&&(i[t]=o)}let e=new Me(n.segments,i);return pv(e)}function pv(n){if(n.numberOfChildren===1&&n.children[ue]){let i=n.children[ue];return new Me(n.segments.concat(i.segments),i.children)}return n}function yi(n){return n instanceof zt}function yh(n,i,e=null,t=null,a=new vi){let o=xh(n);return Ch(o,i,e,t,a)}function xh(n){let i;function e(o){let c={};for(let p of o.children){let f=e(p);c[p.outlet]=f}let u=new Me(o.url,c);return o===n&&(i=u),u}let t=e(n.root),a=bh(t);return i??a}function Ch(n,i,e,t,a){let o=n;for(;o.parent;)o=o.parent;if(i.length===0)return Ed(o,o,o,e,t,a);let c=hv(i);if(c.toRoot())return Ed(o,o,new Me([],{}),e,t,a);let u=fv(c,o,n),p=u.processChildren?Yo(u.segmentGroup,u.index,c.commands):Dh(u.segmentGroup,u.index,c.commands);return Ed(o,u.segmentGroup,p,e,t,a)}function As(n){return typeof n=="object"&&n!=null&&!n.outlets&&!n.segmentPath}function Jo(n){return typeof n=="object"&&n!=null&&n.outlets}function ah(n,i,e){n||="\u0275";let t=new zt;return t.queryParams={[n]:i},e.parse(e.serialize(t)).queryParams[n]}function Ed(n,i,e,t,a,o){let c={};for(let[f,b]of Object.entries(t??{}))c[f]=Array.isArray(b)?b.map(w=>ah(f,w,o)):ah(f,b,o);let u;n===i?u=e:u=wh(n,i,e);let p=bh(vh(u));return new zt(p,c,a)}function wh(n,i,e){let t={};return Object.entries(n.children).forEach(([a,o])=>{o===i?t[a]=e:t[a]=wh(o,i,e)}),new Me(n.segments,t)}var Rs=class{isAbsolute;numberOfDoubleDots;commands;constructor(i,e,t){if(this.isAbsolute=i,this.numberOfDoubleDots=e,this.commands=t,i&&t.length>0&&As(t[0]))throw new oe(4003,!1);let a=t.find(Jo);if(a&&a!==Xb(t))throw new oe(4004,!1)}toRoot(){return this.isAbsolute&&this.commands.length===1&&this.commands[0]=="/"}};function hv(n){if(typeof n[0]=="string"&&n.length===1&&n[0]==="/")return new Rs(!0,0,n);let i=0,e=!1,t=n.reduce((a,o,c)=>{if(typeof o=="object"&&o!=null){if(o.outlets){let u={};return Object.entries(o.outlets).forEach(([p,f])=>{u[p]=typeof f=="string"?f.split("/"):f}),[...a,{outlets:u}]}if(o.segmentPath)return[...a,o.segmentPath]}return typeof o!="string"?[...a,o]:c===0?(o.split("/").forEach((u,p)=>{p==0&&u==="."||(p==0&&u===""?e=!0:u===".."?i++:u!=""&&a.push(u))}),a):[...a,o]},[]);return new Rs(e,i,t)}var Fa=class{segmentGroup;processChildren;index;constructor(i,e,t){this.segmentGroup=i,this.processChildren=e,this.index=t}};function fv(n,i,e){if(n.isAbsolute)return new Fa(i,!0,0);if(!e)return new Fa(i,!1,NaN);if(e.parent===null)return new Fa(e,!0,0);let t=As(n.commands[0])?0:1,a=e.segments.length-1+t;return gv(e,a,n.numberOfDoubleDots)}function gv(n,i,e){let t=n,a=i,o=e;for(;o>a;){if(o-=a,t=t.parent,!t)throw new oe(4005,!1);a=t.segments.length}return new Fa(t,!1,a-o)}function _v(n){return Jo(n[0])?n[0].outlets:{[ue]:n}}function Dh(n,i,e){if(n??=new Me([],{}),n.segments.length===0&&n.hasChildren())return Yo(n,i,e);let t=bv(n,i,e),a=e.slice(t.commandIndex);if(t.match&&t.pathIndex<n.segments.length){let o=new Me(n.segments.slice(0,t.pathIndex),{});return o.children[ue]=new Me(n.segments.slice(t.pathIndex),n.children),Yo(o,0,a)}else return t.match&&a.length===0?new Me(n.segments,{}):t.match&&!n.hasChildren()?Td(n,i,e):t.match?Yo(n,0,a):Td(n,i,e)}function Yo(n,i,e){if(e.length===0)return new Me(n.segments,{});{let t=_v(e),a={};if(Object.keys(t).some(o=>o!==ue)&&n.children[ue]&&n.numberOfChildren===1&&n.children[ue].segments.length===0){let o=Yo(n.children[ue],i,e);return new Me(n.segments,o.children)}return Object.entries(t).forEach(([o,c])=>{typeof c=="string"&&(c=[c]),c!==null&&(a[o]=Dh(n.children[o],i,c))}),Object.entries(n.children).forEach(([o,c])=>{t[o]===void 0&&(a[o]=c)}),new Me(n.segments,a)}}function bv(n,i,e){let t=0,a=i,o={match:!1,pathIndex:0,commandIndex:0};for(;a<n.segments.length;){if(t>=e.length)return o;let c=n.segments[a],u=e[t];if(Jo(u))break;let p=`${u}`,f=t<e.length-1?e[t+1]:null;if(a>0&&p===void 0)break;if(p&&f&&typeof f=="object"&&f.outlets===void 0){if(!rh(p,f,c))return o;t+=2}else{if(!rh(p,{},c))return o;t++}a++}return{match:!0,pathIndex:a,commandIndex:t}}function Td(n,i,e){let t=n.segments.slice(0,i),a=0;for(;a<e.length;){let o=e[a];if(Jo(o)){let p=vv(o.outlets);return new Me(t,p)}if(a===0&&As(e[0])){let p=n.segments[i];t.push(new bi(p.path,oh(e[0]))),a++;continue}let c=Jo(o)?o.outlets[ue]:`${o}`,u=a<e.length-1?e[a+1]:null;c&&u&&As(u)?(t.push(new bi(c,oh(u))),a+=2):(t.push(new bi(c,{})),a++)}return new Me(t,{})}function vv(n){let i={};return Object.entries(n).forEach(([e,t])=>{typeof t=="string"&&(t=[t]),t!==null&&(i[e]=Td(new Me([],{}),0,t))}),i}function oh(n){let i={};return Object.entries(n).forEach(([e,t])=>i[e]=`${t}`),i}function rh(n,i,e){return n==e.path&&Bn(i,e.parameters)}var Xo="imperative",pt=(function(n){return n[n.NavigationStart=0]="NavigationStart",n[n.NavigationEnd=1]="NavigationEnd",n[n.NavigationCancel=2]="NavigationCancel",n[n.NavigationError=3]="NavigationError",n[n.RoutesRecognized=4]="RoutesRecognized",n[n.ResolveStart=5]="ResolveStart",n[n.ResolveEnd=6]="ResolveEnd",n[n.GuardsCheckStart=7]="GuardsCheckStart",n[n.GuardsCheckEnd=8]="GuardsCheckEnd",n[n.RouteConfigLoadStart=9]="RouteConfigLoadStart",n[n.RouteConfigLoadEnd=10]="RouteConfigLoadEnd",n[n.ChildActivationStart=11]="ChildActivationStart",n[n.ChildActivationEnd=12]="ChildActivationEnd",n[n.ActivationStart=13]="ActivationStart",n[n.ActivationEnd=14]="ActivationEnd",n[n.Scroll=15]="Scroll",n[n.NavigationSkipped=16]="NavigationSkipped",n})(pt||{}),Kt=class{id;url;constructor(i,e){this.id=i,this.url=e}},Ji=class extends Kt{type=pt.NavigationStart;navigationTrigger;restoredState;constructor(i,e,t="imperative",a=null){super(i,e),this.navigationTrigger=t,this.restoredState=a}toString(){return`NavigationStart(id: ${this.id}, url: '${this.url}')`}},bn=class extends Kt{urlAfterRedirects;type=pt.NavigationEnd;constructor(i,e,t){super(i,e),this.urlAfterRedirects=t}toString(){return`NavigationEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}')`}},Rt=(function(n){return n[n.Redirect=0]="Redirect",n[n.SupersededByNewNavigation=1]="SupersededByNewNavigation",n[n.NoDataFromResolver=2]="NoDataFromResolver",n[n.GuardRejected=3]="GuardRejected",n[n.Aborted=4]="Aborted",n})(Rt||{}),er=(function(n){return n[n.IgnoredSameUrlNavigation=0]="IgnoredSameUrlNavigation",n[n.IgnoredByUrlHandlingStrategy=1]="IgnoredByUrlHandlingStrategy",n})(er||{}),rn=class extends Kt{reason;code;type=pt.NavigationCancel;constructor(i,e,t,a){super(i,e),this.reason=t,this.code=a}toString(){return`NavigationCancel(id: ${this.id}, url: '${this.url}')`}};function Eh(n){return n instanceof rn&&(n.code===Rt.Redirect||n.code===Rt.SupersededByNewNavigation)}var ti=class extends Kt{reason;code;type=pt.NavigationSkipped;constructor(i,e,t,a){super(i,e),this.reason=t,this.code=a}},ea=class extends Kt{error;target;type=pt.NavigationError;constructor(i,e,t,a){super(i,e),this.error=t,this.target=a}toString(){return`NavigationError(id: ${this.id}, url: '${this.url}', error: ${this.error})`}},tr=class extends Kt{urlAfterRedirects;state;type=pt.RoutesRecognized;constructor(i,e,t,a){super(i,e),this.urlAfterRedirects=t,this.state=a}toString(){return`RoutesRecognized(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`}},Ts=class extends Kt{urlAfterRedirects;state;type=pt.GuardsCheckStart;constructor(i,e,t,a){super(i,e),this.urlAfterRedirects=t,this.state=a}toString(){return`GuardsCheckStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`}},Os=class extends Kt{urlAfterRedirects;state;shouldActivate;type=pt.GuardsCheckEnd;constructor(i,e,t,a,o){super(i,e),this.urlAfterRedirects=t,this.state=a,this.shouldActivate=o}toString(){return`GuardsCheckEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state}, shouldActivate: ${this.shouldActivate})`}},Ps=class extends Kt{urlAfterRedirects;state;type=pt.ResolveStart;constructor(i,e,t,a){super(i,e),this.urlAfterRedirects=t,this.state=a}toString(){return`ResolveStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`}},Fs=class extends Kt{urlAfterRedirects;state;type=pt.ResolveEnd;constructor(i,e,t,a){super(i,e),this.urlAfterRedirects=t,this.state=a}toString(){return`ResolveEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`}},Ns=class{route;type=pt.RouteConfigLoadStart;constructor(i){this.route=i}toString(){return`RouteConfigLoadStart(path: ${this.route.path})`}},Ls=class{route;type=pt.RouteConfigLoadEnd;constructor(i){this.route=i}toString(){return`RouteConfigLoadEnd(path: ${this.route.path})`}},Bs=class{snapshot;type=pt.ChildActivationStart;constructor(i){this.snapshot=i}toString(){return`ChildActivationStart(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`}},js=class{snapshot;type=pt.ChildActivationEnd;constructor(i){this.snapshot=i}toString(){return`ChildActivationEnd(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`}},Vs=class{snapshot;type=pt.ActivationStart;constructor(i){this.snapshot=i}toString(){return`ActivationStart(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`}},zs=class{snapshot;type=pt.ActivationEnd;constructor(i){this.snapshot=i}toString(){return`ActivationEnd(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`}};var La=class{},nr=class{},Ba=class{url;navigationBehaviorOptions;constructor(i,e){this.url=i,this.navigationBehaviorOptions=e}};function yv(n){return!(n instanceof La)&&!(n instanceof Ba)&&!(n instanceof nr)}var Us=class{rootInjector;outlet=null;route=null;children;attachRef=null;get injector(){return this.route?.snapshot._environmentInjector??this.rootInjector}constructor(i){this.rootInjector=i,this.children=new Ha(this.rootInjector)}},Ha=(()=>{class n{rootInjector;contexts=new Map;constructor(e){this.rootInjector=e}onChildOutletCreated(e,t){let a=this.getOrCreateContext(e);a.outlet=t,this.contexts.set(e,a)}onChildOutletDestroyed(e){let t=this.getContext(e);t&&(t.outlet=null,t.attachRef=null)}onOutletDeactivated(){let e=this.contexts;return this.contexts=new Map,e}onOutletReAttached(e){this.contexts=e}getOrCreateContext(e){let t=this.getContext(e);return t||(t=new Us(this.rootInjector),this.contexts.set(e,t)),t}getContext(e){return this.contexts.get(e)||null}static \u0275fac=function(t){return new(t||n)(U(bt))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),Hs=class{_root;constructor(i){this._root=i}get root(){return this._root.value}parent(i){let e=this.pathFromRoot(i);return e.length>1?e[e.length-2]:null}children(i){let e=Od(i,this._root);return e?e.children.map(t=>t.value):[]}firstChild(i){let e=Od(i,this._root);return e&&e.children.length>0?e.children[0].value:null}siblings(i){let e=Pd(i,this._root);return e.length<2?[]:e[e.length-2].children.map(a=>a.value).filter(a=>a!==i)}pathFromRoot(i){return Pd(i,this._root).map(e=>e.value)}};function Od(n,i){if(n===i.value)return i;for(let e of i.children){let t=Od(n,e);if(t)return t}return null}function Pd(n,i){if(n===i.value)return[i];for(let e of i.children){let t=Pd(n,e);if(t.length)return t.unshift(i),t}return[]}var Xt=class{value;children;constructor(i,e){this.value=i,this.children=e}toString(){return`TreeNode(${this.value})`}};function Pa(n){let i={};return n&&n.children.forEach(e=>i[e.value.outlet]=e),i}var ir=class extends Hs{snapshot;constructor(i,e){super(i),this.snapshot=e,Gd(this,i)}toString(){return this.snapshot.toString()}};function Sh(n,i){let e=xv(n,i),t=new et([new bi("",{})]),a=new et({}),o=new et({}),c=new et({}),u=new et(""),p=new Ct(t,a,c,u,o,ue,n,e.root);return p.snapshot=e.root,new ir(new Xt(p,[]),e)}function xv(n,i){let e={},t={},a={},c=new ja([],e,a,"",t,ue,n,null,{},i);return new ar("",new Xt(c,[]))}var Ct=class{urlSubject;paramsSubject;queryParamsSubject;fragmentSubject;dataSubject;outlet;component;snapshot;_futureSnapshot;_routerState;_paramMap;_queryParamMap;title;url;params;queryParams;fragment;data;constructor(i,e,t,a,o,c,u,p){this.urlSubject=i,this.paramsSubject=e,this.queryParamsSubject=t,this.fragmentSubject=a,this.dataSubject=o,this.outlet=c,this.component=u,this._futureSnapshot=p,this.title=this.dataSubject?.pipe(Q(f=>f[sr]))??K(void 0),this.url=i,this.params=e,this.queryParams=t,this.fragment=a,this.data=o}get routeConfig(){return this._futureSnapshot.routeConfig}get root(){return this._routerState.root}get parent(){return this._routerState.parent(this)}get firstChild(){return this._routerState.firstChild(this)}get children(){return this._routerState.children(this)}get pathFromRoot(){return this._routerState.pathFromRoot(this)}get paramMap(){return this._paramMap??=this.params.pipe(Q(i=>Zi(i))),this._paramMap}get queryParamMap(){return this._queryParamMap??=this.queryParams.pipe(Q(i=>Zi(i))),this._queryParamMap}toString(){return this.snapshot?this.snapshot.toString():`Future(${this._futureSnapshot})`}};function $d(n,i,e="emptyOnly"){let t,{routeConfig:a}=n;return i!==null&&(e==="always"||a?.path===""||!i.component&&!i.routeConfig?.loadComponent)?t={params:M(M({},i.params),n.params),data:M(M({},i.data),n.data),resolve:M(M(M(M({},n.data),i.data),a?.data),n._resolvedData)}:t={params:M({},n.params),data:M({},n.data),resolve:M(M({},n.data),n._resolvedData??{})},a&&Mh(a)&&(t.resolve[sr]=a.title),t}var ja=class{url;params;queryParams;fragment;data;outlet;component;routeConfig;_resolve;_resolvedData;_routerState;_paramMap;_queryParamMap;_environmentInjector;get title(){return this.data?.[sr]}constructor(i,e,t,a,o,c,u,p,f,b){this.url=i,this.params=e,this.queryParams=t,this.fragment=a,this.data=o,this.outlet=c,this.component=u,this.routeConfig=p,this._resolve=f,this._environmentInjector=b}get root(){return this._routerState.root}get parent(){return this._routerState.parent(this)}get firstChild(){return this._routerState.firstChild(this)}get children(){return this._routerState.children(this)}get pathFromRoot(){return this._routerState.pathFromRoot(this)}get paramMap(){return this._paramMap??=Zi(this.params),this._paramMap}get queryParamMap(){return this._queryParamMap??=Zi(this.queryParams),this._queryParamMap}toString(){let i=this.url.map(t=>t.toString()).join("/"),e=this.routeConfig?this.routeConfig.path:"";return`Route(url:'${i}', path:'${e}')`}},ar=class extends Hs{url;constructor(i,e){super(e),this.url=i,Gd(this,e)}toString(){return kh(this._root)}};function Gd(n,i){i.value._routerState=n,i.children.forEach(e=>Gd(n,e))}function kh(n){let i=n.children.length>0?` { ${n.children.map(kh).join(", ")} } `:"";return`${n.value}${i}`}function Sd(n){if(n.snapshot){let i=n.snapshot,e=n._futureSnapshot;n.snapshot=e,Bn(i.queryParams,e.queryParams)||n.queryParamsSubject.next(e.queryParams),i.fragment!==e.fragment&&n.fragmentSubject.next(e.fragment),Bn(i.params,e.params)||n.paramsSubject.next(e.params),Yb(i.url,e.url)||n.urlSubject.next(e.url),Bn(i.data,e.data)||n.dataSubject.next(e.data)}else n.snapshot=n._futureSnapshot,n.dataSubject.next(n._futureSnapshot.data)}function Fd(n,i){let e=Bn(n.params,i.params)&&ev(n.url,i.url),t=!n.parent!=!i.parent;return e&&!t&&(!n.parent||Fd(n.parent,i.parent))}function Mh(n){return typeof n.title=="string"||n.title===null}var Ih=new E(""),na=(()=>{class n{activated=null;get activatedComponentRef(){return this.activated}_activatedRoute=null;name=ue;activateEvents=new z;deactivateEvents=new z;attachEvents=new z;detachEvents=new z;routerOutletData=lp();parentContexts=m(Ha);location=m(Xe);changeDetector=m(Z);inputBinder=m(Ws,{optional:!0});supportsBindingToComponentInputs=!0;ngOnChanges(e){if(e.name){let{firstChange:t,previousValue:a}=e.name;if(t)return;this.isTrackedInParentContexts(a)&&(this.deactivate(),this.parentContexts.onChildOutletDestroyed(a)),this.initializeOutletWithName()}}ngOnDestroy(){this.isTrackedInParentContexts(this.name)&&this.parentContexts.onChildOutletDestroyed(this.name),this.inputBinder?.unsubscribeFromRouteData(this)}isTrackedInParentContexts(e){return this.parentContexts.getContext(e)?.outlet===this}ngOnInit(){this.initializeOutletWithName()}initializeOutletWithName(){if(this.parentContexts.onChildOutletCreated(this.name,this),this.activated)return;let e=this.parentContexts.getContext(this.name);e?.route&&(e.attachRef?this.attach(e.attachRef,e.route):this.activateWith(e.route,e.injector))}get isActivated(){return!!this.activated}get component(){if(!this.activated)throw new oe(4012,!1);return this.activated.instance}get activatedRoute(){if(!this.activated)throw new oe(4012,!1);return this._activatedRoute}get activatedRouteData(){return this._activatedRoute?this._activatedRoute.snapshot.data:{}}detach(){if(!this.activated)throw new oe(4012,!1);this.location.detach();let e=this.activated;return this.activated=null,this._activatedRoute=null,this.detachEvents.emit(e.instance),e}attach(e,t){this.activated=e,this._activatedRoute=t,this.location.insert(e.hostView),this.inputBinder?.bindActivatedRouteToOutletComponent(this),this.attachEvents.emit(e.instance)}deactivate(){if(this.activated){let e=this.component;this.activated.destroy(),this.activated=null,this._activatedRoute=null,this.deactivateEvents.emit(e)}}activateWith(e,t){if(this.isActivated)throw new oe(4013,!1);this._activatedRoute=e;let a=this.location,c=e.snapshot.component,u=this.parentContexts.getOrCreateContext(this.name).children,p=new Nd(e,u,a.injector,this.routerOutletData);this.activated=a.createComponent(c,{index:a.length,injector:p,environmentInjector:t}),this.changeDetector.markForCheck(),this.inputBinder?.bindActivatedRouteToOutletComponent(this),this.activateEvents.emit(this.activated.instance)}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["router-outlet"]],inputs:{name:"name",routerOutletData:[1,"routerOutletData"]},outputs:{activateEvents:"activate",deactivateEvents:"deactivate",attachEvents:"attach",detachEvents:"detach"},exportAs:["outlet"],features:[we]})}return n})(),Nd=class{route;childContexts;parent;outletData;constructor(i,e,t,a){this.route=i,this.childContexts=e,this.parent=t,this.outletData=a}get(i,e){return i===Ct?this.route:i===Ha?this.childContexts:i===Ih?this.outletData:this.parent.get(i,e)}},Ws=new E("");var qd=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["ng-component"]],exportAs:["emptyRouterOutlet"],decls:1,vars:0,template:function(t,a){t&1&&H(0,"router-outlet")},dependencies:[na],encapsulation:2})}return n})();function Wd(n){let i=n.children&&n.children.map(Wd),e=i?Re(M({},n),{children:i}):M({},n);return!e.component&&!e.loadComponent&&(i||e.loadChildren)&&e.outlet&&e.outlet!==ue&&(e.component=qd),e}function Cv(n,i,e){let t=or(n,i._root,e?e._root:void 0);return new ir(t,i)}function or(n,i,e){if(e&&n.shouldReuseRoute(i.value,e.value.snapshot)){let t=e.value;t._futureSnapshot=i.value;let a=wv(n,i,e);return new Xt(t,a)}else{if(n.shouldAttach(i.value)){let o=n.retrieve(i.value);if(o!==null){let c=o.route;return c.value._futureSnapshot=i.value,c.children=i.children.map(u=>or(n,u)),c}}let t=Dv(i.value),a=i.children.map(o=>or(n,o));return new Xt(t,a)}}function wv(n,i,e){return i.children.map(t=>{for(let a of e.children)if(n.shouldReuseRoute(t.value,a.value.snapshot))return or(n,t,a);return or(n,t)})}function Dv(n){return new Ct(new et(n.url),new et(n.params),new et(n.queryParams),new et(n.fragment),new et(n.data),n.outlet,n.component,n)}var Va=class{redirectTo;navigationBehaviorOptions;constructor(i,e){this.redirectTo=i,this.navigationBehaviorOptions=e}},Ah="ngNavigationCancelingError";function $s(n,i){let{redirectTo:e,navigationBehaviorOptions:t}=yi(i)?{redirectTo:i,navigationBehaviorOptions:void 0}:i,a=Rh(!1,Rt.Redirect);return a.url=e,a.navigationBehaviorOptions=t,a}function Rh(n,i){let e=new Error(`NavigationCancelingError: ${n||""}`);return e[Ah]=!0,e.cancellationCode=i,e}function Ev(n){return Th(n)&&yi(n.url)}function Th(n){return!!n&&n[Ah]}var Ld=class{routeReuseStrategy;futureState;currState;forwardEvent;inputBindingEnabled;constructor(i,e,t,a,o){this.routeReuseStrategy=i,this.futureState=e,this.currState=t,this.forwardEvent=a,this.inputBindingEnabled=o}activate(i){let e=this.futureState._root,t=this.currState?this.currState._root:null;this.deactivateChildRoutes(e,t,i),Sd(this.futureState.root),this.activateChildRoutes(e,t,i)}deactivateChildRoutes(i,e,t){let a=Pa(e);i.children.forEach(o=>{let c=o.value.outlet;this.deactivateRoutes(o,a[c],t),delete a[c]}),Object.values(a).forEach(o=>{this.deactivateRouteAndItsChildren(o,t)})}deactivateRoutes(i,e,t){let a=i.value,o=e?e.value:null;if(a===o)if(a.component){let c=t.getContext(a.outlet);c&&this.deactivateChildRoutes(i,e,c.children)}else this.deactivateChildRoutes(i,e,t);else o&&this.deactivateRouteAndItsChildren(e,t)}deactivateRouteAndItsChildren(i,e){i.value.component&&this.routeReuseStrategy.shouldDetach(i.value.snapshot)?this.detachAndStoreRouteSubtree(i,e):this.deactivateRouteAndOutlet(i,e)}detachAndStoreRouteSubtree(i,e){let t=e.getContext(i.value.outlet),a=t&&i.value.component?t.children:e,o=Pa(i);for(let c of Object.values(o))this.deactivateRouteAndItsChildren(c,a);if(t&&t.outlet){let c=t.outlet.detach(),u=t.children.onOutletDeactivated();this.routeReuseStrategy.store(i.value.snapshot,{componentRef:c,route:i,contexts:u})}}deactivateRouteAndOutlet(i,e){let t=e.getContext(i.value.outlet),a=t&&i.value.component?t.children:e,o=Pa(i);for(let c of Object.values(o))this.deactivateRouteAndItsChildren(c,a);t&&(t.outlet&&(t.outlet.deactivate(),t.children.onOutletDeactivated()),t.attachRef=null,t.route=null)}activateChildRoutes(i,e,t){let a=Pa(e);i.children.forEach(o=>{this.activateRoutes(o,a[o.value.outlet],t),this.forwardEvent(new zs(o.value.snapshot))}),i.children.length&&this.forwardEvent(new js(i.value.snapshot))}activateRoutes(i,e,t){let a=i.value,o=e?e.value:null;if(Sd(a),a===o)if(a.component){let c=t.getOrCreateContext(a.outlet);this.activateChildRoutes(i,e,c.children)}else this.activateChildRoutes(i,e,t);else if(a.component){let c=t.getOrCreateContext(a.outlet);if(this.routeReuseStrategy.shouldAttach(a.snapshot)){let u=this.routeReuseStrategy.retrieve(a.snapshot);this.routeReuseStrategy.store(a.snapshot,null),c.children.onOutletReAttached(u.contexts),c.attachRef=u.componentRef,c.route=u.route.value,c.outlet&&c.outlet.attach(u.componentRef,u.route.value),Sd(u.route.value),this.activateChildRoutes(i,null,c.children)}else c.attachRef=null,c.route=a,c.outlet&&c.outlet.activateWith(a,c.injector),this.activateChildRoutes(i,null,c.children)}else this.activateChildRoutes(i,null,t)}},Gs=class{path;route;constructor(i){this.path=i,this.route=this.path[this.path.length-1]}},Na=class{component;route;constructor(i,e){this.component=i,this.route=e}};function Sv(n,i,e){let t=n._root,a=i?i._root:null;return Qo(t,a,e,[t.value])}function kv(n){let i=n.routeConfig?n.routeConfig.canActivateChild:null;return!i||i.length===0?null:{node:n,guards:i}}function $a(n,i){let e=Symbol(),t=i.get(n,e);return t===e?typeof n=="function"&&!Tm(n)?n:i.get(n):t}function Qo(n,i,e,t,a={canDeactivateChecks:[],canActivateChecks:[]}){let o=Pa(i);return n.children.forEach(c=>{Mv(c,o[c.value.outlet],e,t.concat([c.value]),a),delete o[c.value.outlet]}),Object.entries(o).forEach(([c,u])=>Ko(u,e.getContext(c),a)),a}function Mv(n,i,e,t,a={canDeactivateChecks:[],canActivateChecks:[]}){let o=n.value,c=i?i.value:null,u=e?e.getContext(n.value.outlet):null;if(c&&o.routeConfig===c.routeConfig){let p=Iv(c,o,o.routeConfig.runGuardsAndResolvers);p?a.canActivateChecks.push(new Gs(t)):(o.data=c.data,o._resolvedData=c._resolvedData),o.component?Qo(n,i,u?u.children:null,t,a):Qo(n,i,e,t,a),p&&u&&u.outlet&&u.outlet.isActivated&&a.canDeactivateChecks.push(new Na(u.outlet.component,c))}else c&&Ko(i,u,a),a.canActivateChecks.push(new Gs(t)),o.component?Qo(n,null,u?u.children:null,t,a):Qo(n,null,e,t,a);return a}function Iv(n,i,e){if(typeof e=="function")return $t(i._environmentInjector,()=>e(n,i));switch(e){case"pathParamsChange":return!Ki(n.url,i.url);case"pathParamsOrQueryParamsChange":return!Ki(n.url,i.url)||!Bn(n.queryParams,i.queryParams);case"always":return!0;case"paramsOrQueryParamsChange":return!Fd(n,i)||!Bn(n.queryParams,i.queryParams);default:return!Fd(n,i)}}function Ko(n,i,e){let t=Pa(n),a=n.value;Object.entries(t).forEach(([o,c])=>{a.component?i?Ko(c,i.children.getContext(o),e):Ko(c,null,e):Ko(c,i,e)}),a.component?i&&i.outlet&&i.outlet.isActivated?e.canDeactivateChecks.push(new Na(i.outlet.component,a)):e.canDeactivateChecks.push(new Na(null,a)):e.canDeactivateChecks.push(new Na(null,a))}function cr(n){return typeof n=="function"}function Av(n){return typeof n=="boolean"}function Rv(n){return n&&cr(n.canLoad)}function Tv(n){return n&&cr(n.canActivate)}function Ov(n){return n&&cr(n.canActivateChild)}function Pv(n){return n&&cr(n.canDeactivate)}function Fv(n){return n&&cr(n.canMatch)}function Oh(n){return n instanceof Mm||n?.name==="EmptyError"}var Es=Symbol("INITIAL_VALUE");function za(){return at(n=>nn(n.map(i=>i.pipe(it(1),tt(Es)))).pipe(Q(i=>{for(let e of i)if(e!==!0){if(e===Es)return Es;if(e===!1||Nv(e))return e}return!0}),Ce(i=>i!==Es),it(1)))}function Nv(n){return yi(n)||n instanceof Va}function Ph(n){return n.aborted?K(void 0).pipe(it(1)):new Ht(i=>{let e=()=>{i.next(),i.complete()};return n.addEventListener("abort",e),()=>n.removeEventListener("abort",e)})}function Fh(n){return pe(Ph(n))}function Lv(n){return Kn(i=>{let{targetSnapshot:e,currentSnapshot:t,guards:{canActivateChecks:a,canDeactivateChecks:o}}=i;return o.length===0&&a.length===0?K(Re(M({},i),{guardsResult:!0})):Bv(o,e,t).pipe(Kn(c=>c&&Av(c)?jv(e,a,n):K(c)),Q(c=>Re(M({},i),{guardsResult:c})))})}function Bv(n,i,e){return Lt(n).pipe(Kn(t=>$v(t.component,t.route,e,i)),li(t=>t!==!0,!0))}function jv(n,i,e){return Lt(i).pipe(ya(t=>Jr(zv(t.route.parent,e),Vv(t.route,e),Hv(n,t.path),Uv(n,t.route))),li(t=>t!==!0,!0))}function Vv(n,i){return n!==null&&i&&i(new Vs(n)),K(!0)}function zv(n,i){return n!==null&&i&&i(new Bs(n)),K(!0)}function Uv(n,i){let e=i.routeConfig?i.routeConfig.canActivate:null;if(!e||e.length===0)return K(!0);let t=e.map(a=>Tn(()=>{let o=i._environmentInjector,c=$a(a,o),u=Tv(c)?c.canActivate(i,n):$t(o,()=>c(i,n));return ta(u).pipe(li())}));return K(t).pipe(za())}function Hv(n,i){let e=i[i.length-1],a=i.slice(0,i.length-1).reverse().map(o=>kv(o)).filter(o=>o!==null).map(o=>Tn(()=>{let c=o.guards.map(u=>{let p=o.node._environmentInjector,f=$a(u,p),b=Ov(f)?f.canActivateChild(e,n):$t(p,()=>f(e,n));return ta(b).pipe(li())});return K(c).pipe(za())}));return K(a).pipe(za())}function $v(n,i,e,t){let a=i&&i.routeConfig?i.routeConfig.canDeactivate:null;if(!a||a.length===0)return K(!0);let o=a.map(c=>{let u=i._environmentInjector,p=$a(c,u),f=Pv(p)?p.canDeactivate(n,i,e,t):$t(u,()=>p(n,i,e,t));return ta(f).pipe(li())});return K(o).pipe(za())}function Gv(n,i,e,t,a){let o=i.canLoad;if(o===void 0||o.length===0)return K(!0);let c=o.map(u=>{let p=$a(u,n),f=Rv(p)?p.canLoad(i,e):$t(n,()=>p(i,e)),b=ta(f);return a?b.pipe(Fh(a)):b});return K(c).pipe(za(),Nh(t))}function Nh(n){return Sm(_t(i=>{if(typeof i!="boolean")throw $s(n,i)}),Q(i=>i===!0))}function qv(n,i,e,t,a,o){let c=i.canMatch;if(!c||c.length===0)return K(!0);let u=c.map(p=>{let f=$a(p,n),b=Fv(f)?f.canMatch(i,e,a):$t(n,()=>f(i,e,a));return ta(b).pipe(Fh(o))});return K(u).pipe(za(),Nh(t))}var ei=class n extends Error{segmentGroup;constructor(i){super(),this.segmentGroup=i||null,Object.setPrototypeOf(this,n.prototype)}},rr=class n extends Error{urlTree;constructor(i){super(),this.urlTree=i,Object.setPrototypeOf(this,n.prototype)}};function Wv(n){throw new oe(4e3,!1)}function Qv(n){throw Rh(!1,Rt.GuardRejected)}var Bd=class{urlSerializer;urlTree;constructor(i,e){this.urlSerializer=i,this.urlTree=e}lineralizeSegments(i,e){return $e(this,null,function*(){let t=[],a=e.root;for(;;){if(t=t.concat(a.segments),a.numberOfChildren===0)return t;if(a.numberOfChildren>1||!a.children[ue])throw Wv(`${i.redirectTo}`);a=a.children[ue]}})}applyRedirectCommands(i,e,t,a,o){return $e(this,null,function*(){let c=yield Yv(e,a,o);if(c instanceof zt)throw new rr(c);let u=this.applyRedirectCreateUrlTree(c,this.urlSerializer.parse(c),i,t);if(c[0]==="/")throw new rr(u);return u})}applyRedirectCreateUrlTree(i,e,t,a){let o=this.createSegmentGroup(i,e.root,t,a);return new zt(o,this.createQueryParams(e.queryParams,this.urlTree.queryParams),e.fragment)}createQueryParams(i,e){let t={};return Object.entries(i).forEach(([a,o])=>{if(typeof o=="string"&&o[0]===":"){let u=o.substring(1);t[a]=e[u]}else t[a]=o}),t}createSegmentGroup(i,e,t,a){let o=this.createSegments(i,e.segments,t,a),c={};return Object.entries(e.children).forEach(([u,p])=>{c[u]=this.createSegmentGroup(i,p,t,a)}),new Me(o,c)}createSegments(i,e,t,a){return e.map(o=>o.path[0]===":"?this.findPosParam(i,o,a):this.findOrReturn(o,t))}findPosParam(i,e,t){let a=t[e.path.substring(1)];if(!a)throw new oe(4001,!1);return a}findOrReturn(i,e){let t=0;for(let a of e){if(a.path===i.path)return e.splice(t),a;t++}return i}};function Yv(n,i,e){if(typeof n=="string")return Promise.resolve(n);let t=n;return Is(ta($t(e,()=>t(i))))}function Xv(n,i){return n.providers&&!n._injector&&(n._injector=Gl(n.providers,i,`Route: ${n.path}`)),n._injector??i}function _n(n){return n.outlet||ue}function Kv(n,i){let e=n.filter(t=>_n(t)===i);return e.push(...n.filter(t=>_n(t)!==i)),e}var jd={matched:!1,consumedSegments:[],remainingSegments:[],parameters:{},positionalParamSegments:{}};function Lh(n){return{routeConfig:n.routeConfig,url:n.url,params:n.params,queryParams:n.queryParams,fragment:n.fragment,data:n.data,outlet:n.outlet,title:n.title,paramMap:n.paramMap,queryParamMap:n.queryParamMap}}function Zv(n,i,e,t,a,o,c){let u=Bh(n,i,e);if(!u.matched)return K(u);let p=Lh(o(u));return t=Xv(i,t),qv(t,i,e,a,p,c).pipe(Q(f=>f===!0?u:M({},jd)))}function Bh(n,i,e){if(i.path==="")return i.pathMatch==="full"&&(n.hasChildren()||e.length>0)?M({},jd):{matched:!0,consumedSegments:[],remainingSegments:e,parameters:{},positionalParamSegments:{}};let a=(i.matcher||lh)(e,n,i);if(!a)return M({},jd);let o={};Object.entries(a.posParams??{}).forEach(([u,p])=>{o[u]=p.path});let c=a.consumed.length>0?M(M({},o),a.consumed[a.consumed.length-1].parameters):o;return{matched:!0,consumedSegments:a.consumed,remainingSegments:e.slice(a.consumed.length),parameters:c,positionalParamSegments:a.posParams??{}}}function sh(n,i,e,t,a){return e.length>0&&ty(n,e,t,a)?{segmentGroup:new Me(i,ey(t,new Me(e,n.children))),slicedSegments:[]}:e.length===0&&ny(n,e,t)?{segmentGroup:new Me(n.segments,Jv(n,e,t,n.children)),slicedSegments:e}:{segmentGroup:new Me(n.segments,n.children),slicedSegments:e}}function Jv(n,i,e,t){let a={};for(let o of e)if(Qs(n,i,o)&&!t[_n(o)]){let c=new Me([],{});a[_n(o)]=c}return M(M({},t),a)}function ey(n,i){let e={};e[ue]=i;for(let t of n)if(t.path===""&&_n(t)!==ue){let a=new Me([],{});e[_n(t)]=a}return e}function ty(n,i,e,t){return e.some(a=>!Qs(n,i,a)||!(_n(a)!==ue)?!1:!(t!==void 0&&_n(a)===t))}function ny(n,i,e){return e.some(t=>Qs(n,i,t))}function Qs(n,i,e){return(n.hasChildren()||i.length>0)&&e.pathMatch==="full"?!1:e.path===""}function iy(n,i,e){return i.length===0&&!n.children[e]}var Vd=class{};function ay(n,i,e,t,a,o,c="emptyOnly",u){return $e(this,null,function*(){return new zd(n,i,e,t,a,c,o,u).recognize()})}var oy=31,zd=class{injector;configLoader;rootComponentType;config;urlTree;paramsInheritanceStrategy;urlSerializer;abortSignal;applyRedirects;absoluteRedirectCount=0;allowRedirects=!0;constructor(i,e,t,a,o,c,u,p){this.injector=i,this.configLoader=e,this.rootComponentType=t,this.config=a,this.urlTree=o,this.paramsInheritanceStrategy=c,this.urlSerializer=u,this.abortSignal=p,this.applyRedirects=new Bd(this.urlSerializer,this.urlTree)}noMatchError(i){return new oe(4002,`'${i.segmentGroup}'`)}recognize(){return $e(this,null,function*(){let i=sh(this.urlTree.root,[],[],this.config).segmentGroup,{children:e,rootSnapshot:t}=yield this.match(i),a=new Xt(t,e),o=new ar("",a),c=yh(t,[],this.urlTree.queryParams,this.urlTree.fragment);return c.queryParams=this.urlTree.queryParams,o.url=this.urlSerializer.serialize(c),{state:o,tree:c}})}match(i){return $e(this,null,function*(){let e=new ja([],Object.freeze({}),Object.freeze(M({},this.urlTree.queryParams)),this.urlTree.fragment,Object.freeze({}),ue,this.rootComponentType,null,{},this.injector);try{return{children:yield this.processSegmentGroup(this.injector,this.config,i,ue,e),rootSnapshot:e}}catch(t){if(t instanceof rr)return this.urlTree=t.urlTree,this.match(t.urlTree.root);throw t instanceof ei?this.noMatchError(t):t}})}processSegmentGroup(i,e,t,a,o){return $e(this,null,function*(){if(t.segments.length===0&&t.hasChildren())return this.processChildren(i,e,t,o);let c=yield this.processSegment(i,e,t,t.segments,a,!0,o);return c instanceof Xt?[c]:[]})}processChildren(i,e,t,a){return $e(this,null,function*(){let o=[];for(let p of Object.keys(t.children))p==="primary"?o.unshift(p):o.push(p);let c=[];for(let p of o){let f=t.children[p],b=Kv(e,p),w=yield this.processSegmentGroup(i,b,f,p,a);c.push(...w)}let u=jh(c);return ry(u),u})}processSegment(i,e,t,a,o,c,u){return $e(this,null,function*(){for(let p of e)try{return yield this.processSegmentAgainstRoute(p._injector??i,e,p,t,a,o,c,u)}catch(f){if(f instanceof ei||Oh(f))continue;throw f}if(iy(t,a,o))return new Vd;throw new ei(t)})}processSegmentAgainstRoute(i,e,t,a,o,c,u,p){return $e(this,null,function*(){if(_n(t)!==c&&(c===ue||!Qs(a,o,t)))throw new ei(a);if(t.redirectTo===void 0)return this.matchSegmentAgainstRoute(i,a,t,o,c,p);if(this.allowRedirects&&u)return this.expandSegmentAgainstRouteUsingRedirect(i,a,e,t,o,c,p);throw new ei(a)})}expandSegmentAgainstRouteUsingRedirect(i,e,t,a,o,c,u){return $e(this,null,function*(){let{matched:p,parameters:f,consumedSegments:b,positionalParamSegments:w,remainingSegments:L}=Bh(e,a,o);if(!p)throw new ei(e);typeof a.redirectTo=="string"&&a.redirectTo[0]==="/"&&(this.absoluteRedirectCount++,this.absoluteRedirectCount>oy&&(this.allowRedirects=!1));let $=this.createSnapshot(i,a,o,f,u);if(this.abortSignal.aborted)throw new Error(this.abortSignal.reason);let ae=yield this.applyRedirects.applyRedirectCommands(b,a.redirectTo,w,Lh($),i),me=yield this.applyRedirects.lineralizeSegments(a,ae);return this.processSegment(i,t,e,me.concat(L),c,!1,u)})}createSnapshot(i,e,t,a,o){let c=new ja(t,a,Object.freeze(M({},this.urlTree.queryParams)),this.urlTree.fragment,cy(e),_n(e),e.component??e._loadedComponent??null,e,ly(e),i),u=$d(c,o,this.paramsInheritanceStrategy);return c.params=Object.freeze(u.params),c.data=Object.freeze(u.data),c}matchSegmentAgainstRoute(i,e,t,a,o,c){return $e(this,null,function*(){if(this.abortSignal.aborted)throw new Error(this.abortSignal.reason);let u=gt=>this.createSnapshot(i,t,gt.consumedSegments,gt.parameters,c),p=yield Is(Zv(e,t,a,i,this.urlSerializer,u,this.abortSignal));if(t.path==="**"&&(e.children={}),!p?.matched)throw new ei(e);i=t._injector??i;let{routes:f}=yield this.getChildConfig(i,t,a),b=t._loadedInjector??i,{parameters:w,consumedSegments:L,remainingSegments:$}=p,ae=this.createSnapshot(i,t,L,w,c),{segmentGroup:me,slicedSegments:J}=sh(e,L,$,f,o);if(J.length===0&&me.hasChildren()){let gt=yield this.processChildren(b,f,me,ae);return new Xt(ae,gt)}if(f.length===0&&J.length===0)return new Xt(ae,[]);let se=_n(t)===o,Ie=yield this.processSegment(b,f,me,J,se?ue:o,!0,ae);return new Xt(ae,Ie instanceof Xt?[Ie]:[])})}getChildConfig(i,e,t){return $e(this,null,function*(){if(e.children)return{routes:e.children,injector:i};if(e.loadChildren){if(e._loadedRoutes!==void 0){let o=e._loadedNgModuleFactory;return o&&!e._loadedInjector&&(e._loadedInjector=o.create(i).injector),{routes:e._loadedRoutes,injector:e._loadedInjector}}if(this.abortSignal.aborted)throw new Error(this.abortSignal.reason);if(yield Is(Gv(i,e,t,this.urlSerializer,this.abortSignal))){let o=yield this.configLoader.loadChildren(i,e);return e._loadedRoutes=o.routes,e._loadedInjector=o.injector,e._loadedNgModuleFactory=o.factory,o}throw Qv(e)}return{routes:[],injector:i}})}};function ry(n){n.sort((i,e)=>i.value.outlet===ue?-1:e.value.outlet===ue?1:i.value.outlet.localeCompare(e.value.outlet))}function sy(n){let i=n.value.routeConfig;return i&&i.path===""}function jh(n){let i=[],e=new Set;for(let t of n){if(!sy(t)){i.push(t);continue}let a=i.find(o=>t.value.routeConfig===o.value.routeConfig);a!==void 0?(a.children.push(...t.children),e.add(a)):i.push(t)}for(let t of e){let a=jh(t.children);i.push(new Xt(t.value,a))}return i.filter(t=>!e.has(t))}function cy(n){return n.data||{}}function ly(n){return n.resolve||{}}function dy(n,i,e,t,a,o,c){return Kn(u=>$e(null,null,function*(){let{state:p,tree:f}=yield ay(n,i,e,t,u.extractedUrl,a,o,c);return Re(M({},u),{targetSnapshot:p,urlAfterRedirects:f})}))}function uy(n){return Kn(i=>{let{targetSnapshot:e,guards:{canActivateChecks:t}}=i;if(!t.length)return K(i);let a=new Set(t.map(u=>u.route)),o=new Set;for(let u of a)if(!o.has(u))for(let p of Vh(u))o.add(p);let c=0;return Lt(o).pipe(ya(u=>a.has(u)?my(u,e,n):(u.data=$d(u,u.parent,n).resolve,K(void 0))),_t(()=>c++),Vl(1),Kn(u=>c===o.size?K(i):mt))})}function Vh(n){let i=n.children.map(e=>Vh(e)).flat();return[n,...i]}function my(n,i,e){let t=n.routeConfig,a=n._resolve;return t?.title!==void 0&&!Mh(t)&&(a[sr]=t.title),Tn(()=>(n.data=$d(n,n.parent,e).resolve,py(a,n,i).pipe(Q(o=>(n._resolvedData=o,n.data=M(M({},n.data),o),null)))))}function py(n,i,e){let t=Md(n);if(t.length===0)return K({});let a={};return Lt(t).pipe(Kn(o=>hy(n[o],i,e).pipe(li(),_t(c=>{if(c instanceof Va)throw $s(new vi,c);a[o]=c}))),Vl(1),Q(()=>a),va(o=>Oh(o)?mt:Zr(o)))}function hy(n,i,e){let t=i._environmentInjector,a=$a(n,t),o=a.resolve?a.resolve(i,e):$t(t,()=>a(i,e));return ta(o)}function ch(n){return at(i=>{let e=n(i);return e?Lt(e).pipe(Q(()=>i)):K(i)})}var Qd=(()=>{class n{buildTitle(e){let t,a=e.root;for(;a!==void 0;)t=this.getResolvedTitleForRoute(a)??t,a=a.children.find(o=>o.outlet===ue);return t}getResolvedTitleForRoute(e){return e.data[sr]}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:()=>m(zh),providedIn:"root"})}return n})(),zh=(()=>{class n extends Qd{title;constructor(e){super(),this.title=e}updateTitle(e){let t=this.buildTitle(e);t!==void 0&&this.title.setTitle(t)}static \u0275fac=function(t){return new(t||n)(U(th))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),Ga=new E("",{factory:()=>({})}),lr=new E(""),Uh=(()=>{class n{componentLoaders=new WeakMap;childrenLoaders=new WeakMap;onLoadStartListener;onLoadEndListener;compiler=m(rp);loadComponent(e,t){return $e(this,null,function*(){if(this.componentLoaders.get(t))return this.componentLoaders.get(t);if(t._loadedComponent)return Promise.resolve(t._loadedComponent);this.onLoadStartListener&&this.onLoadStartListener(t);let a=$e(this,null,function*(){try{let o=yield uh($t(e,()=>t.loadComponent())),c=yield Gh($h(o));return this.onLoadEndListener&&this.onLoadEndListener(t),t._loadedComponent=c,c}finally{this.componentLoaders.delete(t)}});return this.componentLoaders.set(t,a),a})}loadChildren(e,t){if(this.childrenLoaders.get(t))return this.childrenLoaders.get(t);if(t._loadedRoutes)return Promise.resolve({routes:t._loadedRoutes,injector:t._loadedInjector});this.onLoadStartListener&&this.onLoadStartListener(t);let a=$e(this,null,function*(){try{let o=yield Hh(t,this.compiler,e,this.onLoadEndListener);return t._loadedRoutes=o.routes,t._loadedInjector=o.injector,t._loadedNgModuleFactory=o.factory,o}finally{this.childrenLoaders.delete(t)}});return this.childrenLoaders.set(t,a),a}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();function Hh(n,i,e,t){return $e(this,null,function*(){let a=yield uh($t(e,()=>n.loadChildren())),o=yield Gh($h(a)),c;o instanceof Xm||Array.isArray(o)?c=o:c=yield i.compileModuleAsync(o),t&&t(n);let u,p,f=!1,b;return Array.isArray(c)?(p=c,f=!0):(u=c.create(e).injector,b=c,p=u.get(lr,[],{optional:!0,self:!0}).flat()),{routes:p.map(Wd),injector:u,factory:b}})}function fy(n){return n&&typeof n=="object"&&"default"in n}function $h(n){return fy(n)?n.default:n}function Gh(n){return $e(this,null,function*(){return n})}var Ys=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:()=>m(gy),providedIn:"root"})}return n})(),gy=(()=>{class n{shouldProcessUrl(e){return!0}extract(e){return e}merge(e,t){return e}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),qh=new E("");var _y=()=>{},Wh=new E(""),Qh=(()=>{class n{currentNavigation=le(null,{equal:()=>!1});currentTransition=null;lastSuccessfulNavigation=le(null);events=new F;transitionAbortWithErrorSubject=new F;configLoader=m(Uh);environmentInjector=m(bt);destroyRef=m($i);urlSerializer=m(Ua);rootContexts=m(Ha);location=m(hi);inputBindingEnabled=m(Ws,{optional:!0})!==null;titleStrategy=m(Qd);options=m(Ga,{optional:!0})||{};paramsInheritanceStrategy=this.options.paramsInheritanceStrategy||"emptyOnly";urlHandlingStrategy=m(Ys);createViewTransition=m(qh,{optional:!0});navigationErrorHandler=m(Wh,{optional:!0});navigationId=0;get hasRequestedNavigation(){return this.navigationId!==0}transitions;afterPreactivation=()=>K(void 0);rootComponentType=null;destroyed=!1;constructor(){let e=a=>this.events.next(new Ns(a)),t=a=>this.events.next(new Ls(a));this.configLoader.onLoadEndListener=t,this.configLoader.onLoadStartListener=e,this.destroyRef.onDestroy(()=>{this.destroyed=!0})}complete(){this.transitions?.complete()}handleNavigationRequest(e){let t=++this.navigationId;ke(()=>{this.transitions?.next(Re(M({},e),{extractedUrl:this.urlHandlingStrategy.extract(e.rawUrl),targetSnapshot:null,targetRouterState:null,guards:{canActivateChecks:[],canDeactivateChecks:[]},guardsResult:null,id:t,routesRecognizeHandler:{},beforeActivateHandler:{}}))})}setupNavigations(e){return this.transitions=new et(null),this.transitions.pipe(Ce(t=>t!==null),at(t=>{let a=!1,o=new AbortController,c=()=>!a&&this.currentTransition?.id===t.id;return K(t).pipe(at(u=>{if(this.navigationId>t.id)return this.cancelNavigationTransition(t,"",Rt.SupersededByNewNavigation),mt;this.currentTransition=t;let p=this.lastSuccessfulNavigation();this.currentNavigation.set({id:u.id,initialUrl:u.rawUrl,extractedUrl:u.extractedUrl,targetBrowserUrl:typeof u.extras.browserUrl=="string"?this.urlSerializer.parse(u.extras.browserUrl):u.extras.browserUrl,trigger:u.source,extras:u.extras,previousNavigation:p?Re(M({},p),{previousNavigation:null}):null,abort:()=>o.abort(),routesRecognizeHandler:u.routesRecognizeHandler,beforeActivateHandler:u.beforeActivateHandler});let f=!e.navigated||this.isUpdatingInternalState()||this.isUpdatedBrowserUrl(),b=u.extras.onSameUrlNavigation??e.onSameUrlNavigation;if(!f&&b!=="reload")return this.events.next(new ti(u.id,this.urlSerializer.serialize(u.rawUrl),"",er.IgnoredSameUrlNavigation)),u.resolve(!1),mt;if(this.urlHandlingStrategy.shouldProcessUrl(u.rawUrl))return K(u).pipe(at(w=>(this.events.next(new Ji(w.id,this.urlSerializer.serialize(w.extractedUrl),w.source,w.restoredState)),w.id!==this.navigationId?mt:Promise.resolve(w))),dy(this.environmentInjector,this.configLoader,this.rootComponentType,e.config,this.urlSerializer,this.paramsInheritanceStrategy,o.signal),_t(w=>{t.targetSnapshot=w.targetSnapshot,t.urlAfterRedirects=w.urlAfterRedirects,this.currentNavigation.update(L=>(L.finalUrl=w.urlAfterRedirects,L)),this.events.next(new nr)}),at(w=>Lt(t.routesRecognizeHandler.deferredHandle??K(void 0)).pipe(Q(()=>w))),_t(()=>{let w=new tr(u.id,this.urlSerializer.serialize(u.extractedUrl),this.urlSerializer.serialize(u.urlAfterRedirects),u.targetSnapshot);this.events.next(w)}));if(f&&this.urlHandlingStrategy.shouldProcessUrl(u.currentRawUrl)){let{id:w,extractedUrl:L,source:$,restoredState:ae,extras:me}=u,J=new Ji(w,this.urlSerializer.serialize(L),$,ae);this.events.next(J);let se=Sh(this.rootComponentType,this.environmentInjector).snapshot;return this.currentTransition=t=Re(M({},u),{targetSnapshot:se,urlAfterRedirects:L,extras:Re(M({},me),{skipLocationChange:!1,replaceUrl:!1})}),this.currentNavigation.update(Ie=>(Ie.finalUrl=L,Ie)),K(t)}else return this.events.next(new ti(u.id,this.urlSerializer.serialize(u.extractedUrl),"",er.IgnoredByUrlHandlingStrategy)),u.resolve(!1),mt}),Q(u=>{let p=new Ts(u.id,this.urlSerializer.serialize(u.extractedUrl),this.urlSerializer.serialize(u.urlAfterRedirects),u.targetSnapshot);return this.events.next(p),this.currentTransition=t=Re(M({},u),{guards:Sv(u.targetSnapshot,u.currentSnapshot,this.rootContexts)}),t}),Lv(u=>this.events.next(u)),at(u=>{if(t.guardsResult=u.guardsResult,u.guardsResult&&typeof u.guardsResult!="boolean")throw $s(this.urlSerializer,u.guardsResult);let p=new Os(u.id,this.urlSerializer.serialize(u.extractedUrl),this.urlSerializer.serialize(u.urlAfterRedirects),u.targetSnapshot,!!u.guardsResult);if(this.events.next(p),!c())return mt;if(!u.guardsResult)return this.cancelNavigationTransition(u,"",Rt.GuardRejected),mt;if(u.guards.canActivateChecks.length===0)return K(u);let f=new Ps(u.id,this.urlSerializer.serialize(u.extractedUrl),this.urlSerializer.serialize(u.urlAfterRedirects),u.targetSnapshot);if(this.events.next(f),!c())return mt;let b=!1;return K(u).pipe(uy(this.paramsInheritanceStrategy),_t({next:()=>{b=!0;let w=new Fs(u.id,this.urlSerializer.serialize(u.extractedUrl),this.urlSerializer.serialize(u.urlAfterRedirects),u.targetSnapshot);this.events.next(w)},complete:()=>{b||this.cancelNavigationTransition(u,"",Rt.NoDataFromResolver)}}))}),ch(u=>{let p=b=>{let w=[];if(b.routeConfig?._loadedComponent)b.component=b.routeConfig?._loadedComponent;else if(b.routeConfig?.loadComponent){let L=b._environmentInjector;w.push(this.configLoader.loadComponent(L,b.routeConfig).then($=>{b.component=$}))}for(let L of b.children)w.push(...p(L));return w},f=p(u.targetSnapshot.root);return f.length===0?K(u):Lt(Promise.all(f).then(()=>u))}),ch(()=>this.afterPreactivation()),at(()=>{let{currentSnapshot:u,targetSnapshot:p}=t,f=this.createViewTransition?.(this.environmentInjector,u.root,p.root);return f?Lt(f).pipe(Q(()=>t)):K(t)}),it(1),at(u=>{let p=Cv(e.routeReuseStrategy,u.targetSnapshot,u.currentRouterState);this.currentTransition=t=u=Re(M({},u),{targetRouterState:p}),this.currentNavigation.update(b=>(b.targetRouterState=p,b)),this.events.next(new La);let f=t.beforeActivateHandler.deferredHandle;return f?Lt(f.then(()=>u)):K(u)}),_t(u=>{new Ld(e.routeReuseStrategy,t.targetRouterState,t.currentRouterState,p=>this.events.next(p),this.inputBindingEnabled).activate(this.rootContexts),c()&&(a=!0,this.currentNavigation.update(p=>(p.abort=_y,p)),this.lastSuccessfulNavigation.set(ke(this.currentNavigation)),this.events.next(new bn(u.id,this.urlSerializer.serialize(u.extractedUrl),this.urlSerializer.serialize(u.urlAfterRedirects))),this.titleStrategy?.updateTitle(u.targetRouterState.snapshot),u.resolve(!0))}),pe(Ph(o.signal).pipe(Ce(()=>!a&&!t.targetRouterState),_t(()=>{this.cancelNavigationTransition(t,o.signal.reason+"",Rt.Aborted)}))),_t({complete:()=>{a=!0}}),pe(this.transitionAbortWithErrorSubject.pipe(_t(u=>{throw u}))),xa(()=>{o.abort(),a||this.cancelNavigationTransition(t,"",Rt.SupersededByNewNavigation),this.currentTransition?.id===t.id&&(this.currentNavigation.set(null),this.currentTransition=null)}),va(u=>{if(a=!0,this.destroyed)return t.resolve(!1),mt;if(Th(u))this.events.next(new rn(t.id,this.urlSerializer.serialize(t.extractedUrl),u.message,u.cancellationCode)),Ev(u)?this.events.next(new Ba(u.url,u.navigationBehaviorOptions)):t.resolve(!1);else{let p=new ea(t.id,this.urlSerializer.serialize(t.extractedUrl),u,t.targetSnapshot??void 0);try{let f=$t(this.environmentInjector,()=>this.navigationErrorHandler?.(p));if(f instanceof Va){let{message:b,cancellationCode:w}=$s(this.urlSerializer,f);this.events.next(new rn(t.id,this.urlSerializer.serialize(t.extractedUrl),b,w)),this.events.next(new Ba(f.redirectTo,f.navigationBehaviorOptions))}else throw this.events.next(p),u}catch(f){this.options.resolveNavigationPromiseOnError?t.resolve(!1):t.reject(f)}}return mt}))}))}cancelNavigationTransition(e,t,a){let o=new rn(e.id,this.urlSerializer.serialize(e.extractedUrl),t,a);this.events.next(o),e.resolve(!1)}isUpdatingInternalState(){return this.currentTransition?.extractedUrl.toString()!==this.currentTransition?.currentUrlTree.toString()}isUpdatedBrowserUrl(){let e=this.urlHandlingStrategy.extract(this.urlSerializer.parse(this.location.path(!0))),t=ke(this.currentNavigation),a=t?.targetBrowserUrl??t?.extractedUrl;return e.toString()!==a?.toString()&&!t?.extras.skipLocationChange}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();function by(n){return n!==Xo}var Yh=new E("");var Xh=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:()=>m(vy),providedIn:"root"})}return n})(),qs=class{shouldDetach(i){return!1}store(i,e){}shouldAttach(i){return!1}retrieve(i){return null}shouldReuseRoute(i,e){return i.routeConfig===e.routeConfig}shouldDestroyInjector(i){return!0}},vy=(()=>{class n extends qs{static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),Xs=(()=>{class n{urlSerializer=m(Ua);options=m(Ga,{optional:!0})||{};canceledNavigationResolution=this.options.canceledNavigationResolution||"replace";location=m(hi);urlHandlingStrategy=m(Ys);urlUpdateStrategy=this.options.urlUpdateStrategy||"deferred";currentUrlTree=new zt;getCurrentUrlTree(){return this.currentUrlTree}rawUrlTree=this.currentUrlTree;getRawUrlTree(){return this.rawUrlTree}createBrowserPath({finalUrl:e,initialUrl:t,targetBrowserUrl:a}){let o=e!==void 0?this.urlHandlingStrategy.merge(e,t):t,c=a??o;return c instanceof zt?this.urlSerializer.serialize(c):c}routerUrlState(e){return e?.targetBrowserUrl===void 0||e?.finalUrl===void 0?{}:{\u0275routerUrl:this.urlSerializer.serialize(e.finalUrl)}}commitTransition({targetRouterState:e,finalUrl:t,initialUrl:a}){t&&e?(this.currentUrlTree=t,this.rawUrlTree=this.urlHandlingStrategy.merge(t,a),this.routerState=e):this.rawUrlTree=a}routerState=Sh(null,m(bt));getRouterState(){return this.routerState}_stateMemento=this.createStateMemento();get stateMemento(){return this._stateMemento}updateStateMemento(){this._stateMemento=this.createStateMemento()}createStateMemento(){return{rawUrlTree:this.rawUrlTree,currentUrlTree:this.currentUrlTree,routerState:this.routerState}}restoredState(){return this.location.getState()}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:()=>m(yy),providedIn:"root"})}return n})(),yy=(()=>{class n extends Xs{currentPageId=0;lastSuccessfulId=-1;get browserPageId(){return this.canceledNavigationResolution!=="computed"?this.currentPageId:this.restoredState()?.\u0275routerPageId??this.currentPageId}registerNonRouterCurrentEntryChangeListener(e){return this.location.subscribe(t=>{t.type==="popstate"&&setTimeout(()=>{e(t.url,t.state,"popstate",{replaceUrl:!0})})})}handleRouterEvent(e,t){e instanceof Ji?this.updateStateMemento():e instanceof ti?this.commitTransition(t):e instanceof tr?this.urlUpdateStrategy==="eager"&&(t.extras.skipLocationChange||this.setBrowserUrl(this.createBrowserPath(t),t)):e instanceof La?(this.commitTransition(t),this.urlUpdateStrategy==="deferred"&&!t.extras.skipLocationChange&&this.setBrowserUrl(this.createBrowserPath(t),t)):e instanceof rn&&!Eh(e)?this.restoreHistory(t):e instanceof ea?this.restoreHistory(t,!0):e instanceof bn&&(this.lastSuccessfulId=e.id,this.currentPageId=this.browserPageId)}setBrowserUrl(e,t){let{extras:a,id:o}=t,{replaceUrl:c,state:u}=a;if(this.location.isCurrentPathEqualTo(e)||c){let p=this.browserPageId,f=M(M({},u),this.generateNgRouterState(o,p,t));this.location.replaceState(e,"",f)}else{let p=M(M({},u),this.generateNgRouterState(o,this.browserPageId+1,t));this.location.go(e,"",p)}}restoreHistory(e,t=!1){if(this.canceledNavigationResolution==="computed"){let a=this.browserPageId,o=this.currentPageId-a;o!==0?this.location.historyGo(o):this.getCurrentUrlTree()===e.finalUrl&&o===0&&(this.resetInternalState(e),this.resetUrlToCurrentUrlTree())}else this.canceledNavigationResolution==="replace"&&(t&&this.resetInternalState(e),this.resetUrlToCurrentUrlTree())}resetInternalState({finalUrl:e}){this.routerState=this.stateMemento.routerState,this.currentUrlTree=this.stateMemento.currentUrlTree,this.rawUrlTree=this.urlHandlingStrategy.merge(this.currentUrlTree,e??this.rawUrlTree)}resetUrlToCurrentUrlTree(){this.location.replaceState(this.urlSerializer.serialize(this.getRawUrlTree()),"",this.generateNgRouterState(this.lastSuccessfulId,this.currentPageId))}generateNgRouterState(e,t,a){return this.canceledNavigationResolution==="computed"?M({navigationId:e,\u0275routerPageId:t},this.routerUrlState(a)):M({navigationId:e},this.routerUrlState(a))}static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();function Yd(n,i){n.events.pipe(Ce(e=>e instanceof bn||e instanceof rn||e instanceof ea||e instanceof ti),Q(e=>e instanceof bn||e instanceof ti?0:(e instanceof rn?e.code===Rt.Redirect||e.code===Rt.SupersededByNewNavigation:!1)?2:1),Ce(e=>e!==2),it(1)).subscribe(()=>{i()})}var We=(()=>{class n{get currentUrlTree(){return this.stateManager.getCurrentUrlTree()}get rawUrlTree(){return this.stateManager.getRawUrlTree()}disposed=!1;nonRouterCurrentEntryChangeSubscription;console=m(Wl);stateManager=m(Xs);options=m(Ga,{optional:!0})||{};pendingTasks=m(Fm);urlUpdateStrategy=this.options.urlUpdateStrategy||"deferred";navigationTransitions=m(Qh);urlSerializer=m(Ua);location=m(hi);urlHandlingStrategy=m(Ys);injector=m(bt);_events=new F;get events(){return this._events}get routerState(){return this.stateManager.getRouterState()}navigated=!1;routeReuseStrategy=m(Xh);injectorCleanup=m(Yh,{optional:!0});onSameUrlNavigation=this.options.onSameUrlNavigation||"ignore";config=m(lr,{optional:!0})?.flat()??[];componentInputBindingEnabled=!!m(Ws,{optional:!0});currentNavigation=this.navigationTransitions.currentNavigation.asReadonly();constructor(){this.resetConfig(this.config),this.navigationTransitions.setupNavigations(this).subscribe({error:e=>{}}),this.subscribeToNavigationEvents()}eventsSubscription=new Le;subscribeToNavigationEvents(){let e=this.navigationTransitions.events.subscribe(t=>{try{let a=this.navigationTransitions.currentTransition,o=ke(this.navigationTransitions.currentNavigation);if(a!==null&&o!==null){if(this.stateManager.handleRouterEvent(t,o),t instanceof rn&&t.code!==Rt.Redirect&&t.code!==Rt.SupersededByNewNavigation)this.navigated=!0;else if(t instanceof bn)this.navigated=!0,this.injectorCleanup?.(this.routeReuseStrategy,this.routerState,this.config);else if(t instanceof Ba){let c=t.navigationBehaviorOptions,u=this.urlHandlingStrategy.merge(t.url,a.currentRawUrl),p=M({scroll:a.extras.scroll,browserUrl:a.extras.browserUrl,info:a.extras.info,skipLocationChange:a.extras.skipLocationChange,replaceUrl:a.extras.replaceUrl||this.urlUpdateStrategy==="eager"||by(a.source)},c);this.scheduleNavigation(u,Xo,null,p,{resolve:a.resolve,reject:a.reject,promise:a.promise})}}yv(t)&&this._events.next(t)}catch(a){this.navigationTransitions.transitionAbortWithErrorSubject.next(a)}});this.eventsSubscription.add(e)}resetRootComponentType(e){this.routerState.root.component=e,this.navigationTransitions.rootComponentType=e}initialNavigation(){this.setUpLocationChangeListener(),this.navigationTransitions.hasRequestedNavigation||this.navigateToSyncWithBrowser(this.location.path(!0),Xo,this.stateManager.restoredState(),{replaceUrl:!0})}setUpLocationChangeListener(){this.nonRouterCurrentEntryChangeSubscription??=this.stateManager.registerNonRouterCurrentEntryChangeListener((e,t,a,o)=>{this.navigateToSyncWithBrowser(e,a,t,o)})}navigateToSyncWithBrowser(e,t,a,o){let c=a?.navigationId?a:null,u=a?.\u0275routerUrl??e;if(a?.\u0275routerUrl&&(o=Re(M({},o),{browserUrl:e})),a){let f=M({},a);delete f.navigationId,delete f.\u0275routerPageId,delete f.\u0275routerUrl,Object.keys(f).length!==0&&(o.state=f)}let p=this.parseUrl(u);this.scheduleNavigation(p,t,c,o).catch(f=>{this.disposed||this.injector.get(Io)(f)})}get url(){return this.serializeUrl(this.currentUrlTree)}getCurrentNavigation(){return ke(this.navigationTransitions.currentNavigation)}get lastSuccessfulNavigation(){return this.navigationTransitions.lastSuccessfulNavigation}resetConfig(e){this.config=e.map(Wd),this.navigated=!1}ngOnDestroy(){this.dispose()}dispose(){this._events.unsubscribe(),this.navigationTransitions.complete(),this.nonRouterCurrentEntryChangeSubscription?.unsubscribe(),this.nonRouterCurrentEntryChangeSubscription=void 0,this.disposed=!0,this.eventsSubscription.unsubscribe()}createUrlTree(e,t={}){let{relativeTo:a,queryParams:o,fragment:c,queryParamsHandling:u,preserveFragment:p}=t,f=p?this.currentUrlTree.fragment:c,b=null;switch(u??this.options.defaultQueryParamsHandling){case"merge":b=M(M({},this.currentUrlTree.queryParams),o);break;case"preserve":b=this.currentUrlTree.queryParams;break;default:b=o||null}b!==null&&(b=this.removeEmptyProps(b));let w;try{let L=a?a.snapshot:this.routerState.snapshot.root;w=xh(L)}catch(L){(typeof e[0]!="string"||e[0][0]!=="/")&&(e=[]),w=this.currentUrlTree.root}return Ch(w,e,b,f??null,this.urlSerializer)}navigateByUrl(e,t={skipLocationChange:!1}){let a=yi(e)?e:this.parseUrl(e),o=this.urlHandlingStrategy.merge(a,this.rawUrlTree);return this.scheduleNavigation(o,Xo,null,t)}navigate(e,t={skipLocationChange:!1}){return xy(e),this.navigateByUrl(this.createUrlTree(e,t),t)}serializeUrl(e){return this.urlSerializer.serialize(e)}parseUrl(e){try{return this.urlSerializer.parse(e)}catch(t){return this.console.warn(Mo(4018,!1)),this.urlSerializer.parse("/")}}isActive(e,t){let a;if(t===!0?a=M({},Ud):t===!1?a=M({},Zo):a=M(M({},Zo),t),yi(e))return Id(this.currentUrlTree,e,a);let o=this.parseUrl(e);return Id(this.currentUrlTree,o,a)}removeEmptyProps(e){return Object.entries(e).reduce((t,[a,o])=>(o!=null&&(t[a]=o),t),{})}scheduleNavigation(e,t,a,o,c){if(this.disposed)return Promise.resolve(!1);let u,p,f;c?(u=c.resolve,p=c.reject,f=c.promise):f=new Promise((w,L)=>{u=w,p=L});let b=this.pendingTasks.add();return Yd(this,()=>{queueMicrotask(()=>this.pendingTasks.remove(b))}),this.navigationTransitions.handleNavigationRequest({source:t,restoredState:a,currentUrlTree:this.currentUrlTree,currentRawUrl:this.currentUrlTree,rawUrl:e,extras:o,resolve:u,reject:p,promise:f,currentSnapshot:this.routerState.snapshot,currentRouterState:this.routerState}),f.catch(Promise.reject.bind(Promise))}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();function xy(n){for(let i=0;i<n.length;i++)if(n[i]==null)throw new oe(4008,!1)}var wy=(()=>{class n{router=m(We);stateManager=m(Xs);fragment=le("");queryParams=le({});path=le("");serializer=m(Ua);constructor(){this.updateState(),this.router.events?.subscribe(e=>{e instanceof bn&&this.updateState()})}updateState(){let{fragment:e,root:t,queryParams:a}=this.stateManager.getCurrentUrlTree();this.fragment.set(e),this.queryParams.set(a),this.path.set(this.serializer.serialize(new zt(t)))}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),qa=(()=>{class n{router;route;tabIndexAttribute;renderer;el;locationStrategy;hrefAttributeValue=m(new xt("href"),{optional:!0});reactiveHref=sp(()=>this.isAnchorElement?this.computeHref(this._urlTree()):this.hrefAttributeValue);get href(){return ke(this.reactiveHref)}set href(e){this.reactiveHref.set(e)}set target(e){this._target.set(e)}get target(){return ke(this._target)}_target=le(void 0);set queryParams(e){this._queryParams.set(e)}get queryParams(){return ke(this._queryParams)}_queryParams=le(void 0,{equal:()=>!1});set fragment(e){this._fragment.set(e)}get fragment(){return ke(this._fragment)}_fragment=le(void 0);set queryParamsHandling(e){this._queryParamsHandling.set(e)}get queryParamsHandling(){return ke(this._queryParamsHandling)}_queryParamsHandling=le(void 0);set state(e){this._state.set(e)}get state(){return ke(this._state)}_state=le(void 0,{equal:()=>!1});set info(e){this._info.set(e)}get info(){return ke(this._info)}_info=le(void 0,{equal:()=>!1});set relativeTo(e){this._relativeTo.set(e)}get relativeTo(){return ke(this._relativeTo)}_relativeTo=le(void 0);set preserveFragment(e){this._preserveFragment.set(e)}get preserveFragment(){return ke(this._preserveFragment)}_preserveFragment=le(!1);set skipLocationChange(e){this._skipLocationChange.set(e)}get skipLocationChange(){return ke(this._skipLocationChange)}_skipLocationChange=le(!1);set replaceUrl(e){this._replaceUrl.set(e)}get replaceUrl(){return ke(this._replaceUrl)}_replaceUrl=le(!1);isAnchorElement;onChanges=new F;applicationErrorHandler=m(Io);options=m(Ga,{optional:!0});reactiveRouterState=m(wy);constructor(e,t,a,o,c,u){this.router=e,this.route=t,this.tabIndexAttribute=a,this.renderer=o,this.el=c,this.locationStrategy=u;let p=c.nativeElement.tagName?.toLowerCase();this.isAnchorElement=p==="a"||p==="area"||!!(typeof customElements=="object"&&customElements.get(p)?.observedAttributes?.includes?.("href"))}setTabIndexIfNotOnNativeEl(e){this.tabIndexAttribute!=null||this.isAnchorElement||this.applyAttributeValue("tabindex",e)}ngOnChanges(e){this.onChanges.next(this)}routerLinkInput=le(null);set routerLink(e){e==null?(this.routerLinkInput.set(null),this.setTabIndexIfNotOnNativeEl(null)):(yi(e)?this.routerLinkInput.set(e):this.routerLinkInput.set(Array.isArray(e)?e:[e]),this.setTabIndexIfNotOnNativeEl("0"))}onClick(e,t,a,o,c){let u=this._urlTree();if(u===null||this.isAnchorElement&&(e!==0||t||a||o||c||typeof this.target=="string"&&this.target!="_self"))return!0;let p={skipLocationChange:this.skipLocationChange,replaceUrl:this.replaceUrl,state:this.state,info:this.info};return this.router.navigateByUrl(u,p)?.catch(f=>{this.applicationErrorHandler(f)}),!this.isAnchorElement}ngOnDestroy(){}applyAttributeValue(e,t){let a=this.renderer,o=this.el.nativeElement;t!==null?a.setAttribute(o,e,t):a.removeAttribute(o,e)}_urlTree=Vt(()=>{this.reactiveRouterState.path(),this._preserveFragment()&&this.reactiveRouterState.fragment();let e=a=>a==="preserve"||a==="merge";(e(this._queryParamsHandling())||e(this.options?.defaultQueryParamsHandling))&&this.reactiveRouterState.queryParams();let t=this.routerLinkInput();return t===null||!this.router.createUrlTree?null:yi(t)?t:this.router.createUrlTree(t,{relativeTo:this._relativeTo()!==void 0?this._relativeTo():this.route,queryParams:this._queryParams(),fragment:this._fragment(),queryParamsHandling:this._queryParamsHandling(),preserveFragment:this._preserveFragment()})},{equal:(e,t)=>this.computeHref(e)===this.computeHref(t)});get urlTree(){return ke(this._urlTree)}computeHref(e){return e!==null&&this.locationStrategy?this.locationStrategy?.prepareExternalUrl(this.router.serializeUrl(e))??"":null}static \u0275fac=function(t){return new(t||n)(S(We),S(Ct),Ul("tabindex"),S(Se),S(B),S(Ra))};static \u0275dir=I({type:n,selectors:[["","routerLink",""]],hostVars:2,hostBindings:function(t,a){t&1&&_("click",function(c){return a.onClick(c.button,c.ctrlKey,c.shiftKey,c.altKey,c.metaKey)}),t&2&&Y("href",a.reactiveHref(),Qm)("target",a._target())},inputs:{target:"target",queryParams:"queryParams",fragment:"fragment",queryParamsHandling:"queryParamsHandling",state:"state",info:"info",relativeTo:"relativeTo",preserveFragment:[2,"preserveFragment","preserveFragment",R],skipLocationChange:[2,"skipLocationChange","skipLocationChange",R],replaceUrl:[2,"replaceUrl","replaceUrl",R],routerLink:"routerLink"},features:[we]})}return n})(),Xd=(()=>{class n{router;element;renderer;cdr;links;classes=[];routerEventsSubscription;linkInputChangesSubscription;_isActive=!1;get isActive(){return this._isActive}routerLinkActiveOptions={exact:!1};ariaCurrentWhenActive;isActiveChange=new z;link=m(qa,{optional:!0});constructor(e,t,a,o){this.router=e,this.element=t,this.renderer=a,this.cdr=o,this.routerEventsSubscription=e.events.subscribe(c=>{c instanceof bn&&this.update()})}ngAfterContentInit(){K(this.links.changes,K(null)).pipe(Bl()).subscribe(e=>{this.update(),this.subscribeToEachLinkOnChanges()})}subscribeToEachLinkOnChanges(){this.linkInputChangesSubscription?.unsubscribe();let e=[...this.links.toArray(),this.link].filter(t=>!!t).map(t=>t.onChanges);this.linkInputChangesSubscription=Lt(e).pipe(Bl()).subscribe(t=>{this._isActive!==this.isLinkActive(this.router)(t)&&this.update()})}set routerLinkActive(e){let t=Array.isArray(e)?e:e.split(" ");this.classes=t.filter(a=>!!a)}ngOnChanges(e){this.update()}ngOnDestroy(){this.routerEventsSubscription.unsubscribe(),this.linkInputChangesSubscription?.unsubscribe()}update(){!this.links||!this.router.navigated||queueMicrotask(()=>{let e=this.hasActiveLinks();this.classes.forEach(t=>{e?this.renderer.addClass(this.element.nativeElement,t):this.renderer.removeClass(this.element.nativeElement,t)}),e&&this.ariaCurrentWhenActive!==void 0?this.renderer.setAttribute(this.element.nativeElement,"aria-current",this.ariaCurrentWhenActive.toString()):this.renderer.removeAttribute(this.element.nativeElement,"aria-current"),this._isActive!==e&&(this._isActive=e,this.cdr.markForCheck(),this.isActiveChange.emit(e))})}isLinkActive(e){let t=Dy(this.routerLinkActiveOptions)?this.routerLinkActiveOptions:this.routerLinkActiveOptions.exact??!1?M({},Ud):M({},Zo);return a=>{let o=a.urlTree;return o?ke(Hd(o,e,t)):!1}}hasActiveLinks(){let e=this.isLinkActive(this.router);return this.link&&e(this.link)||this.links.some(e)}static \u0275fac=function(t){return new(t||n)(S(We),S(B),S(Se),S(Z))};static \u0275dir=I({type:n,selectors:[["","routerLinkActive",""]],contentQueries:function(t,a,o){if(t&1&&st(o,qa,5),t&2){let c;j(c=V())&&(a.links=c)}},inputs:{routerLinkActiveOptions:"routerLinkActiveOptions",ariaCurrentWhenActive:"ariaCurrentWhenActive",routerLinkActive:"routerLinkActive"},outputs:{isActiveChange:"isActiveChange"},exportAs:["routerLinkActive"],features:[we]})}return n})();function Dy(n){let i=n;return!!(i.paths||i.matrixParams||i.queryParams||i.fragment)}var Ey=new E("");function Kd(n,...i){return Hi([{provide:lr,multi:!0,useValue:n},[],{provide:Ct,useFactory:Sy},{provide:Jm,multi:!0,useFactory:ky},i.map(e=>e.\u0275providers)])}function Sy(){return m(We).routerState.root}function ky(){let n=m(re);return i=>{let e=n.get(Pn);if(i!==e.components[0])return;let t=n.get(We),a=n.get(My);n.get(Iy)===1&&t.initialNavigation(),n.get(Ay,null,{optional:!0})?.setUpPreloading(),n.get(Ey,null,{optional:!0})?.init(),t.resetRootComponentType(e.componentTypes[0]),a.closed||(a.next(),a.complete(),a.unsubscribe())}}var My=new E("",{factory:()=>new F}),Iy=new E("",{factory:()=>1});var Ay=new E("");var Kh="ddp_revision_token",Zh="ddp_revision_nombre",Jh="ddp_revision_rol",ef="ddp_revision_forzar_cambio",Ci=class n{getToken(){return localStorage.getItem(Kh)}getNombre(){return localStorage.getItem(Zh)}getRol(){return localStorage.getItem(Jh)}debeCambiarPassword(){return localStorage.getItem(ef)==="true"}haySesion(){return!!this.getToken()}esAnalistaPrimerContacto(){return this.getRol()==="ANALISTA_PRIMER_CONTACTO"}cerrarSesion(){localStorage.removeItem(Kh),localStorage.removeItem(Zh),localStorage.removeItem(Jh),localStorage.removeItem(ef)}static \u0275fac=function(e){return new(e||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var tf=(n,i)=>{let t=m(Ci).getToken(),a=n.url.includes("/api/primer-contacto")||n.url.includes("/api/denunciado");if(!t||!a)return i(n);let o=n.clone({setHeaders:{Authorization:`Bearer ${t}`}});return i(o)};var Ty="@",Oy=(()=>{class n{doc;delegate;zone;animationType;moduleImpl;_rendererFactoryPromise=null;scheduler=null;injector=m(re);loadingSchedulerFn=m(Py,{optional:!0});_engine;constructor(e,t,a,o,c){this.doc=e,this.delegate=t,this.zone=a,this.animationType=o,this.moduleImpl=c}ngOnDestroy(){this._engine?.flush()}loadImpl(){let e=()=>this.moduleImpl??import("./chunk-KKFFP6FT.js").then(a=>a),t;return this.loadingSchedulerFn?t=this.loadingSchedulerFn(e):t=e(),t.catch(a=>{throw new oe(5300,!1)}).then(({\u0275createEngine:a,\u0275AnimationRendererFactory:o})=>{this._engine=a(this.animationType,this.doc);let c=new o(this.delegate,this._engine,this.zone);return this.delegate=c,c})}createRenderer(e,t){let a=this.delegate.createRenderer(e,t);if(a.\u0275type===0)return a;typeof a.throwOnSyntheticProps=="boolean"&&(a.throwOnSyntheticProps=!1);let o=new Zd(a);return t?.data?.animation&&!this._rendererFactoryPromise&&(this._rendererFactoryPromise=this.loadImpl()),this._rendererFactoryPromise?.then(c=>{let u=c.createRenderer(e,t);o.use(u),this.scheduler??=this.injector.get(Lm,null,{optional:!0}),this.scheduler?.notify(10)}).catch(c=>{o.use(a)}),o}begin(){this.delegate.begin?.()}end(){this.delegate.end?.()}whenRenderingDone(){return this.delegate.whenRenderingDone?.()??Promise.resolve()}componentReplaced(e){this._engine?.flush(),this.delegate.componentReplaced?.(e)}static \u0275fac=function(t){$l()};static \u0275prov=D({token:n,factory:n.\u0275fac})}return n})(),Zd=class{delegate;replay=[];\u0275type=1;constructor(i){this.delegate=i}use(i){if(this.delegate=i,this.replay!==null){for(let e of this.replay)e(i);this.replay=null}}get data(){return this.delegate.data}destroy(){this.replay=null,this.delegate.destroy()}createElement(i,e){return this.delegate.createElement(i,e)}createComment(i){return this.delegate.createComment(i)}createText(i){return this.delegate.createText(i)}get destroyNode(){return this.delegate.destroyNode}appendChild(i,e){this.delegate.appendChild(i,e)}insertBefore(i,e,t,a){this.delegate.insertBefore(i,e,t,a)}removeChild(i,e,t,a){this.delegate.removeChild(i,e,t,a)}selectRootElement(i,e){return this.delegate.selectRootElement(i,e)}parentNode(i){return this.delegate.parentNode(i)}nextSibling(i){return this.delegate.nextSibling(i)}setAttribute(i,e,t,a){this.delegate.setAttribute(i,e,t,a)}removeAttribute(i,e,t){this.delegate.removeAttribute(i,e,t)}addClass(i,e){this.delegate.addClass(i,e)}removeClass(i,e){this.delegate.removeClass(i,e)}setStyle(i,e,t,a){this.delegate.setStyle(i,e,t,a)}removeStyle(i,e,t){this.delegate.removeStyle(i,e,t)}setProperty(i,e,t){this.shouldReplay(e)&&this.replay.push(a=>a.setProperty(i,e,t)),this.delegate.setProperty(i,e,t)}setValue(i,e){this.delegate.setValue(i,e)}listen(i,e,t,a){return this.shouldReplay(e)&&this.replay.push(o=>o.listen(i,e,t,a)),this.delegate.listen(i,e,t,a)}shouldReplay(i){return this.replay!==null&&i.startsWith(Ty)}},Py=new E("");function nf(n="animations"){return Hl("NgAsyncAnimations"),Hi([{provide:vt,useFactory:()=>new Oy(m(X),m(Ho),m(W),n)},{provide:Da,useValue:n==="noop"?"NoopAnimations":"BrowserAnimations"}])}var Ks=class n{constructor(i){this.sesion=i}sesion;get nombreUsuario(){return this.sesion.getNombre()??"Primer Contacto"}cerrarSesion(){this.sesion.cerrarSesion(),window.location.assign("/revision/login")}static \u0275fac=function(e){return new(e||n)(S(Ci))};static \u0275cmp=A({type:n,selectors:[["app-header"]],decls:14,vars:1,consts:[[1,"header"],[1,"brand"],[1,"logo-mark"],[1,"user-area"],[1,"user-name"],[1,"logout-btn",3,"click"]],template:function(e,t){e&1&&(Te(0,"header",0)(1,"div",1)(2,"div",2),l(3,"IPN"),Be(),Te(4,"div")(5,"h1"),l(6,"Defensor\xEDa de los Derechos Polit\xE9cnicos"),Be(),Te(7,"p"),l(8,"M\xF3dulo de Primer Contacto"),Be()()(),Te(9,"div",3)(10,"span",4),l(11),Be(),Te(12,"button",5),os("click",function(){return t.cerrarSesion()}),l(13," Cerrar sesi\xF3n "),Be()()()),e&2&&(d(11),g(t.nombreUsuario))},styles:[".header[_ngcontent-%COMP%]{position:fixed;top:0;left:0;right:0;z-index:1000;height:72px;background:#fff;border-bottom:1px solid var(--borde);display:flex;align-items:center;justify-content:space-between;padding:0 28px}.brand[_ngcontent-%COMP%]{display:flex;align-items:center;gap:14px}.logo-mark[_ngcontent-%COMP%]{width:44px;height:44px;border-radius:10px;background:var(--guinda);color:#fff;display:grid;place-items:center;font-weight:700}.brand[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{margin:0;font-size:18px;color:var(--guinda)}.brand[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:2px 0 0;font-size:13px;color:var(--texto-suave)}.user-area[_ngcontent-%COMP%]{display:flex;align-items:center;gap:16px}.user-name[_ngcontent-%COMP%]{color:var(--texto);font-size:14px}.logout-btn[_ngcontent-%COMP%]{border:none;background:var(--guinda);color:#fff;padding:9px 16px;border-radius:6px;cursor:pointer;font-weight:600}"]})};var Zs=class n{static \u0275fac=function(e){return new(e||n)};static \u0275cmp=A({type:n,selectors:[["app-sidebar"]],decls:8,vars:0,consts:[[1,"sidebar"],["routerLink","/dashboard","routerLinkActive","active"],["routerLink","/bandeja","routerLinkActive","active"],["routerLink","/agenda","routerLinkActive","active"]],template:function(e,t){e&1&&(s(0,"aside",0)(1,"nav")(2,"a",1),l(3,"Inicio"),r(),s(4,"a",2),l(5,"Bandeja de An\xE1lisis"),r(),s(6,"a",3),l(7,"Agenda de Citas"),r()()())},dependencies:[qa,Xd],styles:[".sidebar[_ngcontent-%COMP%]{position:fixed;top:72px;left:0;bottom:40px;width:250px;overflow-y:auto;background:#fff;border-right:1px solid var(--borde);padding:22px 14px;z-index:900}.sidebar[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:6px}.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]{padding:12px 14px;border-radius:8px;color:var(--texto);text-decoration:none;font-weight:500;cursor:pointer}.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover, .sidebar[_ngcontent-%COMP%]   a.active[_ngcontent-%COMP%]{background:var(--guinda-suave);color:var(--guinda)}"]})};var Js=class n{static \u0275fac=function(e){return new(e||n)};static \u0275cmp=A({type:n,selectors:[["app-footer"]],decls:2,vars:0,consts:[[1,"footer"]],template:function(e,t){e&1&&(Te(0,"footer",0),l(1,` \xA9 2026 - Defensor\xEDa de los Derechos Polit\xE9cnicos
`),Be())},styles:[".footer[_ngcontent-%COMP%]{position:fixed;bottom:0;left:0;right:0;z-index:1000;height:40px;background:#3b0a22;color:#fff;display:grid;place-items:center;font-size:12px}"]})};var ec=class n{static \u0275fac=function(e){return new(e||n)};static \u0275cmp=A({type:n,selectors:[["app-main-layout"]],decls:7,vars:0,consts:[[1,"app-shell"],[1,"app-body"],[1,"app-content"]],template:function(e,t){e&1&&(s(0,"div",0),H(1,"app-header"),s(2,"div",1),H(3,"app-sidebar"),s(4,"main",2),H(5,"router-outlet"),r()(),H(6,"app-footer"),r())},dependencies:[na,Ks,Zs,Js],styles:[".app-shell[_ngcontent-%COMP%]{min-height:100vh;display:flex;flex-direction:column;background:#f4f5f7}.app-body[_ngcontent-%COMP%]{flex:1;display:flex;margin-top:72px}.app-content[_ngcontent-%COMP%]{flex:1;margin-left:250px;padding:var(--space-6) var(--space-6) 68px var(--content-gutter);background:#f4f5f7;min-height:calc(100vh - 112px)}"]})};var Fy=new E("cdk-dir-doc",{providedIn:"root",factory:()=>m(X)}),Ny=/^(ar|ckb|dv|he|iw|fa|nqo|ps|sd|ug|ur|yi|.*[-_](Adlm|Arab|Hebr|Nkoo|Rohg|Thaa))(?!.*[-_](Latn|Cyrl)($|-|_))($|-|_)/i;function af(n){let i=n?.toLowerCase()||"";return i==="auto"&&typeof navigator<"u"&&navigator?.language?Ny.test(navigator.language)?"rtl":"ltr":i==="rtl"?"rtl":"ltr"}var Qe=(()=>{class n{get value(){return this.valueSignal()}valueSignal=le("ltr");change=new z;constructor(){let e=m(Fy,{optional:!0});if(e){let t=e.body?e.body.dir:null,a=e.documentElement?e.documentElement.dir:null;this.valueSignal.set(af(t||a||"ltr"))}}ngOnDestroy(){this.change.complete()}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var de=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({})}return n})();var Ly=["*"];var By=new E("MAT_CARD_CONFIG"),jn=(()=>{class n{appearance;constructor(){let e=m(By,{optional:!0});this.appearance=e?.appearance||"raised"}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-card"]],hostAttrs:[1,"mat-mdc-card","mdc-card"],hostVars:8,hostBindings:function(t,a){t&2&&k("mat-mdc-card-outlined",a.appearance==="outlined")("mdc-card--outlined",a.appearance==="outlined")("mat-mdc-card-filled",a.appearance==="filled")("mdc-card--filled",a.appearance==="filled")},inputs:{appearance:"appearance"},exportAs:["matCard"],ngContentSelectors:Ly,decls:1,vars:0,template:function(t,a){t&1&&(ye(),ee(0))},styles:[`.mat-mdc-card {
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  position: relative;
  border-style: solid;
  border-width: 0;
  background-color: var(--mat-card-elevated-container-color, var(--mat-sys-surface-container-low));
  border-color: var(--mat-card-elevated-container-color, var(--mat-sys-surface-container-low));
  border-radius: var(--mat-card-elevated-container-shape, var(--mat-sys-corner-medium));
  box-shadow: var(--mat-card-elevated-container-elevation, var(--mat-sys-level1));
}
.mat-mdc-card::after {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border: solid 1px transparent;
  content: "";
  display: block;
  pointer-events: none;
  box-sizing: border-box;
  border-radius: var(--mat-card-elevated-container-shape, var(--mat-sys-corner-medium));
}

.mat-mdc-card-outlined {
  background-color: var(--mat-card-outlined-container-color, var(--mat-sys-surface));
  border-radius: var(--mat-card-outlined-container-shape, var(--mat-sys-corner-medium));
  border-width: var(--mat-card-outlined-outline-width, 1px);
  border-color: var(--mat-card-outlined-outline-color, var(--mat-sys-outline-variant));
  box-shadow: var(--mat-card-outlined-container-elevation, var(--mat-sys-level0));
}
.mat-mdc-card-outlined::after {
  border: none;
}

.mat-mdc-card-filled {
  background-color: var(--mat-card-filled-container-color, var(--mat-sys-surface-container-highest));
  border-radius: var(--mat-card-filled-container-shape, var(--mat-sys-corner-medium));
  box-shadow: var(--mat-card-filled-container-elevation, var(--mat-sys-level0));
}

.mdc-card__media {
  position: relative;
  box-sizing: border-box;
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
}
.mdc-card__media::before {
  display: block;
  content: "";
}
.mdc-card__media:first-child {
  border-top-left-radius: inherit;
  border-top-right-radius: inherit;
}
.mdc-card__media:last-child {
  border-bottom-left-radius: inherit;
  border-bottom-right-radius: inherit;
}

.mat-mdc-card-actions {
  display: flex;
  flex-direction: row;
  align-items: center;
  box-sizing: border-box;
  min-height: 52px;
  padding: 8px;
}

.mat-mdc-card-title {
  font-family: var(--mat-card-title-text-font, var(--mat-sys-title-large-font));
  line-height: var(--mat-card-title-text-line-height, var(--mat-sys-title-large-line-height));
  font-size: var(--mat-card-title-text-size, var(--mat-sys-title-large-size));
  letter-spacing: var(--mat-card-title-text-tracking, var(--mat-sys-title-large-tracking));
  font-weight: var(--mat-card-title-text-weight, var(--mat-sys-title-large-weight));
}

.mat-mdc-card-subtitle {
  color: var(--mat-card-subtitle-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-card-subtitle-text-font, var(--mat-sys-title-medium-font));
  line-height: var(--mat-card-subtitle-text-line-height, var(--mat-sys-title-medium-line-height));
  font-size: var(--mat-card-subtitle-text-size, var(--mat-sys-title-medium-size));
  letter-spacing: var(--mat-card-subtitle-text-tracking, var(--mat-sys-title-medium-tracking));
  font-weight: var(--mat-card-subtitle-text-weight, var(--mat-sys-title-medium-weight));
}

.mat-mdc-card-title,
.mat-mdc-card-subtitle {
  display: block;
  margin: 0;
}
.mat-mdc-card-avatar ~ .mat-mdc-card-header-text .mat-mdc-card-title,
.mat-mdc-card-avatar ~ .mat-mdc-card-header-text .mat-mdc-card-subtitle {
  padding: 16px 16px 0;
}

.mat-mdc-card-header {
  display: flex;
  padding: 16px 16px 0;
}

.mat-mdc-card-content {
  display: block;
  padding: 0 16px;
}
.mat-mdc-card-content:first-child {
  padding-top: 16px;
}
.mat-mdc-card-content:last-child {
  padding-bottom: 16px;
}

.mat-mdc-card-title-group {
  display: flex;
  justify-content: space-between;
  width: 100%;
}

.mat-mdc-card-avatar {
  height: 40px;
  width: 40px;
  border-radius: 50%;
  flex-shrink: 0;
  margin-bottom: 16px;
  object-fit: cover;
}
.mat-mdc-card-avatar ~ .mat-mdc-card-header-text .mat-mdc-card-subtitle,
.mat-mdc-card-avatar ~ .mat-mdc-card-header-text .mat-mdc-card-title {
  line-height: normal;
}

.mat-mdc-card-sm-image {
  width: 80px;
  height: 80px;
}

.mat-mdc-card-md-image {
  width: 112px;
  height: 112px;
}

.mat-mdc-card-lg-image {
  width: 152px;
  height: 152px;
}

.mat-mdc-card-xl-image {
  width: 240px;
  height: 240px;
}

.mat-mdc-card-subtitle ~ .mat-mdc-card-title,
.mat-mdc-card-title ~ .mat-mdc-card-subtitle,
.mat-mdc-card-header .mat-mdc-card-header-text .mat-mdc-card-title,
.mat-mdc-card-header .mat-mdc-card-header-text .mat-mdc-card-subtitle,
.mat-mdc-card-title-group .mat-mdc-card-title,
.mat-mdc-card-title-group .mat-mdc-card-subtitle {
  padding-top: 0;
}

.mat-mdc-card-content > :last-child:not(.mat-mdc-card-footer) {
  margin-bottom: 0;
}

.mat-mdc-card-actions-align-end {
  justify-content: flex-end;
}
`],encapsulation:2,changeDetection:0})}return n})();var sn=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[de]})}return n})();function ur(n){return n.buttons===0||n.detail===0}function mr(n){let i=n.touches&&n.touches[0]||n.changedTouches&&n.changedTouches[0];return!!i&&i.identifier===-1&&(i.radiusX==null||i.radiusX===1)&&(i.radiusY==null||i.radiusY===1)}var Jd;function of(){if(Jd==null){let n=typeof document<"u"?document.head:null;Jd=!!(n&&(n.createShadowRoot||n.attachShadow))}return Jd}function eu(n){if(of()){let i=n.getRootNode?n.getRootNode():null;if(typeof ShadowRoot<"u"&&ShadowRoot&&i instanceof ShadowRoot)return i}return null}function pr(){let n=typeof document<"u"&&document?document.activeElement:null;for(;n&&n.shadowRoot;){let i=n.shadowRoot.activeElement;if(i===n)break;n=i}return n}function wt(n){return n.composedPath?n.composedPath()[0]:n.target}var tu;try{tu=typeof Intl<"u"&&Intl.v8BreakIterator}catch(n){tu=!1}var be=(()=>{class n{_platformId=m(wa);isBrowser=this._platformId?Np(this._platformId):typeof document=="object"&&!!document;EDGE=this.isBrowser&&/(edge)/i.test(navigator.userAgent);TRIDENT=this.isBrowser&&/(msie|trident)/i.test(navigator.userAgent);BLINK=this.isBrowser&&!!(window.chrome||tu)&&typeof CSS<"u"&&!this.EDGE&&!this.TRIDENT;WEBKIT=this.isBrowser&&/AppleWebKit/i.test(navigator.userAgent)&&!this.BLINK&&!this.EDGE&&!this.TRIDENT;IOS=this.isBrowser&&/iPad|iPhone|iPod/.test(navigator.userAgent)&&!("MSStream"in window);FIREFOX=this.isBrowser&&/(firefox|minefield)/i.test(navigator.userAgent);ANDROID=this.isBrowser&&/android/i.test(navigator.userAgent)&&!this.TRIDENT;SAFARI=this.isBrowser&&/safari/i.test(navigator.userAgent)&&this.WEBKIT;constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var hr;function rf(){if(hr==null&&typeof window<"u")try{window.addEventListener("test",null,Object.defineProperty({},"passive",{get:()=>hr=!0}))}finally{hr=hr||!1}return hr}function Wa(n){return rf()?n:!!n.capture}function vn(n,i=0){return tc(n)?Number(n):arguments.length===2?i:0}function tc(n){return!isNaN(parseFloat(n))&&!isNaN(Number(n))}function Ut(n){return n instanceof B?n.nativeElement:n}var sf=new E("cdk-input-modality-detector-options"),cf={ignoreKeys:[18,17,224,91,16]},lf=650,nu={passive:!0,capture:!0},df=(()=>{class n{_platform=m(be);_listenerCleanups;modalityDetected;modalityChanged;get mostRecentModality(){return this._modality.value}_mostRecentTarget=null;_modality=new et(null);_options;_lastTouchMs=0;_onKeydown=e=>{this._options?.ignoreKeys?.some(t=>t===e.keyCode)||(this._modality.next("keyboard"),this._mostRecentTarget=wt(e))};_onMousedown=e=>{Date.now()-this._lastTouchMs<lf||(this._modality.next(ur(e)?"keyboard":"mouse"),this._mostRecentTarget=wt(e))};_onTouchstart=e=>{if(mr(e)){this._modality.next("keyboard");return}this._lastTouchMs=Date.now(),this._modality.next("touch"),this._mostRecentTarget=wt(e)};constructor(){let e=m(W),t=m(X),a=m(sf,{optional:!0});if(this._options=M(M({},cf),a),this.modalityDetected=this._modality.pipe(Ca(1)),this.modalityChanged=this.modalityDetected.pipe(jl()),this._platform.isBrowser){let o=m(vt).createRenderer(null,null);this._listenerCleanups=e.runOutsideAngular(()=>[o.listen(t,"keydown",this._onKeydown,nu),o.listen(t,"mousedown",this._onMousedown,nu),o.listen(t,"touchstart",this._onTouchstart,nu)])}}ngOnDestroy(){this._modality.complete(),this._listenerCleanups?.forEach(e=>e())}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),fr=(function(n){return n[n.IMMEDIATE=0]="IMMEDIATE",n[n.EVENTUAL=1]="EVENTUAL",n})(fr||{}),uf=new E("cdk-focus-monitor-default-options"),nc=Wa({passive:!0,capture:!0}),Dt=(()=>{class n{_ngZone=m(W);_platform=m(be);_inputModalityDetector=m(df);_origin=null;_lastFocusOrigin=null;_windowFocused=!1;_windowFocusTimeoutId;_originTimeoutId;_originFromTouchInteraction=!1;_elementInfo=new Map;_monitoredElementCount=0;_rootNodeFocusListenerCount=new Map;_detectionMode;_windowFocusListener=()=>{this._windowFocused=!0,this._windowFocusTimeoutId=setTimeout(()=>this._windowFocused=!1)};_document=m(X);_stopInputModalityDetector=new F;constructor(){let e=m(uf,{optional:!0});this._detectionMode=e?.detectionMode||fr.IMMEDIATE}_rootNodeFocusAndBlurListener=e=>{let t=wt(e);for(let a=t;a;a=a.parentElement)e.type==="focus"?this._onFocus(e,a):this._onBlur(e,a)};monitor(e,t=!1){let a=Ut(e);if(!this._platform.isBrowser||a.nodeType!==1)return K();let o=eu(a)||this._document,c=this._elementInfo.get(a);if(c)return t&&(c.checkChildren=!0),c.subject;let u={checkChildren:t,subject:new F,rootNode:o};return this._elementInfo.set(a,u),this._registerGlobalListeners(u),u.subject}stopMonitoring(e){let t=Ut(e),a=this._elementInfo.get(t);a&&(a.subject.complete(),this._setClasses(t),this._elementInfo.delete(t),this._removeGlobalListeners(a))}focusVia(e,t,a){let o=Ut(e),c=this._document.activeElement;o===c?this._getClosestElementsInfo(o).forEach(([u,p])=>this._originChanged(u,t,p)):(this._setOrigin(t),typeof o.focus=="function"&&o.focus(a))}ngOnDestroy(){this._elementInfo.forEach((e,t)=>this.stopMonitoring(t))}_getWindow(){return this._document.defaultView||window}_getFocusOrigin(e){return this._origin?this._originFromTouchInteraction?this._shouldBeAttributedToTouch(e)?"touch":"program":this._origin:this._windowFocused&&this._lastFocusOrigin?this._lastFocusOrigin:e&&this._isLastInteractionFromInputLabel(e)?"mouse":"program"}_shouldBeAttributedToTouch(e){return this._detectionMode===fr.EVENTUAL||!!e?.contains(this._inputModalityDetector._mostRecentTarget)}_setClasses(e,t){e.classList.toggle("cdk-focused",!!t),e.classList.toggle("cdk-touch-focused",t==="touch"),e.classList.toggle("cdk-keyboard-focused",t==="keyboard"),e.classList.toggle("cdk-mouse-focused",t==="mouse"),e.classList.toggle("cdk-program-focused",t==="program")}_setOrigin(e,t=!1){this._ngZone.runOutsideAngular(()=>{if(this._origin=e,this._originFromTouchInteraction=e==="touch"&&t,this._detectionMode===fr.IMMEDIATE){clearTimeout(this._originTimeoutId);let a=this._originFromTouchInteraction?lf:1;this._originTimeoutId=setTimeout(()=>this._origin=null,a)}})}_onFocus(e,t){let a=this._elementInfo.get(t),o=wt(e);!a||!a.checkChildren&&t!==o||this._originChanged(t,this._getFocusOrigin(o),a)}_onBlur(e,t){let a=this._elementInfo.get(t);!a||a.checkChildren&&e.relatedTarget instanceof Node&&t.contains(e.relatedTarget)||(this._setClasses(t),this._emitOrigin(a,null))}_emitOrigin(e,t){e.subject.observers.length&&this._ngZone.run(()=>e.subject.next(t))}_registerGlobalListeners(e){if(!this._platform.isBrowser)return;let t=e.rootNode,a=this._rootNodeFocusListenerCount.get(t)||0;a||this._ngZone.runOutsideAngular(()=>{t.addEventListener("focus",this._rootNodeFocusAndBlurListener,nc),t.addEventListener("blur",this._rootNodeFocusAndBlurListener,nc)}),this._rootNodeFocusListenerCount.set(t,a+1),++this._monitoredElementCount===1&&(this._ngZone.runOutsideAngular(()=>{this._getWindow().addEventListener("focus",this._windowFocusListener)}),this._inputModalityDetector.modalityDetected.pipe(pe(this._stopInputModalityDetector)).subscribe(o=>{this._setOrigin(o,!0)}))}_removeGlobalListeners(e){let t=e.rootNode;if(this._rootNodeFocusListenerCount.has(t)){let a=this._rootNodeFocusListenerCount.get(t);a>1?this._rootNodeFocusListenerCount.set(t,a-1):(t.removeEventListener("focus",this._rootNodeFocusAndBlurListener,nc),t.removeEventListener("blur",this._rootNodeFocusAndBlurListener,nc),this._rootNodeFocusListenerCount.delete(t))}--this._monitoredElementCount||(this._getWindow().removeEventListener("focus",this._windowFocusListener),this._stopInputModalityDetector.next(),clearTimeout(this._windowFocusTimeoutId),clearTimeout(this._originTimeoutId))}_originChanged(e,t,a){this._setClasses(e,t),this._emitOrigin(a,t),this._lastFocusOrigin=t}_getClosestElementsInfo(e){let t=[];return this._elementInfo.forEach((a,o)=>{(o===e||a.checkChildren&&o.contains(e))&&t.push([o,a])}),t}_isLastInteractionFromInputLabel(e){let{_mostRecentTarget:t,mostRecentModality:a}=this._inputModalityDetector;if(a!=="mouse"||!t||t===e||e.nodeName!=="INPUT"&&e.nodeName!=="TEXTAREA"||e.disabled)return!1;let o=e.labels;if(o){for(let c=0;c<o.length;c++)if(o[c].contains(t))return!0}return!1}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),iu=(()=>{class n{_elementRef=m(B);_focusMonitor=m(Dt);_monitorSubscription;_focusOrigin=null;cdkFocusChange=new z;constructor(){}get focusOrigin(){return this._focusOrigin}ngAfterViewInit(){let e=this._elementRef.nativeElement;this._monitorSubscription=this._focusMonitor.monitor(e,e.nodeType===1&&e.hasAttribute("cdkMonitorSubtreeFocus")).subscribe(t=>{this._focusOrigin=t,this.cdkFocusChange.emit(t)})}ngOnDestroy(){this._focusMonitor.stopMonitoring(this._elementRef),this._monitorSubscription?.unsubscribe()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdkMonitorElementFocus",""],["","cdkMonitorSubtreeFocus",""]],outputs:{cdkFocusChange:"cdkFocusChange"},exportAs:["cdkMonitorFocus"]})}return n})();var ic=new WeakMap,Oe=(()=>{class n{_appRef;_injector=m(re);_environmentInjector=m(bt);load(e){let t=this._appRef=this._appRef||this._injector.get(Pn),a=ic.get(t);a||(a={loaders:new Set,refs:[]},ic.set(t,a),t.onDestroy(()=>{ic.get(t)?.refs.forEach(o=>o.destroy()),ic.delete(t)})),a.loaders.has(e)||(a.loaders.add(e),a.refs.push(rs(e,{environmentInjector:this._environmentInjector})))}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var wi=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["ng-component"]],exportAs:["cdkVisuallyHidden"],decls:0,vars:0,template:function(t,a){},styles:[`.cdk-visually-hidden {
  border: 0;
  clip: rect(0 0 0 0);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
  white-space: nowrap;
  outline: 0;
  -webkit-appearance: none;
  -moz-appearance: none;
  left: 0;
}
[dir=rtl] .cdk-visually-hidden {
  left: auto;
  right: 0;
}
`],encapsulation:2,changeDetection:0})}return n})(),ac;function jy(){if(ac===void 0&&(ac=null,typeof window<"u")){let n=window;n.trustedTypes!==void 0&&(ac=n.trustedTypes.createPolicy("angular#components",{createHTML:i=>i}))}return ac}function ia(n){return jy()?.createHTML(n)||n}function mf(n,i,e){let t=e.sanitize(Bt.HTML,i);n.innerHTML=ia(t||"")}function Qa(n){return Array.isArray(n)?n:[n]}var pf=new Set,aa,Ya=(()=>{class n{_platform=m(be);_nonce=m(Ea,{optional:!0});_matchMedia;constructor(){this._matchMedia=this._platform.isBrowser&&window.matchMedia?window.matchMedia.bind(window):zy}matchMedia(e){return(this._platform.WEBKIT||this._platform.BLINK)&&Vy(e,this._nonce),this._matchMedia(e)}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();function Vy(n,i){if(!pf.has(n))try{aa||(aa=document.createElement("style"),i&&aa.setAttribute("nonce",i),aa.setAttribute("type","text/css"),document.head.appendChild(aa)),aa.sheet&&(aa.sheet.insertRule(`@media ${n} {body{ }}`,0),pf.add(n))}catch(e){console.error(e)}}function zy(n){return{matches:n==="all"||n==="",media:n,addListener:()=>{},removeListener:()=>{}}}var gr=(()=>{class n{_mediaMatcher=m(Ya);_zone=m(W);_queries=new Map;_destroySubject=new F;constructor(){}ngOnDestroy(){this._destroySubject.next(),this._destroySubject.complete()}isMatched(e){return hf(Qa(e)).some(a=>this._registerQuery(a).mql.matches)}observe(e){let a=hf(Qa(e)).map(c=>this._registerQuery(c).observable),o=nn(a);return o=Jr(o.pipe(it(1)),o.pipe(Ca(1),On(0))),o.pipe(Q(c=>{let u={matches:!1,breakpoints:{}};return c.forEach(({matches:p,query:f})=>{u.matches=u.matches||p,u.breakpoints[f]=p}),u}))}_registerQuery(e){if(this._queries.has(e))return this._queries.get(e);let t=this._mediaMatcher.matchMedia(e),o={observable:new Ht(c=>{let u=p=>this._zone.run(()=>c.next(p));return t.addListener(u),()=>{t.removeListener(u)}}).pipe(tt(t),Q(({matches:c})=>({query:e,matches:c})),pe(this._destroySubject)),mql:t};return this._queries.set(e,o),o}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();function hf(n){return n.map(i=>i.split(",")).reduce((i,e)=>i.concat(e)).map(i=>i.trim())}function Uy(n){if(n.type==="characterData"&&n.target instanceof Comment)return!0;if(n.type==="childList"){for(let i=0;i<n.addedNodes.length;i++)if(!(n.addedNodes[i]instanceof Comment))return!1;for(let i=0;i<n.removedNodes.length;i++)if(!(n.removedNodes[i]instanceof Comment))return!1;return!0}return!1}var ff=(()=>{class n{create(e){return typeof MutationObserver>"u"?null:new MutationObserver(e)}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),gf=(()=>{class n{_mutationObserverFactory=m(ff);_observedElements=new Map;_ngZone=m(W);constructor(){}ngOnDestroy(){this._observedElements.forEach((e,t)=>this._cleanupObserver(t))}observe(e){let t=Ut(e);return new Ht(a=>{let c=this._observeElement(t).pipe(Q(u=>u.filter(p=>!Uy(p))),Ce(u=>!!u.length)).subscribe(u=>{this._ngZone.run(()=>{a.next(u)})});return()=>{c.unsubscribe(),this._unobserveElement(t)}})}_observeElement(e){return this._ngZone.runOutsideAngular(()=>{if(this._observedElements.has(e))this._observedElements.get(e).count++;else{let t=new F,a=this._mutationObserverFactory.create(o=>t.next(o));a&&a.observe(e,{characterData:!0,childList:!0,subtree:!0}),this._observedElements.set(e,{observer:a,stream:t,count:1})}return this._observedElements.get(e).stream})}_unobserveElement(e){this._observedElements.has(e)&&(this._observedElements.get(e).count--,this._observedElements.get(e).count||this._cleanupObserver(e))}_cleanupObserver(e){if(this._observedElements.has(e)){let{observer:t,stream:a}=this._observedElements.get(e);t&&t.disconnect(),a.complete(),this._observedElements.delete(e)}}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),_f=(()=>{class n{_contentObserver=m(gf);_elementRef=m(B);event=new z;get disabled(){return this._disabled}set disabled(e){this._disabled=e,this._disabled?this._unsubscribe():this._subscribe()}_disabled=!1;get debounce(){return this._debounce}set debounce(e){this._debounce=vn(e),this._subscribe()}_debounce;_currentSubscription=null;constructor(){}ngAfterContentInit(){!this._currentSubscription&&!this.disabled&&this._subscribe()}ngOnDestroy(){this._unsubscribe()}_subscribe(){this._unsubscribe();let e=this._contentObserver.observe(this._elementRef);this._currentSubscription=(this.debounce?e.pipe(On(this.debounce)):e).subscribe(this.event)}_unsubscribe(){this._currentSubscription?.unsubscribe()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdkObserveContent",""]],inputs:{disabled:[2,"cdkObserveContentDisabled","disabled",R],debounce:"debounce"},outputs:{event:"cdkObserveContent"},exportAs:["cdkObserveContent"]})}return n})(),oc=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({providers:[ff]})}return n})();var ru=(()=>{class n{_platform=m(be);constructor(){}isDisabled(e){return e.hasAttribute("disabled")}isVisible(e){return $y(e)&&getComputedStyle(e).visibility==="visible"}isTabbable(e){if(!this._platform.isBrowser)return!1;let t=Hy(Zy(e));if(t&&(bf(t)===-1||!this.isVisible(t)))return!1;let a=e.nodeName.toLowerCase(),o=bf(e);return e.hasAttribute("contenteditable")?o!==-1:a==="iframe"||a==="object"||this._platform.WEBKIT&&this._platform.IOS&&!Xy(e)?!1:a==="audio"?e.hasAttribute("controls")?o!==-1:!1:a==="video"?o===-1?!1:o!==null?!0:this._platform.FIREFOX||e.hasAttribute("controls"):e.tabIndex>=0}isFocusable(e,t){return Ky(e)&&!this.isDisabled(e)&&(t?.ignoreVisibility||this.isVisible(e))}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();function Hy(n){try{return n.frameElement}catch(i){return null}}function $y(n){return!!(n.offsetWidth||n.offsetHeight||typeof n.getClientRects=="function"&&n.getClientRects().length)}function Gy(n){let i=n.nodeName.toLowerCase();return i==="input"||i==="select"||i==="button"||i==="textarea"}function qy(n){return Qy(n)&&n.type=="hidden"}function Wy(n){return Yy(n)&&n.hasAttribute("href")}function Qy(n){return n.nodeName.toLowerCase()=="input"}function Yy(n){return n.nodeName.toLowerCase()=="a"}function xf(n){if(!n.hasAttribute("tabindex")||n.tabIndex===void 0)return!1;let i=n.getAttribute("tabindex");return!!(i&&!isNaN(parseInt(i,10)))}function bf(n){if(!xf(n))return null;let i=parseInt(n.getAttribute("tabindex")||"",10);return isNaN(i)?-1:i}function Xy(n){let i=n.nodeName.toLowerCase(),e=i==="input"&&n.type;return e==="text"||e==="password"||i==="select"||i==="textarea"}function Ky(n){return qy(n)?!1:Gy(n)||Wy(n)||n.hasAttribute("contenteditable")||xf(n)}function Zy(n){return n.ownerDocument&&n.ownerDocument.defaultView||window}var ou=class{_element;_checker;_ngZone;_document;_injector;_startAnchor=null;_endAnchor=null;_hasAttached=!1;startAnchorListener=()=>this.focusLastTabbableElement();endAnchorListener=()=>this.focusFirstTabbableElement();get enabled(){return this._enabled}set enabled(i){this._enabled=i,this._startAnchor&&this._endAnchor&&(this._toggleAnchorTabIndex(i,this._startAnchor),this._toggleAnchorTabIndex(i,this._endAnchor))}_enabled=!0;constructor(i,e,t,a,o=!1,c){this._element=i,this._checker=e,this._ngZone=t,this._document=a,this._injector=c,o||this.attachAnchors()}destroy(){let i=this._startAnchor,e=this._endAnchor;i&&(i.removeEventListener("focus",this.startAnchorListener),i.remove()),e&&(e.removeEventListener("focus",this.endAnchorListener),e.remove()),this._startAnchor=this._endAnchor=null,this._hasAttached=!1}attachAnchors(){return this._hasAttached?!0:(this._ngZone.runOutsideAngular(()=>{this._startAnchor||(this._startAnchor=this._createAnchor(),this._startAnchor.addEventListener("focus",this.startAnchorListener)),this._endAnchor||(this._endAnchor=this._createAnchor(),this._endAnchor.addEventListener("focus",this.endAnchorListener))}),this._element.parentNode&&(this._element.parentNode.insertBefore(this._startAnchor,this._element),this._element.parentNode.insertBefore(this._endAnchor,this._element.nextSibling),this._hasAttached=!0),this._hasAttached)}focusInitialElementWhenReady(i){return new Promise(e=>{this._executeOnStable(()=>e(this.focusInitialElement(i)))})}focusFirstTabbableElementWhenReady(i){return new Promise(e=>{this._executeOnStable(()=>e(this.focusFirstTabbableElement(i)))})}focusLastTabbableElementWhenReady(i){return new Promise(e=>{this._executeOnStable(()=>e(this.focusLastTabbableElement(i)))})}_getRegionBoundary(i){let e=this._element.querySelectorAll(`[cdk-focus-region-${i}], [cdkFocusRegion${i}], [cdk-focus-${i}]`);return i=="start"?e.length?e[0]:this._getFirstTabbableElement(this._element):e.length?e[e.length-1]:this._getLastTabbableElement(this._element)}focusInitialElement(i){let e=this._element.querySelector("[cdk-focus-initial], [cdkFocusInitial]");if(e){if(!this._checker.isFocusable(e)){let t=this._getFirstTabbableElement(e);return t?.focus(i),!!t}return e.focus(i),!0}return this.focusFirstTabbableElement(i)}focusFirstTabbableElement(i){let e=this._getRegionBoundary("start");return e&&e.focus(i),!!e}focusLastTabbableElement(i){let e=this._getRegionBoundary("end");return e&&e.focus(i),!!e}hasAttached(){return this._hasAttached}_getFirstTabbableElement(i){if(this._checker.isFocusable(i)&&this._checker.isTabbable(i))return i;let e=i.children;for(let t=0;t<e.length;t++){let a=e[t].nodeType===this._document.ELEMENT_NODE?this._getFirstTabbableElement(e[t]):null;if(a)return a}return null}_getLastTabbableElement(i){if(this._checker.isFocusable(i)&&this._checker.isTabbable(i))return i;let e=i.children;for(let t=e.length-1;t>=0;t--){let a=e[t].nodeType===this._document.ELEMENT_NODE?this._getLastTabbableElement(e[t]):null;if(a)return a}return null}_createAnchor(){let i=this._document.createElement("div");return this._toggleAnchorTabIndex(this._enabled,i),i.classList.add("cdk-visually-hidden"),i.classList.add("cdk-focus-trap-anchor"),i.setAttribute("aria-hidden","true"),i}_toggleAnchorTabIndex(i,e){i?e.setAttribute("tabindex","0"):e.removeAttribute("tabindex")}toggleAnchors(i){this._startAnchor&&this._endAnchor&&(this._toggleAnchorTabIndex(i,this._startAnchor),this._toggleAnchorTabIndex(i,this._endAnchor))}_executeOnStable(i){this._injector?Pe(i,{injector:this._injector}):setTimeout(i)}},su=(()=>{class n{_checker=m(ru);_ngZone=m(W);_document=m(X);_injector=m(re);constructor(){m(Oe).load(wi)}create(e,t=!1){return new ou(e,this._checker,this._ngZone,this._document,t,this._injector)}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var Cf=new E("liveAnnouncerElement",{providedIn:"root",factory:()=>null}),wf=new E("LIVE_ANNOUNCER_DEFAULT_OPTIONS"),Jy=0,_r=(()=>{class n{_ngZone=m(W);_defaultOptions=m(wf,{optional:!0});_liveElement;_document=m(X);_sanitizer=m(qo);_previousTimeout;_currentPromise;_currentResolve;constructor(){let e=m(Cf,{optional:!0});this._liveElement=e||this._createLiveElement()}announce(e,...t){let a=this._defaultOptions,o,c;return t.length===1&&typeof t[0]=="number"?c=t[0]:[o,c]=t,this.clear(),clearTimeout(this._previousTimeout),o||(o=a&&a.politeness?a.politeness:"polite"),c==null&&a&&(c=a.duration),this._liveElement.setAttribute("aria-live",o),this._liveElement.id&&this._exposeAnnouncerToModals(this._liveElement.id),this._ngZone.runOutsideAngular(()=>(this._currentPromise||(this._currentPromise=new Promise(u=>this._currentResolve=u)),clearTimeout(this._previousTimeout),this._previousTimeout=setTimeout(()=>{!e||typeof e=="string"?this._liveElement.textContent=e:mf(this._liveElement,e,this._sanitizer),typeof c=="number"&&(this._previousTimeout=setTimeout(()=>this.clear(),c)),this._currentResolve?.(),this._currentPromise=this._currentResolve=void 0},100),this._currentPromise))}clear(){this._liveElement&&(this._liveElement.textContent="")}ngOnDestroy(){clearTimeout(this._previousTimeout),this._liveElement?.remove(),this._liveElement=null,this._currentResolve?.(),this._currentPromise=this._currentResolve=void 0}_createLiveElement(){let e="cdk-live-announcer-element",t=this._document.getElementsByClassName(e),a=this._document.createElement("div");for(let o=0;o<t.length;o++)t[o].remove();return a.classList.add(e),a.classList.add("cdk-visually-hidden"),a.setAttribute("aria-atomic","true"),a.setAttribute("aria-live","polite"),a.id=`cdk-live-announcer-${Jy++}`,this._document.body.appendChild(a),a}_exposeAnnouncerToModals(e){let t=this._document.querySelectorAll('body > .cdk-overlay-container [aria-modal="true"]');for(let a=0;a<t.length;a++){let o=t[a],c=o.getAttribute("aria-owns");c?c.indexOf(e)===-1&&o.setAttribute("aria-owns",c+" "+e):o.setAttribute("aria-owns",e)}}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var Di=(function(n){return n[n.NONE=0]="NONE",n[n.BLACK_ON_WHITE=1]="BLACK_ON_WHITE",n[n.WHITE_ON_BLACK=2]="WHITE_ON_BLACK",n})(Di||{}),vf="cdk-high-contrast-black-on-white",yf="cdk-high-contrast-white-on-black",au="cdk-high-contrast-active",Df=(()=>{class n{_platform=m(be);_hasCheckedHighContrastMode=!1;_document=m(X);_breakpointSubscription;constructor(){this._breakpointSubscription=m(gr).observe("(forced-colors: active)").subscribe(()=>{this._hasCheckedHighContrastMode&&(this._hasCheckedHighContrastMode=!1,this._applyBodyHighContrastModeCssClasses())})}getHighContrastMode(){if(!this._platform.isBrowser)return Di.NONE;let e=this._document.createElement("div");e.style.backgroundColor="rgb(1,2,3)",e.style.position="absolute",this._document.body.appendChild(e);let t=this._document.defaultView||window,a=t&&t.getComputedStyle?t.getComputedStyle(e):null,o=(a&&a.backgroundColor||"").replace(/ /g,"");switch(e.remove(),o){case"rgb(0,0,0)":case"rgb(45,50,54)":case"rgb(32,32,32)":return Di.WHITE_ON_BLACK;case"rgb(255,255,255)":case"rgb(255,250,239)":return Di.BLACK_ON_WHITE}return Di.NONE}ngOnDestroy(){this._breakpointSubscription.unsubscribe()}_applyBodyHighContrastModeCssClasses(){if(!this._hasCheckedHighContrastMode&&this._platform.isBrowser&&this._document.body){let e=this._document.body.classList;e.remove(au,vf,yf),this._hasCheckedHighContrastMode=!0;let t=this.getHighContrastMode();t===Di.BLACK_ON_WHITE?e.add(au,vf):t===Di.WHITE_ON_BLACK&&e.add(au,yf)}}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),br=(()=>{class n{constructor(){m(Df)._applyBodyHighContrastModeCssClasses()}static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[oc]})}return n})();var ex=200,rc=class{_letterKeyStream=new F;_items=[];_selectedItemIndex=-1;_pressedLetters=[];_skipPredicateFn;_selectedItem=new F;selectedItem=this._selectedItem;constructor(i,e){let t=typeof e?.debounceInterval=="number"?e.debounceInterval:ex;e?.skipPredicate&&(this._skipPredicateFn=e.skipPredicate),this.setItems(i),this._setupKeyHandler(t)}destroy(){this._pressedLetters=[],this._letterKeyStream.complete(),this._selectedItem.complete()}setCurrentSelectedItemIndex(i){this._selectedItemIndex=i}setItems(i){this._items=i}handleKey(i){let e=i.keyCode;i.key&&i.key.length===1?this._letterKeyStream.next(i.key.toLocaleUpperCase()):(e>=65&&e<=90||e>=48&&e<=57)&&this._letterKeyStream.next(String.fromCharCode(e))}isTyping(){return this._pressedLetters.length>0}reset(){this._pressedLetters=[]}_setupKeyHandler(i){this._letterKeyStream.pipe(_t(e=>this._pressedLetters.push(e)),On(i),Ce(()=>this._pressedLetters.length>0),Q(()=>this._pressedLetters.join("").toLocaleUpperCase())).subscribe(e=>{for(let t=1;t<this._items.length+1;t++){let a=(this._selectedItemIndex+t)%this._items.length,o=this._items[a];if(!this._skipPredicateFn?.(o)&&o.getLabel?.().toLocaleUpperCase().trim().indexOf(e)===0){this._selectedItem.next(o);break}}this._pressedLetters=[]})}};function Ze(n,...i){return i.length?i.some(e=>n[e]):n.altKey||n.shiftKey||n.ctrlKey||n.metaKey}var Xa=class{_items;_activeItemIndex=le(-1);_activeItem=le(null);_wrap=!1;_typeaheadSubscription=Le.EMPTY;_itemChangesSubscription;_vertical=!0;_horizontal=null;_allowedModifierKeys=[];_homeAndEnd=!1;_pageUpAndDown={enabled:!1,delta:10};_effectRef;_typeahead;_skipPredicateFn=i=>i.disabled;constructor(i,e){this._items=i,i instanceof di?this._itemChangesSubscription=i.changes.subscribe(t=>this._itemsChanged(t.toArray())):ui(i)&&(this._effectRef=qi(()=>this._itemsChanged(i()),{injector:e}))}tabOut=new F;change=new F;skipPredicate(i){return this._skipPredicateFn=i,this}withWrap(i=!0){return this._wrap=i,this}withVerticalOrientation(i=!0){return this._vertical=i,this}withHorizontalOrientation(i){return this._horizontal=i,this}withAllowedModifierKeys(i){return this._allowedModifierKeys=i,this}withTypeAhead(i=200){this._typeaheadSubscription.unsubscribe();let e=this._getItemsArray();return this._typeahead=new rc(e,{debounceInterval:typeof i=="number"?i:void 0,skipPredicate:t=>this._skipPredicateFn(t)}),this._typeaheadSubscription=this._typeahead.selectedItem.subscribe(t=>{this.setActiveItem(t)}),this}cancelTypeahead(){return this._typeahead?.reset(),this}withHomeAndEnd(i=!0){return this._homeAndEnd=i,this}withPageUpDown(i=!0,e=10){return this._pageUpAndDown={enabled:i,delta:e},this}setActiveItem(i){let e=this._activeItem();this.updateActiveItem(i),this._activeItem()!==e&&this.change.next(this._activeItemIndex())}onKeydown(i){let e=i.keyCode,a=["altKey","ctrlKey","metaKey","shiftKey"].every(o=>!i[o]||this._allowedModifierKeys.indexOf(o)>-1);switch(e){case 9:this.tabOut.next();return;case 40:if(this._vertical&&a){this.setNextItemActive();break}else return;case 38:if(this._vertical&&a){this.setPreviousItemActive();break}else return;case 39:if(this._horizontal&&a){this._horizontal==="rtl"?this.setPreviousItemActive():this.setNextItemActive();break}else return;case 37:if(this._horizontal&&a){this._horizontal==="rtl"?this.setNextItemActive():this.setPreviousItemActive();break}else return;case 36:if(this._homeAndEnd&&a){this.setFirstItemActive();break}else return;case 35:if(this._homeAndEnd&&a){this.setLastItemActive();break}else return;case 33:if(this._pageUpAndDown.enabled&&a){let o=this._activeItemIndex()-this._pageUpAndDown.delta;this._setActiveItemByIndex(o>0?o:0,1);break}else return;case 34:if(this._pageUpAndDown.enabled&&a){let o=this._activeItemIndex()+this._pageUpAndDown.delta,c=this._getItemsArray().length;this._setActiveItemByIndex(o<c?o:c-1,-1);break}else return;default:(a||Ze(i,"shiftKey"))&&this._typeahead?.handleKey(i);return}this._typeahead?.reset(),i.preventDefault()}get activeItemIndex(){return this._activeItemIndex()}get activeItem(){return this._activeItem()}isTyping(){return!!this._typeahead&&this._typeahead.isTyping()}setFirstItemActive(){this._setActiveItemByIndex(0,1)}setLastItemActive(){this._setActiveItemByIndex(this._getItemsArray().length-1,-1)}setNextItemActive(){this._activeItemIndex()<0?this.setFirstItemActive():this._setActiveItemByDelta(1)}setPreviousItemActive(){this._activeItemIndex()<0&&this._wrap?this.setLastItemActive():this._setActiveItemByDelta(-1)}updateActiveItem(i){let e=this._getItemsArray(),t=typeof i=="number"?i:e.indexOf(i),a=e[t];this._activeItem.set(a??null),this._activeItemIndex.set(t),this._typeahead?.setCurrentSelectedItemIndex(t)}destroy(){this._typeaheadSubscription.unsubscribe(),this._itemChangesSubscription?.unsubscribe(),this._effectRef?.destroy(),this._typeahead?.destroy(),this.tabOut.complete(),this.change.complete()}_setActiveItemByDelta(i){this._wrap?this._setActiveInWrapMode(i):this._setActiveInDefaultMode(i)}_setActiveInWrapMode(i){let e=this._getItemsArray();for(let t=1;t<=e.length;t++){let a=(this._activeItemIndex()+i*t+e.length)%e.length,o=e[a];if(!this._skipPredicateFn(o)){this.setActiveItem(a);return}}}_setActiveInDefaultMode(i){this._setActiveItemByIndex(this._activeItemIndex()+i,i)}_setActiveItemByIndex(i,e){let t=this._getItemsArray();if(t[i]){for(;this._skipPredicateFn(t[i]);)if(i+=e,!t[i])return;this.setActiveItem(i)}}_getItemsArray(){return ui(this._items)?this._items():this._items instanceof di?this._items.toArray():this._items}_itemsChanged(i){this._typeahead?.setItems(i);let e=this._activeItem();if(e){let t=i.indexOf(e);t>-1&&t!==this._activeItemIndex()&&(this._activeItemIndex.set(t),this._typeahead?.setCurrentSelectedItemIndex(t))}}};var xr=class extends Xa{setActiveItem(i){this.activeItem&&this.activeItem.setInactiveStyles(),super.setActiveItem(i),this.activeItem&&this.activeItem.setActiveStyles()}};var Ei=class extends Xa{_origin="program";setFocusOrigin(i){return this._origin=i,this}setActiveItem(i){super.setActiveItem(i),this.activeItem&&this.activeItem.focus(this._origin)}};var cu={},xe=class n{_appId=m(Wi);static _infix=`a${Math.floor(Math.random()*1e5).toString()}`;getId(i,e=!1){return this._appId!=="ng"&&(i+=this._appId),cu.hasOwnProperty(i)||(cu[i]=0),`${i}${e?n._infix+"-":""}${cu[i]++}`}static \u0275fac=function(e){return new(e||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var kf=" ";function uu(n,i,e){let t=dc(n,i);e=e.trim(),!t.some(a=>a.trim()===e)&&(t.push(e),n.setAttribute(i,t.join(kf)))}function uc(n,i,e){let t=dc(n,i);e=e.trim();let a=t.filter(o=>o!==e);a.length?n.setAttribute(i,a.join(kf)):n.removeAttribute(i)}function dc(n,i){return n.getAttribute(i)?.match(/\S+/g)??[]}var Mf="cdk-describedby-message",lc="cdk-describedby-host",du=0,If=(()=>{class n{_platform=m(be);_document=m(X);_messageRegistry=new Map;_messagesContainer=null;_id=`${du++}`;constructor(){m(Oe).load(wi),this._id=m(Wi)+"-"+du++}describe(e,t,a){if(!this._canBeDescribed(e,t))return;let o=lu(t,a);typeof t!="string"?(Sf(t,this._id),this._messageRegistry.set(o,{messageElement:t,referenceCount:0})):this._messageRegistry.has(o)||this._createMessageElement(t,a),this._isElementDescribedByMessage(e,o)||this._addMessageReference(e,o)}removeDescription(e,t,a){if(!t||!this._isElementNode(e))return;let o=lu(t,a);if(this._isElementDescribedByMessage(e,o)&&this._removeMessageReference(e,o),typeof t=="string"){let c=this._messageRegistry.get(o);c&&c.referenceCount===0&&this._deleteMessageElement(o)}this._messagesContainer?.childNodes.length===0&&(this._messagesContainer.remove(),this._messagesContainer=null)}ngOnDestroy(){let e=this._document.querySelectorAll(`[${lc}="${this._id}"]`);for(let t=0;t<e.length;t++)this._removeCdkDescribedByReferenceIds(e[t]),e[t].removeAttribute(lc);this._messagesContainer?.remove(),this._messagesContainer=null,this._messageRegistry.clear()}_createMessageElement(e,t){let a=this._document.createElement("div");Sf(a,this._id),a.textContent=e,t&&a.setAttribute("role",t),this._createMessagesContainer(),this._messagesContainer.appendChild(a),this._messageRegistry.set(lu(e,t),{messageElement:a,referenceCount:0})}_deleteMessageElement(e){this._messageRegistry.get(e)?.messageElement?.remove(),this._messageRegistry.delete(e)}_createMessagesContainer(){if(this._messagesContainer)return;let e="cdk-describedby-message-container",t=this._document.querySelectorAll(`.${e}[platform="server"]`);for(let o=0;o<t.length;o++)t[o].remove();let a=this._document.createElement("div");a.style.visibility="hidden",a.classList.add(e),a.classList.add("cdk-visually-hidden"),this._platform.isBrowser||a.setAttribute("platform","server"),this._document.body.appendChild(a),this._messagesContainer=a}_removeCdkDescribedByReferenceIds(e){let t=dc(e,"aria-describedby").filter(a=>a.indexOf(Mf)!=0);e.setAttribute("aria-describedby",t.join(" "))}_addMessageReference(e,t){let a=this._messageRegistry.get(t);uu(e,"aria-describedby",a.messageElement.id),e.setAttribute(lc,this._id),a.referenceCount++}_removeMessageReference(e,t){let a=this._messageRegistry.get(t);a.referenceCount--,uc(e,"aria-describedby",a.messageElement.id),e.removeAttribute(lc)}_isElementDescribedByMessage(e,t){let a=dc(e,"aria-describedby"),o=this._messageRegistry.get(t),c=o&&o.messageElement.id;return!!c&&a.indexOf(c)!=-1}_canBeDescribed(e,t){if(!this._isElementNode(e))return!1;if(t&&typeof t=="object")return!0;let a=t==null?"":`${t}`.trim(),o=e.getAttribute("aria-label");return a?!o||o.trim()!==a:!1}_isElementNode(e){return e.nodeType===this._document.ELEMENT_NODE}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();function lu(n,i){return typeof n=="string"?`${i||""}/${n}`:n}function Sf(n,i){n.id||(n.id=`${Mf}-${i}-${du++}`)}var yn=(function(n){return n[n.NORMAL=0]="NORMAL",n[n.NEGATED=1]="NEGATED",n[n.INVERTED=2]="INVERTED",n})(yn||{}),mc,oa;function pc(){if(oa==null){if(typeof document!="object"||!document||typeof Element!="function"||!Element)return oa=!1,oa;if(document.documentElement?.style&&"scrollBehavior"in document.documentElement.style)oa=!0;else{let n=Element.prototype.scrollTo;n?oa=!/\{\s*\[native code\]\s*\}/.test(n.toString()):oa=!1}}return oa}function Ka(){if(typeof document!="object"||!document)return yn.NORMAL;if(mc==null){let n=document.createElement("div"),i=n.style;n.dir="rtl",i.width="1px",i.overflow="auto",i.visibility="hidden",i.pointerEvents="none",i.position="absolute";let e=document.createElement("div"),t=e.style;t.width="2px",t.height="1px",n.appendChild(e),document.body.appendChild(n),mc=yn.NORMAL,n.scrollLeft===0&&(n.scrollLeft=1,mc=n.scrollLeft===0?yn.NEGATED:yn.INVERTED),n.remove()}return mc}function mu(){return typeof __karma__<"u"&&!!__karma__||typeof jasmine<"u"&&!!jasmine||typeof jest<"u"&&!!jest||typeof Mocha<"u"&&!!Mocha}var Za,Af=["color","button","checkbox","date","datetime-local","email","file","hidden","image","month","number","password","radio","range","reset","search","submit","tel","text","time","url","week"];function pu(){if(Za)return Za;if(typeof document!="object"||!document)return Za=new Set(Af),Za;let n=document.createElement("input");return Za=new Set(Af.filter(i=>(n.setAttribute("type",i),n.type===i))),Za}var Rf={XSmall:"(max-width: 599.98px)",Small:"(min-width: 600px) and (max-width: 959.98px)",Medium:"(min-width: 960px) and (max-width: 1279.98px)",Large:"(min-width: 1280px) and (max-width: 1919.98px)",XLarge:"(min-width: 1920px)",Handset:"(max-width: 599.98px) and (orientation: portrait), (max-width: 959.98px) and (orientation: landscape)",Tablet:"(min-width: 600px) and (max-width: 839.98px) and (orientation: portrait), (min-width: 960px) and (max-width: 1279.98px) and (orientation: landscape)",Web:"(min-width: 840px) and (orientation: portrait), (min-width: 1280px) and (orientation: landscape)",HandsetPortrait:"(max-width: 599.98px) and (orientation: portrait)",TabletPortrait:"(min-width: 600px) and (max-width: 839.98px) and (orientation: portrait)",WebPortrait:"(min-width: 840px) and (orientation: portrait)",HandsetLandscape:"(max-width: 959.98px) and (orientation: landscape)",TabletLandscape:"(min-width: 960px) and (max-width: 1279.98px) and (orientation: landscape)",WebLandscape:"(min-width: 1280px) and (orientation: landscape)"};var tx=new E("MATERIAL_ANIMATIONS"),Tf=null;function hu(){return m(tx,{optional:!0})?.animationsDisabled||m(Da,{optional:!0})==="NoopAnimations"?"di-disabled":(Tf??=m(Ya).matchMedia("(prefers-reduced-motion)").matches,Tf?"reduced-motion":"enabled")}function Ee(){return hu()!=="enabled"}function nt(n){return n==null?"":typeof n=="string"?n:`${n}px`}function ni(n){return n!=null&&`${n}`!="false"}var cn=(function(n){return n[n.FADING_IN=0]="FADING_IN",n[n.VISIBLE=1]="VISIBLE",n[n.FADING_OUT=2]="FADING_OUT",n[n.HIDDEN=3]="HIDDEN",n})(cn||{}),fu=class{_renderer;element;config;_animationForciblyDisabledThroughCss;state=cn.HIDDEN;constructor(i,e,t,a=!1){this._renderer=i,this.element=e,this.config=t,this._animationForciblyDisabledThroughCss=a}fadeOut(){this._renderer.fadeOutRipple(this)}},Of=Wa({passive:!0,capture:!0}),gu=class{_events=new Map;addHandler(i,e,t,a){let o=this._events.get(e);if(o){let c=o.get(t);c?c.add(a):o.set(t,new Set([a]))}else this._events.set(e,new Map([[t,new Set([a])]])),i.runOutsideAngular(()=>{document.addEventListener(e,this._delegateEventHandler,Of)})}removeHandler(i,e,t){let a=this._events.get(i);if(!a)return;let o=a.get(e);o&&(o.delete(t),o.size===0&&a.delete(e),a.size===0&&(this._events.delete(i),document.removeEventListener(i,this._delegateEventHandler,Of)))}_delegateEventHandler=i=>{let e=wt(i);e&&this._events.get(i.type)?.forEach((t,a)=>{(a===e||a.contains(e))&&t.forEach(o=>o.handleEvent(i))})}},Cr={enterDuration:225,exitDuration:150},nx=800,Pf=Wa({passive:!0,capture:!0}),Ff=["mousedown","touchstart"],Nf=["mouseup","mouseleave","touchend","touchcancel"],ix=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["ng-component"]],hostAttrs:["mat-ripple-style-loader",""],decls:0,vars:0,template:function(t,a){},styles:[`.mat-ripple {
  overflow: hidden;
  position: relative;
}
.mat-ripple:not(:empty) {
  transform: translateZ(0);
}

.mat-ripple.mat-ripple-unbounded {
  overflow: visible;
}

.mat-ripple-element {
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
  transition: opacity, transform 0ms cubic-bezier(0, 0, 0.2, 1);
  transform: scale3d(0, 0, 0);
  background-color: var(--mat-ripple-color, color-mix(in srgb, var(--mat-sys-on-surface) 10%, transparent));
}
@media (forced-colors: active) {
  .mat-ripple-element {
    display: none;
  }
}
.cdk-drag-preview .mat-ripple-element, .cdk-drag-placeholder .mat-ripple-element {
  display: none;
}
`],encapsulation:2,changeDetection:0})}return n})(),wr=class n{_target;_ngZone;_platform;_containerElement;_triggerElement=null;_isPointerDown=!1;_activeRipples=new Map;_mostRecentTransientRipple=null;_lastTouchStartEvent;_pointerUpEventsRegistered=!1;_containerRect=null;static _eventManager=new gu;constructor(i,e,t,a,o){this._target=i,this._ngZone=e,this._platform=a,a.isBrowser&&(this._containerElement=Ut(t)),o&&o.get(Oe).load(ix)}fadeInRipple(i,e,t={}){let a=this._containerRect=this._containerRect||this._containerElement.getBoundingClientRect(),o=M(M({},Cr),t.animation);t.centered&&(i=a.left+a.width/2,e=a.top+a.height/2);let c=t.radius||ax(i,e,a),u=i-a.left,p=e-a.top,f=o.enterDuration,b=document.createElement("div");b.classList.add("mat-ripple-element"),b.style.left=`${u-c}px`,b.style.top=`${p-c}px`,b.style.height=`${c*2}px`,b.style.width=`${c*2}px`,t.color!=null&&(b.style.backgroundColor=t.color),b.style.transitionDuration=`${f}ms`,this._containerElement.appendChild(b);let w=window.getComputedStyle(b),L=w.transitionProperty,$=w.transitionDuration,ae=L==="none"||$==="0s"||$==="0s, 0s"||a.width===0&&a.height===0,me=new fu(this,b,t,ae);b.style.transform="scale3d(1, 1, 1)",me.state=cn.FADING_IN,t.persistent||(this._mostRecentTransientRipple=me);let J=null;return!ae&&(f||o.exitDuration)&&this._ngZone.runOutsideAngular(()=>{let se=()=>{J&&(J.fallbackTimer=null),clearTimeout(gt),this._finishRippleTransition(me)},Ie=()=>this._destroyRipple(me),gt=setTimeout(Ie,f+100);b.addEventListener("transitionend",se),b.addEventListener("transitioncancel",Ie),J={onTransitionEnd:se,onTransitionCancel:Ie,fallbackTimer:gt}}),this._activeRipples.set(me,J),(ae||!f)&&this._finishRippleTransition(me),me}fadeOutRipple(i){if(i.state===cn.FADING_OUT||i.state===cn.HIDDEN)return;let e=i.element,t=M(M({},Cr),i.config.animation);e.style.transitionDuration=`${t.exitDuration}ms`,e.style.opacity="0",i.state=cn.FADING_OUT,(i._animationForciblyDisabledThroughCss||!t.exitDuration)&&this._finishRippleTransition(i)}fadeOutAll(){this._getActiveRipples().forEach(i=>i.fadeOut())}fadeOutAllNonPersistent(){this._getActiveRipples().forEach(i=>{i.config.persistent||i.fadeOut()})}setupTriggerEvents(i){let e=Ut(i);!this._platform.isBrowser||!e||e===this._triggerElement||(this._removeTriggerEvents(),this._triggerElement=e,Ff.forEach(t=>{n._eventManager.addHandler(this._ngZone,t,e,this)}))}handleEvent(i){i.type==="mousedown"?this._onMousedown(i):i.type==="touchstart"?this._onTouchStart(i):this._onPointerUp(),this._pointerUpEventsRegistered||(this._ngZone.runOutsideAngular(()=>{Nf.forEach(e=>{this._triggerElement.addEventListener(e,this,Pf)})}),this._pointerUpEventsRegistered=!0)}_finishRippleTransition(i){i.state===cn.FADING_IN?this._startFadeOutTransition(i):i.state===cn.FADING_OUT&&this._destroyRipple(i)}_startFadeOutTransition(i){let e=i===this._mostRecentTransientRipple,{persistent:t}=i.config;i.state=cn.VISIBLE,!t&&(!e||!this._isPointerDown)&&i.fadeOut()}_destroyRipple(i){let e=this._activeRipples.get(i)??null;this._activeRipples.delete(i),this._activeRipples.size||(this._containerRect=null),i===this._mostRecentTransientRipple&&(this._mostRecentTransientRipple=null),i.state=cn.HIDDEN,e!==null&&(i.element.removeEventListener("transitionend",e.onTransitionEnd),i.element.removeEventListener("transitioncancel",e.onTransitionCancel),e.fallbackTimer!==null&&clearTimeout(e.fallbackTimer)),i.element.remove()}_onMousedown(i){let e=ur(i),t=this._lastTouchStartEvent&&Date.now()<this._lastTouchStartEvent+nx;!this._target.rippleDisabled&&!e&&!t&&(this._isPointerDown=!0,this.fadeInRipple(i.clientX,i.clientY,this._target.rippleConfig))}_onTouchStart(i){if(!this._target.rippleDisabled&&!mr(i)){this._lastTouchStartEvent=Date.now(),this._isPointerDown=!0;let e=i.changedTouches;if(e)for(let t=0;t<e.length;t++)this.fadeInRipple(e[t].clientX,e[t].clientY,this._target.rippleConfig)}}_onPointerUp(){this._isPointerDown&&(this._isPointerDown=!1,this._getActiveRipples().forEach(i=>{let e=i.state===cn.VISIBLE||i.config.terminateOnPointerUp&&i.state===cn.FADING_IN;!i.config.persistent&&e&&i.fadeOut()}))}_getActiveRipples(){return Array.from(this._activeRipples.keys())}_removeTriggerEvents(){let i=this._triggerElement;i&&(Ff.forEach(e=>n._eventManager.removeHandler(e,i,this)),this._pointerUpEventsRegistered&&(Nf.forEach(e=>i.removeEventListener(e,this,Pf)),this._pointerUpEventsRegistered=!1))}};function ax(n,i,e){let t=Math.max(Math.abs(n-e.left),Math.abs(n-e.right)),a=Math.max(Math.abs(i-e.top),Math.abs(i-e.bottom));return Math.sqrt(t*t+a*a)}var Ja=new E("mat-ripple-global-options"),xn=(()=>{class n{_elementRef=m(B);_animationsDisabled=Ee();color;unbounded=!1;centered=!1;radius=0;animation;get disabled(){return this._disabled}set disabled(e){e&&this.fadeOutAllNonPersistent(),this._disabled=e,this._setupTriggerEventsIfEnabled()}_disabled=!1;get trigger(){return this._trigger||this._elementRef.nativeElement}set trigger(e){this._trigger=e,this._setupTriggerEventsIfEnabled()}_trigger;_rippleRenderer;_globalOptions;_isInitialized=!1;constructor(){let e=m(W),t=m(be),a=m(Ja,{optional:!0}),o=m(re);this._globalOptions=a||{},this._rippleRenderer=new wr(this,e,this._elementRef,t,o)}ngOnInit(){this._isInitialized=!0,this._setupTriggerEventsIfEnabled()}ngOnDestroy(){this._rippleRenderer._removeTriggerEvents()}fadeOutAll(){this._rippleRenderer.fadeOutAll()}fadeOutAllNonPersistent(){this._rippleRenderer.fadeOutAllNonPersistent()}get rippleConfig(){return{centered:this.centered,radius:this.radius,color:this.color,animation:M(M(M({},this._globalOptions.animation),this._animationsDisabled?{enterDuration:0,exitDuration:0}:{}),this.animation),terminateOnPointerUp:this._globalOptions.terminateOnPointerUp}}get rippleDisabled(){return this.disabled||!!this._globalOptions.disabled}_setupTriggerEventsIfEnabled(){!this.disabled&&this._isInitialized&&this._rippleRenderer.setupTriggerEvents(this.trigger)}launch(e,t=0,a){return typeof e=="number"?this._rippleRenderer.fadeInRipple(e,t,M(M({},this.rippleConfig),a)):this._rippleRenderer.fadeInRipple(0,0,M(M({},this.rippleConfig),e))}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","mat-ripple",""],["","matRipple",""]],hostAttrs:[1,"mat-ripple"],hostVars:2,hostBindings:function(t,a){t&2&&k("mat-ripple-unbounded",a.unbounded)},inputs:{color:[0,"matRippleColor","color"],unbounded:[0,"matRippleUnbounded","unbounded"],centered:[0,"matRippleCentered","centered"],radius:[0,"matRippleRadius","radius"],animation:[0,"matRippleAnimation","animation"],disabled:[0,"matRippleDisabled","disabled"],trigger:[0,"matRippleTrigger","trigger"]},exportAs:["matRipple"]})}return n})();var ox={capture:!0},rx=["focus","mousedown","mouseenter","touchstart"],_u="mat-ripple-loader-uninitialized",bu="mat-ripple-loader-class-name",Lf="mat-ripple-loader-centered",hc="mat-ripple-loader-disabled",fc=(()=>{class n{_document=m(X);_animationsDisabled=Ee();_globalRippleOptions=m(Ja,{optional:!0});_platform=m(be);_ngZone=m(W);_injector=m(re);_eventCleanups;_hosts=new Map;constructor(){let e=m(vt).createRenderer(null,null);this._eventCleanups=this._ngZone.runOutsideAngular(()=>rx.map(t=>e.listen(this._document,t,this._onInteraction,ox)))}ngOnDestroy(){let e=this._hosts.keys();for(let t of e)this.destroyRipple(t);this._eventCleanups.forEach(t=>t())}configureRipple(e,t){e.setAttribute(_u,this._globalRippleOptions?.namespace??""),(t.className||!e.hasAttribute(bu))&&e.setAttribute(bu,t.className||""),t.centered&&e.setAttribute(Lf,""),t.disabled&&e.setAttribute(hc,"")}setDisabled(e,t){let a=this._hosts.get(e);a?(a.target.rippleDisabled=t,!t&&!a.hasSetUpEvents&&(a.hasSetUpEvents=!0,a.renderer.setupTriggerEvents(e))):t?e.setAttribute(hc,""):e.removeAttribute(hc)}_onInteraction=e=>{let t=wt(e);if(t instanceof HTMLElement){let a=t.closest(`[${_u}="${this._globalRippleOptions?.namespace??""}"]`);a&&this._createRipple(a)}};_createRipple(e){if(!this._document||this._hosts.has(e))return;e.querySelector(".mat-ripple")?.remove();let t=this._document.createElement("span");t.classList.add("mat-ripple",e.getAttribute(bu)),e.append(t);let a=this._globalRippleOptions,o=this._animationsDisabled?0:a?.animation?.enterDuration??Cr.enterDuration,c=this._animationsDisabled?0:a?.animation?.exitDuration??Cr.exitDuration,u={rippleDisabled:this._animationsDisabled||a?.disabled||e.hasAttribute(hc),rippleConfig:{centered:e.hasAttribute(Lf),terminateOnPointerUp:a?.terminateOnPointerUp,animation:{enterDuration:o,exitDuration:c}}},p=new wr(u,this._ngZone,t,this._platform,this._injector),f=!u.rippleDisabled;f&&p.setupTriggerEvents(e),this._hosts.set(e,{target:u,renderer:p,hasSetUpEvents:f}),e.removeAttribute(_u)}destroyRipple(e){let t=this._hosts.get(e);t&&(t.renderer._removeTriggerEvents(),this._hosts.delete(e))}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var Et=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["structural-styles"]],decls:0,vars:0,template:function(t,a){},styles:[`.mat-focus-indicator {
  position: relative;
}
.mat-focus-indicator::before {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  box-sizing: border-box;
  pointer-events: none;
  display: var(--mat-focus-indicator-display, none);
  border-width: var(--mat-focus-indicator-border-width, 3px);
  border-style: var(--mat-focus-indicator-border-style, solid);
  border-color: var(--mat-focus-indicator-border-color, transparent);
  border-radius: var(--mat-focus-indicator-border-radius, 4px);
}
.mat-focus-indicator:focus-visible::before {
  content: "";
}

@media (forced-colors: active) {
  html {
    --mat-focus-indicator-display: block;
  }
}
`],encapsulation:2,changeDetection:0})}return n})();var sx=["mat-icon-button",""],cx=["*"],lx=new E("MAT_BUTTON_CONFIG");function Bf(n){return n==null?void 0:lt(n)}var vu=(()=>{class n{_elementRef=m(B);_ngZone=m(W);_animationsDisabled=Ee();_config=m(lx,{optional:!0});_focusMonitor=m(Dt);_cleanupClick;_renderer=m(Se);_rippleLoader=m(fc);_isAnchor;_isFab=!1;color;get disableRipple(){return this._disableRipple}set disableRipple(e){this._disableRipple=e,this._updateRippleDisabled()}_disableRipple=!1;get disabled(){return this._disabled}set disabled(e){this._disabled=e,this._updateRippleDisabled()}_disabled=!1;ariaDisabled;disabledInteractive;tabIndex;set _tabindex(e){this.tabIndex=e}constructor(){m(Oe).load(Et);let e=this._elementRef.nativeElement;this._isAnchor=e.tagName==="A",this.disabledInteractive=this._config?.disabledInteractive??!1,this.color=this._config?.color??null,this._rippleLoader?.configureRipple(e,{className:"mat-mdc-button-ripple"})}ngAfterViewInit(){this._focusMonitor.monitor(this._elementRef,!0),this._isAnchor&&this._setupAsAnchor()}ngOnDestroy(){this._cleanupClick?.(),this._focusMonitor.stopMonitoring(this._elementRef),this._rippleLoader?.destroyRipple(this._elementRef.nativeElement)}focus(e="program",t){e?this._focusMonitor.focusVia(this._elementRef.nativeElement,e,t):this._elementRef.nativeElement.focus(t)}_getAriaDisabled(){return this.ariaDisabled!=null?this.ariaDisabled:this._isAnchor?this.disabled||null:this.disabled&&this.disabledInteractive?!0:null}_getDisabledAttribute(){return this.disabledInteractive||!this.disabled?null:!0}_updateRippleDisabled(){this._rippleLoader?.setDisabled(this._elementRef.nativeElement,this.disableRipple||this.disabled)}_getTabIndex(){return this._isAnchor?this.disabled&&!this.disabledInteractive?-1:this.tabIndex:this.tabIndex}_setupAsAnchor(){this._cleanupClick=this._ngZone.runOutsideAngular(()=>this._renderer.listen(this._elementRef.nativeElement,"click",e=>{this.disabled&&(e.preventDefault(),e.stopImmediatePropagation())}))}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,hostAttrs:[1,"mat-mdc-button-base"],hostVars:13,hostBindings:function(t,a){t&2&&(Y("disabled",a._getDisabledAttribute())("aria-disabled",a._getAriaDisabled())("tabindex",a._getTabIndex()),ve(a.color?"mat-"+a.color:""),k("mat-mdc-button-disabled",a.disabled)("mat-mdc-button-disabled-interactive",a.disabledInteractive)("mat-unthemed",!a.color)("_mat-animation-noopable",a._animationsDisabled))},inputs:{color:"color",disableRipple:[2,"disableRipple","disableRipple",R],disabled:[2,"disabled","disabled",R],ariaDisabled:[2,"aria-disabled","ariaDisabled",R],disabledInteractive:[2,"disabledInteractive","disabledInteractive",R],tabIndex:[2,"tabIndex","tabIndex",Bf],_tabindex:[2,"tabindex","_tabindex",Bf]}})}return n})(),yu=(()=>{class n extends vu{constructor(){super(),this._rippleLoader.configureRipple(this._elementRef.nativeElement,{centered:!0})}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["button","mat-icon-button",""],["a","mat-icon-button",""],["button","matIconButton",""],["a","matIconButton",""]],hostAttrs:[1,"mdc-icon-button","mat-mdc-icon-button"],exportAs:["matButton","matAnchor"],features:[ie],attrs:sx,ngContentSelectors:cx,decls:4,vars:0,consts:[[1,"mat-mdc-button-persistent-ripple","mdc-icon-button__ripple"],[1,"mat-focus-indicator"],[1,"mat-mdc-button-touch-target"]],template:function(t,a){t&1&&(ye(),yt(0,"span",0),ee(1),yt(2,"span",1)(3,"span",2))},styles:[`.mat-mdc-icon-button {
  -webkit-user-select: none;
  user-select: none;
  display: inline-block;
  position: relative;
  box-sizing: border-box;
  border: none;
  outline: none;
  background-color: transparent;
  fill: currentColor;
  text-decoration: none;
  cursor: pointer;
  z-index: 0;
  overflow: visible;
  border-radius: var(--mat-icon-button-container-shape, var(--mat-sys-corner-full, 50%));
  flex-shrink: 0;
  text-align: center;
  width: var(--mat-icon-button-state-layer-size, 40px);
  height: var(--mat-icon-button-state-layer-size, 40px);
  padding: calc(calc(var(--mat-icon-button-state-layer-size, 40px) - var(--mat-icon-button-icon-size, 24px)) / 2);
  font-size: var(--mat-icon-button-icon-size, 24px);
  color: var(--mat-icon-button-icon-color, var(--mat-sys-on-surface-variant));
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-icon-button .mat-mdc-button-ripple,
.mat-mdc-icon-button .mat-mdc-button-persistent-ripple,
.mat-mdc-icon-button .mat-mdc-button-persistent-ripple::before {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
  border-radius: inherit;
}
.mat-mdc-icon-button .mat-mdc-button-ripple {
  overflow: hidden;
}
.mat-mdc-icon-button .mat-mdc-button-persistent-ripple::before {
  content: "";
  opacity: 0;
}
.mat-mdc-icon-button .mdc-button__label,
.mat-mdc-icon-button .mat-icon {
  z-index: 1;
  position: relative;
}
.mat-mdc-icon-button .mat-focus-indicator {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: inherit;
}
.mat-mdc-icon-button:focus-visible > .mat-focus-indicator::before {
  content: "";
  border-radius: inherit;
}
.mat-mdc-icon-button .mat-ripple-element {
  background-color: var(--mat-icon-button-ripple-color, color-mix(in srgb, var(--mat-sys-on-surface-variant) calc(var(--mat-sys-pressed-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-icon-button .mat-mdc-button-persistent-ripple::before {
  background-color: var(--mat-icon-button-state-layer-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-icon-button.mat-mdc-button-disabled .mat-mdc-button-persistent-ripple::before {
  background-color: var(--mat-icon-button-disabled-state-layer-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-icon-button:hover > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-icon-button-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mat-mdc-icon-button.cdk-program-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-icon-button.cdk-keyboard-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-icon-button.mat-mdc-button-disabled-interactive:focus > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-icon-button-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mat-mdc-icon-button:active > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-icon-button-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
}
.mat-mdc-icon-button .mat-mdc-button-touch-target {
  position: absolute;
  top: 50%;
  height: var(--mat-icon-button-touch-target-size, 48px);
  display: var(--mat-icon-button-touch-target-display, block);
  left: 50%;
  width: var(--mat-icon-button-touch-target-size, 48px);
  transform: translate(-50%, -50%);
}
.mat-mdc-icon-button._mat-animation-noopable {
  transition: none !important;
  animation: none !important;
}
.mat-mdc-icon-button[disabled], .mat-mdc-icon-button.mat-mdc-button-disabled {
  cursor: default;
  pointer-events: none;
  color: var(--mat-icon-button-disabled-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-mdc-icon-button.mat-mdc-button-disabled-interactive {
  pointer-events: auto;
}
.mat-mdc-icon-button img,
.mat-mdc-icon-button svg {
  width: var(--mat-icon-button-icon-size, 24px);
  height: var(--mat-icon-button-icon-size, 24px);
  vertical-align: baseline;
}
.mat-mdc-icon-button .mat-mdc-button-persistent-ripple {
  border-radius: var(--mat-icon-button-container-shape, var(--mat-sys-corner-full, 50%));
}
.mat-mdc-icon-button[hidden] {
  display: none;
}
.mat-mdc-icon-button.mat-unthemed:not(.mdc-ripple-upgraded):focus::before, .mat-mdc-icon-button.mat-primary:not(.mdc-ripple-upgraded):focus::before, .mat-mdc-icon-button.mat-accent:not(.mdc-ripple-upgraded):focus::before, .mat-mdc-icon-button.mat-warn:not(.mdc-ripple-upgraded):focus::before {
  background: transparent;
  opacity: 1;
}
`,`@media (forced-colors: active) {
  .mat-mdc-button:not(.mdc-button--outlined),
  .mat-mdc-unelevated-button:not(.mdc-button--outlined),
  .mat-mdc-raised-button:not(.mdc-button--outlined),
  .mat-mdc-outlined-button:not(.mdc-button--outlined),
  .mat-mdc-button-base.mat-tonal-button,
  .mat-mdc-icon-button.mat-mdc-icon-button,
  .mat-mdc-outlined-button .mdc-button__ripple {
    outline: solid 1px;
  }
}
`],encapsulation:2,changeDetection:0})}return n})();var Si=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[de]})}return n})();var dx=["matButton",""],ux=[[["",8,"material-icons",3,"iconPositionEnd",""],["mat-icon",3,"iconPositionEnd",""],["","matButtonIcon","",3,"iconPositionEnd",""]],"*",[["","iconPositionEnd","",8,"material-icons"],["mat-icon","iconPositionEnd",""],["","matButtonIcon","","iconPositionEnd",""]]],mx=[".material-icons:not([iconPositionEnd]), mat-icon:not([iconPositionEnd]), [matButtonIcon]:not([iconPositionEnd])","*",".material-icons[iconPositionEnd], mat-icon[iconPositionEnd], [matButtonIcon][iconPositionEnd]"];var jf=new Map([["text",["mat-mdc-button"]],["filled",["mdc-button--unelevated","mat-mdc-unelevated-button"]],["elevated",["mdc-button--raised","mat-mdc-raised-button"]],["outlined",["mdc-button--outlined","mat-mdc-outlined-button"]],["tonal",["mat-tonal-button"]]]),Je=(()=>{class n extends vu{get appearance(){return this._appearance}set appearance(e){this.setAppearance(e||this._config?.defaultAppearance||"text")}_appearance=null;constructor(){super();let e=px(this._elementRef.nativeElement);e&&this.setAppearance(e)}setAppearance(e){if(e===this._appearance)return;let t=this._elementRef.nativeElement.classList,a=this._appearance?jf.get(this._appearance):null,o=jf.get(e);a&&t.remove(...a),t.add(...o),this._appearance=e}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["button","matButton",""],["a","matButton",""],["button","mat-button",""],["button","mat-raised-button",""],["button","mat-flat-button",""],["button","mat-stroked-button",""],["a","mat-button",""],["a","mat-raised-button",""],["a","mat-flat-button",""],["a","mat-stroked-button",""]],hostAttrs:[1,"mdc-button"],inputs:{appearance:[0,"matButton","appearance"]},exportAs:["matButton","matAnchor"],features:[ie],attrs:dx,ngContentSelectors:mx,decls:7,vars:4,consts:[[1,"mat-mdc-button-persistent-ripple"],[1,"mdc-button__label"],[1,"mat-focus-indicator"],[1,"mat-mdc-button-touch-target"]],template:function(t,a){t&1&&(ye(ux),yt(0,"span",0),ee(1),Te(2,"span",1),ee(3,1),Be(),ee(4,2),yt(5,"span",2)(6,"span",3)),t&2&&k("mdc-button__ripple",!a._isFab)("mdc-fab__ripple",a._isFab)},styles:[`.mat-mdc-button-base {
  text-decoration: none;
}
.mat-mdc-button-base .mat-icon {
  min-height: fit-content;
  flex-shrink: 0;
}
@media (hover: none) {
  .mat-mdc-button-base:hover > span.mat-mdc-button-persistent-ripple::before {
    opacity: 0;
  }
}

.mdc-button {
  -webkit-user-select: none;
  user-select: none;
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  min-width: 64px;
  border: none;
  outline: none;
  line-height: inherit;
  -webkit-appearance: none;
  overflow: visible;
  vertical-align: middle;
  background: transparent;
  padding: 0 8px;
}
.mdc-button::-moz-focus-inner {
  padding: 0;
  border: 0;
}
.mdc-button:active {
  outline: none;
}
.mdc-button:hover {
  cursor: pointer;
}
.mdc-button:disabled {
  cursor: default;
  pointer-events: none;
}
.mdc-button[hidden] {
  display: none;
}
.mdc-button .mdc-button__label {
  position: relative;
}

.mat-mdc-button {
  padding: 0 var(--mat-button-text-horizontal-padding, 12px);
  height: var(--mat-button-text-container-height, 40px);
  font-family: var(--mat-button-text-label-text-font, var(--mat-sys-label-large-font));
  font-size: var(--mat-button-text-label-text-size, var(--mat-sys-label-large-size));
  letter-spacing: var(--mat-button-text-label-text-tracking, var(--mat-sys-label-large-tracking));
  text-transform: var(--mat-button-text-label-text-transform);
  font-weight: var(--mat-button-text-label-text-weight, var(--mat-sys-label-large-weight));
}
.mat-mdc-button, .mat-mdc-button .mdc-button__ripple {
  border-radius: var(--mat-button-text-container-shape, var(--mat-sys-corner-full));
}
.mat-mdc-button:not(:disabled) {
  color: var(--mat-button-text-label-text-color, var(--mat-sys-primary));
}
.mat-mdc-button[disabled], .mat-mdc-button.mat-mdc-button-disabled {
  cursor: default;
  pointer-events: none;
  color: var(--mat-button-text-disabled-label-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-mdc-button.mat-mdc-button-disabled-interactive {
  pointer-events: auto;
}
.mat-mdc-button:has(.material-icons, mat-icon, [matButtonIcon]) {
  padding: 0 var(--mat-button-text-with-icon-horizontal-padding, 16px);
}
.mat-mdc-button > .mat-icon {
  margin-right: var(--mat-button-text-icon-spacing, 8px);
  margin-left: var(--mat-button-text-icon-offset, -4px);
}
[dir=rtl] .mat-mdc-button > .mat-icon {
  margin-right: var(--mat-button-text-icon-offset, -4px);
  margin-left: var(--mat-button-text-icon-spacing, 8px);
}
.mat-mdc-button .mdc-button__label + .mat-icon {
  margin-right: var(--mat-button-text-icon-offset, -4px);
  margin-left: var(--mat-button-text-icon-spacing, 8px);
}
[dir=rtl] .mat-mdc-button .mdc-button__label + .mat-icon {
  margin-right: var(--mat-button-text-icon-spacing, 8px);
  margin-left: var(--mat-button-text-icon-offset, -4px);
}
.mat-mdc-button .mat-ripple-element {
  background-color: var(--mat-button-text-ripple-color, color-mix(in srgb, var(--mat-sys-primary) calc(var(--mat-sys-pressed-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-button .mat-mdc-button-persistent-ripple::before {
  background-color: var(--mat-button-text-state-layer-color, var(--mat-sys-primary));
}
.mat-mdc-button.mat-mdc-button-disabled .mat-mdc-button-persistent-ripple::before {
  background-color: var(--mat-button-text-disabled-state-layer-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-button:hover > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-text-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mat-mdc-button.cdk-program-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-button.cdk-keyboard-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-button.mat-mdc-button-disabled-interactive:focus > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-text-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mat-mdc-button:active > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-text-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
}
.mat-mdc-button .mat-mdc-button-touch-target {
  position: absolute;
  top: 50%;
  height: var(--mat-button-text-touch-target-size, 48px);
  display: var(--mat-button-text-touch-target-display, block);
  left: 0;
  right: 0;
  transform: translateY(-50%);
}

.mat-mdc-unelevated-button {
  transition: box-shadow 280ms cubic-bezier(0.4, 0, 0.2, 1);
  height: var(--mat-button-filled-container-height, 40px);
  font-family: var(--mat-button-filled-label-text-font, var(--mat-sys-label-large-font));
  font-size: var(--mat-button-filled-label-text-size, var(--mat-sys-label-large-size));
  letter-spacing: var(--mat-button-filled-label-text-tracking, var(--mat-sys-label-large-tracking));
  text-transform: var(--mat-button-filled-label-text-transform);
  font-weight: var(--mat-button-filled-label-text-weight, var(--mat-sys-label-large-weight));
  padding: 0 var(--mat-button-filled-horizontal-padding, 24px);
}
.mat-mdc-unelevated-button > .mat-icon {
  margin-right: var(--mat-button-filled-icon-spacing, 8px);
  margin-left: var(--mat-button-filled-icon-offset, -8px);
}
[dir=rtl] .mat-mdc-unelevated-button > .mat-icon {
  margin-right: var(--mat-button-filled-icon-offset, -8px);
  margin-left: var(--mat-button-filled-icon-spacing, 8px);
}
.mat-mdc-unelevated-button .mdc-button__label + .mat-icon {
  margin-right: var(--mat-button-filled-icon-offset, -8px);
  margin-left: var(--mat-button-filled-icon-spacing, 8px);
}
[dir=rtl] .mat-mdc-unelevated-button .mdc-button__label + .mat-icon {
  margin-right: var(--mat-button-filled-icon-spacing, 8px);
  margin-left: var(--mat-button-filled-icon-offset, -8px);
}
.mat-mdc-unelevated-button .mat-ripple-element {
  background-color: var(--mat-button-filled-ripple-color, color-mix(in srgb, var(--mat-sys-on-primary) calc(var(--mat-sys-pressed-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-unelevated-button .mat-mdc-button-persistent-ripple::before {
  background-color: var(--mat-button-filled-state-layer-color, var(--mat-sys-on-primary));
}
.mat-mdc-unelevated-button.mat-mdc-button-disabled .mat-mdc-button-persistent-ripple::before {
  background-color: var(--mat-button-filled-disabled-state-layer-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-unelevated-button:hover > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-filled-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mat-mdc-unelevated-button.cdk-program-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-unelevated-button.cdk-keyboard-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-unelevated-button.mat-mdc-button-disabled-interactive:focus > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-filled-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mat-mdc-unelevated-button:active > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-filled-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
}
.mat-mdc-unelevated-button .mat-mdc-button-touch-target {
  position: absolute;
  top: 50%;
  height: var(--mat-button-filled-touch-target-size, 48px);
  display: var(--mat-button-filled-touch-target-display, block);
  left: 0;
  right: 0;
  transform: translateY(-50%);
}
.mat-mdc-unelevated-button:not(:disabled) {
  color: var(--mat-button-filled-label-text-color, var(--mat-sys-on-primary));
  background-color: var(--mat-button-filled-container-color, var(--mat-sys-primary));
}
.mat-mdc-unelevated-button, .mat-mdc-unelevated-button .mdc-button__ripple {
  border-radius: var(--mat-button-filled-container-shape, var(--mat-sys-corner-full));
}
.mat-mdc-unelevated-button[disabled], .mat-mdc-unelevated-button.mat-mdc-button-disabled {
  cursor: default;
  pointer-events: none;
  color: var(--mat-button-filled-disabled-label-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  background-color: var(--mat-button-filled-disabled-container-color, color-mix(in srgb, var(--mat-sys-on-surface) 12%, transparent));
}
.mat-mdc-unelevated-button.mat-mdc-button-disabled-interactive {
  pointer-events: auto;
}

.mat-mdc-raised-button {
  transition: box-shadow 280ms cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: var(--mat-button-protected-container-elevation-shadow, var(--mat-sys-level1));
  height: var(--mat-button-protected-container-height, 40px);
  font-family: var(--mat-button-protected-label-text-font, var(--mat-sys-label-large-font));
  font-size: var(--mat-button-protected-label-text-size, var(--mat-sys-label-large-size));
  letter-spacing: var(--mat-button-protected-label-text-tracking, var(--mat-sys-label-large-tracking));
  text-transform: var(--mat-button-protected-label-text-transform);
  font-weight: var(--mat-button-protected-label-text-weight, var(--mat-sys-label-large-weight));
  padding: 0 var(--mat-button-protected-horizontal-padding, 24px);
}
.mat-mdc-raised-button > .mat-icon {
  margin-right: var(--mat-button-protected-icon-spacing, 8px);
  margin-left: var(--mat-button-protected-icon-offset, -8px);
}
[dir=rtl] .mat-mdc-raised-button > .mat-icon {
  margin-right: var(--mat-button-protected-icon-offset, -8px);
  margin-left: var(--mat-button-protected-icon-spacing, 8px);
}
.mat-mdc-raised-button .mdc-button__label + .mat-icon {
  margin-right: var(--mat-button-protected-icon-offset, -8px);
  margin-left: var(--mat-button-protected-icon-spacing, 8px);
}
[dir=rtl] .mat-mdc-raised-button .mdc-button__label + .mat-icon {
  margin-right: var(--mat-button-protected-icon-spacing, 8px);
  margin-left: var(--mat-button-protected-icon-offset, -8px);
}
.mat-mdc-raised-button .mat-ripple-element {
  background-color: var(--mat-button-protected-ripple-color, color-mix(in srgb, var(--mat-sys-primary) calc(var(--mat-sys-pressed-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-raised-button .mat-mdc-button-persistent-ripple::before {
  background-color: var(--mat-button-protected-state-layer-color, var(--mat-sys-primary));
}
.mat-mdc-raised-button.mat-mdc-button-disabled .mat-mdc-button-persistent-ripple::before {
  background-color: var(--mat-button-protected-disabled-state-layer-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-raised-button:hover > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-protected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mat-mdc-raised-button.cdk-program-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-raised-button.cdk-keyboard-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-raised-button.mat-mdc-button-disabled-interactive:focus > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-protected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mat-mdc-raised-button:active > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-protected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
}
.mat-mdc-raised-button .mat-mdc-button-touch-target {
  position: absolute;
  top: 50%;
  height: var(--mat-button-protected-touch-target-size, 48px);
  display: var(--mat-button-protected-touch-target-display, block);
  left: 0;
  right: 0;
  transform: translateY(-50%);
}
.mat-mdc-raised-button:not(:disabled) {
  color: var(--mat-button-protected-label-text-color, var(--mat-sys-primary));
  background-color: var(--mat-button-protected-container-color, var(--mat-sys-surface));
}
.mat-mdc-raised-button, .mat-mdc-raised-button .mdc-button__ripple {
  border-radius: var(--mat-button-protected-container-shape, var(--mat-sys-corner-full));
}
@media (hover: hover) {
  .mat-mdc-raised-button:hover {
    box-shadow: var(--mat-button-protected-hover-container-elevation-shadow, var(--mat-sys-level2));
  }
}
.mat-mdc-raised-button:focus {
  box-shadow: var(--mat-button-protected-focus-container-elevation-shadow, var(--mat-sys-level1));
}
.mat-mdc-raised-button:active, .mat-mdc-raised-button:focus:active {
  box-shadow: var(--mat-button-protected-pressed-container-elevation-shadow, var(--mat-sys-level1));
}
.mat-mdc-raised-button[disabled], .mat-mdc-raised-button.mat-mdc-button-disabled {
  cursor: default;
  pointer-events: none;
  color: var(--mat-button-protected-disabled-label-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  background-color: var(--mat-button-protected-disabled-container-color, color-mix(in srgb, var(--mat-sys-on-surface) 12%, transparent));
}
.mat-mdc-raised-button[disabled].mat-mdc-button-disabled, .mat-mdc-raised-button.mat-mdc-button-disabled.mat-mdc-button-disabled {
  box-shadow: var(--mat-button-protected-disabled-container-elevation-shadow, var(--mat-sys-level0));
}
.mat-mdc-raised-button.mat-mdc-button-disabled-interactive {
  pointer-events: auto;
}

.mat-mdc-outlined-button {
  border-style: solid;
  transition: border 280ms cubic-bezier(0.4, 0, 0.2, 1);
  height: var(--mat-button-outlined-container-height, 40px);
  font-family: var(--mat-button-outlined-label-text-font, var(--mat-sys-label-large-font));
  font-size: var(--mat-button-outlined-label-text-size, var(--mat-sys-label-large-size));
  letter-spacing: var(--mat-button-outlined-label-text-tracking, var(--mat-sys-label-large-tracking));
  text-transform: var(--mat-button-outlined-label-text-transform);
  font-weight: var(--mat-button-outlined-label-text-weight, var(--mat-sys-label-large-weight));
  border-radius: var(--mat-button-outlined-container-shape, var(--mat-sys-corner-full));
  border-width: var(--mat-button-outlined-outline-width, 1px);
  padding: 0 var(--mat-button-outlined-horizontal-padding, 24px);
}
.mat-mdc-outlined-button > .mat-icon {
  margin-right: var(--mat-button-outlined-icon-spacing, 8px);
  margin-left: var(--mat-button-outlined-icon-offset, -8px);
}
[dir=rtl] .mat-mdc-outlined-button > .mat-icon {
  margin-right: var(--mat-button-outlined-icon-offset, -8px);
  margin-left: var(--mat-button-outlined-icon-spacing, 8px);
}
.mat-mdc-outlined-button .mdc-button__label + .mat-icon {
  margin-right: var(--mat-button-outlined-icon-offset, -8px);
  margin-left: var(--mat-button-outlined-icon-spacing, 8px);
}
[dir=rtl] .mat-mdc-outlined-button .mdc-button__label + .mat-icon {
  margin-right: var(--mat-button-outlined-icon-spacing, 8px);
  margin-left: var(--mat-button-outlined-icon-offset, -8px);
}
.mat-mdc-outlined-button .mat-ripple-element {
  background-color: var(--mat-button-outlined-ripple-color, color-mix(in srgb, var(--mat-sys-primary) calc(var(--mat-sys-pressed-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-outlined-button .mat-mdc-button-persistent-ripple::before {
  background-color: var(--mat-button-outlined-state-layer-color, var(--mat-sys-primary));
}
.mat-mdc-outlined-button.mat-mdc-button-disabled .mat-mdc-button-persistent-ripple::before {
  background-color: var(--mat-button-outlined-disabled-state-layer-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-outlined-button:hover > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-outlined-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mat-mdc-outlined-button.cdk-program-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-outlined-button.cdk-keyboard-focused > .mat-mdc-button-persistent-ripple::before, .mat-mdc-outlined-button.mat-mdc-button-disabled-interactive:focus > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-outlined-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mat-mdc-outlined-button:active > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-outlined-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
}
.mat-mdc-outlined-button .mat-mdc-button-touch-target {
  position: absolute;
  top: 50%;
  height: var(--mat-button-outlined-touch-target-size, 48px);
  display: var(--mat-button-outlined-touch-target-display, block);
  left: 0;
  right: 0;
  transform: translateY(-50%);
}
.mat-mdc-outlined-button:not(:disabled) {
  color: var(--mat-button-outlined-label-text-color, var(--mat-sys-primary));
  border-color: var(--mat-button-outlined-outline-color, var(--mat-sys-outline));
}
.mat-mdc-outlined-button[disabled], .mat-mdc-outlined-button.mat-mdc-button-disabled {
  cursor: default;
  pointer-events: none;
  color: var(--mat-button-outlined-disabled-label-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  border-color: var(--mat-button-outlined-disabled-outline-color, color-mix(in srgb, var(--mat-sys-on-surface) 12%, transparent));
}
.mat-mdc-outlined-button.mat-mdc-button-disabled-interactive {
  pointer-events: auto;
}

.mat-tonal-button {
  transition: box-shadow 280ms cubic-bezier(0.4, 0, 0.2, 1);
  height: var(--mat-button-tonal-container-height, 40px);
  font-family: var(--mat-button-tonal-label-text-font, var(--mat-sys-label-large-font));
  font-size: var(--mat-button-tonal-label-text-size, var(--mat-sys-label-large-size));
  letter-spacing: var(--mat-button-tonal-label-text-tracking, var(--mat-sys-label-large-tracking));
  text-transform: var(--mat-button-tonal-label-text-transform);
  font-weight: var(--mat-button-tonal-label-text-weight, var(--mat-sys-label-large-weight));
  padding: 0 var(--mat-button-tonal-horizontal-padding, 24px);
}
.mat-tonal-button:not(:disabled) {
  color: var(--mat-button-tonal-label-text-color, var(--mat-sys-on-secondary-container));
  background-color: var(--mat-button-tonal-container-color, var(--mat-sys-secondary-container));
}
.mat-tonal-button, .mat-tonal-button .mdc-button__ripple {
  border-radius: var(--mat-button-tonal-container-shape, var(--mat-sys-corner-full));
}
.mat-tonal-button[disabled], .mat-tonal-button.mat-mdc-button-disabled {
  cursor: default;
  pointer-events: none;
  color: var(--mat-button-tonal-disabled-label-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  background-color: var(--mat-button-tonal-disabled-container-color, color-mix(in srgb, var(--mat-sys-on-surface) 12%, transparent));
}
.mat-tonal-button.mat-mdc-button-disabled-interactive {
  pointer-events: auto;
}
.mat-tonal-button > .mat-icon {
  margin-right: var(--mat-button-tonal-icon-spacing, 8px);
  margin-left: var(--mat-button-tonal-icon-offset, -8px);
}
[dir=rtl] .mat-tonal-button > .mat-icon {
  margin-right: var(--mat-button-tonal-icon-offset, -8px);
  margin-left: var(--mat-button-tonal-icon-spacing, 8px);
}
.mat-tonal-button .mdc-button__label + .mat-icon {
  margin-right: var(--mat-button-tonal-icon-offset, -8px);
  margin-left: var(--mat-button-tonal-icon-spacing, 8px);
}
[dir=rtl] .mat-tonal-button .mdc-button__label + .mat-icon {
  margin-right: var(--mat-button-tonal-icon-spacing, 8px);
  margin-left: var(--mat-button-tonal-icon-offset, -8px);
}
.mat-tonal-button .mat-ripple-element {
  background-color: var(--mat-button-tonal-ripple-color, color-mix(in srgb, var(--mat-sys-on-secondary-container) calc(var(--mat-sys-pressed-state-layer-opacity) * 100%), transparent));
}
.mat-tonal-button .mat-mdc-button-persistent-ripple::before {
  background-color: var(--mat-button-tonal-state-layer-color, var(--mat-sys-on-secondary-container));
}
.mat-tonal-button.mat-mdc-button-disabled .mat-mdc-button-persistent-ripple::before {
  background-color: var(--mat-button-tonal-disabled-state-layer-color, var(--mat-sys-on-surface-variant));
}
.mat-tonal-button:hover > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-tonal-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mat-tonal-button.cdk-program-focused > .mat-mdc-button-persistent-ripple::before, .mat-tonal-button.cdk-keyboard-focused > .mat-mdc-button-persistent-ripple::before, .mat-tonal-button.mat-mdc-button-disabled-interactive:focus > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-tonal-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mat-tonal-button:active > .mat-mdc-button-persistent-ripple::before {
  opacity: var(--mat-button-tonal-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
}
.mat-tonal-button .mat-mdc-button-touch-target {
  position: absolute;
  top: 50%;
  height: var(--mat-button-tonal-touch-target-size, 48px);
  display: var(--mat-button-tonal-touch-target-display, block);
  left: 0;
  right: 0;
  transform: translateY(-50%);
}

.mat-mdc-button,
.mat-mdc-unelevated-button,
.mat-mdc-raised-button,
.mat-mdc-outlined-button,
.mat-tonal-button {
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-button .mat-mdc-button-ripple,
.mat-mdc-button .mat-mdc-button-persistent-ripple,
.mat-mdc-button .mat-mdc-button-persistent-ripple::before,
.mat-mdc-unelevated-button .mat-mdc-button-ripple,
.mat-mdc-unelevated-button .mat-mdc-button-persistent-ripple,
.mat-mdc-unelevated-button .mat-mdc-button-persistent-ripple::before,
.mat-mdc-raised-button .mat-mdc-button-ripple,
.mat-mdc-raised-button .mat-mdc-button-persistent-ripple,
.mat-mdc-raised-button .mat-mdc-button-persistent-ripple::before,
.mat-mdc-outlined-button .mat-mdc-button-ripple,
.mat-mdc-outlined-button .mat-mdc-button-persistent-ripple,
.mat-mdc-outlined-button .mat-mdc-button-persistent-ripple::before,
.mat-tonal-button .mat-mdc-button-ripple,
.mat-tonal-button .mat-mdc-button-persistent-ripple,
.mat-tonal-button .mat-mdc-button-persistent-ripple::before {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
  border-radius: inherit;
}
.mat-mdc-button .mat-mdc-button-ripple,
.mat-mdc-unelevated-button .mat-mdc-button-ripple,
.mat-mdc-raised-button .mat-mdc-button-ripple,
.mat-mdc-outlined-button .mat-mdc-button-ripple,
.mat-tonal-button .mat-mdc-button-ripple {
  overflow: hidden;
}
.mat-mdc-button .mat-mdc-button-persistent-ripple::before,
.mat-mdc-unelevated-button .mat-mdc-button-persistent-ripple::before,
.mat-mdc-raised-button .mat-mdc-button-persistent-ripple::before,
.mat-mdc-outlined-button .mat-mdc-button-persistent-ripple::before,
.mat-tonal-button .mat-mdc-button-persistent-ripple::before {
  content: "";
  opacity: 0;
}
.mat-mdc-button .mdc-button__label,
.mat-mdc-button .mat-icon,
.mat-mdc-unelevated-button .mdc-button__label,
.mat-mdc-unelevated-button .mat-icon,
.mat-mdc-raised-button .mdc-button__label,
.mat-mdc-raised-button .mat-icon,
.mat-mdc-outlined-button .mdc-button__label,
.mat-mdc-outlined-button .mat-icon,
.mat-tonal-button .mdc-button__label,
.mat-tonal-button .mat-icon {
  z-index: 1;
  position: relative;
}
.mat-mdc-button .mat-focus-indicator,
.mat-mdc-unelevated-button .mat-focus-indicator,
.mat-mdc-raised-button .mat-focus-indicator,
.mat-mdc-outlined-button .mat-focus-indicator,
.mat-tonal-button .mat-focus-indicator {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: inherit;
}
.mat-mdc-button:focus-visible > .mat-focus-indicator::before,
.mat-mdc-unelevated-button:focus-visible > .mat-focus-indicator::before,
.mat-mdc-raised-button:focus-visible > .mat-focus-indicator::before,
.mat-mdc-outlined-button:focus-visible > .mat-focus-indicator::before,
.mat-tonal-button:focus-visible > .mat-focus-indicator::before {
  content: "";
  border-radius: inherit;
}
.mat-mdc-button._mat-animation-noopable,
.mat-mdc-unelevated-button._mat-animation-noopable,
.mat-mdc-raised-button._mat-animation-noopable,
.mat-mdc-outlined-button._mat-animation-noopable,
.mat-tonal-button._mat-animation-noopable {
  transition: none !important;
  animation: none !important;
}
.mat-mdc-button > .mat-icon,
.mat-mdc-unelevated-button > .mat-icon,
.mat-mdc-raised-button > .mat-icon,
.mat-mdc-outlined-button > .mat-icon,
.mat-tonal-button > .mat-icon {
  display: inline-block;
  position: relative;
  vertical-align: top;
  font-size: 1.125rem;
  height: 1.125rem;
  width: 1.125rem;
}

.mat-mdc-outlined-button .mat-mdc-button-ripple,
.mat-mdc-outlined-button .mdc-button__ripple {
  top: -1px;
  left: -1px;
  bottom: -1px;
  right: -1px;
}

.mat-mdc-unelevated-button .mat-focus-indicator::before,
.mat-tonal-button .mat-focus-indicator::before,
.mat-mdc-raised-button .mat-focus-indicator::before {
  margin: calc(calc(var(--mat-focus-indicator-border-width, 3px) + 2px) * -1);
}

.mat-mdc-outlined-button .mat-focus-indicator::before {
  margin: calc(calc(var(--mat-focus-indicator-border-width, 3px) + 3px) * -1);
}
`,`@media (forced-colors: active) {
  .mat-mdc-button:not(.mdc-button--outlined),
  .mat-mdc-unelevated-button:not(.mdc-button--outlined),
  .mat-mdc-raised-button:not(.mdc-button--outlined),
  .mat-mdc-outlined-button:not(.mdc-button--outlined),
  .mat-mdc-button-base.mat-tonal-button,
  .mat-mdc-icon-button.mat-mdc-icon-button,
  .mat-mdc-outlined-button .mdc-button__ripple {
    outline: solid 1px;
  }
}
`],encapsulation:2,changeDetection:0})}return n})();function px(n){return n.hasAttribute("mat-raised-button")?"elevated":n.hasAttribute("mat-stroked-button")?"outlined":n.hasAttribute("mat-flat-button")?"filled":n.hasAttribute("mat-button")?"text":null}var Ge=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[Si,de]})}return n})();function Vf(n){return Error(`Unable to find icon with the name "${n}"`)}function hx(){return Error("Could not find HttpClient for use with Angular Material icons. Please add provideHttpClient() to your providers.")}function zf(n){return Error(`The URL provided to MatIconRegistry was not trusted as a resource URL via Angular's DomSanitizer. Attempted URL was "${n}".`)}function Uf(n){return Error(`The literal provided to MatIconRegistry was not trusted as safe HTML by Angular's DomSanitizer. Attempted literal was "${n}".`)}var ii=class{url;svgText;options;svgElement=null;constructor(i,e,t){this.url=i,this.svgText=e,this.options=t}},$f=(()=>{class n{_httpClient;_sanitizer;_errorHandler;_document;_svgIconConfigs=new Map;_iconSetConfigs=new Map;_cachedIconsByUrl=new Map;_inProgressUrlFetches=new Map;_fontCssClassesByAlias=new Map;_resolvers=[];_defaultFontSetClass=["material-icons","mat-ligature-font"];constructor(e,t,a,o){this._httpClient=e,this._sanitizer=t,this._errorHandler=o,this._document=a}addSvgIcon(e,t,a){return this.addSvgIconInNamespace("",e,t,a)}addSvgIconLiteral(e,t,a){return this.addSvgIconLiteralInNamespace("",e,t,a)}addSvgIconInNamespace(e,t,a,o){return this._addSvgIconConfig(e,t,new ii(a,null,o))}addSvgIconResolver(e){return this._resolvers.push(e),this}addSvgIconLiteralInNamespace(e,t,a,o){let c=this._sanitizer.sanitize(Bt.HTML,a);if(!c)throw Uf(a);let u=ia(c);return this._addSvgIconConfig(e,t,new ii("",u,o))}addSvgIconSet(e,t){return this.addSvgIconSetInNamespace("",e,t)}addSvgIconSetLiteral(e,t){return this.addSvgIconSetLiteralInNamespace("",e,t)}addSvgIconSetInNamespace(e,t,a){return this._addSvgIconSetConfig(e,new ii(t,null,a))}addSvgIconSetLiteralInNamespace(e,t,a){let o=this._sanitizer.sanitize(Bt.HTML,t);if(!o)throw Uf(t);let c=ia(o);return this._addSvgIconSetConfig(e,new ii("",c,a))}registerFontClassAlias(e,t=e){return this._fontCssClassesByAlias.set(e,t),this}classNameForFontAlias(e){return this._fontCssClassesByAlias.get(e)||e}setDefaultFontSetClass(...e){return this._defaultFontSetClass=e,this}getDefaultFontSetClass(){return this._defaultFontSetClass}getSvgIconFromUrl(e){let t=this._sanitizer.sanitize(Bt.RESOURCE_URL,e);if(!t)throw zf(e);let a=this._cachedIconsByUrl.get(t);return a?K(gc(a)):this._loadSvgIconFromConfig(new ii(e,null)).pipe(_t(o=>this._cachedIconsByUrl.set(t,o)),Q(o=>gc(o)))}getNamedSvgIcon(e,t=""){let a=Hf(t,e),o=this._svgIconConfigs.get(a);if(o)return this._getSvgFromConfig(o);if(o=this._getIconConfigFromResolvers(t,e),o)return this._svgIconConfigs.set(a,o),this._getSvgFromConfig(o);let c=this._iconSetConfigs.get(t);return c?this._getSvgFromIconSetConfigs(e,c):Zr(Vf(a))}ngOnDestroy(){this._resolvers=[],this._svgIconConfigs.clear(),this._iconSetConfigs.clear(),this._cachedIconsByUrl.clear()}_getSvgFromConfig(e){return e.svgText?K(gc(this._svgElementFromConfig(e))):this._loadSvgIconFromConfig(e).pipe(Q(t=>gc(t)))}_getSvgFromIconSetConfigs(e,t){let a=this._extractIconWithNameFromAnySet(e,t);if(a)return K(a);let o=t.filter(c=>!c.svgText).map(c=>this._loadSvgIconSetFromConfig(c).pipe(va(u=>{let f=`Loading icon set URL: ${this._sanitizer.sanitize(Bt.RESOURCE_URL,c.url)} failed: ${u.message}`;return this._errorHandler.handleError(new Error(f)),K(null)})));return es(o).pipe(Q(()=>{let c=this._extractIconWithNameFromAnySet(e,t);if(!c)throw Vf(e);return c}))}_extractIconWithNameFromAnySet(e,t){for(let a=t.length-1;a>=0;a--){let o=t[a];if(o.svgText&&o.svgText.toString().indexOf(e)>-1){let c=this._svgElementFromConfig(o),u=this._extractSvgIconFromSet(c,e,o.options);if(u)return u}}return null}_loadSvgIconFromConfig(e){return this._fetchIcon(e).pipe(_t(t=>e.svgText=t),Q(()=>this._svgElementFromConfig(e)))}_loadSvgIconSetFromConfig(e){return e.svgText?K(null):this._fetchIcon(e).pipe(_t(t=>e.svgText=t))}_extractSvgIconFromSet(e,t,a){let o=e.querySelector(`[id="${t}"]`);if(!o)return null;let c=o.cloneNode(!0);if(c.removeAttribute("id"),c.nodeName.toLowerCase()==="svg")return this._setSvgAttributes(c,a);if(c.nodeName.toLowerCase()==="symbol")return this._setSvgAttributes(this._toSvgElement(c),a);let u=this._svgElementFromString(ia("<svg></svg>"));return u.appendChild(c),this._setSvgAttributes(u,a)}_svgElementFromString(e){let t=this._document.createElement("DIV");t.innerHTML=e;let a=t.querySelector("svg");if(!a)throw Error("<svg> tag not found");return a}_toSvgElement(e){let t=this._svgElementFromString(ia("<svg></svg>")),a=e.attributes;for(let o=0;o<a.length;o++){let{name:c,value:u}=a[o];c!=="id"&&t.setAttribute(c,u)}for(let o=0;o<e.childNodes.length;o++)e.childNodes[o].nodeType===this._document.ELEMENT_NODE&&t.appendChild(e.childNodes[o].cloneNode(!0));return t}_setSvgAttributes(e,t){return e.setAttribute("fit",""),e.setAttribute("height","100%"),e.setAttribute("width","100%"),e.setAttribute("preserveAspectRatio","xMidYMid meet"),e.setAttribute("focusable","false"),t&&t.viewBox&&e.setAttribute("viewBox",t.viewBox),e}_fetchIcon(e){let{url:t,options:a}=e,o=a?.withCredentials??!1;if(!this._httpClient)throw hx();if(t==null)throw Error(`Cannot fetch icon from URL "${t}".`);let c=this._sanitizer.sanitize(Bt.RESOURCE_URL,t);if(!c)throw zf(t);let u=this._inProgressUrlFetches.get(c);if(u)return u;let p=this._httpClient.get(c,{responseType:"text",withCredentials:o}).pipe(Q(f=>ia(f)),xa(()=>this._inProgressUrlFetches.delete(c)),Am());return this._inProgressUrlFetches.set(c,p),p}_addSvgIconConfig(e,t,a){return this._svgIconConfigs.set(Hf(e,t),a),this}_addSvgIconSetConfig(e,t){let a=this._iconSetConfigs.get(e);return a?a.push(t):this._iconSetConfigs.set(e,[t]),this}_svgElementFromConfig(e){if(!e.svgElement){let t=this._svgElementFromString(e.svgText);this._setSvgAttributes(t,e.options),e.svgElement=t}return e.svgElement}_getIconConfigFromResolvers(e,t){for(let a=0;a<this._resolvers.length;a++){let o=this._resolvers[a](t,e);if(o)return fx(o)?new ii(o.url,null,o.options):new ii(o,null)}}static \u0275fac=function(t){return new(t||n)(U(_i,8),U(qo),U(X,8),U(Gi))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();function gc(n){return n.cloneNode(!0)}function Hf(n,i){return n+":"+i}function fx(n){return!!(n.url&&n.options)}var gx=["*"],_x=new E("MAT_ICON_DEFAULT_OPTIONS"),bx=new E("mat-icon-location",{providedIn:"root",factory:()=>{let n=m(X),i=n?n.location:null;return{getPathname:()=>i?i.pathname+i.search:""}}}),Gf=["clip-path","color-profile","src","cursor","fill","filter","marker","marker-start","marker-mid","marker-end","mask","stroke"],vx=Gf.map(n=>`[${n}]`).join(", "),yx=/^url\(['"]?#(.*?)['"]?\)$/,Ve=(()=>{class n{_elementRef=m(B);_iconRegistry=m($f);_location=m(bx);_errorHandler=m(Gi);_defaultColor;get color(){return this._color||this._defaultColor}set color(e){this._color=e}_color;inline=!1;get svgIcon(){return this._svgIcon}set svgIcon(e){e!==this._svgIcon&&(e?this._updateSvgIcon(e):this._svgIcon&&this._clearSvgElement(),this._svgIcon=e)}_svgIcon;get fontSet(){return this._fontSet}set fontSet(e){let t=this._cleanupFontValue(e);t!==this._fontSet&&(this._fontSet=t,this._updateFontIconClasses())}_fontSet;get fontIcon(){return this._fontIcon}set fontIcon(e){let t=this._cleanupFontValue(e);t!==this._fontIcon&&(this._fontIcon=t,this._updateFontIconClasses())}_fontIcon;_previousFontSetClass=[];_previousFontIconClass;_svgName=null;_svgNamespace=null;_previousPath;_elementsWithExternalReferences;_currentIconFetch=Le.EMPTY;constructor(){let e=m(new xt("aria-hidden"),{optional:!0}),t=m(_x,{optional:!0});t&&(t.color&&(this.color=this._defaultColor=t.color),t.fontSet&&(this.fontSet=t.fontSet)),e||this._elementRef.nativeElement.setAttribute("aria-hidden","true")}_splitIconName(e){if(!e)return["",""];let t=e.split(":");switch(t.length){case 1:return["",t[0]];case 2:return t;default:throw Error(`Invalid icon name: "${e}"`)}}ngOnInit(){this._updateFontIconClasses()}ngAfterViewChecked(){let e=this._elementsWithExternalReferences;if(e&&e.size){let t=this._location.getPathname();t!==this._previousPath&&(this._previousPath=t,this._prependPathToReferences(t))}}ngOnDestroy(){this._currentIconFetch.unsubscribe(),this._elementsWithExternalReferences&&this._elementsWithExternalReferences.clear()}_usingFontIcon(){return!this.svgIcon}_setSvgElement(e){this._clearSvgElement();let t=this._location.getPathname();this._previousPath=t,this._cacheChildrenWithExternalReferences(e),this._prependPathToReferences(t),this._elementRef.nativeElement.appendChild(e)}_clearSvgElement(){let e=this._elementRef.nativeElement,t=e.childNodes.length;for(this._elementsWithExternalReferences&&this._elementsWithExternalReferences.clear();t--;){let a=e.childNodes[t];(a.nodeType!==1||a.nodeName.toLowerCase()==="svg")&&a.remove()}}_updateFontIconClasses(){if(!this._usingFontIcon())return;let e=this._elementRef.nativeElement,t=(this.fontSet?this._iconRegistry.classNameForFontAlias(this.fontSet).split(/ +/):this._iconRegistry.getDefaultFontSetClass()).filter(a=>a.length>0);this._previousFontSetClass.forEach(a=>e.classList.remove(a)),t.forEach(a=>e.classList.add(a)),this._previousFontSetClass=t,this.fontIcon!==this._previousFontIconClass&&!t.includes("mat-ligature-font")&&(this._previousFontIconClass&&e.classList.remove(this._previousFontIconClass),this.fontIcon&&e.classList.add(this.fontIcon),this._previousFontIconClass=this.fontIcon)}_cleanupFontValue(e){return typeof e=="string"?e.trim().split(" ")[0]:e}_prependPathToReferences(e){let t=this._elementsWithExternalReferences;t&&t.forEach((a,o)=>{a.forEach(c=>{o.setAttribute(c.name,`url('${e}#${c.value}')`)})})}_cacheChildrenWithExternalReferences(e){let t=e.querySelectorAll(vx),a=this._elementsWithExternalReferences=this._elementsWithExternalReferences||new Map;for(let o=0;o<t.length;o++)Gf.forEach(c=>{let u=t[o],p=u.getAttribute(c),f=p?p.match(yx):null;if(f){let b=a.get(u);b||(b=[],a.set(u,b)),b.push({name:c,value:f[1]})}})}_updateSvgIcon(e){if(this._svgNamespace=null,this._svgName=null,this._currentIconFetch.unsubscribe(),e){let[t,a]=this._splitIconName(e);t&&(this._svgNamespace=t),a&&(this._svgName=a),this._currentIconFetch=this._iconRegistry.getNamedSvgIcon(a,t).pipe(it(1)).subscribe(o=>this._setSvgElement(o),o=>{let c=`Error retrieving icon ${t}:${a}! ${o.message}`;this._errorHandler.handleError(new Error(c))})}}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-icon"]],hostAttrs:["role","img",1,"mat-icon","notranslate"],hostVars:10,hostBindings:function(t,a){t&2&&(Y("data-mat-icon-type",a._usingFontIcon()?"font":"svg")("data-mat-icon-name",a._svgName||a.fontIcon)("data-mat-icon-namespace",a._svgNamespace||a.fontSet)("fontIcon",a._usingFontIcon()?a.fontIcon:null),ve(a.color?"mat-"+a.color:""),k("mat-icon-inline",a.inline)("mat-icon-no-color",a.color!=="primary"&&a.color!=="accent"&&a.color!=="warn"))},inputs:{color:"color",inline:[2,"inline","inline",R],svgIcon:"svgIcon",fontSet:"fontSet",fontIcon:"fontIcon"},exportAs:["matIcon"],ngContentSelectors:gx,decls:1,vars:0,template:function(t,a){t&1&&(ye(),ee(0))},styles:[`mat-icon, mat-icon.mat-primary, mat-icon.mat-accent, mat-icon.mat-warn {
  color: var(--mat-icon-color, inherit);
}

.mat-icon {
  -webkit-user-select: none;
  user-select: none;
  background-repeat: no-repeat;
  display: inline-block;
  fill: currentColor;
  height: 24px;
  width: 24px;
  overflow: hidden;
}
.mat-icon.mat-icon-inline {
  font-size: inherit;
  height: inherit;
  line-height: inherit;
  width: inherit;
}
.mat-icon.mat-ligature-font[fontIcon]::before {
  content: attr(fontIcon);
}

[dir=rtl] .mat-icon-rtl-mirror {
  transform: scale(-1, 1);
}

.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-prefix .mat-icon,
.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-suffix .mat-icon {
  display: block;
}
.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-prefix .mat-icon-button .mat-icon,
.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-suffix .mat-icon-button .mat-icon {
  margin: auto;
}
`],encapsulation:2,changeDetection:0})}return n})(),ze=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[de]})}return n})();var eg=(()=>{class n{_renderer;_elementRef;onChange=e=>{};onTouched=()=>{};constructor(e,t){this._renderer=e,this._elementRef=t}setProperty(e,t){this._renderer.setProperty(this._elementRef.nativeElement,e,t)}registerOnTouched(e){this.onTouched=e}registerOnChange(e){this.onChange=e}setDisabledState(e){this.setProperty("disabled",e)}static \u0275fac=function(t){return new(t||n)(S(Se),S(B))};static \u0275dir=I({type:n})}return n})(),Cu=(()=>{class n extends eg{static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,features:[ie]})}return n})(),zn=new E("");var xx={provide:zn,useExisting:It(()=>ft),multi:!0};function Cx(){let n=an()?an().getUserAgent():"";return/android (\d+)/.test(n.toLowerCase())}var wx=new E(""),ft=(()=>{class n extends eg{_compositionMode;_composing=!1;constructor(e,t,a){super(e,t),this._compositionMode=a,this._compositionMode==null&&(this._compositionMode=!Cx())}writeValue(e){let t=e??"";this.setProperty("value",t)}_handleInput(e){(!this._compositionMode||this._compositionMode&&!this._composing)&&this.onChange(e)}_compositionStart(){this._composing=!0}_compositionEnd(e){this._composing=!1,this._compositionMode&&this.onChange(e)}static \u0275fac=function(t){return new(t||n)(S(Se),S(B),S(wx,8))};static \u0275dir=I({type:n,selectors:[["input","formControlName","",3,"type","checkbox"],["textarea","formControlName",""],["input","formControl","",3,"type","checkbox"],["textarea","formControl",""],["input","ngModel","",3,"type","checkbox"],["textarea","ngModel",""],["","ngDefaultControl",""]],hostBindings:function(t,a){t&1&&_("input",function(c){return a._handleInput(c.target.value)})("blur",function(){return a.onTouched()})("compositionstart",function(){return a._compositionStart()})("compositionend",function(c){return a._compositionEnd(c.target.value)})},standalone:!1,features:[ce([xx]),ie]})}return n})();function wu(n){return n==null||Du(n)===0}function Du(n){return n==null?null:Array.isArray(n)||typeof n=="string"?n.length:n instanceof Set?n.size:null}var Ii=new E(""),Eu=new E(""),Dx=/^(?=.{1,254}$)(?=.{1,64}@)[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,no=class{static min(i){return Ex(i)}static max(i){return Sx(i)}static required(i){return kx(i)}static requiredTrue(i){return Mx(i)}static email(i){return Ix(i)}static minLength(i){return Ax(i)}static maxLength(i){return tg(i)}static pattern(i){return Rx(i)}static nullValidator(i){return bc()}static compose(i){return sg(i)}static composeAsync(i){return cg(i)}};function Ex(n){return i=>{if(i.value==null||n==null)return null;let e=parseFloat(i.value);return!isNaN(e)&&e<n?{min:{min:n,actual:i.value}}:null}}function Sx(n){return i=>{if(i.value==null||n==null)return null;let e=parseFloat(i.value);return!isNaN(e)&&e>n?{max:{max:n,actual:i.value}}:null}}function kx(n){return wu(n.value)?{required:!0}:null}function Mx(n){return n.value===!0?null:{required:!0}}function Ix(n){return wu(n.value)||Dx.test(n.value)?null:{email:!0}}function Ax(n){return i=>{let e=i.value?.length??Du(i.value);return e===null||e===0?null:e<n?{minlength:{requiredLength:n,actualLength:e}}:null}}function tg(n){return i=>{let e=i.value?.length??Du(i.value);return e!==null&&e>n?{maxlength:{requiredLength:n,actualLength:e}}:null}}function Rx(n){if(!n)return bc;let i,e;return typeof n=="string"?(e="",n.charAt(0)!=="^"&&(e+="^"),e+=n,n.charAt(n.length-1)!=="$"&&(e+="$"),i=new RegExp(e)):(e=n.toString(),i=n),t=>{if(wu(t.value))return null;let a=t.value;return i.test(a)?null:{pattern:{requiredPattern:e,actualValue:a}}}}function bc(n){return null}function ng(n){return n!=null}function ig(n){return Ao(n)?Lt(n):n}function ag(n){let i={};return n.forEach(e=>{i=e!=null?M(M({},i),e):i}),Object.keys(i).length===0?null:i}function og(n,i){return i.map(e=>e(n))}function Tx(n){return!n.validate}function rg(n){return n.map(i=>Tx(i)?i:e=>i.validate(e))}function sg(n){if(!n)return null;let i=n.filter(ng);return i.length==0?null:function(e){return ag(og(e,i))}}function Su(n){return n!=null?sg(rg(n)):null}function cg(n){if(!n)return null;let i=n.filter(ng);return i.length==0?null:function(e){let t=og(e,i).map(ig);return es(t).pipe(Q(ag))}}function ku(n){return n!=null?cg(rg(n)):null}function qf(n,i){return n===null?[i]:Array.isArray(n)?[...n,i]:[n,i]}function lg(n){return n._rawValidators}function dg(n){return n._rawAsyncValidators}function xu(n){return n?Array.isArray(n)?n:[n]:[]}function vc(n,i){return Array.isArray(n)?n.includes(i):n===i}function Wf(n,i){let e=xu(i);return xu(n).forEach(a=>{vc(e,a)||e.push(a)}),e}function Qf(n,i){return xu(i).filter(e=>!vc(n,e))}var yc=class{get value(){return this.control?this.control.value:null}get valid(){return this.control?this.control.valid:null}get invalid(){return this.control?this.control.invalid:null}get pending(){return this.control?this.control.pending:null}get disabled(){return this.control?this.control.disabled:null}get enabled(){return this.control?this.control.enabled:null}get errors(){return this.control?this.control.errors:null}get pristine(){return this.control?this.control.pristine:null}get dirty(){return this.control?this.control.dirty:null}get touched(){return this.control?this.control.touched:null}get status(){return this.control?this.control.status:null}get untouched(){return this.control?this.control.untouched:null}get statusChanges(){return this.control?this.control.statusChanges:null}get valueChanges(){return this.control?this.control.valueChanges:null}get path(){return null}_composedValidatorFn;_composedAsyncValidatorFn;_rawValidators=[];_rawAsyncValidators=[];_setValidators(i){this._rawValidators=i||[],this._composedValidatorFn=Su(this._rawValidators)}_setAsyncValidators(i){this._rawAsyncValidators=i||[],this._composedAsyncValidatorFn=ku(this._rawAsyncValidators)}get validator(){return this._composedValidatorFn||null}get asyncValidator(){return this._composedAsyncValidatorFn||null}_onDestroyCallbacks=[];_registerOnDestroy(i){this._onDestroyCallbacks.push(i)}_invokeOnDestroyCallbacks(){this._onDestroyCallbacks.forEach(i=>i()),this._onDestroyCallbacks=[]}reset(i=void 0){this.control?.reset(i)}hasError(i,e){return this.control?this.control.hasError(i,e):!1}getError(i,e){return this.control?this.control.getError(i,e):null}},ki=class extends yc{name;get formDirective(){return null}get path(){return null}},ai=class extends yc{_parent=null;name=null;valueAccessor=null},xc=class{_cd;constructor(i){this._cd=i}get isTouched(){return this._cd?.control?._touched?.(),!!this._cd?.control?.touched}get isUntouched(){return!!this._cd?.control?.untouched}get isPristine(){return this._cd?.control?._pristine?.(),!!this._cd?.control?.pristine}get isDirty(){return!!this._cd?.control?.dirty}get isValid(){return this._cd?.control?._status?.(),!!this._cd?.control?.valid}get isInvalid(){return!!this._cd?.control?.invalid}get isPending(){return!!this._cd?.control?.pending}get isSubmitted(){return this._cd?._submitted?.(),!!this._cd?.submitted}};var Tt=(()=>{class n extends xc{constructor(e){super(e)}static \u0275fac=function(t){return new(t||n)(S(ai,2))};static \u0275dir=I({type:n,selectors:[["","formControlName",""],["","ngModel",""],["","formControl",""]],hostVars:14,hostBindings:function(t,a){t&2&&k("ng-untouched",a.isUntouched)("ng-touched",a.isTouched)("ng-pristine",a.isPristine)("ng-dirty",a.isDirty)("ng-valid",a.isValid)("ng-invalid",a.isInvalid)("ng-pending",a.isPending)},standalone:!1,features:[ie]})}return n})(),ug=(()=>{class n extends xc{constructor(e){super(e)}static \u0275fac=function(t){return new(t||n)(S(ki,10))};static \u0275dir=I({type:n,selectors:[["","formGroupName",""],["","formArrayName",""],["","ngModelGroup",""],["","formGroup",""],["","formArray",""],["form",3,"ngNoForm",""],["","ngForm",""]],hostVars:16,hostBindings:function(t,a){t&2&&k("ng-untouched",a.isUntouched)("ng-touched",a.isTouched)("ng-pristine",a.isPristine)("ng-dirty",a.isDirty)("ng-valid",a.isValid)("ng-invalid",a.isInvalid)("ng-pending",a.isPending)("ng-submitted",a.isSubmitted)},standalone:!1,features:[ie]})}return n})();var Dr="VALID",_c="INVALID",eo="PENDING",Er="DISABLED",Mi=class{},Cc=class extends Mi{value;source;constructor(i,e){super(),this.value=i,this.source=e}},kr=class extends Mi{pristine;source;constructor(i,e){super(),this.pristine=i,this.source=e}},Mr=class extends Mi{touched;source;constructor(i,e){super(),this.touched=i,this.source=e}},to=class extends Mi{status;source;constructor(i,e){super(),this.status=i,this.source=e}},wc=class extends Mi{source;constructor(i){super(),this.source=i}},Dc=class extends Mi{source;constructor(i){super(),this.source=i}};function mg(n){return(Ac(n)?n.validators:n)||null}function Ox(n){return Array.isArray(n)?Su(n):n||null}function pg(n,i){return(Ac(i)?i.asyncValidators:n)||null}function Px(n){return Array.isArray(n)?ku(n):n||null}function Ac(n){return n!=null&&!Array.isArray(n)&&typeof n=="object"}function Fx(n,i,e){let t=n.controls;if(!(i?Object.keys(t):t).length)throw new oe(1e3,"");if(!t[e])throw new oe(1001,"")}function Nx(n,i,e){n._forEachChild((t,a)=>{if(e[a]===void 0)throw new oe(-1002,"")})}var Ec=class{_pendingDirty=!1;_hasOwnPendingAsyncValidator=null;_pendingTouched=!1;_onCollectionChange=()=>{};_updateOn;_parent=null;_asyncValidationSubscription;_composedValidatorFn;_composedAsyncValidatorFn;_rawValidators;_rawAsyncValidators;value;constructor(i,e){this._assignValidators(i),this._assignAsyncValidators(e)}get validator(){return this._composedValidatorFn}set validator(i){this._rawValidators=this._composedValidatorFn=i}get asyncValidator(){return this._composedAsyncValidatorFn}set asyncValidator(i){this._rawAsyncValidators=this._composedAsyncValidatorFn=i}get parent(){return this._parent}get status(){return ke(this.statusReactive)}set status(i){ke(()=>this.statusReactive.set(i))}_status=Vt(()=>this.statusReactive());statusReactive=le(void 0);get valid(){return this.status===Dr}get invalid(){return this.status===_c}get pending(){return this.status===eo}get disabled(){return this.status===Er}get enabled(){return this.status!==Er}errors;get pristine(){return ke(this.pristineReactive)}set pristine(i){ke(()=>this.pristineReactive.set(i))}_pristine=Vt(()=>this.pristineReactive());pristineReactive=le(!0);get dirty(){return!this.pristine}get touched(){return ke(this.touchedReactive)}set touched(i){ke(()=>this.touchedReactive.set(i))}_touched=Vt(()=>this.touchedReactive());touchedReactive=le(!1);get untouched(){return!this.touched}_events=new F;events=this._events.asObservable();valueChanges;statusChanges;get updateOn(){return this._updateOn?this._updateOn:this.parent?this.parent.updateOn:"change"}setValidators(i){this._assignValidators(i)}setAsyncValidators(i){this._assignAsyncValidators(i)}addValidators(i){this.setValidators(Wf(i,this._rawValidators))}addAsyncValidators(i){this.setAsyncValidators(Wf(i,this._rawAsyncValidators))}removeValidators(i){this.setValidators(Qf(i,this._rawValidators))}removeAsyncValidators(i){this.setAsyncValidators(Qf(i,this._rawAsyncValidators))}hasValidator(i){return vc(this._rawValidators,i)}hasAsyncValidator(i){return vc(this._rawAsyncValidators,i)}clearValidators(){this.validator=null}clearAsyncValidators(){this.asyncValidator=null}markAsTouched(i={}){let e=this.touched===!1;this.touched=!0;let t=i.sourceControl??this;i.onlySelf||this._parent?.markAsTouched(Re(M({},i),{sourceControl:t})),e&&i.emitEvent!==!1&&this._events.next(new Mr(!0,t))}markAllAsDirty(i={}){this.markAsDirty({onlySelf:!0,emitEvent:i.emitEvent,sourceControl:this}),this._forEachChild(e=>e.markAllAsDirty(i))}markAllAsTouched(i={}){this.markAsTouched({onlySelf:!0,emitEvent:i.emitEvent,sourceControl:this}),this._forEachChild(e=>e.markAllAsTouched(i))}markAsUntouched(i={}){let e=this.touched===!0;this.touched=!1,this._pendingTouched=!1;let t=i.sourceControl??this;this._forEachChild(a=>{a.markAsUntouched({onlySelf:!0,emitEvent:i.emitEvent,sourceControl:t})}),i.onlySelf||this._parent?._updateTouched(i,t),e&&i.emitEvent!==!1&&this._events.next(new Mr(!1,t))}markAsDirty(i={}){let e=this.pristine===!0;this.pristine=!1;let t=i.sourceControl??this;i.onlySelf||this._parent?.markAsDirty(Re(M({},i),{sourceControl:t})),e&&i.emitEvent!==!1&&this._events.next(new kr(!1,t))}markAsPristine(i={}){let e=this.pristine===!1;this.pristine=!0,this._pendingDirty=!1;let t=i.sourceControl??this;this._forEachChild(a=>{a.markAsPristine({onlySelf:!0,emitEvent:i.emitEvent})}),i.onlySelf||this._parent?._updatePristine(i,t),e&&i.emitEvent!==!1&&this._events.next(new kr(!0,t))}markAsPending(i={}){this.status=eo;let e=i.sourceControl??this;i.emitEvent!==!1&&(this._events.next(new to(this.status,e)),this.statusChanges.emit(this.status)),i.onlySelf||this._parent?.markAsPending(Re(M({},i),{sourceControl:e}))}disable(i={}){let e=this._parentMarkedDirty(i.onlySelf);this.status=Er,this.errors=null,this._forEachChild(a=>{a.disable(Re(M({},i),{onlySelf:!0}))}),this._updateValue();let t=i.sourceControl??this;i.emitEvent!==!1&&(this._events.next(new Cc(this.value,t)),this._events.next(new to(this.status,t)),this.valueChanges.emit(this.value),this.statusChanges.emit(this.status)),this._updateAncestors(Re(M({},i),{skipPristineCheck:e}),this),this._onDisabledChange.forEach(a=>a(!0))}enable(i={}){let e=this._parentMarkedDirty(i.onlySelf);this.status=Dr,this._forEachChild(t=>{t.enable(Re(M({},i),{onlySelf:!0}))}),this.updateValueAndValidity({onlySelf:!0,emitEvent:i.emitEvent}),this._updateAncestors(Re(M({},i),{skipPristineCheck:e}),this),this._onDisabledChange.forEach(t=>t(!1))}_updateAncestors(i,e){i.onlySelf||(this._parent?.updateValueAndValidity(i),i.skipPristineCheck||this._parent?._updatePristine({},e),this._parent?._updateTouched({},e))}setParent(i){this._parent=i}getRawValue(){return this.value}updateValueAndValidity(i={}){if(this._setInitialStatus(),this._updateValue(),this.enabled){let t=this._cancelExistingSubscription();this.errors=this._runValidator(),this.status=this._calculateStatus(),(this.status===Dr||this.status===eo)&&this._runAsyncValidator(t,i.emitEvent)}let e=i.sourceControl??this;i.emitEvent!==!1&&(this._events.next(new Cc(this.value,e)),this._events.next(new to(this.status,e)),this.valueChanges.emit(this.value),this.statusChanges.emit(this.status)),i.onlySelf||this._parent?.updateValueAndValidity(Re(M({},i),{sourceControl:e}))}_updateTreeValidity(i={emitEvent:!0}){this._forEachChild(e=>e._updateTreeValidity(i)),this.updateValueAndValidity({onlySelf:!0,emitEvent:i.emitEvent})}_setInitialStatus(){this.status=this._allControlsDisabled()?Er:Dr}_runValidator(){return this.validator?this.validator(this):null}_runAsyncValidator(i,e){if(this.asyncValidator){this.status=eo,this._hasOwnPendingAsyncValidator={emitEvent:e!==!1,shouldHaveEmitted:i!==!1};let t=ig(this.asyncValidator(this));this._asyncValidationSubscription=t.subscribe(a=>{this._hasOwnPendingAsyncValidator=null,this.setErrors(a,{emitEvent:e,shouldHaveEmitted:i})})}}_cancelExistingSubscription(){if(this._asyncValidationSubscription){this._asyncValidationSubscription.unsubscribe();let i=(this._hasOwnPendingAsyncValidator?.emitEvent||this._hasOwnPendingAsyncValidator?.shouldHaveEmitted)??!1;return this._hasOwnPendingAsyncValidator=null,i}return!1}setErrors(i,e={}){this.errors=i,this._updateControlsErrors(e.emitEvent!==!1,this,e.shouldHaveEmitted)}get(i){let e=i;return e==null||(Array.isArray(e)||(e=e.split(".")),e.length===0)?null:e.reduce((t,a)=>t&&t._find(a),this)}getError(i,e){let t=e?this.get(e):this;return t?.errors?t.errors[i]:null}hasError(i,e){return!!this.getError(i,e)}get root(){let i=this;for(;i._parent;)i=i._parent;return i}_updateControlsErrors(i,e,t){this.status=this._calculateStatus(),i&&this.statusChanges.emit(this.status),(i||t)&&this._events.next(new to(this.status,e)),this._parent&&this._parent._updateControlsErrors(i,e,t)}_initObservables(){this.valueChanges=new z,this.statusChanges=new z}_calculateStatus(){return this._allControlsDisabled()?Er:this.errors?_c:this._hasOwnPendingAsyncValidator||this._anyControlsHaveStatus(eo)?eo:this._anyControlsHaveStatus(_c)?_c:Dr}_anyControlsHaveStatus(i){return this._anyControls(e=>e.status===i)}_anyControlsDirty(){return this._anyControls(i=>i.dirty)}_anyControlsTouched(){return this._anyControls(i=>i.touched)}_updatePristine(i,e){let t=!this._anyControlsDirty(),a=this.pristine!==t;this.pristine=t,i.onlySelf||this._parent?._updatePristine(i,e),a&&this._events.next(new kr(this.pristine,e))}_updateTouched(i={},e){this.touched=this._anyControlsTouched(),this._events.next(new Mr(this.touched,e)),i.onlySelf||this._parent?._updateTouched(i,e)}_onDisabledChange=[];_registerOnCollectionChange(i){this._onCollectionChange=i}_setUpdateStrategy(i){Ac(i)&&i.updateOn!=null&&(this._updateOn=i.updateOn)}_parentMarkedDirty(i){return!i&&!!this._parent?.dirty&&!this._parent._anyControlsDirty()}_find(i){return null}_assignValidators(i){this._rawValidators=Array.isArray(i)?i.slice():i,this._composedValidatorFn=Ox(this._rawValidators)}_assignAsyncValidators(i){this._rawAsyncValidators=Array.isArray(i)?i.slice():i,this._composedAsyncValidatorFn=Px(this._rawAsyncValidators)}},Sc=class extends Ec{constructor(i,e,t){super(mg(e),pg(t,e)),this.controls=i,this._initObservables(),this._setUpdateStrategy(e),this._setUpControls(),this.updateValueAndValidity({onlySelf:!0,emitEvent:!!this.asyncValidator})}controls;registerControl(i,e){return this.controls[i]?this.controls[i]:(this.controls[i]=e,e.setParent(this),e._registerOnCollectionChange(this._onCollectionChange),e)}addControl(i,e,t={}){this.registerControl(i,e),this.updateValueAndValidity({emitEvent:t.emitEvent}),this._onCollectionChange()}removeControl(i,e={}){this.controls[i]&&this.controls[i]._registerOnCollectionChange(()=>{}),delete this.controls[i],this.updateValueAndValidity({emitEvent:e.emitEvent}),this._onCollectionChange()}setControl(i,e,t={}){this.controls[i]&&this.controls[i]._registerOnCollectionChange(()=>{}),delete this.controls[i],e&&this.registerControl(i,e),this.updateValueAndValidity({emitEvent:t.emitEvent}),this._onCollectionChange()}contains(i){return this.controls.hasOwnProperty(i)&&this.controls[i].enabled}setValue(i,e={}){Nx(this,!0,i),Object.keys(i).forEach(t=>{Fx(this,!0,t),this.controls[t].setValue(i[t],{onlySelf:!0,emitEvent:e.emitEvent})}),this.updateValueAndValidity(e)}patchValue(i,e={}){i!=null&&(Object.keys(i).forEach(t=>{let a=this.controls[t];a&&a.patchValue(i[t],{onlySelf:!0,emitEvent:e.emitEvent})}),this.updateValueAndValidity(e))}reset(i={},e={}){this._forEachChild((t,a)=>{t.reset(i?i[a]:null,Re(M({},e),{onlySelf:!0}))}),this._updatePristine(e,this),this._updateTouched(e,this),this.updateValueAndValidity(e),e?.emitEvent!==!1&&this._events.next(new Dc(this))}getRawValue(){return this._reduceChildren({},(i,e,t)=>(i[t]=e.getRawValue(),i))}_syncPendingControls(){let i=this._reduceChildren(!1,(e,t)=>t._syncPendingControls()?!0:e);return i&&this.updateValueAndValidity({onlySelf:!0}),i}_forEachChild(i){Object.keys(this.controls).forEach(e=>{let t=this.controls[e];t&&i(t,e)})}_setUpControls(){this._forEachChild(i=>{i.setParent(this),i._registerOnCollectionChange(this._onCollectionChange)})}_updateValue(){this.value=this._reduceValue()}_anyControls(i){for(let[e,t]of Object.entries(this.controls))if(this.contains(e)&&i(t))return!0;return!1}_reduceValue(){let i={};return this._reduceChildren(i,(e,t,a)=>((t.enabled||this.disabled)&&(e[a]=t.value),e))}_reduceChildren(i,e){let t=i;return this._forEachChild((a,o)=>{t=e(t,a,o)}),t}_allControlsDisabled(){for(let i of Object.keys(this.controls))if(this.controls[i].enabled)return!1;return Object.keys(this.controls).length>0||this.disabled}_find(i){return this.controls.hasOwnProperty(i)?this.controls[i]:null}};var Rc=new E("",{factory:()=>Mu}),Mu="always";function Lx(n,i){return[...i.path,n]}function kc(n,i,e=Mu){Iu(n,i),i.valueAccessor.writeValue(n.value),(n.disabled||e==="always")&&i.valueAccessor.setDisabledState?.(n.disabled),jx(n,i),zx(n,i),Vx(n,i),Bx(n,i)}function Yf(n,i,e=!0){let t=()=>{};i?.valueAccessor?.registerOnChange(t),i?.valueAccessor?.registerOnTouched(t),Ic(n,i),n&&(i._invokeOnDestroyCallbacks(),n._registerOnCollectionChange(()=>{}))}function Mc(n,i){n.forEach(e=>{e.registerOnValidatorChange&&e.registerOnValidatorChange(i)})}function Bx(n,i){if(i.valueAccessor.setDisabledState){let e=t=>{i.valueAccessor.setDisabledState(t)};n.registerOnDisabledChange(e),i._registerOnDestroy(()=>{n._unregisterOnDisabledChange(e)})}}function Iu(n,i){let e=lg(n);i.validator!==null?n.setValidators(qf(e,i.validator)):typeof e=="function"&&n.setValidators([e]);let t=dg(n);i.asyncValidator!==null?n.setAsyncValidators(qf(t,i.asyncValidator)):typeof t=="function"&&n.setAsyncValidators([t]);let a=()=>n.updateValueAndValidity();Mc(i._rawValidators,a),Mc(i._rawAsyncValidators,a)}function Ic(n,i){let e=!1;if(n!==null){if(i.validator!==null){let a=lg(n);if(Array.isArray(a)&&a.length>0){let o=a.filter(c=>c!==i.validator);o.length!==a.length&&(e=!0,n.setValidators(o))}}if(i.asyncValidator!==null){let a=dg(n);if(Array.isArray(a)&&a.length>0){let o=a.filter(c=>c!==i.asyncValidator);o.length!==a.length&&(e=!0,n.setAsyncValidators(o))}}}let t=()=>{};return Mc(i._rawValidators,t),Mc(i._rawAsyncValidators,t),e}function jx(n,i){i.valueAccessor.registerOnChange(e=>{n._pendingValue=e,n._pendingChange=!0,n._pendingDirty=!0,n.updateOn==="change"&&hg(n,i)})}function Vx(n,i){i.valueAccessor.registerOnTouched(()=>{n._pendingTouched=!0,n.updateOn==="blur"&&n._pendingChange&&hg(n,i),n.updateOn!=="submit"&&n.markAsTouched()})}function hg(n,i){n._pendingDirty&&n.markAsDirty(),n.setValue(n._pendingValue,{emitModelToViewChange:!1}),i.viewToModelUpdate(n._pendingValue),n._pendingChange=!1}function zx(n,i){let e=(t,a)=>{i.valueAccessor.writeValue(t),a&&i.viewToModelUpdate(t)};n.registerOnChange(e),i._registerOnDestroy(()=>{n._unregisterOnChange(e)})}function fg(n,i){n==null,Iu(n,i)}function Ux(n,i){return Ic(n,i)}function Hx(n,i){if(!n.hasOwnProperty("model"))return!1;let e=n.model;return e.isFirstChange()?!0:!Object.is(i,e.currentValue)}function $x(n){return Object.getPrototypeOf(n.constructor)===Cu}function gg(n,i){n._syncPendingControls(),i.forEach(e=>{let t=e.control;t.updateOn==="submit"&&t._pendingChange&&(e.viewToModelUpdate(t._pendingValue),t._pendingChange=!1)})}function Gx(n,i){if(!i)return null;Array.isArray(i);let e,t,a;return i.forEach(o=>{o.constructor===ft?e=o:$x(o)?t=o:a=o}),a||t||e||null}function qx(n,i){let e=n.indexOf(i);e>-1&&n.splice(e,1)}var Wx={provide:ki,useExisting:It(()=>ra)},Sr=Promise.resolve(),ra=(()=>{class n extends ki{callSetDisabledState;get submitted(){return ke(this.submittedReactive)}_submitted=Vt(()=>this.submittedReactive());submittedReactive=le(!1);_directives=new Set;form;ngSubmit=new z;options;constructor(e,t,a){super(),this.callSetDisabledState=a,this.form=new Sc({},Su(e),ku(t))}ngAfterViewInit(){this._setUpdateStrategy()}get formDirective(){return this}get control(){return this.form}get path(){return[]}get controls(){return this.form.controls}addControl(e){Sr.then(()=>{let t=this._findContainer(e.path);e.control=t.registerControl(e.name,e.control),kc(e.control,e,this.callSetDisabledState),e.control.updateValueAndValidity({emitEvent:!1}),this._directives.add(e)})}getControl(e){return this.form.get(e.path)}removeControl(e){Sr.then(()=>{this._findContainer(e.path)?.removeControl(e.name),this._directives.delete(e)})}addFormGroup(e){Sr.then(()=>{let t=this._findContainer(e.path),a=new Sc({});fg(a,e),t.registerControl(e.name,a),a.updateValueAndValidity({emitEvent:!1})})}removeFormGroup(e){Sr.then(()=>{this._findContainer(e.path)?.removeControl?.(e.name)})}getFormGroup(e){return this.form.get(e.path)}updateModel(e,t){Sr.then(()=>{this.form.get(e.path).setValue(t)})}setValue(e){this.control.setValue(e)}onSubmit(e){return this.submittedReactive.set(!0),gg(this.form,this._directives),this.ngSubmit.emit(e),this.form._events.next(new wc(this.control)),e?.target?.method==="dialog"}onReset(){this.resetForm()}resetForm(e=void 0){this.form.reset(e),this.submittedReactive.set(!1)}_setUpdateStrategy(){this.options&&this.options.updateOn!=null&&(this.form._updateOn=this.options.updateOn)}_findContainer(e){return e.pop(),e.length?this.form.get(e):this.form}static \u0275fac=function(t){return new(t||n)(S(Ii,10),S(Eu,10),S(Rc,8))};static \u0275dir=I({type:n,selectors:[["form",3,"ngNoForm","",3,"formGroup","",3,"formArray",""],["ng-form"],["","ngForm",""]],hostBindings:function(t,a){t&1&&_("submit",function(c){return a.onSubmit(c)})("reset",function(){return a.onReset()})},inputs:{options:[0,"ngFormOptions","options"]},outputs:{ngSubmit:"ngSubmit"},exportAs:["ngForm"],standalone:!1,features:[ce([Wx]),ie]})}return n})();function Xf(n,i){let e=n.indexOf(i);e>-1&&n.splice(e,1)}function Kf(n){return typeof n=="object"&&n!==null&&Object.keys(n).length===2&&"value"in n&&"disabled"in n}var _g=class extends Ec{defaultValue=null;_onChange=[];_pendingValue;_pendingChange=!1;constructor(i=null,e,t){super(mg(e),pg(t,e)),this._applyFormState(i),this._setUpdateStrategy(e),this._initObservables(),this.updateValueAndValidity({onlySelf:!0,emitEvent:!!this.asyncValidator}),Ac(e)&&(e.nonNullable||e.initialValueIsDefault)&&(Kf(i)?this.defaultValue=i.value:this.defaultValue=i)}setValue(i,e={}){this.value=this._pendingValue=i,this._onChange.length&&e.emitModelToViewChange!==!1&&this._onChange.forEach(t=>t(this.value,e.emitViewToModelChange!==!1)),this.updateValueAndValidity(e)}patchValue(i,e={}){this.setValue(i,e)}reset(i=this.defaultValue,e={}){this._applyFormState(i),this.markAsPristine(e),this.markAsUntouched(e),this.setValue(this.value,e),e.overwriteDefaultValue&&(this.defaultValue=this.value),this._pendingChange=!1,e?.emitEvent!==!1&&this._events.next(new Dc(this))}_updateValue(){}_anyControls(i){return!1}_allControlsDisabled(){return this.disabled}registerOnChange(i){this._onChange.push(i)}_unregisterOnChange(i){Xf(this._onChange,i)}registerOnDisabledChange(i){this._onDisabledChange.push(i)}_unregisterOnDisabledChange(i){Xf(this._onDisabledChange,i)}_forEachChild(i){}_syncPendingControls(){return this.updateOn==="submit"&&(this._pendingDirty&&this.markAsDirty(),this._pendingTouched&&this.markAsTouched(),this._pendingChange)?(this.setValue(this._pendingValue,{onlySelf:!0,emitModelToViewChange:!1}),!0):!1}_applyFormState(i){Kf(i)?(this.value=this._pendingValue=i.value,i.disabled?this.disable({onlySelf:!0,emitEvent:!1}):this.enable({onlySelf:!0,emitEvent:!1})):this.value=this._pendingValue=i}};var Qx=n=>n instanceof _g;var Yx={provide:ai,useExisting:It(()=>St)},Zf=Promise.resolve(),St=(()=>{class n extends ai{_changeDetectorRef;callSetDisabledState;control=new _g;static ngAcceptInputType_isDisabled;_registered=!1;viewModel;name="";isDisabled;model;options;update=new z;constructor(e,t,a,o,c,u){super(),this._changeDetectorRef=c,this.callSetDisabledState=u,this._parent=e,this._setValidators(t),this._setAsyncValidators(a),this.valueAccessor=Gx(this,o)}ngOnChanges(e){if(this._checkForErrors(),!this._registered||"name"in e){if(this._registered&&(this._checkName(),this.formDirective)){let t=e.name.previousValue;this.formDirective.removeControl({name:t,path:this._getPath(t)})}this._setUpControl()}"isDisabled"in e&&this._updateDisabled(e),Hx(e,this.viewModel)&&(this._updateValue(this.model),this.viewModel=this.model)}ngOnDestroy(){this.formDirective?.removeControl(this)}get path(){return this._getPath(this.name)}get formDirective(){return this._parent?this._parent.formDirective:null}viewToModelUpdate(e){this.viewModel=e,this.update.emit(e)}_setUpControl(){this._setUpdateStrategy(),this._isStandalone()?this._setUpStandalone():this.formDirective.addControl(this),this._registered=!0}_setUpdateStrategy(){this.options&&this.options.updateOn!=null&&(this.control._updateOn=this.options.updateOn)}_isStandalone(){return!this._parent||!!(this.options&&this.options.standalone)}_setUpStandalone(){kc(this.control,this,this.callSetDisabledState),this.control.updateValueAndValidity({emitEvent:!1})}_checkForErrors(){this._checkName()}_checkName(){this.options&&this.options.name&&(this.name=this.options.name),!this._isStandalone()&&this.name}_updateValue(e){Zf.then(()=>{this.control.setValue(e,{emitViewToModelChange:!1}),this._changeDetectorRef?.markForCheck()})}_updateDisabled(e){let t=e.isDisabled.currentValue,a=t!==0&&R(t);Zf.then(()=>{a&&!this.control.disabled?this.control.disable():!a&&this.control.disabled&&this.control.enable(),this._changeDetectorRef?.markForCheck()})}_getPath(e){return this._parent?Lx(e,this._parent):[e]}static \u0275fac=function(t){return new(t||n)(S(ki,9),S(Ii,10),S(Eu,10),S(zn,10),S(Z,8),S(Rc,8))};static \u0275dir=I({type:n,selectors:[["","ngModel","",3,"formControlName","",3,"formControl",""]],inputs:{name:"name",isDisabled:[0,"disabled","isDisabled"],model:[0,"ngModel","model"],options:[0,"ngModelOptions","options"]},outputs:{update:"ngModelChange"},exportAs:["ngModel"],standalone:!1,features:[ce([Yx]),ie,we]})}return n})();var bg=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["form",3,"ngNoForm","",3,"ngNativeValidate",""]],hostAttrs:["novalidate",""],standalone:!1})}return n})();var Xx=(()=>{class n extends ki{callSetDisabledState;get submitted(){return ke(this._submittedReactive)}set submitted(e){this._submittedReactive.set(e)}_submitted=Vt(()=>this._submittedReactive());_submittedReactive=le(!1);_oldForm;_onCollectionChange=()=>this._updateDomValue();directives=[];constructor(e,t,a){super(),this.callSetDisabledState=a,this._setValidators(e),this._setAsyncValidators(t)}ngOnChanges(e){this.onChanges(e)}ngOnDestroy(){this.onDestroy()}onChanges(e){this._checkFormPresent(),e.hasOwnProperty("form")&&(this._updateValidators(),this._updateDomValue(),this._updateRegistrations(),this._oldForm=this.form)}onDestroy(){this.form&&(Ic(this.form,this),this.form._onCollectionChange===this._onCollectionChange&&this.form._registerOnCollectionChange(()=>{}))}get formDirective(){return this}get path(){return[]}addControl(e){let t=this.form.get(e.path);return kc(t,e,this.callSetDisabledState),t.updateValueAndValidity({emitEvent:!1}),this.directives.push(e),t}getControl(e){return this.form.get(e.path)}removeControl(e){Yf(e.control||null,e,!1),qx(this.directives,e)}addFormGroup(e){this._setUpFormContainer(e)}removeFormGroup(e){this._cleanUpFormContainer(e)}getFormGroup(e){return this.form.get(e.path)}getFormArray(e){return this.form.get(e.path)}addFormArray(e){this._setUpFormContainer(e)}removeFormArray(e){this._cleanUpFormContainer(e)}updateModel(e,t){this.form.get(e.path).setValue(t)}onReset(){this.resetForm()}resetForm(e=void 0,t={}){this.form.reset(e,t),this._submittedReactive.set(!1)}onSubmit(e){return this.submitted=!0,gg(this.form,this.directives),this.ngSubmit.emit(e),this.form._events.next(new wc(this.control)),e?.target?.method==="dialog"}_updateDomValue(){this.directives.forEach(e=>{let t=e.control,a=this.form.get(e.path);t!==a&&(Yf(t||null,e),Qx(a)&&(kc(a,e,this.callSetDisabledState),e.control=a))}),this.form._updateTreeValidity({emitEvent:!1})}_setUpFormContainer(e){let t=this.form.get(e.path);fg(t,e),t.updateValueAndValidity({emitEvent:!1})}_cleanUpFormContainer(e){let t=this.form?.get(e.path);t&&Ux(t,e)&&t.updateValueAndValidity({emitEvent:!1})}_updateRegistrations(){this.form._registerOnCollectionChange(this._onCollectionChange),this._oldForm?._registerOnCollectionChange(()=>{})}_updateValidators(){Iu(this.form,this),this._oldForm&&Ic(this._oldForm,this)}_checkFormPresent(){this.form}static \u0275fac=function(t){return new(t||n)(S(Ii,10),S(Eu,10),S(Rc,8))};static \u0275dir=I({type:n,features:[ie,we]})}return n})();var Kx={provide:ki,useExisting:It(()=>Ir)},Ir=(()=>{class n extends Xx{form=null;ngSubmit=new z;get control(){return this.form}static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["","formGroup",""]],hostBindings:function(t,a){t&1&&_("submit",function(c){return a.onSubmit(c)})("reset",function(){return a.onReset()})},inputs:{form:[0,"formGroup","form"]},outputs:{ngSubmit:"ngSubmit"},exportAs:["ngForm"],standalone:!1,features:[ce([Kx]),ie]})}return n})(),Zx={provide:zn,useExisting:It(()=>Ai),multi:!0};function vg(n,i){return n==null?`${i}`:(i&&typeof i=="object"&&(i="Object"),`${n}: ${i}`.slice(0,50))}function Jx(n){return n.split(":")[0]}var Ai=(()=>{class n extends Cu{value;_optionMap=new Map;_idCounter=0;set compareWith(e){this._compareWith=e}_compareWith=Object.is;appRefInjector=m(Pn).injector;destroyRef=m($i);cdr=m(Z);_queuedWrite=!1;_writeValueAfterRender(){this._queuedWrite||this.appRefInjector.destroyed||(this._queuedWrite=!0,Pe({write:()=>{this.destroyRef.destroyed||(this._queuedWrite=!1,this.writeValue(this.value))}},{injector:this.appRefInjector}))}writeValue(e){this.cdr.markForCheck(),this.value=e;let t=this._getOptionId(e),a=vg(t,e);this.setProperty("value",a)}registerOnChange(e){this.onChange=t=>{this.value=this._getOptionValue(t),e(this.value)}}_registerOption(){return(this._idCounter++).toString()}_getOptionId(e){for(let t of this._optionMap.keys())if(this._compareWith(this._optionMap.get(t),e))return t;return null}_getOptionValue(e){let t=Jx(e);return this._optionMap.has(t)?this._optionMap.get(t):e}static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["select","formControlName","",3,"multiple",""],["select","formControl","",3,"multiple",""],["select","ngModel","",3,"multiple",""]],hostBindings:function(t,a){t&1&&_("change",function(c){return a.onChange(c.target.value)})("blur",function(){return a.onTouched()})},inputs:{compareWith:"compareWith"},standalone:!1,features:[ce([Zx]),ie]})}return n})(),io=(()=>{class n{_element;_renderer;_select;id;constructor(e,t,a){this._element=e,this._renderer=t,this._select=a,this._select&&(this.id=this._select._registerOption())}set ngValue(e){this._select!=null&&(this._select._optionMap.set(this.id,e),this._setElementValue(vg(this.id,e)),this._select._writeValueAfterRender())}set value(e){this._setElementValue(e),this._select?._writeValueAfterRender()}_setElementValue(e){this._renderer.setProperty(this._element.nativeElement,"value",e)}ngOnDestroy(){this._select?._optionMap.delete(this.id),this._select?._writeValueAfterRender()}static \u0275fac=function(t){return new(t||n)(S(B),S(Se),S(Ai,9))};static \u0275dir=I({type:n,selectors:[["option"]],inputs:{ngValue:"ngValue",value:"value"},standalone:!1})}return n})(),eC={provide:zn,useExisting:It(()=>yg),multi:!0};function Jf(n,i){return n==null?`${i}`:(typeof i=="string"&&(i=`'${i}'`),i&&typeof i=="object"&&(i="Object"),`${n}: ${i}`.slice(0,50))}function tC(n){return n.split(":")[0]}var yg=(()=>{class n extends Cu{value;_optionMap=new Map;_idCounter=0;set compareWith(e){this._compareWith=e}_compareWith=Object.is;writeValue(e){this.value=e;let t;if(Array.isArray(e)){let a=e.map(o=>this._getOptionId(o));t=(o,c)=>{o._setSelected(a.indexOf(c)>-1)}}else t=a=>{a._setSelected(!1)};this._optionMap.forEach(t)}registerOnChange(e){this.onChange=t=>{let a=[],o=t.selectedOptions;if(o!==void 0){let c=o;for(let u=0;u<c.length;u++){let p=c[u],f=this._getOptionValue(p.value);a.push(f)}}else{let c=t.options;for(let u=0;u<c.length;u++){let p=c[u];if(p.selected){let f=this._getOptionValue(p.value);a.push(f)}}}this.value=a,e(a)}}_registerOption(e){let t=(this._idCounter++).toString();return this._optionMap.set(t,e),t}_getOptionId(e){for(let t of this._optionMap.keys())if(this._compareWith(this._optionMap.get(t)._value,e))return t;return null}_getOptionValue(e){let t=tC(e);return this._optionMap.has(t)?this._optionMap.get(t)._value:e}static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["select","multiple","","formControlName",""],["select","multiple","","formControl",""],["select","multiple","","ngModel",""]],hostBindings:function(t,a){t&1&&_("change",function(c){return a.onChange(c.target)})("blur",function(){return a.onTouched()})},inputs:{compareWith:"compareWith"},standalone:!1,features:[ce([eC]),ie]})}return n})(),ao=(()=>{class n{_element;_renderer;_select;id;_value;constructor(e,t,a){this._element=e,this._renderer=t,this._select=a,this._select&&(this.id=this._select._registerOption(this))}set ngValue(e){this._select!=null&&(this._value=e,this._setElementValue(Jf(this.id,e)),this._select.writeValue(this._select.value))}set value(e){this._select?(this._value=e,this._setElementValue(Jf(this.id,e)),this._select.writeValue(this._select.value)):this._setElementValue(e)}_setElementValue(e){this._renderer.setProperty(this._element.nativeElement,"value",e)}_setSelected(e){this._renderer.setProperty(this._element.nativeElement,"selected",e)}ngOnDestroy(){this._select&&(this._select._optionMap.delete(this.id),this._select.writeValue(this._select.value))}static \u0275fac=function(t){return new(t||n)(S(B),S(Se),S(yg,9))};static \u0275dir=I({type:n,selectors:[["option"]],inputs:{ngValue:"ngValue",value:"value"},standalone:!1})}return n})();function nC(n){return typeof n=="number"?n:parseInt(n,10)}var iC=(()=>{class n{_validator=bc;_onChange;_enabled;ngOnChanges(e){if(this.inputName in e){let t=this.normalizeInput(e[this.inputName].currentValue);this._enabled=this.enabled(t),this._validator=this._enabled?this.createValidator(t):bc,this._onChange?.()}}validate(e){return this._validator(e)}registerOnValidatorChange(e){this._onChange=e}enabled(e){return e!=null}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,features:[we]})}return n})();var aC={provide:Ii,useExisting:It(()=>sa),multi:!0},sa=(()=>{class n extends iC{maxlength;inputName="maxlength";normalizeInput=e=>nC(e);createValidator=e=>tg(e);static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["","maxlength","","formControlName",""],["","maxlength","","formControl",""],["","maxlength","","ngModel",""]],hostVars:1,hostBindings:function(t,a){t&2&&Y("maxlength",a._enabled?a.maxlength:null)},inputs:{maxlength:"maxlength"},standalone:!1,features:[ce([aC]),ie]})}return n})();var oC=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({})}return n})();var Ot=(()=>{class n{static withConfig(e){return{ngModule:n,providers:[{provide:Rc,useValue:e.callSetDisabledState??Mu}]}}static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[oC]})}return n})();var oo=(()=>{class n{isErrorState(e,t){return!!(e&&e.invalid&&(e.touched||t&&t.submitted))}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var ro=class{_defaultMatcher;ngControl;_parentFormGroup;_parentForm;_stateChanges;errorState=!1;matcher;constructor(i,e,t,a,o){this._defaultMatcher=i,this.ngControl=e,this._parentFormGroup=t,this._parentForm=a,this._stateChanges=o}updateErrorState(){let i=this.errorState,e=this._parentFormGroup||this._parentForm,t=this.matcher||this._defaultMatcher,a=this.ngControl?this.ngControl.control:null,o=t?.isErrorState(a,e)??!1;o!==i&&(this.errorState=o,this._stateChanges.next())}};var Au=class{_box;_destroyed=new F;_resizeSubject=new F;_resizeObserver;_elementObservables=new Map;constructor(i){this._box=i,typeof ResizeObserver<"u"&&(this._resizeObserver=new ResizeObserver(e=>this._resizeSubject.next(e)))}observe(i){return this._elementObservables.has(i)||this._elementObservables.set(i,new Ht(e=>{let t=this._resizeSubject.subscribe(e);return this._resizeObserver?.observe(i,{box:this._box}),()=>{this._resizeObserver?.unobserve(i),t.unsubscribe(),this._elementObservables.delete(i)}}).pipe(Ce(e=>e.some(t=>t.target===i)),ko({bufferSize:1,refCount:!0}),pe(this._destroyed))),this._elementObservables.get(i)}destroy(){this._destroyed.next(),this._destroyed.complete(),this._resizeSubject.complete(),this._elementObservables.clear()}},Tc=(()=>{class n{_cleanupErrorListener;_observers=new Map;_ngZone=m(W);constructor(){typeof ResizeObserver<"u"}ngOnDestroy(){for(let[,e]of this._observers)e.destroy();this._observers.clear(),this._cleanupErrorListener?.()}observe(e,t){let a=t?.box||"content-box";return this._observers.has(a)||this._observers.set(a,new Au(a)),this._observers.get(a).observe(e)}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var rC=["notch"],sC=["matFormFieldNotchedOutline",""],cC=["*"],xg=["iconPrefixContainer"],Cg=["textPrefixContainer"],wg=["iconSuffixContainer"],Dg=["textSuffixContainer"],lC=["textField"],dC=["*",[["mat-label"]],[["","matPrefix",""],["","matIconPrefix",""]],[["","matTextPrefix",""]],[["","matTextSuffix",""]],[["","matSuffix",""],["","matIconSuffix",""]],[["mat-error"],["","matError",""]],[["mat-hint",3,"align","end"]],[["mat-hint","align","end"]]],uC=["*","mat-label","[matPrefix], [matIconPrefix]","[matTextPrefix]","[matTextSuffix]","[matSuffix], [matIconSuffix]","mat-error, [matError]","mat-hint:not([align='end'])","mat-hint[align='end']"];function mC(n,i){n&1&&H(0,"span",21)}function pC(n,i){if(n&1&&(s(0,"label",20),ee(1,1),v(2,mC,1,0,"span",21),r()),n&2){let e=h(2);P("floating",e._shouldLabelFloat())("monitorResize",e._hasOutline())("id",e._labelId),Y("for",e._control.disableAutomaticLabeling?null:e._control.id),d(2),y(!e.hideRequiredMarker&&e._control.required?2:-1)}}function hC(n,i){if(n&1&&v(0,pC,3,5,"label",20),n&2){let e=h();y(e._hasFloatingLabel()?0:-1)}}function fC(n,i){n&1&&H(0,"div",7)}function gC(n,i){}function _C(n,i){if(n&1&&_e(0,gC,0,0,"ng-template",13),n&2){h(2);let e=ct(1);P("ngTemplateOutlet",e)}}function bC(n,i){if(n&1&&(s(0,"div",9),v(1,_C,1,1,null,13),r()),n&2){let e=h();P("matFormFieldNotchedOutlineOpen",e._shouldLabelFloat()),d(),y(e._forceDisplayInfixLabel()?-1:1)}}function vC(n,i){n&1&&(s(0,"div",10,2),ee(2,2),r())}function yC(n,i){n&1&&(s(0,"div",11,3),ee(2,3),r())}function xC(n,i){}function CC(n,i){if(n&1&&_e(0,xC,0,0,"ng-template",13),n&2){h();let e=ct(1);P("ngTemplateOutlet",e)}}function wC(n,i){n&1&&(s(0,"div",14,4),ee(2,4),r())}function DC(n,i){n&1&&(s(0,"div",15,5),ee(2,5),r())}function EC(n,i){n&1&&H(0,"div",16)}function SC(n,i){n&1&&(s(0,"div",18),ee(1,6),r())}function kC(n,i){if(n&1&&(s(0,"mat-hint",22),l(1),r()),n&2){let e=h(2);P("id",e._hintLabelId),d(),g(e.hintLabel)}}function MC(n,i){if(n&1&&(s(0,"div",19),v(1,kC,2,2,"mat-hint",22),ee(2,7),H(3,"div",23),ee(4,8),r()),n&2){let e=h();d(),y(e.hintLabel?1:-1)}}var Jt=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["mat-label"]]})}return n})(),IC=new E("MatError");var Ar=(()=>{class n{align="start";id=m(xe).getId("mat-mdc-hint-");static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["mat-hint"]],hostAttrs:[1,"mat-mdc-form-field-hint","mat-mdc-form-field-bottom-align"],hostVars:4,hostBindings:function(t,a){t&2&&(jt("id",a.id),Y("align",null),k("mat-mdc-form-field-hint-end",a.align==="end"))},inputs:{align:"align",id:"id"}})}return n})(),Rg=new E("MatPrefix"),Ru=(()=>{class n{set _isTextSelector(e){this._isText=!0}_isText=!1;static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","matPrefix",""],["","matIconPrefix",""],["","matTextPrefix",""]],inputs:{_isTextSelector:[0,"matTextPrefix","_isTextSelector"]},features:[ce([{provide:Rg,useExisting:n}])]})}return n})(),Tg=new E("MatSuffix"),Tu=(()=>{class n{set _isTextSelector(e){this._isText=!0}_isText=!1;static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","matSuffix",""],["","matIconSuffix",""],["","matTextSuffix",""]],inputs:{_isTextSelector:[0,"matTextSuffix","_isTextSelector"]},features:[ce([{provide:Tg,useExisting:n}])]})}return n})(),Og=new E("FloatingLabelParent"),Eg=(()=>{class n{_elementRef=m(B);get floating(){return this._floating}set floating(e){this._floating=e,this.monitorResize&&this._handleResize()}_floating=!1;get monitorResize(){return this._monitorResize}set monitorResize(e){this._monitorResize=e,this._monitorResize?this._subscribeToResize():this._resizeSubscription.unsubscribe()}_monitorResize=!1;_resizeObserver=m(Tc);_ngZone=m(W);_parent=m(Og);_resizeSubscription=new Le;constructor(){}ngOnDestroy(){this._resizeSubscription.unsubscribe()}getWidth(){return AC(this._elementRef.nativeElement)}get element(){return this._elementRef.nativeElement}_handleResize(){setTimeout(()=>this._parent._handleLabelResized())}_subscribeToResize(){this._resizeSubscription.unsubscribe(),this._ngZone.runOutsideAngular(()=>{this._resizeSubscription=this._resizeObserver.observe(this._elementRef.nativeElement,{box:"border-box"}).subscribe(()=>this._handleResize())})}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["label","matFormFieldFloatingLabel",""]],hostAttrs:[1,"mdc-floating-label","mat-mdc-floating-label"],hostVars:2,hostBindings:function(t,a){t&2&&k("mdc-floating-label--float-above",a.floating)},inputs:{floating:"floating",monitorResize:"monitorResize"}})}return n})();function AC(n){let i=n;if(i.offsetParent!==null)return i.scrollWidth;let e=i.cloneNode(!0);e.style.setProperty("position","absolute"),e.style.setProperty("transform","translate(-9999px, -9999px)"),document.documentElement.appendChild(e);let t=e.scrollWidth;return e.remove(),t}var Sg="mdc-line-ripple--active",Oc="mdc-line-ripple--deactivating",kg=(()=>{class n{_elementRef=m(B);_cleanupTransitionEnd;constructor(){let e=m(W),t=m(Se);e.runOutsideAngular(()=>{this._cleanupTransitionEnd=t.listen(this._elementRef.nativeElement,"transitionend",this._handleTransitionEnd)})}activate(){let e=this._elementRef.nativeElement.classList;e.remove(Oc),e.add(Sg)}deactivate(){this._elementRef.nativeElement.classList.add(Oc)}_handleTransitionEnd=e=>{let t=this._elementRef.nativeElement.classList,a=t.contains(Oc);e.propertyName==="opacity"&&a&&t.remove(Sg,Oc)};ngOnDestroy(){this._cleanupTransitionEnd()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["div","matFormFieldLineRipple",""]],hostAttrs:[1,"mdc-line-ripple"]})}return n})(),Mg=(()=>{class n{_elementRef=m(B);_ngZone=m(W);open=!1;_notch;ngAfterViewInit(){let e=this._elementRef.nativeElement,t=e.querySelector(".mdc-floating-label");t?(e.classList.add("mdc-notched-outline--upgraded"),typeof requestAnimationFrame=="function"&&(t.style.transitionDuration="0s",this._ngZone.runOutsideAngular(()=>{requestAnimationFrame(()=>t.style.transitionDuration="")}))):e.classList.add("mdc-notched-outline--no-label")}_setNotchWidth(e){let t=this._notch.nativeElement;!this.open||!e?t.style.width="":t.style.width=`calc(${e}px * var(--mat-mdc-form-field-floating-label-scale, 0.75) + 9px)`}_setMaxWidth(e){this._notch.nativeElement.style.setProperty("--mat-form-field-notch-max-width",`calc(100% - ${e}px)`)}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["div","matFormFieldNotchedOutline",""]],viewQuery:function(t,a){if(t&1&&Ae(rC,5),t&2){let o;j(o=V())&&(a._notch=o.first)}},hostAttrs:[1,"mdc-notched-outline"],hostVars:2,hostBindings:function(t,a){t&2&&k("mdc-notched-outline--notched",a.open)},inputs:{open:[0,"matFormFieldNotchedOutlineOpen","open"]},attrs:sC,ngContentSelectors:cC,decls:5,vars:0,consts:[["notch",""],[1,"mat-mdc-notch-piece","mdc-notched-outline__leading"],[1,"mat-mdc-notch-piece","mdc-notched-outline__notch"],[1,"mat-mdc-notch-piece","mdc-notched-outline__trailing"]],template:function(t,a){t&1&&(ye(),yt(0,"div",1),Te(1,"div",2,0),ee(3),Be(),yt(4,"div",3))},encapsulation:2,changeDetection:0})}return n})(),Rr=(()=>{class n{value=null;stateChanges;id;placeholder;ngControl=null;focused=!1;empty=!1;shouldLabelFloat=!1;required=!1;disabled=!1;errorState=!1;controlType;autofilled;userAriaDescribedBy;disableAutomaticLabeling;describedByIds;static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n})}return n})();var Tr=new E("MatFormField"),RC=new E("MAT_FORM_FIELD_DEFAULT_OPTIONS"),Ig="fill",TC="auto",Ag="fixed",OC="translateY(-50%)",ln=(()=>{class n{_elementRef=m(B);_changeDetectorRef=m(Z);_platform=m(be);_idGenerator=m(xe);_ngZone=m(W);_defaults=m(RC,{optional:!0});_currentDirection;_textField;_iconPrefixContainer;_textPrefixContainer;_iconSuffixContainer;_textSuffixContainer;_floatingLabel;_notchedOutline;_lineRipple;_iconPrefixContainerSignal=Oo("iconPrefixContainer");_textPrefixContainerSignal=Oo("textPrefixContainer");_iconSuffixContainerSignal=Oo("iconSuffixContainer");_textSuffixContainerSignal=Oo("textSuffixContainer");_prefixSuffixContainers=Vt(()=>[this._iconPrefixContainerSignal(),this._textPrefixContainerSignal(),this._iconSuffixContainerSignal(),this._textSuffixContainerSignal()].map(e=>e?.nativeElement).filter(e=>e!==void 0));_formFieldControl;_prefixChildren;_suffixChildren;_errorChildren;_hintChildren;_labelChild=dp(Jt);get hideRequiredMarker(){return this._hideRequiredMarker}set hideRequiredMarker(e){this._hideRequiredMarker=ni(e)}_hideRequiredMarker=!1;color="primary";get floatLabel(){return this._floatLabel||this._defaults?.floatLabel||TC}set floatLabel(e){e!==this._floatLabel&&(this._floatLabel=e,this._changeDetectorRef.markForCheck())}_floatLabel;get appearance(){return this._appearanceSignal()}set appearance(e){let t=e||this._defaults?.appearance||Ig;this._appearanceSignal.set(t)}_appearanceSignal=le(Ig);get subscriptSizing(){return this._subscriptSizing||this._defaults?.subscriptSizing||Ag}set subscriptSizing(e){this._subscriptSizing=e||this._defaults?.subscriptSizing||Ag}_subscriptSizing=null;get hintLabel(){return this._hintLabel}set hintLabel(e){this._hintLabel=e,this._processHints()}_hintLabel="";_hasIconPrefix=!1;_hasTextPrefix=!1;_hasIconSuffix=!1;_hasTextSuffix=!1;_labelId=this._idGenerator.getId("mat-mdc-form-field-label-");_hintLabelId=this._idGenerator.getId("mat-mdc-hint-");_describedByIds;get _control(){return this._explicitFormFieldControl||this._formFieldControl}set _control(e){this._explicitFormFieldControl=e}_destroyed=new F;_isFocused=null;_explicitFormFieldControl;_previousControl=null;_previousControlValidatorFn=null;_stateChanges;_valueChanges;_describedByChanges;_outlineLabelOffsetResizeObserver=null;_animationsDisabled=Ee();constructor(){let e=this._defaults,t=m(Qe);e&&(e.appearance&&(this.appearance=e.appearance),this._hideRequiredMarker=!!e?.hideRequiredMarker,e.color&&(this.color=e.color)),qi(()=>this._currentDirection=t.valueSignal()),this._syncOutlineLabelOffset()}ngAfterViewInit(){this._updateFocusState(),this._animationsDisabled||this._ngZone.runOutsideAngular(()=>{setTimeout(()=>{this._elementRef.nativeElement.classList.add("mat-form-field-animations-enabled")},300)}),this._changeDetectorRef.detectChanges()}ngAfterContentInit(){this._assertFormFieldControl(),this._initializeSubscript(),this._initializePrefixAndSuffix()}ngAfterContentChecked(){this._assertFormFieldControl(),this._control!==this._previousControl&&(this._initializeControl(this._previousControl),this._control.ngControl&&this._control.ngControl.control&&(this._previousControlValidatorFn=this._control.ngControl.control.validator),this._previousControl=this._control),this._control.ngControl&&this._control.ngControl.control&&this._control.ngControl.control.validator!==this._previousControlValidatorFn&&this._changeDetectorRef.markForCheck()}ngOnDestroy(){this._outlineLabelOffsetResizeObserver?.disconnect(),this._stateChanges?.unsubscribe(),this._valueChanges?.unsubscribe(),this._describedByChanges?.unsubscribe(),this._destroyed.next(),this._destroyed.complete()}getLabelId=Vt(()=>this._hasFloatingLabel()?this._labelId:null);getConnectedOverlayOrigin(){return this._textField||this._elementRef}_animateAndLockLabel(){this._hasFloatingLabel()&&(this.floatLabel="always")}_initializeControl(e){let t=this._control,a="mat-mdc-form-field-type-";e&&this._elementRef.nativeElement.classList.remove(a+e.controlType),t.controlType&&this._elementRef.nativeElement.classList.add(a+t.controlType),this._stateChanges?.unsubscribe(),this._stateChanges=t.stateChanges.subscribe(()=>{this._updateFocusState(),this._changeDetectorRef.markForCheck()}),this._describedByChanges?.unsubscribe(),this._describedByChanges=t.stateChanges.pipe(tt([void 0,void 0]),Q(()=>[t.errorState,t.userAriaDescribedBy]),zl(),Ce(([[o,c],[u,p]])=>o!==u||c!==p)).subscribe(()=>this._syncDescribedByIds()),this._valueChanges?.unsubscribe(),t.ngControl&&t.ngControl.valueChanges&&(this._valueChanges=t.ngControl.valueChanges.pipe(pe(this._destroyed)).subscribe(()=>this._changeDetectorRef.markForCheck()))}_checkPrefixAndSuffixTypes(){this._hasIconPrefix=!!this._prefixChildren.find(e=>!e._isText),this._hasTextPrefix=!!this._prefixChildren.find(e=>e._isText),this._hasIconSuffix=!!this._suffixChildren.find(e=>!e._isText),this._hasTextSuffix=!!this._suffixChildren.find(e=>e._isText)}_initializePrefixAndSuffix(){this._checkPrefixAndSuffixTypes(),ut(this._prefixChildren.changes,this._suffixChildren.changes).subscribe(()=>{this._checkPrefixAndSuffixTypes(),this._changeDetectorRef.markForCheck()})}_initializeSubscript(){this._hintChildren.changes.subscribe(()=>{this._processHints(),this._changeDetectorRef.markForCheck()}),this._errorChildren.changes.subscribe(()=>{this._syncDescribedByIds(),this._changeDetectorRef.markForCheck()}),this._validateHints(),this._syncDescribedByIds()}_assertFormFieldControl(){this._control}_updateFocusState(){let e=this._control.focused;e&&!this._isFocused?(this._isFocused=!0,this._lineRipple?.activate()):!e&&(this._isFocused||this._isFocused===null)&&(this._isFocused=!1,this._lineRipple?.deactivate()),this._elementRef.nativeElement.classList.toggle("mat-focused",e),this._textField?.nativeElement.classList.toggle("mdc-text-field--focused",e)}_syncOutlineLabelOffset(){mp({earlyRead:()=>{if(this._appearanceSignal()!=="outline")return this._outlineLabelOffsetResizeObserver?.disconnect(),null;if(globalThis.ResizeObserver){this._outlineLabelOffsetResizeObserver||=new globalThis.ResizeObserver(()=>{this._writeOutlinedLabelStyles(this._getOutlinedLabelOffset())});for(let e of this._prefixSuffixContainers())this._outlineLabelOffsetResizeObserver.observe(e,{box:"border-box"})}return this._getOutlinedLabelOffset()},write:e=>this._writeOutlinedLabelStyles(e())})}_shouldAlwaysFloat(){return this.floatLabel==="always"}_hasOutline(){return this.appearance==="outline"}_forceDisplayInfixLabel(){return!this._platform.isBrowser&&this._prefixChildren.length&&!this._shouldLabelFloat()}_hasFloatingLabel=Vt(()=>!!this._labelChild());_shouldLabelFloat(){return this._hasFloatingLabel()?this._control.shouldLabelFloat||this._shouldAlwaysFloat():!1}_shouldForward(e){let t=this._control?this._control.ngControl:null;return t&&t[e]}_getSubscriptMessageType(){return this._errorChildren&&this._errorChildren.length>0&&this._control.errorState?"error":"hint"}_handleLabelResized(){this._refreshOutlineNotchWidth()}_refreshOutlineNotchWidth(){!this._hasOutline()||!this._floatingLabel||!this._shouldLabelFloat()?this._notchedOutline?._setNotchWidth(0):this._notchedOutline?._setNotchWidth(this._floatingLabel.getWidth())}_processHints(){this._validateHints(),this._syncDescribedByIds()}_validateHints(){this._hintChildren}_syncDescribedByIds(){if(this._control){let e=[];if(this._control.userAriaDescribedBy&&typeof this._control.userAriaDescribedBy=="string"&&e.push(...this._control.userAriaDescribedBy.split(" ")),this._getSubscriptMessageType()==="hint"){let o=this._hintChildren?this._hintChildren.find(u=>u.align==="start"):null,c=this._hintChildren?this._hintChildren.find(u=>u.align==="end"):null;o?e.push(o.id):this._hintLabel&&e.push(this._hintLabelId),c&&e.push(c.id)}else this._errorChildren&&e.push(...this._errorChildren.map(o=>o.id));let t=this._control.describedByIds,a;if(t){let o=this._describedByIds||e;a=e.concat(t.filter(c=>c&&!o.includes(c)))}else a=e;this._control.setDescribedByIds(a),this._describedByIds=e}}_getOutlinedLabelOffset(){if(!this._hasOutline()||!this._floatingLabel)return null;if(!this._iconPrefixContainer&&!this._textPrefixContainer)return["",null];if(!this._isAttachedToDom())return null;let e=this._iconPrefixContainer?.nativeElement,t=this._textPrefixContainer?.nativeElement,a=this._iconSuffixContainer?.nativeElement,o=this._textSuffixContainer?.nativeElement,c=e?.getBoundingClientRect().width??0,u=t?.getBoundingClientRect().width??0,p=a?.getBoundingClientRect().width??0,f=o?.getBoundingClientRect().width??0,b=this._currentDirection==="rtl"?"-1":"1",w=`${c+u}px`,$=`calc(${b} * (${w} + var(--mat-mdc-form-field-label-offset-x, 0px)))`,ae=`var(--mat-mdc-form-field-label-transform, ${OC} translateX(${$}))`,me=c+u+p+f;return[ae,me]}_writeOutlinedLabelStyles(e){if(e!==null){let[t,a]=e;this._floatingLabel&&(this._floatingLabel.element.style.transform=t),a!==null&&this._notchedOutline?._setMaxWidth(a)}}_isAttachedToDom(){let e=this._elementRef.nativeElement;if(e.getRootNode){let t=e.getRootNode();return t&&t!==e}return document.documentElement.contains(e)}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-form-field"]],contentQueries:function(t,a,o){if(t&1&&(tp(o,a._labelChild,Jt,5),st(o,Rr,5)(o,Rg,5)(o,Tg,5)(o,IC,5)(o,Ar,5)),t&2){Ql();let c;j(c=V())&&(a._formFieldControl=c.first),j(c=V())&&(a._prefixChildren=c),j(c=V())&&(a._suffixChildren=c),j(c=V())&&(a._errorChildren=c),j(c=V())&&(a._hintChildren=c)}},viewQuery:function(t,a){if(t&1&&(np(a._iconPrefixContainerSignal,xg,5)(a._textPrefixContainerSignal,Cg,5)(a._iconSuffixContainerSignal,wg,5)(a._textSuffixContainerSignal,Dg,5),Ae(lC,5)(xg,5)(Cg,5)(wg,5)(Dg,5)(Eg,5)(Mg,5)(kg,5)),t&2){Ql(4);let o;j(o=V())&&(a._textField=o.first),j(o=V())&&(a._iconPrefixContainer=o.first),j(o=V())&&(a._textPrefixContainer=o.first),j(o=V())&&(a._iconSuffixContainer=o.first),j(o=V())&&(a._textSuffixContainer=o.first),j(o=V())&&(a._floatingLabel=o.first),j(o=V())&&(a._notchedOutline=o.first),j(o=V())&&(a._lineRipple=o.first)}},hostAttrs:[1,"mat-mdc-form-field"],hostVars:38,hostBindings:function(t,a){t&2&&k("mat-mdc-form-field-label-always-float",a._shouldAlwaysFloat())("mat-mdc-form-field-has-icon-prefix",a._hasIconPrefix)("mat-mdc-form-field-has-icon-suffix",a._hasIconSuffix)("mat-form-field-invalid",a._control.errorState)("mat-form-field-disabled",a._control.disabled)("mat-form-field-autofilled",a._control.autofilled)("mat-form-field-appearance-fill",a.appearance=="fill")("mat-form-field-appearance-outline",a.appearance=="outline")("mat-form-field-hide-placeholder",a._hasFloatingLabel()&&!a._shouldLabelFloat())("mat-primary",a.color!=="accent"&&a.color!=="warn")("mat-accent",a.color==="accent")("mat-warn",a.color==="warn")("ng-untouched",a._shouldForward("untouched"))("ng-touched",a._shouldForward("touched"))("ng-pristine",a._shouldForward("pristine"))("ng-dirty",a._shouldForward("dirty"))("ng-valid",a._shouldForward("valid"))("ng-invalid",a._shouldForward("invalid"))("ng-pending",a._shouldForward("pending"))},inputs:{hideRequiredMarker:"hideRequiredMarker",color:"color",floatLabel:"floatLabel",appearance:"appearance",subscriptSizing:"subscriptSizing",hintLabel:"hintLabel"},exportAs:["matFormField"],features:[ce([{provide:Tr,useExisting:n},{provide:Og,useExisting:n}])],ngContentSelectors:uC,decls:18,vars:21,consts:[["labelTemplate",""],["textField",""],["iconPrefixContainer",""],["textPrefixContainer",""],["textSuffixContainer",""],["iconSuffixContainer",""],[1,"mat-mdc-text-field-wrapper","mdc-text-field",3,"click"],[1,"mat-mdc-form-field-focus-overlay"],[1,"mat-mdc-form-field-flex"],["matFormFieldNotchedOutline","",3,"matFormFieldNotchedOutlineOpen"],[1,"mat-mdc-form-field-icon-prefix"],[1,"mat-mdc-form-field-text-prefix"],[1,"mat-mdc-form-field-infix"],[3,"ngTemplateOutlet"],[1,"mat-mdc-form-field-text-suffix"],[1,"mat-mdc-form-field-icon-suffix"],["matFormFieldLineRipple",""],["aria-atomic","true","aria-live","polite",1,"mat-mdc-form-field-subscript-wrapper","mat-mdc-form-field-bottom-align"],[1,"mat-mdc-form-field-error-wrapper"],[1,"mat-mdc-form-field-hint-wrapper"],["matFormFieldFloatingLabel","",3,"floating","monitorResize","id"],["aria-hidden","true",1,"mat-mdc-form-field-required-marker","mdc-floating-label--required"],[3,"id"],[1,"mat-mdc-form-field-hint-spacer"]],template:function(t,a){if(t&1&&(ye(dC),_e(0,hC,1,1,"ng-template",null,0,Ia),s(2,"div",6,1),_("click",function(c){return a._control.onContainerClick(c)}),v(4,fC,1,0,"div",7),s(5,"div",8),v(6,bC,2,2,"div",9),v(7,vC,3,0,"div",10),v(8,yC,3,0,"div",11),s(9,"div",12),v(10,CC,1,1,null,13),ee(11),r(),v(12,wC,3,0,"div",14),v(13,DC,3,0,"div",15),r(),v(14,EC,1,0,"div",16),r(),s(15,"div",17),v(16,SC,2,0,"div",18)(17,MC,5,1,"div",19),r()),t&2){let o;d(2),k("mdc-text-field--filled",!a._hasOutline())("mdc-text-field--outlined",a._hasOutline())("mdc-text-field--no-label",!a._hasFloatingLabel())("mdc-text-field--disabled",a._control.disabled)("mdc-text-field--invalid",a._control.errorState),d(2),y(!a._hasOutline()&&!a._control.disabled?4:-1),d(2),y(a._hasOutline()?6:-1),d(),y(a._hasIconPrefix?7:-1),d(),y(a._hasTextPrefix?8:-1),d(2),y(!a._hasOutline()||a._forceDisplayInfixLabel()?10:-1),d(2),y(a._hasTextSuffix?12:-1),d(),y(a._hasIconSuffix?13:-1),d(),y(a._hasOutline()?-1:14),d(),k("mat-mdc-form-field-subscript-dynamic-size",a.subscriptSizing==="dynamic");let c=a._getSubscriptMessageType();d(),y((o=c)==="error"?16:o==="hint"?17:-1)}},dependencies:[Eg,Mg,Qi,kg,Ar],styles:[`.mdc-text-field {
  display: inline-flex;
  align-items: baseline;
  padding: 0 16px;
  position: relative;
  box-sizing: border-box;
  overflow: hidden;
  will-change: opacity, transform, color;
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}

.mdc-text-field__input {
  width: 100%;
  min-width: 0;
  border: none;
  border-radius: 0;
  background: none;
  padding: 0;
  -moz-appearance: none;
  -webkit-appearance: none;
  height: 28px;
}
.mdc-text-field__input::-webkit-calendar-picker-indicator, .mdc-text-field__input::-webkit-search-cancel-button {
  display: none;
}
.mdc-text-field__input::-ms-clear {
  display: none;
}
.mdc-text-field__input:focus {
  outline: none;
}
.mdc-text-field__input:invalid {
  box-shadow: none;
}
.mdc-text-field__input::placeholder {
  opacity: 0;
}
.mdc-text-field__input::-moz-placeholder {
  opacity: 0;
}
.mdc-text-field__input::-webkit-input-placeholder {
  opacity: 0;
}
.mdc-text-field__input:-ms-input-placeholder {
  opacity: 0;
}
.mdc-text-field--no-label .mdc-text-field__input::placeholder, .mdc-text-field--focused .mdc-text-field__input::placeholder {
  opacity: 1;
}
.mdc-text-field--no-label .mdc-text-field__input::-moz-placeholder, .mdc-text-field--focused .mdc-text-field__input::-moz-placeholder {
  opacity: 1;
}
.mdc-text-field--no-label .mdc-text-field__input::-webkit-input-placeholder, .mdc-text-field--focused .mdc-text-field__input::-webkit-input-placeholder {
  opacity: 1;
}
.mdc-text-field--no-label .mdc-text-field__input:-ms-input-placeholder, .mdc-text-field--focused .mdc-text-field__input:-ms-input-placeholder {
  opacity: 1;
}
.mdc-text-field--disabled:not(.mdc-text-field--no-label) .mdc-text-field__input.mat-mdc-input-disabled-interactive::placeholder {
  opacity: 0;
}
.mdc-text-field--disabled:not(.mdc-text-field--no-label) .mdc-text-field__input.mat-mdc-input-disabled-interactive::-moz-placeholder {
  opacity: 0;
}
.mdc-text-field--disabled:not(.mdc-text-field--no-label) .mdc-text-field__input.mat-mdc-input-disabled-interactive::-webkit-input-placeholder {
  opacity: 0;
}
.mdc-text-field--disabled:not(.mdc-text-field--no-label) .mdc-text-field__input.mat-mdc-input-disabled-interactive:-ms-input-placeholder {
  opacity: 0;
}
.mdc-text-field--outlined .mdc-text-field__input, .mdc-text-field--filled.mdc-text-field--no-label .mdc-text-field__input {
  height: 100%;
}
.mdc-text-field--outlined .mdc-text-field__input {
  display: flex;
  border: none !important;
  background-color: transparent;
}
.mdc-text-field--disabled .mdc-text-field__input {
  pointer-events: auto;
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-text-field__input {
  color: var(--mat-form-field-filled-input-text-color, var(--mat-sys-on-surface));
  caret-color: var(--mat-form-field-filled-caret-color, var(--mat-sys-primary));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-text-field__input::placeholder {
  color: var(--mat-form-field-filled-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-text-field__input::-moz-placeholder {
  color: var(--mat-form-field-filled-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-text-field__input::-webkit-input-placeholder {
  color: var(--mat-form-field-filled-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-text-field__input:-ms-input-placeholder {
  color: var(--mat-form-field-filled-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-text-field__input {
  color: var(--mat-form-field-outlined-input-text-color, var(--mat-sys-on-surface));
  caret-color: var(--mat-form-field-outlined-caret-color, var(--mat-sys-primary));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-text-field__input::placeholder {
  color: var(--mat-form-field-outlined-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-text-field__input::-moz-placeholder {
  color: var(--mat-form-field-outlined-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-text-field__input::-webkit-input-placeholder {
  color: var(--mat-form-field-outlined-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-text-field__input:-ms-input-placeholder {
  color: var(--mat-form-field-outlined-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled.mdc-text-field--invalid:not(.mdc-text-field--disabled) .mdc-text-field__input {
  caret-color: var(--mat-form-field-filled-error-caret-color, var(--mat-sys-error));
}
.mdc-text-field--outlined.mdc-text-field--invalid:not(.mdc-text-field--disabled) .mdc-text-field__input {
  caret-color: var(--mat-form-field-outlined-error-caret-color, var(--mat-sys-error));
}
.mdc-text-field--filled.mdc-text-field--disabled .mdc-text-field__input {
  color: var(--mat-form-field-filled-disabled-input-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mdc-text-field--outlined.mdc-text-field--disabled .mdc-text-field__input {
  color: var(--mat-form-field-outlined-disabled-input-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mdc-text-field--disabled .mdc-text-field__input {
    background-color: Window;
  }
}

.mdc-text-field--filled {
  height: 56px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
  border-top-left-radius: var(--mat-form-field-filled-container-shape, var(--mat-sys-corner-extra-small));
  border-top-right-radius: var(--mat-form-field-filled-container-shape, var(--mat-sys-corner-extra-small));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) {
  background-color: var(--mat-form-field-filled-container-color, var(--mat-sys-surface-variant));
}
.mdc-text-field--filled.mdc-text-field--disabled {
  background-color: var(--mat-form-field-filled-disabled-container-color, color-mix(in srgb, var(--mat-sys-on-surface) 4%, transparent));
}

.mdc-text-field--outlined {
  height: 56px;
  overflow: visible;
  padding-right: max(16px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small)));
  padding-left: max(16px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small)) + 4px);
}
[dir=rtl] .mdc-text-field--outlined {
  padding-right: max(16px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small)) + 4px);
  padding-left: max(16px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small)));
}

.mdc-floating-label {
  position: absolute;
  left: 0;
  transform-origin: left top;
  line-height: 1.15rem;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: text;
  overflow: hidden;
  will-change: transform;
}
[dir=rtl] .mdc-floating-label {
  right: 0;
  left: auto;
  transform-origin: right top;
  text-align: right;
}
.mdc-text-field .mdc-floating-label {
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
}
.mdc-notched-outline .mdc-floating-label {
  display: inline-block;
  position: relative;
  max-width: 100%;
}
.mdc-text-field--outlined .mdc-floating-label {
  left: 4px;
  right: auto;
}
[dir=rtl] .mdc-text-field--outlined .mdc-floating-label {
  left: auto;
  right: 4px;
}
.mdc-text-field--filled .mdc-floating-label {
  left: 16px;
  right: auto;
}
[dir=rtl] .mdc-text-field--filled .mdc-floating-label {
  left: auto;
  right: 16px;
}
.mdc-text-field--disabled .mdc-floating-label {
  cursor: default;
}
@media (forced-colors: active) {
  .mdc-text-field--disabled .mdc-floating-label {
    z-index: 1;
  }
}
.mdc-text-field--filled.mdc-text-field--no-label .mdc-floating-label {
  display: none;
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-floating-label {
  color: var(--mat-form-field-filled-label-text-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled).mdc-text-field--focused .mdc-floating-label {
  color: var(--mat-form-field-filled-focus-label-text-color, var(--mat-sys-primary));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled):not(.mdc-text-field--focused):hover .mdc-floating-label {
  color: var(--mat-form-field-filled-hover-label-text-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled.mdc-text-field--disabled .mdc-floating-label {
  color: var(--mat-form-field-filled-disabled-label-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled).mdc-text-field--invalid .mdc-floating-label {
  color: var(--mat-form-field-filled-error-label-text-color, var(--mat-sys-error));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled).mdc-text-field--invalid.mdc-text-field--focused .mdc-floating-label {
  color: var(--mat-form-field-filled-error-focus-label-text-color, var(--mat-sys-error));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled).mdc-text-field--invalid:not(.mdc-text-field--disabled):hover .mdc-floating-label {
  color: var(--mat-form-field-filled-error-hover-label-text-color, var(--mat-sys-on-error-container));
}
.mdc-text-field--filled .mdc-floating-label {
  font-family: var(--mat-form-field-filled-label-text-font, var(--mat-sys-body-large-font));
  font-size: var(--mat-form-field-filled-label-text-size, var(--mat-sys-body-large-size));
  font-weight: var(--mat-form-field-filled-label-text-weight, var(--mat-sys-body-large-weight));
  letter-spacing: var(--mat-form-field-filled-label-text-tracking, var(--mat-sys-body-large-tracking));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-floating-label {
  color: var(--mat-form-field-outlined-label-text-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--focused .mdc-floating-label {
  color: var(--mat-form-field-outlined-focus-label-text-color, var(--mat-sys-primary));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled):not(.mdc-text-field--focused):hover .mdc-floating-label {
  color: var(--mat-form-field-outlined-hover-label-text-color, var(--mat-sys-on-surface));
}
.mdc-text-field--outlined.mdc-text-field--disabled .mdc-floating-label {
  color: var(--mat-form-field-outlined-disabled-label-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--invalid .mdc-floating-label {
  color: var(--mat-form-field-outlined-error-label-text-color, var(--mat-sys-error));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--invalid.mdc-text-field--focused .mdc-floating-label {
  color: var(--mat-form-field-outlined-error-focus-label-text-color, var(--mat-sys-error));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--invalid:not(.mdc-text-field--disabled):hover .mdc-floating-label {
  color: var(--mat-form-field-outlined-error-hover-label-text-color, var(--mat-sys-on-error-container));
}
.mdc-text-field--outlined .mdc-floating-label {
  font-family: var(--mat-form-field-outlined-label-text-font, var(--mat-sys-body-large-font));
  font-size: var(--mat-form-field-outlined-label-text-size, var(--mat-sys-body-large-size));
  font-weight: var(--mat-form-field-outlined-label-text-weight, var(--mat-sys-body-large-weight));
  letter-spacing: var(--mat-form-field-outlined-label-text-tracking, var(--mat-sys-body-large-tracking));
}

.mdc-floating-label--float-above {
  cursor: auto;
  transform: translateY(-106%) scale(0.75);
}
.mdc-text-field--filled .mdc-floating-label--float-above {
  transform: translateY(-106%) scale(0.75);
}
.mdc-text-field--outlined .mdc-floating-label--float-above {
  transform: translateY(-37.25px) scale(1);
  font-size: 0.75rem;
}
.mdc-notched-outline .mdc-floating-label--float-above {
  text-overflow: clip;
}
.mdc-notched-outline--upgraded .mdc-floating-label--float-above {
  max-width: 133.3333333333%;
}
.mdc-text-field--outlined.mdc-notched-outline--upgraded .mdc-floating-label--float-above, .mdc-text-field--outlined .mdc-notched-outline--upgraded .mdc-floating-label--float-above {
  transform: translateY(-34.75px) scale(0.75);
}
.mdc-text-field--outlined.mdc-notched-outline--upgraded .mdc-floating-label--float-above, .mdc-text-field--outlined .mdc-notched-outline--upgraded .mdc-floating-label--float-above {
  font-size: 1rem;
}

.mdc-floating-label--required:not(.mdc-floating-label--hide-required-marker)::after {
  margin-left: 1px;
  margin-right: 0;
  content: "*";
}
[dir=rtl] .mdc-floating-label--required:not(.mdc-floating-label--hide-required-marker)::after {
  margin-left: 0;
  margin-right: 1px;
}

.mdc-notched-outline {
  display: flex;
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  box-sizing: border-box;
  width: 100%;
  max-width: 100%;
  height: 100%;
  text-align: left;
  pointer-events: none;
}
[dir=rtl] .mdc-notched-outline {
  text-align: right;
}
.mdc-text-field--outlined .mdc-notched-outline {
  z-index: 1;
}

.mat-mdc-notch-piece {
  box-sizing: border-box;
  height: 100%;
  pointer-events: none;
  border: none;
  border-top: 1px solid;
  border-bottom: 1px solid;
}
.mdc-text-field--focused .mat-mdc-notch-piece {
  border-width: 2px;
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-outline-color, var(--mat-sys-outline));
  border-width: var(--mat-form-field-outlined-outline-width, 1px);
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled):not(.mdc-text-field--focused):hover .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-hover-outline-color, var(--mat-sys-on-surface));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--focused .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-focus-outline-color, var(--mat-sys-primary));
}
.mdc-text-field--outlined.mdc-text-field--disabled .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-disabled-outline-color, color-mix(in srgb, var(--mat-sys-on-surface) 12%, transparent));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--invalid .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-error-outline-color, var(--mat-sys-error));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--invalid:not(.mdc-text-field--focused):hover .mdc-notched-outline .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-error-hover-outline-color, var(--mat-sys-on-error-container));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--invalid.mdc-text-field--focused .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-error-focus-outline-color, var(--mat-sys-error));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--focused .mdc-notched-outline .mat-mdc-notch-piece {
  border-width: var(--mat-form-field-outlined-focus-outline-width, 2px);
}

.mdc-notched-outline__leading {
  border-left: 1px solid;
  border-right: none;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  border-top-left-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
  border-bottom-left-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
}
.mdc-text-field--outlined .mdc-notched-outline .mdc-notched-outline__leading {
  width: max(12px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small)));
}
[dir=rtl] .mdc-notched-outline__leading {
  border-left: none;
  border-right: 1px solid;
  border-bottom-left-radius: 0;
  border-top-left-radius: 0;
  border-top-right-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
  border-bottom-right-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
}

.mdc-notched-outline__trailing {
  flex-grow: 1;
  border-left: none;
  border-right: 1px solid;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  border-top-right-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
  border-bottom-right-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
}
[dir=rtl] .mdc-notched-outline__trailing {
  border-left: 1px solid;
  border-right: none;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  border-top-left-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
  border-bottom-left-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
}

.mdc-notched-outline__notch {
  flex: 0 0 auto;
  width: auto;
}
.mdc-text-field--outlined .mdc-notched-outline .mdc-notched-outline__notch {
  max-width: min(var(--mat-form-field-notch-max-width, 100%), calc(100% - max(12px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small))) * 2));
}
.mdc-text-field--outlined .mdc-notched-outline--notched .mdc-notched-outline__notch {
  max-width: min(100%, calc(100% - max(12px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small))) * 2));
}
.mdc-text-field--outlined .mdc-notched-outline--notched .mdc-notched-outline__notch {
  padding-top: 1px;
}
.mdc-text-field--focused.mdc-text-field--outlined .mdc-notched-outline--notched .mdc-notched-outline__notch {
  padding-top: 2px;
}
.mdc-notched-outline--notched .mdc-notched-outline__notch {
  padding-left: 0;
  padding-right: 8px;
  border-top: none;
}
[dir=rtl] .mdc-notched-outline--notched .mdc-notched-outline__notch {
  padding-left: 8px;
  padding-right: 0;
}
.mdc-notched-outline--no-label .mdc-notched-outline__notch {
  display: none;
}

.mdc-line-ripple::before, .mdc-line-ripple::after {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  border-bottom-style: solid;
  content: "";
}
.mdc-line-ripple::before {
  z-index: 1;
  border-bottom-width: var(--mat-form-field-filled-active-indicator-height, 1px);
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-line-ripple::before {
  border-bottom-color: var(--mat-form-field-filled-active-indicator-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled):not(.mdc-text-field--focused):hover .mdc-line-ripple::before {
  border-bottom-color: var(--mat-form-field-filled-hover-active-indicator-color, var(--mat-sys-on-surface));
}
.mdc-text-field--filled.mdc-text-field--disabled .mdc-line-ripple::before {
  border-bottom-color: var(--mat-form-field-filled-disabled-active-indicator-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled).mdc-text-field--invalid .mdc-line-ripple::before {
  border-bottom-color: var(--mat-form-field-filled-error-active-indicator-color, var(--mat-sys-error));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled).mdc-text-field--invalid:not(.mdc-text-field--focused):hover .mdc-line-ripple::before {
  border-bottom-color: var(--mat-form-field-filled-error-hover-active-indicator-color, var(--mat-sys-on-error-container));
}
.mdc-line-ripple::after {
  transform: scaleX(0);
  opacity: 0;
  z-index: 2;
}
.mdc-text-field--filled .mdc-line-ripple::after {
  border-bottom-width: var(--mat-form-field-filled-focus-active-indicator-height, 2px);
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-line-ripple::after {
  border-bottom-color: var(--mat-form-field-filled-focus-active-indicator-color, var(--mat-sys-primary));
}
.mdc-text-field--filled.mdc-text-field--invalid:not(.mdc-text-field--disabled) .mdc-line-ripple::after {
  border-bottom-color: var(--mat-form-field-filled-error-focus-active-indicator-color, var(--mat-sys-error));
}

.mdc-line-ripple--active::after {
  transform: scaleX(1);
  opacity: 1;
}

.mdc-line-ripple--deactivating::after {
  opacity: 0;
}

.mdc-text-field--disabled {
  pointer-events: none;
}

.mat-mdc-form-field-textarea-control {
  vertical-align: middle;
  resize: vertical;
  box-sizing: border-box;
  height: auto;
  margin: 0;
  padding: 0;
  border: none;
  overflow: auto;
}

.mat-mdc-form-field-input-control.mat-mdc-form-field-input-control {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  font: inherit;
  letter-spacing: inherit;
  text-decoration: inherit;
  text-transform: inherit;
  border: none;
}

.mat-mdc-form-field .mat-mdc-floating-label.mdc-floating-label {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  line-height: normal;
  pointer-events: all;
  will-change: auto;
}

.mat-mdc-form-field:not(.mat-form-field-disabled) .mat-mdc-floating-label.mdc-floating-label {
  cursor: inherit;
}

.mdc-text-field--no-label:not(.mdc-text-field--textarea) .mat-mdc-form-field-input-control.mdc-text-field__input,
.mat-mdc-text-field-wrapper .mat-mdc-form-field-input-control {
  height: auto;
}

.mat-mdc-text-field-wrapper .mat-mdc-form-field-input-control.mdc-text-field__input[type=color] {
  height: 23px;
}

.mat-mdc-text-field-wrapper {
  height: auto;
  flex: auto;
  will-change: auto;
}

.mat-mdc-form-field-has-icon-prefix .mat-mdc-text-field-wrapper {
  padding-left: 0;
  --mat-mdc-form-field-label-offset-x: -16px;
}

.mat-mdc-form-field-has-icon-suffix .mat-mdc-text-field-wrapper {
  padding-right: 0;
}

[dir=rtl] .mat-mdc-text-field-wrapper {
  padding-left: 16px;
  padding-right: 16px;
}
[dir=rtl] .mat-mdc-form-field-has-icon-suffix .mat-mdc-text-field-wrapper {
  padding-left: 0;
}
[dir=rtl] .mat-mdc-form-field-has-icon-prefix .mat-mdc-text-field-wrapper {
  padding-right: 0;
}

.mat-form-field-disabled .mdc-text-field__input::placeholder {
  color: var(--mat-form-field-disabled-input-text-placeholder-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-form-field-disabled .mdc-text-field__input::-moz-placeholder {
  color: var(--mat-form-field-disabled-input-text-placeholder-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-form-field-disabled .mdc-text-field__input::-webkit-input-placeholder {
  color: var(--mat-form-field-disabled-input-text-placeholder-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-form-field-disabled .mdc-text-field__input:-ms-input-placeholder {
  color: var(--mat-form-field-disabled-input-text-placeholder-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}

.mat-mdc-form-field-label-always-float .mdc-text-field__input::placeholder {
  transition-delay: 40ms;
  transition-duration: 110ms;
  opacity: 1;
}

.mat-mdc-text-field-wrapper .mat-mdc-form-field-infix .mat-mdc-floating-label {
  left: auto;
  right: auto;
}

.mat-mdc-text-field-wrapper.mdc-text-field--outlined .mdc-text-field__input {
  display: inline-block;
}

.mat-mdc-form-field .mat-mdc-text-field-wrapper.mdc-text-field .mdc-notched-outline__notch {
  padding-top: 0;
}

.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field .mdc-notched-outline__notch {
  border-left: 1px solid transparent;
}

[dir=rtl] .mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field .mdc-notched-outline__notch {
  border-left: none;
  border-right: 1px solid transparent;
}

.mat-mdc-form-field-infix {
  min-height: var(--mat-form-field-container-height, 56px);
  padding-top: var(--mat-form-field-filled-with-label-container-padding-top, 24px);
  padding-bottom: var(--mat-form-field-filled-with-label-container-padding-bottom, 8px);
}
.mdc-text-field--outlined .mat-mdc-form-field-infix, .mdc-text-field--no-label .mat-mdc-form-field-infix {
  padding-top: var(--mat-form-field-container-vertical-padding, 16px);
  padding-bottom: var(--mat-form-field-container-vertical-padding, 16px);
}

.mat-mdc-text-field-wrapper .mat-mdc-form-field-flex .mat-mdc-floating-label {
  top: calc(var(--mat-form-field-container-height, 56px) / 2);
}

.mdc-text-field--filled .mat-mdc-floating-label {
  display: var(--mat-form-field-filled-label-display, block);
}

.mat-mdc-text-field-wrapper.mdc-text-field--outlined .mdc-notched-outline--upgraded .mdc-floating-label--float-above {
  --mat-mdc-form-field-label-transform: translateY(calc(calc(6.75px + var(--mat-form-field-container-height, 56px) / 2) * -1))
    scale(var(--mat-mdc-form-field-floating-label-scale, 0.75));
  transform: var(--mat-mdc-form-field-label-transform);
}

@keyframes _mat-form-field-subscript-animation {
  from {
    opacity: 0;
    transform: translateY(-5px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
.mat-mdc-form-field-subscript-wrapper {
  box-sizing: border-box;
  width: 100%;
  position: relative;
}

.mat-mdc-form-field-hint-wrapper,
.mat-mdc-form-field-error-wrapper {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  padding: 0 16px;
  opacity: 1;
  transform: translateY(0);
  animation: _mat-form-field-subscript-animation 0ms cubic-bezier(0.55, 0, 0.55, 0.2);
}

.mat-mdc-form-field-subscript-dynamic-size .mat-mdc-form-field-hint-wrapper,
.mat-mdc-form-field-subscript-dynamic-size .mat-mdc-form-field-error-wrapper {
  position: static;
}

.mat-mdc-form-field-bottom-align::before {
  content: "";
  display: inline-block;
  height: 16px;
}

.mat-mdc-form-field-bottom-align.mat-mdc-form-field-subscript-dynamic-size::before {
  content: unset;
}

.mat-mdc-form-field-hint-end {
  order: 1;
}

.mat-mdc-form-field-hint-wrapper {
  display: flex;
}

.mat-mdc-form-field-hint-spacer {
  flex: 1 0 1em;
}

.mat-mdc-form-field-error {
  display: block;
  color: var(--mat-form-field-error-text-color, var(--mat-sys-error));
}

.mat-mdc-form-field-subscript-wrapper,
.mat-mdc-form-field-bottom-align::before {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  font-family: var(--mat-form-field-subscript-text-font, var(--mat-sys-body-small-font));
  line-height: var(--mat-form-field-subscript-text-line-height, var(--mat-sys-body-small-line-height));
  font-size: var(--mat-form-field-subscript-text-size, var(--mat-sys-body-small-size));
  letter-spacing: var(--mat-form-field-subscript-text-tracking, var(--mat-sys-body-small-tracking));
  font-weight: var(--mat-form-field-subscript-text-weight, var(--mat-sys-body-small-weight));
}

.mat-mdc-form-field-focus-overlay {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  opacity: 0;
  pointer-events: none;
  background-color: var(--mat-form-field-state-layer-color, var(--mat-sys-on-surface));
}
.mat-mdc-text-field-wrapper:hover .mat-mdc-form-field-focus-overlay {
  opacity: var(--mat-form-field-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mat-mdc-form-field.mat-focused .mat-mdc-form-field-focus-overlay {
  opacity: var(--mat-form-field-focus-state-layer-opacity, 0);
}

select.mat-mdc-form-field-input-control {
  -moz-appearance: none;
  -webkit-appearance: none;
  background-color: transparent;
  display: inline-flex;
  box-sizing: border-box;
}
select.mat-mdc-form-field-input-control:not(:disabled) {
  cursor: pointer;
}
select.mat-mdc-form-field-input-control:not(.mat-mdc-native-select-inline) option {
  color: var(--mat-form-field-select-option-text-color, var(--mat-sys-neutral10));
}
select.mat-mdc-form-field-input-control:not(.mat-mdc-native-select-inline) option:disabled {
  color: var(--mat-form-field-select-disabled-option-text-color, color-mix(in srgb, var(--mat-sys-neutral10) 38%, transparent));
}

.mat-mdc-form-field-type-mat-native-select .mat-mdc-form-field-infix::after {
  content: "";
  width: 0;
  height: 0;
  border-left: 5px solid transparent;
  border-right: 5px solid transparent;
  border-top: 5px solid;
  position: absolute;
  right: 0;
  top: 50%;
  margin-top: -2.5px;
  pointer-events: none;
  color: var(--mat-form-field-enabled-select-arrow-color, var(--mat-sys-on-surface-variant));
}
[dir=rtl] .mat-mdc-form-field-type-mat-native-select .mat-mdc-form-field-infix::after {
  right: auto;
  left: 0;
}
.mat-mdc-form-field-type-mat-native-select.mat-focused .mat-mdc-form-field-infix::after {
  color: var(--mat-form-field-focus-select-arrow-color, var(--mat-sys-primary));
}
.mat-mdc-form-field-type-mat-native-select.mat-form-field-disabled .mat-mdc-form-field-infix::after {
  color: var(--mat-form-field-disabled-select-arrow-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-mdc-form-field-type-mat-native-select .mat-mdc-form-field-input-control {
  padding-right: 15px;
}
[dir=rtl] .mat-mdc-form-field-type-mat-native-select .mat-mdc-form-field-input-control {
  padding-right: 0;
  padding-left: 15px;
}

@media (forced-colors: active) {
  .mat-form-field-appearance-fill .mat-mdc-text-field-wrapper {
    outline: solid 1px;
  }
}
@media (forced-colors: active) {
  .mat-form-field-appearance-fill.mat-form-field-disabled .mat-mdc-text-field-wrapper {
    outline-color: GrayText;
  }
}

@media (forced-colors: active) {
  .mat-form-field-appearance-fill.mat-focused .mat-mdc-text-field-wrapper {
    outline: dashed 3px;
  }
}

@media (forced-colors: active) {
  .mat-mdc-form-field.mat-focused .mdc-notched-outline {
    border: dashed 3px;
  }
}

.mat-mdc-form-field-input-control[type=date], .mat-mdc-form-field-input-control[type=datetime], .mat-mdc-form-field-input-control[type=datetime-local], .mat-mdc-form-field-input-control[type=month], .mat-mdc-form-field-input-control[type=week], .mat-mdc-form-field-input-control[type=time] {
  line-height: 1;
}
.mat-mdc-form-field-input-control::-webkit-datetime-edit {
  line-height: 1;
  padding: 0;
  margin-bottom: -2px;
}

.mat-mdc-form-field {
  --mat-mdc-form-field-floating-label-scale: 0.75;
  display: inline-flex;
  flex-direction: column;
  min-width: 0;
  text-align: left;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  font-family: var(--mat-form-field-container-text-font, var(--mat-sys-body-large-font));
  line-height: var(--mat-form-field-container-text-line-height, var(--mat-sys-body-large-line-height));
  font-size: var(--mat-form-field-container-text-size, var(--mat-sys-body-large-size));
  letter-spacing: var(--mat-form-field-container-text-tracking, var(--mat-sys-body-large-tracking));
  font-weight: var(--mat-form-field-container-text-weight, var(--mat-sys-body-large-weight));
}
.mat-mdc-form-field .mdc-text-field--outlined .mdc-floating-label--float-above {
  font-size: calc(var(--mat-form-field-outlined-label-text-populated-size) * var(--mat-mdc-form-field-floating-label-scale));
}
.mat-mdc-form-field .mdc-text-field--outlined .mdc-notched-outline--upgraded .mdc-floating-label--float-above {
  font-size: var(--mat-form-field-outlined-label-text-populated-size);
}
[dir=rtl] .mat-mdc-form-field {
  text-align: right;
}

.mat-mdc-form-field-flex {
  display: inline-flex;
  align-items: baseline;
  box-sizing: border-box;
  width: 100%;
}

.mat-mdc-text-field-wrapper {
  width: 100%;
  z-index: 0;
}

.mat-mdc-form-field-icon-prefix,
.mat-mdc-form-field-icon-suffix {
  align-self: center;
  line-height: 0;
  pointer-events: auto;
  position: relative;
  z-index: 1;
}
.mat-mdc-form-field-icon-prefix > .mat-icon,
.mat-mdc-form-field-icon-suffix > .mat-icon {
  padding: 0 12px;
  box-sizing: content-box;
}

.mat-mdc-form-field-icon-prefix {
  color: var(--mat-form-field-leading-icon-color, var(--mat-sys-on-surface-variant));
}
.mat-form-field-disabled .mat-mdc-form-field-icon-prefix {
  color: var(--mat-form-field-disabled-leading-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}

.mat-mdc-form-field-icon-suffix {
  color: var(--mat-form-field-trailing-icon-color, var(--mat-sys-on-surface-variant));
}
.mat-form-field-disabled .mat-mdc-form-field-icon-suffix {
  color: var(--mat-form-field-disabled-trailing-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-form-field-invalid .mat-mdc-form-field-icon-suffix {
  color: var(--mat-form-field-error-trailing-icon-color, var(--mat-sys-error));
}
.mat-form-field-invalid:not(.mat-focused):not(.mat-form-field-disabled) .mat-mdc-text-field-wrapper:hover .mat-mdc-form-field-icon-suffix {
  color: var(--mat-form-field-error-hover-trailing-icon-color, var(--mat-sys-on-error-container));
}
.mat-form-field-invalid.mat-focused .mat-mdc-text-field-wrapper .mat-mdc-form-field-icon-suffix {
  color: var(--mat-form-field-error-focus-trailing-icon-color, var(--mat-sys-error));
}

.mat-mdc-form-field-icon-prefix,
[dir=rtl] .mat-mdc-form-field-icon-suffix {
  padding: 0 4px 0 0;
}

.mat-mdc-form-field-icon-suffix,
[dir=rtl] .mat-mdc-form-field-icon-prefix {
  padding: 0 0 0 4px;
}

.mat-mdc-form-field-subscript-wrapper .mat-icon,
.mat-mdc-form-field label .mat-icon {
  width: 1em;
  height: 1em;
  font-size: inherit;
}

.mat-mdc-form-field-infix {
  flex: auto;
  min-width: 0;
  width: 180px;
  position: relative;
  box-sizing: border-box;
}
.mat-mdc-form-field-infix:has(textarea[cols]) {
  width: auto;
}

.mat-mdc-form-field .mdc-notched-outline__notch {
  margin-left: -1px;
  -webkit-clip-path: inset(-9em -999em -9em 1px);
  clip-path: inset(-9em -999em -9em 1px);
}
[dir=rtl] .mat-mdc-form-field .mdc-notched-outline__notch {
  margin-left: 0;
  margin-right: -1px;
  -webkit-clip-path: inset(-9em 1px -9em -999em);
  clip-path: inset(-9em 1px -9em -999em);
}

.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-floating-label {
  transition: transform 150ms cubic-bezier(0.4, 0, 0.2, 1), color 150ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-text-field__input {
  transition: opacity 150ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-text-field__input::placeholder {
  transition: opacity 67ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-text-field__input::-moz-placeholder {
  transition: opacity 67ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-text-field__input::-webkit-input-placeholder {
  transition: opacity 67ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-text-field__input:-ms-input-placeholder {
  transition: opacity 67ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--no-label .mdc-text-field__input::placeholder, .mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--focused .mdc-text-field__input::placeholder {
  transition-delay: 40ms;
  transition-duration: 110ms;
}
.mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--no-label .mdc-text-field__input::-moz-placeholder, .mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--focused .mdc-text-field__input::-moz-placeholder {
  transition-delay: 40ms;
  transition-duration: 110ms;
}
.mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--no-label .mdc-text-field__input::-webkit-input-placeholder, .mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--focused .mdc-text-field__input::-webkit-input-placeholder {
  transition-delay: 40ms;
  transition-duration: 110ms;
}
.mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--no-label .mdc-text-field__input:-ms-input-placeholder, .mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--focused .mdc-text-field__input:-ms-input-placeholder {
  transition-delay: 40ms;
  transition-duration: 110ms;
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-text-field--filled:not(.mdc-ripple-upgraded):focus .mdc-text-field__ripple::before {
  transition-duration: 75ms;
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-line-ripple::after {
  transition: transform 180ms cubic-bezier(0.4, 0, 0.2, 1), opacity 180ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mat-mdc-form-field-hint-wrapper,
.mat-mdc-form-field.mat-form-field-animations-enabled .mat-mdc-form-field-error-wrapper {
  animation-duration: 300ms;
}

.mdc-notched-outline .mdc-floating-label {
  max-width: calc(100% + 1px);
}

.mdc-notched-outline--upgraded .mdc-floating-label--float-above {
  max-width: calc(133.3333333333% + 1px);
}
`],encapsulation:2,changeDetection:0})}return n})();var PC=["*",[["mat-chip-avatar"],["","matChipAvatar",""]],[["mat-chip-trailing-icon"],["","matChipRemove",""],["","matChipTrailingIcon",""]]],FC=["*","mat-chip-avatar, [matChipAvatar]","mat-chip-trailing-icon,[matChipRemove],[matChipTrailingIcon]"];function NC(n,i){n&1&&(s(0,"span",3),ee(1,1),r())}function LC(n,i){n&1&&(s(0,"span",6),ee(1,2),r())}var BC=new E("mat-chips-default-options",{providedIn:"root",factory:()=>({separatorKeyCodes:[13]})}),Pg=new E("MatChipAvatar"),Fg=new E("MatChipTrailingIcon"),Ng=new E("MatChipEdit"),Lg=new E("MatChipRemove"),Bg=new E("MatChip"),jg=(()=>{class n{_elementRef=m(B);_parentChip=m(Bg);_isPrimary=!0;_isLeading=!1;get disabled(){return this._disabled||this._parentChip?.disabled||!1}set disabled(e){this._disabled=e}_disabled=!1;tabIndex=-1;_allowFocusWhenDisabled=!1;_getDisabledAttribute(){return this.disabled&&!this._allowFocusWhenDisabled?"":null}constructor(){m(Oe).load(Et),this._elementRef.nativeElement.nodeName==="BUTTON"&&this._elementRef.nativeElement.setAttribute("type","button")}focus(){this._elementRef.nativeElement.focus()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","matChipContent",""]],hostAttrs:[1,"mat-mdc-chip-action","mdc-evolution-chip__action","mdc-evolution-chip__action--presentational"],hostVars:8,hostBindings:function(t,a){t&2&&(Y("disabled",a._getDisabledAttribute())("aria-disabled",a.disabled),k("mdc-evolution-chip__action--primary",a._isPrimary)("mdc-evolution-chip__action--secondary",!a._isPrimary)("mdc-evolution-chip__action--trailing",!a._isPrimary&&!a._isLeading))},inputs:{disabled:[2,"disabled","disabled",R],tabIndex:[2,"tabIndex","tabIndex",e=>e==null?-1:lt(e)],_allowFocusWhenDisabled:"_allowFocusWhenDisabled"}})}return n})(),jC=(()=>{class n extends jg{_getTabindex(){return this.disabled&&!this._allowFocusWhenDisabled?null:this.tabIndex.toString()}_handleClick(e){!this.disabled&&this._isPrimary&&(e.preventDefault(),this._parentChip._handlePrimaryActionInteraction())}_handleKeydown(e){(e.keyCode===13||e.keyCode===32)&&!this.disabled&&this._isPrimary&&!this._parentChip._isEditing&&(e.preventDefault(),this._parentChip._handlePrimaryActionInteraction())}static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["","matChipAction",""]],hostVars:3,hostBindings:function(t,a){t&1&&_("click",function(c){return a._handleClick(c)})("keydown",function(c){return a._handleKeydown(c)}),t&2&&(Y("tabindex",a._getTabindex()),k("mdc-evolution-chip__action--presentational",!1))},features:[ie]})}return n})();var Ti=(()=>{class n{_changeDetectorRef=m(Z);_elementRef=m(B);_tagName=m(cp);_ngZone=m(W);_focusMonitor=m(Dt);_globalRippleOptions=m(Ja,{optional:!0});_document=m(X);_onFocus=new F;_onBlur=new F;_isBasicChip=!1;role=null;_hasFocusInternal=!1;_pendingFocus=!1;_actionChanges;_animationsDisabled=Ee();_allLeadingIcons;_allTrailingIcons;_allEditIcons;_allRemoveIcons;_hasFocus(){return this._hasFocusInternal}id=m(xe).getId("mat-mdc-chip-");ariaLabel=null;ariaDescription=null;_chipListDisabled=!1;_hadFocusOnRemove=!1;_textElement;get value(){return this._value!==void 0?this._value:this._textElement.textContent.trim()}set value(e){this._value=e}_value;color;removable=!0;highlighted=!1;disableRipple=!1;get disabled(){return this._disabled||this._chipListDisabled}set disabled(e){this._disabled=e}_disabled=!1;removed=new z;destroyed=new z;basicChipAttrName="mat-basic-chip";leadingIcon;editIcon;trailingIcon;removeIcon;primaryAction;_rippleLoader=m(fc);_injector=m(re);constructor(){let e=m(Oe);e.load(Et),e.load(wi),this._monitorFocus(),this._rippleLoader?.configureRipple(this._elementRef.nativeElement,{className:"mat-mdc-chip-ripple",disabled:this._isRippleDisabled()})}ngOnInit(){this._isBasicChip=this._elementRef.nativeElement.hasAttribute(this.basicChipAttrName)||this._tagName.toLowerCase()===this.basicChipAttrName}ngAfterViewInit(){this._textElement=this._elementRef.nativeElement.querySelector(".mat-mdc-chip-action-label"),this._pendingFocus&&(this._pendingFocus=!1,this.focus())}ngAfterContentInit(){this._actionChanges=ut(this._allLeadingIcons.changes,this._allTrailingIcons.changes,this._allEditIcons.changes,this._allRemoveIcons.changes).subscribe(()=>this._changeDetectorRef.markForCheck())}ngDoCheck(){this._rippleLoader.setDisabled(this._elementRef.nativeElement,this._isRippleDisabled())}ngOnDestroy(){this._focusMonitor.stopMonitoring(this._elementRef),this._rippleLoader?.destroyRipple(this._elementRef.nativeElement),this._actionChanges?.unsubscribe(),this.destroyed.emit({chip:this}),this.destroyed.complete()}remove(){this.removable&&(this._hadFocusOnRemove=this._hasFocus(),this.removed.emit({chip:this}))}_isRippleDisabled(){return this.disabled||this.disableRipple||this._animationsDisabled||this._isBasicChip||!this._hasInteractiveActions()||!!this._globalRippleOptions?.disabled}_hasTrailingIcon(){return!!(this.trailingIcon||this.removeIcon)}_handleKeydown(e){(e.keyCode===8&&!e.repeat||e.keyCode===46)&&(e.preventDefault(),this.remove())}focus(){this.disabled||(this.primaryAction?this.primaryAction.focus():this._pendingFocus=!0)}_getSourceAction(e){return this._getActions().find(t=>{let a=t._elementRef.nativeElement;return a===e||a.contains(e)})}_getActions(){let e=[];return this.editIcon&&e.push(this.editIcon),this.primaryAction&&e.push(this.primaryAction),this.removeIcon&&e.push(this.removeIcon),e}_handlePrimaryActionInteraction(){}_hasInteractiveActions(){return this._getActions().length>0}_edit(e){}_monitorFocus(){this._focusMonitor.monitor(this._elementRef,!0).subscribe(e=>{let t=e!==null;t!==this._hasFocusInternal&&(this._hasFocusInternal=t,t?this._onFocus.next({chip:this}):(this._changeDetectorRef.markForCheck(),setTimeout(()=>this._ngZone.run(()=>this._onBlur.next({chip:this})))))})}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-basic-chip"],["","mat-basic-chip",""],["mat-chip"],["","mat-chip",""]],contentQueries:function(t,a,o){if(t&1&&st(o,Pg,5)(o,Ng,5)(o,Fg,5)(o,Lg,5)(o,Pg,5)(o,Fg,5)(o,Ng,5)(o,Lg,5),t&2){let c;j(c=V())&&(a.leadingIcon=c.first),j(c=V())&&(a.editIcon=c.first),j(c=V())&&(a.trailingIcon=c.first),j(c=V())&&(a.removeIcon=c.first),j(c=V())&&(a._allLeadingIcons=c),j(c=V())&&(a._allTrailingIcons=c),j(c=V())&&(a._allEditIcons=c),j(c=V())&&(a._allRemoveIcons=c)}},viewQuery:function(t,a){if(t&1&&Ae(jC,5),t&2){let o;j(o=V())&&(a.primaryAction=o.first)}},hostAttrs:[1,"mat-mdc-chip"],hostVars:31,hostBindings:function(t,a){t&1&&_("keydown",function(c){return a._handleKeydown(c)}),t&2&&(jt("id",a.id),Y("role",a.role)("aria-label",a.ariaLabel),ve("mat-"+(a.color||"primary")),k("mdc-evolution-chip",!a._isBasicChip)("mdc-evolution-chip--disabled",a.disabled)("mdc-evolution-chip--with-trailing-action",a._hasTrailingIcon())("mdc-evolution-chip--with-primary-graphic",a.leadingIcon)("mdc-evolution-chip--with-primary-icon",a.leadingIcon)("mdc-evolution-chip--with-avatar",a.leadingIcon)("mat-mdc-chip-with-avatar",a.leadingIcon)("mat-mdc-chip-highlighted",a.highlighted)("mat-mdc-chip-disabled",a.disabled)("mat-mdc-basic-chip",a._isBasicChip)("mat-mdc-standard-chip",!a._isBasicChip)("mat-mdc-chip-with-trailing-icon",a._hasTrailingIcon())("_mat-animation-noopable",a._animationsDisabled))},inputs:{role:"role",id:"id",ariaLabel:[0,"aria-label","ariaLabel"],ariaDescription:[0,"aria-description","ariaDescription"],value:"value",color:"color",removable:[2,"removable","removable",R],highlighted:[2,"highlighted","highlighted",R],disableRipple:[2,"disableRipple","disableRipple",R],disabled:[2,"disabled","disabled",R]},outputs:{removed:"removed",destroyed:"destroyed"},exportAs:["matChip"],features:[ce([{provide:Bg,useExisting:n}])],ngContentSelectors:FC,decls:8,vars:2,consts:[[1,"mat-mdc-chip-focus-overlay"],[1,"mdc-evolution-chip__cell","mdc-evolution-chip__cell--primary"],["matChipContent",""],[1,"mdc-evolution-chip__graphic","mat-mdc-chip-graphic"],[1,"mdc-evolution-chip__text-label","mat-mdc-chip-action-label"],[1,"mat-mdc-chip-primary-focus-indicator","mat-focus-indicator"],[1,"mdc-evolution-chip__cell","mdc-evolution-chip__cell--trailing"]],template:function(t,a){t&1&&(ye(PC),H(0,"span",0),s(1,"span",1)(2,"span",2),v(3,NC,2,0,"span",3),s(4,"span",4),ee(5),H(6,"span",5),r()()(),v(7,LC,2,0,"span",6)),t&2&&(d(3),y(a.leadingIcon?3:-1),d(4),y(a._hasTrailingIcon()?7:-1))},dependencies:[jg],styles:[`.mdc-evolution-chip,
.mdc-evolution-chip__cell,
.mdc-evolution-chip__action {
  display: inline-flex;
  align-items: center;
}

.mdc-evolution-chip {
  position: relative;
  max-width: 100%;
}

.mdc-evolution-chip__cell,
.mdc-evolution-chip__action {
  height: 100%;
}

.mdc-evolution-chip__cell--primary {
  flex-basis: 100%;
  overflow-x: hidden;
}

.mdc-evolution-chip__cell--trailing {
  flex: 1 0 auto;
}

.mdc-evolution-chip__action {
  align-items: center;
  background: none;
  border: none;
  box-sizing: content-box;
  cursor: pointer;
  display: inline-flex;
  justify-content: center;
  outline: none;
  padding: 0;
  text-decoration: none;
  color: inherit;
}

.mdc-evolution-chip__action--presentational {
  cursor: auto;
}

.mdc-evolution-chip--disabled,
.mdc-evolution-chip__action:disabled {
  pointer-events: none;
}
@media (forced-colors: active) {
  .mdc-evolution-chip--disabled,
  .mdc-evolution-chip__action:disabled {
    forced-color-adjust: none;
  }
}

.mdc-evolution-chip__action--primary {
  font: inherit;
  letter-spacing: inherit;
  white-space: inherit;
  overflow-x: hidden;
}
.mat-mdc-standard-chip .mdc-evolution-chip__action--primary::before {
  border-width: var(--mat-chip-outline-width, 1px);
  border-radius: var(--mat-chip-container-shape-radius, 8px);
  box-sizing: border-box;
  content: "";
  height: 100%;
  left: 0;
  position: absolute;
  pointer-events: none;
  top: 0;
  width: 100%;
  z-index: 1;
  border-style: solid;
}
.mat-mdc-standard-chip .mdc-evolution-chip__action--primary {
  padding-left: 12px;
  padding-right: 12px;
}
.mat-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__action--primary {
  padding-left: 0;
  padding-right: 12px;
}
[dir=rtl] .mat-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__action--primary {
  padding-left: 12px;
  padding-right: 0;
}
.mat-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__action--primary::before {
  border-color: var(--mat-chip-outline-color, var(--mat-sys-outline));
}
.mdc-evolution-chip__action--primary:not(.mdc-evolution-chip__action--presentational):not(.mdc-ripple-upgraded):focus::before {
  border-color: var(--mat-chip-focus-outline-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__action--primary::before {
  border-color: var(--mat-chip-disabled-outline-color, color-mix(in srgb, var(--mat-sys-on-surface) 12%, transparent));
}
.mat-mdc-standard-chip.mdc-evolution-chip--selected .mdc-evolution-chip__action--primary::before {
  border-width: var(--mat-chip-flat-selected-outline-width, 0);
}
.mat-mdc-basic-chip .mdc-evolution-chip__action--primary {
  font: inherit;
}
.mat-mdc-standard-chip.mdc-evolution-chip--with-leading-action .mdc-evolution-chip__action--primary {
  padding-left: 0;
  padding-right: 12px;
}
[dir=rtl] .mat-mdc-standard-chip.mdc-evolution-chip--with-leading-action .mdc-evolution-chip__action--primary {
  padding-left: 12px;
  padding-right: 0;
}
.mat-mdc-standard-chip.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary {
  padding-left: 12px;
  padding-right: 0;
}
[dir=rtl] .mat-mdc-standard-chip.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary {
  padding-left: 0;
  padding-right: 12px;
}
.mat-mdc-standard-chip.mdc-evolution-chip--with-leading-action.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary {
  padding-left: 0;
  padding-right: 0;
}
.mat-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary {
  padding-left: 0;
  padding-right: 0;
}
[dir=rtl] .mat-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary {
  padding-left: 0;
  padding-right: 0;
}
.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__action--primary {
  padding-left: 0;
  padding-right: 12px;
}
[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__action--primary {
  padding-left: 12px;
  padding-right: 0;
}
.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary {
  padding-left: 0;
  padding-right: 0;
}
[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--primary {
  padding-left: 0;
  padding-right: 0;
}

.mdc-evolution-chip__action--secondary {
  position: relative;
  overflow: visible;
}
.mat-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__action--secondary {
  color: var(--mat-chip-with-trailing-icon-trailing-icon-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__action--secondary {
  color: var(--mat-chip-with-trailing-icon-disabled-trailing-icon-color, var(--mat-sys-on-surface));
}
.mat-mdc-standard-chip.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--secondary {
  padding-left: 8px;
  padding-right: 8px;
}
.mat-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--secondary {
  padding-left: 8px;
  padding-right: 8px;
}
.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--secondary {
  padding-left: 8px;
  padding-right: 8px;
}
[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__action--secondary {
  padding-left: 8px;
  padding-right: 8px;
}

.mdc-evolution-chip__text-label {
  -webkit-user-select: none;
  user-select: none;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}
.mat-mdc-standard-chip .mdc-evolution-chip__text-label {
  font-family: var(--mat-chip-label-text-font, var(--mat-sys-label-large-font));
  line-height: var(--mat-chip-label-text-line-height, var(--mat-sys-label-large-line-height));
  font-size: var(--mat-chip-label-text-size, var(--mat-sys-label-large-size));
  font-weight: var(--mat-chip-label-text-weight, var(--mat-sys-label-large-weight));
  letter-spacing: var(--mat-chip-label-text-tracking, var(--mat-sys-label-large-tracking));
}
.mat-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__text-label {
  color: var(--mat-chip-label-text-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-standard-chip.mdc-evolution-chip--selected:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__text-label {
  color: var(--mat-chip-selected-label-text-color, var(--mat-sys-on-secondary-container));
}
.mat-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__text-label, .mat-mdc-standard-chip.mdc-evolution-chip--selected.mdc-evolution-chip--disabled .mdc-evolution-chip__text-label {
  color: var(--mat-chip-disabled-label-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}

.mdc-evolution-chip__graphic {
  align-items: center;
  display: inline-flex;
  justify-content: center;
  overflow: hidden;
  pointer-events: none;
  position: relative;
  flex: 1 0 auto;
}
.mat-mdc-standard-chip .mdc-evolution-chip__graphic {
  width: var(--mat-chip-with-avatar-avatar-size, 24px);
  height: var(--mat-chip-with-avatar-avatar-size, 24px);
  font-size: var(--mat-chip-with-avatar-avatar-size, 24px);
}
.mdc-evolution-chip--selecting .mdc-evolution-chip__graphic {
  transition: width 150ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mdc-evolution-chip--selectable:not(.mdc-evolution-chip--selected):not(.mdc-evolution-chip--with-primary-icon) .mdc-evolution-chip__graphic {
  width: 0;
}
.mat-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__graphic {
  padding-left: 6px;
  padding-right: 6px;
}
.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__graphic {
  padding-left: 4px;
  padding-right: 8px;
}
[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic .mdc-evolution-chip__graphic {
  padding-left: 8px;
  padding-right: 4px;
}
.mat-mdc-standard-chip.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__graphic {
  padding-left: 6px;
  padding-right: 6px;
}
.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__graphic {
  padding-left: 4px;
  padding-right: 8px;
}
[dir=rtl] .mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-trailing-action .mdc-evolution-chip__graphic {
  padding-left: 8px;
  padding-right: 4px;
}
.mdc-evolution-chip--with-avatar.mdc-evolution-chip--with-primary-graphic.mdc-evolution-chip--with-leading-action .mdc-evolution-chip__graphic {
  padding-left: 0;
}

.mdc-evolution-chip__checkmark {
  position: absolute;
  opacity: 0;
  top: 50%;
  left: 50%;
  height: 20px;
  width: 20px;
}
.mat-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__checkmark {
  color: var(--mat-chip-with-icon-selected-icon-color, var(--mat-sys-on-secondary-container));
}
.mat-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__checkmark {
  color: var(--mat-chip-with-icon-disabled-icon-color, var(--mat-sys-on-surface));
}
.mdc-evolution-chip--selecting .mdc-evolution-chip__checkmark {
  transition: transform 150ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
  transform: translate(-75%, -50%);
}
.mdc-evolution-chip--selected .mdc-evolution-chip__checkmark {
  transform: translate(-50%, -50%);
  opacity: 1;
}

.mdc-evolution-chip__checkmark-svg {
  display: block;
}

.mdc-evolution-chip__checkmark-path {
  stroke-width: 2px;
  stroke-dasharray: 29.7833385;
  stroke-dashoffset: 29.7833385;
  stroke: currentColor;
}
.mdc-evolution-chip--selecting .mdc-evolution-chip__checkmark-path {
  transition: stroke-dashoffset 150ms 45ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mdc-evolution-chip--selected .mdc-evolution-chip__checkmark-path {
  stroke-dashoffset: 0;
}
@media (forced-colors: active) {
  .mdc-evolution-chip__checkmark-path {
    stroke: CanvasText !important;
  }
}

.mat-mdc-standard-chip .mdc-evolution-chip__icon--trailing {
  height: 18px;
  width: 18px;
  font-size: 18px;
}
.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing.mat-mdc-chip-remove {
  opacity: calc(var(--mat-chip-trailing-action-opacity, 1) * var(--mat-chip-with-trailing-icon-disabled-trailing-icon-opacity, 0.38));
}
.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing.mat-mdc-chip-remove:focus {
  opacity: calc(var(--mat-chip-trailing-action-focus-opacity, 1) * var(--mat-chip-with-trailing-icon-disabled-trailing-icon-opacity, 0.38));
}

.mat-mdc-standard-chip {
  border-radius: var(--mat-chip-container-shape-radius, 8px);
  height: var(--mat-chip-container-height, 32px);
}
.mat-mdc-standard-chip:not(.mdc-evolution-chip--disabled) {
  background-color: var(--mat-chip-elevated-container-color, transparent);
}
.mat-mdc-standard-chip.mdc-evolution-chip--disabled {
  background-color: var(--mat-chip-elevated-disabled-container-color);
}
.mat-mdc-standard-chip.mdc-evolution-chip--selected:not(.mdc-evolution-chip--disabled) {
  background-color: var(--mat-chip-elevated-selected-container-color, var(--mat-sys-secondary-container));
}
.mat-mdc-standard-chip.mdc-evolution-chip--selected.mdc-evolution-chip--disabled {
  background-color: var(--mat-chip-flat-disabled-selected-container-color, color-mix(in srgb, var(--mat-sys-on-surface) 12%, transparent));
}
@media (forced-colors: active) {
  .mat-mdc-standard-chip {
    outline: solid 1px;
  }
}

.mat-mdc-standard-chip .mdc-evolution-chip__icon--primary {
  border-radius: var(--mat-chip-with-avatar-avatar-shape-radius, 24px);
  width: var(--mat-chip-with-icon-icon-size, 18px);
  height: var(--mat-chip-with-icon-icon-size, 18px);
  font-size: var(--mat-chip-with-icon-icon-size, 18px);
}
.mdc-evolution-chip--selected .mdc-evolution-chip__icon--primary {
  opacity: 0;
}
.mat-mdc-standard-chip:not(.mdc-evolution-chip--disabled) .mdc-evolution-chip__icon--primary {
  color: var(--mat-chip-with-icon-icon-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-standard-chip.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--primary {
  color: var(--mat-chip-with-icon-disabled-icon-color, var(--mat-sys-on-surface));
}

.mat-mdc-chip-highlighted {
  --mat-chip-with-icon-icon-color: var(--mat-chip-with-icon-selected-icon-color, var(--mat-sys-on-secondary-container));
  --mat-chip-elevated-container-color: var(--mat-chip-elevated-selected-container-color, var(--mat-sys-secondary-container));
  --mat-chip-label-text-color: var(--mat-chip-selected-label-text-color, var(--mat-sys-on-secondary-container));
  --mat-chip-outline-width: var(--mat-chip-flat-selected-outline-width, 0);
}

.mat-mdc-chip-focus-overlay {
  background: var(--mat-chip-focus-state-layer-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-chip-selected .mat-mdc-chip-focus-overlay, .mat-mdc-chip-highlighted .mat-mdc-chip-focus-overlay {
  background: var(--mat-chip-selected-focus-state-layer-color, var(--mat-sys-on-secondary-container));
}
.mat-mdc-chip:hover .mat-mdc-chip-focus-overlay {
  background: var(--mat-chip-hover-state-layer-color, var(--mat-sys-on-surface-variant));
  opacity: var(--mat-chip-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mat-mdc-chip-focus-overlay .mat-mdc-chip-selected:hover, .mat-mdc-chip-highlighted:hover .mat-mdc-chip-focus-overlay {
  background: var(--mat-chip-selected-hover-state-layer-color, var(--mat-sys-on-secondary-container));
  opacity: var(--mat-chip-selected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mat-mdc-chip.cdk-focused .mat-mdc-chip-focus-overlay {
  background: var(--mat-chip-focus-state-layer-color, var(--mat-sys-on-surface-variant));
  opacity: var(--mat-chip-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mat-mdc-chip-selected.cdk-focused .mat-mdc-chip-focus-overlay, .mat-mdc-chip-highlighted.cdk-focused .mat-mdc-chip-focus-overlay {
  background: var(--mat-chip-selected-focus-state-layer-color, var(--mat-sys-on-secondary-container));
  opacity: var(--mat-chip-selected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}

.mdc-evolution-chip--disabled:not(.mdc-evolution-chip--selected) .mat-mdc-chip-avatar {
  opacity: var(--mat-chip-with-avatar-disabled-avatar-opacity, 0.38);
}

.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing {
  opacity: var(--mat-chip-with-trailing-icon-disabled-trailing-icon-opacity, 0.38);
}

.mdc-evolution-chip--disabled.mdc-evolution-chip--selected .mdc-evolution-chip__checkmark {
  opacity: var(--mat-chip-with-icon-disabled-icon-opacity, 0.38);
}

.mat-mdc-standard-chip.mdc-evolution-chip--disabled {
  opacity: var(--mat-chip-disabled-container-opacity, 1);
}
.mat-mdc-standard-chip.mdc-evolution-chip--selected .mdc-evolution-chip__icon--trailing, .mat-mdc-standard-chip.mat-mdc-chip-highlighted .mdc-evolution-chip__icon--trailing {
  color: var(--mat-chip-selected-trailing-icon-color, var(--mat-sys-on-secondary-container));
}
.mat-mdc-standard-chip.mdc-evolution-chip--selected.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing, .mat-mdc-standard-chip.mat-mdc-chip-highlighted.mdc-evolution-chip--disabled .mdc-evolution-chip__icon--trailing {
  color: var(--mat-chip-selected-disabled-trailing-icon-color, var(--mat-sys-on-surface));
}

.mat-mdc-chip-edit, .mat-mdc-chip-remove {
  opacity: var(--mat-chip-trailing-action-opacity, 1);
}
.mat-mdc-chip-edit:focus, .mat-mdc-chip-remove:focus {
  opacity: var(--mat-chip-trailing-action-focus-opacity, 1);
}
.mat-mdc-chip-edit::after, .mat-mdc-chip-remove::after {
  background-color: var(--mat-chip-trailing-action-state-layer-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-chip-edit:hover::after, .mat-mdc-chip-remove:hover::after {
  opacity: calc(var(--mat-chip-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity)) + var(--mat-chip-trailing-action-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity)));
}
.mat-mdc-chip-edit:focus::after, .mat-mdc-chip-remove:focus::after {
  opacity: calc(var(--mat-chip-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity)) + var(--mat-chip-trailing-action-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity)));
}

.mat-mdc-chip-selected .mat-mdc-chip-remove::after,
.mat-mdc-chip-highlighted .mat-mdc-chip-remove::after {
  background-color: var(--mat-chip-selected-trailing-action-state-layer-color, var(--mat-sys-on-secondary-container));
}

.mat-mdc-chip.cdk-focused .mat-mdc-chip-edit:focus::after, .mat-mdc-chip.cdk-focused .mat-mdc-chip-remove:focus::after {
  opacity: calc(var(--mat-chip-selected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity)) + var(--mat-chip-trailing-action-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity)));
}
.mat-mdc-chip.cdk-focused .mat-mdc-chip-edit:hover::after, .mat-mdc-chip.cdk-focused .mat-mdc-chip-remove:hover::after {
  opacity: calc(var(--mat-chip-selected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity)) + var(--mat-chip-trailing-action-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity)));
}

.mat-mdc-standard-chip {
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-standard-chip .mat-mdc-chip-graphic,
.mat-mdc-standard-chip .mat-mdc-chip-trailing-icon {
  box-sizing: content-box;
}
.mat-mdc-standard-chip._mat-animation-noopable,
.mat-mdc-standard-chip._mat-animation-noopable .mdc-evolution-chip__graphic,
.mat-mdc-standard-chip._mat-animation-noopable .mdc-evolution-chip__checkmark,
.mat-mdc-standard-chip._mat-animation-noopable .mdc-evolution-chip__checkmark-path {
  transition-duration: 1ms;
  animation-duration: 1ms;
}

.mat-mdc-chip-focus-overlay {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
  opacity: 0;
  border-radius: inherit;
  transition: opacity 150ms linear;
}
._mat-animation-noopable .mat-mdc-chip-focus-overlay {
  transition: none;
}
.mat-mdc-basic-chip .mat-mdc-chip-focus-overlay {
  display: none;
}

.mat-mdc-chip .mat-ripple.mat-mdc-chip-ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
  border-radius: inherit;
}

.mat-mdc-chip-avatar {
  text-align: center;
  line-height: 1;
  color: var(--mat-chip-with-icon-icon-color, currentColor);
}

.mat-mdc-chip {
  position: relative;
  z-index: 0;
}

.mat-mdc-chip-action-label {
  text-align: left;
  z-index: 1;
}
[dir=rtl] .mat-mdc-chip-action-label {
  text-align: right;
}
.mat-mdc-chip.mdc-evolution-chip--with-trailing-action .mat-mdc-chip-action-label {
  position: relative;
}
.mat-mdc-chip-action-label .mat-mdc-chip-primary-focus-indicator {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  pointer-events: none;
}
.mat-mdc-chip-action-label .mat-focus-indicator::before {
  margin: calc(calc(var(--mat-focus-indicator-border-width, 3px) + 2px) * -1);
}

.mat-mdc-chip-edit::before, .mat-mdc-chip-remove::before {
  margin: calc(var(--mat-focus-indicator-border-width, 3px) * -1);
  left: 8px;
  right: 8px;
}
.mat-mdc-chip-edit::after, .mat-mdc-chip-remove::after {
  content: "";
  display: block;
  opacity: 0;
  position: absolute;
  top: -3px;
  bottom: -3px;
  left: 5px;
  right: 5px;
  border-radius: 50%;
  box-sizing: border-box;
  padding: 12px;
  margin: -12px;
  background-clip: content-box;
}
.mat-mdc-chip-edit .mat-icon, .mat-mdc-chip-remove .mat-icon {
  width: 18px;
  height: 18px;
  font-size: 18px;
  box-sizing: content-box;
}

.mat-chip-edit-input {
  cursor: text;
  display: inline-block;
  color: inherit;
  outline: 0;
}

@media (forced-colors: active) {
  .mat-mdc-chip-selected:not(.mat-mdc-chip-multiple) {
    outline-width: 3px;
  }
}

.mat-mdc-chip-action:focus-visible .mat-focus-indicator::before {
  content: "";
}

.mdc-evolution-chip__icon, .mat-mdc-chip-edit .mat-icon, .mat-mdc-chip-remove .mat-icon {
  min-height: fit-content;
}

img.mdc-evolution-chip__icon {
  min-height: 0;
}
`],encapsulation:2,changeDetection:0})}return n})();var Un=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({providers:[oo,{provide:BC,useValue:{separatorKeyCodes:[13]}}],imports:[Si,de]})}return n})();var VC={TURNADA:"Turnada",EN_ANALISIS:"En an\xE1lisis",PROCEDENTE:"Procedente",IMPROCEDENTE:"Improcedente",REMITIDA:"Remitida",PENDIENTE_REMISION:"Improcedente"};function Oi(n){return n?VC[n.toUpperCase()]??n:""}function so(n){let i=(n??"").toUpperCase();return i==="PENDIENTE_REMISION"?"IMPROCEDENTE":i}function Fc(n){let i=so(n);return i==="TURNADA"||i==="EN_ANALISIS"}function co(n){return"estatus-"+(so(n)||"desconocido").toLowerCase().replace("_","-")}function Nc(n){switch(n?.toUpperCase()){case"ALTA":return"Alta";case"BAJA":return"Baja";default:return"Media"}}function oi(n){if(!n)return"";let[i,e,t]=n.substring(0,10).split("-");return t&&e&&i?`${t}/${e}/${i}`:n}function Hn(n){if(!n)return"";let i=n.length>=16?" "+n.substring(11,16):"";return oi(n)+i}var Lc={production:!0,apiUrl:"/api/primer-contacto",denunciadoApiUrl:"/api/denunciado"};var Ue=class n{constructor(i){this.http=i}http;apiUrl=Lc.apiUrl;get(i){return this.http.get(`${this.apiUrl}${i}`)}getBlob(i){return this.http.get(`${this.apiUrl}${i}`,{responseType:"blob"})}post(i,e){return this.http.post(`${this.apiUrl}${i}`,e)}put(i,e){return this.http.put(`${this.apiUrl}${i}`,e)}delete(i){return this.http.delete(`${this.apiUrl}${i}`)}static \u0275fac=function(e){return new(e||n)(U(_i))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var Pi=class n{constructor(i){this.api=i}api;obtenerBandeja(){return this.api.get("/bandeja").pipe(Q(i=>i.map(e=>this.mapearExpediente(e))))}filtrar(i){return this.api.post("/bandeja/filtrar",i).pipe(Q(e=>e.map(t=>this.mapearExpediente(t))))}buscarPorFolio(i){return this.api.get(`/bandeja/folio/${i}`).pipe(Q(e=>this.mapearExpediente(e)))}mapearExpediente(i){return{expedienteId:i.expedienteId,folio:i.folio,folioOrigen:i.folioOrigen,nombreQuejoso:i.nombreQuejoso??"",unidadAcademica:i.unidadAcademica??"",tema:i.tema??"",prioridad:Nc(i.prioridad),estatus:Oi(i.estatus),estatusCodigo:so(i.estatus),fechaRecepcion:oi(i.fechaRecepcion),tieneCitaActiva:!!i.tieneCitaActiva}}static \u0275fac=function(e){return new(e||n)(U(Ue))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var $n=class n{constructor(i){this.api=i}api;crearCita(i){return this.api.post("/citas",i).pipe(Q(e=>this.mapearCita(e)))}obtenerAgendaDia(i){return this.api.get(`/citas/agenda?fecha=${encodeURIComponent(i)}`).pipe(Q(e=>e.map(t=>this.mapearCita(t))))}obtenerRango(i,e){return this.api.get(`/citas/rango?desde=${encodeURIComponent(i)}&hasta=${encodeURIComponent(e)}`).pipe(Q(t=>t.map(a=>this.mapearCita(a))))}obtenerMisProximasCitas(){return this.api.get("/citas/mias").pipe(Q(i=>i.map(e=>this.mapearCita(e))))}listarPorFolio(i){return this.api.get(`/citas/folio/${encodeURIComponent(i)}`).pipe(Q(e=>e.map(t=>this.mapearCita(t))))}confirmarCita(i){return this.api.put(`/citas/${i}/confirmar`,{}).pipe(Q(e=>this.mapearCita(e)))}reagendarCita(i,e){return this.api.put(`/citas/${i}/reagendar`,e).pipe(Q(t=>this.mapearCita(t)))}registrarCancelacionQuejoso(i,e){return this.api.put(`/citas/${i}/cancelacion-quejoso`,{motivo:e}).pipe(Q(t=>this.mapearCita(t)))}cancelarCita(i){return this.api.put(`/citas/${i}/cancelar`,{}).pipe(Q(e=>this.mapearCita(e)))}mapearCita(i){return{id:i.id,expedienteId:i.expedienteId,folio:i.folio,quejosoId:i.quejosoId,quejoso:i.quejosoNombre??"",analistaId:i.analistaId,analistaNombre:i.analistaNombre,fecha:this.formatearFechaVista(i.fechaCita),hora:i.horaCita?.slice(0,5),tipo:i.tipoCita==="VIRTUAL"?"Virtual":"Presencial",categoria:i.categoria??"COMPARECENCIA",motivo:i.motivo,estatus:this.formatearEstatus(i.estatus),fechaCreacion:i.fechaCreacion,actualizadoPorNombre:i.actualizadoPorNombre,estatusCodigo:i.estatus?.toUpperCase(),fechaLimiteRespuesta:i.fechaLimiteRespuesta,fechaRespuestaQuejoso:i.fechaRespuestaQuejoso,motivoCancelacionQuejoso:i.motivoCancelacionQuejoso,respuestaRegistradaPor:i.respuestaRegistradaPor,citaAnteriorId:i.citaAnteriorId}}formatearFechaVista(i){if(!i)return"";let[e,t,a]=i.split("-");return`${a}/${t}/${e}`}formatearEstatus(i){switch(i?.toUpperCase()){case"PROGRAMADA":return"Programada";case"CONFIRMADA":return"Confirmada";case"CANCELADA":return"Cancelada";case"CANCELADA_QUEJOSO":return"Cancelada por el quejoso";case"SIN_RESPUESTA":return"Sin respuesta";case"REAGENDADA":return"Reagendada";default:return i}}static \u0275fac=function(e){return new(e||n)(U(Ue))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var jc=class n{constructor(i,e){this.bandejaService=i;this.agendaService=e}bandejaService;agendaService;obtenerResumen(){return this.bandejaService.obtenerBandeja().pipe(Q(i=>this.construirResumen(i)))}obtenerLista(){return this.bandejaService.obtenerBandeja().pipe(Q(i=>i.map(e=>this.mapearItemLista(e))))}obtenerCitasHoy(){return this.agendaService.obtenerAgendaDia(this.formatearFechaHoy()).pipe(Q(i=>i.filter(e=>e.estatus!=="Cancelada").map(e=>({hora:e.hora,quejoso:e.quejoso,folio:e.folio,tipo:e.tipo}))))}obtenerActividad(){return this.bandejaService.obtenerBandeja().pipe(Q(i=>this.construirActividad(i)))}construirResumen(i){let e=t=>i.filter(a=>this.tipoDeExpediente(a)===t).length;return[{titulo:"Pendientes",valor:e("PENDIENTES"),icono:"assignment",tipo:"PENDIENTES"},{titulo:"Con cita",valor:e("CON_CITA"),icono:"event",tipo:"CON_CITA"},{titulo:"Dictaminados",valor:e("EN_DICTAMEN"),icono:"description",tipo:"EN_DICTAMEN"},{titulo:"Remitidos",valor:e("REMITIDOS"),icono:"outgoing_mail",tipo:"REMITIDOS"}]}mapearItemLista(i){return{folio:i.folio,nombre:i.nombreQuejoso,detalle:i.tema,estado:i.estatus,tipo:this.tipoDeExpediente(i)}}construirActividad(i){return i.slice().sort((e,t)=>this.aTimestamp(t.fechaRecepcion)-this.aTimestamp(e.fechaRecepcion)).slice(0,5).map(e=>({folio:e.folio,accion:`Estatus actual: ${e.estatus}`,tiempo:e.fechaRecepcion,icono:"assignment",prioridad:e.prioridad}))}tipoDeExpediente(i){switch(i.estatusCodigo){case"PROCEDENTE":case"IMPROCEDENTE":return"EN_DICTAMEN";case"REMITIDA":return"REMITIDOS";default:return i.tieneCitaActiva?"CON_CITA":"PENDIENTES"}}aTimestamp(i){if(!i)return 0;let[e,t,a]=i.split("/");return new Date(+a,+t-1,+e).getTime()}formatearFechaHoy(){let i=new Date,e=i.getFullYear(),t=(i.getMonth()+1).toString().padStart(2,"0"),a=i.getDate().toString().padStart(2,"0");return`${e}-${t}-${a}`}static \u0275fac=function(e){return new(e||n)(U(Pi),U($n))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var UC=(n,i)=>i.titulo,HC=(n,i)=>i.folio,$C=(n,i)=>i.folio+i.hora,GC=(n,i)=>i.folio+i.tiempo;function qC(n,i){if(n&1){let e=T();s(0,"div",18),_("click",function(){let a=x(e).$implicit,o=h();return C(o.seleccionarCategoria(a.tipo))}),s(1,"mat-icon"),l(2),r(),s(3,"div")(4,"span"),l(5),r(),s(6,"strong"),l(7),r()()()}if(n&2){let e=i.$implicit;d(2),g(e.icono),d(3),g(e.titulo),d(2),g(e.valor)}}function WC(n,i){n&1&&(s(0,"p",10),l(1," No hay expedientes en esta categor\xEDa. "),r())}function QC(n,i){if(n&1){let e=T();s(0,"div",19),_("click",function(){let a=x(e).$implicit,o=h();return C(o.abrirExpediente(a.folio))}),s(1,"div")(2,"strong"),l(3),r(),s(4,"span"),l(5),r()(),s(6,"span"),l(7),r(),s(8,"mat-chip",20),l(9),r()()}if(n&2){let e=i.$implicit;d(3),g(e.folio),d(2),g(e.nombre),d(2),g(e.detalle),d(2),g(e.estado)}}function YC(n,i){n&1&&(s(0,"p",10),l(1," No hay citas programadas para hoy. "),r())}function XC(n,i){if(n&1&&(s(0,"div",15)(1,"div",21),l(2),r(),s(3,"div")(4,"strong"),l(5),r(),s(6,"span"),l(7),r()(),s(8,"mat-chip",22),l(9,"Confirmada"),r()()),n&2){let e=i.$implicit;d(2),N("",e.hora," hrs"),d(3),g(e.quejoso),d(2),g(e.folio)}}function KC(n,i){n&1&&(s(0,"p",10),l(1," No se registra actividad reciente. "),r())}function ZC(n,i){n&1&&(s(0,"mat-chip",22),l(1,"Alta"),r())}function JC(n,i){n&1&&(s(0,"mat-chip",26),l(1,"Media"),r())}function ew(n,i){if(n&1){let e=T();s(0,"div",23),_("click",function(){let a=x(e).$implicit,o=h();return C(o.abrirExpediente(a.folio))}),s(1,"mat-icon",24),l(2),r(),s(3,"div")(4,"div",25)(5,"strong"),l(6),r(),v(7,ZC,2,0,"mat-chip",22)(8,JC,2,0,"mat-chip",26),r(),s(9,"span"),l(10),r(),s(11,"small"),l(12),r()()()}if(n&2){let e=i.$implicit;d(2),g(e.icono),d(4),g(e.folio),d(),y(e.prioridad==="Alta"?7:e.prioridad==="Media"?8:-1),d(3),g(e.accion),d(2),N("Hace ",e.tiempo)}}var Vc=class n{constructor(i,e,t){this.router=i;this.dashboardService=e;this.cdr=t}router;dashboardService;cdr;fechaActual=this.obtenerFechaActual();resumen=[];actividad=[];citasHoy=[];lista=[];navegar(i){this.router.navigate([i])}abrirExpediente(i){this.router.navigate(["/expediente",i])}irABandeja(){this.router.navigate(["/bandeja"])}irAgenda(){this.router.navigate(["/agenda"])}ngOnInit(){this.dashboardService.obtenerResumen().subscribe(i=>{this.resumen=i,this.cdr.detectChanges()}),this.dashboardService.obtenerActividad().subscribe(i=>{this.actividad=i,this.cdr.detectChanges()}),this.dashboardService.obtenerCitasHoy().subscribe(i=>{this.citasHoy=i,this.cdr.detectChanges()}),this.dashboardService.obtenerLista().subscribe(i=>{this.lista=i,this.cdr.detectChanges()})}categoriaSeleccionada="PENDIENTES";seleccionarCategoria(i){this.categoriaSeleccionada=i}obtenerListaSeleccionada(){return this.lista.filter(i=>i.tipo===this.categoriaSeleccionada)}get tituloLista(){switch(this.categoriaSeleccionada){case"PENDIENTES":return"Expedientes pendientes";case"CON_CITA":return"Expedientes con cita";case"EN_DICTAMEN":return"Expedientes dictaminados (procedentes e improcedentes)";case"REMITIDOS":return"Expedientes remitidos";default:return"Expedientes"}}obtenerFechaActual(){let i=new Date().toLocaleDateString("es-MX",{weekday:"long",year:"numeric",month:"long",day:"numeric"});return i.charAt(0).toUpperCase()+i.slice(1)}static \u0275fac=function(e){return new(e||n)(S(We),S(jc),S(Z))};static \u0275cmp=A({type:n,selectors:[["app-dashboard"]],decls:51,vars:5,consts:[[1,"page"],[1,"page-header"],[1,"date-label"],["mat-flat-button","",1,"primary-btn",3,"click"],[1,"stats-grid"],[1,"stat-card","clickable"],[1,"dashboard-layout"],[1,"card"],[1,"card-header-custom"],[1,"dashboard-list"],[2,"color","#6b7280","padding","var(--space-3)","text-align","center","font-size","var(--font-size-sm)"],[1,"dashboard-list-item","clickable"],[2,"display","grid","gap","var(--space-5)"],["mat-stroked-button","",1,"outline-btn",3,"click"],[1,"appointments"],[1,"appointment-item"],[1,"activity-timeline"],[1,"activity-item","clickable"],[1,"stat-card","clickable",3,"click"],[1,"dashboard-list-item","clickable",3,"click"],[1,"status-chip-default"],[1,"hour"],[1,"priority-high"],[1,"activity-item","clickable",3,"click"],[1,"activity-icon"],[1,"activity-title"],[1,"priority-medium"]],template:function(e,t){e&1&&(s(0,"section",0)(1,"div",1)(2,"div")(3,"h2"),l(4,"Panel de inicio"),r(),s(5,"p",2),l(6),r()(),s(7,"button",3),_("click",function(){return t.irABandeja()}),s(8,"mat-icon"),l(9,"assignment"),r(),l(10," Ir a Bandeja "),r()(),s(11,"div",4),te(12,qC,8,3,"div",5,UC),r(),s(14,"div",6)(15,"mat-card",7)(16,"div",8)(17,"div")(18,"h3"),l(19),r(),s(20,"p"),l(21,"Listado filtrado seg\xFAn el indicador seleccionado arriba."),r()()(),s(22,"div",9),v(23,WC,2,0,"p",10),te(24,QC,10,4,"div",11,HC),r()(),s(26,"div",12)(27,"mat-card",7)(28,"div",8)(29,"div")(30,"h3"),l(31,"Citas de hoy"),r(),s(32,"p"),l(33,"Comparecencias programadas para el d\xEDa actual."),r()(),s(34,"button",13),_("click",function(){return t.irAgenda()}),l(35," Ver agenda "),r()(),s(36,"div",14),v(37,YC,2,0,"p",10),te(38,XC,10,3,"div",15,$C),r()(),s(40,"mat-card",7)(41,"div",8)(42,"div")(43,"h3"),l(44,"Actividad reciente"),r(),s(45,"p"),l(46,"\xDAltimas acciones realizadas en el m\xF3dulo."),r()()(),s(47,"div",16),v(48,KC,2,0,"p",10),te(49,ew,13,5,"div",17,GC),r()()()()()),e&2&&(d(6),g(t.fechaActual),d(6),ne(t.resumen),d(7),g(t.tituloLista),d(4),y(t.obtenerListaSeleccionada().length===0?23:-1),d(),ne(t.obtenerListaSeleccionada()),d(13),y(t.citasHoy.length===0?37:-1),d(),ne(t.citasHoy),d(10),y(t.actividad.length===0?48:-1),d(),ne(t.actividad))},dependencies:[sn,jn,Ge,Je,ze,Ve,Un,Ti],styles:[".page[_ngcontent-%COMP%]{max-width:1280px}.page-header[_ngcontent-%COMP%]{margin-bottom:var(--space-5);display:flex;justify-content:space-between;align-items:center;gap:var(--space-5)}.page-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{margin:0;color:var(--guinda);font-size:28px;font-weight:800}.page-header[_ngcontent-%COMP%]   p.date-label[_ngcontent-%COMP%]{margin:var(--space-1) 0 0;color:var(--texto-suave);font-size:var(--font-size-base)}.stats-grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:var(--space-4);margin-bottom:var(--space-5)}.stat-card[_ngcontent-%COMP%]{border-radius:14px;box-shadow:0 2px 8px #0f172a14;padding:var(--space-4);display:flex;flex-direction:row;align-items:center;gap:var(--space-3);background:#fff;border:1px solid transparent;transition:all .2s ease}.stat-card[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{color:var(--guinda);font-size:28px;width:28px;height:28px}.stat-card[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{display:flex;flex-direction:column}.stat-card[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:var(--texto-suave);font-size:var(--font-size-sm);font-weight:700}.stat-card[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--negro-inst);font-size:var(--font-size-2xl);font-weight:900;line-height:var(--line-height-tight)}.dashboard-layout[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:var(--space-5);align-items:start}.card[_ngcontent-%COMP%]{border-radius:14px;box-shadow:0 2px 8px #0f172a14;padding:var(--space-4);background:#fff}.card-header-custom[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:var(--space-4)}.card-header-custom[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{margin:0;font-size:var(--font-size-lg);font-weight:900;color:var(--negro-inst)}.card-header-custom[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-1) 0 0;color:var(--texto-suave);font-size:var(--font-size-sm)}.dashboard-list[_ngcontent-%COMP%], .activity-timeline[_ngcontent-%COMP%], .appointments[_ngcontent-%COMP%]{display:grid;gap:var(--space-2)}.dashboard-list-item[_ngcontent-%COMP%], .activity-item[_ngcontent-%COMP%], .appointment-item[_ngcontent-%COMP%]{display:grid;align-items:center;background:#f9fafb;border-radius:8px;padding:var(--space-3);transition:background .2s ease}.dashboard-list-item[_ngcontent-%COMP%]{grid-template-columns:1.2fr 1.4fr auto;gap:var(--space-4)}.activity-item[_ngcontent-%COMP%]{grid-template-columns:auto 1fr;gap:var(--space-3);align-items:start}.appointment-item[_ngcontent-%COMP%]{grid-template-columns:75px 1fr auto;gap:var(--space-4)}.dashboard-list-item[_ngcontent-%COMP%]   div[_ngcontent-%COMP%], .activity-item[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:last-child, .appointment-item[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{display:grid;gap:var(--space-1)}.dashboard-list-item[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%], .activity-title[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%], .appointment-item[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--negro-inst);font-weight:800}.dashboard-list-item[_ngcontent-%COMP%]   span[_ngcontent-%COMP%], .activity-item[_ngcontent-%COMP%]   span[_ngcontent-%COMP%], .appointment-item[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:var(--texto);font-size:var(--font-size-sm)}.activity-item[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:#9ca3af;font-size:var(--font-size-xs)}.appointment-item[_ngcontent-%COMP%]   .hour[_ngcontent-%COMP%]{color:var(--guinda);font-weight:800;font-size:var(--font-size-base)}.activity-icon[_ngcontent-%COMP%]{color:var(--guinda);margin-top:var(--space-1)}.activity-title[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-2)}.primary-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important;font-weight:700;border-radius:8px!important;padding:0 var(--space-4);height:40px}.outline-btn[_ngcontent-%COMP%]{border-color:var(--texto-suave)!important;color:var(--texto)!important;font-weight:700;border-radius:8px!important}mat-chip[_ngcontent-%COMP%]{font-weight:700!important}.priority-high[_ngcontent-%COMP%]{background:#ffebee!important;color:var(--peligro)!important}.priority-medium[_ngcontent-%COMP%]{background:#fdf6e3!important;color:var(--advertencia)!important}.status-chip-default[_ngcontent-%COMP%]{background:var(--borde)!important;color:var(--texto)!important}.clickable[_ngcontent-%COMP%]{cursor:pointer}.stat-card.clickable[_ngcontent-%COMP%]:hover{background:#fdf2f4;border-color:#ead5df}.dashboard-list-item.clickable[_ngcontent-%COMP%]:hover{background:#f3f4f6}@media(max-width:900px){.dashboard-layout[_ngcontent-%COMP%]{grid-template-columns:1fr}.dashboard-list-item[_ngcontent-%COMP%]{grid-template-columns:1fr;gap:var(--space-2)}}"]})};var kt=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[oc,ln,de]})}return n})();var Pr=class{};function Fr(n){return n&&typeof n.connect=="function"&&!(n instanceof km)}var wn=(function(n){return n[n.REPLACED=0]="REPLACED",n[n.INSERTED=1]="INSERTED",n[n.MOVED=2]="MOVED",n[n.REMOVED=3]="REMOVED",n})(wn||{}),zc=class{viewCacheSize=20;_viewCache=[];applyChanges(i,e,t,a,o){i.forEachOperation((c,u,p)=>{let f,b;if(c.previousIndex==null){let w=()=>t(c,u,p);f=this._insertView(w,p,e,a(c)),b=f?wn.INSERTED:wn.REPLACED}else p==null?(this._detachAndCacheView(u,e),b=wn.REMOVED):(f=this._moveView(u,p,e,a(c)),b=wn.MOVED);o&&o({context:f?.context,operation:b,record:c})})}detach(){for(let i of this._viewCache)i.destroy();this._viewCache=[]}_insertView(i,e,t,a){let o=this._insertViewFromCache(e,t);if(o){o.context.$implicit=a;return}let c=i();return t.createEmbeddedView(c.templateRef,c.context,c.index)}_detachAndCacheView(i,e){let t=e.detach(i);this._maybeCacheView(t,e)}_moveView(i,e,t,a){let o=t.get(i);return t.move(o,e),o.context.$implicit=a,o}_maybeCacheView(i,e){if(this._viewCache.length<this.viewCacheSize)this._viewCache.push(i);else{let t=e.indexOf(i);t===-1?i.destroy():e.remove(t)}}_insertViewFromCache(i,e){let t=this._viewCache.pop();return t&&e.insert(t,i),t||null}};var ca=class{_multiple;_emitChanges;compareWith;_selection=new Set;_deselectedToEmit=[];_selectedToEmit=[];_selected=null;get selected(){return this._selected||(this._selected=Array.from(this._selection.values())),this._selected}changed=new F;constructor(i=!1,e,t=!0,a){this._multiple=i,this._emitChanges=t,this.compareWith=a,e&&e.length&&(i?e.forEach(o=>this._markSelected(o)):this._markSelected(e[0]),this._selectedToEmit.length=0)}select(...i){this._verifyValueAssignment(i),i.forEach(t=>this._markSelected(t));let e=this._hasQueuedChanges();return this._emitChangeEvent(),e}deselect(...i){this._verifyValueAssignment(i),i.forEach(t=>this._unmarkSelected(t));let e=this._hasQueuedChanges();return this._emitChangeEvent(),e}setSelection(...i){this._verifyValueAssignment(i);let e=this.selected,t=new Set(i.map(o=>this._getConcreteValue(o)));i.forEach(o=>this._markSelected(o)),e.filter(o=>!t.has(this._getConcreteValue(o,t))).forEach(o=>this._unmarkSelected(o));let a=this._hasQueuedChanges();return this._emitChangeEvent(),a}toggle(i){return this.isSelected(i)?this.deselect(i):this.select(i)}clear(i=!0){this._unmarkAll();let e=this._hasQueuedChanges();return i&&this._emitChangeEvent(),e}isSelected(i){return this._selection.has(this._getConcreteValue(i))}isEmpty(){return this._selection.size===0}hasValue(){return!this.isEmpty()}sort(i){this._multiple&&this.selected&&this._selected.sort(i)}isMultipleSelection(){return this._multiple}_emitChangeEvent(){this._selected=null,(this._selectedToEmit.length||this._deselectedToEmit.length)&&(this.changed.next({source:this,added:this._selectedToEmit,removed:this._deselectedToEmit}),this._deselectedToEmit=[],this._selectedToEmit=[])}_markSelected(i){i=this._getConcreteValue(i),this.isSelected(i)||(this._multiple||this._unmarkAll(),this.isSelected(i)||this._selection.add(i),this._emitChanges&&this._selectedToEmit.push(i))}_unmarkSelected(i){i=this._getConcreteValue(i),this.isSelected(i)&&(this._selection.delete(i),this._emitChanges&&this._deselectedToEmit.push(i))}_unmarkAll(){this.isEmpty()||this._selection.forEach(i=>this._unmarkSelected(i))}_verifyValueAssignment(i){i.length>1&&this._multiple}_hasQueuedChanges(){return!!(this._deselectedToEmit.length||this._selectedToEmit.length)}_getConcreteValue(i,e){if(this.compareWith){e=e??this._selection;for(let t of e)if(this.compareWith(i,t))return t;return i}else return i}};var Nr=(()=>{class n{_listeners=[];notify(e,t){for(let a of this._listeners)a(e,t)}listen(e){return this._listeners.push(e),()=>{this._listeners=this._listeners.filter(t=>e!==t)}}ngOnDestroy(){this._listeners=[]}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var Uc=class{applyChanges(i,e,t,a,o){i.forEachOperation((c,u,p)=>{let f,b;if(c.previousIndex==null){let w=t(c,u,p);f=e.createEmbeddedView(w.templateRef,w.context,w.index),b=wn.INSERTED}else p==null?(e.remove(u),b=wn.REMOVED):(f=e.get(u),e.move(f,p),b=wn.MOVED);o&&o({context:f?.context,operation:b,record:c})})}detach(){}};var tw=20,da=(()=>{class n{_ngZone=m(W);_platform=m(be);_renderer=m(vt).createRenderer(null,null);_cleanupGlobalListener;constructor(){}_scrolled=new F;_scrolledCount=0;scrollContainers=new Map;register(e){this.scrollContainers.has(e)||this.scrollContainers.set(e,e.elementScrolled().subscribe(()=>this._scrolled.next(e)))}deregister(e){let t=this.scrollContainers.get(e);t&&(t.unsubscribe(),this.scrollContainers.delete(e))}scrolled(e=tw){return this._platform.isBrowser?new Ht(t=>{this._cleanupGlobalListener||(this._cleanupGlobalListener=this._ngZone.runOutsideAngular(()=>this._renderer.listen("document","scroll",()=>this._scrolled.next())));let a=e>0?this._scrolled.pipe(So(e)).subscribe(t):this._scrolled.subscribe(t);return this._scrolledCount++,()=>{a.unsubscribe(),this._scrolledCount--,this._scrolledCount||(this._cleanupGlobalListener?.(),this._cleanupGlobalListener=void 0)}}):K()}ngOnDestroy(){this._cleanupGlobalListener?.(),this._cleanupGlobalListener=void 0,this.scrollContainers.forEach((e,t)=>this.deregister(t)),this._scrolled.complete()}ancestorScrolled(e,t){let a=this.getAncestorScrollContainers(e);return this.scrolled(t).pipe(Ce(o=>!o||a.indexOf(o)>-1))}getAncestorScrollContainers(e){let t=[];return this.scrollContainers.forEach((a,o)=>{this._scrollableContainsElement(o,e)&&t.push(o)}),t}_scrollableContainsElement(e,t){let a=Ut(t),o=e.getElementRef().nativeElement;do if(a==o)return!0;while(a=a.parentElement);return!1}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),Lr=(()=>{class n{elementRef=m(B);scrollDispatcher=m(da);ngZone=m(W);dir=m(Qe,{optional:!0});_scrollElement=this.elementRef.nativeElement;_destroyed=new F;_renderer=m(Se);_cleanupScroll;_elementScrolled=new F;constructor(){}ngOnInit(){this._cleanupScroll=this.ngZone.runOutsideAngular(()=>this._renderer.listen(this._scrollElement,"scroll",e=>this._elementScrolled.next(e))),this.scrollDispatcher.register(this)}ngOnDestroy(){this._cleanupScroll?.(),this._elementScrolled.complete(),this.scrollDispatcher.deregister(this),this._destroyed.next(),this._destroyed.complete()}elementScrolled(){return this._elementScrolled}getElementRef(){return this.elementRef}scrollTo(e){let t=this.elementRef.nativeElement,a=this.dir&&this.dir.value=="rtl";e.left==null&&(e.left=a?e.end:e.start),e.right==null&&(e.right=a?e.start:e.end),e.bottom!=null&&(e.top=t.scrollHeight-t.clientHeight-e.bottom),a&&Ka()!=yn.NORMAL?(e.left!=null&&(e.right=t.scrollWidth-t.clientWidth-e.left),Ka()==yn.INVERTED?e.left=e.right:Ka()==yn.NEGATED&&(e.left=e.right?-e.right:e.right)):e.right!=null&&(e.left=t.scrollWidth-t.clientWidth-e.right),this._applyScrollToOptions(e)}_applyScrollToOptions(e){let t=this.elementRef.nativeElement;pc()?t.scrollTo(e):(e.top!=null&&(t.scrollTop=e.top),e.left!=null&&(t.scrollLeft=e.left))}measureScrollOffset(e){let t="left",a="right",o=this.elementRef.nativeElement;if(e=="top")return o.scrollTop;if(e=="bottom")return o.scrollHeight-o.clientHeight-o.scrollTop;let c=this.dir&&this.dir.value=="rtl";return e=="start"?e=c?a:t:e=="end"&&(e=c?t:a),c&&Ka()==yn.INVERTED?e==t?o.scrollWidth-o.clientWidth-o.scrollLeft:o.scrollLeft:c&&Ka()==yn.NEGATED?e==t?o.scrollLeft+o.scrollWidth-o.clientWidth:-o.scrollLeft:e==t?o.scrollLeft:o.scrollWidth-o.clientWidth-o.scrollLeft}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdk-scrollable",""],["","cdkScrollable",""]]})}return n})(),nw=20,un=(()=>{class n{_platform=m(be);_listeners;_viewportSize=null;_change=new F;_document=m(X);constructor(){let e=m(W),t=m(vt).createRenderer(null,null);e.runOutsideAngular(()=>{if(this._platform.isBrowser){let a=o=>this._change.next(o);this._listeners=[t.listen("window","resize",a),t.listen("window","orientationchange",a)]}this.change().subscribe(()=>this._viewportSize=null)})}ngOnDestroy(){this._listeners?.forEach(e=>e()),this._change.complete()}getViewportSize(){this._viewportSize||this._updateViewportSize();let e={width:this._viewportSize.width,height:this._viewportSize.height};return this._platform.isBrowser||(this._viewportSize=null),e}getViewportRect(){let e=this.getViewportScrollPosition(),{width:t,height:a}=this.getViewportSize();return{top:e.top,left:e.left,bottom:e.top+a,right:e.left+t,height:a,width:t}}getViewportScrollPosition(){if(!this._platform.isBrowser)return{top:0,left:0};let e=this._document,t=this._getWindow(),a=e.documentElement,o=a.getBoundingClientRect(),c=-o.top||e.body?.scrollTop||t.scrollY||a.scrollTop||0,u=-o.left||e.body?.scrollLeft||t.scrollX||a.scrollLeft||0;return{top:c,left:u}}change(e=nw){return e>0?this._change.pipe(So(e)):this._change}_getWindow(){return this._document.defaultView||window}_updateViewportSize(){let e=this._getWindow();this._viewportSize=this._platform.isBrowser?{width:e.innerWidth,height:e.innerHeight}:{width:0,height:0}}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var Vg=new E("CDK_VIRTUAL_SCROLL_VIEWPORT");var la=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({})}return n})(),Br=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[de,la,de,la]})}return n})();var jr=class{_attachedHost=null;attach(i){return this._attachedHost=i,i.attach(this)}detach(){let i=this._attachedHost;i!=null&&(this._attachedHost=null,i.detach())}get isAttached(){return this._attachedHost!=null}setAttachedHost(i){this._attachedHost=i}},Dn=class extends jr{component;viewContainerRef;injector;projectableNodes;bindings;constructor(i,e,t,a,o){super(),this.component=i,this.viewContainerRef=e,this.injector=t,this.projectableNodes=a,this.bindings=o||null}},Qt=class extends jr{templateRef;viewContainerRef;context;injector;constructor(i,e,t,a){super(),this.templateRef=i,this.viewContainerRef=e,this.context=t,this.injector=a}get origin(){return this.templateRef.elementRef}attach(i,e=this.context){return this.context=e,super.attach(i)}detach(){return this.context=void 0,super.detach()}},Pu=class extends jr{element;constructor(i){super(),this.element=i instanceof B?i.nativeElement:i}},Fi=class{_attachedPortal=null;_disposeFn=null;_isDisposed=!1;hasAttached(){return!!this._attachedPortal}attach(i){if(i instanceof Dn)return this._attachedPortal=i,this.attachComponentPortal(i);if(i instanceof Qt)return this._attachedPortal=i,this.attachTemplatePortal(i);if(this.attachDomPortal&&i instanceof Pu)return this._attachedPortal=i,this.attachDomPortal(i)}attachDomPortal=null;detach(){this._attachedPortal&&(this._attachedPortal.setAttachedHost(null),this._attachedPortal=null),this._invokeDisposeFn()}dispose(){this.hasAttached()&&this.detach(),this._invokeDisposeFn(),this._isDisposed=!0}setDisposeFn(i){this._disposeFn=i}_invokeDisposeFn(){this._disposeFn&&(this._disposeFn(),this._disposeFn=null)}},Hc=class extends Fi{outletElement;_appRef;_defaultInjector;constructor(i,e,t){super(),this.outletElement=i,this._appRef=e,this._defaultInjector=t}attachComponentPortal(i){let e;if(i.viewContainerRef){let t=i.injector||i.viewContainerRef.injector,a=t.get(as,null,{optional:!0})||void 0;e=i.viewContainerRef.createComponent(i.component,{index:i.viewContainerRef.length,injector:t,ngModuleRef:a,projectableNodes:i.projectableNodes||void 0,bindings:i.bindings||void 0}),this.setDisposeFn(()=>e.destroy())}else{let t=this._appRef,a=i.injector||this._defaultInjector||re.NULL,o=a.get(bt,t.injector);e=rs(i.component,{elementInjector:a,environmentInjector:o,projectableNodes:i.projectableNodes||void 0,bindings:i.bindings||void 0}),t.attachView(e.hostView),this.setDisposeFn(()=>{t.viewCount>0&&t.detachView(e.hostView),e.destroy()})}return this.outletElement.appendChild(this._getComponentRootNode(e)),this._attachedPortal=i,e}attachTemplatePortal(i){let e=i.viewContainerRef,t=e.createEmbeddedView(i.templateRef,i.context,{injector:i.injector});return t.rootNodes.forEach(a=>this.outletElement.appendChild(a)),t.detectChanges(),this.setDisposeFn(()=>{let a=e.indexOf(t);a!==-1&&e.remove(a)}),this._attachedPortal=i,t}attachDomPortal=i=>{let e=i.element;e.parentNode;let t=this.outletElement.ownerDocument.createComment("dom-portal");e.parentNode.insertBefore(t,e),this.outletElement.appendChild(e),this._attachedPortal=i,super.setDisposeFn(()=>{t.parentNode&&t.parentNode.replaceChild(e,t)})};dispose(){super.dispose(),this.outletElement.remove()}_getComponentRootNode(i){return i.hostView.rootNodes[0]}},zg=(()=>{class n extends Qt{constructor(){let e=m(He),t=m(Xe);super(e,t)}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdkPortal",""]],exportAs:["cdkPortal"],features:[ie]})}return n})(),tn=(()=>{class n extends Fi{_moduleRef=m(as,{optional:!0});_document=m(X);_viewContainerRef=m(Xe);_isInitialized=!1;_attachedRef=null;constructor(){super()}get portal(){return this._attachedPortal}set portal(e){this.hasAttached()&&!e&&!this._isInitialized||(this.hasAttached()&&super.detach(),e&&super.attach(e),this._attachedPortal=e||null)}attached=new z;get attachedRef(){return this._attachedRef}ngOnInit(){this._isInitialized=!0}ngOnDestroy(){super.dispose(),this._attachedRef=this._attachedPortal=null}attachComponentPortal(e){e.setAttachedHost(this);let t=e.viewContainerRef!=null?e.viewContainerRef:this._viewContainerRef,a=t.createComponent(e.component,{index:t.length,injector:e.injector||t.injector,projectableNodes:e.projectableNodes||void 0,ngModuleRef:this._moduleRef||void 0,bindings:e.bindings||void 0});return t!==this._viewContainerRef&&this._getRootNode().appendChild(a.hostView.rootNodes[0]),super.setDisposeFn(()=>a.destroy()),this._attachedPortal=e,this._attachedRef=a,this.attached.emit(a),a}attachTemplatePortal(e){e.setAttachedHost(this);let t=this._viewContainerRef.createEmbeddedView(e.templateRef,e.context,{injector:e.injector});return super.setDisposeFn(()=>this._viewContainerRef.clear()),this._attachedPortal=e,this._attachedRef=t,this.attached.emit(t),t}attachDomPortal=e=>{let t=e.element;t.parentNode;let a=this._document.createComment("dom-portal");e.setAttachedHost(this),t.parentNode.insertBefore(a,t),this._getRootNode().appendChild(t),this._attachedPortal=e,super.setDisposeFn(()=>{a.parentNode&&a.parentNode.replaceChild(t,a)})};_getRootNode(){let e=this._viewContainerRef.element.nativeElement;return e.nodeType===e.ELEMENT_NODE?e:e.parentNode}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdkPortalOutlet",""]],inputs:{portal:[0,"cdkPortalOutlet","portal"]},outputs:{attached:"attached"},exportAs:["cdkPortalOutlet"],features:[ie]})}return n})(),En=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({})}return n})();var Ug=pc();function mo(n){return new $c(n.get(un),n.get(X))}var $c=class{_viewportRuler;_previousHTMLStyles={top:"",left:""};_previousScrollPosition;_isEnabled=!1;_document;constructor(i,e){this._viewportRuler=i,this._document=e}attach(){}enable(){if(this._canBeEnabled()){let i=this._document.documentElement;this._previousScrollPosition=this._viewportRuler.getViewportScrollPosition(),this._previousHTMLStyles.left=i.style.left||"",this._previousHTMLStyles.top=i.style.top||"",i.style.left=nt(-this._previousScrollPosition.left),i.style.top=nt(-this._previousScrollPosition.top),i.classList.add("cdk-global-scrollblock"),this._isEnabled=!0}}disable(){if(this._isEnabled){let i=this._document.documentElement,e=this._document.body,t=i.style,a=e.style,o=t.scrollBehavior||"",c=a.scrollBehavior||"";this._isEnabled=!1,t.left=this._previousHTMLStyles.left,t.top=this._previousHTMLStyles.top,i.classList.remove("cdk-global-scrollblock"),Ug&&(t.scrollBehavior=a.scrollBehavior="auto"),window.scroll(this._previousScrollPosition.left,this._previousScrollPosition.top),Ug&&(t.scrollBehavior=o,a.scrollBehavior=c)}}_canBeEnabled(){if(this._document.documentElement.classList.contains("cdk-global-scrollblock")||this._isEnabled)return!1;let e=this._document.documentElement,t=this._viewportRuler.getViewportSize();return e.scrollHeight>t.height||e.scrollWidth>t.width}};function Yg(n,i){return new Gc(n.get(da),n.get(W),n.get(un),i)}var Gc=class{_scrollDispatcher;_ngZone;_viewportRuler;_config;_scrollSubscription=null;_overlayRef;_initialScrollPosition;constructor(i,e,t,a){this._scrollDispatcher=i,this._ngZone=e,this._viewportRuler=t,this._config=a}attach(i){this._overlayRef,this._overlayRef=i}enable(){if(this._scrollSubscription)return;let i=this._scrollDispatcher.scrolled(0).pipe(Ce(e=>!e||!this._overlayRef.overlayElement.contains(e.getElementRef().nativeElement)));this._config&&this._config.threshold&&this._config.threshold>1?(this._initialScrollPosition=this._viewportRuler.getViewportScrollPosition().top,this._scrollSubscription=i.subscribe(()=>{let e=this._viewportRuler.getViewportScrollPosition().top;Math.abs(e-this._initialScrollPosition)>this._config.threshold?this._detach():this._overlayRef.updatePosition()})):this._scrollSubscription=i.subscribe(this._detach)}disable(){this._scrollSubscription&&(this._scrollSubscription.unsubscribe(),this._scrollSubscription=null)}detach(){this.disable(),this._overlayRef=null}_detach=()=>{this.disable(),this._overlayRef.hasAttached()&&this._ngZone.run(()=>this._overlayRef.detach())}};var Vr=class{enable(){}disable(){}attach(){}};function Fu(n,i){return i.some(e=>{let t=n.bottom<e.top,a=n.top>e.bottom,o=n.right<e.left,c=n.left>e.right;return t||a||o||c})}function Hg(n,i){return i.some(e=>{let t=n.top<e.top,a=n.bottom>e.bottom,o=n.left<e.left,c=n.right>e.right;return t||a||o||c})}function pa(n,i){return new qc(n.get(da),n.get(un),n.get(W),i)}var qc=class{_scrollDispatcher;_viewportRuler;_ngZone;_config;_scrollSubscription=null;_overlayRef;constructor(i,e,t,a){this._scrollDispatcher=i,this._viewportRuler=e,this._ngZone=t,this._config=a}attach(i){this._overlayRef,this._overlayRef=i}enable(){if(!this._scrollSubscription){let i=this._config?this._config.scrollThrottle:0;this._scrollSubscription=this._scrollDispatcher.scrolled(i).subscribe(()=>{if(this._overlayRef.updatePosition(),this._config&&this._config.autoClose){let e=this._overlayRef.overlayElement.getBoundingClientRect(),{width:t,height:a}=this._viewportRuler.getViewportSize();Fu(e,[{width:t,height:a,bottom:a,right:t,top:0,left:0}])&&(this.disable(),this._ngZone.run(()=>this._overlayRef.detach()))}})}}disable(){this._scrollSubscription&&(this._scrollSubscription.unsubscribe(),this._scrollSubscription=null)}detach(){this.disable(),this._overlayRef=null}},Xg=(()=>{class n{_injector=m(re);constructor(){}noop=()=>new Vr;close=e=>Yg(this._injector,e);block=()=>mo(this._injector);reposition=e=>pa(this._injector,e);static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),ri=class{positionStrategy;scrollStrategy=new Vr;panelClass="";hasBackdrop=!1;backdropClass="cdk-overlay-dark-backdrop";disableAnimations;width;height;minWidth;minHeight;maxWidth;maxHeight;direction;disposeOnNavigation=!1;usePopover;eventPredicate;constructor(i){if(i){let e=Object.keys(i);for(let t of e)i[t]!==void 0&&(this[t]=i[t])}}};var Wc=class{connectionPair;scrollableViewProperties;constructor(i,e){this.connectionPair=i,this.scrollableViewProperties=e}};var Kg=(()=>{class n{_attachedOverlays=[];_document=m(X);_isAttached=!1;constructor(){}ngOnDestroy(){this.detach()}add(e){this.remove(e),this._attachedOverlays.push(e)}remove(e){let t=this._attachedOverlays.indexOf(e);t>-1&&this._attachedOverlays.splice(t,1),this._attachedOverlays.length===0&&this.detach()}canReceiveEvent(e,t,a){return a.observers.length<1?!1:e.eventPredicate?e.eventPredicate(t):!0}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),Zg=(()=>{class n extends Kg{_ngZone=m(W);_renderer=m(vt).createRenderer(null,null);_cleanupKeydown;add(e){super.add(e),this._isAttached||(this._ngZone.runOutsideAngular(()=>{this._cleanupKeydown=this._renderer.listen("body","keydown",this._keydownListener)}),this._isAttached=!0)}detach(){this._isAttached&&(this._cleanupKeydown?.(),this._isAttached=!1)}_keydownListener=e=>{let t=this._attachedOverlays;for(let a=t.length-1;a>-1;a--){let o=t[a];if(this.canReceiveEvent(o,e,o._keydownEvents)){this._ngZone.run(()=>o._keydownEvents.next(e));break}}};static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),Jg=(()=>{class n extends Kg{_platform=m(be);_ngZone=m(W);_renderer=m(vt).createRenderer(null,null);_cursorOriginalValue;_cursorStyleIsSet=!1;_pointerDownEventTarget=null;_cleanups;add(e){if(super.add(e),!this._isAttached){let t=this._document.body,a={capture:!0},o=this._renderer;this._cleanups=this._ngZone.runOutsideAngular(()=>[o.listen(t,"pointerdown",this._pointerDownListener,a),o.listen(t,"click",this._clickListener,a),o.listen(t,"auxclick",this._clickListener,a),o.listen(t,"contextmenu",this._clickListener,a)]),this._platform.IOS&&!this._cursorStyleIsSet&&(this._cursorOriginalValue=t.style.cursor,t.style.cursor="pointer",this._cursorStyleIsSet=!0),this._isAttached=!0}}detach(){this._isAttached&&(this._cleanups?.forEach(e=>e()),this._cleanups=void 0,this._platform.IOS&&this._cursorStyleIsSet&&(this._document.body.style.cursor=this._cursorOriginalValue,this._cursorStyleIsSet=!1),this._isAttached=!1)}_pointerDownListener=e=>{this._pointerDownEventTarget=wt(e)};_clickListener=e=>{let t=wt(e),a=e.type==="click"&&this._pointerDownEventTarget?this._pointerDownEventTarget:t;this._pointerDownEventTarget=null;let o=this._attachedOverlays.slice();for(let c=o.length-1;c>-1;c--){let u=o[c],p=u._outsidePointerEvents;if(!(!u.hasAttached()||!this.canReceiveEvent(u,e,p))){if($g(u.overlayElement,t)||$g(u.overlayElement,a))break;this._ngZone?this._ngZone.run(()=>p.next(e)):p.next(e)}}};static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();function $g(n,i){let e=typeof ShadowRoot<"u"&&ShadowRoot,t=i;for(;t;){if(t===n)return!0;t=e&&t instanceof ShadowRoot?t.host:t.parentNode}return!1}var e_=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["ng-component"]],hostAttrs:["cdk-overlay-style-loader",""],decls:0,vars:0,template:function(t,a){},styles:[`.cdk-overlay-container, .cdk-global-overlay-wrapper {
  pointer-events: none;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
}

.cdk-overlay-container {
  position: fixed;
}
@layer cdk-overlay {
  .cdk-overlay-container {
    z-index: 1000;
  }
}
.cdk-overlay-container:empty {
  display: none;
}

.cdk-global-overlay-wrapper {
  display: flex;
  position: absolute;
}
@layer cdk-overlay {
  .cdk-global-overlay-wrapper {
    z-index: 1000;
  }
}

.cdk-overlay-pane {
  position: absolute;
  pointer-events: auto;
  box-sizing: border-box;
  display: flex;
  max-width: 100%;
  max-height: 100%;
}
@layer cdk-overlay {
  .cdk-overlay-pane {
    z-index: 1000;
  }
}

.cdk-overlay-backdrop {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  pointer-events: auto;
  -webkit-tap-highlight-color: transparent;
  opacity: 0;
  touch-action: manipulation;
}
@layer cdk-overlay {
  .cdk-overlay-backdrop {
    z-index: 1000;
    transition: opacity 400ms cubic-bezier(0.25, 0.8, 0.25, 1);
  }
}
@media (prefers-reduced-motion) {
  .cdk-overlay-backdrop {
    transition-duration: 1ms;
  }
}

.cdk-overlay-backdrop-showing {
  opacity: 1;
}
@media (forced-colors: active) {
  .cdk-overlay-backdrop-showing {
    opacity: 0.6;
  }
}

@layer cdk-overlay {
  .cdk-overlay-dark-backdrop {
    background: rgba(0, 0, 0, 0.32);
  }
}

.cdk-overlay-transparent-backdrop {
  transition: visibility 1ms linear, opacity 1ms linear;
  visibility: hidden;
  opacity: 1;
}
.cdk-overlay-transparent-backdrop.cdk-overlay-backdrop-showing, .cdk-high-contrast-active .cdk-overlay-transparent-backdrop {
  opacity: 0;
  visibility: visible;
}

.cdk-overlay-backdrop-noop-animation {
  transition: none;
}

.cdk-overlay-connected-position-bounding-box {
  position: absolute;
  display: flex;
  flex-direction: column;
  min-width: 1px;
  min-height: 1px;
}
@layer cdk-overlay {
  .cdk-overlay-connected-position-bounding-box {
    z-index: 1000;
  }
}

.cdk-global-scrollblock {
  position: fixed;
  width: 100%;
  overflow-y: scroll;
}

.cdk-overlay-popover {
  background: none;
  border: none;
  padding: 0;
  outline: 0;
  overflow: visible;
  position: fixed;
  pointer-events: none;
  white-space: normal;
  color: inherit;
  text-decoration: none;
  width: 100%;
  height: 100%;
  inset: auto;
  top: 0;
  left: 0;
}
.cdk-overlay-popover::backdrop {
  display: none;
}
.cdk-overlay-popover .cdk-overlay-backdrop {
  position: fixed;
  z-index: auto;
}
`],encapsulation:2,changeDetection:0})}return n})(),Xc=(()=>{class n{_platform=m(be);_containerElement;_document=m(X);_styleLoader=m(Oe);constructor(){}ngOnDestroy(){this._containerElement?.remove()}getContainerElement(){return this._loadStyles(),this._containerElement||this._createContainer(),this._containerElement}_createContainer(){let e="cdk-overlay-container";if(this._platform.isBrowser||mu()){let a=this._document.querySelectorAll(`.${e}[platform="server"], .${e}[platform="test"]`);for(let o=0;o<a.length;o++)a[o].remove()}let t=this._document.createElement("div");t.classList.add(e),mu()?t.setAttribute("platform","test"):this._platform.isBrowser||t.setAttribute("platform","server"),this._document.body.appendChild(t),this._containerElement=t}_loadStyles(){this._styleLoader.load(e_)}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),Nu=class{_renderer;_ngZone;element;_cleanupClick;_cleanupTransitionEnd;_fallbackTimeout;constructor(i,e,t,a){this._renderer=e,this._ngZone=t,this.element=i.createElement("div"),this.element.classList.add("cdk-overlay-backdrop"),this._cleanupClick=e.listen(this.element,"click",a)}detach(){this._ngZone.runOutsideAngular(()=>{let i=this.element;clearTimeout(this._fallbackTimeout),this._cleanupTransitionEnd?.(),this._cleanupTransitionEnd=this._renderer.listen(i,"transitionend",this.dispose),this._fallbackTimeout=setTimeout(this.dispose,500),i.style.pointerEvents="none",i.classList.remove("cdk-overlay-backdrop-showing")})}dispose=()=>{clearTimeout(this._fallbackTimeout),this._cleanupClick?.(),this._cleanupTransitionEnd?.(),this._cleanupClick=this._cleanupTransitionEnd=this._fallbackTimeout=void 0,this.element.remove()}};function Lu(n){return n&&n.nodeType===1}var lo=class{_portalOutlet;_host;_pane;_config;_ngZone;_keyboardDispatcher;_document;_location;_outsideClickDispatcher;_animationsDisabled;_injector;_renderer;_backdropClick=new F;_attachments=new F;_detachments=new F;_positionStrategy;_scrollStrategy;_locationChanges=Le.EMPTY;_backdropRef=null;_detachContentMutationObserver;_detachContentAfterRenderRef;_disposed=!1;_previousHostParent;_keydownEvents=new F;_outsidePointerEvents=new F;_afterNextRenderRef;constructor(i,e,t,a,o,c,u,p,f,b=!1,w,L){this._portalOutlet=i,this._host=e,this._pane=t,this._config=a,this._ngZone=o,this._keyboardDispatcher=c,this._document=u,this._location=p,this._outsideClickDispatcher=f,this._animationsDisabled=b,this._injector=w,this._renderer=L,a.scrollStrategy&&(this._scrollStrategy=a.scrollStrategy,this._scrollStrategy.attach(this)),this._positionStrategy=a.positionStrategy}get overlayElement(){return this._pane}get backdropElement(){return this._backdropRef?.element||null}get hostElement(){return this._host}get eventPredicate(){return this._config?.eventPredicate||null}attach(i){if(this._disposed)return null;this._attachHost();let e=this._portalOutlet.attach(i);return this._positionStrategy?.attach(this),this._updateStackingOrder(),this._updateElementSize(),this._updateElementDirection(),this._scrollStrategy&&this._scrollStrategy.enable(),this._afterNextRenderRef?.destroy(),this._afterNextRenderRef=Pe(()=>{this.hasAttached()&&this.updatePosition()},{injector:this._injector}),this._togglePointerEvents(!0),this._config.hasBackdrop&&this._attachBackdrop(),this._config.panelClass&&this._toggleClasses(this._pane,this._config.panelClass,!0),this._attachments.next(),this._completeDetachContent(),this._keyboardDispatcher.add(this),this._config.disposeOnNavigation&&(this._locationChanges=this._location.subscribe(()=>this.dispose())),this._outsideClickDispatcher.add(this),typeof e?.onDestroy=="function"&&e.onDestroy(()=>{this.hasAttached()&&this._ngZone.runOutsideAngular(()=>Promise.resolve().then(()=>this.detach()))}),e}detach(){if(!this.hasAttached())return;this.detachBackdrop(),this._togglePointerEvents(!1),this._positionStrategy&&this._positionStrategy.detach&&this._positionStrategy.detach(),this._scrollStrategy&&this._scrollStrategy.disable();let i=this._portalOutlet.detach();return this._detachments.next(),this._completeDetachContent(),this._keyboardDispatcher.remove(this),this._detachContentWhenEmpty(),this._locationChanges.unsubscribe(),this._outsideClickDispatcher.remove(this),i}dispose(){if(this._disposed)return;let i=this.hasAttached();this._positionStrategy&&this._positionStrategy.dispose(),this._disposeScrollStrategy(),this._backdropRef?.dispose(),this._locationChanges.unsubscribe(),this._keyboardDispatcher.remove(this),this._portalOutlet.dispose(),this._attachments.complete(),this._backdropClick.complete(),this._keydownEvents.complete(),this._outsidePointerEvents.complete(),this._outsideClickDispatcher.remove(this),this._host?.remove(),this._afterNextRenderRef?.destroy(),this._previousHostParent=this._pane=this._host=this._backdropRef=null,i&&this._detachments.next(),this._detachments.complete(),this._completeDetachContent(),this._disposed=!0}hasAttached(){return this._portalOutlet.hasAttached()}backdropClick(){return this._backdropClick}attachments(){return this._attachments}detachments(){return this._detachments}keydownEvents(){return this._keydownEvents}outsidePointerEvents(){return this._outsidePointerEvents}getConfig(){return this._config}updatePosition(){this._positionStrategy&&this._positionStrategy.apply()}updatePositionStrategy(i){i!==this._positionStrategy&&(this._positionStrategy&&this._positionStrategy.dispose(),this._positionStrategy=i,this.hasAttached()&&(i.attach(this),this.updatePosition()))}updateSize(i){this._config=M(M({},this._config),i),this._updateElementSize()}setDirection(i){this._config=Re(M({},this._config),{direction:i}),this._updateElementDirection()}addPanelClass(i){this._pane&&this._toggleClasses(this._pane,i,!0)}removePanelClass(i){this._pane&&this._toggleClasses(this._pane,i,!1)}getDirection(){let i=this._config.direction;return i?typeof i=="string"?i:i.value:"ltr"}updateScrollStrategy(i){i!==this._scrollStrategy&&(this._disposeScrollStrategy(),this._scrollStrategy=i,this.hasAttached()&&(i.attach(this),i.enable()))}_updateElementDirection(){this._host.setAttribute("dir",this.getDirection())}_updateElementSize(){if(!this._pane)return;let i=this._pane.style;i.width=nt(this._config.width),i.height=nt(this._config.height),i.minWidth=nt(this._config.minWidth),i.minHeight=nt(this._config.minHeight),i.maxWidth=nt(this._config.maxWidth),i.maxHeight=nt(this._config.maxHeight)}_togglePointerEvents(i){this._pane.style.pointerEvents=i?"":"none"}_attachHost(){if(!this._host.parentElement){let i=this._config.usePopover?this._positionStrategy?.getPopoverInsertionPoint?.():null;Lu(i)?i.after(this._host):i?.type==="parent"?i.element.appendChild(this._host):this._previousHostParent?.appendChild(this._host)}if(this._config.usePopover)try{this._host.showPopover()}catch(i){}}_attachBackdrop(){let i="cdk-overlay-backdrop-showing";this._backdropRef?.dispose(),this._backdropRef=new Nu(this._document,this._renderer,this._ngZone,e=>{this._backdropClick.next(e)}),this._animationsDisabled&&this._backdropRef.element.classList.add("cdk-overlay-backdrop-noop-animation"),this._config.backdropClass&&this._toggleClasses(this._backdropRef.element,this._config.backdropClass,!0),this._config.usePopover?this._host.prepend(this._backdropRef.element):this._host.parentElement.insertBefore(this._backdropRef.element,this._host),!this._animationsDisabled&&typeof requestAnimationFrame<"u"?this._ngZone.runOutsideAngular(()=>{requestAnimationFrame(()=>this._backdropRef?.element.classList.add(i))}):this._backdropRef.element.classList.add(i)}_updateStackingOrder(){!this._config.usePopover&&this._host.nextSibling&&this._host.parentNode.appendChild(this._host)}detachBackdrop(){this._animationsDisabled?(this._backdropRef?.dispose(),this._backdropRef=null):this._backdropRef?.detach()}_toggleClasses(i,e,t){let a=Qa(e||[]).filter(o=>!!o);a.length&&(t?i.classList.add(...a):i.classList.remove(...a))}_detachContentWhenEmpty(){let i=!1;try{this._detachContentAfterRenderRef=Pe(()=>{i=!0,this._detachContent()},{injector:this._injector})}catch(e){if(i)throw e;this._detachContent()}globalThis.MutationObserver&&this._pane&&(this._detachContentMutationObserver||=new globalThis.MutationObserver(()=>{this._detachContent()}),this._detachContentMutationObserver.observe(this._pane,{childList:!0}))}_detachContent(){(!this._pane||!this._host||this._pane.children.length===0)&&(this._pane&&this._config.panelClass&&this._toggleClasses(this._pane,this._config.panelClass,!1),this._host&&this._host.parentElement&&(this._previousHostParent=this._host.parentElement,this._host.remove()),this._completeDetachContent())}_completeDetachContent(){this._detachContentAfterRenderRef?.destroy(),this._detachContentAfterRenderRef=void 0,this._detachContentMutationObserver?.disconnect()}_disposeScrollStrategy(){let i=this._scrollStrategy;i?.disable(),i?.detach?.()}},Gg="cdk-overlay-connected-position-bounding-box",aw=/([A-Za-z%]+)$/;function zr(n,i){return new Qc(i,n.get(un),n.get(X),n.get(be),n.get(Xc))}var Qc=class{_viewportRuler;_document;_platform;_overlayContainer;_overlayRef;_isInitialRender=!1;_lastBoundingBoxSize={width:0,height:0};_isPushed=!1;_canPush=!0;_growAfterOpen=!1;_hasFlexibleDimensions=!0;_positionLocked=!1;_originRect;_overlayRect;_viewportRect;_containerRect;_viewportMargin=0;_scrollables=[];_preferredPositions=[];_origin;_pane;_isDisposed=!1;_boundingBox=null;_lastPosition=null;_lastScrollVisibility=null;_positionChanges=new F;_resizeSubscription=Le.EMPTY;_offsetX=0;_offsetY=0;_transformOriginSelector;_appliedPanelClasses=[];_previousPushAmount=null;_popoverLocation="global";positionChanges=this._positionChanges;get positions(){return this._preferredPositions}constructor(i,e,t,a,o){this._viewportRuler=e,this._document=t,this._platform=a,this._overlayContainer=o,this.setOrigin(i)}attach(i){this._overlayRef&&this._overlayRef,this._validatePositions(),i.hostElement.classList.add(Gg),this._overlayRef=i,this._boundingBox=i.hostElement,this._pane=i.overlayElement,this._isDisposed=!1,this._isInitialRender=!0,this._lastPosition=null,this._resizeSubscription.unsubscribe(),this._resizeSubscription=this._viewportRuler.change().subscribe(()=>{this._isInitialRender=!0,this.apply()})}apply(){if(this._isDisposed||!this._platform.isBrowser)return;if(!this._isInitialRender&&this._positionLocked&&this._lastPosition){this.reapplyLastPosition();return}this._clearPanelClasses(),this._resetOverlayElementStyles(),this._resetBoundingBoxStyles(),this._viewportRect=this._getNarrowedViewportRect(),this._originRect=this._getOriginRect(),this._overlayRect=this._pane.getBoundingClientRect(),this._containerRect=this._getContainerRect();let i=this._originRect,e=this._overlayRect,t=this._viewportRect,a=this._containerRect,o=[],c;for(let u of this._preferredPositions){let p=this._getOriginPoint(i,a,u),f=this._getOverlayPoint(p,e,u),b=this._getOverlayFit(f,e,t,u);if(b.isCompletelyWithinViewport){this._isPushed=!1,this._applyPosition(u,p);return}if(this._canFitWithFlexibleDimensions(b,f,t)){o.push({position:u,origin:p,overlayRect:e,boundingBoxRect:this._calculateBoundingBoxRect(p,u)});continue}(!c||c.overlayFit.visibleArea<b.visibleArea)&&(c={overlayFit:b,overlayPoint:f,originPoint:p,position:u,overlayRect:e})}if(o.length){let u=null,p=-1;for(let f of o){let b=f.boundingBoxRect.width*f.boundingBoxRect.height*(f.position.weight||1);b>p&&(p=b,u=f)}this._isPushed=!1,this._applyPosition(u.position,u.origin);return}if(this._canPush){this._isPushed=!0,this._applyPosition(c.position,c.originPoint);return}this._applyPosition(c.position,c.originPoint)}detach(){this._clearPanelClasses(),this._lastPosition=null,this._previousPushAmount=null,this._resizeSubscription.unsubscribe()}dispose(){this._isDisposed||(this._boundingBox&&ua(this._boundingBox.style,{top:"",left:"",right:"",bottom:"",height:"",width:"",alignItems:"",justifyContent:""}),this._pane&&this._resetOverlayElementStyles(),this._overlayRef&&this._overlayRef.hostElement.classList.remove(Gg),this.detach(),this._positionChanges.complete(),this._overlayRef=this._boundingBox=null,this._isDisposed=!0)}reapplyLastPosition(){if(this._isDisposed||!this._platform.isBrowser)return;let i=this._lastPosition;i?(this._originRect=this._getOriginRect(),this._overlayRect=this._pane.getBoundingClientRect(),this._viewportRect=this._getNarrowedViewportRect(),this._containerRect=this._getContainerRect(),this._applyPosition(i,this._getOriginPoint(this._originRect,this._containerRect,i))):this.apply()}withScrollableContainers(i){return this._scrollables=i,this}withPositions(i){return this._preferredPositions=i,i.indexOf(this._lastPosition)===-1&&(this._lastPosition=null),this._validatePositions(),this}withViewportMargin(i){return this._viewportMargin=i,this}withFlexibleDimensions(i=!0){return this._hasFlexibleDimensions=i,this}withGrowAfterOpen(i=!0){return this._growAfterOpen=i,this}withPush(i=!0){return this._canPush=i,this}withLockedPosition(i=!0){return this._positionLocked=i,this}setOrigin(i){return this._origin=i,this}withDefaultOffsetX(i){return this._offsetX=i,this}withDefaultOffsetY(i){return this._offsetY=i,this}withTransformOriginOn(i){return this._transformOriginSelector=i,this}withPopoverLocation(i){return this._popoverLocation=i,this}getPopoverInsertionPoint(){return this._popoverLocation==="global"?null:this._popoverLocation!=="inline"?this._popoverLocation:this._origin instanceof B?this._origin.nativeElement:Lu(this._origin)?this._origin:null}_getOriginPoint(i,e,t){let a;if(t.originX=="center")a=i.left+i.width/2;else{let c=this._isRtl()?i.right:i.left,u=this._isRtl()?i.left:i.right;a=t.originX=="start"?c:u}e.left<0&&(a-=e.left);let o;return t.originY=="center"?o=i.top+i.height/2:o=t.originY=="top"?i.top:i.bottom,e.top<0&&(o-=e.top),{x:a,y:o}}_getOverlayPoint(i,e,t){let a;t.overlayX=="center"?a=-e.width/2:t.overlayX==="start"?a=this._isRtl()?-e.width:0:a=this._isRtl()?0:-e.width;let o;return t.overlayY=="center"?o=-e.height/2:o=t.overlayY=="top"?0:-e.height,{x:i.x+a,y:i.y+o}}_getOverlayFit(i,e,t,a){let o=Wg(e),{x:c,y:u}=i,p=this._getOffset(a,"x"),f=this._getOffset(a,"y");p&&(c+=p),f&&(u+=f);let b=0-c,w=c+o.width-t.width,L=0-u,$=u+o.height-t.height,ae=this._subtractOverflows(o.width,b,w),me=this._subtractOverflows(o.height,L,$),J=ae*me;return{visibleArea:J,isCompletelyWithinViewport:o.width*o.height===J,fitsInViewportVertically:me===o.height,fitsInViewportHorizontally:ae==o.width}}_canFitWithFlexibleDimensions(i,e,t){if(this._hasFlexibleDimensions){let a=t.bottom-e.y,o=t.right-e.x,c=qg(this._overlayRef.getConfig().minHeight),u=qg(this._overlayRef.getConfig().minWidth),p=i.fitsInViewportVertically||c!=null&&c<=a,f=i.fitsInViewportHorizontally||u!=null&&u<=o;return p&&f}return!1}_pushOverlayOnScreen(i,e,t){if(this._previousPushAmount&&this._positionLocked)return{x:i.x+this._previousPushAmount.x,y:i.y+this._previousPushAmount.y};let a=Wg(e),o=this._viewportRect,c=Math.max(i.x+a.width-o.width,0),u=Math.max(i.y+a.height-o.height,0),p=Math.max(o.top-t.top-i.y,0),f=Math.max(o.left-t.left-i.x,0),b=0,w=0;return a.width<=o.width?b=f||-c:b=i.x<this._getViewportMarginStart()?o.left-t.left-i.x:0,a.height<=o.height?w=p||-u:w=i.y<this._getViewportMarginTop()?o.top-t.top-i.y:0,this._previousPushAmount={x:b,y:w},{x:i.x+b,y:i.y+w}}_applyPosition(i,e){if(this._setTransformOrigin(i),this._setOverlayElementStyles(e,i),this._setBoundingBoxStyles(e,i),i.panelClass&&this._addPanelClasses(i.panelClass),this._positionChanges.observers.length){let t=this._getScrollVisibility();if(i!==this._lastPosition||!this._lastScrollVisibility||!ow(this._lastScrollVisibility,t)){let a=new Wc(i,t);this._positionChanges.next(a)}this._lastScrollVisibility=t}this._lastPosition=i,this._isInitialRender=!1}_setTransformOrigin(i){if(!this._transformOriginSelector)return;let e=this._boundingBox.querySelectorAll(this._transformOriginSelector),t,a=i.overlayY;i.overlayX==="center"?t="center":this._isRtl()?t=i.overlayX==="start"?"right":"left":t=i.overlayX==="start"?"left":"right";for(let o=0;o<e.length;o++)e[o].style.transformOrigin=`${t} ${a}`}_calculateBoundingBoxRect(i,e){let t=this._viewportRect,a=this._isRtl(),o,c,u;if(e.overlayY==="top")c=i.y,o=t.height-c+this._getViewportMarginBottom();else if(e.overlayY==="bottom")u=t.height-i.y+this._getViewportMarginTop()+this._getViewportMarginBottom(),o=t.height-u+this._getViewportMarginTop();else{let $=Math.min(t.bottom-i.y+t.top,i.y),ae=this._lastBoundingBoxSize.height;o=$*2,c=i.y-$,o>ae&&!this._isInitialRender&&!this._growAfterOpen&&(c=i.y-ae/2)}let p=e.overlayX==="start"&&!a||e.overlayX==="end"&&a,f=e.overlayX==="end"&&!a||e.overlayX==="start"&&a,b,w,L;if(f)L=t.width-i.x+this._getViewportMarginStart()+this._getViewportMarginEnd(),b=i.x-this._getViewportMarginStart();else if(p)w=i.x,b=t.right-i.x-this._getViewportMarginEnd();else{let $=Math.min(t.right-i.x+t.left,i.x),ae=this._lastBoundingBoxSize.width;b=$*2,w=i.x-$,b>ae&&!this._isInitialRender&&!this._growAfterOpen&&(w=i.x-ae/2)}return{top:c,left:w,bottom:u,right:L,width:b,height:o}}_setBoundingBoxStyles(i,e){let t=this._calculateBoundingBoxRect(i,e);!this._isInitialRender&&!this._growAfterOpen&&(t.height=Math.min(t.height,this._lastBoundingBoxSize.height),t.width=Math.min(t.width,this._lastBoundingBoxSize.width));let a={};if(this._hasExactPosition())a.top=a.left="0",a.bottom=a.right="auto",a.maxHeight=a.maxWidth="",a.width=a.height="100%";else{let o=this._overlayRef.getConfig().maxHeight,c=this._overlayRef.getConfig().maxWidth;a.width=nt(t.width),a.height=nt(t.height),a.top=nt(t.top)||"auto",a.bottom=nt(t.bottom)||"auto",a.left=nt(t.left)||"auto",a.right=nt(t.right)||"auto",e.overlayX==="center"?a.alignItems="center":a.alignItems=e.overlayX==="end"?"flex-end":"flex-start",e.overlayY==="center"?a.justifyContent="center":a.justifyContent=e.overlayY==="bottom"?"flex-end":"flex-start",o&&(a.maxHeight=nt(o)),c&&(a.maxWidth=nt(c))}this._lastBoundingBoxSize=t,ua(this._boundingBox.style,a)}_resetBoundingBoxStyles(){ua(this._boundingBox.style,{top:"0",left:"0",right:"0",bottom:"0",height:"",width:"",alignItems:"",justifyContent:""})}_resetOverlayElementStyles(){ua(this._pane.style,{top:"",left:"",bottom:"",right:"",position:"",transform:""})}_setOverlayElementStyles(i,e){let t={},a=this._hasExactPosition(),o=this._hasFlexibleDimensions,c=this._overlayRef.getConfig();if(a){let b=this._viewportRuler.getViewportScrollPosition();ua(t,this._getExactOverlayY(e,i,b)),ua(t,this._getExactOverlayX(e,i,b))}else t.position="static";let u="",p=this._getOffset(e,"x"),f=this._getOffset(e,"y");p&&(u+=`translateX(${p}px) `),f&&(u+=`translateY(${f}px)`),t.transform=u.trim(),c.maxHeight&&(a?t.maxHeight=nt(c.maxHeight):o&&(t.maxHeight="")),c.maxWidth&&(a?t.maxWidth=nt(c.maxWidth):o&&(t.maxWidth="")),ua(this._pane.style,t)}_getExactOverlayY(i,e,t){let a={top:"",bottom:""},o=this._getOverlayPoint(e,this._overlayRect,i);if(this._isPushed&&(o=this._pushOverlayOnScreen(o,this._overlayRect,t)),i.overlayY==="bottom"){let c=this._document.documentElement.clientHeight;a.bottom=`${c-(o.y+this._overlayRect.height)}px`}else a.top=nt(o.y);return a}_getExactOverlayX(i,e,t){let a={left:"",right:""},o=this._getOverlayPoint(e,this._overlayRect,i);this._isPushed&&(o=this._pushOverlayOnScreen(o,this._overlayRect,t));let c;if(this._isRtl()?c=i.overlayX==="end"?"left":"right":c=i.overlayX==="end"?"right":"left",c==="right"){let u=this._document.documentElement.clientWidth;a.right=`${u-(o.x+this._overlayRect.width)}px`}else a.left=nt(o.x);return a}_getScrollVisibility(){let i=this._getOriginRect(),e=this._pane.getBoundingClientRect(),t=this._scrollables.map(a=>a.getElementRef().nativeElement.getBoundingClientRect());return{isOriginClipped:Hg(i,t),isOriginOutsideView:Fu(i,t),isOverlayClipped:Hg(e,t),isOverlayOutsideView:Fu(e,t)}}_subtractOverflows(i,...e){return e.reduce((t,a)=>t-Math.max(a,0),i)}_getNarrowedViewportRect(){let i=this._document.documentElement.clientWidth,e=this._document.documentElement.clientHeight,t=this._viewportRuler.getViewportScrollPosition();return{top:t.top+this._getViewportMarginTop(),left:t.left+this._getViewportMarginStart(),right:t.left+i-this._getViewportMarginEnd(),bottom:t.top+e-this._getViewportMarginBottom(),width:i-this._getViewportMarginStart()-this._getViewportMarginEnd(),height:e-this._getViewportMarginTop()-this._getViewportMarginBottom()}}_isRtl(){return this._overlayRef.getDirection()==="rtl"}_hasExactPosition(){return!this._hasFlexibleDimensions||this._isPushed}_getOffset(i,e){return e==="x"?i.offsetX==null?this._offsetX:i.offsetX:i.offsetY==null?this._offsetY:i.offsetY}_validatePositions(){}_addPanelClasses(i){this._pane&&Qa(i).forEach(e=>{e!==""&&this._appliedPanelClasses.indexOf(e)===-1&&(this._appliedPanelClasses.push(e),this._pane.classList.add(e))})}_clearPanelClasses(){this._pane&&(this._appliedPanelClasses.forEach(i=>{this._pane.classList.remove(i)}),this._appliedPanelClasses=[])}_getViewportMarginStart(){return typeof this._viewportMargin=="number"?this._viewportMargin:this._viewportMargin?.start??0}_getViewportMarginEnd(){return typeof this._viewportMargin=="number"?this._viewportMargin:this._viewportMargin?.end??0}_getViewportMarginTop(){return typeof this._viewportMargin=="number"?this._viewportMargin:this._viewportMargin?.top??0}_getViewportMarginBottom(){return typeof this._viewportMargin=="number"?this._viewportMargin:this._viewportMargin?.bottom??0}_getOriginRect(){let i=this._origin;if(i instanceof B)return i.nativeElement.getBoundingClientRect();if(i instanceof Element)return i.getBoundingClientRect();let e=i.width||0,t=i.height||0;return{top:i.y,bottom:i.y+t,left:i.x,right:i.x+e,height:t,width:e}}_getContainerRect(){let i=this._overlayRef.getConfig().usePopover&&this._popoverLocation!=="global",e=this._overlayContainer.getContainerElement();i&&(e.style.display="block");let t=e.getBoundingClientRect();return i&&(e.style.display=""),t}};function ua(n,i){for(let e in i)i.hasOwnProperty(e)&&(n[e]=i[e]);return n}function qg(n){if(typeof n!="number"&&n!=null){let[i,e]=n.split(aw);return!e||e==="px"?parseFloat(i):null}return n||null}function Wg(n){return{top:Math.floor(n.top),right:Math.floor(n.right),bottom:Math.floor(n.bottom),left:Math.floor(n.left),width:Math.floor(n.width),height:Math.floor(n.height)}}function ow(n,i){return n===i?!0:n.isOriginClipped===i.isOriginClipped&&n.isOriginOutsideView===i.isOriginOutsideView&&n.isOverlayClipped===i.isOverlayClipped&&n.isOverlayOutsideView===i.isOverlayOutsideView}var Qg="cdk-global-overlay-wrapper";function Ni(n){return new Yc}var Yc=class{_overlayRef;_cssPosition="static";_topOffset="";_bottomOffset="";_alignItems="";_xPosition="";_xOffset="";_width="";_height="";_isDisposed=!1;attach(i){let e=i.getConfig();this._overlayRef=i,this._width&&!e.width&&i.updateSize({width:this._width}),this._height&&!e.height&&i.updateSize({height:this._height}),i.hostElement.classList.add(Qg),this._isDisposed=!1}top(i=""){return this._bottomOffset="",this._topOffset=i,this._alignItems="flex-start",this}left(i=""){return this._xOffset=i,this._xPosition="left",this}bottom(i=""){return this._topOffset="",this._bottomOffset=i,this._alignItems="flex-end",this}right(i=""){return this._xOffset=i,this._xPosition="right",this}start(i=""){return this._xOffset=i,this._xPosition="start",this}end(i=""){return this._xOffset=i,this._xPosition="end",this}width(i=""){return this._overlayRef?this._overlayRef.updateSize({width:i}):this._width=i,this}height(i=""){return this._overlayRef?this._overlayRef.updateSize({height:i}):this._height=i,this}centerHorizontally(i=""){return this.left(i),this._xPosition="center",this}centerVertically(i=""){return this.top(i),this._alignItems="center",this}apply(){if(!this._overlayRef||!this._overlayRef.hasAttached())return;let i=this._overlayRef.overlayElement.style,e=this._overlayRef.hostElement.style,t=this._overlayRef.getConfig(),{width:a,height:o,maxWidth:c,maxHeight:u}=t,p=(a==="100%"||a==="100vw")&&(!c||c==="100%"||c==="100vw"),f=(o==="100%"||o==="100vh")&&(!u||u==="100%"||u==="100vh"),b=this._xPosition,w=this._xOffset,L=this._overlayRef.getConfig().direction==="rtl",$="",ae="",me="";p?me="flex-start":b==="center"?(me="center",L?ae=w:$=w):L?b==="left"||b==="end"?(me="flex-end",$=w):(b==="right"||b==="start")&&(me="flex-start",ae=w):b==="left"||b==="start"?(me="flex-start",$=w):(b==="right"||b==="end")&&(me="flex-end",ae=w),i.position=this._cssPosition,i.marginLeft=p?"0":$,i.marginTop=f?"0":this._topOffset,i.marginBottom=this._bottomOffset,i.marginRight=p?"0":ae,e.justifyContent=me,e.alignItems=f?"flex-start":this._alignItems}dispose(){if(this._isDisposed||!this._overlayRef)return;let i=this._overlayRef.overlayElement.style,e=this._overlayRef.hostElement,t=e.style;e.classList.remove(Qg),t.justifyContent=t.alignItems=i.marginTop=i.marginBottom=i.marginLeft=i.marginRight=i.position="",this._overlayRef=null,this._isDisposed=!0}},t_=(()=>{class n{_injector=m(re);constructor(){}global(){return Ni()}flexibleConnectedTo(e){return zr(this._injector,e)}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),Ur=new E("OVERLAY_DEFAULT_CONFIG");function si(n,i){n.get(Oe).load(e_);let e=n.get(Xc),t=n.get(X),a=n.get(xe),o=n.get(Pn),c=n.get(Qe),u=n.get(Se,null,{optional:!0})||n.get(vt).createRenderer(null,null),p=new ri(i),f=n.get(Ur,null,{optional:!0})?.usePopover??!0;p.direction=p.direction||c.value,"showPopover"in t.body?p.usePopover=i?.usePopover??f:p.usePopover=!1;let b=t.createElement("div"),w=t.createElement("div");b.id=a.getId("cdk-overlay-"),b.classList.add("cdk-overlay-pane"),w.appendChild(b),p.usePopover&&(w.setAttribute("popover","manual"),w.classList.add("cdk-overlay-popover"));let L=p.usePopover?p.positionStrategy?.getPopoverInsertionPoint?.():null;return Lu(L)?L.after(w):L?.type==="parent"?L.element.appendChild(w):e.getContainerElement().appendChild(w),new lo(new Hc(b,o,n),w,b,p,n.get(W),n.get(Zg),t,n.get(hi),n.get(Jg),i?.disableAnimations??n.get(Da,null,{optional:!0})==="NoopAnimations",n.get(bt),u)}var n_=(()=>{class n{scrollStrategies=m(Xg);_positionBuilder=m(t_);_injector=m(re);constructor(){}create(e){return si(this._injector,e)}position(){return this._positionBuilder}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),rw=[{originX:"start",originY:"bottom",overlayX:"start",overlayY:"top"},{originX:"start",originY:"top",overlayX:"start",overlayY:"bottom"},{originX:"end",originY:"top",overlayX:"end",overlayY:"bottom"},{originX:"end",originY:"bottom",overlayX:"end",overlayY:"top"}],sw=new E("cdk-connected-overlay-scroll-strategy",{providedIn:"root",factory:()=>{let n=m(re);return()=>pa(n)}}),uo=(()=>{class n{elementRef=m(B);constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdk-overlay-origin",""],["","overlay-origin",""],["","cdkOverlayOrigin",""]],exportAs:["cdkOverlayOrigin"]})}return n})(),i_=new E("cdk-connected-overlay-default-config"),Kc=(()=>{class n{_dir=m(Qe,{optional:!0});_injector=m(re);_overlayRef;_templatePortal;_backdropSubscription=Le.EMPTY;_attachSubscription=Le.EMPTY;_detachSubscription=Le.EMPTY;_positionSubscription=Le.EMPTY;_offsetX;_offsetY;_position;_scrollStrategyFactory=m(sw);_ngZone=m(W);origin;positions;positionStrategy;get offsetX(){return this._offsetX}set offsetX(e){this._offsetX=e,this._position&&this._updatePositionStrategy(this._position)}get offsetY(){return this._offsetY}set offsetY(e){this._offsetY=e,this._position&&this._updatePositionStrategy(this._position)}width;height;minWidth;minHeight;backdropClass;panelClass;viewportMargin=0;scrollStrategy;open=!1;disableClose=!1;transformOriginSelector;hasBackdrop=!1;lockPosition=!1;flexibleDimensions=!1;growAfterOpen=!1;push=!1;disposeOnNavigation=!1;usePopover;matchWidth=!1;set _config(e){typeof e!="string"&&this._assignConfig(e)}backdropClick=new z;positionChange=new z;attach=new z;detach=new z;overlayKeydown=new z;overlayOutsideClick=new z;constructor(){let e=m(He),t=m(Xe),a=m(i_,{optional:!0}),o=m(Ur,{optional:!0});this.usePopover=o?.usePopover===!1?null:"global",this._templatePortal=new Qt(e,t),this.scrollStrategy=this._scrollStrategyFactory(),a&&this._assignConfig(a)}get overlayRef(){return this._overlayRef}get dir(){return this._dir?this._dir.value:"ltr"}ngOnDestroy(){this._attachSubscription.unsubscribe(),this._detachSubscription.unsubscribe(),this._backdropSubscription.unsubscribe(),this._positionSubscription.unsubscribe(),this._overlayRef?.dispose()}ngOnChanges(e){this._position&&(this._updatePositionStrategy(this._position),this._overlayRef?.updateSize({width:this._getWidth(),minWidth:this.minWidth,height:this.height,minHeight:this.minHeight}),e.origin&&this.open&&this._position.apply()),e.open&&(this.open?this.attachOverlay():this.detachOverlay())}_createOverlay(){(!this.positions||!this.positions.length)&&(this.positions=rw);let e=this._overlayRef=si(this._injector,this._buildConfig());this._attachSubscription=e.attachments().subscribe(()=>this.attach.emit()),this._detachSubscription=e.detachments().subscribe(()=>this.detach.emit()),e.keydownEvents().subscribe(t=>{this.overlayKeydown.next(t),t.keyCode===27&&!this.disableClose&&!Ze(t)&&(t.preventDefault(),this.detachOverlay())}),this._overlayRef.outsidePointerEvents().subscribe(t=>{let a=this._getOriginElement(),o=wt(t);(!a||a!==o&&!a.contains(o))&&this.overlayOutsideClick.next(t)})}_buildConfig(){let e=this._position=this.positionStrategy||this._createPositionStrategy(),t=new ri({direction:this._dir||"ltr",positionStrategy:e,scrollStrategy:this.scrollStrategy,hasBackdrop:this.hasBackdrop,disposeOnNavigation:this.disposeOnNavigation,usePopover:!!this.usePopover});return(this.height||this.height===0)&&(t.height=this.height),(this.minWidth||this.minWidth===0)&&(t.minWidth=this.minWidth),(this.minHeight||this.minHeight===0)&&(t.minHeight=this.minHeight),this.backdropClass&&(t.backdropClass=this.backdropClass),this.panelClass&&(t.panelClass=this.panelClass),t}_updatePositionStrategy(e){let t=this.positions.map(a=>({originX:a.originX,originY:a.originY,overlayX:a.overlayX,overlayY:a.overlayY,offsetX:a.offsetX||this.offsetX,offsetY:a.offsetY||this.offsetY,panelClass:a.panelClass||void 0}));return e.setOrigin(this._getOrigin()).withPositions(t).withFlexibleDimensions(this.flexibleDimensions).withPush(this.push).withGrowAfterOpen(this.growAfterOpen).withViewportMargin(this.viewportMargin).withLockedPosition(this.lockPosition).withTransformOriginOn(this.transformOriginSelector).withPopoverLocation(this.usePopover===null?"global":this.usePopover)}_createPositionStrategy(){let e=zr(this._injector,this._getOrigin());return this._updatePositionStrategy(e),e}_getOrigin(){return this.origin instanceof uo?this.origin.elementRef:this.origin}_getOriginElement(){return this.origin instanceof uo?this.origin.elementRef.nativeElement:this.origin instanceof B?this.origin.nativeElement:typeof Element<"u"&&this.origin instanceof Element?this.origin:null}_getWidth(){return this.width?this.width:this.matchWidth?this._getOriginElement()?.getBoundingClientRect?.().width:void 0}attachOverlay(){this._overlayRef||this._createOverlay();let e=this._overlayRef;e.getConfig().hasBackdrop=this.hasBackdrop,e.updateSize({width:this._getWidth()}),e.hasAttached()||e.attach(this._templatePortal),this.hasBackdrop?this._backdropSubscription=e.backdropClick().subscribe(t=>this.backdropClick.emit(t)):this._backdropSubscription.unsubscribe(),this._positionSubscription.unsubscribe(),this.positionChange.observers.length>0&&(this._positionSubscription=this._position.positionChanges.pipe(Rm(()=>this.positionChange.observers.length>0)).subscribe(t=>{this._ngZone.run(()=>this.positionChange.emit(t)),this.positionChange.observers.length===0&&this._positionSubscription.unsubscribe()})),this.open=!0}detachOverlay(){this._overlayRef?.detach(),this._backdropSubscription.unsubscribe(),this._positionSubscription.unsubscribe(),this.open=!1}_assignConfig(e){this.origin=e.origin??this.origin,this.positions=e.positions??this.positions,this.positionStrategy=e.positionStrategy??this.positionStrategy,this.offsetX=e.offsetX??this.offsetX,this.offsetY=e.offsetY??this.offsetY,this.width=e.width??this.width,this.height=e.height??this.height,this.minWidth=e.minWidth??this.minWidth,this.minHeight=e.minHeight??this.minHeight,this.backdropClass=e.backdropClass??this.backdropClass,this.panelClass=e.panelClass??this.panelClass,this.viewportMargin=e.viewportMargin??this.viewportMargin,this.scrollStrategy=e.scrollStrategy??this.scrollStrategy,this.disableClose=e.disableClose??this.disableClose,this.transformOriginSelector=e.transformOriginSelector??this.transformOriginSelector,this.hasBackdrop=e.hasBackdrop??this.hasBackdrop,this.lockPosition=e.lockPosition??this.lockPosition,this.flexibleDimensions=e.flexibleDimensions??this.flexibleDimensions,this.growAfterOpen=e.growAfterOpen??this.growAfterOpen,this.push=e.push??this.push,this.disposeOnNavigation=e.disposeOnNavigation??this.disposeOnNavigation,this.usePopover=e.usePopover??this.usePopover,this.matchWidth=e.matchWidth??this.matchWidth}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdk-connected-overlay",""],["","connected-overlay",""],["","cdkConnectedOverlay",""]],inputs:{origin:[0,"cdkConnectedOverlayOrigin","origin"],positions:[0,"cdkConnectedOverlayPositions","positions"],positionStrategy:[0,"cdkConnectedOverlayPositionStrategy","positionStrategy"],offsetX:[0,"cdkConnectedOverlayOffsetX","offsetX"],offsetY:[0,"cdkConnectedOverlayOffsetY","offsetY"],width:[0,"cdkConnectedOverlayWidth","width"],height:[0,"cdkConnectedOverlayHeight","height"],minWidth:[0,"cdkConnectedOverlayMinWidth","minWidth"],minHeight:[0,"cdkConnectedOverlayMinHeight","minHeight"],backdropClass:[0,"cdkConnectedOverlayBackdropClass","backdropClass"],panelClass:[0,"cdkConnectedOverlayPanelClass","panelClass"],viewportMargin:[0,"cdkConnectedOverlayViewportMargin","viewportMargin"],scrollStrategy:[0,"cdkConnectedOverlayScrollStrategy","scrollStrategy"],open:[0,"cdkConnectedOverlayOpen","open"],disableClose:[0,"cdkConnectedOverlayDisableClose","disableClose"],transformOriginSelector:[0,"cdkConnectedOverlayTransformOriginOn","transformOriginSelector"],hasBackdrop:[2,"cdkConnectedOverlayHasBackdrop","hasBackdrop",R],lockPosition:[2,"cdkConnectedOverlayLockPosition","lockPosition",R],flexibleDimensions:[2,"cdkConnectedOverlayFlexibleDimensions","flexibleDimensions",R],growAfterOpen:[2,"cdkConnectedOverlayGrowAfterOpen","growAfterOpen",R],push:[2,"cdkConnectedOverlayPush","push",R],disposeOnNavigation:[2,"cdkConnectedOverlayDisposeOnNavigation","disposeOnNavigation",R],usePopover:[0,"cdkConnectedOverlayUsePopover","usePopover"],matchWidth:[2,"cdkConnectedOverlayMatchWidth","matchWidth",R],_config:[0,"cdkConnectedOverlay","_config"]},outputs:{backdropClick:"backdropClick",positionChange:"positionChange",attach:"attach",detach:"detach",overlayKeydown:"overlayKeydown",overlayOutsideClick:"overlayOutsideClick"},exportAs:["cdkConnectedOverlay"],features:[we]})}return n})(),Sn=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({providers:[n_],imports:[de,En,Br,Br]})}return n})();var Zc=(()=>{class n{_animationsDisabled=Ee();state="unchecked";disabled=!1;appearance="full";constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-pseudo-checkbox"]],hostAttrs:[1,"mat-pseudo-checkbox"],hostVars:12,hostBindings:function(t,a){t&2&&k("mat-pseudo-checkbox-indeterminate",a.state==="indeterminate")("mat-pseudo-checkbox-checked",a.state==="checked")("mat-pseudo-checkbox-disabled",a.disabled)("mat-pseudo-checkbox-minimal",a.appearance==="minimal")("mat-pseudo-checkbox-full",a.appearance==="full")("_mat-animation-noopable",a._animationsDisabled)},inputs:{state:"state",disabled:"disabled",appearance:"appearance"},decls:0,vars:0,template:function(t,a){},styles:[`.mat-pseudo-checkbox {
  border-radius: 2px;
  cursor: pointer;
  display: inline-block;
  vertical-align: middle;
  box-sizing: border-box;
  position: relative;
  flex-shrink: 0;
  transition: border-color 90ms cubic-bezier(0, 0, 0.2, 0.1), background-color 90ms cubic-bezier(0, 0, 0.2, 0.1);
}
.mat-pseudo-checkbox::after {
  position: absolute;
  opacity: 0;
  content: "";
  border-bottom: 2px solid currentColor;
  transition: opacity 90ms cubic-bezier(0, 0, 0.2, 0.1);
}
.mat-pseudo-checkbox._mat-animation-noopable {
  transition: none !important;
  animation: none !important;
}
.mat-pseudo-checkbox._mat-animation-noopable::after {
  transition: none;
}

.mat-pseudo-checkbox-disabled {
  cursor: default;
}

.mat-pseudo-checkbox-indeterminate::after {
  left: 1px;
  opacity: 1;
  border-radius: 2px;
}

.mat-pseudo-checkbox-checked::after {
  left: 1px;
  border-left: 2px solid currentColor;
  transform: rotate(-45deg);
  opacity: 1;
  box-sizing: content-box;
}

.mat-pseudo-checkbox-minimal.mat-pseudo-checkbox-checked::after, .mat-pseudo-checkbox-minimal.mat-pseudo-checkbox-indeterminate::after {
  color: var(--mat-pseudo-checkbox-minimal-selected-checkmark-color, var(--mat-sys-primary));
}
.mat-pseudo-checkbox-minimal.mat-pseudo-checkbox-checked.mat-pseudo-checkbox-disabled::after, .mat-pseudo-checkbox-minimal.mat-pseudo-checkbox-indeterminate.mat-pseudo-checkbox-disabled::after {
  color: var(--mat-pseudo-checkbox-minimal-disabled-selected-checkmark-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}

.mat-pseudo-checkbox-full {
  border-color: var(--mat-pseudo-checkbox-full-unselected-icon-color, var(--mat-sys-on-surface-variant));
  border-width: 2px;
  border-style: solid;
}
.mat-pseudo-checkbox-full.mat-pseudo-checkbox-disabled {
  border-color: var(--mat-pseudo-checkbox-full-disabled-unselected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-pseudo-checkbox-full.mat-pseudo-checkbox-checked, .mat-pseudo-checkbox-full.mat-pseudo-checkbox-indeterminate {
  background-color: var(--mat-pseudo-checkbox-full-selected-icon-color, var(--mat-sys-primary));
  border-color: transparent;
}
.mat-pseudo-checkbox-full.mat-pseudo-checkbox-checked::after, .mat-pseudo-checkbox-full.mat-pseudo-checkbox-indeterminate::after {
  color: var(--mat-pseudo-checkbox-full-selected-checkmark-color, var(--mat-sys-on-primary));
}
.mat-pseudo-checkbox-full.mat-pseudo-checkbox-checked.mat-pseudo-checkbox-disabled, .mat-pseudo-checkbox-full.mat-pseudo-checkbox-indeterminate.mat-pseudo-checkbox-disabled {
  background-color: var(--mat-pseudo-checkbox-full-disabled-selected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-pseudo-checkbox-full.mat-pseudo-checkbox-checked.mat-pseudo-checkbox-disabled::after, .mat-pseudo-checkbox-full.mat-pseudo-checkbox-indeterminate.mat-pseudo-checkbox-disabled::after {
  color: var(--mat-pseudo-checkbox-full-disabled-selected-checkmark-color, var(--mat-sys-surface));
}

.mat-pseudo-checkbox {
  width: 18px;
  height: 18px;
}

.mat-pseudo-checkbox-minimal.mat-pseudo-checkbox-checked::after {
  width: 14px;
  height: 6px;
  transform-origin: center;
  top: -4.2426406871px;
  left: 0;
  bottom: 0;
  right: 0;
  margin: auto;
}
.mat-pseudo-checkbox-minimal.mat-pseudo-checkbox-indeterminate::after {
  top: 8px;
  width: 16px;
}

.mat-pseudo-checkbox-full.mat-pseudo-checkbox-checked::after {
  width: 10px;
  height: 4px;
  transform-origin: center;
  top: -2.8284271247px;
  left: 0;
  bottom: 0;
  right: 0;
  margin: auto;
}
.mat-pseudo-checkbox-full.mat-pseudo-checkbox-indeterminate::after {
  top: 6px;
  width: 12px;
}
`],encapsulation:2,changeDetection:0})}return n})();var cw=["text"],lw=[[["mat-icon"]],"*"],dw=["mat-icon","*"];function uw(n,i){if(n&1&&H(0,"mat-pseudo-checkbox",1),n&2){let e=h();P("disabled",e.disabled)("state",e.selected?"checked":"unchecked")}}function mw(n,i){if(n&1&&H(0,"mat-pseudo-checkbox",3),n&2){let e=h();P("disabled",e.disabled)}}function pw(n,i){if(n&1&&(s(0,"span",4),l(1),r()),n&2){let e=h();d(),N("(",e.group.label,")")}}var ju=new E("MAT_OPTION_PARENT_COMPONENT"),Vu=new E("MatOptgroup");var Bu=class{source;isUserInput;constructor(i,e=!1){this.source=i,this.isUserInput=e}},Li=(()=>{class n{_element=m(B);_changeDetectorRef=m(Z);_parent=m(ju,{optional:!0});group=m(Vu,{optional:!0});_signalDisableRipple=!1;_selected=!1;_active=!1;_mostRecentViewValue="";get multiple(){return this._parent&&this._parent.multiple}get selected(){return this._selected}value;id=m(xe).getId("mat-option-");get disabled(){return this.group&&this.group.disabled||this._disabled()}set disabled(e){this._disabled.set(e)}_disabled=le(!1);get disableRipple(){return this._signalDisableRipple?this._parent.disableRipple():!!this._parent?.disableRipple}get hideSingleSelectionIndicator(){return!!(this._parent&&this._parent.hideSingleSelectionIndicator)}onSelectionChange=new z;_text;_stateChanges=new F;constructor(){let e=m(Oe);e.load(Et),e.load(wi),this._signalDisableRipple=!!this._parent&&ui(this._parent.disableRipple)}get active(){return this._active}get viewValue(){return(this._text?.nativeElement.textContent||"").trim()}select(e=!0){this._selected||(this._selected=!0,this._changeDetectorRef.markForCheck(),e&&this._emitSelectionChangeEvent())}deselect(e=!0){this._selected&&(this._selected=!1,this._changeDetectorRef.markForCheck(),e&&this._emitSelectionChangeEvent())}focus(e,t){let a=this._getHostElement();typeof a.focus=="function"&&a.focus(t)}setActiveStyles(){this._active||(this._active=!0,this._changeDetectorRef.markForCheck())}setInactiveStyles(){this._active&&(this._active=!1,this._changeDetectorRef.markForCheck())}getLabel(){return this.viewValue}_handleKeydown(e){(e.keyCode===13||e.keyCode===32)&&!Ze(e)&&(this._selectViaInteraction(),e.preventDefault())}_selectViaInteraction(){this.disabled||(this._selected=this.multiple?!this._selected:!0,this._changeDetectorRef.markForCheck(),this._emitSelectionChangeEvent(!0))}_getTabIndex(){return this.disabled?"-1":"0"}_getHostElement(){return this._element.nativeElement}ngAfterViewChecked(){if(this._selected){let e=this.viewValue;e!==this._mostRecentViewValue&&(this._mostRecentViewValue&&this._stateChanges.next(),this._mostRecentViewValue=e)}}ngOnDestroy(){this._stateChanges.complete()}_emitSelectionChangeEvent(e=!1){this.onSelectionChange.emit(new Bu(this,e))}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-option"]],viewQuery:function(t,a){if(t&1&&Ae(cw,7),t&2){let o;j(o=V())&&(a._text=o.first)}},hostAttrs:["role","option",1,"mat-mdc-option","mdc-list-item"],hostVars:11,hostBindings:function(t,a){t&1&&_("click",function(){return a._selectViaInteraction()})("keydown",function(c){return a._handleKeydown(c)}),t&2&&(jt("id",a.id),Y("aria-selected",a.selected)("aria-disabled",a.disabled.toString()),k("mdc-list-item--selected",a.selected)("mat-mdc-option-multiple",a.multiple)("mat-mdc-option-active",a.active)("mdc-list-item--disabled",a.disabled))},inputs:{value:"value",id:"id",disabled:[2,"disabled","disabled",R]},outputs:{onSelectionChange:"onSelectionChange"},exportAs:["matOption"],ngContentSelectors:dw,decls:8,vars:5,consts:[["text",""],["aria-hidden","true",1,"mat-mdc-option-pseudo-checkbox",3,"disabled","state"],[1,"mdc-list-item__primary-text"],["state","checked","aria-hidden","true","appearance","minimal",1,"mat-mdc-option-pseudo-checkbox",3,"disabled"],[1,"cdk-visually-hidden"],["aria-hidden","true","mat-ripple","",1,"mat-mdc-option-ripple","mat-focus-indicator",3,"matRippleTrigger","matRippleDisabled"]],template:function(t,a){t&1&&(ye(lw),v(0,uw,1,2,"mat-pseudo-checkbox",1),ee(1),s(2,"span",2,0),ee(4,1),r(),v(5,mw,1,1,"mat-pseudo-checkbox",3),v(6,pw,2,1,"span",4),H(7,"div",5)),t&2&&(y(a.multiple?0:-1),d(5),y(!a.multiple&&a.selected&&!a.hideSingleSelectionIndicator?5:-1),d(),y(a.group&&a.group._inert?6:-1),d(),P("matRippleTrigger",a._getHostElement())("matRippleDisabled",a.disabled||a.disableRipple))},dependencies:[Zc,xn],styles:[`.mat-mdc-option {
  -webkit-user-select: none;
  user-select: none;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  display: flex;
  position: relative;
  align-items: center;
  justify-content: flex-start;
  overflow: hidden;
  min-height: 48px;
  padding: 0 16px;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  color: var(--mat-option-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-option-label-text-font, var(--mat-sys-label-large-font));
  line-height: var(--mat-option-label-text-line-height, var(--mat-sys-label-large-line-height));
  font-size: var(--mat-option-label-text-size, var(--mat-sys-body-large-size));
  letter-spacing: var(--mat-option-label-text-tracking, var(--mat-sys-label-large-tracking));
  font-weight: var(--mat-option-label-text-weight, var(--mat-sys-body-large-weight));
}
.mat-mdc-option:hover:not(.mdc-list-item--disabled) {
  background-color: var(--mat-option-hover-state-layer-color, color-mix(in srgb, var(--mat-sys-on-surface) calc(var(--mat-sys-hover-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-option:focus.mdc-list-item, .mat-mdc-option.mat-mdc-option-active.mdc-list-item {
  background-color: var(--mat-option-focus-state-layer-color, color-mix(in srgb, var(--mat-sys-on-surface) calc(var(--mat-sys-focus-state-layer-opacity) * 100%), transparent));
  outline: 0;
}
.mat-mdc-option.mdc-list-item--selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) {
  background-color: var(--mat-option-selected-state-layer-color, var(--mat-sys-secondary-container));
}
.mat-mdc-option.mdc-list-item--selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) .mdc-list-item__primary-text {
  color: var(--mat-option-selected-state-label-text-color, var(--mat-sys-on-secondary-container));
}
.mat-mdc-option .mat-pseudo-checkbox {
  --mat-pseudo-checkbox-minimal-selected-checkmark-color: var(--mat-option-selected-state-label-text-color, var(--mat-sys-on-secondary-container));
}
.mat-mdc-option.mdc-list-item {
  align-items: center;
  background: transparent;
}
.mat-mdc-option.mdc-list-item--disabled {
  cursor: default;
  pointer-events: none;
}
.mat-mdc-option.mdc-list-item--disabled .mat-mdc-option-pseudo-checkbox, .mat-mdc-option.mdc-list-item--disabled .mdc-list-item__primary-text, .mat-mdc-option.mdc-list-item--disabled > mat-icon {
  opacity: 0.38;
}
.mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 32px;
}
[dir=rtl] .mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 16px;
  padding-right: 32px;
}
.mat-mdc-option .mat-icon,
.mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-icon,
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 0;
  margin-left: 16px;
}
.mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-left: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-right: 16px;
  margin-left: 0;
}
.mat-mdc-option .mat-mdc-option-ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}
.mat-mdc-option .mdc-list-item__primary-text {
  white-space: normal;
  font-size: inherit;
  font-weight: inherit;
  letter-spacing: inherit;
  line-height: inherit;
  font-family: inherit;
  text-decoration: inherit;
  text-transform: inherit;
  margin-right: auto;
}
[dir=rtl] .mat-mdc-option .mdc-list-item__primary-text {
  margin-right: 0;
  margin-left: auto;
}
@media (forced-colors: active) {
  .mat-mdc-option.mdc-list-item--selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    content: "";
    position: absolute;
    top: 50%;
    right: 16px;
    transform: translateY(-50%);
    width: 10px;
    height: 0;
    border-bottom: solid 10px;
    border-radius: 10px;
  }
  [dir=rtl] .mat-mdc-option.mdc-list-item--selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    right: auto;
    left: 16px;
  }
}

.mat-mdc-option-multiple {
  --mat-list-list-item-selected-container-color: var(--mat-list-list-item-container-color, transparent);
}

.mat-mdc-option-active .mat-focus-indicator::before {
  content: "";
}
`],encapsulation:2,changeDetection:0})}return n})();function a_(n,i,e){if(e.length){let t=i.toArray(),a=e.toArray(),o=0;for(let c=0;c<n+1;c++)t[c].group&&t[c].group===a[o]&&o++;return o}return 0}function o_(n,i,e,t){return n<e?n:n+i>e+t?Math.max(0,n-t+i):e}var r_=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[de]})}return n})();var zu=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[Si,r_,Li,de]})}return n})();var hw=["trigger"],fw=["panel"],gw=[[["mat-select-trigger"]],"*"],_w=["mat-select-trigger","*"];function bw(n,i){if(n&1&&(s(0,"span",4),l(1),r()),n&2){let e=h();d(),g(e.placeholder)}}function vw(n,i){n&1&&ee(0)}function yw(n,i){if(n&1&&(s(0,"span",11),l(1),r()),n&2){let e=h(2);d(),g(e.triggerValue)}}function xw(n,i){if(n&1&&(s(0,"span",5),v(1,vw,1,0)(2,yw,2,1,"span",11),r()),n&2){let e=h();d(),y(e.customTrigger?1:2)}}function Cw(n,i){if(n&1){let e=T();s(0,"div",12,1),_("keydown",function(a){x(e);let o=h();return C(o._handleKeydown(a))}),ee(2,1),r()}if(n&2){let e=h();ve(e.panelClass),k("mat-select-panel-animations-enabled",!e._animationsDisabled)("mat-primary",(e._parentFormField==null?null:e._parentFormField.color)==="primary")("mat-accent",(e._parentFormField==null?null:e._parentFormField.color)==="accent")("mat-warn",(e._parentFormField==null?null:e._parentFormField.color)==="warn")("mat-undefined",!(e._parentFormField!=null&&e._parentFormField.color)),Y("id",e.id+"-panel")("aria-multiselectable",e.multiple)("aria-label",e.ariaLabel||null)("aria-labelledby",e._getPanelAriaLabelledby())}}var ww=new E("mat-select-scroll-strategy",{providedIn:"root",factory:()=>{let n=m(re);return()=>pa(n)}}),Dw=new E("MAT_SELECT_CONFIG"),Ew=new E("MatSelectTrigger"),Uu=class{source;value;constructor(i,e){this.source=i,this.value=e}},Jc=(()=>{class n{_viewportRuler=m(un);_changeDetectorRef=m(Z);_elementRef=m(B);_dir=m(Qe,{optional:!0});_idGenerator=m(xe);_renderer=m(Se);_parentFormField=m(Tr,{optional:!0});ngControl=m(ai,{self:!0,optional:!0});_liveAnnouncer=m(_r);_defaultOptions=m(Dw,{optional:!0});_animationsDisabled=Ee();_popoverLocation;_initialized=new F;_cleanupDetach;options;optionGroups;customTrigger;_positions=[{originX:"start",originY:"bottom",overlayX:"start",overlayY:"top"},{originX:"end",originY:"bottom",overlayX:"end",overlayY:"top"},{originX:"start",originY:"top",overlayX:"start",overlayY:"bottom",panelClass:"mat-mdc-select-panel-above"},{originX:"end",originY:"top",overlayX:"end",overlayY:"bottom",panelClass:"mat-mdc-select-panel-above"}];_scrollOptionIntoView(e){let t=this.options.toArray()[e];if(t){let a=this.panel.nativeElement,o=a_(e,this.options,this.optionGroups),c=t._getHostElement();e===0&&o===1?a.scrollTop=0:a.scrollTop=o_(c.offsetTop,c.offsetHeight,a.scrollTop,a.offsetHeight)}}_positioningSettled(){this._scrollOptionIntoView(this._keyManager.activeItemIndex||0)}_getChangeEvent(e){return new Uu(this,e)}_scrollStrategyFactory=m(ww);_panelOpen=!1;_compareWith=(e,t)=>e===t;_uid=this._idGenerator.getId("mat-select-");_triggerAriaLabelledBy=null;_previousControl;_destroy=new F;_errorStateTracker;stateChanges=new F;disableAutomaticLabeling=!0;userAriaDescribedBy;_selectionModel;_keyManager;_preferredOverlayOrigin;_overlayWidth;_onChange=()=>{};_onTouched=()=>{};_valueId=this._idGenerator.getId("mat-select-value-");_scrollStrategy;_overlayPanelClass=this._defaultOptions?.overlayPanelClass||"";get focused(){return this._focused||this._panelOpen}_focused=!1;controlType="mat-select";trigger;panel;_overlayDir;panelClass;disabled=!1;get disableRipple(){return this._disableRipple()}set disableRipple(e){this._disableRipple.set(e)}_disableRipple=le(!1);tabIndex=0;get hideSingleSelectionIndicator(){return this._hideSingleSelectionIndicator}set hideSingleSelectionIndicator(e){this._hideSingleSelectionIndicator=e,this._syncParentProperties()}_hideSingleSelectionIndicator=this._defaultOptions?.hideSingleSelectionIndicator??!1;get placeholder(){return this._placeholder}set placeholder(e){this._placeholder=e,this.stateChanges.next()}_placeholder;get required(){return this._required??this.ngControl?.control?.hasValidator(no.required)??!1}set required(e){this._required=e,this.stateChanges.next()}_required;get multiple(){return this._multiple}set multiple(e){this._selectionModel,this._multiple=e}_multiple=!1;disableOptionCentering=this._defaultOptions?.disableOptionCentering??!1;get compareWith(){return this._compareWith}set compareWith(e){this._compareWith=e,this._selectionModel&&this._initializeSelection()}get value(){return this._value}set value(e){this._assignValue(e)&&this._onChange(e)}_value;ariaLabel="";ariaLabelledby;get errorStateMatcher(){return this._errorStateTracker.matcher}set errorStateMatcher(e){this._errorStateTracker.matcher=e}typeaheadDebounceInterval;sortComparator;get id(){return this._id}set id(e){this._id=e||this._uid,this.stateChanges.next()}_id;get errorState(){return this._errorStateTracker.errorState}set errorState(e){this._errorStateTracker.errorState=e}panelWidth=this._defaultOptions&&typeof this._defaultOptions.panelWidth<"u"?this._defaultOptions.panelWidth:"auto";canSelectNullableOptions=this._defaultOptions?.canSelectNullableOptions??!1;optionSelectionChanges=Tn(()=>{let e=this.options;return e?e.changes.pipe(tt(e),at(()=>ut(...e.map(t=>t.onSelectionChange)))):this._initialized.pipe(at(()=>this.optionSelectionChanges))});openedChange=new z;_openedStream=this.openedChange.pipe(Ce(e=>e),Q(()=>{}));_closedStream=this.openedChange.pipe(Ce(e=>!e),Q(()=>{}));selectionChange=new z;valueChange=new z;constructor(){let e=m(oo),t=m(ra,{optional:!0}),a=m(Ir,{optional:!0}),o=m(new xt("tabindex"),{optional:!0}),c=m(Ur,{optional:!0});this.ngControl&&(this.ngControl.valueAccessor=this),this._defaultOptions?.typeaheadDebounceInterval!=null&&(this.typeaheadDebounceInterval=this._defaultOptions.typeaheadDebounceInterval),this._errorStateTracker=new ro(e,this.ngControl,a,t,this.stateChanges),this._scrollStrategy=this._scrollStrategyFactory(),this.tabIndex=o==null?0:parseInt(o)||0,this._popoverLocation=c?.usePopover===!1?null:"inline",this.id=this.id}ngOnInit(){this._selectionModel=new ca(this.multiple),this.stateChanges.next(),this._viewportRuler.change().pipe(pe(this._destroy)).subscribe(()=>{this.panelOpen&&(this._overlayWidth=this._getOverlayWidth(this._preferredOverlayOrigin),this._changeDetectorRef.detectChanges())})}ngAfterContentInit(){this._initialized.next(),this._initialized.complete(),this._initKeyManager(),this._selectionModel.changed.pipe(pe(this._destroy)).subscribe(e=>{e.added.forEach(t=>t.select()),e.removed.forEach(t=>t.deselect())}),this.options.changes.pipe(tt(null),pe(this._destroy)).subscribe(()=>{this._resetOptions(),this._initializeSelection()})}ngDoCheck(){let e=this._getTriggerAriaLabelledby(),t=this.ngControl;if(e!==this._triggerAriaLabelledBy){let a=this._elementRef.nativeElement;this._triggerAriaLabelledBy=e,e?a.setAttribute("aria-labelledby",e):a.removeAttribute("aria-labelledby")}t&&(this._previousControl!==t.control&&(this._previousControl!==void 0&&t.disabled!==null&&t.disabled!==this.disabled&&(this.disabled=t.disabled),this._previousControl=t.control),this.updateErrorState())}ngOnChanges(e){(e.disabled||e.userAriaDescribedBy)&&this.stateChanges.next(),e.typeaheadDebounceInterval&&this._keyManager&&this._keyManager.withTypeAhead(this.typeaheadDebounceInterval),e.panelClass&&this.panelClass instanceof Set&&(this.panelClass=Array.from(this.panelClass))}ngOnDestroy(){this._cleanupDetach?.(),this._keyManager?.destroy(),this._destroy.next(),this._destroy.complete(),this.stateChanges.complete(),this._clearFromModal()}toggle(){this.panelOpen?this.close():this.open()}open(){this._canOpen()&&(this._parentFormField&&(this._preferredOverlayOrigin=this._parentFormField.getConnectedOverlayOrigin()),this._cleanupDetach?.(),this._overlayWidth=this._getOverlayWidth(this._preferredOverlayOrigin),this._applyModalPanelOwnership(),this._panelOpen=!0,this._overlayDir.positionChange.pipe(it(1)).subscribe(()=>{this._changeDetectorRef.detectChanges(),this._positioningSettled()}),this._overlayDir.attachOverlay(),this._keyManager.withHorizontalOrientation(null),this._highlightCorrectOption(),this._changeDetectorRef.markForCheck(),this.stateChanges.next(),Promise.resolve().then(()=>this.openedChange.emit(!0)))}_trackedModal=null;_applyModalPanelOwnership(){let e=this._elementRef.nativeElement.closest('body > .cdk-overlay-container [aria-modal="true"]');if(!e)return;let t=`${this.id}-panel`;this._trackedModal&&uc(this._trackedModal,"aria-owns",t),uu(e,"aria-owns",t),this._trackedModal=e}_clearFromModal(){if(!this._trackedModal)return;let e=`${this.id}-panel`;uc(this._trackedModal,"aria-owns",e),this._trackedModal=null}close(){this._panelOpen&&(this._panelOpen=!1,this._exitAndDetach(),this._keyManager.withHorizontalOrientation(this._isRtl()?"rtl":"ltr"),this._changeDetectorRef.markForCheck(),this._onTouched(),this.stateChanges.next(),Promise.resolve().then(()=>this.openedChange.emit(!1)))}_exitAndDetach(){if(this._animationsDisabled||!this.panel){this._detachOverlay();return}this._cleanupDetach?.(),this._cleanupDetach=()=>{t(),clearTimeout(a),this._cleanupDetach=void 0};let e=this.panel.nativeElement,t=this._renderer.listen(e,"animationend",o=>{o.animationName==="_mat-select-exit"&&(this._cleanupDetach?.(),this._detachOverlay())}),a=setTimeout(()=>{this._cleanupDetach?.(),this._detachOverlay()},200);e.classList.add("mat-select-panel-exit")}_detachOverlay(){this._overlayDir.detachOverlay(),this._changeDetectorRef.markForCheck()}writeValue(e){this._assignValue(e)}registerOnChange(e){this._onChange=e}registerOnTouched(e){this._onTouched=e}setDisabledState(e){this.disabled=e,this._changeDetectorRef.markForCheck(),this.stateChanges.next()}get panelOpen(){return this._panelOpen}get selected(){return this.multiple?this._selectionModel?.selected||[]:this._selectionModel?.selected[0]}get triggerValue(){if(this.empty)return"";if(this._multiple){let e=this._selectionModel.selected.map(t=>t.viewValue);return this._isRtl()&&e.reverse(),e.join(", ")}return this._selectionModel.selected[0].viewValue}updateErrorState(){this._errorStateTracker.updateErrorState()}_isRtl(){return this._dir?this._dir.value==="rtl":!1}_handleKeydown(e){this.disabled||(this.panelOpen?this._handleOpenKeydown(e):this._handleClosedKeydown(e))}_handleClosedKeydown(e){let t=e.keyCode,a=t===40||t===38||t===37||t===39,o=t===13||t===32,c=this._keyManager;if(!c.isTyping()&&o&&!Ze(e)||(this.multiple||e.altKey)&&a)e.preventDefault(),this.open();else if(!this.multiple){let u=this.selected;c.onKeydown(e);let p=this.selected;p&&u!==p&&this._liveAnnouncer.announce(p.viewValue,1e4)}}_handleOpenKeydown(e){let t=this._keyManager,a=e.keyCode,o=a===40||a===38,c=t.isTyping();if(o&&e.altKey)e.preventDefault(),this.close();else if(!c&&(a===13||a===32)&&t.activeItem&&!Ze(e))e.preventDefault(),t.activeItem._selectViaInteraction();else if(!c&&this._multiple&&a===65&&e.ctrlKey){e.preventDefault();let u=this.options.some(p=>!p.disabled&&!p.selected);this.options.forEach(p=>{p.disabled||(u?p.select():p.deselect())})}else{let u=t.activeItemIndex;t.onKeydown(e),this._multiple&&o&&e.shiftKey&&t.activeItem&&t.activeItemIndex!==u&&t.activeItem._selectViaInteraction()}}_handleOverlayKeydown(e){e.keyCode===27&&!Ze(e)&&(e.preventDefault(),this.close())}_onFocus(){this.disabled||(this._focused=!0,this.stateChanges.next())}_onBlur(){this._focused=!1,this._keyManager?.cancelTypeahead(),!this.disabled&&!this.panelOpen&&(this._onTouched(),this._changeDetectorRef.markForCheck(),this.stateChanges.next())}get empty(){return!this._selectionModel||this._selectionModel.isEmpty()}_initializeSelection(){Promise.resolve().then(()=>{this.ngControl&&(this._value=this.ngControl.value),this._setSelectionByValue(this._value),this.stateChanges.next()})}_setSelectionByValue(e){if(this.options.forEach(t=>t.setInactiveStyles()),this._selectionModel.clear(),this.multiple&&e)Array.isArray(e),e.forEach(t=>this._selectOptionByValue(t)),this._sortValues();else{let t=this._selectOptionByValue(e);t?this._keyManager.updateActiveItem(t):this.panelOpen||this._keyManager.updateActiveItem(-1)}this._changeDetectorRef.markForCheck()}_selectOptionByValue(e){let t=this.options.find(a=>{if(this._selectionModel.isSelected(a))return!1;try{return(a.value!=null||this.canSelectNullableOptions)&&this._compareWith(a.value,e)}catch(o){return!1}});return t&&this._selectionModel.select(t),t}_assignValue(e){return e!==this._value||this._multiple&&Array.isArray(e)?(this.options&&this._setSelectionByValue(e),this._value=e,!0):!1}_skipPredicate=e=>this.panelOpen?!1:e.disabled;_getOverlayWidth(e){return this.panelWidth==="auto"?(e instanceof uo?e.elementRef:e||this._elementRef).nativeElement.getBoundingClientRect().width:this.panelWidth===null?"":this.panelWidth}_syncParentProperties(){if(this.options)for(let e of this.options)e._changeDetectorRef.markForCheck()}_initKeyManager(){this._keyManager=new xr(this.options).withTypeAhead(this.typeaheadDebounceInterval).withVerticalOrientation().withHorizontalOrientation(this._isRtl()?"rtl":"ltr").withHomeAndEnd().withPageUpDown().withAllowedModifierKeys(["shiftKey"]).skipPredicate(this._skipPredicate),this._keyManager.tabOut.subscribe(()=>{this.panelOpen&&(!this.multiple&&this._keyManager.activeItem&&this._keyManager.activeItem._selectViaInteraction(),this.focus(),this.close())}),this._keyManager.change.subscribe(()=>{this._panelOpen&&this.panel?this._scrollOptionIntoView(this._keyManager.activeItemIndex||0):!this._panelOpen&&!this.multiple&&this._keyManager.activeItem&&this._keyManager.activeItem._selectViaInteraction()})}_resetOptions(){let e=ut(this.options.changes,this._destroy);this.optionSelectionChanges.pipe(pe(e)).subscribe(t=>{this._onSelect(t.source,t.isUserInput),t.isUserInput&&!this.multiple&&this._panelOpen&&(this.close(),this.focus())}),ut(...this.options.map(t=>t._stateChanges)).pipe(pe(e)).subscribe(()=>{this._changeDetectorRef.detectChanges(),this.stateChanges.next()})}_onSelect(e,t){let a=this._selectionModel.isSelected(e);!this.canSelectNullableOptions&&e.value==null&&!this._multiple?(e.deselect(),this._selectionModel.clear(),this.value!=null&&this._propagateChanges(e.value)):(a!==e.selected&&(e.selected?this._selectionModel.select(e):this._selectionModel.deselect(e)),t&&this._keyManager.setActiveItem(e),this.multiple&&(this._sortValues(),t&&this.focus())),a!==this._selectionModel.isSelected(e)&&this._propagateChanges(),this.stateChanges.next()}_sortValues(){if(this.multiple){let e=this.options.toArray();this._selectionModel.sort((t,a)=>this.sortComparator?this.sortComparator(t,a,e):e.indexOf(t)-e.indexOf(a)),this.stateChanges.next()}}_propagateChanges(e){let t;this.multiple?t=this.selected.map(a=>a.value):t=this.selected?this.selected.value:e,this._value=t,this.valueChange.emit(t),this._onChange(t),this.selectionChange.emit(this._getChangeEvent(t)),this._changeDetectorRef.markForCheck()}_highlightCorrectOption(){if(this._keyManager)if(this.empty){let e=-1;for(let t=0;t<this.options.length;t++)if(!this.options.get(t).disabled){e=t;break}this._keyManager.setActiveItem(e)}else this._keyManager.setActiveItem(this._selectionModel.selected[0])}_canOpen(){return!this._panelOpen&&!this.disabled&&this.options?.length>0&&!!this._overlayDir}focus(e){this._elementRef.nativeElement.focus(e)}_getPanelAriaLabelledby(){if(this.ariaLabel)return null;let e=this._parentFormField?.getLabelId()||null,t=e?e+" ":"";return this.ariaLabelledby?t+this.ariaLabelledby:e}_getAriaActiveDescendant(){return this.panelOpen&&this._keyManager&&this._keyManager.activeItem?this._keyManager.activeItem.id:null}_getTriggerAriaLabelledby(){if(this.ariaLabel)return null;let e=this._parentFormField?.getLabelId()||"";return this.ariaLabelledby&&(e+=" "+this.ariaLabelledby),e||(e=this._valueId),e}get describedByIds(){return this._elementRef.nativeElement.getAttribute("aria-describedby")?.split(" ")||[]}setDescribedByIds(e){let t=this._elementRef.nativeElement;e.length?t.setAttribute("aria-describedby",e.join(" ")):t.removeAttribute("aria-describedby")}onContainerClick(e){let t=wt(e);t&&(t.tagName==="MAT-OPTION"||t.classList.contains("cdk-overlay-backdrop")||t.closest(".mat-mdc-select-panel"))||(this.focus(),this.open())}get shouldLabelFloat(){return this.panelOpen||!this.empty||this.focused&&!!this.placeholder}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-select"]],contentQueries:function(t,a,o){if(t&1&&st(o,Ew,5)(o,Li,5)(o,Vu,5),t&2){let c;j(c=V())&&(a.customTrigger=c.first),j(c=V())&&(a.options=c),j(c=V())&&(a.optionGroups=c)}},viewQuery:function(t,a){if(t&1&&Ae(hw,5)(fw,5)(Kc,5),t&2){let o;j(o=V())&&(a.trigger=o.first),j(o=V())&&(a.panel=o.first),j(o=V())&&(a._overlayDir=o.first)}},hostAttrs:["role","combobox","aria-haspopup","listbox",1,"mat-mdc-select"],hostVars:21,hostBindings:function(t,a){t&1&&_("keydown",function(c){return a._handleKeydown(c)})("focus",function(){return a._onFocus()})("blur",function(){return a._onBlur()}),t&2&&(Y("id",a.id)("tabindex",a.disabled?-1:a.tabIndex)("aria-controls",a.panelOpen?a.id+"-panel":null)("aria-expanded",a.panelOpen)("aria-label",a.ariaLabel||null)("aria-required",a.required.toString())("aria-disabled",a.disabled.toString())("aria-invalid",a.errorState)("aria-activedescendant",a._getAriaActiveDescendant()),k("mat-mdc-select-disabled",a.disabled)("mat-mdc-select-invalid",a.errorState)("mat-mdc-select-required",a.required)("mat-mdc-select-empty",a.empty)("mat-mdc-select-multiple",a.multiple)("mat-select-open",a.panelOpen))},inputs:{userAriaDescribedBy:[0,"aria-describedby","userAriaDescribedBy"],panelClass:"panelClass",disabled:[2,"disabled","disabled",R],disableRipple:[2,"disableRipple","disableRipple",R],tabIndex:[2,"tabIndex","tabIndex",e=>e==null?0:lt(e)],hideSingleSelectionIndicator:[2,"hideSingleSelectionIndicator","hideSingleSelectionIndicator",R],placeholder:"placeholder",required:[2,"required","required",R],multiple:[2,"multiple","multiple",R],disableOptionCentering:[2,"disableOptionCentering","disableOptionCentering",R],compareWith:"compareWith",value:"value",ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],errorStateMatcher:"errorStateMatcher",typeaheadDebounceInterval:[2,"typeaheadDebounceInterval","typeaheadDebounceInterval",lt],sortComparator:"sortComparator",id:"id",panelWidth:"panelWidth",canSelectNullableOptions:[2,"canSelectNullableOptions","canSelectNullableOptions",R]},outputs:{openedChange:"openedChange",_openedStream:"opened",_closedStream:"closed",selectionChange:"selectionChange",valueChange:"valueChange"},exportAs:["matSelect"],features:[ce([{provide:Rr,useExisting:n},{provide:ju,useExisting:n}]),we],ngContentSelectors:_w,decls:11,vars:10,consts:[["fallbackOverlayOrigin","cdkOverlayOrigin","trigger",""],["panel",""],["cdk-overlay-origin","",1,"mat-mdc-select-trigger",3,"click"],[1,"mat-mdc-select-value"],[1,"mat-mdc-select-placeholder","mat-mdc-select-min-line"],[1,"mat-mdc-select-value-text"],[1,"mat-mdc-select-arrow-wrapper"],[1,"mat-mdc-select-arrow"],["viewBox","0 0 24 24","width","24px","height","24px","focusable","false","aria-hidden","true"],["d","M7 10l5 5 5-5z"],["cdk-connected-overlay","","cdkConnectedOverlayHasBackdrop","","cdkConnectedOverlayBackdropClass","cdk-overlay-transparent-backdrop",3,"detach","backdropClick","overlayKeydown","cdkConnectedOverlayDisableClose","cdkConnectedOverlayPanelClass","cdkConnectedOverlayScrollStrategy","cdkConnectedOverlayOrigin","cdkConnectedOverlayPositions","cdkConnectedOverlayWidth","cdkConnectedOverlayFlexibleDimensions","cdkConnectedOverlayUsePopover"],[1,"mat-mdc-select-min-line"],["role","listbox","tabindex","-1",1,"mat-mdc-select-panel","mdc-menu-surface","mdc-menu-surface--open",3,"keydown"]],template:function(t,a){if(t&1&&(ye(gw),s(0,"div",2,0),_("click",function(){return a.open()}),s(3,"div",3),v(4,bw,2,1,"span",4)(5,xw,3,1,"span",5),r(),s(6,"div",6)(7,"div",7),Zn(),s(8,"svg",8),H(9,"path",9),r()()()(),_e(10,Cw,3,16,"ng-template",10),_("detach",function(){return a.close()})("backdropClick",function(){return a.close()})("overlayKeydown",function(c){return a._handleOverlayKeydown(c)})),t&2){let o=ct(1);d(3),Y("id",a._valueId),d(),y(a.empty?4:5),d(6),P("cdkConnectedOverlayDisableClose",!0)("cdkConnectedOverlayPanelClass",a._overlayPanelClass)("cdkConnectedOverlayScrollStrategy",a._scrollStrategy)("cdkConnectedOverlayOrigin",a._preferredOverlayOrigin||o)("cdkConnectedOverlayPositions",a._positions)("cdkConnectedOverlayWidth",a._overlayWidth)("cdkConnectedOverlayFlexibleDimensions",!0)("cdkConnectedOverlayUsePopover",a._popoverLocation)}},dependencies:[uo,Kc],styles:[`@keyframes _mat-select-enter {
  from {
    opacity: 0;
    transform: scaleY(0.8);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes _mat-select-exit {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
.mat-mdc-select {
  display: inline-block;
  width: 100%;
  outline: none;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  color: var(--mat-select-enabled-trigger-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-select-trigger-text-font, var(--mat-sys-body-large-font));
  line-height: var(--mat-select-trigger-text-line-height, var(--mat-sys-body-large-line-height));
  font-size: var(--mat-select-trigger-text-size, var(--mat-sys-body-large-size));
  font-weight: var(--mat-select-trigger-text-weight, var(--mat-sys-body-large-weight));
  letter-spacing: var(--mat-select-trigger-text-tracking, var(--mat-sys-body-large-tracking));
}

div.mat-mdc-select-panel {
  box-shadow: var(--mat-select-container-elevation-shadow, 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12));
}

.mat-mdc-select-disabled {
  color: var(--mat-select-disabled-trigger-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-mdc-select-disabled .mat-mdc-select-placeholder {
  color: var(--mat-select-disabled-trigger-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}

.mat-mdc-select-trigger {
  display: inline-flex;
  align-items: center;
  cursor: pointer;
  position: relative;
  box-sizing: border-box;
  width: 100%;
}
.mat-mdc-select-disabled .mat-mdc-select-trigger {
  -webkit-user-select: none;
  user-select: none;
  cursor: default;
}

.mat-mdc-select-value {
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.mat-mdc-select-value-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.mat-mdc-select-arrow-wrapper {
  height: 24px;
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
}
.mat-form-field-appearance-fill .mdc-text-field--no-label .mat-mdc-select-arrow-wrapper {
  transform: none;
}

.mat-mdc-form-field .mat-mdc-select.mat-mdc-select-invalid .mat-mdc-select-arrow,
.mat-form-field-invalid:not(.mat-form-field-disabled) .mat-mdc-form-field-infix::after {
  color: var(--mat-select-invalid-arrow-color, var(--mat-sys-error));
}

.mat-mdc-select-arrow {
  width: 10px;
  height: 5px;
  position: relative;
  color: var(--mat-select-enabled-arrow-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-form-field.mat-focused .mat-mdc-select-arrow {
  color: var(--mat-select-focused-arrow-color, var(--mat-sys-primary));
}
.mat-mdc-form-field .mat-mdc-select.mat-mdc-select-disabled .mat-mdc-select-arrow {
  color: var(--mat-select-disabled-arrow-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-select-open .mat-mdc-select-arrow {
  transform: rotate(180deg);
}
.mat-form-field-animations-enabled .mat-mdc-select-arrow {
  transition: transform 80ms linear;
}
.mat-mdc-select-arrow svg {
  fill: currentColor;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
@media (forced-colors: active) {
  .mat-mdc-select-arrow svg {
    fill: CanvasText;
  }
  .mat-mdc-select-disabled .mat-mdc-select-arrow svg {
    fill: GrayText;
  }
}

div.mat-mdc-select-panel {
  width: 100%;
  max-height: 275px;
  outline: 0;
  overflow: auto;
  padding: 8px 0;
  box-sizing: border-box;
  transform-origin: top center;
  border-radius: 0 0 4px 4px;
  position: relative;
  background-color: var(--mat-select-panel-background-color, var(--mat-sys-surface-container));
}
.mat-mdc-select-panel-above div.mat-mdc-select-panel {
  border-radius: 4px 4px 0 0;
  transform-origin: bottom center;
}
@media (forced-colors: active) {
  div.mat-mdc-select-panel {
    outline: solid 1px;
  }
}

.mat-select-panel-animations-enabled {
  animation: _mat-select-enter 120ms cubic-bezier(0, 0, 0.2, 1);
}
.mat-select-panel-animations-enabled.mat-select-panel-exit {
  animation: _mat-select-exit 100ms linear;
}

.mat-mdc-select-placeholder {
  transition: color 400ms 133.3333333333ms cubic-bezier(0.25, 0.8, 0.25, 1);
  color: var(--mat-select-placeholder-text-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-form-field:not(.mat-form-field-animations-enabled) .mat-mdc-select-placeholder, ._mat-animation-noopable .mat-mdc-select-placeholder {
  transition: none;
}
.mat-form-field-hide-placeholder .mat-mdc-select-placeholder {
  color: transparent;
  -webkit-text-fill-color: transparent;
  transition: none;
  display: block;
}

.mat-mdc-form-field-type-mat-select:not(.mat-form-field-disabled) .mat-mdc-text-field-wrapper {
  cursor: pointer;
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-fill .mat-mdc-floating-label {
  max-width: calc(100% - 18px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-fill .mdc-floating-label--float-above {
  max-width: calc(100% / 0.75 - 24px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-outline .mdc-notched-outline__notch {
  max-width: calc(100% - 60px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-outline .mdc-text-field--label-floating .mdc-notched-outline__notch {
  max-width: calc(100% - 24px);
}

.mat-mdc-select-min-line:empty::before {
  content: " ";
  white-space: pre;
  width: 1px;
  display: inline-block;
  visibility: hidden;
}

.mat-form-field-appearance-fill .mat-mdc-select-arrow-wrapper {
  transform: var(--mat-select-arrow-transform, translateY(-8px));
}
`],encapsulation:2,changeDetection:0})}return n})();var el=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[Sn,zu,de,la,kt,zu]})}return n})();var Sw=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["ng-component"]],hostAttrs:["cdk-text-field-style-loader",""],decls:0,vars:0,template:function(t,a){},styles:[`textarea.cdk-textarea-autosize {
  resize: none;
}

textarea.cdk-textarea-autosize-measuring {
  padding: 2px 0 !important;
  box-sizing: content-box !important;
  height: auto !important;
  overflow: hidden !important;
}

textarea.cdk-textarea-autosize-measuring-firefox {
  padding: 2px 0 !important;
  box-sizing: content-box !important;
  height: 0 !important;
}

@keyframes cdk-text-field-autofill-start { /*!*/ }
@keyframes cdk-text-field-autofill-end { /*!*/ }
.cdk-text-field-autofill-monitored:-webkit-autofill {
  animation: cdk-text-field-autofill-start 0s 1ms;
}

.cdk-text-field-autofill-monitored:not(:-webkit-autofill) {
  animation: cdk-text-field-autofill-end 0s 1ms;
}
`],encapsulation:2,changeDetection:0})}return n})(),kw={passive:!0},c_=(()=>{class n{_platform=m(be);_ngZone=m(W);_renderer=m(vt).createRenderer(null,null);_styleLoader=m(Oe);_monitoredElements=new Map;constructor(){}monitor(e){if(!this._platform.isBrowser)return mt;this._styleLoader.load(Sw);let t=Ut(e),a=this._monitoredElements.get(t);if(a)return a.subject;let o=new F,c="cdk-text-field-autofilled",u=f=>{f.animationName==="cdk-text-field-autofill-start"&&!t.classList.contains(c)?(t.classList.add(c),this._ngZone.run(()=>o.next({target:f.target,isAutofilled:!0}))):f.animationName==="cdk-text-field-autofill-end"&&t.classList.contains(c)&&(t.classList.remove(c),this._ngZone.run(()=>o.next({target:f.target,isAutofilled:!1})))},p=this._ngZone.runOutsideAngular(()=>(t.classList.add("cdk-text-field-autofill-monitored"),this._renderer.listen(t,"animationstart",u,kw)));return this._monitoredElements.set(t,{subject:o,unlisten:p}),o}stopMonitoring(e){let t=Ut(e),a=this._monitoredElements.get(t);a&&(a.unlisten(),a.subject.complete(),t.classList.remove("cdk-text-field-autofill-monitored"),t.classList.remove("cdk-text-field-autofilled"),this._monitoredElements.delete(t))}ngOnDestroy(){this._monitoredElements.forEach((e,t)=>this.stopMonitoring(t))}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var l_=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({})}return n})();var d_=new E("MAT_INPUT_VALUE_ACCESSOR");var Mw=["button","checkbox","file","hidden","image","radio","range","reset","submit"],Iw=new E("MAT_INPUT_CONFIG"),Gn=(()=>{class n{_elementRef=m(B);_platform=m(be);ngControl=m(ai,{optional:!0,self:!0});_autofillMonitor=m(c_);_ngZone=m(W);_formField=m(Tr,{optional:!0});_renderer=m(Se);_uid=m(xe).getId("mat-input-");_previousNativeValue;_inputValueAccessor;_signalBasedValueAccessor;_previousPlaceholder=null;_errorStateTracker;_config=m(Iw,{optional:!0});_cleanupIosKeyup;_cleanupWebkitWheel;_isServer=!1;_isNativeSelect=!1;_isTextarea=!1;_isInFormField=!1;focused=!1;stateChanges=new F;controlType="mat-input";autofilled=!1;get disabled(){return this._disabled}set disabled(e){this._disabled=ni(e),this.focused&&(this.focused=!1,this.stateChanges.next())}_disabled=!1;get id(){return this._id}set id(e){this._id=e||this._uid}_id;placeholder;name;get required(){return this._required??this.ngControl?.control?.hasValidator(no.required)??!1}set required(e){this._required=ni(e)}_required;get type(){return this._type}set type(e){this._type=e||"text",this._validateType(),!this._isTextarea&&pu().has(this._type)&&(this._elementRef.nativeElement.type=this._type)}_type="text";get errorStateMatcher(){return this._errorStateTracker.matcher}set errorStateMatcher(e){this._errorStateTracker.matcher=e}userAriaDescribedBy;get value(){return this._signalBasedValueAccessor?this._signalBasedValueAccessor.value():this._inputValueAccessor.value}set value(e){e!==this.value&&(this._signalBasedValueAccessor?this._signalBasedValueAccessor.value.set(e):this._inputValueAccessor.value=e,this.stateChanges.next())}get readonly(){return this._readonly}set readonly(e){this._readonly=ni(e)}_readonly=!1;disabledInteractive;get errorState(){return this._errorStateTracker.errorState}set errorState(e){this._errorStateTracker.errorState=e}_neverEmptyInputTypes=["date","datetime","datetime-local","month","time","week"].filter(e=>pu().has(e));constructor(){let e=m(ra,{optional:!0}),t=m(Ir,{optional:!0}),a=m(oo),o=m(d_,{optional:!0,self:!0}),c=this._elementRef.nativeElement,u=c.nodeName.toLowerCase();o?ui(o.value)?this._signalBasedValueAccessor=o:this._inputValueAccessor=o:this._inputValueAccessor=c,this._previousNativeValue=this.value,this.id=this.id,this._platform.IOS&&this._ngZone.runOutsideAngular(()=>{this._cleanupIosKeyup=this._renderer.listen(c,"keyup",this._iOSKeyupListener)}),this._errorStateTracker=new ro(a,this.ngControl,t,e,this.stateChanges),this._isServer=!this._platform.isBrowser,this._isNativeSelect=u==="select",this._isTextarea=u==="textarea",this._isInFormField=!!this._formField,this.disabledInteractive=this._config?.disabledInteractive||!1,this._isNativeSelect&&(this.controlType=c.multiple?"mat-native-select-multiple":"mat-native-select"),this._signalBasedValueAccessor&&qi(()=>{this._signalBasedValueAccessor.value(),this.stateChanges.next()})}ngAfterViewInit(){this._platform.isBrowser&&this._autofillMonitor.monitor(this._elementRef.nativeElement).subscribe(e=>{this.autofilled=e.isAutofilled,this.stateChanges.next()})}ngOnChanges(){this.stateChanges.next()}ngOnDestroy(){this.stateChanges.complete(),this._platform.isBrowser&&this._autofillMonitor.stopMonitoring(this._elementRef.nativeElement),this._cleanupIosKeyup?.(),this._cleanupWebkitWheel?.()}ngDoCheck(){this.ngControl&&(this.updateErrorState(),this.ngControl.disabled!==null&&this.ngControl.disabled!==this.disabled&&(this.disabled=this.ngControl.disabled,this.stateChanges.next())),this._dirtyCheckNativeValue(),this._dirtyCheckPlaceholder()}focus(e){this._elementRef.nativeElement.focus(e)}updateErrorState(){this._errorStateTracker.updateErrorState()}_focusChanged(e){if(e!==this.focused){if(!this._isNativeSelect&&e&&this.disabled&&this.disabledInteractive){let t=this._elementRef.nativeElement;t.type==="number"?(t.type="text",t.setSelectionRange(0,0),t.type="number"):t.setSelectionRange(0,0)}this.focused=e,this.stateChanges.next()}}_onInput(){}_dirtyCheckNativeValue(){let e=this._elementRef.nativeElement.value;this._previousNativeValue!==e&&(this._previousNativeValue=e,this.stateChanges.next())}_dirtyCheckPlaceholder(){let e=this._getPlaceholder();if(e!==this._previousPlaceholder){let t=this._elementRef.nativeElement;this._previousPlaceholder=e,e?t.setAttribute("placeholder",e):t.removeAttribute("placeholder")}}_getPlaceholder(){return this.placeholder||null}_validateType(){Mw.indexOf(this._type)>-1}_isNeverEmpty(){return this._neverEmptyInputTypes.indexOf(this._type)>-1}_isBadInput(){let e=this._elementRef.nativeElement.validity;return e&&e.badInput}get empty(){return!this._isNeverEmpty()&&!this._elementRef.nativeElement.value&&!this._isBadInput()&&!this.autofilled}get shouldLabelFloat(){if(this._isNativeSelect){let e=this._elementRef.nativeElement,t=e.options[0];return this.focused||e.multiple||!this.empty||!!(e.selectedIndex>-1&&t&&t.label)}else return this.focused&&!this.disabled||!this.empty}get describedByIds(){return this._elementRef.nativeElement.getAttribute("aria-describedby")?.split(" ")||[]}setDescribedByIds(e){let t=this._elementRef.nativeElement;e.length?t.setAttribute("aria-describedby",e.join(" ")):t.removeAttribute("aria-describedby")}onContainerClick(){this.focused||this.focus()}_isInlineSelect(){let e=this._elementRef.nativeElement;return this._isNativeSelect&&(e.multiple||e.size>1)}_iOSKeyupListener=e=>{let t=e.target;!t.value&&t.selectionStart===0&&t.selectionEnd===0&&(t.setSelectionRange(1,1),t.setSelectionRange(0,0))};_getReadonlyAttribute(){return this._isNativeSelect?null:this.readonly||this.disabled&&this.disabledInteractive?"true":null}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["input","matInput",""],["textarea","matInput",""],["select","matNativeControl",""],["input","matNativeControl",""],["textarea","matNativeControl",""]],hostAttrs:[1,"mat-mdc-input-element"],hostVars:21,hostBindings:function(t,a){t&1&&_("focus",function(){return a._focusChanged(!0)})("blur",function(){return a._focusChanged(!1)})("input",function(){return a._onInput()}),t&2&&(jt("id",a.id)("disabled",a.disabled&&!a.disabledInteractive)("required",a.required),Y("name",a.name||null)("readonly",a._getReadonlyAttribute())("aria-disabled",a.disabled&&a.disabledInteractive?"true":null)("aria-invalid",a.empty&&a.required?null:a.errorState)("aria-required",a.required)("id",a.id),k("mat-input-server",a._isServer)("mat-mdc-form-field-textarea-control",a._isInFormField&&a._isTextarea)("mat-mdc-form-field-input-control",a._isInFormField)("mat-mdc-input-disabled-interactive",a.disabledInteractive)("mdc-text-field__input",a._isInFormField)("mat-mdc-native-select-inline",a._isInlineSelect()))},inputs:{disabled:"disabled",id:"id",placeholder:"placeholder",name:"name",required:"required",type:"type",errorStateMatcher:"errorStateMatcher",userAriaDescribedBy:[0,"aria-describedby","userAriaDescribedBy"],value:"value",readonly:"readonly",disabledInteractive:[2,"disabledInteractive","disabledInteractive",R]},exportAs:["matInput"],features:[ce([{provide:Rr,useExisting:n}]),we]})}return n})(),mn=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[kt,kt,l_,de]})}return n})();var Aw=["mat-internal-form-field",""],Rw=["*"],tl=(()=>{class n{labelPosition="after";static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["div","mat-internal-form-field",""]],hostAttrs:[1,"mdc-form-field","mat-internal-form-field"],hostVars:2,hostBindings:function(t,a){t&2&&k("mdc-form-field--align-end",a.labelPosition==="before")},inputs:{labelPosition:"labelPosition"},attrs:Aw,ngContentSelectors:Rw,decls:1,vars:0,template:function(t,a){t&1&&(ye(),ee(0))},styles:[`.mat-internal-form-field {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  display: inline-flex;
  align-items: center;
  vertical-align: middle;
}
.mat-internal-form-field > label {
  margin-left: 0;
  margin-right: auto;
  padding-left: 4px;
  padding-right: 0;
  order: 0;
}
[dir=rtl] .mat-internal-form-field > label {
  margin-left: auto;
  margin-right: 0;
  padding-left: 0;
  padding-right: 4px;
}

.mdc-form-field--align-end > label {
  margin-left: auto;
  margin-right: 0;
  padding-left: 0;
  padding-right: 4px;
  order: -1;
}
[dir=rtl] .mdc-form-field--align-end .mdc-form-field--align-end label {
  margin-left: 0;
  margin-right: auto;
  padding-left: 4px;
  padding-right: 0;
}
`],encapsulation:2,changeDetection:0})}return n})();var Tw=["input"],Ow=["label"],Pw=["*"],Hu={color:"accent",clickAction:"check-indeterminate",disabledInteractive:!1},Fw=new E("mat-checkbox-default-options",{providedIn:"root",factory:()=>Hu}),Pt=(function(n){return n[n.Init=0]="Init",n[n.Checked=1]="Checked",n[n.Unchecked=2]="Unchecked",n[n.Indeterminate=3]="Indeterminate",n})(Pt||{}),$u=class{source;checked},ha=(()=>{class n{_elementRef=m(B);_changeDetectorRef=m(Z);_ngZone=m(W);_animationsDisabled=Ee();_options=m(Fw,{optional:!0});focus(){this._inputElement.nativeElement.focus()}_createChangeEvent(e){let t=new $u;return t.source=this,t.checked=e,t}_getAnimationTargetElement(){return this._inputElement?.nativeElement}_animationClasses={uncheckedToChecked:"mdc-checkbox--anim-unchecked-checked",uncheckedToIndeterminate:"mdc-checkbox--anim-unchecked-indeterminate",checkedToUnchecked:"mdc-checkbox--anim-checked-unchecked",checkedToIndeterminate:"mdc-checkbox--anim-checked-indeterminate",indeterminateToChecked:"mdc-checkbox--anim-indeterminate-checked",indeterminateToUnchecked:"mdc-checkbox--anim-indeterminate-unchecked"};ariaLabel="";ariaLabelledby=null;ariaDescribedby;ariaExpanded;ariaControls;ariaOwns;_uniqueId;id;get inputId(){return`${this.id||this._uniqueId}-input`}required=!1;labelPosition="after";name=null;change=new z;indeterminateChange=new z;value;disableRipple=!1;_inputElement;_labelElement;tabIndex;color;disabledInteractive;_onTouched=()=>{};_currentAnimationClass="";_currentCheckState=Pt.Init;_controlValueAccessorChangeFn=()=>{};_validatorChangeFn=()=>{};constructor(){m(Oe).load(Et);let e=m(new xt("tabindex"),{optional:!0});this._options=this._options||Hu,this.color=this._options.color||Hu.color,this.tabIndex=e==null?0:parseInt(e)||0,this.id=this._uniqueId=m(xe).getId("mat-mdc-checkbox-"),this.disabledInteractive=this._options?.disabledInteractive??!1}ngOnChanges(e){e.required&&this._validatorChangeFn()}ngAfterViewInit(){this._syncIndeterminate(this.indeterminate)}get checked(){return this._checked}set checked(e){e!=this.checked&&(this._checked=e,this._changeDetectorRef.markForCheck())}_checked=!1;get disabled(){return this._disabled}set disabled(e){e!==this.disabled&&(this._disabled=e,this._changeDetectorRef.markForCheck())}_disabled=!1;get indeterminate(){return this._indeterminate()}set indeterminate(e){let t=e!=this._indeterminate();this._indeterminate.set(e),t&&(e?this._transitionCheckState(Pt.Indeterminate):this._transitionCheckState(this.checked?Pt.Checked:Pt.Unchecked),this.indeterminateChange.emit(e)),this._syncIndeterminate(e)}_indeterminate=le(!1);_isRippleDisabled(){return this.disableRipple||this.disabled}_onLabelTextChange(){this._changeDetectorRef.detectChanges()}writeValue(e){this.checked=!!e}registerOnChange(e){this._controlValueAccessorChangeFn=e}registerOnTouched(e){this._onTouched=e}setDisabledState(e){this.disabled=e}validate(e){return this.required&&e.value!==!0?{required:!0}:null}registerOnValidatorChange(e){this._validatorChangeFn=e}_transitionCheckState(e){let t=this._currentCheckState,a=this._getAnimationTargetElement();if(!(t===e||!a)&&(this._currentAnimationClass&&a.classList.remove(this._currentAnimationClass),this._currentAnimationClass=this._getAnimationClassForCheckStateTransition(t,e),this._currentCheckState=e,this._currentAnimationClass.length>0)){a.classList.add(this._currentAnimationClass);let o=this._currentAnimationClass;this._ngZone.runOutsideAngular(()=>{setTimeout(()=>{a.classList.remove(o)},1e3)})}}_emitChangeEvent(){this._controlValueAccessorChangeFn(this.checked),this.change.emit(this._createChangeEvent(this.checked)),this._inputElement&&(this._inputElement.nativeElement.checked=this.checked)}toggle(){this.checked=!this.checked,this._controlValueAccessorChangeFn(this.checked)}_handleInputClick(){let e=this._options?.clickAction;!this.disabled&&e!=="noop"?(this.indeterminate&&e!=="check"&&Promise.resolve().then(()=>{this._indeterminate.set(!1),this.indeterminateChange.emit(!1)}),this._checked=!this._checked,this._transitionCheckState(this._checked?Pt.Checked:Pt.Unchecked),this._emitChangeEvent()):(this.disabled&&this.disabledInteractive||!this.disabled&&e==="noop")&&(this._inputElement.nativeElement.checked=this.checked,this._inputElement.nativeElement.indeterminate=this.indeterminate)}_onInteractionEvent(e){e.stopPropagation()}_onBlur(){Promise.resolve().then(()=>{this._onTouched(),this._changeDetectorRef.markForCheck()})}_getAnimationClassForCheckStateTransition(e,t){if(this._animationsDisabled)return"";switch(e){case Pt.Init:if(t===Pt.Checked)return this._animationClasses.uncheckedToChecked;if(t==Pt.Indeterminate)return this._checked?this._animationClasses.checkedToIndeterminate:this._animationClasses.uncheckedToIndeterminate;break;case Pt.Unchecked:return t===Pt.Checked?this._animationClasses.uncheckedToChecked:this._animationClasses.uncheckedToIndeterminate;case Pt.Checked:return t===Pt.Unchecked?this._animationClasses.checkedToUnchecked:this._animationClasses.checkedToIndeterminate;case Pt.Indeterminate:return t===Pt.Checked?this._animationClasses.indeterminateToChecked:this._animationClasses.indeterminateToUnchecked}return""}_syncIndeterminate(e){let t=this._inputElement;t&&(t.nativeElement.indeterminate=e)}_onInputClick(){this._handleInputClick()}_onTouchTargetClick(){this._handleInputClick(),this.disabled||this._inputElement.nativeElement.focus()}_preventBubblingFromLabel(e){e.target&&this._labelElement.nativeElement.contains(e.target)&&e.stopPropagation()}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-checkbox"]],viewQuery:function(t,a){if(t&1&&Ae(Tw,5)(Ow,5),t&2){let o;j(o=V())&&(a._inputElement=o.first),j(o=V())&&(a._labelElement=o.first)}},hostAttrs:[1,"mat-mdc-checkbox"],hostVars:16,hostBindings:function(t,a){t&2&&(jt("id",a.id),Y("tabindex",null)("aria-label",null)("aria-labelledby",null),ve(a.color?"mat-"+a.color:"mat-accent"),k("_mat-animation-noopable",a._animationsDisabled)("mdc-checkbox--disabled",a.disabled)("mat-mdc-checkbox-disabled",a.disabled)("mat-mdc-checkbox-checked",a.checked)("mat-mdc-checkbox-disabled-interactive",a.disabledInteractive))},inputs:{ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],ariaDescribedby:[0,"aria-describedby","ariaDescribedby"],ariaExpanded:[2,"aria-expanded","ariaExpanded",R],ariaControls:[0,"aria-controls","ariaControls"],ariaOwns:[0,"aria-owns","ariaOwns"],id:"id",required:[2,"required","required",R],labelPosition:"labelPosition",name:"name",value:"value",disableRipple:[2,"disableRipple","disableRipple",R],tabIndex:[2,"tabIndex","tabIndex",e=>e==null?void 0:lt(e)],color:"color",disabledInteractive:[2,"disabledInteractive","disabledInteractive",R],checked:[2,"checked","checked",R],disabled:[2,"disabled","disabled",R],indeterminate:[2,"indeterminate","indeterminate",R]},outputs:{change:"change",indeterminateChange:"indeterminateChange"},exportAs:["matCheckbox"],features:[ce([{provide:zn,useExisting:It(()=>n),multi:!0},{provide:Ii,useExisting:n,multi:!0}]),we],ngContentSelectors:Pw,decls:15,vars:23,consts:[["checkbox",""],["input",""],["label",""],["mat-internal-form-field","",3,"click","labelPosition"],[1,"mdc-checkbox"],["aria-hidden","true",1,"mat-mdc-checkbox-touch-target",3,"click"],["type","checkbox",1,"mdc-checkbox__native-control",3,"blur","click","change","checked","indeterminate","disabled","id","required","tabIndex"],["aria-hidden","true",1,"mdc-checkbox__ripple"],["aria-hidden","true",1,"mdc-checkbox__background"],["focusable","false","viewBox","0 0 24 24",1,"mdc-checkbox__checkmark"],["fill","none","d","M1.73,12.91 8.1,19.28 22.79,4.59",1,"mdc-checkbox__checkmark-path"],[1,"mdc-checkbox__mixedmark"],["mat-ripple","","aria-hidden","true",1,"mat-mdc-checkbox-ripple","mat-focus-indicator",3,"matRippleTrigger","matRippleDisabled","matRippleCentered"],[1,"mdc-label",3,"for"]],template:function(t,a){if(t&1&&(ye(),s(0,"div",3),_("click",function(c){return a._preventBubblingFromLabel(c)}),s(1,"div",4,0)(3,"div",5),_("click",function(){return a._onTouchTargetClick()}),r(),s(4,"input",6,1),_("blur",function(){return a._onBlur()})("click",function(){return a._onInputClick()})("change",function(c){return a._onInteractionEvent(c)}),r(),H(6,"div",7),s(7,"div",8),Zn(),s(8,"svg",9),H(9,"path",10),r(),Pm(),H(10,"div",11),r(),H(11,"div",12),r(),s(12,"label",13,2),ee(14),r()()),t&2){let o=ct(2);P("labelPosition",a.labelPosition),d(4),k("mdc-checkbox--selected",a.checked),P("checked",a.checked)("indeterminate",a.indeterminate)("disabled",a.disabled&&!a.disabledInteractive)("id",a.inputId)("required",a.required)("tabIndex",a.disabled&&!a.disabledInteractive?-1:a.tabIndex),Y("aria-label",a.ariaLabel||null)("aria-labelledby",a.ariaLabelledby)("aria-describedby",a.ariaDescribedby)("aria-checked",a.indeterminate?"mixed":null)("aria-controls",a.ariaControls)("aria-disabled",a.disabled&&a.disabledInteractive?!0:null)("aria-expanded",a.ariaExpanded)("aria-owns",a.ariaOwns)("name",a.name)("value",a.value),d(7),P("matRippleTrigger",o)("matRippleDisabled",a.disableRipple||a.disabled)("matRippleCentered",!0),d(),P("for",a.inputId)}},dependencies:[xn,tl],styles:[`.mdc-checkbox {
  display: inline-block;
  position: relative;
  flex: 0 0 18px;
  box-sizing: content-box;
  width: 18px;
  height: 18px;
  line-height: 0;
  white-space: nowrap;
  cursor: pointer;
  vertical-align: bottom;
  padding: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
  margin: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
}
.mdc-checkbox:hover > .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:hover > .mat-mdc-checkbox-ripple > .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control:focus + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control:focus ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:active > .mdc-checkbox__native-control + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-pressed-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:active > .mdc-checkbox__native-control ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-pressed-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:hover > .mdc-checkbox__native-control:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-hover-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:hover > .mdc-checkbox__native-control:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-hover-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox .mdc-checkbox__native-control:focus:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-focus-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox .mdc-checkbox__native-control:focus:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-focus-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:active > .mdc-checkbox__native-control:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-pressed-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:active > .mdc-checkbox__native-control:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-pressed-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control ~ .mat-mdc-checkbox-ripple .mat-ripple-element,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control + .mdc-checkbox__ripple {
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control {
  position: absolute;
  margin: 0;
  padding: 0;
  opacity: 0;
  cursor: inherit;
  z-index: 1;
  width: var(--mat-checkbox-state-layer-size, 40px);
  height: var(--mat-checkbox-state-layer-size, 40px);
  top: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
  right: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
  left: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
}

.mdc-checkbox--disabled {
  cursor: default;
  pointer-events: none;
}

.mdc-checkbox__background {
  display: inline-flex;
  position: absolute;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  width: 18px;
  height: 18px;
  border: 2px solid currentColor;
  border-radius: 2px;
  background-color: transparent;
  pointer-events: none;
  will-change: background-color, border-color;
  transition: background-color 90ms cubic-bezier(0.4, 0, 0.6, 1), border-color 90ms cubic-bezier(0.4, 0, 0.6, 1);
  -webkit-print-color-adjust: exact;
  color-adjust: exact;
  border-color: var(--mat-checkbox-unselected-icon-color, var(--mat-sys-on-surface-variant));
  top: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
  left: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
}

.mdc-checkbox__native-control:enabled:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:enabled:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox--disabled .mdc-checkbox__background {
  border-color: var(--mat-checkbox-disabled-unselected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__background {
    border-color: GrayText;
  }
}

.mdc-checkbox__native-control:disabled:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:disabled:indeterminate ~ .mdc-checkbox__background {
  background-color: var(--mat-checkbox-disabled-selected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  border-color: transparent;
}
@media (forced-colors: active) {
  .mdc-checkbox__native-control:disabled:checked ~ .mdc-checkbox__background,
  .mdc-checkbox__native-control:disabled:indeterminate ~ .mdc-checkbox__background {
    border-color: GrayText;
  }
}

.mdc-checkbox:hover > .mdc-checkbox__native-control:not(:checked) ~ .mdc-checkbox__background,
.mdc-checkbox:hover > .mdc-checkbox__native-control:not(:indeterminate) ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-unselected-hover-icon-color, var(--mat-sys-on-surface));
  background-color: transparent;
}

.mdc-checkbox:hover > .mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox:hover > .mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-hover-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-hover-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox__native-control:focus:focus:not(:checked) ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:focus:focus:not(:indeterminate) ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-unselected-focus-icon-color, var(--mat-sys-on-surface));
}

.mdc-checkbox__native-control:focus:focus:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:focus:focus:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-focus-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-focus-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox:hover > .mdc-checkbox__native-control ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control:focus ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__background {
  border-color: var(--mat-checkbox-disabled-unselected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox:hover > .mdc-checkbox__native-control ~ .mdc-checkbox__background,
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control:focus ~ .mdc-checkbox__background,
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__background {
    border-color: GrayText;
  }
}
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  background-color: var(--mat-checkbox-disabled-selected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  border-color: transparent;
}

.mdc-checkbox__checkmark {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  opacity: 0;
  transition: opacity 180ms cubic-bezier(0.4, 0, 0.6, 1);
  color: var(--mat-checkbox-selected-checkmark-color, var(--mat-sys-on-primary));
}
@media (forced-colors: active) {
  .mdc-checkbox__checkmark {
    color: CanvasText;
  }
}

.mdc-checkbox--disabled .mdc-checkbox__checkmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__checkmark {
  color: var(--mat-checkbox-disabled-selected-checkmark-color, var(--mat-sys-surface));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__checkmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__checkmark {
    color: GrayText;
  }
}

.mdc-checkbox__checkmark-path {
  transition: stroke-dashoffset 180ms cubic-bezier(0.4, 0, 0.6, 1);
  stroke: currentColor;
  stroke-width: 3.12px;
  stroke-dashoffset: 29.7833385;
  stroke-dasharray: 29.7833385;
}

.mdc-checkbox__mixedmark {
  width: 100%;
  height: 0;
  transform: scaleX(0) rotate(0deg);
  border-width: 1px;
  border-style: solid;
  opacity: 0;
  transition: opacity 90ms cubic-bezier(0.4, 0, 0.6, 1), transform 90ms cubic-bezier(0.4, 0, 0.6, 1);
  border-color: var(--mat-checkbox-selected-checkmark-color, var(--mat-sys-on-primary));
}
@media (forced-colors: active) {
  .mdc-checkbox__mixedmark {
    margin: 0 1px;
  }
}

.mdc-checkbox--disabled .mdc-checkbox__mixedmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__mixedmark {
  border-color: var(--mat-checkbox-disabled-selected-checkmark-color, var(--mat-sys-surface));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__mixedmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__mixedmark {
    border-color: GrayText;
  }
}

.mdc-checkbox--anim-unchecked-checked .mdc-checkbox__background,
.mdc-checkbox--anim-unchecked-indeterminate .mdc-checkbox__background,
.mdc-checkbox--anim-checked-unchecked .mdc-checkbox__background,
.mdc-checkbox--anim-indeterminate-unchecked .mdc-checkbox__background {
  animation-duration: 180ms;
  animation-timing-function: linear;
}

.mdc-checkbox--anim-unchecked-checked .mdc-checkbox__checkmark-path {
  animation: mdc-checkbox-unchecked-checked-checkmark-path 180ms linear;
  transition: none;
}

.mdc-checkbox--anim-unchecked-indeterminate .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-unchecked-indeterminate-mixedmark 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-checked-unchecked .mdc-checkbox__checkmark-path {
  animation: mdc-checkbox-checked-unchecked-checkmark-path 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-checked-indeterminate .mdc-checkbox__checkmark {
  animation: mdc-checkbox-checked-indeterminate-checkmark 90ms linear;
  transition: none;
}
.mdc-checkbox--anim-checked-indeterminate .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-checked-indeterminate-mixedmark 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-indeterminate-checked .mdc-checkbox__checkmark {
  animation: mdc-checkbox-indeterminate-checked-checkmark 500ms linear;
  transition: none;
}
.mdc-checkbox--anim-indeterminate-checked .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-indeterminate-checked-mixedmark 500ms linear;
  transition: none;
}

.mdc-checkbox--anim-indeterminate-unchecked .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-indeterminate-unchecked-mixedmark 300ms linear;
  transition: none;
}

.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  transition: border-color 90ms cubic-bezier(0, 0, 0.2, 1), background-color 90ms cubic-bezier(0, 0, 0.2, 1);
}
.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path,
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path {
  stroke-dashoffset: 0;
}

.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__checkmark {
  transition: opacity 180ms cubic-bezier(0, 0, 0.2, 1), transform 180ms cubic-bezier(0, 0, 0.2, 1);
  opacity: 1;
}
.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transform: scaleX(1) rotate(-45deg);
}

.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__checkmark {
  transform: rotate(45deg);
  opacity: 0;
  transition: opacity 90ms cubic-bezier(0.4, 0, 0.6, 1), transform 90ms cubic-bezier(0.4, 0, 0.6, 1);
}
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transform: scaleX(1) rotate(0deg);
  opacity: 1;
}

@keyframes mdc-checkbox-unchecked-checked-checkmark-path {
  0%, 50% {
    stroke-dashoffset: 29.7833385;
  }
  50% {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
  }
  100% {
    stroke-dashoffset: 0;
  }
}
@keyframes mdc-checkbox-unchecked-indeterminate-mixedmark {
  0%, 68.2% {
    transform: scaleX(0);
  }
  68.2% {
    animation-timing-function: cubic-bezier(0, 0, 0, 1);
  }
  100% {
    transform: scaleX(1);
  }
}
@keyframes mdc-checkbox-checked-unchecked-checkmark-path {
  from {
    animation-timing-function: cubic-bezier(0.4, 0, 1, 1);
    opacity: 1;
    stroke-dashoffset: 0;
  }
  to {
    opacity: 0;
    stroke-dashoffset: -29.7833385;
  }
}
@keyframes mdc-checkbox-checked-indeterminate-checkmark {
  from {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    transform: rotate(0deg);
    opacity: 1;
  }
  to {
    transform: rotate(45deg);
    opacity: 0;
  }
}
@keyframes mdc-checkbox-indeterminate-checked-checkmark {
  from {
    animation-timing-function: cubic-bezier(0.14, 0, 0, 1);
    transform: rotate(45deg);
    opacity: 0;
  }
  to {
    transform: rotate(360deg);
    opacity: 1;
  }
}
@keyframes mdc-checkbox-checked-indeterminate-mixedmark {
  from {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    transform: rotate(-45deg);
    opacity: 0;
  }
  to {
    transform: rotate(0deg);
    opacity: 1;
  }
}
@keyframes mdc-checkbox-indeterminate-checked-mixedmark {
  from {
    animation-timing-function: cubic-bezier(0.14, 0, 0, 1);
    transform: rotate(0deg);
    opacity: 1;
  }
  to {
    transform: rotate(315deg);
    opacity: 0;
  }
}
@keyframes mdc-checkbox-indeterminate-unchecked-mixedmark {
  0% {
    animation-timing-function: linear;
    transform: scaleX(1);
    opacity: 1;
  }
  32.8%, 100% {
    transform: scaleX(0);
    opacity: 0;
  }
}
.mat-mdc-checkbox {
  display: inline-block;
  position: relative;
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mat-mdc-checkbox-touch-target,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__native-control,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__ripple,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mat-mdc-checkbox-ripple::before,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__checkmark,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transition: none !important;
  animation: none !important;
}
.mat-mdc-checkbox label {
  cursor: pointer;
}
.mat-mdc-checkbox .mat-internal-form-field {
  color: var(--mat-checkbox-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-checkbox-label-text-font, var(--mat-sys-body-medium-font));
  line-height: var(--mat-checkbox-label-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-checkbox-label-text-size, var(--mat-sys-body-medium-size));
  letter-spacing: var(--mat-checkbox-label-text-tracking, var(--mat-sys-body-medium-tracking));
  font-weight: var(--mat-checkbox-label-text-weight, var(--mat-sys-body-medium-weight));
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled.mat-mdc-checkbox-disabled-interactive {
  pointer-events: auto;
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled.mat-mdc-checkbox-disabled-interactive input {
  cursor: default;
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled label {
  cursor: default;
  color: var(--mat-checkbox-disabled-label-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mat-mdc-checkbox.mat-mdc-checkbox-disabled label {
    color: GrayText;
  }
}
.mat-mdc-checkbox label:empty {
  display: none;
}
.mat-mdc-checkbox .mdc-checkbox__ripple {
  opacity: 0;
}

.mat-mdc-checkbox .mat-mdc-checkbox-ripple,
.mdc-checkbox__ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
}
.mat-mdc-checkbox .mat-mdc-checkbox-ripple:not(:empty),
.mdc-checkbox__ripple:not(:empty) {
  transform: translateZ(0);
}

.mat-mdc-checkbox-ripple .mat-ripple-element {
  opacity: 0.1;
}

.mat-mdc-checkbox-touch-target {
  position: absolute;
  top: 50%;
  left: 50%;
  height: var(--mat-checkbox-touch-target-size, 48px);
  width: var(--mat-checkbox-touch-target-size, 48px);
  transform: translate(-50%, -50%);
  display: var(--mat-checkbox-touch-target-display, block);
}

.mat-mdc-checkbox .mat-mdc-checkbox-ripple::before {
  border-radius: 50%;
}

.mdc-checkbox__native-control:focus-visible ~ .mat-focus-indicator::before {
  content: "";
}
`],encapsulation:2,changeDetection:0})}return n})(),po=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[ha,de]})}return n})();var qu=new E("CdkAccordion"),u_=(()=>{class n{_stateChanges=new F;_openCloseAllActions=new F;id=m(xe).getId("cdk-accordion-");multi=!1;openAll(){this.multi&&this._openCloseAllActions.next(!0)}closeAll(){this._openCloseAllActions.next(!1)}ngOnChanges(e){this._stateChanges.next(e)}ngOnDestroy(){this._stateChanges.complete(),this._openCloseAllActions.complete()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["cdk-accordion"],["","cdkAccordion",""]],inputs:{multi:[2,"multi","multi",R]},exportAs:["cdkAccordion"],features:[ce([{provide:qu,useExisting:n}]),we]})}return n})(),m_=(()=>{class n{accordion=m(qu,{optional:!0,skipSelf:!0});_changeDetectorRef=m(Z);_expansionDispatcher=m(Nr);_openCloseAllSubscription=Le.EMPTY;closed=new z;opened=new z;destroyed=new z;expandedChange=new z;id=m(xe).getId("cdk-accordion-child-");get expanded(){return this._expanded}set expanded(e){if(this._expanded!==e){if(this._expanded=e,this.expandedChange.emit(e),e){this.opened.emit();let t=this.accordion?this.accordion.id:this.id;this._expansionDispatcher.notify(this.id,t)}else this.closed.emit();this._changeDetectorRef.markForCheck()}}_expanded=!1;get disabled(){return this._disabled()}set disabled(e){this._disabled.set(e)}_disabled=le(!1);_removeUniqueSelectionListener=()=>{};constructor(){}ngOnInit(){this._removeUniqueSelectionListener=this._expansionDispatcher.listen((e,t)=>{this.accordion&&!this.accordion.multi&&this.accordion.id===t&&this.id!==e&&(this.expanded=!1)}),this.accordion&&(this._openCloseAllSubscription=this._subscribeToOpenCloseAllActions())}ngOnDestroy(){this.opened.complete(),this.closed.complete(),this.destroyed.emit(),this.destroyed.complete(),this._removeUniqueSelectionListener(),this._openCloseAllSubscription.unsubscribe()}toggle(){this.disabled||(this.expanded=!this.expanded)}close(){this.disabled||(this.expanded=!1)}open(){this.disabled||(this.expanded=!0)}_subscribeToOpenCloseAllActions(){return this.accordion._openCloseAllActions.subscribe(e=>{this.disabled||(this.expanded=e)})}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["cdk-accordion-item"],["","cdkAccordionItem",""]],inputs:{expanded:[2,"expanded","expanded",R],disabled:[2,"disabled","disabled",R]},outputs:{closed:"closed",opened:"opened",destroyed:"destroyed",expandedChange:"expandedChange"},exportAs:["cdkAccordionItem"],features:[ce([{provide:qu,useValue:void 0}])]})}return n})(),p_=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({})}return n})();var Nw=["body"],Lw=["bodyWrapper"],Bw=[[["mat-expansion-panel-header"]],"*",[["mat-action-row"]]],jw=["mat-expansion-panel-header","*","mat-action-row"];function Vw(n,i){}var zw=[[["mat-panel-title"]],[["mat-panel-description"]],"*"],Uw=["mat-panel-title","mat-panel-description","*"];function Hw(n,i){n&1&&(Te(0,"span",1),Zn(),Te(1,"svg",2),yt(2,"path",3),Be()())}var Wu=new E("MAT_ACCORDION"),h_=new E("MAT_EXPANSION_PANEL"),$w=(()=>{class n{_template=m(He);_expansionPanel=m(h_,{optional:!0});constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["ng-template","matExpansionPanelContent",""]]})}return n})(),f_=new E("MAT_EXPANSION_PANEL_DEFAULT_OPTIONS"),Qu=(()=>{class n extends m_{_viewContainerRef=m(Xe);_animationsDisabled=Ee();_document=m(X);_ngZone=m(W);_elementRef=m(B);_renderer=m(Se);_cleanupTransitionEnd;get hideToggle(){return this._hideToggle||this.accordion&&this.accordion.hideToggle}set hideToggle(e){this._hideToggle=e}_hideToggle=!1;get togglePosition(){return this._togglePosition||this.accordion&&this.accordion.togglePosition}set togglePosition(e){this._togglePosition=e}_togglePosition;afterExpand=new z;afterCollapse=new z;_inputChanges=new F;accordion=m(Wu,{optional:!0,skipSelf:!0});_lazyContent;_body;_bodyWrapper;_portal;_headerId=m(xe).getId("mat-expansion-panel-header-");constructor(){super();let e=m(f_,{optional:!0});this._expansionDispatcher=m(Nr),e&&(this.hideToggle=e.hideToggle)}_hasSpacing(){return this.accordion?this.expanded&&this.accordion.displayMode==="default":!1}_getExpandedState(){return this.expanded?"expanded":"collapsed"}toggle(){this.expanded=!this.expanded}close(){this.expanded=!1}open(){this.expanded=!0}ngAfterContentInit(){this._lazyContent&&this._lazyContent._expansionPanel===this&&this.opened.pipe(tt(null),Ce(()=>this.expanded&&!this._portal),it(1)).subscribe(()=>{this._portal=new Qt(this._lazyContent._template,this._viewContainerRef)}),this._setupAnimationEvents()}ngOnChanges(e){this._inputChanges.next(e)}ngOnDestroy(){super.ngOnDestroy(),this._cleanupTransitionEnd?.(),this._inputChanges.complete()}_containsFocus(){if(this._body){let e=this._document.activeElement,t=this._body.nativeElement;return e===t||t.contains(e)}return!1}_transitionEndListener=({target:e,propertyName:t})=>{e===this._bodyWrapper?.nativeElement&&t==="grid-template-rows"&&this._ngZone.run(()=>{this.expanded?this.afterExpand.emit():this.afterCollapse.emit()})};_setupAnimationEvents(){this._ngZone.runOutsideAngular(()=>{this._animationsDisabled?(this.opened.subscribe(()=>this._ngZone.run(()=>this.afterExpand.emit())),this.closed.subscribe(()=>this._ngZone.run(()=>this.afterCollapse.emit()))):setTimeout(()=>{let e=this._elementRef.nativeElement;this._cleanupTransitionEnd=this._renderer.listen(e,"transitionend",this._transitionEndListener),e.classList.add("mat-expansion-panel-animations-enabled")},200)})}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-expansion-panel"]],contentQueries:function(t,a,o){if(t&1&&st(o,$w,5),t&2){let c;j(c=V())&&(a._lazyContent=c.first)}},viewQuery:function(t,a){if(t&1&&Ae(Nw,5)(Lw,5),t&2){let o;j(o=V())&&(a._body=o.first),j(o=V())&&(a._bodyWrapper=o.first)}},hostAttrs:[1,"mat-expansion-panel"],hostVars:4,hostBindings:function(t,a){t&2&&k("mat-expanded",a.expanded)("mat-expansion-panel-spacing",a._hasSpacing())},inputs:{hideToggle:[2,"hideToggle","hideToggle",R],togglePosition:"togglePosition"},outputs:{afterExpand:"afterExpand",afterCollapse:"afterCollapse"},exportAs:["matExpansionPanel"],features:[ce([{provide:Wu,useValue:void 0},{provide:h_,useExisting:n}]),ie,we],ngContentSelectors:jw,decls:9,vars:4,consts:[["bodyWrapper",""],["body",""],[1,"mat-expansion-panel-content-wrapper"],["role","region",1,"mat-expansion-panel-content",3,"id"],[1,"mat-expansion-panel-body"],[3,"cdkPortalOutlet"]],template:function(t,a){t&1&&(ye(Bw),ee(0),s(1,"div",2,0)(3,"div",3,1)(5,"div",4),ee(6,1),_e(7,Vw,0,0,"ng-template",5),r(),ee(8,2),r()()),t&2&&(d(),Y("inert",a.expanded?null:""),d(2),P("id",a.id),Y("aria-labelledby",a._headerId),d(4),P("cdkPortalOutlet",a._portal))},dependencies:[tn],styles:[`.mat-expansion-panel {
  box-sizing: content-box;
  display: block;
  margin: 0;
  overflow: hidden;
}
.mat-expansion-panel.mat-expansion-panel-animations-enabled {
  transition: margin 225ms cubic-bezier(0.4, 0, 0.2, 1), box-shadow 280ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-expansion-panel {
  position: relative;
  background: var(--mat-expansion-container-background-color, var(--mat-sys-surface));
  color: var(--mat-expansion-container-text-color, var(--mat-sys-on-surface));
  border-radius: var(--mat-expansion-container-shape, 12px);
}
.mat-expansion-panel:not([class*=mat-elevation-z]) {
  box-shadow: var(--mat-expansion-container-elevation-shadow, 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12));
}
.mat-accordion .mat-expansion-panel:not(.mat-expanded), .mat-accordion .mat-expansion-panel:not(.mat-expansion-panel-spacing) {
  border-radius: 0;
}
.mat-accordion .mat-expansion-panel:first-of-type {
  border-top-right-radius: var(--mat-expansion-container-shape, 12px);
  border-top-left-radius: var(--mat-expansion-container-shape, 12px);
}
.mat-accordion .mat-expansion-panel:last-of-type {
  border-bottom-right-radius: var(--mat-expansion-container-shape, 12px);
  border-bottom-left-radius: var(--mat-expansion-container-shape, 12px);
}
@media (forced-colors: active) {
  .mat-expansion-panel {
    outline: solid 1px;
  }
}

.mat-expansion-panel-content-wrapper {
  display: grid;
  grid-template-rows: 0fr;
  grid-template-columns: 100%;
}
.mat-expansion-panel-animations-enabled .mat-expansion-panel-content-wrapper {
  transition: grid-template-rows 225ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-expansion-panel.mat-expanded > .mat-expansion-panel-content-wrapper {
  grid-template-rows: 1fr;
}
@supports not (grid-template-rows: 0fr) {
  .mat-expansion-panel-content-wrapper {
    height: 0;
  }
  .mat-expansion-panel.mat-expanded > .mat-expansion-panel-content-wrapper {
    height: auto;
  }
}
@media print {
  .mat-expansion-panel-content-wrapper {
    height: 0;
  }
  .mat-expansion-panel.mat-expanded > .mat-expansion-panel-content-wrapper {
    height: auto;
  }
}

.mat-expansion-panel-content {
  display: flex;
  flex-direction: column;
  overflow: visible;
  min-height: 0;
  visibility: hidden;
}
.mat-expansion-panel-animations-enabled .mat-expansion-panel-content {
  transition: visibility 190ms linear;
}
.mat-expansion-panel.mat-expanded > .mat-expansion-panel-content-wrapper > .mat-expansion-panel-content {
  visibility: visible;
}
.mat-expansion-panel-content {
  font-family: var(--mat-expansion-container-text-font, var(--mat-sys-body-large-font));
  font-size: var(--mat-expansion-container-text-size, var(--mat-sys-body-large-size));
  font-weight: var(--mat-expansion-container-text-weight, var(--mat-sys-body-large-weight));
  line-height: var(--mat-expansion-container-text-line-height, var(--mat-sys-body-large-line-height));
  letter-spacing: var(--mat-expansion-container-text-tracking, var(--mat-sys-body-large-tracking));
}

.mat-expansion-panel-body {
  padding: 0 24px 16px;
}

.mat-expansion-panel-spacing {
  margin: 16px 0;
}
.mat-accordion > .mat-expansion-panel-spacing:first-child, .mat-accordion > *:first-child:not(.mat-expansion-panel) .mat-expansion-panel-spacing {
  margin-top: 0;
}
.mat-accordion > .mat-expansion-panel-spacing:last-child, .mat-accordion > *:last-child:not(.mat-expansion-panel) .mat-expansion-panel-spacing {
  margin-bottom: 0;
}

.mat-action-row {
  border-top-style: solid;
  border-top-width: 1px;
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  padding: 16px 8px 16px 24px;
  border-top-color: var(--mat-expansion-actions-divider-color, var(--mat-sys-outline));
}
.mat-action-row .mat-button-base,
.mat-action-row .mat-mdc-button-base {
  margin-left: 8px;
}
[dir=rtl] .mat-action-row .mat-button-base,
[dir=rtl] .mat-action-row .mat-mdc-button-base {
  margin-left: 0;
  margin-right: 8px;
}
`],encapsulation:2,changeDetection:0})}return n})();var Yu=(()=>{class n{panel=m(Qu,{host:!0});_element=m(B);_focusMonitor=m(Dt);_changeDetectorRef=m(Z);_parentChangeSubscription=Le.EMPTY;constructor(){m(Oe).load(Et);let e=this.panel,t=m(f_,{optional:!0}),a=m(new xt("tabindex"),{optional:!0}),o=e.accordion?e.accordion._stateChanges.pipe(Ce(c=>!!(c.hideToggle||c.togglePosition))):mt;this.tabIndex=parseInt(a||"")||0,this._parentChangeSubscription=ut(e.opened,e.closed,o,e._inputChanges.pipe(Ce(c=>!!(c.hideToggle||c.disabled||c.togglePosition)))).subscribe(()=>this._changeDetectorRef.markForCheck()),e.closed.pipe(Ce(()=>e._containsFocus())).subscribe(()=>this._focusMonitor.focusVia(this._element,"program")),t&&(this.expandedHeight=t.expandedHeight,this.collapsedHeight=t.collapsedHeight)}expandedHeight;collapsedHeight;tabIndex=0;get disabled(){return this.panel.disabled}_toggle(){this.disabled||this.panel.toggle()}_isExpanded(){return this.panel.expanded}_getExpandedState(){return this.panel._getExpandedState()}_getPanelId(){return this.panel.id}_getTogglePosition(){return this.panel.togglePosition}_showToggle(){return!this.panel.hideToggle&&!this.panel.disabled}_getHeaderHeight(){let e=this._isExpanded();return e&&this.expandedHeight?this.expandedHeight:!e&&this.collapsedHeight?this.collapsedHeight:null}_keydown(e){switch(e.keyCode){case 32:case 13:Ze(e)||(e.preventDefault(),this._toggle());break;default:this.panel.accordion&&this.panel.accordion._handleHeaderKeydown(e);return}}focus(e,t){e?this._focusMonitor.focusVia(this._element,e,t):this._element.nativeElement.focus(t)}ngAfterViewInit(){this._focusMonitor.monitor(this._element).subscribe(e=>{e&&this.panel.accordion&&this.panel.accordion._handleHeaderFocus(this)})}ngOnDestroy(){this._parentChangeSubscription.unsubscribe(),this._focusMonitor.stopMonitoring(this._element)}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-expansion-panel-header"]],hostAttrs:["role","button",1,"mat-expansion-panel-header","mat-focus-indicator"],hostVars:13,hostBindings:function(t,a){t&1&&_("click",function(){return a._toggle()})("keydown",function(c){return a._keydown(c)}),t&2&&(Y("id",a.panel._headerId)("tabindex",a.disabled?-1:a.tabIndex)("aria-controls",a._getPanelId())("aria-expanded",a._isExpanded())("aria-disabled",a.panel.disabled),Gt("height",a._getHeaderHeight()),k("mat-expanded",a._isExpanded())("mat-expansion-toggle-indicator-after",a._getTogglePosition()==="after")("mat-expansion-toggle-indicator-before",a._getTogglePosition()==="before"))},inputs:{expandedHeight:"expandedHeight",collapsedHeight:"collapsedHeight",tabIndex:[2,"tabIndex","tabIndex",e=>e==null?0:lt(e)]},ngContentSelectors:Uw,decls:5,vars:3,consts:[[1,"mat-content"],[1,"mat-expansion-indicator"],["xmlns","http://www.w3.org/2000/svg","viewBox","0 -960 960 960","aria-hidden","true","focusable","false"],["d","M480-345 240-585l56-56 184 184 184-184 56 56-240 240Z"]],template:function(t,a){t&1&&(ye(zw),Te(0,"span",0),ee(1),ee(2,1),ee(3,2),Be(),v(4,Hw,3,0,"span",1)),t&2&&(k("mat-content-hide-toggle",!a._showToggle()),d(4),y(a._showToggle()?4:-1))},styles:[`.mat-expansion-panel-header {
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 0 24px;
  border-radius: inherit;
}
.mat-expansion-panel-animations-enabled .mat-expansion-panel-header {
  transition: height 225ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-expansion-panel-header::before {
  border-radius: inherit;
}
.mat-expansion-panel-header {
  height: var(--mat-expansion-header-collapsed-state-height, 48px);
  font-family: var(--mat-expansion-header-text-font, var(--mat-sys-title-medium-font));
  font-size: var(--mat-expansion-header-text-size, var(--mat-sys-title-medium-size));
  font-weight: var(--mat-expansion-header-text-weight, var(--mat-sys-title-medium-weight));
  line-height: var(--mat-expansion-header-text-line-height, var(--mat-sys-title-medium-line-height));
  letter-spacing: var(--mat-expansion-header-text-tracking, var(--mat-sys-title-medium-tracking));
}
.mat-expansion-panel-header.mat-expanded {
  height: var(--mat-expansion-header-expanded-state-height, 64px);
}
.mat-expansion-panel-header[aria-disabled=true] {
  color: var(--mat-expansion-header-disabled-state-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-expansion-panel-header:not([aria-disabled=true]) {
  cursor: pointer;
}
.mat-expansion-panel:not(.mat-expanded) .mat-expansion-panel-header:not([aria-disabled=true]):hover {
  background: var(--mat-expansion-header-hover-state-layer-color, color-mix(in srgb, var(--mat-sys-on-surface) calc(var(--mat-sys-hover-state-layer-opacity) * 100%), transparent));
}
@media (hover: none) {
  .mat-expansion-panel:not(.mat-expanded) .mat-expansion-panel-header:not([aria-disabled=true]):hover {
    background: var(--mat-expansion-container-background-color, var(--mat-sys-surface));
  }
}
.mat-expansion-panel .mat-expansion-panel-header:not([aria-disabled=true]).cdk-keyboard-focused, .mat-expansion-panel .mat-expansion-panel-header:not([aria-disabled=true]).cdk-program-focused {
  background: var(--mat-expansion-header-focus-state-layer-color, color-mix(in srgb, var(--mat-sys-on-surface) calc(var(--mat-sys-focus-state-layer-opacity) * 100%), transparent));
}
.mat-expansion-panel-header._mat-animation-noopable {
  transition: none;
}
.mat-expansion-panel-header:focus, .mat-expansion-panel-header:hover {
  outline: none;
}
.mat-expansion-panel-header.mat-expanded:focus, .mat-expansion-panel-header.mat-expanded:hover {
  background: inherit;
}
.mat-expansion-panel-header.mat-expansion-toggle-indicator-before {
  flex-direction: row-reverse;
}
.mat-expansion-panel-header.mat-expansion-toggle-indicator-before .mat-expansion-indicator {
  margin: 0 16px 0 0;
}
[dir=rtl] .mat-expansion-panel-header.mat-expansion-toggle-indicator-before .mat-expansion-indicator {
  margin: 0 0 0 16px;
}

.mat-content {
  display: flex;
  flex: 1;
  flex-direction: row;
  overflow: hidden;
}
.mat-content.mat-content-hide-toggle {
  margin-right: 8px;
}
[dir=rtl] .mat-content.mat-content-hide-toggle {
  margin-right: 0;
  margin-left: 8px;
}
.mat-expansion-toggle-indicator-before .mat-content.mat-content-hide-toggle {
  margin-left: 24px;
  margin-right: 0;
}
[dir=rtl] .mat-expansion-toggle-indicator-before .mat-content.mat-content-hide-toggle {
  margin-right: 24px;
  margin-left: 0;
}

.mat-expansion-panel-header-title {
  color: var(--mat-expansion-header-text-color, var(--mat-sys-on-surface));
}

.mat-expansion-panel-header-title,
.mat-expansion-panel-header-description {
  display: flex;
  flex-grow: 1;
  flex-basis: 0;
  margin-right: 16px;
  align-items: center;
}
[dir=rtl] .mat-expansion-panel-header-title,
[dir=rtl] .mat-expansion-panel-header-description {
  margin-right: 0;
  margin-left: 16px;
}
.mat-expansion-panel-header[aria-disabled=true] .mat-expansion-panel-header-title,
.mat-expansion-panel-header[aria-disabled=true] .mat-expansion-panel-header-description {
  color: inherit;
}

.mat-expansion-panel-header-description {
  flex-grow: 2;
  color: var(--mat-expansion-header-description-color, var(--mat-sys-on-surface-variant));
}

.mat-expansion-panel-animations-enabled .mat-expansion-indicator {
  transition: transform 225ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-expansion-panel-header.mat-expanded .mat-expansion-indicator {
  transform: rotate(180deg);
}
.mat-expansion-indicator::after {
  border-style: solid;
  border-width: 0 2px 2px 0;
  content: "";
  padding: 3px;
  transform: rotate(45deg);
  vertical-align: middle;
  color: var(--mat-expansion-header-indicator-color, var(--mat-sys-on-surface-variant));
  display: var(--mat-expansion-legacy-header-indicator-display, none);
}
.mat-expansion-indicator svg {
  width: 24px;
  height: 24px;
  margin: 0 -8px;
  vertical-align: middle;
  fill: var(--mat-expansion-header-indicator-color, var(--mat-sys-on-surface-variant));
  display: var(--mat-expansion-header-indicator-display, inline-block);
}

@media (forced-colors: active) {
  .mat-expansion-panel-content {
    border-top: 1px solid;
    border-top-left-radius: 0;
    border-top-right-radius: 0;
  }
}
`],encapsulation:2,changeDetection:0})}return n})();var g_=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["mat-panel-title"]],hostAttrs:[1,"mat-expansion-panel-header-title"]})}return n})(),__=(()=>{class n extends u_{_keyManager;_ownHeaders=new di;_headers;hideToggle=!1;displayMode="default";togglePosition="after";ngAfterContentInit(){this._headers.changes.pipe(tt(this._headers)).subscribe(e=>{this._ownHeaders.reset(e.filter(t=>t.panel.accordion===this)),this._ownHeaders.notifyOnChanges()}),this._keyManager=new Ei(this._ownHeaders).withWrap().withHomeAndEnd()}_handleHeaderKeydown(e){this._keyManager.onKeydown(e)}_handleHeaderFocus(e){this._keyManager.updateActiveItem(e)}ngOnDestroy(){super.ngOnDestroy(),this._keyManager?.destroy(),this._ownHeaders.destroy()}static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["mat-accordion"]],contentQueries:function(t,a,o){if(t&1&&st(o,Yu,5),t&2){let c;j(c=V())&&(a._headers=c)}},hostAttrs:[1,"mat-accordion"],hostVars:2,hostBindings:function(t,a){t&2&&k("mat-accordion-multi",a.multi)},inputs:{hideToggle:[2,"hideToggle","hideToggle",R],displayMode:"displayMode",togglePosition:"togglePosition"},exportAs:["matAccordion"],features:[ce([{provide:Wu,useExisting:n}]),ie]})}return n})(),b_=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[p_,En,de]})}return n})();var qw=[[["caption"]],[["colgroup"],["col"]],"*"],Ww=["caption","colgroup, col","*"];function Qw(n,i){n&1&&ee(0,2)}function Yw(n,i){n&1&&(s(0,"thead",0),ot(1,1),r(),s(2,"tbody",0),ot(3,2)(4,3),r(),s(5,"tfoot",0),ot(6,4),r())}function Xw(n,i){n&1&&ot(0,1)(1,2)(2,3)(3,4)}var kn=new E("CDK_TABLE");var al=(()=>{class n{template=m(He);constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdkCellDef",""]]})}return n})(),ol=(()=>{class n{template=m(He);constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdkHeaderCellDef",""]]})}return n})(),x_=(()=>{class n{template=m(He);constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdkFooterCellDef",""]]})}return n})(),ho=(()=>{class n{_table=m(kn,{optional:!0});_hasStickyChanged=!1;get name(){return this._name}set name(e){this._setNameInput(e)}_name;get sticky(){return this._sticky}set sticky(e){e!==this._sticky&&(this._sticky=e,this._hasStickyChanged=!0)}_sticky=!1;get stickyEnd(){return this._stickyEnd}set stickyEnd(e){e!==this._stickyEnd&&(this._stickyEnd=e,this._hasStickyChanged=!0)}_stickyEnd=!1;cell;headerCell;footerCell;cssClassFriendlyName;_columnCssClassName;constructor(){}hasStickyChanged(){let e=this._hasStickyChanged;return this.resetStickyChanged(),e}resetStickyChanged(){this._hasStickyChanged=!1}_updateColumnCssClassName(){this._columnCssClassName=[`cdk-column-${this.cssClassFriendlyName}`]}_setNameInput(e){e&&(this._name=e,this.cssClassFriendlyName=e.replace(/[^a-z0-9_-]/gi,"-"),this._updateColumnCssClassName())}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdkColumnDef",""]],contentQueries:function(t,a,o){if(t&1&&st(o,al,5)(o,ol,5)(o,x_,5),t&2){let c;j(c=V())&&(a.cell=c.first),j(c=V())&&(a.headerCell=c.first),j(c=V())&&(a.footerCell=c.first)}},inputs:{name:[0,"cdkColumnDef","name"],sticky:[2,"sticky","sticky",R],stickyEnd:[2,"stickyEnd","stickyEnd",R]}})}return n})(),il=class{constructor(i,e){e.nativeElement.classList.add(...i._columnCssClassName)}},C_=(()=>{class n extends il{constructor(){super(m(ho),m(B))}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["cdk-header-cell"],["th","cdk-header-cell",""]],hostAttrs:["role","columnheader",1,"cdk-header-cell"],features:[ie]})}return n})();var w_=(()=>{class n extends il{constructor(){let e=m(ho),t=m(B);super(e,t);let a=e._table?._getCellRole();a&&t.nativeElement.setAttribute("role",a)}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["cdk-cell"],["td","cdk-cell",""]],hostAttrs:[1,"cdk-cell"],features:[ie]})}return n})();var Ku=(()=>{class n{template=m(He);_differs=m(mi);columns;_columnsDiffer;constructor(){}ngOnChanges(e){if(!this._columnsDiffer){let t=e.columns&&e.columns.currentValue||[];this._columnsDiffer=this._differs.find(t).create(),this._columnsDiffer.diff(t)}}getColumnsDiff(){return this._columnsDiffer.diff(this.columns)}extractCellTemplate(e){return this instanceof Gr?e.headerCell.template:this instanceof Zu?e.footerCell.template:e.cell.template}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,features:[we]})}return n})(),Gr=(()=>{class n extends Ku{_table=m(kn,{optional:!0});_hasStickyChanged=!1;get sticky(){return this._sticky}set sticky(e){e!==this._sticky&&(this._sticky=e,this._hasStickyChanged=!0)}_sticky=!1;constructor(){super(m(He),m(mi))}ngOnChanges(e){super.ngOnChanges(e)}hasStickyChanged(){let e=this._hasStickyChanged;return this.resetStickyChanged(),e}resetStickyChanged(){this._hasStickyChanged=!1}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdkHeaderRowDef",""]],inputs:{columns:[0,"cdkHeaderRowDef","columns"],sticky:[2,"cdkHeaderRowDefSticky","sticky",R]},features:[ie,we]})}return n})(),Zu=(()=>{class n extends Ku{_table=m(kn,{optional:!0});_hasStickyChanged=!1;get sticky(){return this._sticky}set sticky(e){e!==this._sticky&&(this._sticky=e,this._hasStickyChanged=!0)}_sticky=!1;constructor(){super(m(He),m(mi))}ngOnChanges(e){super.ngOnChanges(e)}hasStickyChanged(){let e=this._hasStickyChanged;return this.resetStickyChanged(),e}resetStickyChanged(){this._hasStickyChanged=!1}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdkFooterRowDef",""]],inputs:{columns:[0,"cdkFooterRowDef","columns"],sticky:[2,"cdkFooterRowDefSticky","sticky",R]},features:[ie,we]})}return n})(),rl=(()=>{class n extends Ku{_table=m(kn,{optional:!0});when;constructor(){super(m(He),m(mi))}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdkRowDef",""]],inputs:{columns:[0,"cdkRowDefColumns","columns"],when:[0,"cdkRowDefWhen","when"]},features:[ie]})}return n})(),fa=(()=>{class n{_viewContainer=m(Xe);cells;context;static mostRecentCellOutlet=null;constructor(){n.mostRecentCellOutlet=this}ngOnDestroy(){n.mostRecentCellOutlet===this&&(n.mostRecentCellOutlet=null)}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","cdkCellOutlet",""]]})}return n})(),Ju=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["cdk-header-row"],["tr","cdk-header-row",""]],hostAttrs:["role","row",1,"cdk-header-row"],decls:1,vars:0,consts:[["cdkCellOutlet",""]],template:function(t,a){t&1&&ot(0,0)},dependencies:[fa],encapsulation:2})}return n})();var em=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["cdk-row"],["tr","cdk-row",""]],hostAttrs:["role","row",1,"cdk-row"],decls:1,vars:0,consts:[["cdkCellOutlet",""]],template:function(t,a){t&1&&ot(0,0)},dependencies:[fa],encapsulation:2})}return n})(),D_=(()=>{class n{templateRef=m(He);_contentClassNames=["cdk-no-data-row","cdk-row"];_cellClassNames=["cdk-cell","cdk-no-data-cell"];_cellSelector="td, cdk-cell, [cdk-cell], .cdk-cell";constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["ng-template","cdkNoDataRow",""]]})}return n})(),v_=["top","bottom","left","right"],Xu=class{_isNativeHtmlTable;_stickCellCss;_isBrowser;_needsPositionStickyOnElement;direction;_positionListener;_tableInjector;_elemSizeCache=new WeakMap;_resizeObserver=globalThis?.ResizeObserver?new globalThis.ResizeObserver(i=>this._updateCachedSizes(i)):null;_updatedStickyColumnsParamsToReplay=[];_stickyColumnsReplayTimeout=null;_cachedCellWidths=[];_borderCellCss;_destroyed=!1;constructor(i,e,t=!0,a=!0,o,c,u){this._isNativeHtmlTable=i,this._stickCellCss=e,this._isBrowser=t,this._needsPositionStickyOnElement=a,this.direction=o,this._positionListener=c,this._tableInjector=u,this._borderCellCss={top:`${e}-border-elem-top`,bottom:`${e}-border-elem-bottom`,left:`${e}-border-elem-left`,right:`${e}-border-elem-right`}}clearStickyPositioning(i,e){(e.includes("left")||e.includes("right"))&&this._removeFromStickyColumnReplayQueue(i);let t=[];for(let a of i)a.nodeType===a.ELEMENT_NODE&&t.push(a,...Array.from(a.children));Pe({write:()=>{for(let a of t)this._removeStickyStyle(a,e)}},{injector:this._tableInjector})}updateStickyColumns(i,e,t,a=!0,o=!0){if(!i.length||!this._isBrowser||!(e.some(J=>J)||t.some(J=>J))){this._positionListener?.stickyColumnsUpdated({sizes:[]}),this._positionListener?.stickyEndColumnsUpdated({sizes:[]});return}let c=i[0],u=c.children.length,p=this.direction==="rtl",f=p?"right":"left",b=p?"left":"right",w=e.lastIndexOf(!0),L=t.indexOf(!0),$,ae,me;o&&this._updateStickyColumnReplayQueue({rows:[...i],stickyStartStates:[...e],stickyEndStates:[...t]}),Pe({earlyRead:()=>{$=this._getCellWidths(c,a),ae=this._getStickyStartColumnPositions($,e),me=this._getStickyEndColumnPositions($,t)},write:()=>{for(let J of i)for(let se=0;se<u;se++){let Ie=J.children[se];e[se]&&this._addStickyStyle(Ie,f,ae[se],se===w),t[se]&&this._addStickyStyle(Ie,b,me[se],se===L)}this._positionListener&&$.some(J=>!!J)&&(this._positionListener.stickyColumnsUpdated({sizes:w===-1?[]:$.slice(0,w+1).map((J,se)=>e[se]?J:null)}),this._positionListener.stickyEndColumnsUpdated({sizes:L===-1?[]:$.slice(L).map((J,se)=>t[se+L]?J:null).reverse()}))}},{injector:this._tableInjector})}stickRows(i,e,t){if(!this._isBrowser)return;let a=t==="bottom"?i.slice().reverse():i,o=t==="bottom"?e.slice().reverse():e,c=[],u=[],p=[];Pe({earlyRead:()=>{for(let f=0,b=0;f<a.length;f++){if(!o[f])continue;c[f]=b;let w=a[f];p[f]=this._isNativeHtmlTable?Array.from(w.children):[w];let L=this._retrieveElementSize(w).height;b+=L,u[f]=L}},write:()=>{let f=o.lastIndexOf(!0);for(let b=0;b<a.length;b++){if(!o[b])continue;let w=c[b],L=b===f;for(let $ of p[b])this._addStickyStyle($,t,w,L)}t==="top"?this._positionListener?.stickyHeaderRowsUpdated({sizes:u,offsets:c,elements:p}):this._positionListener?.stickyFooterRowsUpdated({sizes:u,offsets:c,elements:p})}},{injector:this._tableInjector})}updateStickyFooterContainer(i,e){this._isNativeHtmlTable&&Pe({write:()=>{let t=i.querySelector("tfoot");t&&(e.some(a=>!a)?this._removeStickyStyle(t,["bottom"]):this._addStickyStyle(t,"bottom",0,!1))}},{injector:this._tableInjector})}destroy(){this._stickyColumnsReplayTimeout&&clearTimeout(this._stickyColumnsReplayTimeout),this._resizeObserver?.disconnect(),this._destroyed=!0}_removeStickyStyle(i,e){if(!i.classList.contains(this._stickCellCss))return;for(let a of e)i.style[a]="",i.classList.remove(this._borderCellCss[a]);v_.some(a=>e.indexOf(a)===-1&&i.style[a])?i.style.zIndex=this._getCalculatedZIndex(i):(i.style.zIndex="",this._needsPositionStickyOnElement&&(i.style.position=""),i.classList.remove(this._stickCellCss))}_addStickyStyle(i,e,t,a){i.classList.add(this._stickCellCss),a&&i.classList.add(this._borderCellCss[e]),i.style[e]=`${t}px`,i.style.zIndex=this._getCalculatedZIndex(i),this._needsPositionStickyOnElement&&(i.style.cssText+="position: -webkit-sticky; position: sticky; ")}_getCalculatedZIndex(i){let e={top:100,bottom:10,left:1,right:1},t=0;for(let a of v_)i.style[a]&&(t+=e[a]);return t?`${t}`:""}_getCellWidths(i,e=!0){if(!e&&this._cachedCellWidths.length)return this._cachedCellWidths;let t=[],a=i.children;for(let o=0;o<a.length;o++){let c=a[o];t.push(this._retrieveElementSize(c).width)}return this._cachedCellWidths=t,t}_getStickyStartColumnPositions(i,e){let t=[],a=0;for(let o=0;o<i.length;o++)e[o]&&(t[o]=a,a+=i[o]);return t}_getStickyEndColumnPositions(i,e){let t=[],a=0;for(let o=i.length;o>0;o--)e[o]&&(t[o]=a,a+=i[o]);return t}_retrieveElementSize(i){let e=this._elemSizeCache.get(i);if(e)return e;let t=i.getBoundingClientRect(),a={width:t.width,height:t.height};return this._resizeObserver&&(this._elemSizeCache.set(i,a),this._resizeObserver.observe(i,{box:"border-box"})),a}_updateStickyColumnReplayQueue(i){this._removeFromStickyColumnReplayQueue(i.rows),this._stickyColumnsReplayTimeout||this._updatedStickyColumnsParamsToReplay.push(i)}_removeFromStickyColumnReplayQueue(i){let e=new Set(i);for(let t of this._updatedStickyColumnsParamsToReplay)t.rows=t.rows.filter(a=>!e.has(a));this._updatedStickyColumnsParamsToReplay=this._updatedStickyColumnsParamsToReplay.filter(t=>!!t.rows.length)}_updateCachedSizes(i){let e=!1;for(let t of i){let a=t.borderBoxSize?.length?{width:t.borderBoxSize[0].inlineSize,height:t.borderBoxSize[0].blockSize}:{width:t.contentRect.width,height:t.contentRect.height};a.width!==this._elemSizeCache.get(t.target)?.width&&Kw(t.target)&&(e=!0),this._elemSizeCache.set(t.target,a)}e&&this._updatedStickyColumnsParamsToReplay.length&&(this._stickyColumnsReplayTimeout&&clearTimeout(this._stickyColumnsReplayTimeout),this._stickyColumnsReplayTimeout=setTimeout(()=>{if(!this._destroyed){for(let t of this._updatedStickyColumnsParamsToReplay)this.updateStickyColumns(t.rows,t.stickyStartStates,t.stickyEndStates,!0,!1);this._updatedStickyColumnsParamsToReplay=[],this._stickyColumnsReplayTimeout=null}},0))}};function Kw(n){return["cdk-cell","cdk-header-cell","cdk-footer-cell"].some(i=>n.classList.contains(i))}var $r=new E("STICKY_POSITIONING_LISTENER");var tm=(()=>{class n{viewContainer=m(Xe);elementRef=m(B);constructor(){let e=m(kn);e._rowOutlet=this,e._outletAssigned()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","rowOutlet",""]]})}return n})(),nm=(()=>{class n{viewContainer=m(Xe);elementRef=m(B);constructor(){let e=m(kn);e._headerRowOutlet=this,e._outletAssigned()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","headerRowOutlet",""]]})}return n})(),im=(()=>{class n{viewContainer=m(Xe);elementRef=m(B);constructor(){let e=m(kn);e._footerRowOutlet=this,e._outletAssigned()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","footerRowOutlet",""]]})}return n})(),am=(()=>{class n{viewContainer=m(Xe);elementRef=m(B);constructor(){let e=m(kn);e._noDataRowOutlet=this,e._outletAssigned()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","noDataRowOutlet",""]]})}return n})(),om=(()=>{class n{_differs=m(mi);_changeDetectorRef=m(Z);_elementRef=m(B);_dir=m(Qe,{optional:!0});_platform=m(be);_viewRepeater;_viewportRuler=m(un);_injector=m(re);_virtualScrollViewport=m(Vg,{optional:!0,host:!0});_positionListener=m($r,{optional:!0})||m($r,{optional:!0,skipSelf:!0});_document=m(X);_data;_renderedRange;_onDestroy=new F;_renderRows;_renderChangeSubscription=null;_columnDefsByName=new Map;_rowDefs;_headerRowDefs;_footerRowDefs;_dataDiffer;_defaultRowDef=null;_customColumnDefs=new Set;_customRowDefs=new Set;_customHeaderRowDefs=new Set;_customFooterRowDefs=new Set;_customNoDataRow=null;_headerRowDefChanged=!0;_footerRowDefChanged=!0;_stickyColumnStylesNeedReset=!0;_forceRecalculateCellWidths=!0;_cachedRenderRowsMap=new Map;_isNativeHtmlTable;_stickyStyler;stickyCssClass="cdk-table-sticky";needsPositionStickyOnElement=!0;_isServer;_isShowingNoDataRow=!1;_hasAllOutlets=!1;_hasInitialized=!1;_headerRowStickyUpdates=new F;_footerRowStickyUpdates=new F;_disableVirtualScrolling=!1;_getCellRole(){if(this._cellRoleInternal===void 0){let e=this._elementRef.nativeElement.getAttribute("role");return e==="grid"||e==="treegrid"?"gridcell":"cell"}return this._cellRoleInternal}_cellRoleInternal=void 0;get trackBy(){return this._trackByFn}set trackBy(e){this._trackByFn=e}_trackByFn;get dataSource(){return this._dataSource}set dataSource(e){this._dataSource!==e&&(this._switchDataSource(e),this._changeDetectorRef.markForCheck())}_dataSource;_dataSourceChanges=new F;_dataStream=new F;get multiTemplateDataRows(){return this._multiTemplateDataRows}set multiTemplateDataRows(e){this._multiTemplateDataRows=e,this._rowOutlet&&this._rowOutlet.viewContainer.length&&(this._forceRenderDataRows(),this.updateStickyColumnStyles())}_multiTemplateDataRows=!1;get fixedLayout(){return this._virtualScrollEnabled()?!0:this._fixedLayout}set fixedLayout(e){this._fixedLayout=e,this._forceRecalculateCellWidths=!0,this._stickyColumnStylesNeedReset=!0}_fixedLayout=!1;recycleRows=!1;contentChanged=new z;viewChange=new et({start:0,end:Number.MAX_VALUE});_rowOutlet;_headerRowOutlet;_footerRowOutlet;_noDataRowOutlet;_contentColumnDefs;_contentRowDefs;_contentHeaderRowDefs;_contentFooterRowDefs;_noDataRow;constructor(){m(new xt("role"),{optional:!0})||this._elementRef.nativeElement.setAttribute("role","table"),this._isServer=!this._platform.isBrowser,this._isNativeHtmlTable=this._elementRef.nativeElement.nodeName==="TABLE",this._dataDiffer=this._differs.find([]).create((t,a)=>this.trackBy?this.trackBy(a.dataIndex,a.data):a)}ngOnInit(){this._setupStickyStyler(),this._viewportRuler.change().pipe(pe(this._onDestroy)).subscribe(()=>{this._forceRecalculateCellWidths=!0})}ngAfterContentInit(){this._viewRepeater=this.recycleRows||this._virtualScrollEnabled()?new zc:new Uc,this._virtualScrollEnabled()&&this._setupVirtualScrolling(this._virtualScrollViewport),this._hasInitialized=!0}ngAfterContentChecked(){this._canRender()&&this._render()}ngOnDestroy(){this._stickyStyler?.destroy(),[this._rowOutlet?.viewContainer,this._headerRowOutlet?.viewContainer,this._footerRowOutlet?.viewContainer,this._cachedRenderRowsMap,this._customColumnDefs,this._customRowDefs,this._customHeaderRowDefs,this._customFooterRowDefs,this._columnDefsByName].forEach(e=>{e?.clear()}),this._headerRowDefs=[],this._footerRowDefs=[],this._defaultRowDef=null,this._headerRowStickyUpdates.complete(),this._footerRowStickyUpdates.complete(),this._onDestroy.next(),this._onDestroy.complete(),Fr(this.dataSource)&&this.dataSource.disconnect(this)}renderRows(){this._renderRows=this._getAllRenderRows();let e=this._dataDiffer.diff(this._renderRows);if(!e){this._updateNoDataRow(),this.contentChanged.next();return}let t=this._rowOutlet.viewContainer;this._viewRepeater.applyChanges(e,t,(a,o,c)=>this._getEmbeddedViewArgs(a.item,c),a=>a.item.data,a=>{a.operation===wn.INSERTED&&a.context&&this._renderCellTemplateForItem(a.record.item.rowDef,a.context)}),this._updateRowIndexContext(),e.forEachIdentityChange(a=>{let o=t.get(a.currentIndex);o.context.$implicit=a.item.data}),this._updateNoDataRow(),this.contentChanged.next(),this.updateStickyColumnStyles()}addColumnDef(e){this._customColumnDefs.add(e)}removeColumnDef(e){this._customColumnDefs.delete(e)}addRowDef(e){this._customRowDefs.add(e)}removeRowDef(e){this._customRowDefs.delete(e)}addHeaderRowDef(e){this._customHeaderRowDefs.add(e),this._headerRowDefChanged=!0}removeHeaderRowDef(e){this._customHeaderRowDefs.delete(e),this._headerRowDefChanged=!0}addFooterRowDef(e){this._customFooterRowDefs.add(e),this._footerRowDefChanged=!0}removeFooterRowDef(e){this._customFooterRowDefs.delete(e),this._footerRowDefChanged=!0}setNoDataRow(e){this._customNoDataRow=e}updateStickyHeaderRowStyles(){let e=this._getRenderedRows(this._headerRowOutlet);if(this._isNativeHtmlTable){let a=y_(this._headerRowOutlet,"thead");a&&(a.style.display=e.length?"":"none")}let t=this._headerRowDefs.map(a=>a.sticky);this._stickyStyler.clearStickyPositioning(e,["top"]),this._stickyStyler.stickRows(e,t,"top"),this._headerRowDefs.forEach(a=>a.resetStickyChanged())}updateStickyFooterRowStyles(){let e=this._getRenderedRows(this._footerRowOutlet);if(this._isNativeHtmlTable){let a=y_(this._footerRowOutlet,"tfoot");a&&(a.style.display=e.length?"":"none")}let t=this._footerRowDefs.map(a=>a.sticky);this._stickyStyler.clearStickyPositioning(e,["bottom"]),this._stickyStyler.stickRows(e,t,"bottom"),this._stickyStyler.updateStickyFooterContainer(this._elementRef.nativeElement,t),this._footerRowDefs.forEach(a=>a.resetStickyChanged())}updateStickyColumnStyles(){let e=this._getRenderedRows(this._headerRowOutlet),t=this._getRenderedRows(this._rowOutlet),a=this._getRenderedRows(this._footerRowOutlet);(this._isNativeHtmlTable&&!this.fixedLayout||this._stickyColumnStylesNeedReset)&&(this._stickyStyler.clearStickyPositioning([...e,...t,...a],["left","right"]),this._stickyColumnStylesNeedReset=!1),e.forEach((o,c)=>{this._addStickyColumnStyles([o],this._headerRowDefs[c])}),this._rowDefs.forEach(o=>{let c=[];for(let u=0;u<t.length;u++)this._renderRows[u].rowDef===o&&c.push(t[u]);this._addStickyColumnStyles(c,o)}),a.forEach((o,c)=>{this._addStickyColumnStyles([o],this._footerRowDefs[c])}),Array.from(this._columnDefsByName.values()).forEach(o=>o.resetStickyChanged())}stickyColumnsUpdated(e){this._positionListener?.stickyColumnsUpdated(e)}stickyEndColumnsUpdated(e){this._positionListener?.stickyEndColumnsUpdated(e)}stickyHeaderRowsUpdated(e){this._headerRowStickyUpdates.next(e),this._positionListener?.stickyHeaderRowsUpdated(e)}stickyFooterRowsUpdated(e){this._footerRowStickyUpdates.next(e),this._positionListener?.stickyFooterRowsUpdated(e)}_outletAssigned(){!this._hasAllOutlets&&this._rowOutlet&&this._headerRowOutlet&&this._footerRowOutlet&&this._noDataRowOutlet&&(this._hasAllOutlets=!0,this._canRender()&&this._render())}_canRender(){return this._hasAllOutlets&&this._hasInitialized}_render(){this._cacheRowDefs(),this._cacheColumnDefs(),!this._headerRowDefs.length&&!this._footerRowDefs.length&&this._rowDefs.length;let t=this._renderUpdatedColumns()||this._headerRowDefChanged||this._footerRowDefChanged;this._stickyColumnStylesNeedReset=this._stickyColumnStylesNeedReset||t,this._forceRecalculateCellWidths=t,this._headerRowDefChanged&&(this._forceRenderHeaderRows(),this._headerRowDefChanged=!1),this._footerRowDefChanged&&(this._forceRenderFooterRows(),this._footerRowDefChanged=!1),this.dataSource&&this._rowDefs.length>0&&!this._renderChangeSubscription?this._observeRenderChanges():this._stickyColumnStylesNeedReset&&this.updateStickyColumnStyles(),this._checkStickyStates()}_getAllRenderRows(){if(!Array.isArray(this._data)||!this._renderedRange)return[];let e=[],t=Math.min(this._data.length,this._renderedRange.end),a=this._cachedRenderRowsMap;this._cachedRenderRowsMap=new Map;for(let o=this._renderedRange.start;o<t;o++){let c=this._data[o],u=this._getRenderRowsForData(c,o,a.get(c));this._cachedRenderRowsMap.has(c)||this._cachedRenderRowsMap.set(c,new WeakMap);for(let p=0;p<u.length;p++){let f=u[p],b=this._cachedRenderRowsMap.get(f.data);b.has(f.rowDef)?b.get(f.rowDef).push(f):b.set(f.rowDef,[f]),e.push(f)}}return e}_getRenderRowsForData(e,t,a){return this._getRowDefs(e,t).map(c=>{let u=a&&a.has(c)?a.get(c):[];if(u.length){let p=u.shift();return p.dataIndex=t,p}else return{data:e,rowDef:c,dataIndex:t}})}_cacheColumnDefs(){this._columnDefsByName.clear(),nl(this._getOwnDefs(this._contentColumnDefs),this._customColumnDefs).forEach(t=>{this._columnDefsByName.has(t.name),this._columnDefsByName.set(t.name,t)})}_cacheRowDefs(){this._headerRowDefs=nl(this._getOwnDefs(this._contentHeaderRowDefs),this._customHeaderRowDefs),this._footerRowDefs=nl(this._getOwnDefs(this._contentFooterRowDefs),this._customFooterRowDefs),this._rowDefs=nl(this._getOwnDefs(this._contentRowDefs),this._customRowDefs);let e=this._rowDefs.filter(t=>!t.when);this._defaultRowDef=e[0]}_renderUpdatedColumns(){let e=(c,u)=>{let p=!!u.getColumnsDiff();return c||p},t=this._rowDefs.reduce(e,!1);t&&this._forceRenderDataRows();let a=this._headerRowDefs.reduce(e,!1);a&&this._forceRenderHeaderRows();let o=this._footerRowDefs.reduce(e,!1);return o&&this._forceRenderFooterRows(),t||a||o}_switchDataSource(e){this._data=[],Fr(this.dataSource)&&this.dataSource.disconnect(this),this._renderChangeSubscription&&(this._renderChangeSubscription.unsubscribe(),this._renderChangeSubscription=null),e||(this._dataDiffer&&this._dataDiffer.diff([]),this._rowOutlet&&this._rowOutlet.viewContainer.clear()),this._dataSource=e}_observeRenderChanges(){if(!this.dataSource)return;let e;Fr(this.dataSource)?e=this.dataSource.connect(this):ba(this.dataSource)?e=this.dataSource:Array.isArray(this.dataSource)&&(e=K(this.dataSource)),this._renderChangeSubscription=nn([e,this.viewChange]).pipe(pe(this._onDestroy)).subscribe(([t,a])=>{this._data=t||[],this._renderedRange=a,this._dataStream.next(t),this.renderRows()})}_forceRenderHeaderRows(){this._headerRowOutlet.viewContainer.length>0&&this._headerRowOutlet.viewContainer.clear(),this._headerRowDefs.forEach((e,t)=>this._renderRow(this._headerRowOutlet,e,t)),this.updateStickyHeaderRowStyles()}_forceRenderFooterRows(){this._footerRowOutlet.viewContainer.length>0&&this._footerRowOutlet.viewContainer.clear(),this._footerRowDefs.forEach((e,t)=>this._renderRow(this._footerRowOutlet,e,t)),this.updateStickyFooterRowStyles()}_addStickyColumnStyles(e,t){let a=Array.from(t?.columns||[]).map(u=>{let p=this._columnDefsByName.get(u);return p}),o=a.map(u=>u.sticky),c=a.map(u=>u.stickyEnd);this._stickyStyler.updateStickyColumns(e,o,c,!this.fixedLayout||this._forceRecalculateCellWidths)}_getRenderedRows(e){let t=[];for(let a=0;a<e.viewContainer.length;a++){let o=e.viewContainer.get(a);t.push(o.rootNodes[0])}return t}_getRowDefs(e,t){if(this._rowDefs.length===1)return[this._rowDefs[0]];let a=[];if(this.multiTemplateDataRows)a=this._rowDefs.filter(o=>!o.when||o.when(t,e));else{let o=this._rowDefs.find(c=>c.when&&c.when(t,e))||this._defaultRowDef;o&&a.push(o)}return a.length,a}_getEmbeddedViewArgs(e,t){let a=e.rowDef,o={$implicit:e.data};return{templateRef:a.template,context:o,index:t}}_renderRow(e,t,a,o={}){let c=e.viewContainer.createEmbeddedView(t.template,o,a);return this._renderCellTemplateForItem(t,o),c}_renderCellTemplateForItem(e,t){for(let a of this._getCellTemplates(e))fa.mostRecentCellOutlet&&fa.mostRecentCellOutlet._viewContainer.createEmbeddedView(a,t);this._changeDetectorRef.markForCheck()}_updateRowIndexContext(){let e=this._rowOutlet.viewContainer;for(let t=0,a=e.length;t<a;t++){let c=e.get(t).context;c.count=a,c.first=t===0,c.last=t===a-1,c.even=t%2===0,c.odd=!c.even,this.multiTemplateDataRows?(c.dataIndex=this._renderRows[t].dataIndex,c.renderIndex=t):c.index=this._renderRows[t].dataIndex}}_getCellTemplates(e){return!e||!e.columns?[]:Array.from(e.columns,t=>{let a=this._columnDefsByName.get(t);return e.extractCellTemplate(a)})}_forceRenderDataRows(){this._dataDiffer.diff([]),this._rowOutlet.viewContainer.clear(),this.renderRows()}_checkStickyStates(){let e=(t,a)=>t||a.hasStickyChanged();this._headerRowDefs.reduce(e,!1)&&this.updateStickyHeaderRowStyles(),this._footerRowDefs.reduce(e,!1)&&this.updateStickyFooterRowStyles(),Array.from(this._columnDefsByName.values()).reduce(e,!1)&&(this._stickyColumnStylesNeedReset=!0,this.updateStickyColumnStyles())}_setupStickyStyler(){let e=this._dir?this._dir.value:"ltr",t=this._injector;this._stickyStyler=new Xu(this._isNativeHtmlTable,this.stickyCssClass,this._platform.isBrowser,this.needsPositionStickyOnElement,e,this,t),(this._dir?this._dir.change:K()).pipe(pe(this._onDestroy)).subscribe(a=>{this._stickyStyler.direction=a,this.updateStickyColumnStyles()})}_setupVirtualScrolling(e){let t=typeof requestAnimationFrame<"u"?Ll:Nl;this.viewChange.next({start:0,end:0}),e.renderedRangeStream.pipe(So(0,t),pe(this._onDestroy)).subscribe(this.viewChange),e.attach({dataStream:this._dataStream,measureRangeSize:(a,o)=>this._measureRangeSize(a,o)}),nn([e.renderedContentOffset,this._headerRowStickyUpdates]).pipe(pe(this._onDestroy)).subscribe(([a,o])=>{if(!(!o.sizes||!o.offsets||!o.elements))for(let c=0;c<o.elements.length;c++){let u=o.elements[c];if(u){let p=o.offsets[c],f=a!==0?Math.max(a-p,p):-p;for(let b of u)b.style.top=`${-f}px`}}}),nn([e.renderedContentOffset,this._footerRowStickyUpdates]).pipe(pe(this._onDestroy)).subscribe(([a,o])=>{if(!(!o.sizes||!o.offsets||!o.elements))for(let c=0;c<o.elements.length;c++){let u=o.elements[c];if(u)for(let p of u)p.style.bottom=`${a+o.offsets[c]}px`}})}_getOwnDefs(e){return e.filter(t=>!t._table||t._table===this)}_updateNoDataRow(){let e=this._customNoDataRow||this._noDataRow;if(!e)return;let t=this._rowOutlet.viewContainer.length===0;if(t===this._isShowingNoDataRow)return;let a=this._noDataRowOutlet.viewContainer;if(t){let o=a.createEmbeddedView(e.templateRef),c=o.rootNodes[0];if(o.rootNodes.length===1&&c?.nodeType===this._document.ELEMENT_NODE){c.setAttribute("role","row"),c.classList.add(...e._contentClassNames);let u=c.querySelectorAll(e._cellSelector);for(let p=0;p<u.length;p++)u[p].classList.add(...e._cellClassNames)}}else a.clear();this._isShowingNoDataRow=t,this._changeDetectorRef.markForCheck()}_measureRangeSize(e,t){if(e.start>=e.end||t!=="vertical")return 0;let a=this.viewChange.value,o=this._rowOutlet.viewContainer;e.start<a.start||e.end>a.end;let c=e.start-a.start,u=e.end-e.start,p,f;for(let L=0;L<u;L++){let $=o.get(L+c);if($&&$.rootNodes.length){p=f=$.rootNodes[0];break}}for(let L=u-1;L>-1;L--){let $=o.get(L+c);if($&&$.rootNodes.length){f=$.rootNodes[$.rootNodes.length-1];break}}let b=p?.getBoundingClientRect?.(),w=f?.getBoundingClientRect?.();return b&&w?w.bottom-b.top:0}_virtualScrollEnabled(){return!this._disableVirtualScrolling&&this._virtualScrollViewport!=null}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["cdk-table"],["table","cdk-table",""]],contentQueries:function(t,a,o){if(t&1&&st(o,D_,5)(o,ho,5)(o,rl,5)(o,Gr,5)(o,Zu,5),t&2){let c;j(c=V())&&(a._noDataRow=c.first),j(c=V())&&(a._contentColumnDefs=c),j(c=V())&&(a._contentRowDefs=c),j(c=V())&&(a._contentHeaderRowDefs=c),j(c=V())&&(a._contentFooterRowDefs=c)}},hostAttrs:[1,"cdk-table"],hostVars:2,hostBindings:function(t,a){t&2&&k("cdk-table-fixed-layout",a.fixedLayout)},inputs:{trackBy:"trackBy",dataSource:"dataSource",multiTemplateDataRows:[2,"multiTemplateDataRows","multiTemplateDataRows",R],fixedLayout:[2,"fixedLayout","fixedLayout",R],recycleRows:[2,"recycleRows","recycleRows",R]},outputs:{contentChanged:"contentChanged"},exportAs:["cdkTable"],features:[ce([{provide:kn,useExisting:n},{provide:$r,useValue:null}])],ngContentSelectors:Ww,decls:5,vars:2,consts:[["role","rowgroup"],["headerRowOutlet",""],["rowOutlet",""],["noDataRowOutlet",""],["footerRowOutlet",""]],template:function(t,a){t&1&&(ye(qw),ee(0),ee(1,1),v(2,Qw,1,0),v(3,Yw,7,0)(4,Xw,4,0)),t&2&&(d(2),y(a._isServer?2:-1),d(),y(a._isNativeHtmlTable?3:4))},dependencies:[nm,tm,am,im],styles:[`.cdk-table-fixed-layout {
  table-layout: fixed;
}
`],encapsulation:2})}return n})();function nl(n,i){return n.concat(Array.from(i))}function y_(n,i){let e=i.toUpperCase(),t=n.viewContainer.element.nativeElement;for(;t;){let a=t.nodeType===1?t.nodeName:null;if(a===e)return t;if(a==="TABLE")break;t=t.parentNode}return null}var E_=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[Br]})}return n})();var Zw=[[["caption"]],[["colgroup"],["col"]],"*"],Jw=["caption","colgroup, col","*"];function e1(n,i){n&1&&ee(0,2)}function t1(n,i){n&1&&(s(0,"thead",0),ot(1,1),r(),s(2,"tbody",2),ot(3,3)(4,4),r(),s(5,"tfoot",0),ot(6,5),r())}function n1(n,i){n&1&&ot(0,1)(1,3)(2,4)(3,5)}var S_=(()=>{class n extends om{stickyCssClass="mat-mdc-table-sticky";needsPositionStickyOnElement=!1;static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275cmp=A({type:n,selectors:[["mat-table"],["table","mat-table",""]],hostAttrs:[1,"mat-mdc-table","mdc-data-table__table"],hostVars:2,hostBindings:function(t,a){t&2&&k("mat-table-fixed-layout",a.fixedLayout)},exportAs:["matTable"],features:[ce([{provide:om,useExisting:n},{provide:kn,useExisting:n},{provide:$r,useValue:null}]),ie],ngContentSelectors:Jw,decls:5,vars:2,consts:[["role","rowgroup"],["headerRowOutlet",""],["role","rowgroup",1,"mdc-data-table__content"],["rowOutlet",""],["noDataRowOutlet",""],["footerRowOutlet",""]],template:function(t,a){t&1&&(ye(Zw),ee(0),ee(1,1),v(2,e1,1,0),v(3,t1,7,0)(4,n1,4,0)),t&2&&(d(2),y(a._isServer?2:-1),d(),y(a._isNativeHtmlTable?3:4))},dependencies:[nm,tm,am,im],styles:[`.mat-mdc-table-sticky {
  position: sticky !important;
}

mat-table {
  display: block;
}

mat-header-row {
  min-height: var(--mat-table-header-container-height, 56px);
}

mat-row {
  min-height: var(--mat-table-row-item-container-height, 52px);
}

mat-footer-row {
  min-height: var(--mat-table-footer-container-height, 52px);
}

mat-row, mat-header-row, mat-footer-row {
  display: flex;
  border-width: 0;
  border-bottom-width: 1px;
  border-style: solid;
  align-items: center;
  box-sizing: border-box;
}

mat-cell:first-of-type, mat-header-cell:first-of-type, mat-footer-cell:first-of-type {
  padding-left: 24px;
}
[dir=rtl] mat-cell:first-of-type:not(:only-of-type), [dir=rtl] mat-header-cell:first-of-type:not(:only-of-type), [dir=rtl] mat-footer-cell:first-of-type:not(:only-of-type) {
  padding-left: 0;
  padding-right: 24px;
}
mat-cell:last-of-type, mat-header-cell:last-of-type, mat-footer-cell:last-of-type {
  padding-right: 24px;
}
[dir=rtl] mat-cell:last-of-type:not(:only-of-type), [dir=rtl] mat-header-cell:last-of-type:not(:only-of-type), [dir=rtl] mat-footer-cell:last-of-type:not(:only-of-type) {
  padding-right: 0;
  padding-left: 24px;
}

mat-cell, mat-header-cell, mat-footer-cell {
  flex: 1;
  display: flex;
  align-items: center;
  overflow: hidden;
  word-wrap: break-word;
  min-height: inherit;
}

.mat-mdc-table {
  min-width: 100%;
  border: 0;
  border-spacing: 0;
  table-layout: auto;
  white-space: normal;
  background-color: var(--mat-table-background-color, var(--mat-sys-surface));
}

.mat-table-fixed-layout {
  table-layout: fixed;
}

.mdc-data-table__cell {
  box-sizing: border-box;
  overflow: hidden;
  text-align: start;
  text-overflow: ellipsis;
}

.mdc-data-table__cell,
.mdc-data-table__header-cell {
  padding: 0 16px;
}

.mat-mdc-header-row {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  height: var(--mat-table-header-container-height, 56px);
  color: var(--mat-table-header-headline-color, var(--mat-sys-on-surface, rgba(0, 0, 0, 0.87)));
  font-family: var(--mat-table-header-headline-font, var(--mat-sys-title-small-font, Roboto, sans-serif));
  line-height: var(--mat-table-header-headline-line-height, var(--mat-sys-title-small-line-height));
  font-size: var(--mat-table-header-headline-size, var(--mat-sys-title-small-size, 14px));
  font-weight: var(--mat-table-header-headline-weight, var(--mat-sys-title-small-weight, 500));
}

.mat-mdc-row {
  height: var(--mat-table-row-item-container-height, 52px);
  color: var(--mat-table-row-item-label-text-color, var(--mat-sys-on-surface, rgba(0, 0, 0, 0.87)));
}

.mat-mdc-row,
.mdc-data-table__content {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  font-family: var(--mat-table-row-item-label-text-font, var(--mat-sys-body-medium-font, Roboto, sans-serif));
  line-height: var(--mat-table-row-item-label-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-table-row-item-label-text-size, var(--mat-sys-body-medium-size, 14px));
  font-weight: var(--mat-table-row-item-label-text-weight, var(--mat-sys-body-medium-weight));
}

.mat-mdc-footer-row {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  height: var(--mat-table-footer-container-height, 52px);
  color: var(--mat-table-row-item-label-text-color, var(--mat-sys-on-surface, rgba(0, 0, 0, 0.87)));
  font-family: var(--mat-table-footer-supporting-text-font, var(--mat-sys-body-medium-font, Roboto, sans-serif));
  line-height: var(--mat-table-footer-supporting-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-table-footer-supporting-text-size, var(--mat-sys-body-medium-size, 14px));
  font-weight: var(--mat-table-footer-supporting-text-weight, var(--mat-sys-body-medium-weight));
  letter-spacing: var(--mat-table-footer-supporting-text-tracking, var(--mat-sys-body-medium-tracking));
}

.mat-mdc-header-cell {
  border-bottom-color: var(--mat-table-row-item-outline-color, var(--mat-sys-outline, rgba(0, 0, 0, 0.12)));
  border-bottom-width: var(--mat-table-row-item-outline-width, 1px);
  border-bottom-style: solid;
  letter-spacing: var(--mat-table-header-headline-tracking, var(--mat-sys-title-small-tracking));
  font-weight: inherit;
  line-height: inherit;
  box-sizing: border-box;
  text-overflow: ellipsis;
  overflow: hidden;
  outline: none;
  text-align: start;
}
.mdc-data-table__row:last-child > .mat-mdc-header-cell {
  border-bottom: none;
}

.mat-mdc-cell {
  border-bottom-color: var(--mat-table-row-item-outline-color, var(--mat-sys-outline, rgba(0, 0, 0, 0.12)));
  border-bottom-width: var(--mat-table-row-item-outline-width, 1px);
  border-bottom-style: solid;
  letter-spacing: var(--mat-table-row-item-label-text-tracking, var(--mat-sys-body-medium-tracking));
  line-height: inherit;
}
.mdc-data-table__row:last-child > .mat-mdc-cell {
  border-bottom: none;
}

.mat-mdc-footer-cell {
  letter-spacing: var(--mat-table-row-item-label-text-tracking, var(--mat-sys-body-medium-tracking));
}

mat-row.mat-mdc-row,
mat-header-row.mat-mdc-header-row,
mat-footer-row.mat-mdc-footer-row {
  border-bottom: none;
}

.mat-mdc-table tbody,
.mat-mdc-table tfoot,
.mat-mdc-table thead,
.mat-mdc-cell,
.mat-mdc-footer-cell,
.mat-mdc-header-row,
.mat-mdc-row,
.mat-mdc-footer-row,
.mat-mdc-table .mat-mdc-header-cell {
  background: inherit;
}

.mat-mdc-table mat-header-row.mat-mdc-header-row,
.mat-mdc-table mat-row.mat-mdc-row,
.mat-mdc-table mat-footer-row.mat-mdc-footer-cell {
  height: unset;
}

mat-header-cell.mat-mdc-header-cell,
mat-cell.mat-mdc-cell,
mat-footer-cell.mat-mdc-footer-cell {
  align-self: stretch;
}
`],encapsulation:2})}return n})(),k_=(()=>{class n extends al{static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["","matCellDef",""]],features:[ce([{provide:al,useExisting:n}]),ie]})}return n})(),M_=(()=>{class n extends ol{static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["","matHeaderCellDef",""]],features:[ce([{provide:ol,useExisting:n}]),ie]})}return n})();var I_=(()=>{class n extends ho{get name(){return this._name}set name(e){this._setNameInput(e)}_updateColumnCssClassName(){super._updateColumnCssClassName(),this._columnCssClassName.push(`mat-column-${this.cssClassFriendlyName}`)}static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["","matColumnDef",""]],inputs:{name:[0,"matColumnDef","name"]},features:[ce([{provide:ho,useExisting:n}]),ie]})}return n})(),A_=(()=>{class n extends C_{static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["mat-header-cell"],["th","mat-header-cell",""]],hostAttrs:["role","columnheader",1,"mat-mdc-header-cell","mdc-data-table__header-cell"],features:[ie]})}return n})();var R_=(()=>{class n extends w_{static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["mat-cell"],["td","mat-cell",""]],hostAttrs:[1,"mat-mdc-cell","mdc-data-table__cell"],features:[ie]})}return n})();var T_=(()=>{class n extends Gr{static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["","matHeaderRowDef",""]],inputs:{columns:[0,"matHeaderRowDef","columns"],sticky:[2,"matHeaderRowDefSticky","sticky",R]},features:[ce([{provide:Gr,useExisting:n}]),ie]})}return n})();var O_=(()=>{class n extends rl{static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["","matRowDef",""]],inputs:{columns:[0,"matRowDefColumns","columns"],when:[0,"matRowDefWhen","when"]},features:[ce([{provide:rl,useExisting:n}]),ie]})}return n})(),P_=(()=>{class n extends Ju{static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275cmp=A({type:n,selectors:[["mat-header-row"],["tr","mat-header-row",""]],hostAttrs:["role","row",1,"mat-mdc-header-row","mdc-data-table__header-row"],exportAs:["matHeaderRow"],features:[ce([{provide:Ju,useExisting:n}]),ie],decls:1,vars:0,consts:[["cdkCellOutlet",""]],template:function(t,a){t&1&&ot(0,0)},dependencies:[fa],encapsulation:2})}return n})();var F_=(()=>{class n extends em{static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275cmp=A({type:n,selectors:[["mat-row"],["tr","mat-row",""]],hostAttrs:["role","row",1,"mat-mdc-row","mdc-data-table__row"],exportAs:["matRow"],features:[ce([{provide:em,useExisting:n}]),ie],decls:1,vars:0,consts:[["cdkCellOutlet",""]],template:function(t,a){t&1&&ot(0,0)},dependencies:[fa],encapsulation:2})}return n})();var N_=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[E_,de]})}return n})(),i1=9007199254740991,sl=class extends Pr{_data;_renderData=new et([]);_filter=new et("");_internalPageChanges=new F;_renderChangesSubscription=null;filteredData;get data(){return this._data.value}set data(i){i=Array.isArray(i)?i:[],this._data.next(i),this._renderChangesSubscription||this._filterData(i)}get filter(){return this._filter.value}set filter(i){this._filter.next(i),this._renderChangesSubscription||this._filterData(this.data)}get sort(){return this._sort}set sort(i){this._sort=i,this._updateChangeSubscription()}_sort;get paginator(){return this._paginator}set paginator(i){this._paginator=i,this._updateChangeSubscription()}_paginator;sortingDataAccessor=(i,e)=>{let t=i[e];if(tc(t)){let a=Number(t);return a<i1?a:t}return t};sortData=(i,e)=>{let t=e.active,a=e.direction;return!t||a==""?i:i.sort((o,c)=>{let u=this.sortingDataAccessor(o,t),p=this.sortingDataAccessor(c,t),f=typeof u,b=typeof p;f!==b&&(f==="number"&&(u+=""),b==="number"&&(p+=""));let w=0;return u!=null&&p!=null?u>p?w=1:u<p&&(w=-1):u!=null?w=1:p!=null&&(w=-1),w*(a=="asc"?1:-1)})};filterPredicate=(i,e)=>{let t=e.trim().toLowerCase();return Object.values(i).some(a=>`${a}`.toLowerCase().includes(t))};constructor(i=[]){super(),this._data=new et(i),this._updateChangeSubscription()}_updateChangeSubscription(){let i=this._sort?ut(this._sort.sortChange,this._sort.initialized):K(null),e=this._paginator?ut(this._paginator.page,this._internalPageChanges,this._paginator.initialized):K(null),t=this._data,a=nn([t,this._filter]).pipe(Q(([u])=>this._filterData(u))),o=nn([a,i]).pipe(Q(([u])=>this._orderData(u))),c=nn([o,e]).pipe(Q(([u])=>this._pageData(u)));this._renderChangesSubscription?.unsubscribe(),this._renderChangesSubscription=c.subscribe(u=>this._renderData.next(u))}_filterData(i){return this.filteredData=this.filter==null||this.filter===""?i:i.filter(e=>this.filterPredicate(e,this.filter)),this.paginator&&this._updatePaginator(this.filteredData.length),this.filteredData}_orderData(i){return this.sort?this.sortData(i.slice(),this.sort):i}_pageData(i){if(!this.paginator)return i;let e=this.paginator.pageIndex*this.paginator.pageSize;return i.slice(e,e+this.paginator.pageSize)}_updatePaginator(i){Promise.resolve().then(()=>{let e=this.paginator;if(e&&(e.length=i,e.pageIndex>0)){let t=Math.ceil(e.length/e.pageSize)-1||0,a=Math.min(e.pageIndex,t);a!==e.pageIndex&&(e.pageIndex=a,this._internalPageChanges.next())}})}connect(){return this._renderChangesSubscription||this._updateChangeSubscription(),this._renderData}disconnect(){this._renderChangesSubscription?.unsubscribe(),this._renderChangesSubscription=null}};var o1=["tooltip"],r1=20;var s1=new E("mat-tooltip-scroll-strategy",{providedIn:"root",factory:()=>{let n=m(re);return()=>pa(n,{scrollThrottle:r1})}}),c1=new E("mat-tooltip-default-options",{providedIn:"root",factory:()=>({showDelay:0,hideDelay:0,touchendHideDelay:1500})});var L_="tooltip-panel",l1={passive:!0},d1=8,u1=8,m1=24,p1=200,qr=(()=>{class n{_elementRef=m(B);_ngZone=m(W);_platform=m(be);_ariaDescriber=m(If);_focusMonitor=m(Dt);_dir=m(Qe);_injector=m(re);_viewContainerRef=m(Xe);_mediaMatcher=m(Ya);_document=m(X);_renderer=m(Se);_animationsDisabled=Ee();_defaultOptions=m(c1,{optional:!0});_overlayRef=null;_tooltipInstance=null;_overlayPanelClass;_portal;_position="below";_positionAtOrigin=!1;_disabled=!1;_tooltipClass;_viewInitialized=!1;_pointerExitEventsInitialized=!1;_tooltipComponent=B_;_viewportMargin=8;_currentPosition;_cssClassPrefix="mat-mdc";_ariaDescriptionPending=!1;_dirSubscribed=!1;get position(){return this._position}set position(e){e!==this._position&&(this._position=e,this._overlayRef&&(this._updatePosition(this._overlayRef),this._tooltipInstance?.show(0),this._overlayRef.updatePosition()))}get positionAtOrigin(){return this._positionAtOrigin}set positionAtOrigin(e){this._positionAtOrigin=ni(e),this._detach(),this._overlayRef=null}get disabled(){return this._disabled}set disabled(e){let t=ni(e);this._disabled!==t&&(this._disabled=t,t?this.hide(0):this._setupPointerEnterEventsIfNeeded(),this._syncAriaDescription(this.message))}get showDelay(){return this._showDelay}set showDelay(e){this._showDelay=vn(e)}_showDelay;get hideDelay(){return this._hideDelay}set hideDelay(e){this._hideDelay=vn(e),this._tooltipInstance&&(this._tooltipInstance._mouseLeaveHideDelay=this._hideDelay)}_hideDelay;touchGestures="auto";get message(){return this._message}set message(e){let t=this._message;this._message=e!=null?String(e).trim():"",!this._message&&this._isTooltipVisible()?this.hide(0):(this._setupPointerEnterEventsIfNeeded(),this._updateTooltipMessage()),this._syncAriaDescription(t)}_message="";get tooltipClass(){return this._tooltipClass}set tooltipClass(e){this._tooltipClass=e,this._tooltipInstance&&this._setTooltipClass(this._tooltipClass)}_eventCleanups=[];_touchstartTimeout=null;_destroyed=new F;_isDestroyed=!1;constructor(){let e=this._defaultOptions;e&&(this._showDelay=e.showDelay,this._hideDelay=e.hideDelay,e.position&&(this.position=e.position),e.positionAtOrigin&&(this.positionAtOrigin=e.positionAtOrigin),e.touchGestures&&(this.touchGestures=e.touchGestures),e.tooltipClass&&(this.tooltipClass=e.tooltipClass)),this._viewportMargin=d1}ngAfterViewInit(){this._viewInitialized=!0,this._setupPointerEnterEventsIfNeeded(),this._focusMonitor.monitor(this._elementRef).pipe(pe(this._destroyed)).subscribe(e=>{e?e==="keyboard"&&this._ngZone.run(()=>this.show()):this._ngZone.run(()=>this.hide(0))})}ngOnDestroy(){let e=this._elementRef.nativeElement;this._touchstartTimeout&&clearTimeout(this._touchstartTimeout),this._overlayRef&&(this._overlayRef.dispose(),this._tooltipInstance=null),this._eventCleanups.forEach(t=>t()),this._eventCleanups.length=0,this._destroyed.next(),this._destroyed.complete(),this._isDestroyed=!0,this._ariaDescriber.removeDescription(e,this.message,"tooltip"),this._focusMonitor.stopMonitoring(e)}show(e=this.showDelay,t){if(this.disabled||!this.message||this._isTooltipVisible()){this._tooltipInstance?._cancelPendingAnimations();return}let a=this._createOverlay(t);this._detach(),this._portal=this._portal||new Dn(this._tooltipComponent,this._viewContainerRef);let o=this._tooltipInstance=a.attach(this._portal).instance;o._triggerElement=this._elementRef.nativeElement,o._mouseLeaveHideDelay=this._hideDelay,o.afterHidden().pipe(pe(this._destroyed)).subscribe(()=>this._detach()),this._setTooltipClass(this._tooltipClass),this._updateTooltipMessage(),o.show(e)}hide(e=this.hideDelay){let t=this._tooltipInstance;t&&(t.isVisible()?t.hide(e):(t._cancelPendingAnimations(),this._detach()))}toggle(e){this._isTooltipVisible()?this.hide():this.show(void 0,e)}_isTooltipVisible(){return!!this._tooltipInstance&&this._tooltipInstance.isVisible()}_createOverlay(e){if(this._overlayRef){let c=this._overlayRef.getConfig().positionStrategy;if((!this.positionAtOrigin||!e)&&c._origin instanceof B)return this._overlayRef;this._detach()}let t=this._injector.get(da).getAncestorScrollContainers(this._elementRef),a=`${this._cssClassPrefix}-${L_}`,o=zr(this._injector,this.positionAtOrigin?e||this._elementRef:this._elementRef).withTransformOriginOn(`.${this._cssClassPrefix}-tooltip`).withFlexibleDimensions(!1).withViewportMargin(this._viewportMargin).withScrollableContainers(t).withPopoverLocation("global");return o.positionChanges.pipe(pe(this._destroyed)).subscribe(c=>{this._updateCurrentPositionClass(c.connectionPair),this._tooltipInstance&&c.scrollableViewProperties.isOverlayClipped&&this._tooltipInstance.isVisible()&&this._ngZone.run(()=>this.hide(0))}),this._overlayRef=si(this._injector,{direction:this._dir,positionStrategy:o,panelClass:this._overlayPanelClass?[...this._overlayPanelClass,a]:a,scrollStrategy:this._injector.get(s1)(),disableAnimations:this._animationsDisabled,eventPredicate:this._overlayEventPredicate}),this._updatePosition(this._overlayRef),this._overlayRef.detachments().pipe(pe(this._destroyed)).subscribe(()=>this._detach()),this._overlayRef.outsidePointerEvents().pipe(pe(this._destroyed)).subscribe(()=>this._tooltipInstance?._handleBodyInteraction()),this._overlayRef.keydownEvents().pipe(pe(this._destroyed)).subscribe(c=>{c.preventDefault(),c.stopPropagation(),this._ngZone.run(()=>this.hide(0))}),this._defaultOptions?.disableTooltipInteractivity&&this._overlayRef.addPanelClass(`${this._cssClassPrefix}-tooltip-panel-non-interactive`),this._dirSubscribed||(this._dirSubscribed=!0,this._dir.change.pipe(pe(this._destroyed)).subscribe(()=>{this._overlayRef&&this._updatePosition(this._overlayRef)})),this._overlayRef}_detach(){this._overlayRef&&this._overlayRef.hasAttached()&&this._overlayRef.detach(),this._tooltipInstance=null}_updatePosition(e){let t=e.getConfig().positionStrategy,a=this._getOrigin(),o=this._getOverlayPosition();t.withPositions([this._addOffset(M(M({},a.main),o.main)),this._addOffset(M(M({},a.fallback),o.fallback))])}_addOffset(e){let t=u1,a=!this._dir||this._dir.value=="ltr";return e.originY==="top"?e.offsetY=-t:e.originY==="bottom"?e.offsetY=t:e.originX==="start"?e.offsetX=a?-t:t:e.originX==="end"&&(e.offsetX=a?t:-t),e}_getOrigin(){let e=!this._dir||this._dir.value=="ltr",t=this.position,a;t=="above"||t=="below"?a={originX:"center",originY:t=="above"?"top":"bottom"}:t=="before"||t=="left"&&e||t=="right"&&!e?a={originX:"start",originY:"center"}:(t=="after"||t=="right"&&e||t=="left"&&!e)&&(a={originX:"end",originY:"center"});let{x:o,y:c}=this._invertPosition(a.originX,a.originY);return{main:a,fallback:{originX:o,originY:c}}}_getOverlayPosition(){let e=!this._dir||this._dir.value=="ltr",t=this.position,a;t=="above"?a={overlayX:"center",overlayY:"bottom"}:t=="below"?a={overlayX:"center",overlayY:"top"}:t=="before"||t=="left"&&e||t=="right"&&!e?a={overlayX:"end",overlayY:"center"}:(t=="after"||t=="right"&&e||t=="left"&&!e)&&(a={overlayX:"start",overlayY:"center"});let{x:o,y:c}=this._invertPosition(a.overlayX,a.overlayY);return{main:a,fallback:{overlayX:o,overlayY:c}}}_updateTooltipMessage(){this._tooltipInstance&&(this._tooltipInstance.message=this.message,this._tooltipInstance._markForCheck(),Pe(()=>{this._tooltipInstance&&this._overlayRef.updatePosition()},{injector:this._injector}))}_setTooltipClass(e){this._tooltipInstance&&(this._tooltipInstance.tooltipClass=e instanceof Set?Array.from(e):e,this._tooltipInstance._markForCheck())}_invertPosition(e,t){return this.position==="above"||this.position==="below"?t==="top"?t="bottom":t==="bottom"&&(t="top"):e==="end"?e="start":e==="start"&&(e="end"),{x:e,y:t}}_updateCurrentPositionClass(e){let{overlayY:t,originX:a,originY:o}=e,c;if(t==="center"?this._dir&&this._dir.value==="rtl"?c=a==="end"?"left":"right":c=a==="start"?"left":"right":c=t==="bottom"&&o==="top"?"above":"below",c!==this._currentPosition){let u=this._overlayRef;if(u){let p=`${this._cssClassPrefix}-${L_}-`;u.removePanelClass(p+this._currentPosition),u.addPanelClass(p+c)}this._currentPosition=c}}_setupPointerEnterEventsIfNeeded(){this._disabled||!this.message||!this._viewInitialized||this._eventCleanups.length||(this._isTouchPlatform()?this.touchGestures!=="off"&&(this._disableNativeGesturesIfNecessary(),this._addListener("touchstart",e=>{let t=e.targetTouches?.[0],a=t?{x:t.clientX,y:t.clientY}:void 0;this._setupPointerExitEventsIfNeeded(),this._touchstartTimeout&&clearTimeout(this._touchstartTimeout);let o=500;this._touchstartTimeout=setTimeout(()=>{this._touchstartTimeout=null,this.show(void 0,a)},this._defaultOptions?.touchLongPressShowDelay??o)})):this._addListener("mouseenter",e=>{this._setupPointerExitEventsIfNeeded();let t;e.x!==void 0&&e.y!==void 0&&(t=e),this.show(void 0,t)}))}_setupPointerExitEventsIfNeeded(){if(!this._pointerExitEventsInitialized){if(this._pointerExitEventsInitialized=!0,!this._isTouchPlatform())this._addListener("mouseleave",e=>{let t=e.relatedTarget;(!t||!this._overlayRef?.overlayElement.contains(t))&&this.hide()}),this._addListener("wheel",e=>{if(this._isTooltipVisible()){let t=this._document.elementFromPoint(e.clientX,e.clientY),a=this._elementRef.nativeElement;t!==a&&!a.contains(t)&&this.hide()}});else if(this.touchGestures!=="off"){this._disableNativeGesturesIfNecessary();let e=()=>{this._touchstartTimeout&&clearTimeout(this._touchstartTimeout),this.hide(this._defaultOptions?.touchendHideDelay)};this._addListener("touchend",e),this._addListener("touchcancel",e)}}}_addListener(e,t){this._eventCleanups.push(this._renderer.listen(this._elementRef.nativeElement,e,t,l1))}_isTouchPlatform(){let e=this._defaultOptions?.detectHoverCapability;return typeof e=="function"?!e():this._platform.IOS||this._platform.ANDROID?!0:this._platform.isBrowser?!!e&&this._mediaMatcher.matchMedia("(any-hover: none)").matches:!1}_disableNativeGesturesIfNecessary(){let e=this.touchGestures;if(e!=="off"){let t=this._elementRef.nativeElement,a=t.style;(e==="on"||t.nodeName!=="INPUT"&&t.nodeName!=="TEXTAREA")&&(a.userSelect=a.msUserSelect=a.webkitUserSelect=a.MozUserSelect="none"),(e==="on"||!t.draggable)&&(a.webkitUserDrag="none"),a.touchAction="none",a.webkitTapHighlightColor="transparent"}}_syncAriaDescription(e){this._ariaDescriptionPending||(this._ariaDescriptionPending=!0,this._ariaDescriber.removeDescription(this._elementRef.nativeElement,e,"tooltip"),this._isDestroyed||Pe({write:()=>{this._ariaDescriptionPending=!1,this.message&&!this.disabled&&this._ariaDescriber.describe(this._elementRef.nativeElement,this.message,"tooltip")}},{injector:this._injector}))}_overlayEventPredicate=e=>e.type==="keydown"?this._isTooltipVisible()&&e.keyCode===27&&!Ze(e):!0;static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","matTooltip",""]],hostAttrs:[1,"mat-mdc-tooltip-trigger"],hostVars:2,hostBindings:function(t,a){t&2&&k("mat-mdc-tooltip-disabled",a.disabled)},inputs:{position:[0,"matTooltipPosition","position"],positionAtOrigin:[0,"matTooltipPositionAtOrigin","positionAtOrigin"],disabled:[0,"matTooltipDisabled","disabled"],showDelay:[0,"matTooltipShowDelay","showDelay"],hideDelay:[0,"matTooltipHideDelay","hideDelay"],touchGestures:[0,"matTooltipTouchGestures","touchGestures"],message:[0,"matTooltip","message"],tooltipClass:[0,"matTooltipClass","tooltipClass"]},exportAs:["matTooltip"]})}return n})(),B_=(()=>{class n{_changeDetectorRef=m(Z);_elementRef=m(B);_isMultiline=!1;message;tooltipClass;_showTimeoutId;_hideTimeoutId;_triggerElement;_mouseLeaveHideDelay;_animationsDisabled=Ee();_tooltip;_closeOnInteraction=!1;_isVisible=!1;_onHide=new F;_showAnimation="mat-mdc-tooltip-show";_hideAnimation="mat-mdc-tooltip-hide";constructor(){}show(e){this._hideTimeoutId!=null&&clearTimeout(this._hideTimeoutId),this._showTimeoutId=setTimeout(()=>{this._toggleVisibility(!0),this._showTimeoutId=void 0},e)}hide(e){this._showTimeoutId!=null&&clearTimeout(this._showTimeoutId),this._hideTimeoutId=setTimeout(()=>{this._toggleVisibility(!1),this._hideTimeoutId=void 0},e)}afterHidden(){return this._onHide}isVisible(){return this._isVisible}ngOnDestroy(){this._cancelPendingAnimations(),this._onHide.complete(),this._triggerElement=null}_handleBodyInteraction(){this._closeOnInteraction&&this.hide(0)}_markForCheck(){this._changeDetectorRef.markForCheck()}_handleMouseLeave({relatedTarget:e}){(!e||!this._triggerElement.contains(e))&&(this.isVisible()?this.hide(this._mouseLeaveHideDelay):this._finalizeAnimation(!1))}_onShow(){this._isMultiline=this._isTooltipMultiline(),this._markForCheck()}_isTooltipMultiline(){let e=this._elementRef.nativeElement.getBoundingClientRect();return e.height>m1&&e.width>=p1}_handleAnimationEnd({animationName:e}){(e===this._showAnimation||e===this._hideAnimation)&&this._finalizeAnimation(e===this._showAnimation)}_cancelPendingAnimations(){this._showTimeoutId!=null&&clearTimeout(this._showTimeoutId),this._hideTimeoutId!=null&&clearTimeout(this._hideTimeoutId),this._showTimeoutId=this._hideTimeoutId=void 0}_finalizeAnimation(e){e?this._closeOnInteraction=!0:this.isVisible()||this._onHide.next()}_toggleVisibility(e){let t=this._tooltip.nativeElement,a=this._showAnimation,o=this._hideAnimation;if(t.classList.remove(e?o:a),t.classList.add(e?a:o),this._isVisible!==e&&(this._isVisible=e,this._changeDetectorRef.markForCheck()),e&&!this._animationsDisabled&&typeof getComputedStyle=="function"){let c=getComputedStyle(t);(c.getPropertyValue("animation-duration")==="0s"||c.getPropertyValue("animation-name")==="none")&&(this._animationsDisabled=!0)}e&&this._onShow(),this._animationsDisabled&&(t.classList.add("_mat-animation-noopable"),this._finalizeAnimation(e))}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-tooltip-component"]],viewQuery:function(t,a){if(t&1&&Ae(o1,7),t&2){let o;j(o=V())&&(a._tooltip=o.first)}},hostAttrs:["aria-hidden","true"],hostBindings:function(t,a){t&1&&_("mouseleave",function(c){return a._handleMouseLeave(c)})},decls:4,vars:5,consts:[["tooltip",""],[1,"mdc-tooltip","mat-mdc-tooltip",3,"animationend"],[1,"mat-mdc-tooltip-surface","mdc-tooltip__surface"]],template:function(t,a){t&1&&(Te(0,"div",1,0),os("animationend",function(c){return a._handleAnimationEnd(c)}),Te(2,"div",2),l(3),Be()()),t&2&&(ve(a.tooltipClass),k("mdc-tooltip--multiline",a._isMultiline),d(3),g(a.message))},styles:[`.mat-mdc-tooltip {
  position: relative;
  transform: scale(0);
  display: inline-flex;
}
.mat-mdc-tooltip::before {
  content: "";
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: -1;
  position: absolute;
}
.mat-mdc-tooltip-panel-below .mat-mdc-tooltip::before {
  top: -8px;
}
.mat-mdc-tooltip-panel-above .mat-mdc-tooltip::before {
  bottom: -8px;
}
.mat-mdc-tooltip-panel-right .mat-mdc-tooltip::before {
  left: -8px;
}
.mat-mdc-tooltip-panel-left .mat-mdc-tooltip::before {
  right: -8px;
}
.mat-mdc-tooltip._mat-animation-noopable {
  animation: none;
  transform: scale(1);
}

.mat-mdc-tooltip-surface {
  word-break: normal;
  overflow-wrap: anywhere;
  padding: 4px 8px;
  min-width: 40px;
  max-width: 200px;
  min-height: 24px;
  max-height: 40vh;
  box-sizing: border-box;
  overflow: hidden;
  text-align: center;
  will-change: transform, opacity;
  background-color: var(--mat-tooltip-container-color, var(--mat-sys-inverse-surface));
  color: var(--mat-tooltip-supporting-text-color, var(--mat-sys-inverse-on-surface));
  border-radius: var(--mat-tooltip-container-shape, var(--mat-sys-corner-extra-small));
  font-family: var(--mat-tooltip-supporting-text-font, var(--mat-sys-body-small-font));
  font-size: var(--mat-tooltip-supporting-text-size, var(--mat-sys-body-small-size));
  font-weight: var(--mat-tooltip-supporting-text-weight, var(--mat-sys-body-small-weight));
  line-height: var(--mat-tooltip-supporting-text-line-height, var(--mat-sys-body-small-line-height));
  letter-spacing: var(--mat-tooltip-supporting-text-tracking, var(--mat-sys-body-small-tracking));
}
.mat-mdc-tooltip-surface::before {
  position: absolute;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  border: 1px solid transparent;
  border-radius: inherit;
  content: "";
  pointer-events: none;
}
.mdc-tooltip--multiline .mat-mdc-tooltip-surface {
  text-align: left;
}
[dir=rtl] .mdc-tooltip--multiline .mat-mdc-tooltip-surface {
  text-align: right;
}

.mat-mdc-tooltip-panel {
  line-height: normal;
}
.mat-mdc-tooltip-panel.mat-mdc-tooltip-panel-non-interactive {
  pointer-events: none;
}

@keyframes mat-mdc-tooltip-show {
  0% {
    opacity: 0;
    transform: scale(0.8);
  }
  100% {
    opacity: 1;
    transform: scale(1);
  }
}
@keyframes mat-mdc-tooltip-hide {
  0% {
    opacity: 1;
    transform: scale(1);
  }
  100% {
    opacity: 0;
    transform: scale(0.8);
  }
}
.mat-mdc-tooltip-show {
  animation: mat-mdc-tooltip-show 150ms cubic-bezier(0, 0, 0.2, 1) forwards;
}

.mat-mdc-tooltip-hide {
  animation: mat-mdc-tooltip-hide 75ms cubic-bezier(0.4, 0, 1, 1) forwards;
}
`],encapsulation:2,changeDetection:0})}return n})();var fo=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[br,Sn,de,la]})}return n})();function h1(n,i){if(n&1){let e=T();s(0,"div",1)(1,"button",2),_("click",function(){x(e);let a=h();return C(a.action())}),l(2),r()()}if(n&2){let e=h();d(2),N(" ",e.data.action," ")}}var f1=["label"];function g1(n,i){}var _1=Math.pow(2,31)-1,Wr=class{_overlayRef;instance;containerInstance;_afterDismissed=new F;_afterOpened=new F;_onAction=new F;_durationTimeoutId;_dismissedByAction=!1;constructor(i,e){this._overlayRef=e,this.containerInstance=i,i._onExit.subscribe(()=>this._finishDismiss())}dismiss(){this._afterDismissed.closed||this.containerInstance.exit(),clearTimeout(this._durationTimeoutId)}dismissWithAction(){this._onAction.closed||(this._dismissedByAction=!0,this._onAction.next(),this._onAction.complete(),this.dismiss()),clearTimeout(this._durationTimeoutId)}closeWithAction(){this.dismissWithAction()}_dismissAfter(i){this._durationTimeoutId=setTimeout(()=>this.dismiss(),Math.min(i,_1))}_open(){this._afterOpened.closed||(this._afterOpened.next(),this._afterOpened.complete())}_finishDismiss(){this._overlayRef.dispose(),this._onAction.closed||this._onAction.complete(),this._afterDismissed.next({dismissedByAction:this._dismissedByAction}),this._afterDismissed.complete(),this._dismissedByAction=!1}afterDismissed(){return this._afterDismissed}afterOpened(){return this.containerInstance._onEnter}onAction(){return this._onAction}},V_=new E("MatSnackBarData"),go=class{politeness="polite";announcementMessage="";viewContainerRef;duration=0;panelClass;direction;data=null;horizontalPosition="center";verticalPosition="bottom"},b1=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","matSnackBarLabel",""]],hostAttrs:[1,"mat-mdc-snack-bar-label","mdc-snackbar__label"]})}return n})(),v1=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","matSnackBarActions",""]],hostAttrs:[1,"mat-mdc-snack-bar-actions","mdc-snackbar__actions"]})}return n})(),y1=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","matSnackBarAction",""]],hostAttrs:[1,"mat-mdc-snack-bar-action","mdc-snackbar__action"]})}return n})(),z_=(()=>{class n{snackBarRef=m(Wr);data=m(V_);constructor(){}action(){this.snackBarRef.dismissWithAction()}get hasAction(){return!!this.data.action}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["simple-snack-bar"]],hostAttrs:[1,"mat-mdc-simple-snack-bar"],exportAs:["matSnackBar"],decls:3,vars:2,consts:[["matSnackBarLabel",""],["matSnackBarActions",""],["matButton","","matSnackBarAction","",3,"click"]],template:function(t,a){t&1&&(s(0,"div",0),l(1),r(),v(2,h1,3,1,"div",1)),t&2&&(d(),N(" ",a.data.message,`
`),d(),y(a.hasAction?2:-1))},dependencies:[Je,b1,v1,y1],styles:[`.mat-mdc-simple-snack-bar {
  display: flex;
}
.mat-mdc-simple-snack-bar .mat-mdc-snack-bar-label {
  max-height: 50vh;
  overflow: auto;
}
`],encapsulation:2,changeDetection:0})}return n})(),rm="_mat-snack-bar-enter",sm="_mat-snack-bar-exit",x1=(()=>{class n extends Fi{_ngZone=m(W);_elementRef=m(B);_changeDetectorRef=m(Z);_platform=m(be);_animationsDisabled=Ee();snackBarConfig=m(go);_document=m(X);_trackedModals=new Set;_enterFallback;_exitFallback;_injector=m(re);_announceDelay=150;_announceTimeoutId;_destroyed=!1;_portalOutlet;_onAnnounce=new F;_onExit=new F;_onEnter=new F;_animationState="void";_live;_label;_role;_liveElementId=m(xe).getId("mat-snack-bar-container-live-");constructor(){super();let e=this.snackBarConfig;e.politeness==="assertive"&&!e.announcementMessage?this._live="assertive":e.politeness==="off"?this._live="off":this._live="polite",this._platform.FIREFOX&&(this._live==="polite"&&(this._role="status"),this._live==="assertive"&&(this._role="alert"))}attachComponentPortal(e){this._assertNotAttached();let t=this._portalOutlet.attachComponentPortal(e);return this._afterPortalAttached(),t}attachTemplatePortal(e){this._assertNotAttached();let t=this._portalOutlet.attachTemplatePortal(e);return this._afterPortalAttached(),t}attachDomPortal=e=>{this._assertNotAttached();let t=this._portalOutlet.attachDomPortal(e);return this._afterPortalAttached(),t};onAnimationEnd(e){e===sm?this._completeExit():e===rm&&(clearTimeout(this._enterFallback),this._ngZone.run(()=>{this._onEnter.next(),this._onEnter.complete()}))}enter(){this._destroyed||(this._animationState="visible",this._changeDetectorRef.markForCheck(),this._changeDetectorRef.detectChanges(),this._screenReaderAnnounce(),this._animationsDisabled?Pe(()=>{this._ngZone.run(()=>queueMicrotask(()=>this.onAnimationEnd(rm)))},{injector:this._injector}):(clearTimeout(this._enterFallback),this._enterFallback=setTimeout(()=>{this._elementRef.nativeElement.classList.add("mat-snack-bar-fallback-visible"),this.onAnimationEnd(rm)},200)))}exit(){return this._destroyed?K(void 0):(this._ngZone.run(()=>{this._animationState="hidden",this._changeDetectorRef.markForCheck(),this._elementRef.nativeElement.setAttribute("mat-exit",""),clearTimeout(this._announceTimeoutId),this._animationsDisabled?Pe(()=>{this._ngZone.run(()=>queueMicrotask(()=>this.onAnimationEnd(sm)))},{injector:this._injector}):(clearTimeout(this._exitFallback),this._exitFallback=setTimeout(()=>this.onAnimationEnd(sm),200))}),this._onExit)}ngOnDestroy(){this._destroyed=!0,this._clearFromModals(),this._completeExit()}_completeExit(){clearTimeout(this._exitFallback),queueMicrotask(()=>{this._onExit.next(),this._onExit.complete()})}_afterPortalAttached(){let e=this._elementRef.nativeElement,t=this.snackBarConfig.panelClass;t&&(Array.isArray(t)?t.forEach(c=>e.classList.add(c)):e.classList.add(t)),this._exposeToModals();let a=this._label.nativeElement,o="mdc-snackbar__label";a.classList.toggle(o,!a.querySelector(`.${o}`))}_exposeToModals(){let e=this._liveElementId,t=this._document.querySelectorAll('body > .cdk-overlay-container [aria-modal="true"]');for(let a=0;a<t.length;a++){let o=t[a],c=o.getAttribute("aria-owns");this._trackedModals.add(o),c?c.indexOf(e)===-1&&o.setAttribute("aria-owns",c+" "+e):o.setAttribute("aria-owns",e)}}_clearFromModals(){this._trackedModals.forEach(e=>{let t=e.getAttribute("aria-owns");if(t){let a=t.replace(this._liveElementId,"").trim();a.length>0?e.setAttribute("aria-owns",a):e.removeAttribute("aria-owns")}}),this._trackedModals.clear()}_assertNotAttached(){this._portalOutlet.hasAttached()}_screenReaderAnnounce(){this._announceTimeoutId||this._ngZone.runOutsideAngular(()=>{this._announceTimeoutId=setTimeout(()=>{if(this._destroyed)return;let e=this._elementRef.nativeElement,t=e.querySelector("[aria-hidden]"),a=e.querySelector("[aria-live]");if(t&&a){let o=null;this._platform.isBrowser&&document.activeElement instanceof HTMLElement&&t.contains(document.activeElement)&&(o=document.activeElement),t.removeAttribute("aria-hidden"),a.appendChild(t),o?.focus(),this._onAnnounce.next(),this._onAnnounce.complete()}},this._announceDelay)})}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-snack-bar-container"]],viewQuery:function(t,a){if(t&1&&Ae(tn,7)(f1,7),t&2){let o;j(o=V())&&(a._portalOutlet=o.first),j(o=V())&&(a._label=o.first)}},hostAttrs:[1,"mdc-snackbar","mat-mdc-snack-bar-container"],hostVars:6,hostBindings:function(t,a){t&1&&_("animationend",function(c){return a.onAnimationEnd(c.animationName)})("animationcancel",function(c){return a.onAnimationEnd(c.animationName)}),t&2&&k("mat-snack-bar-container-enter",a._animationState==="visible")("mat-snack-bar-container-exit",a._animationState==="hidden")("mat-snack-bar-container-animations-enabled",!a._animationsDisabled)},features:[ie],decls:6,vars:3,consts:[["label",""],[1,"mdc-snackbar__surface","mat-mdc-snackbar-surface"],[1,"mat-mdc-snack-bar-label"],["aria-hidden","true"],["cdkPortalOutlet",""]],template:function(t,a){t&1&&(s(0,"div",1)(1,"div",2,0)(3,"div",3),_e(4,g1,0,0,"ng-template",4),r(),H(5,"div"),r()()),t&2&&(d(5),Y("aria-live",a._live)("role",a._role)("id",a._liveElementId))},dependencies:[tn],styles:[`@keyframes _mat-snack-bar-enter {
  from {
    transform: scale(0.8);
    opacity: 0;
  }
  to {
    transform: scale(1);
    opacity: 1;
  }
}
@keyframes _mat-snack-bar-exit {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
.mat-mdc-snack-bar-container {
  display: flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
  margin: 8px;
}
.mat-mdc-snack-bar-handset .mat-mdc-snack-bar-container {
  width: 100vw;
}

.mat-snack-bar-container-animations-enabled {
  opacity: 0;
}
.mat-snack-bar-container-animations-enabled.mat-snack-bar-fallback-visible {
  opacity: 1;
}
.mat-snack-bar-container-animations-enabled.mat-snack-bar-container-enter {
  animation: _mat-snack-bar-enter 150ms cubic-bezier(0, 0, 0.2, 1) forwards;
}
.mat-snack-bar-container-animations-enabled.mat-snack-bar-container-exit {
  animation: _mat-snack-bar-exit 75ms cubic-bezier(0.4, 0, 1, 1) forwards;
}

.mat-mdc-snackbar-surface {
  box-shadow: 0px 3px 5px -1px rgba(0, 0, 0, 0.2), 0px 6px 10px 0px rgba(0, 0, 0, 0.14), 0px 1px 18px 0px rgba(0, 0, 0, 0.12);
  display: flex;
  align-items: center;
  justify-content: flex-start;
  box-sizing: border-box;
  padding-left: 0;
  padding-right: 8px;
}
[dir=rtl] .mat-mdc-snackbar-surface {
  padding-right: 0;
  padding-left: 8px;
}
.mat-mdc-snack-bar-container .mat-mdc-snackbar-surface {
  min-width: 344px;
  max-width: 672px;
}
.mat-mdc-snack-bar-handset .mat-mdc-snackbar-surface {
  width: 100%;
  min-width: 0;
}
@media (forced-colors: active) {
  .mat-mdc-snackbar-surface {
    outline: solid 1px;
  }
}
.mat-mdc-snack-bar-container .mat-mdc-snackbar-surface {
  color: var(--mat-snack-bar-supporting-text-color, var(--mat-sys-inverse-on-surface));
  border-radius: var(--mat-snack-bar-container-shape, var(--mat-sys-corner-extra-small));
  background-color: var(--mat-snack-bar-container-color, var(--mat-sys-inverse-surface));
}

.mdc-snackbar__label {
  width: 100%;
  flex-grow: 1;
  box-sizing: border-box;
  margin: 0;
  padding: 14px 8px 14px 16px;
}
[dir=rtl] .mdc-snackbar__label {
  padding-left: 8px;
  padding-right: 16px;
}
.mat-mdc-snack-bar-container .mdc-snackbar__label {
  font-family: var(--mat-snack-bar-supporting-text-font, var(--mat-sys-body-medium-font));
  font-size: var(--mat-snack-bar-supporting-text-size, var(--mat-sys-body-medium-size));
  font-weight: var(--mat-snack-bar-supporting-text-weight, var(--mat-sys-body-medium-weight));
  line-height: var(--mat-snack-bar-supporting-text-line-height, var(--mat-sys-body-medium-line-height));
}

.mat-mdc-snack-bar-actions {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  box-sizing: border-box;
}

.mat-mdc-snack-bar-handset,
.mat-mdc-snack-bar-container,
.mat-mdc-snack-bar-label {
  flex: 1 1 auto;
}

.mat-mdc-snack-bar-container .mat-mdc-button.mat-mdc-snack-bar-action:not(:disabled).mat-unthemed {
  color: var(--mat-snack-bar-button-color, var(--mat-sys-inverse-primary));
}
.mat-mdc-snack-bar-container .mat-mdc-button.mat-mdc-snack-bar-action:not(:disabled) {
  --mat-button-text-state-layer-color: currentColor;
  --mat-button-text-ripple-color: currentColor;
}
.mat-mdc-snack-bar-container .mat-mdc-button.mat-mdc-snack-bar-action:not(:disabled) .mat-ripple-element {
  opacity: 0.1;
}
`],encapsulation:2})}return n})(),C1=new E("mat-snack-bar-default-options",{providedIn:"root",factory:()=>new go}),Mt=(()=>{class n{_live=m(_r);_injector=m(re);_breakpointObserver=m(gr);_parentSnackBar=m(n,{optional:!0,skipSelf:!0});_defaultConfig=m(C1);_animationsDisabled=Ee();_snackBarRefAtThisLevel=null;simpleSnackBarComponent=z_;snackBarContainerComponent=x1;handsetCssClass="mat-mdc-snack-bar-handset";get _openedSnackBarRef(){let e=this._parentSnackBar;return e?e._openedSnackBarRef:this._snackBarRefAtThisLevel}set _openedSnackBarRef(e){this._parentSnackBar?this._parentSnackBar._openedSnackBarRef=e:this._snackBarRefAtThisLevel=e}constructor(){}openFromComponent(e,t){return this._attach(e,t)}openFromTemplate(e,t){return this._attach(e,t)}open(e,t="",a){let o=M(M({},this._defaultConfig),a);return o.data={message:e,action:t},o.announcementMessage===e&&(o.announcementMessage=void 0),this.openFromComponent(this.simpleSnackBarComponent,o)}dismiss(){this._openedSnackBarRef&&this._openedSnackBarRef.dismiss()}ngOnDestroy(){this._snackBarRefAtThisLevel&&this._snackBarRefAtThisLevel.dismiss()}_attachSnackBarContainer(e,t){let a=t&&t.viewContainerRef&&t.viewContainerRef.injector,o=re.create({parent:a||this._injector,providers:[{provide:go,useValue:t}]}),c=new Dn(this.snackBarContainerComponent,t.viewContainerRef,o),u=e.attach(c);return u.instance.snackBarConfig=t,u.instance}_attach(e,t){let a=M(M(M({},new go),this._defaultConfig),t),o=this._createOverlay(a),c=this._attachSnackBarContainer(o,a),u=new Wr(c,o);if(e instanceof He){let p=new Qt(e,null,{$implicit:a.data,snackBarRef:u});u.instance=c.attachTemplatePortal(p)}else{let p=this._createInjector(a,u),f=new Dn(e,void 0,p),b=c.attachComponentPortal(f);u.instance=b.instance}return this._breakpointObserver.observe(Rf.HandsetPortrait).pipe(pe(o.detachments())).subscribe(p=>{o.overlayElement.classList.toggle(this.handsetCssClass,p.matches)}),a.announcementMessage&&c._onAnnounce.subscribe(()=>{this._live.announce(a.announcementMessage,a.politeness)}),this._animateSnackBar(u,a),this._openedSnackBarRef=u,this._openedSnackBarRef}_animateSnackBar(e,t){e.afterDismissed().subscribe(()=>{this._openedSnackBarRef==e&&(this._openedSnackBarRef=null),t.announcementMessage&&this._live.clear()}),t.duration&&t.duration>0&&e.afterOpened().subscribe(()=>e._dismissAfter(t.duration)),this._openedSnackBarRef?(this._openedSnackBarRef.afterDismissed().subscribe(()=>{e.containerInstance.enter()}),this._openedSnackBarRef.dismiss()):e.containerInstance.enter()}_createOverlay(e){let t=new ri;t.direction=e.direction;let a=Ni(this._injector),o=e.direction==="rtl",c=e.horizontalPosition==="left"||e.horizontalPosition==="start"&&!o||e.horizontalPosition==="end"&&o,u=!c&&e.horizontalPosition!=="center";return c?a.left("0"):u?a.right("0"):a.centerHorizontally(),e.verticalPosition==="top"?a.top("0"):a.bottom("0"),t.positionStrategy=a,t.disableAnimations=this._animationsDisabled,si(this._injector,t)}_createInjector(e,t){let a=e&&e.viewContainerRef&&e.viewContainerRef.injector;return re.create({parent:a||this._injector,providers:[{provide:Wr,useValue:t},{provide:V_,useValue:e.data}]})}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var Ft=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({providers:[Mt],imports:[Sn,En,Ge,z_,de]})}return n})();function w1(n,i){if(n&1){let e=T();s(0,"button",35),_("click",function(){x(e);let a=h();return C(a.limpiarFiltros())}),l(1),r()}if(n&2){let e=h();d(),N(" Limpiar (",e.totalFiltrosActivos,") ")}}function D1(n,i){if(n&1){let e=T();s(0,"div",8)(1,"mat-checkbox",36),_("change",function(){let a=x(e).$implicit,o=h();return C(o.toggleValor("prioridades",a))}),l(2),r(),s(3,"span",37),l(4),r()()}if(n&2){let e=i.$implicit,t=h();d(),P("checked",t.estaSeleccionado("prioridades",e)),d(),N(" ",e," "),d(2),g(t.contarCoincidencias("prioridad",e))}}function E1(n,i){if(n&1){let e=T();s(0,"div",8)(1,"mat-checkbox",36),_("change",function(){let a=x(e).$implicit,o=h();return C(o.toggleValor("temas",a))}),l(2),r(),s(3,"span",37),l(4),r()()}if(n&2){let e=i.$implicit,t=h();d(),P("checked",t.estaSeleccionado("temas",e)),d(),N(" ",e," "),d(2),g(t.contarCoincidencias("tema",e))}}function S1(n,i){if(n&1){let e=T();s(0,"div",8)(1,"mat-checkbox",36),_("change",function(){let a=x(e).$implicit,o=h();return C(o.toggleValor("escuelas",a))}),l(2),r(),s(3,"span",37),l(4),r()()}if(n&2){let e=i.$implicit,t=h();d(),P("checked",t.estaSeleccionado("escuelas",e)),d(),N(" ",e," "),d(2),g(t.contarCoincidencias("unidadAcademica",e))}}function k1(n,i){if(n&1){let e=T();s(0,"div",8)(1,"mat-checkbox",36),_("change",function(){let a=x(e).$implicit,o=h();return C(o.toggleValor("estatus",a))}),l(2),r(),s(3,"span",37),l(4),r()()}if(n&2){let e=i.$implicit,t=h();d(),P("checked",t.estaSeleccionado("estatus",e)),d(),N(" ",t.etiquetaEstatus(e)," "),d(2),g(t.contarCoincidencias("estatusCodigo",e))}}function M1(n,i){n&1&&(s(0,"th",38),l(1,"Folio"),r())}function I1(n,i){if(n&1&&(s(0,"td",39),l(1),r()),n&2){let e=i.$implicit;d(),g(e.folio)}}function A1(n,i){n&1&&(s(0,"th",38),l(1,"Fecha ingreso"),r())}function R1(n,i){if(n&1&&(s(0,"td",39),l(1),r()),n&2){let e=i.$implicit;d(),g(e.fechaRecepcion)}}function T1(n,i){n&1&&(s(0,"th",38),l(1,"Quejoso"),r())}function O1(n,i){if(n&1&&(s(0,"td",39),l(1),r()),n&2){let e=i.$implicit;d(),g(e.nombreQuejoso)}}function P1(n,i){n&1&&(s(0,"th",38),l(1,"Escuela"),r())}function F1(n,i){if(n&1&&(s(0,"td",39),l(1),r()),n&2){let e=i.$implicit;d(),g(e.unidadAcademica)}}function N1(n,i){n&1&&(s(0,"th",38),l(1,"Tema"),r())}function L1(n,i){if(n&1&&(s(0,"td",39),l(1),r()),n&2){let e=i.$implicit;d(),g(e.tema)}}function B1(n,i){n&1&&(s(0,"th",38),l(1,"Prioridad"),r())}function j1(n,i){if(n&1&&(s(0,"td",39)(1,"mat-chip"),l(2),r()()),n&2){let e=i.$implicit;d(),k("chip-high",e.prioridad==="Alta")("chip-medium",e.prioridad==="Media")("chip-low",e.prioridad==="Baja"),d(),N(" ",e.prioridad," ")}}function V1(n,i){n&1&&(s(0,"th",38),l(1,"Estatus"),r())}function z1(n,i){n&1&&(s(0,"span",40)(1,"mat-icon"),l(2,"event"),r()())}function U1(n,i){if(n&1&&(s(0,"td",39)(1,"span"),l(2),r(),v(3,z1,3,0,"span",40),r()),n&2){let e=i.$implicit,t=h();d(),ve("estatus-chip "+t.claseEstatus(e.estatusCodigo)),d(),g(e.estatus),d(),y(e.tieneCitaActiva?3:-1)}}function H1(n,i){n&1&&(s(0,"th",38),l(1,"Acciones"),r())}function $1(n,i){if(n&1){let e=T();s(0,"td",39)(1,"button",41),_("click",function(){let a=x(e).$implicit,o=h();return C(o.analizar(a))}),s(2,"mat-icon"),l(3,"visibility"),r(),l(4," Analizar "),r()()}}function G1(n,i){n&1&&H(0,"tr",42)}function q1(n,i){n&1&&H(0,"tr",43)}function W1(n,i){n&1&&(s(0,"p",34),l(1,"No hay expedientes que coincidan con los filtros aplicados."),r())}var U_=["TURNADA","EN_ANALISIS","PROCEDENTE","IMPROCEDENTE","REMITIDA"],cl=class n{constructor(i,e,t,a){this.router=i;this.bandejaService=e;this.snackBar=t;this.cdr=a}router;bandejaService;snackBar;cdr;displayedColumns=["folio","fechaRecepcion","nombreQuejoso","unidadAcademica","tema","prioridad","estatus","acciones"];expedientes=new sl([]);expedientesOriginal=[];prioridades=["Alta","Media","Baja"];etiquetaEstatus=Oi;claseEstatus=co;filtros={texto:"",orden:"recientes",prioridades:[],temas:[],escuelas:[],estatus:[]};cambios$=new F;suscripcion;ngOnInit(){this.suscripcion=this.cambios$.pipe(On(250),at(()=>this.bandejaService.filtrar(this.construirFiltro()))).subscribe({next:i=>{this.expedientes.data=i,this.cdr.detectChanges()},error:()=>{this.snackBar.open("No fue posible aplicar los filtros.","Cerrar",{duration:3e3})}}),this.cargarBandeja()}ngOnDestroy(){this.suscripcion?.unsubscribe()}cargarBandeja(){this.bandejaService.obtenerBandeja().subscribe({next:i=>{this.expedientesOriginal=i,this.expedientes.data=i,this.cdr.detectChanges()},error:()=>{this.cdr.detectChanges(),this.snackBar.open("No fue posible cargar la bandeja de an\xE1lisis.","Cerrar",{duration:3e3})}})}get temas(){return this.valoresDe("tema")}get escuelas(){return this.valoresDe("unidadAcademica")}get estatusDisponibles(){return Array.from(new Set(this.expedientesOriginal.map(i=>i.estatusCodigo))).filter(Boolean).sort((i,e)=>U_.indexOf(i)-U_.indexOf(e))}get totalFiltrosActivos(){return this.filtros.prioridades.length+this.filtros.temas.length+this.filtros.escuelas.length+this.filtros.estatus.length}estaSeleccionado(i,e){return this.filtros[i].includes(e)}toggleValor(i,e){let t=this.filtros[i],a=t.indexOf(e);a===-1?t.push(e):t.splice(a,1),this.aplicarFiltros()}contarCoincidencias(i,e){return this.expedientesOriginal.filter(t=>t[i]===e).length}aplicarFiltros(){this.cambios$.next()}limpiarFiltros(){this.filtros={texto:"",orden:"recientes",prioridades:[],temas:[],escuelas:[],estatus:[]},this.aplicarFiltros()}analizar(i){this.router.navigate(["/expediente",i.folio])}construirFiltro(){return{texto:this.filtros.texto.trim()||void 0,prioridades:this.filtros.prioridades.map(i=>i.toUpperCase()),estatusLista:this.filtros.estatus,unidadesAcademicas:this.filtros.escuelas,temas:this.filtros.temas,orden:this.filtros.orden}}valoresDe(i){return Array.from(new Set(this.expedientesOriginal.map(e=>e[i]).filter(Boolean))).sort((e,t)=>e.localeCompare(t,"es"))}static \u0275fac=function(e){return new(e||n)(S(We),S(Pi),S(Mt),S(Z))};static \u0275cmp=A({type:n,selectors:[["app-bandeja-analisis"]],decls:86,vars:10,consts:[[1,"page"],[1,"page-header"],[1,"bandeja-layout"],[1,"filters-panel"],[1,"filters-panel-header"],["mat-button","",1,"clear-link"],["multi","",1,"filters-accordion"],["expanded",""],[1,"facet-option"],[1,"facet-scroll"],[1,"results-column"],[1,"search-card"],["appearance","outline",1,"search-field"],["matInput","","placeholder","Ej. PC-A1B2C3D4, FOL-12345678 o Juan Paco",3,"ngModelChange","ngModel"],["matPrefix",""],["appearance","outline",1,"order-field"],[3,"ngModelChange","selectionChange","ngModel"],["value","recientes"],["value","antiguos"],[1,"results-count"],[1,"table-card"],["mat-table","",1,"mat-elevation-z0",3,"dataSource"],["matColumnDef","folio"],["mat-header-cell","",4,"matHeaderCellDef"],["mat-cell","",4,"matCellDef"],["matColumnDef","fechaRecepcion"],["matColumnDef","nombreQuejoso"],["matColumnDef","unidadAcademica"],["matColumnDef","tema"],["matColumnDef","prioridad"],["matColumnDef","estatus"],["matColumnDef","acciones"],["mat-header-row","",4,"matHeaderRowDef"],["mat-row","",4,"matRowDef","matRowDefColumns"],[1,"empty-state"],["mat-button","",1,"clear-link",3,"click"],[3,"change","checked"],[1,"facet-count"],["mat-header-cell",""],["mat-cell",""],["matTooltip","Tiene una cita programada o confirmada",1,"cita-indicador"],["mat-flat-button","",1,"action-btn",3,"click"],["mat-header-row",""],["mat-row",""]],template:function(e,t){e&1&&(s(0,"section",0)(1,"div",1)(2,"div")(3,"h2"),l(4,"Bandeja de An\xE1lisis"),r(),s(5,"p"),l(6,"Expedientes recibidos para revisi\xF3n de Primer Contacto."),r()()(),s(7,"div",2)(8,"mat-card",3)(9,"div",4)(10,"h3"),l(11,"Filtros"),r(),v(12,w1,2,1,"button",5),r(),s(13,"mat-accordion",6)(14,"mat-expansion-panel",7)(15,"mat-expansion-panel-header")(16,"mat-panel-title"),l(17,"Prioridad"),r()(),te(18,D1,5,3,"div",8,Ke),r(),s(20,"mat-expansion-panel",7)(21,"mat-expansion-panel-header")(22,"mat-panel-title"),l(23,"Tema de violaci\xF3n"),r()(),te(24,E1,5,3,"div",8,Ke),r(),s(26,"mat-expansion-panel")(27,"mat-expansion-panel-header")(28,"mat-panel-title"),l(29,"Escuela"),r()(),s(30,"div",9),te(31,S1,5,3,"div",8,Ke),r()(),s(33,"mat-expansion-panel")(34,"mat-expansion-panel-header")(35,"mat-panel-title"),l(36,"Estatus"),r()(),te(37,k1,5,3,"div",8,Ke),r()()(),s(39,"div",10)(40,"mat-card",11)(41,"mat-form-field",12)(42,"mat-label"),l(43,"Buscar por folio, folio de la queja o nombre"),r(),s(44,"input",13),ge("ngModelChange",function(o){return fe(t.filtros.texto,o)||(t.filtros.texto=o),o}),_("ngModelChange",function(){return t.aplicarFiltros()}),r(),s(45,"mat-icon",14),l(46,"search"),r()(),s(47,"mat-form-field",15)(48,"mat-label"),l(49,"Ordenar por"),r(),s(50,"mat-select",16),ge("ngModelChange",function(o){return fe(t.filtros.orden,o)||(t.filtros.orden=o),o}),_("selectionChange",function(){return t.aplicarFiltros()}),s(51,"mat-option",17),l(52,"M\xE1s recientes"),r(),s(53,"mat-option",18),l(54,"M\xE1s antiguos"),r()()()(),s(55,"p",19),l(56),r(),s(57,"mat-card",20)(58,"table",21),pn(59,22),_e(60,M1,2,0,"th",23)(61,I1,2,1,"td",24),hn(),pn(62,25),_e(63,A1,2,0,"th",23)(64,R1,2,1,"td",24),hn(),pn(65,26),_e(66,T1,2,0,"th",23)(67,O1,2,1,"td",24),hn(),pn(68,27),_e(69,P1,2,0,"th",23)(70,F1,2,1,"td",24),hn(),pn(71,28),_e(72,N1,2,0,"th",23)(73,L1,2,1,"td",24),hn(),pn(74,29),_e(75,B1,2,0,"th",23)(76,j1,3,7,"td",24),hn(),pn(77,30),_e(78,V1,2,0,"th",23)(79,U1,4,4,"td",24),hn(),pn(80,31),_e(81,H1,2,0,"th",23)(82,$1,5,0,"td",24),hn(),_e(83,G1,1,0,"tr",32)(84,q1,1,0,"tr",33),r(),v(85,W1,2,0,"p",34),r()()()()),e&2&&(d(12),y(t.totalFiltrosActivos>0?12:-1),d(6),ne(t.prioridades),d(6),ne(t.temas),d(7),ne(t.escuelas),d(6),ne(t.estatusDisponibles),d(7),he("ngModel",t.filtros.texto),d(6),he("ngModel",t.filtros.orden),d(6),Nn(" ",t.expedientes.data.length," expediente",t.expedientes.data.length===1?"":"s"," encontrado",t.expedientes.data.length===1?"":"s"," "),d(2),P("dataSource",t.expedientes),d(25),P("matHeaderRowDef",t.displayedColumns),d(),P("matRowDefColumns",t.displayedColumns),d(),y(t.expedientes.data.length===0?85:-1))},dependencies:[Ot,ft,Tt,St,sn,jn,kt,ln,Jt,Ru,el,Jc,Li,mn,Gn,po,ha,b_,__,Qu,Yu,g_,N_,S_,M_,T_,I_,k_,O_,A_,R_,P_,F_,Ge,Je,ze,Ve,Un,Ti,fo,qr,Ft],styles:[".page[_ngcontent-%COMP%]{max-width:1280px}.page-header[_ngcontent-%COMP%]{margin-bottom:var(--space-5)}.page-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{margin:0;color:var(--guinda);font-size:28px;font-weight:800}.page-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-1) 0 0;color:var(--texto-suave)}.bandeja-layout[_ngcontent-%COMP%]{display:grid;grid-template-columns:260px 1fr;gap:var(--space-5);align-items:start}.filters-panel[_ngcontent-%COMP%]{border-radius:14px;box-shadow:0 2px 8px #0f172a14;padding:var(--space-4);position:sticky;top:calc(72px + var(--space-5));background:#fff}.filters-panel-header[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;margin-bottom:var(--space-2)}.filters-panel-header[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{margin:0;font-size:var(--font-size-lg);font-weight:900;color:var(--negro-inst)}.clear-link[_ngcontent-%COMP%]{color:var(--guinda)!important;font-weight:700;font-size:var(--font-size-sm);min-width:0;padding:0 var(--space-2)}.filters-accordion[_ngcontent-%COMP%]   .mat-expansion-panel[_ngcontent-%COMP%]{box-shadow:none!important;border-bottom:1px solid #f1f1f3}.filters-accordion[_ngcontent-%COMP%]   .mat-expansion-panel[_ngcontent-%COMP%]:last-child{border-bottom:none}.filters-accordion[_ngcontent-%COMP%]   mat-panel-title[_ngcontent-%COMP%]{font-weight:800;color:var(--negro-inst);font-size:var(--font-size-base)}.facet-option[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;gap:var(--space-2);padding:var(--space-1) 0}.facet-option[_ngcontent-%COMP%]   mat-checkbox[_ngcontent-%COMP%]{font-size:var(--font-size-sm)}.facet-count[_ngcontent-%COMP%]{color:#9ca3af;font-size:var(--font-size-xs);font-weight:700}.facet-scroll[_ngcontent-%COMP%]{max-height:220px;overflow-y:auto;padding-right:var(--space-1)}.results-column[_ngcontent-%COMP%]{display:grid;gap:var(--space-4);min-width:0}.search-card[_ngcontent-%COMP%]{border-radius:14px;box-shadow:0 2px 8px #0f172a14;padding:var(--space-4);display:grid;grid-template-columns:1fr 220px;align-items:start;gap:var(--space-4);background:#fff}.search-field[_ngcontent-%COMP%], .order-field[_ngcontent-%COMP%]{width:100%}.search-card[_ngcontent-%COMP%]     .mat-mdc-form-field-subscript-wrapper{display:none}.results-count[_ngcontent-%COMP%]{margin:0;color:var(--texto-suave);font-size:var(--font-size-sm);font-weight:700}.table-card[_ngcontent-%COMP%]{overflow-x:auto;border-radius:14px;box-shadow:0 2px 8px #0f172a14;padding:0;background:#fff}table[_ngcontent-%COMP%]{width:100%;min-width:900px}th[_ngcontent-%COMP%]{background:var(--negro-inst)!important;color:#fff;font-weight:800}td[_ngcontent-%COMP%], th[_ngcontent-%COMP%]{padding:var(--space-4)!important}tr[_ngcontent-%COMP%]:hover   td[_ngcontent-%COMP%]{background:#f9fafb}mat-chip[_ngcontent-%COMP%]{font-weight:700}.chip-high[_ngcontent-%COMP%]{background:#ffebee!important;color:var(--peligro)!important}.chip-medium[_ngcontent-%COMP%]{background:#fdf6e3!important;color:var(--advertencia)!important}.chip-low[_ngcontent-%COMP%]{background:#e8f5e9!important;color:var(--exito)!important}.status[_ngcontent-%COMP%]{font-weight:700;color:var(--texto)}.action-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important;font-weight:700;border-radius:8px;padding:0 var(--space-4)}.empty-state[_ngcontent-%COMP%]{text-align:center;color:var(--texto-suave);padding:var(--space-6);margin:0}@media(max-width:1000px){.bandeja-layout[_ngcontent-%COMP%]{grid-template-columns:1fr}.filters-panel[_ngcontent-%COMP%]{position:static}.search-card[_ngcontent-%COMP%]{grid-template-columns:1fr}}"]})};function Q1(n,i){}var ji=class{viewContainerRef;injector;id;role="dialog";panelClass="";hasBackdrop=!0;backdropClass="";disableClose=!1;closePredicate;width="";height="";minWidth;minHeight;maxWidth;maxHeight;positionStrategy;data=null;direction;ariaDescribedBy=null;ariaLabelledBy=null;ariaLabel=null;ariaModal=!1;autoFocus="first-tabbable";restoreFocus=!0;scrollStrategy;closeOnNavigation=!0;closeOnDestroy=!0;closeOnOverlayDetachments=!0;disableAnimations=!1;providers;container;templateContext};var lm=(()=>{class n extends Fi{_elementRef=m(B);_focusTrapFactory=m(su);_config;_interactivityChecker=m(ru);_ngZone=m(W);_focusMonitor=m(Dt);_renderer=m(Se);_changeDetectorRef=m(Z);_injector=m(re);_platform=m(be);_document=m(X);_portalOutlet;_focusTrapped=new F;_focusTrap=null;_elementFocusedBeforeDialogWasOpened=null;_closeInteractionType=null;_ariaLabelledByQueue=[];_isDestroyed=!1;constructor(){super(),this._config=m(ji,{optional:!0})||new ji,this._config.ariaLabelledBy&&this._ariaLabelledByQueue.push(this._config.ariaLabelledBy)}_addAriaLabelledBy(e){this._ariaLabelledByQueue.push(e),this._changeDetectorRef.markForCheck()}_removeAriaLabelledBy(e){let t=this._ariaLabelledByQueue.indexOf(e);t>-1&&(this._ariaLabelledByQueue.splice(t,1),this._changeDetectorRef.markForCheck())}_contentAttached(){this._initializeFocusTrap(),this._captureInitialFocus()}_captureInitialFocus(){this._trapFocus()}ngOnDestroy(){this._focusTrapped.complete(),this._isDestroyed=!0,this._restoreFocus()}attachComponentPortal(e){this._portalOutlet.hasAttached();let t=this._portalOutlet.attachComponentPortal(e);return this._contentAttached(),t}attachTemplatePortal(e){this._portalOutlet.hasAttached();let t=this._portalOutlet.attachTemplatePortal(e);return this._contentAttached(),t}attachDomPortal=e=>{this._portalOutlet.hasAttached();let t=this._portalOutlet.attachDomPortal(e);return this._contentAttached(),t};_recaptureFocus(){this._containsFocus()||this._trapFocus()}_forceFocus(e,t){this._interactivityChecker.isFocusable(e)||(e.tabIndex=-1,this._ngZone.runOutsideAngular(()=>{let a=()=>{o(),c(),e.removeAttribute("tabindex")},o=this._renderer.listen(e,"blur",a),c=this._renderer.listen(e,"mousedown",a)})),e.focus(t)}_focusByCssSelector(e,t){let a=this._elementRef.nativeElement.querySelector(e);a&&this._forceFocus(a,t)}_trapFocus(e){this._isDestroyed||Pe(()=>{let t=this._elementRef.nativeElement;switch(this._config.autoFocus){case!1:case"dialog":this._containsFocus()||t.focus(e);break;case!0:case"first-tabbable":this._focusTrap?.focusInitialElement(e)||this._focusDialogContainer(e);break;case"first-heading":this._focusByCssSelector('h1, h2, h3, h4, h5, h6, [role="heading"]',e);break;default:this._focusByCssSelector(this._config.autoFocus,e);break}this._focusTrapped.next()},{injector:this._injector})}_restoreFocus(){let e=this._config.restoreFocus,t=null;if(typeof e=="string"?t=this._document.querySelector(e):typeof e=="boolean"?t=e?this._elementFocusedBeforeDialogWasOpened:null:e&&(t=e),this._config.restoreFocus&&t&&typeof t.focus=="function"){let a=pr(),o=this._elementRef.nativeElement;(!a||a===this._document.body||a===o||o.contains(a))&&(this._focusMonitor?(this._focusMonitor.focusVia(t,this._closeInteractionType),this._closeInteractionType=null):t.focus())}this._focusTrap&&this._focusTrap.destroy()}_focusDialogContainer(e){this._elementRef.nativeElement.focus?.(e)}_containsFocus(){let e=this._elementRef.nativeElement,t=pr();return e===t||e.contains(t)}_initializeFocusTrap(){this._platform.isBrowser&&(this._focusTrap=this._focusTrapFactory.create(this._elementRef.nativeElement),this._document&&(this._elementFocusedBeforeDialogWasOpened=pr()))}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["cdk-dialog-container"]],viewQuery:function(t,a){if(t&1&&Ae(tn,7),t&2){let o;j(o=V())&&(a._portalOutlet=o.first)}},hostAttrs:["tabindex","-1",1,"cdk-dialog-container"],hostVars:6,hostBindings:function(t,a){t&2&&Y("id",a._config.id||null)("role",a._config.role)("aria-modal",a._config.ariaModal)("aria-labelledby",a._config.ariaLabel?null:a._ariaLabelledByQueue[0])("aria-label",a._config.ariaLabel)("aria-describedby",a._config.ariaDescribedBy||null)},features:[ie],decls:1,vars:0,consts:[["cdkPortalOutlet",""]],template:function(t,a){t&1&&_e(0,Q1,0,0,"ng-template",0)},dependencies:[tn],styles:[`.cdk-dialog-container {
  display: block;
  width: 100%;
  height: 100%;
  min-height: inherit;
  max-height: inherit;
}
`],encapsulation:2})}return n})(),Qr=class{overlayRef;config;componentInstance=null;componentRef=null;containerInstance;disableClose;closed=new F;backdropClick;keydownEvents;outsidePointerEvents;id;_detachSubscription;constructor(i,e){this.overlayRef=i,this.config=e,this.disableClose=e.disableClose,this.backdropClick=i.backdropClick(),this.keydownEvents=i.keydownEvents(),this.outsidePointerEvents=i.outsidePointerEvents(),this.id=e.id,this.keydownEvents.subscribe(t=>{t.keyCode===27&&!this.disableClose&&!Ze(t)&&(t.preventDefault(),this.close(void 0,{focusOrigin:"keyboard"}))}),this.backdropClick.subscribe(()=>{!this.disableClose&&this._canClose()?this.close(void 0,{focusOrigin:"mouse"}):this.containerInstance._recaptureFocus?.()}),this._detachSubscription=i.detachments().subscribe(()=>{e.closeOnOverlayDetachments!==!1&&this.close()})}close(i,e){if(this._canClose(i)){let t=this.closed;this.containerInstance._closeInteractionType=e?.focusOrigin||"program",this._detachSubscription.unsubscribe(),this.overlayRef.dispose(),t.next(i),t.complete(),this.componentInstance=this.containerInstance=null}}updatePosition(){return this.overlayRef.updatePosition(),this}updateSize(i="",e=""){return this.overlayRef.updateSize({width:i,height:e}),this}addPanelClass(i){return this.overlayRef.addPanelClass(i),this}removePanelClass(i){return this.overlayRef.removePanelClass(i),this}_canClose(i){let e=this.config;return!!this.containerInstance&&(!e.closePredicate||e.closePredicate(i,e,this.componentInstance))}},Y1=new E("DialogScrollStrategy",{providedIn:"root",factory:()=>{let n=m(re);return()=>mo(n)}}),X1=new E("DialogData"),K1=new E("DefaultDialogConfig");function Z1(n){let i=le(n),e=new z;return{valueSignal:i,get value(){return i()},change:e,ngOnDestroy(){e.complete()}}}var dm=(()=>{class n{_injector=m(re);_defaultOptions=m(K1,{optional:!0});_parentDialog=m(n,{optional:!0,skipSelf:!0});_overlayContainer=m(Xc);_idGenerator=m(xe);_openDialogsAtThisLevel=[];_afterAllClosedAtThisLevel=new F;_afterOpenedAtThisLevel=new F;_ariaHiddenElements=new Map;_scrollStrategy=m(Y1);get openDialogs(){return this._parentDialog?this._parentDialog.openDialogs:this._openDialogsAtThisLevel}get afterOpened(){return this._parentDialog?this._parentDialog.afterOpened:this._afterOpenedAtThisLevel}afterAllClosed=Tn(()=>this.openDialogs.length?this._getAfterAllClosed():this._getAfterAllClosed().pipe(tt(void 0)));constructor(){}open(e,t){let a=this._defaultOptions||new ji;t=M(M({},a),t),t.id=t.id||this._idGenerator.getId("cdk-dialog-"),t.id&&this.getDialogById(t.id);let o=this._getOverlayConfig(t),c=si(this._injector,o),u=new Qr(c,t),p=this._attachContainer(c,u,t);if(u.containerInstance=p,!this.openDialogs.length){let f=this._overlayContainer.getContainerElement();p._focusTrapped?p._focusTrapped.pipe(it(1)).subscribe(()=>{this._hideNonDialogContentFromAssistiveTechnology(f)}):this._hideNonDialogContentFromAssistiveTechnology(f)}return this._attachDialogContent(e,u,p,t),this.openDialogs.push(u),u.closed.subscribe(()=>this._removeOpenDialog(u,!0)),this.afterOpened.next(u),u}closeAll(){cm(this.openDialogs,e=>e.close())}getDialogById(e){return this.openDialogs.find(t=>t.id===e)}ngOnDestroy(){cm(this._openDialogsAtThisLevel,e=>{e.config.closeOnDestroy===!1&&this._removeOpenDialog(e,!1)}),cm(this._openDialogsAtThisLevel,e=>e.close()),this._afterAllClosedAtThisLevel.complete(),this._afterOpenedAtThisLevel.complete(),this._openDialogsAtThisLevel=[]}_getOverlayConfig(e){let t=new ri({positionStrategy:e.positionStrategy||Ni().centerHorizontally().centerVertically(),scrollStrategy:e.scrollStrategy||this._scrollStrategy(),panelClass:e.panelClass,hasBackdrop:e.hasBackdrop,direction:e.direction,minWidth:e.minWidth,minHeight:e.minHeight,maxWidth:e.maxWidth,maxHeight:e.maxHeight,width:e.width,height:e.height,disposeOnNavigation:e.closeOnNavigation,disableAnimations:e.disableAnimations});return e.backdropClass&&(t.backdropClass=e.backdropClass),t}_attachContainer(e,t,a){let o=a.injector||a.viewContainerRef?.injector,c=[{provide:ji,useValue:a},{provide:Qr,useValue:t},{provide:lo,useValue:e}],u;a.container?typeof a.container=="function"?u=a.container:(u=a.container.type,c.push(...a.container.providers(a))):u=lm;let p=new Dn(u,a.viewContainerRef,re.create({parent:o||this._injector,providers:c}));return e.attach(p).instance}_attachDialogContent(e,t,a,o){if(e instanceof He){let c=this._createInjector(o,t,a,void 0),u={$implicit:o.data,dialogRef:t};o.templateContext&&(u=M(M({},u),typeof o.templateContext=="function"?o.templateContext():o.templateContext)),a.attachTemplatePortal(new Qt(e,null,u,c))}else{let c=this._createInjector(o,t,a,this._injector),u=a.attachComponentPortal(new Dn(e,o.viewContainerRef,c));t.componentRef=u,t.componentInstance=u.instance}}_createInjector(e,t,a,o){let c=e.injector||e.viewContainerRef?.injector,u=[{provide:X1,useValue:e.data},{provide:Qr,useValue:t}];return e.providers&&(typeof e.providers=="function"?u.push(...e.providers(t,e,a)):u.push(...e.providers)),e.direction&&(!c||!c.get(Qe,null,{optional:!0}))&&u.push({provide:Qe,useValue:Z1(e.direction)}),re.create({parent:c||o,providers:u})}_removeOpenDialog(e,t){let a=this.openDialogs.indexOf(e);a>-1&&(this.openDialogs.splice(a,1),this.openDialogs.length||(this._ariaHiddenElements.forEach((o,c)=>{o?c.setAttribute("aria-hidden",o):c.removeAttribute("aria-hidden")}),this._ariaHiddenElements.clear(),t&&this._getAfterAllClosed().next()))}_hideNonDialogContentFromAssistiveTechnology(e){if(e.parentElement){let t=e.parentElement.children;for(let a=t.length-1;a>-1;a--){let o=t[a];o!==e&&o.nodeName!=="SCRIPT"&&o.nodeName!=="STYLE"&&!o.hasAttribute("aria-live")&&!o.hasAttribute("popover")&&(this._ariaHiddenElements.set(o,o.getAttribute("aria-hidden")),o.setAttribute("aria-hidden","true"))}}}_getAfterAllClosed(){let e=this._parentDialog;return e?e._getAfterAllClosed():this._afterAllClosedAtThisLevel}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();function cm(n,i){let e=n.length;for(;e--;)i(n[e])}var H_=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({providers:[dm],imports:[Sn,En,br,En]})}return n})();function J1(n,i){}var dl=class{viewContainerRef;injector;id;role="dialog";panelClass="";hasBackdrop=!0;backdropClass="";disableClose=!1;closePredicate;width="";height="";minWidth;minHeight;maxWidth;maxHeight;position;data=null;direction;ariaDescribedBy=null;ariaLabelledBy=null;ariaLabel=null;ariaModal=!1;autoFocus="first-tabbable";restoreFocus=!0;delayFocusTrap=!0;scrollStrategy;closeOnNavigation=!0;enterAnimationDuration;exitAnimationDuration},um="mdc-dialog--open",$_="mdc-dialog--opening",G_="mdc-dialog--closing",eD=150,tD=75,nD=(()=>{class n extends lm{_animationStateChanged=new z;_animationsEnabled=!Ee();_actionSectionCount=0;_hostElement=this._elementRef.nativeElement;_enterAnimationDuration=this._animationsEnabled?W_(this._config.enterAnimationDuration)??eD:0;_exitAnimationDuration=this._animationsEnabled?W_(this._config.exitAnimationDuration)??tD:0;_animationTimer=null;_contentAttached(){super._contentAttached(),this._startOpenAnimation()}_startOpenAnimation(){this._animationStateChanged.emit({state:"opening",totalTime:this._enterAnimationDuration}),this._animationsEnabled?(this._hostElement.style.setProperty(q_,`${this._enterAnimationDuration}ms`),this._requestAnimationFrame(()=>this._hostElement.classList.add($_,um)),this._waitForAnimationToComplete(this._enterAnimationDuration,this._finishDialogOpen)):(this._hostElement.classList.add(um),Promise.resolve().then(()=>this._finishDialogOpen()))}_startExitAnimation(){this._animationStateChanged.emit({state:"closing",totalTime:this._exitAnimationDuration}),this._hostElement.classList.remove(um),this._animationsEnabled?(this._hostElement.style.setProperty(q_,`${this._exitAnimationDuration}ms`),this._requestAnimationFrame(()=>this._hostElement.classList.add(G_)),this._waitForAnimationToComplete(this._exitAnimationDuration,this._finishDialogClose)):Promise.resolve().then(()=>this._finishDialogClose())}_updateActionSectionCount(e){this._actionSectionCount+=e,this._changeDetectorRef.markForCheck()}_finishDialogOpen=()=>{this._clearAnimationClasses(),this._openAnimationDone(this._enterAnimationDuration)};_finishDialogClose=()=>{this._clearAnimationClasses(),this._animationStateChanged.emit({state:"closed",totalTime:this._exitAnimationDuration})};_clearAnimationClasses(){this._hostElement.classList.remove($_,G_)}_waitForAnimationToComplete(e,t){this._animationTimer!==null&&clearTimeout(this._animationTimer),this._animationTimer=setTimeout(t,e)}_requestAnimationFrame(e){this._ngZone.runOutsideAngular(()=>{typeof requestAnimationFrame=="function"?requestAnimationFrame(e):e()})}_captureInitialFocus(){this._config.delayFocusTrap||this._trapFocus()}_openAnimationDone(e){this._config.delayFocusTrap&&this._trapFocus(),this._animationStateChanged.next({state:"opened",totalTime:e})}ngOnDestroy(){super.ngOnDestroy(),this._animationTimer!==null&&clearTimeout(this._animationTimer)}attachComponentPortal(e){let t=super.attachComponentPortal(e);return t.location.nativeElement.classList.add("mat-mdc-dialog-component-host"),t}static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275cmp=A({type:n,selectors:[["mat-dialog-container"]],hostAttrs:["tabindex","-1",1,"mat-mdc-dialog-container","mdc-dialog"],hostVars:10,hostBindings:function(t,a){t&2&&(jt("id",a._config.id),Y("aria-modal",a._config.ariaModal)("role",a._config.role)("aria-labelledby",a._config.ariaLabel?null:a._ariaLabelledByQueue[0])("aria-label",a._config.ariaLabel)("aria-describedby",a._config.ariaDescribedBy||null),k("_mat-animation-noopable",!a._animationsEnabled)("mat-mdc-dialog-container-with-actions",a._actionSectionCount>0))},features:[ie],decls:3,vars:0,consts:[[1,"mat-mdc-dialog-inner-container","mdc-dialog__container"],[1,"mat-mdc-dialog-surface","mdc-dialog__surface"],["cdkPortalOutlet",""]],template:function(t,a){t&1&&(s(0,"div",0)(1,"div",1),_e(2,J1,0,0,"ng-template",2),r()())},dependencies:[tn],styles:[`.mat-mdc-dialog-container {
  width: 100%;
  height: 100%;
  display: block;
  box-sizing: border-box;
  max-height: inherit;
  min-height: inherit;
  min-width: inherit;
  max-width: inherit;
  outline: 0;
}

.cdk-overlay-pane.mat-mdc-dialog-panel {
  max-width: var(--mat-dialog-container-max-width, 560px);
  min-width: var(--mat-dialog-container-min-width, 280px);
}
@media (max-width: 599px) {
  .cdk-overlay-pane.mat-mdc-dialog-panel {
    max-width: var(--mat-dialog-container-small-max-width, calc(100vw - 32px));
  }
}

.mat-mdc-dialog-inner-container {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-around;
  box-sizing: border-box;
  height: 100%;
  opacity: 0;
  transition: opacity linear var(--mat-dialog-transition-duration, 0ms);
  max-height: inherit;
  min-height: inherit;
  min-width: inherit;
  max-width: inherit;
}
.mdc-dialog--closing .mat-mdc-dialog-inner-container {
  transition: opacity 75ms linear;
  transform: none;
}
.mdc-dialog--open .mat-mdc-dialog-inner-container {
  opacity: 1;
}
._mat-animation-noopable .mat-mdc-dialog-inner-container {
  transition: none;
}

.mat-mdc-dialog-surface {
  display: flex;
  flex-direction: column;
  flex-grow: 0;
  flex-shrink: 0;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  position: relative;
  overflow-y: auto;
  outline: 0;
  transform: scale(0.8);
  transition: transform var(--mat-dialog-transition-duration, 0ms) cubic-bezier(0, 0, 0.2, 1);
  max-height: inherit;
  min-height: inherit;
  min-width: inherit;
  max-width: inherit;
  box-shadow: var(--mat-dialog-container-elevation-shadow, none);
  border-radius: var(--mat-dialog-container-shape, var(--mat-sys-corner-extra-large, 4px));
  background-color: var(--mat-dialog-container-color, var(--mat-sys-surface, white));
}
[dir=rtl] .mat-mdc-dialog-surface {
  text-align: right;
}
.mdc-dialog--open .mat-mdc-dialog-surface, .mdc-dialog--closing .mat-mdc-dialog-surface {
  transform: none;
}
._mat-animation-noopable .mat-mdc-dialog-surface {
  transition: none;
}
.mat-mdc-dialog-surface::before {
  position: absolute;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  border: 2px solid transparent;
  border-radius: inherit;
  content: "";
  pointer-events: none;
}

.mat-mdc-dialog-title {
  display: block;
  position: relative;
  flex-shrink: 0;
  box-sizing: border-box;
  margin: 0 0 1px;
  padding: var(--mat-dialog-headline-padding, 6px 24px 13px);
}
.mat-mdc-dialog-title::before {
  display: inline-block;
  width: 0;
  height: 40px;
  content: "";
  vertical-align: 0;
}
[dir=rtl] .mat-mdc-dialog-title {
  text-align: right;
}
.mat-mdc-dialog-container .mat-mdc-dialog-title {
  color: var(--mat-dialog-subhead-color, var(--mat-sys-on-surface, rgba(0, 0, 0, 0.87)));
  font-family: var(--mat-dialog-subhead-font, var(--mat-sys-headline-small-font, inherit));
  line-height: var(--mat-dialog-subhead-line-height, var(--mat-sys-headline-small-line-height, 1.5rem));
  font-size: var(--mat-dialog-subhead-size, var(--mat-sys-headline-small-size, 1rem));
  font-weight: var(--mat-dialog-subhead-weight, var(--mat-sys-headline-small-weight, 400));
  letter-spacing: var(--mat-dialog-subhead-tracking, var(--mat-sys-headline-small-tracking, 0.03125em));
}

.mat-mdc-dialog-content {
  display: block;
  flex-grow: 1;
  box-sizing: border-box;
  margin: 0;
  overflow: auto;
  max-height: 65vh;
}
.mat-mdc-dialog-content > :first-child {
  margin-top: 0;
}
.mat-mdc-dialog-content > :last-child {
  margin-bottom: 0;
}
.mat-mdc-dialog-container .mat-mdc-dialog-content {
  color: var(--mat-dialog-supporting-text-color, var(--mat-sys-on-surface-variant, rgba(0, 0, 0, 0.6)));
  font-family: var(--mat-dialog-supporting-text-font, var(--mat-sys-body-medium-font, inherit));
  line-height: var(--mat-dialog-supporting-text-line-height, var(--mat-sys-body-medium-line-height, 1.5rem));
  font-size: var(--mat-dialog-supporting-text-size, var(--mat-sys-body-medium-size, 1rem));
  font-weight: var(--mat-dialog-supporting-text-weight, var(--mat-sys-body-medium-weight, 400));
  letter-spacing: var(--mat-dialog-supporting-text-tracking, var(--mat-sys-body-medium-tracking, 0.03125em));
}
.mat-mdc-dialog-container .mat-mdc-dialog-content {
  padding: var(--mat-dialog-content-padding, 20px 24px);
}
.mat-mdc-dialog-container-with-actions .mat-mdc-dialog-content {
  padding: var(--mat-dialog-with-actions-content-padding, 20px 24px 0);
}
.mat-mdc-dialog-container .mat-mdc-dialog-title + .mat-mdc-dialog-content {
  padding-top: 0;
}

.mat-mdc-dialog-actions {
  display: flex;
  position: relative;
  flex-shrink: 0;
  flex-wrap: wrap;
  align-items: center;
  box-sizing: border-box;
  min-height: 52px;
  margin: 0;
  border-top: 1px solid transparent;
  padding: var(--mat-dialog-actions-padding, 16px 24px);
  justify-content: var(--mat-dialog-actions-alignment, flex-end);
}
@media (forced-colors: active) {
  .mat-mdc-dialog-actions {
    border-top-color: CanvasText;
  }
}
.mat-mdc-dialog-actions.mat-mdc-dialog-actions-align-start, .mat-mdc-dialog-actions[align=start] {
  justify-content: start;
}
.mat-mdc-dialog-actions.mat-mdc-dialog-actions-align-center, .mat-mdc-dialog-actions[align=center] {
  justify-content: center;
}
.mat-mdc-dialog-actions.mat-mdc-dialog-actions-align-end, .mat-mdc-dialog-actions[align=end] {
  justify-content: flex-end;
}
.mat-mdc-dialog-actions .mat-button-base + .mat-button-base,
.mat-mdc-dialog-actions .mat-mdc-button-base + .mat-mdc-button-base {
  margin-left: 8px;
}
[dir=rtl] .mat-mdc-dialog-actions .mat-button-base + .mat-button-base,
[dir=rtl] .mat-mdc-dialog-actions .mat-mdc-button-base + .mat-mdc-button-base {
  margin-left: 0;
  margin-right: 8px;
}

.mat-mdc-dialog-component-host {
  display: contents;
}
`],encapsulation:2})}return n})(),q_="--mat-dialog-transition-duration";function W_(n){return n==null?null:typeof n=="number"?n:n.endsWith("ms")?vn(n.substring(0,n.length-2)):n.endsWith("s")?vn(n.substring(0,n.length-1))*1e3:n==="0"?0:null}var ll=(function(n){return n[n.OPEN=0]="OPEN",n[n.CLOSING=1]="CLOSING",n[n.CLOSED=2]="CLOSED",n})(ll||{}),Mn=class{_ref;_config;_containerInstance;componentInstance;componentRef=null;disableClose;id;_afterOpened=new Fl(1);_beforeClosed=new Fl(1);_result;_closeFallbackTimeout;_state=ll.OPEN;_closeInteractionType;constructor(i,e,t){this._ref=i,this._config=e,this._containerInstance=t,this.disableClose=e.disableClose,this.id=i.id,i.addPanelClass("mat-mdc-dialog-panel"),t._animationStateChanged.pipe(Ce(a=>a.state==="opened"),it(1)).subscribe(()=>{this._afterOpened.next(),this._afterOpened.complete()}),t._animationStateChanged.pipe(Ce(a=>a.state==="closed"),it(1)).subscribe(()=>{clearTimeout(this._closeFallbackTimeout),this._finishDialogClose()}),i.overlayRef.detachments().subscribe(()=>{this._beforeClosed.next(this._result),this._beforeClosed.complete(),this._finishDialogClose()}),ut(this.backdropClick(),this.keydownEvents().pipe(Ce(a=>a.keyCode===27&&!this.disableClose&&!Ze(a)))).subscribe(a=>{this.disableClose||(a.preventDefault(),Q_(this,a.type==="keydown"?"keyboard":"mouse"))})}close(i){let e=this._config.closePredicate;e&&!e(i,this._config,this.componentInstance)||(this._result=i,this._containerInstance._animationStateChanged.pipe(Ce(t=>t.state==="closing"),it(1)).subscribe(t=>{this._beforeClosed.next(i),this._beforeClosed.complete(),this._ref.overlayRef.detachBackdrop(),this._closeFallbackTimeout=setTimeout(()=>this._finishDialogClose(),t.totalTime+100)}),this._state=ll.CLOSING,this._containerInstance._startExitAnimation())}afterOpened(){return this._afterOpened}afterClosed(){return this._ref.closed}beforeClosed(){return this._beforeClosed}backdropClick(){return this._ref.backdropClick}keydownEvents(){return this._ref.keydownEvents}updatePosition(i){let e=this._ref.config.positionStrategy;return i&&(i.left||i.right)?i.left?e.left(i.left):e.right(i.right):e.centerHorizontally(),i&&(i.top||i.bottom)?i.top?e.top(i.top):e.bottom(i.bottom):e.centerVertically(),this._ref.updatePosition(),this}updateSize(i="",e=""){return this._ref.updateSize(i,e),this}addPanelClass(i){return this._ref.addPanelClass(i),this}removePanelClass(i){return this._ref.removePanelClass(i),this}getState(){return this._state}_finishDialogClose(){this._state=ll.CLOSED,this._ref.close(this._result,{focusOrigin:this._closeInteractionType}),this.componentInstance=null}};function Q_(n,i,e){return n._closeInteractionType=i,n.close(e)}var In=new E("MatMdcDialogData"),iD=new E("mat-mdc-dialog-default-options"),aD=new E("mat-mdc-dialog-scroll-strategy",{providedIn:"root",factory:()=>{let n=m(re);return()=>mo(n)}}),An=(()=>{class n{_defaultOptions=m(iD,{optional:!0});_scrollStrategy=m(aD);_parentDialog=m(n,{optional:!0,skipSelf:!0});_idGenerator=m(xe);_injector=m(re);_dialog=m(dm);_animationsDisabled=Ee();_openDialogsAtThisLevel=[];_afterAllClosedAtThisLevel=new F;_afterOpenedAtThisLevel=new F;dialogConfigClass=dl;_dialogRefConstructor;_dialogContainerType;_dialogDataToken;get openDialogs(){return this._parentDialog?this._parentDialog.openDialogs:this._openDialogsAtThisLevel}get afterOpened(){return this._parentDialog?this._parentDialog.afterOpened:this._afterOpenedAtThisLevel}_getAfterAllClosed(){let e=this._parentDialog;return e?e._getAfterAllClosed():this._afterAllClosedAtThisLevel}afterAllClosed=Tn(()=>this.openDialogs.length?this._getAfterAllClosed():this._getAfterAllClosed().pipe(tt(void 0)));constructor(){this._dialogRefConstructor=Mn,this._dialogContainerType=nD,this._dialogDataToken=In}open(e,t){let a;t=M(M({},this._defaultOptions||new dl),t),t.id=t.id||this._idGenerator.getId("mat-mdc-dialog-"),t.scrollStrategy=t.scrollStrategy||this._scrollStrategy();let o=this._dialog.open(e,Re(M({},t),{positionStrategy:Ni(this._injector).centerHorizontally().centerVertically(),disableClose:!0,closePredicate:void 0,closeOnDestroy:!1,closeOnOverlayDetachments:!1,disableAnimations:this._animationsDisabled||t.enterAnimationDuration?.toLocaleString()==="0"||t.exitAnimationDuration?.toString()==="0",container:{type:this._dialogContainerType,providers:()=>[{provide:this.dialogConfigClass,useValue:t},{provide:ji,useValue:t}]},templateContext:()=>({dialogRef:a}),providers:(c,u,p)=>(a=new this._dialogRefConstructor(c,t,p),a.updatePosition(t?.position),[{provide:this._dialogContainerType,useValue:p},{provide:this._dialogDataToken,useValue:u.data},{provide:this._dialogRefConstructor,useValue:a}])}));return a.componentRef=o.componentRef,a.componentInstance=o.componentInstance,this.openDialogs.push(a),this.afterOpened.next(a),a.afterClosed().subscribe(()=>{let c=this.openDialogs.indexOf(a);c>-1&&(this.openDialogs.splice(c,1),this.openDialogs.length||this._getAfterAllClosed().next())}),a}closeAll(){this._closeDialogs(this.openDialogs)}getDialogById(e){return this.openDialogs.find(t=>t.id===e)}ngOnDestroy(){this._closeDialogs(this._openDialogsAtThisLevel),this._afterAllClosedAtThisLevel.complete(),this._afterOpenedAtThisLevel.complete()}_closeDialogs(e){let t=e.length;for(;t--;)e[t].close()}static \u0275fac=function(t){return new(t||n)};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})(),Vi=(()=>{class n{dialogRef=m(Mn,{optional:!0});_elementRef=m(B);_dialog=m(An);ariaLabel;type="button";dialogResult;_matDialogClose;constructor(){}ngOnInit(){this.dialogRef||(this.dialogRef=X_(this._elementRef,this._dialog.openDialogs))}ngOnChanges(e){let t=e._matDialogClose||e._matDialogCloseResult;t&&(this.dialogResult=t.currentValue)}_onButtonClick(e){Q_(this.dialogRef,e.screenX===0&&e.screenY===0?"keyboard":"mouse",this.dialogResult)}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","mat-dialog-close",""],["","matDialogClose",""]],hostVars:2,hostBindings:function(t,a){t&1&&_("click",function(c){return a._onButtonClick(c)}),t&2&&Y("aria-label",a.ariaLabel||null)("type",a.type)},inputs:{ariaLabel:[0,"aria-label","ariaLabel"],type:"type",dialogResult:[0,"mat-dialog-close","dialogResult"],_matDialogClose:[0,"matDialogClose","_matDialogClose"]},exportAs:["matDialogClose"],features:[we]})}return n})(),Y_=(()=>{class n{_dialogRef=m(Mn,{optional:!0});_elementRef=m(B);_dialog=m(An);constructor(){}ngOnInit(){this._dialogRef||(this._dialogRef=X_(this._elementRef,this._dialog.openDialogs)),this._dialogRef&&Promise.resolve().then(()=>{this._onAdd()})}ngOnDestroy(){this._dialogRef?._containerInstance&&Promise.resolve().then(()=>{this._onRemove()})}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n})}return n})(),qn=(()=>{class n extends Y_{id=m(xe).getId("mat-mdc-dialog-title-");_onAdd(){this._dialogRef._containerInstance?._addAriaLabelledBy?.(this.id)}_onRemove(){this._dialogRef?._containerInstance?._removeAriaLabelledBy?.(this.id)}static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["","mat-dialog-title",""],["","matDialogTitle",""]],hostAttrs:[1,"mat-mdc-dialog-title","mdc-dialog__title"],hostVars:1,hostBindings:function(t,a){t&2&&jt("id",a.id)},inputs:{id:"id"},exportAs:["matDialogTitle"],features:[ie]})}return n})(),Wn=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","mat-dialog-content",""],["mat-dialog-content"],["","matDialogContent",""]],hostAttrs:[1,"mat-mdc-dialog-content","mdc-dialog__content"],features:[Km([Lr])]})}return n})(),Qn=(()=>{class n extends Y_{align;_onAdd(){this._dialogRef._containerInstance?._updateActionSectionCount?.(1)}_onRemove(){this._dialogRef._containerInstance?._updateActionSectionCount?.(-1)}static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["","mat-dialog-actions",""],["mat-dialog-actions"],["","matDialogActions",""]],hostAttrs:[1,"mat-mdc-dialog-actions","mdc-dialog__actions"],hostVars:6,hostBindings:function(t,a){t&2&&k("mat-mdc-dialog-actions-align-start",a.align==="start")("mat-mdc-dialog-actions-align-center",a.align==="center")("mat-mdc-dialog-actions-align-end",a.align==="end")},inputs:{align:"align"},features:[ie]})}return n})();function X_(n,i){let e=n.nativeElement.parentElement;for(;e&&!e.classList.contains("mat-mdc-dialog-container");)e=e.parentElement;return e?i.find(t=>t.id===e.id):null}var Nt=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({providers:[An],imports:[H_,Sn,En,de]})}return n})();function K_(n){return n.estatusCodigo==="CANCELADA"||n.estatusCodigo==="REAGENDADA"}function ga(n){return["PROGRAMADA","CONFIRMADA","SIN_RESPUESTA"].includes(n.estatusCodigo??"")}var Yr=[{clave:"COMPARECENCIA",etiqueta:"Comparecencia"},{clave:"REVISION",etiqueta:"Revisi\xF3n de documentos"},{clave:"SEGUIMIENTO",etiqueta:"Seguimiento"}];function _a(n){return Yr.find(i=>i.clave===n)?.etiqueta??"Comparecencia"}var Z_=["09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30","13:00","13:30","14:00","14:30","15:00","15:30","16:00"];function Xr(n){let i=URL.createObjectURL(n);window.open(i,"_blank","noopener"),setTimeout(()=>URL.revokeObjectURL(i),6e4)}function Kr(n,i){let e=URL.createObjectURL(n),t=document.createElement("a");t.href=e,t.download=i,t.click(),setTimeout(()=>URL.revokeObjectURL(e),1e4)}function Ne(n,i){if(n instanceof fi&&n.error&&typeof n.error=="object"){let e=n.error.error;if(e&&n.status<500)return e}return i}function oD(n,i){if(n&1&&(l(0," a "),s(1,"strong"),l(2),r()),n&2){let e=h();d(2),g(e.data.denunciado)}}function rD(n,i){n&1&&(s(0,"mat-hint",4),l(1,"Escribe un correo v\xE1lido."),r())}function sD(n,i){if(n&1&&(s(0,"p",5)(1,"mat-icon",9),l(2,"info"),r(),l(3),r()),n&2){let e=h();d(3),N(" La solicitud anterior se envi\xF3 a ",e.data.correoAnterior,". Puedes corregir la direcci\xF3n. ")}}var cD=/^[^@\s]+@[^@\s]+\.[^@\s]+$/,ul=class n{constructor(i,e){this.data=i;this.dialogRef=e;this.correo=i.correoAnterior??""}data;dialogRef;correo;intentoEnviar=!1;get correoValido(){return cD.test(this.correo.trim())}enviar(){this.intentoEnviar=!0,this.correoValido&&this.dialogRef.close(this.correo.trim())}static \u0275fac=function(e){return new(e||n)(S(In),S(Mn))};static \u0275cmp=A({type:n,selectors:[["app-solicitud-denunciado-dialog"]],decls:23,vars:6,consts:[["mat-dialog-title",""],[1,"intro"],["appearance","outline",1,"campo"],["matInput","","type","email","id","correo-denunciado","placeholder","nombre@ipn.mx","cdkFocusInitial","",3,"ngModelChange","keydown.enter","ngModel"],[1,"error"],[1,"nota"],["align","end"],["mat-button","","mat-dialog-close",""],["mat-flat-button","",1,"primary-btn",3,"click"],[1,"inline-icon"]],template:function(e,t){e&1&&(s(0,"h2",0),l(1),r(),s(2,"mat-dialog-content")(3,"p",1),l(4," Se enviar\xE1 un correo "),v(5,oD,3,1),l(6," para pedirle su versi\xF3n de los hechos de la queja "),s(7,"strong"),l(8),r(),l(9,", con el enlace al formulario donde puede responder y adjuntar su credencial y evidencias. El correo le pide contestar a la brevedad. "),r(),s(10,"mat-form-field",2)(11,"mat-label"),l(12,"Correo del denunciado"),r(),s(13,"input",3),ge("ngModelChange",function(o){return fe(t.correo,o)||(t.correo=o),o}),_("keydown.enter",function(){return t.enviar()}),r(),v(14,rD,2,0,"mat-hint",4),r(),v(15,sD,4,1,"p",5),r(),s(16,"mat-dialog-actions",6)(17,"button",7),l(18,"Cancelar"),r(),s(19,"button",8),_("click",function(){return t.enviar()}),s(20,"mat-icon"),l(21,"send"),r(),l(22," Enviar correo "),r()()),e&2&&(d(),g(t.data.correoAnterior?"Reenviar solicitud al denunciado":"Solicitar respuesta del denunciado"),d(4),y(t.data.denunciado?5:-1),d(3),g(t.data.folioQueja),d(5),he("ngModel",t.correo),d(),y(t.intentoEnviar&&!t.correoValido?14:-1),d(),y(t.data.correoAnterior?15:-1))},dependencies:[Ot,ft,Tt,St,Nt,Vi,qn,Qn,Wn,Ge,Je,kt,ln,Jt,Ar,ze,Ve,mn,Gn],styles:[".intro[_ngcontent-%COMP%]{margin:0 0 16px;color:var(--negro-inst);line-height:1.5}.campo[_ngcontent-%COMP%]{width:100%}.error[_ngcontent-%COMP%]{color:var(--peligro)}.nota[_ngcontent-%COMP%]{display:flex;align-items:center;gap:6px;margin:4px 0 0;color:var(--texto-suave);font-size:13px}.inline-icon[_ngcontent-%COMP%]{font-size:18px;width:18px;height:18px}.primary-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important;border-radius:999px!important;font-weight:800}"]})};var _o=class n{constructor(i,e){this.api=i;this.http=e}api;http;denunciadoUrl=Lc.denunciadoApiUrl;listarSolicitudes(i){return this.api.get(`/expedientes/folio/${encodeURIComponent(i)}/denunciado/solicitudes`)}enviarSolicitud(i,e){return this.api.post(`/expedientes/folio/${encodeURIComponent(i)}/denunciado/solicitudes`,{correo:e})}listarRespuestas(i){return this.http.get(`${this.denunciadoUrl}/respuestas`,{params:new gn().set("folioQueja",i)})}descargarArchivo(i){return this.http.get(`${this.denunciadoUrl}/respuestas/archivos/${i}`,{responseType:"blob"})}static \u0275fac=function(e){return new(e||n)(U(Ue),U(_i))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var e0=(n,i)=>i.id;function lD(n,i){n&1&&(s(0,"p",6),l(1,"Respuesta anterior"),r())}function dD(n,i){n&1&&(s(0,"p",10),l(1,"No adjunt\xF3 archivos."),r())}function uD(n,i){if(n&1){let e=T();s(0,"li")(1,"mat-icon"),l(2),r(),s(3,"span",12)(4,"strong"),l(5),r(),s(6,"small"),l(7),r()(),s(8,"button",13),_("click",function(){let a=x(e).$implicit,o=h(3);return C(o.abrir(a))}),s(9,"mat-icon"),l(10,"open_in_new"),r(),l(11," Abrir "),r()()}if(n&2){let e=i.$implicit,t=h(3);d(2),g(e.tipo==="IDENTIFICACION"?"badge":"attach_file"),d(3),g(e.nombreArchivo),d(2),qe("",t.etiquetaArchivo(e)," \xB7 ",t.tamanio(e.tamanioBytes))}}function mD(n,i){if(n&1&&(s(0,"ul",11),te(1,uD,12,4,"li",null,e0),r()),n&2){let e=h().$implicit;d(),ne(e.archivos)}}function pD(n,i){if(n&1&&(s(0,"article",5),v(1,lD,2,0,"p",6),s(2,"div",7)(3,"div")(4,"span"),l(5,"Folio de la respuesta"),r(),s(6,"strong"),l(7),r()(),s(8,"div")(9,"span"),l(10,"Fecha"),r(),s(11,"strong"),l(12),Ro(13,"date"),r()(),s(14,"div")(15,"span"),l(16,"Nombre"),r(),s(17,"strong"),l(18),r()(),s(19,"div")(20,"span"),l(21,"Identificaci\xF3n"),r(),s(22,"strong"),l(23),r()(),s(24,"div")(25,"span"),l(26,"Unidad de procedencia"),r(),s(27,"strong"),l(28),r()()(),s(29,"div",8)(30,"span"),l(31,"Su versi\xF3n de los hechos"),r(),s(32,"p",9),l(33),r()(),s(34,"div",8)(35,"span"),l(36),r(),v(37,dD,2,0,"p",10)(38,mD,3,0,"ul",11),r()()),n&2){let e=i.$implicit,t=i.$index,a=h();k("anterior",t!==0),d(),y(t!==0?1:-1),d(6),g(e.folioRespuesta),d(5),g(To(13,11,e.fechaRegistro,"dd/MM/yyyy HH:mm")),d(6),g(a.nombreCompleto(e)),d(5),g(a.identificacion(e)),d(5),g(e.unidadProcedenciaClave),d(5),g(e.descripcionHechos),d(3),N("Archivos (",e.archivos.length,")"),d(),y(e.archivos.length===0?37:38)}}var ml=class n{constructor(i,e,t){this.data=i;this.denunciadoService=e;this.snackBar=t}data;denunciadoService;snackBar;nombreCompleto(i){return[i.nombre,i.apellido1,i.apellido2].filter(e=>!!e).join(" ")}identificacion(i){return`${i.tipoIdentificacion==="EMPLEADO"?"N\xFAm. de empleado":"Boleta"}: ${i.numeroIdentificacion}`}etiquetaArchivo(i){return i.tipo==="IDENTIFICACION"?"Credencial":"Evidencia"}tamanio(i){return i>=1024*1024?`${(i/(1024*1024)).toFixed(1)} MB`:`${Math.max(1,Math.round(i/1024))} KB`}abrir(i){this.denunciadoService.descargarArchivo(i.id).subscribe({next:e=>Xr(e),error:e=>{this.snackBar.open(Ne(e,"No fue posible abrir el archivo."),"Cerrar",{duration:3500})}})}static \u0275fac=function(e){return new(e||n)(S(In),S(_o),S(Mt))};static \u0275cmp=A({type:n,selectors:[["app-respuesta-denunciado-dialog"]],decls:12,vars:1,consts:[["mat-dialog-title",""],[1,"encabezado"],[1,"respuesta",3,"anterior"],["align","end"],["mat-flat-button","","mat-dialog-close","",1,"primary-btn"],[1,"respuesta"],[1,"etiqueta-anterior"],[1,"detail-grid"],[1,"section"],[1,"hechos"],[1,"vacio"],[1,"archivos"],[1,"archivo-nombre"],["mat-button","",3,"click"]],template:function(e,t){e&1&&(s(0,"h2",0),l(1,"Respuesta del denunciado"),r(),s(2,"mat-dialog-content")(3,"p",1),l(4,"Queja "),s(5,"strong"),l(6),r()(),te(7,pD,39,14,"article",2,e0),r(),s(9,"mat-dialog-actions",3)(10,"button",4),l(11,"Cerrar"),r()()),e&2&&(d(6),g(t.data.folioQueja),d(),ne(t.data.respuestas))},dependencies:[Nt,Vi,qn,Qn,Wn,Ge,Je,ze,Ve,Ft,ad],styles:[".encabezado[_ngcontent-%COMP%]{margin:0 0 14px;color:var(--texto-suave)}.respuesta[_ngcontent-%COMP%] + .respuesta[_ngcontent-%COMP%]{margin-top:22px;padding-top:18px;border-top:2px dashed var(--borde)}.etiqueta-anterior[_ngcontent-%COMP%]{margin:0 0 10px;color:var(--texto-suave);font-size:12px;font-weight:900;text-transform:uppercase}.detail-grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px}.detail-grid[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{display:grid;gap:4px;padding:12px;border:1px solid var(--borde);border-radius:12px;background:#fbfbfc;min-width:0}.detail-grid[_ngcontent-%COMP%]   span[_ngcontent-%COMP%], .section[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]{color:var(--texto-suave);font-size:12px;font-weight:900;text-transform:uppercase}.detail-grid[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--negro-inst);overflow-wrap:anywhere}.section[_ngcontent-%COMP%]{border-top:1px solid var(--borde);padding-top:14px;margin-top:14px}.hechos[_ngcontent-%COMP%]{margin:6px 0 0;color:var(--negro-inst);white-space:pre-wrap;line-height:1.5}.vacio[_ngcontent-%COMP%]{margin:6px 0 0;color:var(--texto-suave)}.archivos[_ngcontent-%COMP%]{list-style:none;margin:8px 0 0;padding:0;display:grid;gap:8px}.archivos[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px;padding:8px 10px;border:1px solid var(--borde);border-radius:12px}.archivo-nombre[_ngcontent-%COMP%]{display:grid;flex:1;min-width:0}.archivo-nombre[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--negro-inst);overflow-wrap:anywhere}.archivo-nombre[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:var(--texto-suave)}.primary-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important;border-radius:999px!important;font-weight:800}@media(max-width:600px){.detail-grid[_ngcontent-%COMP%]{grid-template-columns:1fr}}"]})};function hD(n,i){n&1&&yt(0,"div",2)}var fD=new E("MAT_PROGRESS_BAR_DEFAULT_OPTIONS");var pl=(()=>{class n{_elementRef=m(B);_ngZone=m(W);_changeDetectorRef=m(Z);_renderer=m(Se);_cleanupTransitionEnd;constructor(){let e=hu(),t=m(fD,{optional:!0});this._isNoopAnimation=e==="di-disabled",e==="reduced-motion"&&this._elementRef.nativeElement.classList.add("mat-progress-bar-reduced-motion"),t&&(t.color&&(this.color=this._defaultColor=t.color),this.mode=t.mode||this.mode)}_isNoopAnimation;get color(){return this._color||this._defaultColor}set color(e){this._color=e}_color;_defaultColor="primary";get value(){return this._value}set value(e){this._value=t0(e||0),this._changeDetectorRef.markForCheck()}_value=0;get bufferValue(){return this._bufferValue||0}set bufferValue(e){this._bufferValue=t0(e||0),this._changeDetectorRef.markForCheck()}_bufferValue=0;animationEnd=new z;get mode(){return this._mode}set mode(e){this._mode=e,this._changeDetectorRef.markForCheck()}_mode="determinate";ngAfterViewInit(){this._ngZone.runOutsideAngular(()=>{this._cleanupTransitionEnd=this._renderer.listen(this._elementRef.nativeElement,"transitionend",this._transitionendHandler)})}ngOnDestroy(){this._cleanupTransitionEnd?.()}_getPrimaryBarTransform(){return`scaleX(${this._isIndeterminate()?1:this.value/100})`}_getBufferBarFlexBasis(){return`${this.mode==="buffer"?this.bufferValue:100}%`}_isIndeterminate(){return this.mode==="indeterminate"||this.mode==="query"}_transitionendHandler=e=>{this.animationEnd.observers.length===0||!e.target||!e.target.classList.contains("mdc-linear-progress__primary-bar")||(this.mode==="determinate"||this.mode==="buffer")&&this._ngZone.run(()=>this.animationEnd.next({value:this.value}))};static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-progress-bar"]],hostAttrs:["role","progressbar","aria-valuemin","0","aria-valuemax","100","tabindex","-1",1,"mat-mdc-progress-bar","mdc-linear-progress"],hostVars:10,hostBindings:function(t,a){t&2&&(Y("aria-valuenow",a._isIndeterminate()?null:a.value)("mode",a.mode),ve("mat-"+a.color),k("_mat-animation-noopable",a._isNoopAnimation)("mdc-linear-progress--animation-ready",!a._isNoopAnimation)("mdc-linear-progress--indeterminate",a._isIndeterminate()))},inputs:{color:"color",value:[2,"value","value",lt],bufferValue:[2,"bufferValue","bufferValue",lt],mode:"mode"},outputs:{animationEnd:"animationEnd"},exportAs:["matProgressBar"],decls:7,vars:5,consts:[["aria-hidden","true",1,"mdc-linear-progress__buffer"],[1,"mdc-linear-progress__buffer-bar"],[1,"mdc-linear-progress__buffer-dots"],["aria-hidden","true",1,"mdc-linear-progress__bar","mdc-linear-progress__primary-bar"],[1,"mdc-linear-progress__bar-inner"],["aria-hidden","true",1,"mdc-linear-progress__bar","mdc-linear-progress__secondary-bar"]],template:function(t,a){t&1&&(Te(0,"div",0),yt(1,"div",1),v(2,hD,1,0,"div",2),Be(),Te(3,"div",3),yt(4,"span",4),Be(),Te(5,"div",5),yt(6,"span",4),Be()),t&2&&(d(),Gt("flex-basis",a._getBufferBarFlexBasis()),d(),y(a.mode==="buffer"?2:-1),d(),Gt("transform",a._getPrimaryBarTransform()))},styles:[`.mat-mdc-progress-bar {
  --mat-progress-bar-animation-multiplier: 1;
  display: block;
  text-align: start;
}
.mat-mdc-progress-bar[mode=query] {
  transform: scaleX(-1);
}
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__buffer-dots,
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__primary-bar,
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__secondary-bar,
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__bar-inner.mdc-linear-progress__bar-inner {
  animation: none;
}
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__primary-bar,
.mat-mdc-progress-bar._mat-animation-noopable .mdc-linear-progress__buffer-bar {
  transition: transform 1ms;
}

.mat-progress-bar-reduced-motion {
  --mat-progress-bar-animation-multiplier: 2;
}

.mdc-linear-progress {
  position: relative;
  width: 100%;
  transform: translateZ(0);
  outline: 1px solid transparent;
  overflow-x: hidden;
  transition: opacity 250ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  height: max(var(--mat-progress-bar-track-height, 4px), var(--mat-progress-bar-active-indicator-height, 4px));
}
@media (forced-colors: active) {
  .mdc-linear-progress {
    outline-color: CanvasText;
  }
}

.mdc-linear-progress__bar {
  position: absolute;
  top: 0;
  bottom: 0;
  margin: auto 0;
  width: 100%;
  animation: none;
  transform-origin: top left;
  transition: transform 250ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  height: var(--mat-progress-bar-active-indicator-height, 4px);
}
.mdc-linear-progress--indeterminate .mdc-linear-progress__bar {
  transition: none;
}
[dir=rtl] .mdc-linear-progress__bar {
  right: 0;
  transform-origin: center right;
}

.mdc-linear-progress__bar-inner {
  display: inline-block;
  position: absolute;
  width: 100%;
  animation: none;
  border-top-style: solid;
  border-color: var(--mat-progress-bar-active-indicator-color, var(--mat-sys-primary));
  border-top-width: var(--mat-progress-bar-active-indicator-height, 4px);
}

.mdc-linear-progress__buffer {
  display: flex;
  position: absolute;
  top: 0;
  bottom: 0;
  margin: auto 0;
  width: 100%;
  overflow: hidden;
  height: var(--mat-progress-bar-track-height, 4px);
  border-radius: var(--mat-progress-bar-track-shape, var(--mat-sys-corner-none));
}

.mdc-linear-progress__buffer-dots {
  background-image: radial-gradient(circle, var(--mat-progress-bar-track-color, var(--mat-sys-surface-variant)) calc(var(--mat-progress-bar-track-height, 4px) / 2), transparent 0);
  background-repeat: repeat-x;
  background-size: calc(calc(var(--mat-progress-bar-track-height, 4px) / 2) * 5);
  background-position: left;
  flex: auto;
  transform: rotate(180deg);
  animation: mdc-linear-progress-buffering calc(250ms * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
@media (forced-colors: active) {
  .mdc-linear-progress__buffer-dots {
    background-color: ButtonBorder;
  }
}
[dir=rtl] .mdc-linear-progress__buffer-dots {
  animation: mdc-linear-progress-buffering-reverse calc(250ms * var(--mat-progress-bar-animation-multiplier)) infinite linear;
  transform: rotate(0);
}

.mdc-linear-progress__buffer-bar {
  flex: 0 1 100%;
  transition: flex-basis 250ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  background-color: var(--mat-progress-bar-track-color, var(--mat-sys-surface-variant));
}

.mdc-linear-progress__primary-bar {
  transform: scaleX(0);
}
.mdc-linear-progress--indeterminate .mdc-linear-progress__primary-bar {
  left: -145.166611%;
}
.mdc-linear-progress--indeterminate.mdc-linear-progress--animation-ready .mdc-linear-progress__primary-bar {
  animation: mdc-linear-progress-primary-indeterminate-translate calc(2s * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
.mdc-linear-progress--indeterminate.mdc-linear-progress--animation-ready .mdc-linear-progress__primary-bar > .mdc-linear-progress__bar-inner {
  animation: mdc-linear-progress-primary-indeterminate-scale calc(2s * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
[dir=rtl] .mdc-linear-progress.mdc-linear-progress--animation-ready .mdc-linear-progress__primary-bar {
  animation-name: mdc-linear-progress-primary-indeterminate-translate-reverse;
}
[dir=rtl] .mdc-linear-progress.mdc-linear-progress--indeterminate .mdc-linear-progress__primary-bar {
  right: -145.166611%;
  left: auto;
}

.mdc-linear-progress__secondary-bar {
  display: none;
}
.mdc-linear-progress--indeterminate .mdc-linear-progress__secondary-bar {
  left: -54.888891%;
  display: block;
}
.mdc-linear-progress--indeterminate.mdc-linear-progress--animation-ready .mdc-linear-progress__secondary-bar {
  animation: mdc-linear-progress-secondary-indeterminate-translate calc(2s * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
.mdc-linear-progress--indeterminate.mdc-linear-progress--animation-ready .mdc-linear-progress__secondary-bar > .mdc-linear-progress__bar-inner {
  animation: mdc-linear-progress-secondary-indeterminate-scale calc(2s * var(--mat-progress-bar-animation-multiplier)) infinite linear;
}
[dir=rtl] .mdc-linear-progress.mdc-linear-progress--animation-ready .mdc-linear-progress__secondary-bar {
  animation-name: mdc-linear-progress-secondary-indeterminate-translate-reverse;
}
[dir=rtl] .mdc-linear-progress.mdc-linear-progress--indeterminate .mdc-linear-progress__secondary-bar {
  right: -54.888891%;
  left: auto;
}

@keyframes mdc-linear-progress-buffering {
  from {
    transform: rotate(180deg) translateX(calc(var(--mat-progress-bar-track-height, 4px) * -2.5));
  }
}
@keyframes mdc-linear-progress-primary-indeterminate-translate {
  0% {
    transform: translateX(0);
  }
  20% {
    animation-timing-function: cubic-bezier(0.5, 0, 0.701732, 0.495819);
    transform: translateX(0);
  }
  59.15% {
    animation-timing-function: cubic-bezier(0.302435, 0.381352, 0.55, 0.956352);
    transform: translateX(83.67142%);
  }
  100% {
    transform: translateX(200.611057%);
  }
}
@keyframes mdc-linear-progress-primary-indeterminate-scale {
  0% {
    transform: scaleX(0.08);
  }
  36.65% {
    animation-timing-function: cubic-bezier(0.334731, 0.12482, 0.785844, 1);
    transform: scaleX(0.08);
  }
  69.15% {
    animation-timing-function: cubic-bezier(0.06, 0.11, 0.6, 1);
    transform: scaleX(0.661479);
  }
  100% {
    transform: scaleX(0.08);
  }
}
@keyframes mdc-linear-progress-secondary-indeterminate-translate {
  0% {
    animation-timing-function: cubic-bezier(0.15, 0, 0.515058, 0.409685);
    transform: translateX(0);
  }
  25% {
    animation-timing-function: cubic-bezier(0.31033, 0.284058, 0.8, 0.733712);
    transform: translateX(37.651913%);
  }
  48.35% {
    animation-timing-function: cubic-bezier(0.4, 0.627035, 0.6, 0.902026);
    transform: translateX(84.386165%);
  }
  100% {
    transform: translateX(160.277782%);
  }
}
@keyframes mdc-linear-progress-secondary-indeterminate-scale {
  0% {
    animation-timing-function: cubic-bezier(0.205028, 0.057051, 0.57661, 0.453971);
    transform: scaleX(0.08);
  }
  19.15% {
    animation-timing-function: cubic-bezier(0.152313, 0.196432, 0.648374, 1.004315);
    transform: scaleX(0.457104);
  }
  44.15% {
    animation-timing-function: cubic-bezier(0.257759, -0.003163, 0.211762, 1.38179);
    transform: scaleX(0.72796);
  }
  100% {
    transform: scaleX(0.08);
  }
}
@keyframes mdc-linear-progress-primary-indeterminate-translate-reverse {
  0% {
    transform: translateX(0);
  }
  20% {
    animation-timing-function: cubic-bezier(0.5, 0, 0.701732, 0.495819);
    transform: translateX(0);
  }
  59.15% {
    animation-timing-function: cubic-bezier(0.302435, 0.381352, 0.55, 0.956352);
    transform: translateX(-83.67142%);
  }
  100% {
    transform: translateX(-200.611057%);
  }
}
@keyframes mdc-linear-progress-secondary-indeterminate-translate-reverse {
  0% {
    animation-timing-function: cubic-bezier(0.15, 0, 0.515058, 0.409685);
    transform: translateX(0);
  }
  25% {
    animation-timing-function: cubic-bezier(0.31033, 0.284058, 0.8, 0.733712);
    transform: translateX(-37.651913%);
  }
  48.35% {
    animation-timing-function: cubic-bezier(0.4, 0.627035, 0.6, 0.902026);
    transform: translateX(-84.386165%);
  }
  100% {
    transform: translateX(-160.277782%);
  }
}
@keyframes mdc-linear-progress-buffering-reverse {
  from {
    transform: translateX(-10px);
  }
}
`],encapsulation:2,changeDetection:0})}return n})();function t0(n,i=0,e=100){return Math.max(i,Math.min(e,n))}var hl=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[de]})}return n})();var gD=["golpe","golpe\xF3","agred","amenaz","acos","hostig","humill","insult","grit","discrimin","ofens","violen","abus","intimid","burl","exhib","reprob","castig","extors","sexual","miedo","lesion","empuj","represal","toc","oblig","despid","in\xFAtil","inutil","denigr","excluy","neg\xF3","nego"];function fl(n){let i=(n??"").replace(/\s+/g," ").trim();if(!i)return{resumen:"",frasesImpacto:[]};let e=i.split(/(?<=[.!?;])\s+/).map(u=>u.trim()).filter(u=>u.length>12);if(e.length===0)return{resumen:mm(i,380),frasesImpacto:[]};let t=e.map((u,p)=>({oracion:u,indice:p,puntos:_D(u)})),a=t.filter(u=>u.puntos>0).sort((u,p)=>p.puntos-u.puntos||u.indice-p.indice),o=[t[0]];a.length>0&&a[0].indice!==0?o.push(a[0]):t.length>1&&o.push(t[1]);let c=o.sort((u,p)=>u.indice-p.indice).map(u=>u.oracion).join(" ");return{resumen:mm(c,380),frasesImpacto:a.slice(0,3).map(u=>mm(u.oracion,220))}}function _D(n){let i=n.toLowerCase();return gD.reduce((e,t)=>e+(i.includes(t)?1:0),0)}function mm(n,i){return n.length<=i?n:n.slice(0,i-1).trimEnd()+"\u2026"}var bo=class n{constructor(i){this.api=i}api;resumir(i){return this.api.post("/resumen",{texto:i})}static \u0275fac=function(e){return new(e||n)(U(Ue))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};function bD(n,i){if(n&1&&l(0),n&2){let e=h();N(" \xB7 ",e.data.asunto," ")}}function vD(n,i){n&1&&(s(0,"p",2),l(1,"La queja no tiene narrativa para resumir."),r())}function yD(n,i){n&1&&(s(0,"div",3),H(1,"mat-progress-bar",6),s(2,"p")(3,"strong"),l(4,"Generando el resumen con el modelo\u2026"),r(),l(5," Puede tardar hasta 2 minutos. Si cierras este cuadro, el resumen se seguir\xE1 generando y aparecer\xE1 de inmediato la pr\xF3xima vez. "),r()())}function xD(n,i){n&1&&(s(0,"p",2),l(1,"El modelo no devolvi\xF3 fragmentos."),r())}function CD(n,i){if(n&1&&(s(0,"li")(1,"mat-icon"),l(2,"format_quote"),r(),s(3,"span"),l(4),r()()),n&2){let e=i.$implicit;d(4),g(e)}}function wD(n,i){if(n&1&&(s(0,"ul",10),te(1,CD,5,1,"li",null,Fn),r()),n&2){let e=h(2);d(),ne(e.modelo.fragmentos)}}function DD(n,i){if(n&1&&(s(0,"div",7)(1,"mat-icon"),l(2,"rate_review"),r(),s(3,"span")(4,"strong"),l(5,"Borrador del modelo."),r(),l(6," Es una sugerencia para apoyar el an\xE1lisis: rev\xEDsalo contra la narrativa antes de usarlo. "),r()(),s(7,"section")(8,"span",8),l(9,"Resumen propuesto"),r(),s(10,"p",9),l(11),r()(),s(12,"section")(13,"span",8),l(14,"Fragmentos clave de la queja"),r(),v(15,xD,2,0,"p",2)(16,wD,3,0,"ul",10),r()),n&2){let e=h();d(11),g(e.modelo.resumen),d(4),y(e.modelo.fragmentos.length===0?15:16)}}function ED(n,i){n&1&&(s(0,"div",11)(1,"mat-icon"),l(2,"science"),r(),s(3,"span")(4,"strong"),l(5,"Simulado."),r(),l(6," El modelo de resumen no est\xE1 disponible en este momento; este resumen es una aproximaci\xF3n calculada en el navegador. "),r()())}function SD(n,i){n&1&&(s(0,"p",2),l(1,"No se identificaron frases de impacto en la narrativa."),r())}function kD(n,i){if(n&1&&(s(0,"li")(1,"mat-icon"),l(2,"format_quote"),r(),s(3,"span"),l(4),r()()),n&2){let e=i.$implicit;d(4),g(e)}}function MD(n,i){if(n&1&&(s(0,"ul",10),te(1,kD,5,1,"li",null,Fn),r()),n&2){let e=h(2);d(),ne(e.simulado.frasesImpacto)}}function ID(n,i){if(n&1&&(v(0,ED,7,0,"div",11),s(1,"section")(2,"span",8),l(3,"Resumen propuesto"),r(),s(4,"p",9),l(5),r()(),s(6,"section")(7,"span",8),l(8,"Frases de impacto"),r(),v(9,SD,2,0,"p",2)(10,MD,3,0,"ul",10),r()),n&2){let e=h();y(e.sinModelo?0:-1),d(5),g(e.simulado.resumen),d(4),y(e.simulado.frasesImpacto.length===0?9:10)}}var vo=class n{constructor(i,e,t){this.data=i;this.resumenService=e;this.cdr=t;this.simulado=fl(i.texto)}data;resumenService;cdr;simulado;modelo=null;cargando=!1;sinModelo=!1;peticion;ngOnInit(){!this.simulado.resumen||!this.data.texto||(this.cargando=!0,this.peticion=this.resumenService.resumir(this.data.texto).subscribe({next:i=>{this.modelo=i,this.cargando=!1,this.cdr.detectChanges()},error:()=>{this.sinModelo=!0,this.cargando=!1,this.cdr.detectChanges()}}))}ngOnDestroy(){this.peticion?.unsubscribe()}static \u0275fac=function(e){return new(e||n)(S(In),S(bo),S(Z))};static \u0275cmp=A({type:n,selectors:[["app-resumen-dialog"]],decls:14,vars:3,consts:[["mat-dialog-title",""],[1,"encabezado"],[1,"vacio"],[1,"generando"],["align","end"],["mat-flat-button","","mat-dialog-close","",1,"primary-btn"],["mode","indeterminate"],[1,"simulado","revision"],[1,"etiqueta"],[1,"resumen"],[1,"frases"],[1,"simulado"]],template:function(e,t){e&1&&(s(0,"h2",0),l(1,"Resumen de la queja"),r(),s(2,"mat-dialog-content")(3,"p",1)(4,"strong"),l(5),r(),v(6,bD,1,1),r(),v(7,vD,2,0,"p",2)(8,yD,6,0,"div",3)(9,DD,17,2)(10,ID,11,3),r(),s(11,"mat-dialog-actions",4)(12,"button",5),l(13,"Cerrar"),r()()),e&2&&(d(5),g(t.data.folio),d(),y(t.data.asunto?6:-1),d(),y(t.simulado.resumen?t.cargando?8:t.modelo?9:10:7))},dependencies:[Nt,Vi,qn,Qn,Wn,Ge,Je,ze,Ve,hl,pl],styles:[".encabezado[_ngcontent-%COMP%]{margin:0 0 12px;color:var(--texto-suave)}.encabezado[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--negro-inst)}.simulado[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:8px;padding:10px 14px;border-radius:10px;background:#fff4e5;color:#7a4800;font-size:13px;margin-bottom:16px}.simulado.revision[_ngcontent-%COMP%]{background:#eef4ff;color:#1e3a8a}.generando[_ngcontent-%COMP%]{display:grid;gap:12px;margin:8px 0 4px}.generando[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;color:var(--texto-suave);font-size:13px;line-height:1.5}.generando[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{display:block;color:var(--negro-inst);font-size:14px}section[_ngcontent-%COMP%]{margin-top:14px}.etiqueta[_ngcontent-%COMP%]{display:block;color:var(--guinda);font-size:12px;font-weight:900;text-transform:uppercase;letter-spacing:.05em}.resumen[_ngcontent-%COMP%]{margin:6px 0 0;color:var(--negro-inst);line-height:1.5}.frases[_ngcontent-%COMP%]{list-style:none;margin:8px 0 0;padding:0;display:grid;gap:8px}.frases[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{display:flex;gap:8px;padding:10px 12px;border-left:4px solid var(--guinda);border-radius:8px;background:var(--guinda-suave);color:var(--negro-inst);font-style:italic}.frases[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{color:var(--guinda);flex-shrink:0}.vacio[_ngcontent-%COMP%]{color:var(--texto-suave)}.primary-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important;border-radius:999px!important;font-weight:800}"]})};function AD(n,i){if(n&1&&l(0),n&2){let e=h();N(" \xB7 Similitud ",e.a.similitud,"% ")}}function RD(n,i){if(n&1&&(s(0,"span",9),l(1),r()),n&2){let e=i.$implicit;d(),g(e)}}function TD(n,i){if(n&1&&(s(0,"div",2),te(1,RD,2,1,"span",9,Ke),r()),n&2){let e=h();d(),ne(e.a.coincidencias)}}function OD(n,i){if(n&1&&(s(0,"div")(1,"span"),l(2,"Resultado"),r(),s(3,"strong"),l(4),r()()),n&2){let e=h();d(4),g(e.a.resultado)}}function PD(n,i){if(n&1&&(s(0,"div")(1,"span"),l(2,"Guardado por"),r(),s(3,"strong"),l(4),r()(),s(5,"div")(6,"span"),l(7,"Encontrado con"),r(),s(8,"strong"),l(9),r()()),n&2){let e=h();d(4),qe("",e.a.analistaNombre," \xB7 ",e.formatearFechaHora(e.a.fechaRegistro)),d(5),g(e.fuente)}}function FD(n,i){if(n&1){let e=T();s(0,"button",10),_("click",function(){x(e);let a=h();return C(a.verResumen())}),s(1,"mat-icon"),l(2,"summarize"),r(),l(3," Resumen "),r()}}function ND(n,i){if(n&1){let e=T();s(0,"button",10),_("click",function(){x(e);let a=h();return C(a.verExpediente())}),s(1,"mat-icon"),l(2,"open_in_new"),r(),l(3," Ver expediente "),r()}}var yo=class n{constructor(i,e,t,a){this.a=i;this.dialogRef=e;this.dialog=t;this.router=a}a;dialogRef;dialog;router;formatearFecha=oi;formatearFechaHora=Hn;get narrativa(){return this.a.descripcion||this.a.extracto||""}get origen(){return this.a.origen==="HISTORICO"?"Caso hist\xF3rico":"Queja del sistema"}get fuente(){switch(this.a.fuente){case"MANUAL":return"B\xFAsqueda manual";case"MODELO":return"Modelo";case"REGLAS_PROVISIONAL":return"Motor provisional";default:return this.a.fuente??""}}verResumen(){this.dialog.open(vo,{width:"640px",data:{folio:this.a.folioQueja,asunto:this.a.asunto,texto:this.narrativa}})}verExpediente(){this.dialogRef.close(),this.router.navigate(["/expediente",this.a.folioPrimerContacto])}static \u0275fac=function(e){return new(e||n)(S(In),S(Mn),S(An),S(We))};static \u0275cmp=A({type:n,selectors:[["app-antecedente-detalle-dialog"]],decls:47,vars:15,consts:[["mat-dialog-title",""],[1,"encabezado"],[1,"coincidencias"],[1,"grid"],[1,"etiqueta"],[1,"narrativa"],["align","end"],["mat-stroked-button",""],["mat-flat-button","","mat-dialog-close","",1,"primary-btn"],[1,"coincidencia"],["mat-stroked-button","",3,"click"]],template:function(e,t){e&1&&(s(0,"h2",0),l(1),r(),s(2,"mat-dialog-content")(3,"p",1)(4,"strong"),l(5),r(),l(6),v(7,AD,1,1),r(),v(8,TD,3,0,"div",2),s(9,"div",3)(10,"div")(11,"span"),l(12,"Quejoso"),r(),s(13,"strong"),l(14),r()(),s(15,"div")(16,"span"),l(17,"Denunciado"),r(),s(18,"strong"),l(19),r()(),s(20,"div")(21,"span"),l(22,"Fecha"),r(),s(23,"strong"),l(24),r()(),s(25,"div")(26,"span"),l(27,"Unidad acad\xE9mica"),r(),s(28,"strong"),l(29),r()(),s(30,"div")(31,"span"),l(32,"Estatus"),r(),s(33,"strong"),l(34),r()(),v(35,OD,5,1,"div"),v(36,PD,10,3),r(),s(37,"section")(38,"span",4),l(39,"Narrativa de los hechos"),r(),s(40,"p",5),l(41),r()()(),s(42,"mat-dialog-actions",6),v(43,FD,4,0,"button",7),v(44,ND,4,0,"button",7),s(45,"button",8),l(46,"Cerrar"),r()()),e&2&&(d(),g(t.a.asunto||"Queja sin asunto"),d(4),g(t.a.folioQueja),d(),N(" \xB7 ",t.origen," "),d(),y(t.a.similitud!=null?7:-1),d(),y(t.a.coincidencias!=null&&t.a.coincidencias.length?8:-1),d(6),g(t.a.nombreQuejoso||"\u2014"),d(5),g(t.a.nombreDenunciado||"\u2014"),d(5),g(t.formatearFecha(t.a.fecha)||"\u2014"),d(5),g(t.a.unidadAcademica||"\u2014"),d(5),g(t.a.estatus||"\u2014"),d(),y(t.a.resultado?35:-1),d(),y(t.a.analistaNombre?36:-1),d(5),g(t.narrativa||"Sin narrativa registrada."),d(2),y(t.narrativa?43:-1),d(),y(t.a.folioPrimerContacto?44:-1))},dependencies:[Nt,Vi,qn,Qn,Wn,Ge,Je,ze,Ve],styles:[".encabezado[_ngcontent-%COMP%]{margin:0 0 10px;color:var(--texto-suave)}.encabezado[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--negro-inst)}.coincidencias[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px}.coincidencia[_ngcontent-%COMP%]{padding:2px 10px;border-radius:999px;background:var(--guinda-suave);color:var(--guinda);font-size:12px;font-weight:700}.grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:10px}.grid[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{display:grid;gap:2px;padding:10px 12px;border:1px solid var(--borde);border-radius:10px;background:#fbfbfc}.grid[_ngcontent-%COMP%]   span[_ngcontent-%COMP%], .etiqueta[_ngcontent-%COMP%]{color:var(--texto-suave);font-size:12px;font-weight:900;text-transform:uppercase}.grid[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--negro-inst)}section[_ngcontent-%COMP%]{margin-top:16px}.narrativa[_ngcontent-%COMP%]{margin:6px 0 0;color:var(--negro-inst);line-height:1.5;white-space:pre-line}.primary-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important;border-radius:999px!important;font-weight:800}@media(max-width:700px){.grid[_ngcontent-%COMP%]{grid-template-columns:1fr}}"]})};var Yn=class n{constructor(i){this.api=i}api;obtenerPorFolio(i){return this.api.get(`/expedientes/folio/${encodeURIComponent(i)}`)}iniciarAnalisis(i){return this.api.post(`/expedientes/folio/${encodeURIComponent(i)}/iniciar-analisis`,{})}descargarEvidencia(i){return this.api.getBlob(`/evidencias/${i}`)}mapearADetalle(i){return{expedienteId:i.expedienteId,folio:i.folio,folioOrigen:i.folioOrigen,folioSubdefensoria:i.folioSubdefensoria,asunto:i.tema??"",fechaIngreso:oi(i.fechaRecepcion),estatus:Oi(i.estatus),estatusCodigo:so(i.estatus),prioridad:Nc(i.prioridad),narrativa:i.descripcionHechos??"",fechaInicioAnalisis:i.fechaInicioAnalisis,analistaAnalisisNombre:i.analistaAnalisisNombre,quejoso:{nombre:i.quejoso?.nombreCompleto??"",boleta:i.quejoso?.tipoUsuario??"",correo:i.quejoso?.correo??"",telefono:i.quejoso?.telefono??"",unidadAcademica:i.quejoso?.unidadAcademica??""},datosQueja:i.datosQueja,evidencias:(i.evidencias??[]).map(e=>({id:e.id,nombre:e.nombreArchivo,tipo:e.tipoArchivo})),notas:i.notas??[]}}static \u0275fac=function(e){return new(e||n)(U(Ue))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var xo=class n{constructor(i){this.api=i}api;analista$;obtener(){return this.analista$??=this.api.get("/analistas/yo").pipe(ko(1)),this.analista$}static \u0275fac=function(e){return new(e||n)(U(Ue))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var LD=(n,i)=>i.clave,BD=(n,i)=>i.folio;function jD(n,i){if(n&1&&H(0,"input",11),n&2){let e=h();P("value",e.folio)}}function VD(n,i){if(n&1&&(s(0,"option",16),l(1),r()),n&2){let e=i.$implicit;P("value",e.folio),d(),qe("",e.folio," \xB7 ",e.nombreQuejoso)}}function zD(n,i){if(n&1){let e=T();s(0,"select",40),_("ngModelChange",function(a){x(e);let o=h();return C(o.elegirExpediente(a))}),s(1,"option",41),l(2,"Selecciona un expediente"),r(),te(3,VD,2,3,"option",16,BD),r()}if(n&2){let e=h();P("ngModel",e.folio),d(3),ne(e.expedientes)}}function UD(n,i){if(n&1&&(s(0,"option",16),l(1),r()),n&2){let e=i.$implicit;P("value",e.clave),d(),g(e.etiqueta)}}function HD(n,i){if(n&1&&(s(0,"span",29),l(1),r()),n&2){let e=i.$implicit;d(),g(e)}}function $D(n,i){n&1&&H(0,"span")}function GD(n,i){if(n&1){let e=T();s(0,"button",43),_("click",function(){x(e);let a=h().$implicit,o=h();return C(o.elegirFecha(o.isoDe(a)))}),l(1),r()}if(n&2){let e=h().$implicit,t=h();k("sel",t.isoDe(e)===t.fecha)("hoy",t.isoDe(e)===t.hoyIso),P("disabled",t.diaInhabil(e)),d(),g(e)}}function qD(n,i){if(n&1&&v(0,$D,1,0,"span")(1,GD,2,6,"button",42),n&2){let e=i.$implicit;y(e===null?0:1)}}function WD(n,i){if(n&1){let e=T();s(0,"button",44),_("click",function(){let a=x(e).$implicit,o=h();return C(o.hora=a)}),l(1),r()}if(n&2){let e=i.$implicit,t=h();ve("nc-hora "+t.estadoHorario(e)),k("sel",t.hora===e),P("disabled",t.estadoHorario(e)!=="libre")("title",t.estadoHorario(e)==="ocupado"?"Ya tienes una cita a esta hora":t.estadoHorario(e)==="no-disponible"?"Horario no disponible":"Disponible"),d(),g(e)}}var QD=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"],Co=class n{constructor(i,e,t,a,o,c){this.agenda=i;this.bandeja=e;this.expedientesService=t;this.analista=a;this.snackBar=o;this.cdr=c}agenda;bandeja;expedientesService;analista;snackBar;cdr;folio="";cita;fechaInicial="";guardada=new z;cerrar=new z;categorias=Yr;horarios=Z_;diasSemana=["Dom","Lun","Mar","Mi\xE9","Jue","Vie","S\xE1b"];expedientes=[];nombreQuejoso="";categoria="COMPARECENCIA";modalidad="PRESENCIAL";motivo="";fecha="";hora="";guardando=!1;anio=new Date().getFullYear();mes=new Date().getMonth();citasDelDia=[];analistaId;ngOnInit(){this.analista.obtener().subscribe({next:e=>{this.analistaId=e.id,this.cdr.detectChanges()}}),this.cita?(this.folio=this.cita.folio,this.nombreQuejoso=this.cita.quejoso,this.categoria=this.cita.categoria??"COMPARECENCIA",this.modalidad=this.cita.tipo==="Virtual"?"VIRTUAL":"PRESENCIAL",this.motivo=this.cita.motivo):(this.bandeja.obtenerBandeja().subscribe({next:e=>{this.expedientes=e.filter(t=>Fc(t.estatusCodigo)&&(!t.tieneCitaActiva||t.folio===this.folio)),this.cdr.detectChanges()}}),this.folio&&this.elegirExpediente(this.folio));let i=this.fechaInicial&&this.fechaInicial>=this.hoyIso?this.fechaInicial:this.siguienteDiaHabil();this.elegirFecha(i)}get reagendando(){return!!this.cita}alEscape(){this.guardando||this.cerrar.emit()}elegirExpediente(i){this.folio=i;let e=this.expedientes.find(t=>t.folio===i);this.nombreQuejoso=e?.nombreQuejoso??"",this.expedientesService.obtenerPorFolio(i).subscribe({next:t=>{this.nombreQuejoso=t.quejoso?.nombreCompleto??this.nombreQuejoso,this.cdr.detectChanges()}})}get hoyIso(){return pm(new Date)}get tituloMes(){return`${QD[this.mes]} ${this.anio}`}get celdas(){let i=new Date(this.anio,this.mes,1).getDay(),e=new Date(this.anio,this.mes+1,0).getDate();return[...Array(i).fill(null),...Array.from({length:e},(t,a)=>a+1)]}isoDe(i){return pm(new Date(this.anio,this.mes,i))}diaInhabil(i){let e=new Date(this.anio,this.mes,i);return e.getDay()===0||e.getDay()===6||this.isoDe(i)<this.hoyIso}mover(i){let e=new Date(this.anio,this.mes+i,1);this.anio=e.getFullYear(),this.mes=e.getMonth()}elegirFecha(i){if(!i)return;this.fecha=i;let[e,t]=i.split("-").map(Number);this.anio=e,this.mes=t-1,this.hora=this.estadoHorario(this.hora)==="libre"?this.hora:"",this.agenda.obtenerAgendaDia(i).subscribe({next:a=>{this.citasDelDia=a,this.estadoHorario(this.hora)!=="libre"&&(this.hora=""),this.cdr.detectChanges()},error:()=>{this.citasDelDia=[],this.cdr.detectChanges()}})}estadoHorario(i){if(!i||!this.fecha)return"no-disponible";let e=new Date(this.fecha+"T"+i+":00");return e.getDay()===0||e.getDay()===6||e.getTime()<=Date.now()?"no-disponible":this.citasDelDia.some(a=>a.hora===i&&ga(a)&&a.id!==this.cita?.id&&(this.analistaId===void 0||a.analistaId===this.analistaId))?"ocupado":"libre"}guardar(){if(!this.folio||!this.fecha||!this.hora||!this.motivo.trim()){this.snackBar.open("Completa el expediente, el motivo, la fecha y el horario.","Cerrar",{duration:3e3});return}this.guardando=!0,(this.cita?.id?this.agenda.reagendarCita(this.cita.id,{fechaCita:this.fecha,horaCita:this.hora,tipoCita:this.modalidad,categoria:this.categoria,motivo:this.motivo.trim()}):this.agenda.crearCita({folio:this.folio,quejosoNombre:this.nombreQuejoso,fechaCita:this.fecha,horaCita:this.hora,tipoCita:this.modalidad,categoria:this.categoria,motivo:this.motivo.trim()})).subscribe({next:e=>{this.guardando=!1,this.snackBar.open(this.reagendando?"Cita reagendada. Se avis\xF3 al quejoso.":"Cita agendada. Se avis\xF3 al quejoso.","Cerrar",{duration:3500}),this.guardada.emit(e)},error:e=>{this.guardando=!1,this.cdr.detectChanges(),this.snackBar.open(Ne(e,"No fue posible guardar la cita."),"Cerrar",{duration:4500})}})}siguienteDiaHabil(){let i=new Date;for(i.getHours()>=16&&i.setDate(i.getDate()+1);i.getDay()===0||i.getDay()===6;)i.setDate(i.getDate()+1);return pm(i)}static \u0275fac=function(e){return new(e||n)(S($n),S(Pi),S(Yn),S(xo),S(Mt),S(Z))};static \u0275cmp=A({type:n,selectors:[["app-nueva-cita"]],hostBindings:function(e,t){e&1&&_("keydown.escape",function(){return t.alEscape()},ns)},inputs:{folio:"folio",cita:"cita",fechaInicial:"fechaInicial"},outputs:{guardada:"guardada",cerrar:"cerrar"},decls:110,vars:14,consts:[[1,"pc-modal-fondo",3,"click"],["role","dialog","aria-modal","true","aria-labelledby","titulo-cita",1,"pc-modal","nueva-cita",3,"click"],[1,"nc-cabeza"],[1,"nc-icono"],["id","titulo-cita"],["type","button","aria-label","Cerrar",1,"nc-cerrar",3,"click"],[1,"nc-cuerpo"],[1,"nc-paso"],[1,"nc-num"],[1,"pc-campo"],[1,"req"],["type","text","disabled","",3,"value"],["name","expediente",3,"ngModel"],["type","text","placeholder","Se mostrar\xE1 al seleccionar un expediente","disabled","",3,"value"],[1,"nc-dos"],["name","categoria",3,"ngModelChange","ngModel"],[3,"value"],["name","modalidad",3,"ngModelChange","ngModel"],["value","PRESENCIAL"],["value","VIRTUAL"],["rows","4","maxlength","500","name","motivo","placeholder","Describe el motivo de la cita\u2026",3,"ngModelChange","ngModel"],[1,"contador"],[1,"nc-info"],["type","date","name","fecha",3,"ngModelChange","min","ngModel"],[1,"nc-cal"],[1,"nc-cal-cabeza"],["type","button","aria-label","Mes anterior",3,"click"],["type","button","aria-label","Mes siguiente",3,"click"],[1,"nc-cal-rejilla"],[1,"nc-dia-sem"],[1,"pc-campo-titulo"],[1,"nc-horas"],["type","button",3,"class","sel","disabled","title"],[1,"nc-leyenda"],[1,"libre"],[1,"ocupado"],[1,"no-disponible"],[1,"nc-pie"],["type","button",1,"pc-btn-borde",3,"click","disabled"],["type","button",1,"pc-btn",3,"click","disabled"],["name","expediente",3,"ngModelChange","ngModel"],["value","","disabled",""],["type","button",1,"nc-dia",3,"sel","hoy","disabled"],["type","button",1,"nc-dia",3,"click","disabled"],["type","button",3,"click","disabled","title"]],template:function(e,t){e&1&&(s(0,"div",0),_("click",function(){return!t.guardando&&t.cerrar.emit()}),s(1,"section",1),_("click",function(o){return o.stopPropagation()}),s(2,"header",2)(3,"span",3)(4,"mat-icon"),l(5,"event"),r()(),s(6,"div")(7,"h2",4),l(8),r(),s(9,"p"),l(10),r()(),s(11,"button",5),_("click",function(){return t.cerrar.emit()}),s(12,"mat-icon"),l(13,"close"),r()()(),s(14,"div",6)(15,"div",7)(16,"h3")(17,"span",8),l(18,"1"),r(),l(19," Datos de la cita"),r(),s(20,"label",9),l(21,"Expediente "),s(22,"b",10),l(23,"*"),r(),v(24,jD,1,1,"input",11)(25,zD,5,1,"select",12),r(),s(26,"label",9),l(27,"Nombre del quejoso "),H(28,"input",13),r(),s(29,"div",14)(30,"label",9),l(31,"Tipo de cita "),s(32,"b",10),l(33,"*"),r(),s(34,"select",15),ge("ngModelChange",function(o){return fe(t.categoria,o)||(t.categoria=o),o}),te(35,UD,2,2,"option",16,LD),r()(),s(37,"label",9),l(38,"Modalidad "),s(39,"b",10),l(40,"*"),r(),s(41,"select",17),ge("ngModelChange",function(o){return fe(t.modalidad,o)||(t.modalidad=o),o}),s(42,"option",18),l(43,"Presencial (en las instalaciones)"),r(),s(44,"option",19),l(45,"Virtual (videollamada)"),r()()()(),s(46,"label",9),l(47,"Motivo de la cita "),s(48,"b",10),l(49,"*"),r(),s(50,"textarea",20),ge("ngModelChange",function(o){return fe(t.motivo,o)||(t.motivo=o),o}),r(),s(51,"small",21),l(52),r()(),s(53,"div",22)(54,"mat-icon"),l(55,"info"),r(),s(56,"div")(57,"b"),l(58,"Informaci\xF3n"),r(),s(59,"p"),l(60,"La persona quejosa recibir\xE1 una notificaci\xF3n con los detalles de la cita a trav\xE9s del correo registrado en el expediente, y tendr\xE1 48 horas para confirmarla."),r()()()(),s(61,"div",7)(62,"h3")(63,"span",8),l(64,"2"),r(),l(65," Fecha y hora"),r(),s(66,"label",9),l(67,"Fecha seleccionada "),s(68,"b",10),l(69,"*"),r(),s(70,"input",23),_("ngModelChange",function(o){return t.elegirFecha(o)}),r()(),s(71,"div",24)(72,"div",25)(73,"button",26),_("click",function(){return t.mover(-1)}),s(74,"mat-icon"),l(75,"chevron_left"),r()(),s(76,"b"),l(77),r(),s(78,"button",27),_("click",function(){return t.mover(1)}),s(79,"mat-icon"),l(80,"chevron_right"),r()()(),s(81,"div",28),te(82,HD,2,1,"span",29,Ke),te(84,qD,2,1,null,null,Fn),r()(),s(86,"span",30),l(87,"Horarios disponibles "),s(88,"b",10),l(89,"*"),r()(),s(90,"div",31),te(91,WD,2,7,"button",32,Ke),r(),s(93,"div",33)(94,"span"),H(95,"i",34),l(96,"Disponible"),r(),s(97,"span"),H(98,"i",35),l(99,"Ocupado"),r(),s(100,"span"),H(101,"i",36),l(102,"No disponible"),r()()()(),s(103,"footer",37)(104,"button",38),_("click",function(){return t.cerrar.emit()}),l(105,"Cancelar"),r(),s(106,"button",39),_("click",function(){return t.guardar()}),s(107,"mat-icon"),l(108,"event_available"),r(),l(109),r()()()()),e&2&&(d(8),g(t.reagendando?"Reagendar Cita":"Programar Nueva Cita"),d(2),g(t.reagendando?"Elige la nueva fecha y hora; la cita anterior queda en el historial.":"Registra una cita de comparecencia o seguimiento."),d(14),y(t.reagendando?24:25),d(4),P("value",t.nombreQuejoso),d(6),he("ngModel",t.categoria),d(),ne(t.categorias),d(6),he("ngModel",t.modalidad),d(9),he("ngModel",t.motivo),d(2),N("",t.motivo.length,"/500"),d(18),P("min",t.hoyIso)("ngModel",t.fecha),d(7),g(t.tituloMes),d(5),ne(t.diasSemana),d(2),ne(t.celdas),d(7),ne(t.horarios),d(13),P("disabled",t.guardando),d(2),P("disabled",t.guardando),d(3),N(" ",t.guardando?"Guardando\u2026":t.reagendando?"Reagendar Cita":"Agendar Cita"," "))},dependencies:[Ot,io,ao,ft,Ai,Tt,sa,St,ze,Ve,Ft],styles:[".nueva-cita[_ngcontent-%COMP%]{width:min(980px,100%);padding:0;overflow:hidden}.nc-cabeza[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:14px;padding:20px 24px;background:#fbf3f6;border-bottom:1px solid #f0e2e8}.nc-cabeza[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{margin:0;color:var(--guinda);font-size:22px;font-weight:800}.nc-cabeza[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:4px 0 0;color:var(--texto-suave);font-size:14px}.nc-icono[_ngcontent-%COMP%]{display:grid;place-items:center;width:46px;height:46px;flex-shrink:0;border-radius:10px;background:#fff;color:var(--guinda)}.nc-cerrar[_ngcontent-%COMP%]{margin-left:auto;border:none;background:none;color:#333;cursor:pointer}.nc-cuerpo[_ngcontent-%COMP%]{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr)}.nc-paso[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:14px;padding:20px 24px}.nc-paso[_ngcontent-%COMP%] + .nc-paso[_ngcontent-%COMP%]{border-left:1px solid #eee}.nc-paso[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px;margin:0;font-size:17px}.nc-num[_ngcontent-%COMP%]{display:grid;place-items:center;width:28px;height:28px;border-radius:50%;background:var(--guinda);color:#fff;font-size:14px}.nc-dos[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:12px}.contador[_ngcontent-%COMP%]{align-self:flex-end;color:var(--texto-suave);font-size:12px;font-weight:400}.nc-info[_ngcontent-%COMP%]{display:flex;gap:12px;padding:12px 14px;border:1px solid #f0d3dd;border-radius:10px;background:#fdf3f6;color:var(--guinda)}.nc-info[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:2px 0 0;color:#5a3a46;font-size:13px}.nc-cal[_ngcontent-%COMP%]{padding:10px;border:1px solid #eceef1;border-radius:10px}.nc-cal-cabeza[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}.nc-cal-cabeza[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{border:none;background:none;cursor:pointer;color:#444}.nc-cal-rejilla[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(7,1fr);gap:3px;text-align:center}.nc-dia-sem[_ngcontent-%COMP%]{color:var(--texto-suave);font-size:12px;font-weight:700}.nc-dia[_ngcontent-%COMP%]{height:32px;border:none;border-radius:6px;background:none;font:inherit;font-size:13.5px;cursor:pointer}.nc-dia[_ngcontent-%COMP%]:hover:not(:disabled){background:var(--guinda-suave)}.nc-dia.hoy[_ngcontent-%COMP%]{font-weight:800;color:var(--guinda)}.nc-dia.sel[_ngcontent-%COMP%]{background:var(--guinda);color:#fff}.nc-dia[_ngcontent-%COMP%]:disabled{color:#c5c8ce;cursor:not-allowed}.nc-horas[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}.nc-hora[_ngcontent-%COMP%]{height:36px;border:1px solid #d5d8de;border-radius:7px;background:#fff;font:inherit;font-size:13.5px;font-weight:600;cursor:pointer}.nc-hora[_ngcontent-%COMP%]:hover:not(:disabled){border-color:var(--guinda)}.nc-hora.sel[_ngcontent-%COMP%]{border-color:var(--guinda);background:var(--guinda);color:#fff}.nc-hora.ocupado[_ngcontent-%COMP%]{border-color:#e5e7eb;background:#e5e7eb;color:#8a8f98;cursor:not-allowed}.nc-hora.no-disponible[_ngcontent-%COMP%]{border-style:dashed;color:#c5c8ce;cursor:not-allowed}.nc-leyenda[_ngcontent-%COMP%]{display:flex;gap:16px;color:var(--texto-suave);font-size:12.5px}.nc-leyenda[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:6px}.nc-leyenda[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]{width:11px;height:11px;border-radius:50%}.nc-leyenda[_ngcontent-%COMP%]   .libre[_ngcontent-%COMP%]{background:var(--guinda)}.nc-leyenda[_ngcontent-%COMP%]   .ocupado[_ngcontent-%COMP%]{background:#d1d5db}.nc-leyenda[_ngcontent-%COMP%]   .no-disponible[_ngcontent-%COMP%]{border:1.5px solid #c5c8ce}.nc-pie[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;gap:12px;padding:16px 24px;border-top:1px solid #eee}@media(max-width:800px){.nc-cuerpo[_ngcontent-%COMP%]{grid-template-columns:1fr}.nc-paso[_ngcontent-%COMP%] + .nc-paso[_ngcontent-%COMP%]{border-left:none;border-top:1px solid #eee}}"]})};function pm(n){return`${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,"0")}-${String(n.getDate()).padStart(2,"0")}`}var _l=class n{constructor(i){this.api=i}api;crearNota(i){return this.api.post("/notas",i)}obtenerPorFolio(i){return this.api.get(`/notas/folio/${encodeURIComponent(i)}`)}actualizarNota(i,e){return this.api.put(`/notas/${i}`,e)}eliminarNota(i){return this.api.delete(`/notas/${i}`)}static \u0275fac=function(e){return new(e||n)(U(Ue))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var bl=class n{constructor(i){this.api=i}api;listar(i){return this.api.get(`/conciliaciones/expediente/${encodeURIComponent(i)}`)}proponer(i){return this.api.post("/conciliaciones",i)}static \u0275fac=function(e){return new(e||n)(U(Ue))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var wo=class n{constructor(i){this.api=i}api;registrarCompetencia(i){return this.api.post("/dictamenes/competente",i)}registrarImprocedencia(i){return this.api.post("/dictamenes/improcedente",i)}obtenerPorFolio(i){return this.api.get(`/dictamenes/folio/${encodeURIComponent(i)}`)}reenviarASubdefensoria(i){return this.api.post(`/dictamenes/folio/${encodeURIComponent(i)}/reenviar-subdefensoria`,{})}static \u0275fac=function(e){return new(e||n)(U(Ue))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var Do=class n{constructor(i){this.api=i}api;buscar(i){return this.api.get(`/antecedentes/${encodeURIComponent(i)}`)}buscarManual(i,e,t){let a=new URLSearchParams;return e.trim()&&a.set("quejoso",e.trim()),t.trim()&&a.set("denunciado",t.trim()),this.api.get(`/antecedentes/${encodeURIComponent(i)}/manual?${a.toString()}`)}guardados(i){return this.api.get(`/antecedentes/${encodeURIComponent(i)}/guardados`)}guardar(i,e){return this.api.post(`/antecedentes/${encodeURIComponent(i)}/guardados`,{antecedentes:e})}quitar(i,e){return this.api.delete(`/antecedentes/${encodeURIComponent(i)}/guardados/${e}`)}static \u0275fac=function(e){return new(e||n)(U(Ue))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var vl=class n{constructor(i){this.api=i}api;listar(){return this.api.get("/abogados")}static \u0275fac=function(e){return new(e||n)(U(Ue))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};var s0=(n,i)=>i.folioQueja,Eo=(n,i)=>i.id;function ZD(n,i){n&1&&(s(0,"div",2)(1,"p",4),l(2,"Cargando expediente\u2026"),r()())}function JD(n,i){if(n&1&&(s(0,"div",2)(1,"p",4),l(2," A\xFAn no se ha recibido de Revisi\xF3n ning\xFAn expediente con folio "),s(3,"strong"),l(4),r(),l(5,". En cuanto Revisi\xF3n lo turne a Primer Contacto, aparecer\xE1 aqu\xED. "),r()()),n&2){let e=h();d(4),g(e.folio)}}function eE(n,i){if(n&1&&(s(0,"p",8)(1,"mat-icon"),l(2,"person_search"),r(),l(3),r()),n&2){let e=h(2);d(3),qe(" En an\xE1lisis por ",e.expediente.analistaAnalisisNombre," desde ",e.formatearFechaHora(e.expediente.fechaInicioAnalisis))}}function tE(n,i){if(n&1&&(s(0,"span",11),l(1),r()),n&2){let e=h(2);d(),g(e.expediente.quejoso.unidadAcademica)}}function nE(n,i){if(n&1&&(s(0,"span",18)(1,"span",26),l(2),r(),s(3,"small"),l(4),r()()),n&2){let e=h(3);d(),k("simulado",e.resumenSimulado),d(),g(e.resumenSimulado?"Resumen simulado (sin modelo)":"Borrador generado por IA"),d(2),g(e.formatearFechaHora(e.fechaResumen))}}function iE(n,i){n&1&&(s(0,"div",19),H(1,"span",27),l(2,"Generando el resumen con el modelo. Puede tardar hasta dos minutos\u2026"),r())}function aE(n,i){n&1&&(s(0,"p",29),l(1,"El modelo de resumen no respondi\xF3; esto es una aproximaci\xF3n hecha en el navegador. Rev\xEDsalo antes de usarlo."),r())}function oE(n,i){if(n&1){let e=T();s(0,"p",28),l(1),r(),v(2,aE,2,0,"p",29),s(3,"div",30)(4,"button",31),_("click",function(){x(e);let a=h(3);return C(a.verNarrativaCompleta())}),s(5,"mat-icon"),l(6,"visibility"),r(),l(7," Ver narrativa completa"),r(),s(8,"button",32),_("click",function(){x(e);let a=h(3);return C(a.copiarResumen())}),s(9,"mat-icon"),l(10,"content_copy"),r(),l(11," Copiar resumen"),r()()}if(n&2){let e=h(3);d(),g(e.resumen.resumen),d(),y(e.resumenSimulado?2:-1)}}function rE(n,i){n&1&&(s(0,"p",4),l(1,"La queja no tiene narrativa para resumir."),r())}function sE(n,i){if(n&1&&(s(0,"span",20),l(1),r()),n&2){let e=h(3);d(),N("",e.fragmentos.length," fragmentos")}}function cE(n,i){if(n&1&&(s(0,"li")(1,"mat-icon"),l(2,"format_quote"),r(),s(3,"q"),l(4),r(),s(5,"span",33),l(6),r()()),n&2){let e=i.$implicit;d(4),g(e.texto),d(2),g(e.etiqueta)}}function lE(n,i){if(n&1&&(s(0,"li",4),l(1),r()),n&2){let e=h(3);d(),g(e.cargandoResumen?"Esperando al modelo\u2026":"Sin fragmentos.")}}function dE(n,i){if(n&1){let e=T();s(0,"button",34),_("click",function(){x(e);let a=h(3);return C(a.buscarAntecedentes())}),l(1),s(2,"mat-icon"),l(3,"arrow_forward"),r()()}if(n&2){let e=h(3);d(),N("Ver todos (",e.antecedentesLista.length,") ")}}function uE(n,i){n&1&&(s(0,"p",4),l(1,"Buscando antecedentes\u2026"),r())}function mE(n,i){n&1&&(s(0,"p",4),l(1,"No se encontraron otras quejas relacionadas con esta."),r())}function pE(n,i){if(n&1){let e=T();s(0,"li")(1,"button",37),_("click",function(){let a=x(e).$implicit,o=h(4);return C(o.verAntecedente(a))}),s(2,"mat-icon"),l(3,"description"),r(),s(4,"span",38)(5,"b"),l(6),r(),s(7,"small"),l(8),r()(),s(9,"span"),l(10),Ro(11,"number"),r(),s(12,"mat-icon",39),l(13,"chevron_right"),r()()()}if(n&2){let e=i.$implicit,t=h(4);d(6),g(e.folioQueja),d(2),g(e.asunto||e.extracto||"Sin asunto"),d(),ve("sim "+t.claseSimilitud(e.similitud)),d(),N("",To(11,5,e.similitud,"1.0-0"),"%")}}function hE(n,i){if(n&1&&(s(0,"p",35),l(1),H(2,"br"),l(3,"Similitud m\xE1xima: "),s(4,"b"),l(5),r()(),s(6,"ul",36),te(7,pE,14,8,"li",null,s0),r()),n&2){let e=h(3);d(),N("Se encontraron ",e.antecedentes.total," expedientes con temas similares."),d(4),N("",e.antecedentes.maxSimilitud,"%"),d(2),ne(e.antecedentesLista.slice(0,4))}}function fE(n,i){if(n&1&&(s(0,"li")(1,"span"),l(2),r(),s(3,"span",27),H(4,"span"),r(),s(5,"b"),l(6),Ro(7,"number"),r()()),n&2){let e=i.$implicit,t=h(3);d(2),g(e.folioQueja),d(2),ve(t.claseSimilitud(e.similitud)),Gt("width",e.similitud,"%"),d(2),N("",To(7,6,e.similitud,"1.0-0"),"%")}}function gE(n,i){n&1&&(s(0,"li",4),l(1,"Sin antecedentes para comparar."),r())}function _E(n,i){if(n&1){let e=T();s(0,"div",14)(1,"div",16)(2,"div",2)(3,"div",17)(4,"h3")(5,"mat-icon"),l(6,"summarize"),r(),l(7," Resumen de la queja"),r(),v(8,nE,5,4,"span",18),r(),v(9,iE,3,0,"div",19)(10,oE,12,2)(11,rE,2,0,"p",4),r(),s(12,"div",2)(13,"div",17)(14,"div")(15,"h3")(16,"mat-icon"),l(17,"format_quote"),r(),l(18," Fragmentos clave de la queja"),r(),s(19,"p"),l(20,"Fragmentos relevantes identificados por el modelo. Sirven de apoyo para el an\xE1lisis y la comparaci\xF3n con antecedentes."),r()(),v(21,sE,2,1,"span",20),r(),s(22,"ul",21),te(23,cE,7,2,"li",null,Fn,!1,lE,2,1,"li",4),r()()(),s(26,"div",16)(27,"div",22)(28,"div",17)(29,"h3")(30,"mat-icon"),l(31,"history"),r(),l(32," Antecedentes relacionados"),r(),v(33,dE,4,1,"button",23),r(),v(34,uE,2,0,"p",4)(35,mE,2,0,"p",4)(36,hE,9,2),r(),s(37,"div",2)(38,"div",17)(39,"div")(40,"h3")(41,"mat-icon"),l(42,"bar_chart"),r(),l(43," Visualizaci\xF3n r\xE1pida"),r(),s(44,"p"),l(45,"Comparaci\xF3n de similitud con antecedentes encontrados."),r()()(),s(46,"ul",24),te(47,fE,8,9,"li",null,s0,!1,gE,2,0,"li",4),r(),s(50,"button",25),_("click",function(){x(e);let a=h(2);return C(a.buscarAntecedentes())}),s(51,"mat-icon"),l(52,"search"),r(),l(53," Ver an\xE1lisis detallado de antecedentes"),r()()()()}if(n&2){let e=h(2);d(8),y(e.resumen?8:-1),d(),y(e.cargandoResumen?9:e.resumen?10:11),d(12),y(e.fragmentos.length?21:-1),d(2),ne(e.fragmentos),d(10),y(e.antecedentesLista.length?33:-1),d(),y(e.antecedentes?e.antecedentesLista.length===0?35:36:34),d(13),ne(e.antecedentesLista.slice(0,6))}}function bE(n,i){if(n&1){let e=T();s(0,"button",47),_("click",function(){x(e);let a=h(3);return C(a.narrativaCompleta=!a.narrativaCompleta)}),l(1),s(2,"mat-icon"),l(3),r()()}if(n&2){let e=h(3);d(),N(" ",e.narrativaCompleta?"Ver menos":"Ver m\xE1s"," "),d(2),g(e.narrativaCompleta?"expand_less":"expand_more")}}function vE(n,i){if(n&1){let e=T();s(0,"li")(1,"mat-icon",48),l(2,"description"),r(),s(3,"span",38)(4,"b"),l(5),r(),s(6,"small"),l(7),r()(),s(8,"button",49),_("click",function(){let a=x(e).$implicit,o=h(3);return C(o.descargarEvidencia(a))}),s(9,"mat-icon"),l(10,"download"),r()(),s(11,"button",50),_("click",function(){let a=x(e).$implicit,o=h(3);return C(o.abrirEvidencia(a))}),s(12,"mat-icon"),l(13,"open_in_new"),r()()()}if(n&2){let e=i.$implicit;d(5),g(e.nombre),d(2),g(e.tipo)}}function yE(n,i){n&1&&(s(0,"li",4),l(1,"La queja no trae evidencias adjuntas."),r())}function xE(n,i){n&1&&ot(0)}function CE(n,i){if(n&1&&(s(0,"div",15)(1,"div",16)(2,"div",2)(3,"div",17)(4,"h3")(5,"mat-icon"),l(6,"description"),r(),l(7," Narrativa del quejoso"),r()(),s(8,"div",40),l(9),r(),v(10,bE,4,2,"button",41),r(),s(11,"div",2)(12,"div",17)(13,"h3")(14,"mat-icon"),l(15,"person"),r(),l(16," Datos del quejoso"),r()(),s(17,"div",42)(18,"dl")(19,"div")(20,"dt")(21,"mat-icon"),l(22,"person"),r(),l(23," Nombre"),r(),s(24,"dd"),l(25),r()(),s(26,"div")(27,"dt")(28,"mat-icon"),l(29,"badge"),r(),l(30," Tipo de usuario"),r(),s(31,"dd"),l(32),r()(),s(33,"div")(34,"dt")(35,"mat-icon"),l(36,"bookmark_border"),r(),l(37," Identificaci\xF3n"),r(),s(38,"dd"),l(39),r()(),s(40,"div")(41,"dt")(42,"mat-icon"),l(43,"cake"),r(),l(44," Fecha de nacimiento"),r(),s(45,"dd"),l(46),r()()(),s(47,"dl")(48,"div")(49,"dt")(50,"mat-icon"),l(51,"mail_outline"),r(),l(52," Correo electr\xF3nico"),r(),s(53,"dd"),l(54),r()(),s(55,"div")(56,"dt")(57,"mat-icon"),l(58,"call"),r(),l(59," Tel\xE9fono de contacto"),r(),s(60,"dd"),l(61),r()(),s(62,"div")(63,"dt")(64,"mat-icon"),l(65,"school"),r(),l(66," Unidad acad\xE9mica"),r(),s(67,"dd"),l(68),r()()()()(),s(69,"div",2)(70,"div",17)(71,"h3")(72,"mat-icon"),l(73,"attach_file"),r(),l(74," Evidencias adjuntas"),r(),s(75,"span",43),l(76),r()(),s(77,"ul",44),te(78,vE,14,2,"li",null,Eo,!1,yE,2,0,"li",4),r()()(),s(81,"div",16)(82,"div",2)(83,"div",17)(84,"h3")(85,"mat-icon"),l(86,"assignment"),r(),l(87," Datos de la queja"),r()(),s(88,"dl",45)(89,"div")(90,"dt")(91,"mat-icon"),l(92,"event"),r(),l(93," Fecha de registro"),r(),s(94,"dd"),l(95),r()(),s(96,"div")(97,"dt")(98,"mat-icon"),l(99,"assignment"),r(),l(100," Asunto"),r(),s(101,"dd"),l(102),r()(),s(103,"div")(104,"dt")(105,"mat-icon"),l(106,"place"),r(),l(107," Lugar de los hechos"),r(),s(108,"dd"),l(109),r()(),s(110,"div")(111,"dt")(112,"mat-icon"),l(113,"event"),r(),l(114," Fecha de los hechos"),r(),s(115,"dd"),l(116),r()(),s(117,"div")(118,"dt")(119,"mat-icon"),l(120,"send"),r(),l(121," Origen"),r(),s(122,"dd"),l(123,"Portal institucional"),r()(),s(124,"div")(125,"dt")(126,"mat-icon"),l(127,"schedule"),r(),l(128," Estado actual"),r(),s(129,"dd")(130,"span"),l(131),r()()(),s(132,"div")(133,"dt")(134,"mat-icon"),l(135,"flag"),r(),l(136," Prioridad"),r(),s(137,"dd")(138,"span",33),l(139),r()()()()(),s(140,"div",2)(141,"div",17)(142,"h3")(143,"mat-icon"),l(144,"group"),r(),l(145," Persona denunciada"),r()(),s(146,"dl",45)(147,"div")(148,"dt")(149,"mat-icon"),l(150,"person"),r(),l(151," Nombre"),r(),s(152,"dd"),l(153),r()(),s(154,"div")(155,"dt")(156,"mat-icon"),l(157,"school"),r(),l(158," Unidad acad\xE9mica"),r(),s(159,"dd"),l(160),r()()()(),s(161,"div",2)(162,"div",17)(163,"h3")(164,"mat-icon"),l(165,"history"),r(),l(166," Historial del expediente"),r()(),_e(167,xE,1,0,"ng-container",46),r()()()),n&2){let e=h(2),t=ct(5);d(8),k("completa",e.narrativaCompleta),d(),g(e.expediente.narrativa),d(),y(e.expediente.narrativa.length>600?10:-1),d(15),g(e.expediente.quejoso.nombre||"\u2014"),d(7),g(e.expediente.quejoso.boleta||"\u2014"),d(7),g(e.expediente.datosQueja!=null&&e.expediente.datosQueja.numeroIdentificacionQuejoso?(e.expediente.datosQueja!=null&&e.expediente.datosQueja.tipoIdentificacionQuejoso?(e.expediente.datosQueja==null?null:e.expediente.datosQueja.tipoIdentificacionQuejoso)+": ":"")+(e.expediente.datosQueja==null?null:e.expediente.datosQueja.numeroIdentificacionQuejoso):"\u2014"),d(7),g((e.expediente.datosQueja==null?null:e.expediente.datosQueja.fechaNacimientoQuejoso)||"\u2014"),d(8),g(e.expediente.quejoso.correo||"\u2014"),d(7),g(e.expediente.quejoso.telefono||"\u2014"),d(7),g(e.expediente.quejoso.unidadAcademica||"\u2014"),d(8),N("",e.expediente.evidencias.length," archivos"),d(2),ne(e.expediente.evidencias),d(17),g((e.expediente.datosQueja==null?null:e.expediente.datosQueja.fechaRegistro)||"\u2014"),d(7),g((e.expediente.datosQueja==null?null:e.expediente.datosQueja.asunto)||e.expediente.asunto||"\u2014"),d(7),g((e.expediente.datosQueja==null?null:e.expediente.datosQueja.unidadAcademicaClave)||"\u2014"),d(7),g((e.expediente.datosQueja==null?null:e.expediente.datosQueja.fechaHechos)||"\u2014"),d(14),ve("estatus-chip "+e.claseEstatus(e.expediente.estatusCodigo)),d(),g(e.expediente.estatus),d(8),g(e.expediente.prioridad),d(14),g((e.expediente.datosQueja==null?null:e.expediente.datosQueja.denunciado)||"\u2014"),d(7),g((e.expediente.datosQueja==null?null:e.expediente.datosQueja.unidadAcademicaClave)||"\u2014"),d(7),P("ngTemplateOutlet",t)}}function wE(n,i){if(n&1){let e=T();s(0,"button",61),_("click",function(){x(e);let a=h(3);return C(a.mostrarNuevaNota=!0)}),s(1,"mat-icon"),l(2,"add"),r(),l(3," Nueva nota"),r()}}function DE(n,i){if(n&1){let e=T();s(0,"div",52)(1,"textarea",62),ge("ngModelChange",function(a){x(e);let o=h(3);return fe(o.nuevaNota,a)||(o.nuevaNota=a),C(a)}),r(),s(2,"div",30)(3,"button",61),_("click",function(){x(e);let a=h(3);return a.mostrarNuevaNota=!1,C(a.nuevaNota="")}),l(4,"Cancelar"),r(),s(5,"button",63),_("click",function(){x(e);let a=h(3);return a.agregarNota(),C(a.mostrarNuevaNota=!1)}),l(6,"Guardar nota"),r()()()}if(n&2){let e=h(3);d(),he("ngModel",e.nuevaNota)}}function EE(n,i){n&1&&l(0," \xB7 editada ")}function SE(n,i){if(n&1){let e=T();s(0,"textarea",65),ge("ngModelChange",function(a){x(e);let o=h(4);return fe(o.textoEdicion,a)||(o.textoEdicion=a),C(a)}),r(),s(1,"div",30)(2,"button",61),_("click",function(){x(e);let a=h(4);return C(a.cancelarEdicion())}),l(3,"Cancelar"),r(),s(4,"button",63),_("click",function(){x(e);let a=h().$implicit,o=h(3);return C(o.guardarEdicion(a))}),l(5,"Guardar"),r()()}if(n&2){let e=h(4);he("ngModel",e.textoEdicion)}}function kE(n,i){if(n&1){let e=T();s(0,"div",66)(1,"button",67),_("click",function(){x(e);let a=h(2).$implicit,o=h(3);return C(o.editarNota(a))}),s(2,"mat-icon"),l(3,"edit"),r()(),s(4,"button",68),_("click",function(){x(e);let a=h(2).$implicit,o=h(3);return C(o.eliminarNota(a))}),s(5,"mat-icon"),l(6,"delete"),r()()()}}function ME(n,i){if(n&1&&(s(0,"p"),l(1),r(),v(2,kE,7,0,"div",66)),n&2){let e=h().$implicit,t=h(3);d(),g(e.contenido),d(),y(t.esNotaPropia(e)?2:-1)}}function IE(n,i){if(n&1&&(s(0,"li")(1,"div",64)(2,"b"),l(3),r(),s(4,"small"),l(5),v(6,EE,1,0),r()(),v(7,SE,6,1)(8,ME,3,2),r()),n&2){let e=i.$implicit,t=h(3);k("propia",t.esNotaPropia(e)),d(3),g(e.analistaNombre),d(2),g(t.formatearFechaHora(e.fechaCreacion)),d(),y(e.fechaActualizacion?6:-1),d(),y(t.notaEnEdicion===e.id?7:8)}}function AE(n,i){n&1&&(s(0,"li",4),l(1,"Todav\xEDa no hay notas de an\xE1lisis."),r())}function RE(n,i){if(n&1){let e=T();s(0,"li")(1,"mat-icon",48),l(2,"description"),r(),s(3,"span",38)(4,"b"),l(5),r(),s(6,"small"),l(7),r()(),s(8,"button",49),_("click",function(){let a=x(e).$implicit,o=h(5);return C(o.abrirArchivoDenunciado(a,!0))}),s(9,"mat-icon"),l(10,"download"),r()(),s(11,"button",72),_("click",function(){let a=x(e).$implicit,o=h(5);return C(o.abrirArchivoDenunciado(a))}),s(12,"mat-icon"),l(13,"open_in_new"),r()()()}if(n&2){let e=i.$implicit,t=h(5);d(5),g(e.nombreArchivo),d(2),qe("",e.tipoMime," \xB7 ",t.tamanio(e.tamanioBytes))}}function TE(n,i){if(n&1&&(s(0,"h4",71),l(1),r(),s(2,"ul",44),te(3,RE,14,3,"li",null,Eo),r()),n&2){let e=h(4);d(),N("Archivos adjuntos (",e.respuestasDenunciado[0].archivos.length,")"),d(2),ne(e.respuestasDenunciado[0].archivos)}}function OE(n,i){if(n&1){let e=T();s(0,"div",69)(1,"mat-icon",70),l(2,"check_circle"),r(),s(3,"div")(4,"b"),l(5,"Respuesta recibida"),r(),s(6,"span"),l(7),r()(),s(8,"button",61),_("click",function(){x(e);let a=h(3);return C(a.verRespuestaDenunciado())}),s(9,"mat-icon"),l(10,"visibility"),r(),l(11," Ver respuesta"),r()(),v(12,TE,5,1)}if(n&2){let e=h(3);d(7),N("El denunciado respondi\xF3 el ",e.formatearFechaHora(e.respuestasDenunciado[0].fechaRegistro),"."),d(5),y(e.respuestasDenunciado[0].archivos.length?12:-1)}}function PE(n,i){if(n&1&&(s(0,"div",55)(1,"mat-icon"),l(2,"hourglass_empty"),r(),s(3,"div")(4,"b"),l(5,"Sin respuesta todav\xEDa"),r(),s(6,"span"),l(7),r()()()),n&2){let e=h(3);d(7),N(" ",e.ultimaSolicitudDenunciado?"Ya se le pidi\xF3 su versi\xF3n; a\xFAn no responde.":"A\xFAn no se le ha pedido al denunciado su versi\xF3n de los hechos.")}}function FE(n,i){if(n&1){let e=T();s(0,"button",61),_("click",function(){x(e);let a=h(3);return C(a.agendarCita())}),s(1,"mat-icon"),l(2,"add"),r(),l(3," Agendar cita"),r()}}function NE(n,i){if(n&1&&(s(0,"small",75),l(1),r()),n&2){let e=h();d(),N("Motivo del quejoso: \u201C",e.motivoCancelacionQuejoso,"\u201D")}}function LE(n,i){n&1&&(s(0,"small",75),l(1,"El quejoso no respondi\xF3 en el plazo de 48 horas."),r())}function BE(n,i){if(n&1){let e=T();s(0,"div",73)(1,"span",74)(2,"b"),l(3),r(),s(4,"small"),l(5),r()(),s(6,"div")(7,"b"),l(8),r(),s(9,"small"),l(10),r(),v(11,NE,2,1,"small",75),v(12,LE,2,0,"small",75),r(),s(13,"span"),l(14),r()(),s(15,"button",34),_("click",function(){x(e);let a=h(3);return C(a.irAAgenda())}),l(16,"Confirmar, reagendar o cancelar en la Agenda "),s(17,"mat-icon"),l(18,"arrow_forward"),r()()}if(n&2){let e=i,t=h(3);d(3),g(e.fecha.slice(0,2)),d(2),qe("",e.fecha.slice(3,5),"/",e.fecha.slice(8)),d(3),qe("",e.hora," h \xB7 ",t.etiquetaCategoria(e.categoria)),d(2),qe("",e.tipo," \xB7 Agend\xF3 ",e.analistaNombre||"\u2014"),d(),y(e.estatusCodigo==="CANCELADA_QUEJOSO"?11:-1),d(),y(e.estatusCodigo==="SIN_RESPUESTA"?12:-1),d(),ve("pc-chip "+e.estatusCodigo),d(),g(e.estatus)}}function jE(n,i){n&1&&(s(0,"div",55)(1,"mat-icon"),l(2,"event"),r(),s(3,"div")(4,"b"),l(5,"Sin citas activas"),r(),s(6,"span"),l(7,"Agenda una cita si necesitas entrevistar al quejoso."),r()()())}function VE(n,i){if(n&1&&(s(0,"li")(1,"span"),l(2),r(),s(3,"span"),l(4),r()()),n&2){let e=i.$implicit,t=h(4);d(2),Nn("",e.fecha," \xB7 ",e.hora," h \xB7 ",t.etiquetaCategoria(e.categoria)),d(),ve("pc-chip "+e.estatusCodigo),d(),g(e.estatus)}}function zE(n,i){if(n&1&&(s(0,"details",56)(1,"summary"),l(2),r(),s(3,"ul"),te(4,VE,5,6,"li",null,Eo),r()()),n&2){let e=h(3);d(2),N("Historial de citas (",e.historialCitas.length,")"),d(2),ne(e.historialCitas)}}function UE(n,i){if(n&1){let e=T();s(0,"button",76),_("click",function(){x(e);let a=h(3);return C(a.solicitarRespuestaDenunciado())}),s(1,"mat-icon"),l(2),r(),l(3),r()}if(n&2){let e=h(3);P("disabled",e.enviandoSolicitudDenunciado),d(2),g(e.ultimaSolicitudDenunciado?"refresh":"add"),d(),N(" ",e.ultimaSolicitudDenunciado?"Reenviar":"Enviar solicitud"," ")}}function HE(n,i){if(n&1&&l(0),n&2){let e=h();N(" por ",e.enviadoPorNombre)}}function $E(n,i){n&1&&(s(0,"p",75),l(1,"El correo no se pudo enviar. Revisa la direcci\xF3n y reenv\xEDalo."),r())}function GE(n,i){if(n&1){let e=T();s(0,"li"),H(1,"span",79),s(2,"b"),l(3,"Respuesta recibida"),r(),s(4,"small"),l(5),r(),s(6,"p"),l(7),s(8,"button",34),_("click",function(){x(e);let a=h(4);return C(a.verRespuestaDenunciado())}),s(9,"mat-icon"),l(10,"visibility"),r(),l(11," Ver respuesta"),r()()()}if(n&2){let e=h(4);d(5),g(e.formatearFechaHora(e.respuestasDenunciado[0].fechaRegistro)),d(2),N("Respondi\xF3 al correo de seguimiento (",e.respuestasDenunciado[0].folioRespuesta,"). ")}}function qE(n,i){if(n&1&&(s(0,"ol",58)(1,"li"),H(2,"span",77),s(3,"b"),l(4,"Solicitud enviada"),r(),s(5,"small"),l(6),r(),s(7,"p"),l(8),v(9,HE,1,1),l(10,"."),r(),v(11,$E,2,0,"p",75),r(),s(12,"li"),H(13,"span",78),s(14,"b"),l(15,"En espera de respuesta"),r(),s(16,"p"),l(17),r()(),v(18,GE,12,2,"li"),r()),n&2){let e=i,t=h(3);d(6),g(t.formatearFechaHora(e.fechaEnvio)),d(2),N("Solicitud enviada a ",e.correoDenunciado),d(),y(e.enviadoPorNombre?9:-1),d(2),y(e.correoEnviado?-1:11),d(2),k("lleno",t.respuestasDenunciado.length>0),d(4),g(t.respuestasDenunciado.length?"Completado":"Pendiente \xB7 se espera la respuesta del denunciado."),d(),y(t.respuestasDenunciado.length>0?18:-1)}}function WE(n,i){n&1&&(s(0,"div",55)(1,"mat-icon"),l(2,"mail_outline"),r(),s(3,"div")(4,"b"),l(5,"Sin solicitudes enviadas"),r(),s(6,"span"),l(7,"Env\xEDa al denunciado el enlace para que d\xE9 su versi\xF3n de los hechos."),r()()())}function QE(n,i){if(n&1){let e=T();s(0,"button",61),_("click",function(){x(e);let a=h(3);return C(a.mostrarFormConciliacion=!0)}),s(1,"mat-icon"),l(2,"add"),r(),l(3," Proponer acuerdo"),r()}}function YE(n,i){if(n&1){let e=T();s(0,"div",59)(1,"label",80),l(2,"Asunto del acuerdo "),s(3,"input",81),ge("ngModelChange",function(a){x(e);let o=h(3);return fe(o.conciliacion.asunto,a)||(o.conciliacion.asunto=a),C(a)}),r()(),s(4,"label",80),l(5,"T\xE9rminos del acuerdo "),s(6,"textarea",82),ge("ngModelChange",function(a){x(e);let o=h(3);return fe(o.conciliacion.terminos,a)||(o.conciliacion.terminos=a),C(a)}),r()(),s(7,"div",30)(8,"button",61),_("click",function(){x(e);let a=h(3);return C(a.mostrarFormConciliacion=!1)}),l(9,"Cancelar"),r(),s(10,"button",83),_("click",function(){x(e);let a=h(3);return C(a.proponerConciliacion())}),s(11,"mat-icon"),l(12,"send"),r(),l(13," Enviar al quejoso"),r()()()}if(n&2){let e=h(3);d(3),he("ngModel",e.conciliacion.asunto),d(3),he("ngModel",e.conciliacion.terminos),d(4),P("disabled",e.procesando)}}function XE(n,i){if(n&1&&l(0),n&2){let e=h().$implicit,t=h(3);N(" \xB7 respondido el ",t.formatearFechaHora(e.fechaRespuesta))}}function KE(n,i){if(n&1&&(s(0,"p",84),l(1),r()),n&2){let e=h().$implicit;d(),N("\u201C",e.comentarioQuejoso,"\u201D")}}function ZE(n,i){if(n&1&&(s(0,"div",60)(1,"div",64)(2,"b"),l(3),r(),s(4,"span",26),l(5),r()(),s(6,"p"),l(7),r(),s(8,"small"),l(9),v(10,XE,1,1),r(),v(11,KE,2,1,"p",84),r()),n&2){let e=i.$implicit,t=h(3);Y("data-estado",e.estado),d(3),g(e.asunto),d(),k("CONFIRMADA",e.estado==="ACEPTADO")("CANCELADA",e.estado==="RECHAZADO")("PROGRAMADA",e.estado==="PENDIENTE"),d(),g(t.etiquetaAcuerdo(e.estado)),d(2),g(e.terminos),d(2),qe("Propuesto por ",e.creadoPorNombre||e.creadoPor," el ",t.formatearFechaHora(e.fechaEmision)),d(),y(e.fechaRespuesta?10:-1),d(),y(e.comentarioQuejoso?11:-1)}}function JE(n,i){n&1&&(s(0,"div",55)(1,"mat-icon"),l(2,"handshake"),r(),s(3,"div")(4,"b"),l(5,"No se ha propuesto un acuerdo"),r(),s(6,"span"),l(7,"Prop\xF3n un acuerdo al quejoso. Si lo acepta, el expediente pasa a Subdefensor\xEDa."),r()()())}function eS(n,i){if(n&1&&v(0,JE,8,0,"div",55),n&2){let e=h(3);y(e.mostrarFormConciliacion?-1:0)}}function tS(n,i){if(n&1&&(s(0,"div",15)(1,"div",16)(2,"div",2)(3,"div",17)(4,"h3")(5,"mat-icon"),l(6,"sticky_note_2"),r(),l(7," Notas de an\xE1lisis"),r(),v(8,wE,4,0,"button",51),r(),v(9,DE,7,1,"div",52),s(10,"ul",53),te(11,IE,9,6,"li",54,Eo,!1,AE,2,0,"li",4),r()(),s(14,"div",2)(15,"div",17)(16,"h3")(17,"mat-icon"),l(18,"record_voice_over"),r(),l(19," Versi\xF3n del denunciado"),r()(),v(20,OE,13,2)(21,PE,8,1,"div",55),r()(),s(22,"div",16)(23,"div",2)(24,"div",17)(25,"h3")(26,"mat-icon"),l(27,"event"),r(),l(28," Citas con el quejoso"),r(),v(29,FE,4,0,"button",51),r(),v(30,BE,19,12)(31,jE,8,0,"div",55),v(32,zE,6,1,"details",56),r(),s(33,"div",2)(34,"div",17)(35,"h3")(36,"mat-icon"),l(37,"outgoing_mail"),r(),l(38," Solicitud de versi\xF3n del denunciado"),r(),v(39,UE,4,3,"button",57),r(),v(40,qE,19,8,"ol",58)(41,WE,8,0,"div",55),r(),s(42,"div",2)(43,"div",17)(44,"h3")(45,"mat-icon"),l(46,"handshake"),r(),l(47," Propuesta de conciliaci\xF3n"),r(),v(48,QE,4,0,"button",51),r(),v(49,YE,14,3,"div",59),te(50,ZE,12,14,"div",60,Eo,!1,eS,1,1),r()()()),n&2){let e,t,a=h(2);d(8),y(a.abierto&&!a.mostrarNuevaNota?8:-1),d(),y(a.mostrarNuevaNota?9:-1),d(2),ne(a.expediente.notas),d(9),y(a.respuestasDenunciado.length>0?20:21),d(9),y(a.abierto&&!a.citaActiva?29:-1),d(),y((e=a.citaActiva)?30:31,e),d(2),y(a.historialCitas.length>(a.citaActiva?1:0)?32:-1),d(7),y(a.abierto?39:-1),d(),y((t=a.ultimaSolicitudDenunciado)?40:41,t),d(8),y(a.abierto&&!a.conciliacionPendiente&&!a.mostrarFormConciliacion?48:-1),d(),y(a.mostrarFormConciliacion?49:-1),d(),ne(a.acuerdos)}}function nS(n,i){if(n&1&&(s(0,"p"),l(1,"Subdefensor\xEDa lo recibi\xF3 con folio "),s(2,"strong"),l(3),r(),l(4,"."),r()),n&2){let e=h(4);d(3),g(e.expediente.folioSubdefensoria)}}function iS(n,i){n&1&&(s(0,"p",75),l(1,"El dictamen qued\xF3 registrado, pero Subdefensor\xEDa no confirm\xF3 la recepci\xF3n. Reintenta el env\xEDo."),r())}function aS(n,i){if(n&1){let e=T();s(0,"button",88),_("click",function(){x(e);let a=h(4);return C(a.reenviarASubdefensoria())}),s(1,"mat-icon"),l(2,"sync"),r(),l(3," Reintentar env\xEDo"),r()}if(n&2){let e=h(4);P("disabled",e.procesando)}}function oS(n,i){if(n&1){let e=T();s(0,"div",17)(1,"h3")(2,"mat-icon"),l(3,"task_alt"),r(),l(4," Procedente \xB7 turnado a Subdefensor\xEDa"),r()(),v(5,nS,5,1,"p")(6,iS,2,0,"p",75),s(7,"div",30),v(8,aS,4,1,"button",87),s(9,"button",31),_("click",function(){x(e);let a=h(3);return C(a.verDictamen())}),s(10,"mat-icon"),l(11,"visibility"),r(),l(12," Ver dictamen"),r()()}if(n&2){let e=h(3);d(5),y(e.expediente.folioSubdefensoria?5:6),d(3),y(e.expediente.folioSubdefensoria?-1:8)}}function rS(n,i){if(n&1){let e=T();s(0,"div",17)(1,"h3")(2,"mat-icon"),l(3,"cancel"),r(),l(4," Improcedente \xB7 pendiente de remisi\xF3n"),r()(),s(5,"p"),l(6,"Genera el oficio y registra su env\xEDo a la instancia competente para cerrar el expediente."),r(),s(7,"div",30)(8,"button",31),_("click",function(){x(e);let a=h(3);return C(a.verDictamen())}),s(9,"mat-icon"),l(10,"visibility"),r(),l(11," Ver dictamen"),r(),s(12,"button",32),_("click",function(){x(e);let a=h(3);return C(a.irARemision())}),s(13,"mat-icon"),l(14,"outgoing_mail"),r(),l(15," Continuar con la remisi\xF3n"),r()()}}function sS(n,i){if(n&1){let e=T();s(0,"div",17)(1,"h3")(2,"mat-icon"),l(3,"outgoing_mail"),r(),l(4," Remitido a otra instancia"),r()(),s(5,"p"),l(6,"El oficio de remisi\xF3n ya se registr\xF3 como enviado."),r(),s(7,"div",30)(8,"button",31),_("click",function(){x(e);let a=h(3);return C(a.verDictamen())}),s(9,"mat-icon"),l(10,"visibility"),r(),l(11," Ver dictamen"),r(),s(12,"button",31),_("click",function(){x(e);let a=h(3);return C(a.irARemision())}),s(13,"mat-icon"),l(14,"description"),r(),l(15," Ver remisi\xF3n"),r()()}}function cS(n,i){n&1&&(s(0,"p",29),l(1,"Hay un acuerdo de conciliaci\xF3n esperando la respuesta del quejoso; espera su respuesta para dictaminar."),r())}function lS(n,i){if(n&1&&(s(0,"option",100),l(1),r()),n&2){let e=i.$implicit;P("value",e.nombre),d(),Nn("",e.nombre," \xB7 ",e.enTramite," ",e.enTramite===1?"queja":"quejas"," en tr\xE1mite")}}function dS(n,i){n&1&&(s(0,"small",101),l(1,"Ordenados de menor a mayor carga."),r())}function uS(n,i){if(n&1){let e=T();s(0,"label",80),l(1,"Responsable en Subdefensor\xEDa "),s(2,"b",94),l(3,"*"),r(),s(4,"select",98),ge("ngModelChange",function(a){x(e);let o=h(5);return fe(o.responsableTurno,a)||(o.responsableTurno=a),C(a)}),s(5,"option",99),l(6,"Seleccione un responsable\u2026"),r(),te(7,lS,2,4,"option",100,Eo),r(),v(9,dS,2,0,"small",101),r()}if(n&2){let e=h(5);d(4),he("ngModel",e.responsableTurno),d(3),ne(e.abogados),d(2),y(e.abogados.length?9:-1)}}function mS(n,i){if(n&1){let e=T();s(0,"div",93)(1,"mat-icon"),l(2),r(),s(3,"div")(4,"b"),l(5),r(),s(6,"small"),l(7),r()()(),s(8,"div",59)(9,"label",80),l(10,"Justificaci\xF3n del dictamen "),s(11,"b",94),l(12,"*"),r(),s(13,"textarea",95),ge("ngModelChange",function(a){x(e);let o=h(4);return fe(o.justificacion,a)||(o.justificacion=a),C(a)}),r(),s(14,"small",96),l(15),r()(),s(16,"label",80),l(17),s(18,"textarea",97),ge("ngModelChange",function(a){x(e);let o=h(4);return fe(o.observacionesDictamen,a)||(o.observacionesDictamen=a),C(a)}),r(),s(19,"small",96),l(20),r()(),v(21,uS,10,2,"label",80),s(22,"div",30)(23,"button",31),_("click",function(){x(e);let a=h(4);return C(a.cancelarDecision())}),l(24,"Cancelar"),r(),s(25,"button",88),_("click",function(){x(e);let a=h(4);return C(a.registrarDictamen())}),s(26,"mat-icon"),l(27),r(),l(28),r()()()}if(n&2){let e=h(4);k("improcedente",e.decision==="improcedente"),d(2),g(e.decision==="competente"?"check_circle":"cancel"),d(3),g(e.decision==="competente"?"Dictamen de Competencia":"Dictamen de Improcedencia"),d(2),g(e.decision==="competente"?"Complete la informaci\xF3n para turnar el expediente a Subdefensor\xEDa.":"Complete la justificaci\xF3n del dictamen."),d(6),he("ngModel",e.justificacion),P("placeholder",e.decision==="competente"?"Describa los motivos por los cuales el asunto corresponde a la competencia de la Defensor\xEDa.":"Describa los motivos por los cuales la queja es improcedente."),d(2),N("",e.justificacion.length,"/1000"),d(2),N("",e.decision==="competente"?"Observaciones para Subdefensor\xEDa":"Observaciones (opcional)"," "),d(),he("ngModel",e.observacionesDictamen),d(2),N("",e.observacionesDictamen.length,"/1000"),d(),y(e.decision==="competente"?21:-1),d(4),P("disabled",e.procesando),d(2),g(e.decision==="competente"?"send":"close"),d(),N(" ",e.procesando?"Guardando\u2026":e.decision==="competente"?"Turnar a Subdefensor\xEDa":"Declarar improcedente"," ")}}function pS(n,i){if(n&1){let e=T();s(0,"div",17)(1,"div")(2,"h3")(3,"mat-icon"),l(4,"description"),r(),l(5," Determinaci\xF3n del an\xE1lisis"),r(),s(6,"p"),l(7,"Seleccione si el asunto corresponde o no a la competencia de la Defensor\xEDa."),r()()(),v(8,cS,2,0,"p",29),s(9,"div",89)(10,"button",90),_("click",function(){x(e);let a=h(3);return C(a.decision="competente")}),H(11,"span",91),s(12,"span")(13,"b"),l(14,"Competente"),r(),s(15,"small"),l(16,"El asunto corresponde a la competencia de la Defensor\xEDa."),r()()(),s(17,"button",92),_("click",function(){x(e);let a=h(3);return C(a.decision="improcedente")}),H(18,"span",91),s(19,"span")(20,"b"),l(21,"Improcedente"),r(),s(22,"small"),l(23,"El asunto no corresponde a la competencia de la Defensor\xEDa."),r()()()(),v(24,mS,29,15)}if(n&2){let e=h(3);d(8),y(e.conciliacionPendiente?8:-1),d(2),k("sel",e.decision==="competente"),P("disabled",e.conciliacionPendiente||!e.abierto),d(7),k("sel",e.decision==="improcedente"),P("disabled",e.conciliacionPendiente||!e.abierto),d(7),y(e.decision?24:-1)}}function hS(n,i){n&1&&(s(0,"span"),l(1,"Buscando antecedentes\u2026"),r())}function fS(n,i){n&1&&(s(0,"span")(1,"b"),l(2,"Sin antecedentes"),r()())}function gS(n,i){if(n&1&&(s(0,"span")(1,"b"),l(2),r(),s(3,"small"),l(4),r()()),n&2){let e=h(3);d(2),Nn("",e.antecedentes.total," posible",e.antecedentes.total===1?"":"s"," antecedente",e.antecedentes.total===1?"":"s"),d(2),N("Similitud m\xE1xima: ",e.antecedentes.maxSimilitud,"%")}}function _S(n,i){n&1&&ot(0)}function bS(n,i){if(n&1){let e=T();s(0,"div",15)(1,"div",16)(2,"div",2),v(3,oS,13,2)(4,rS,16,0)(5,sS,16,0)(6,pS,25,8),r()(),s(7,"div",16)(8,"div",2)(9,"div",17)(10,"h3")(11,"mat-icon"),l(12,"description"),r(),l(13," Datos del expediente"),r()(),s(14,"dl",85)(15,"div")(16,"dt"),l(17,"Folio"),r(),s(18,"dd"),l(19),r()(),s(20,"div")(21,"dt"),l(22,"Asunto"),r(),s(23,"dd"),l(24),r()(),s(25,"div")(26,"dt"),l(27,"Quejoso"),r(),s(28,"dd"),l(29),r()(),s(30,"div")(31,"dt"),l(32,"Persona denunciada"),r(),s(33,"dd"),l(34),r()(),s(35,"div")(36,"dt"),l(37,"Unidad acad\xE9mica"),r(),s(38,"dd"),l(39),r()(),s(40,"div")(41,"dt"),l(42,"Fecha de ingreso"),r(),s(43,"dd"),l(44),r()(),s(45,"div")(46,"dt"),l(47,"Prioridad"),r(),s(48,"dd")(49,"span",33),l(50),r()()(),s(51,"div")(52,"dt"),l(53,"Estado actual"),r(),s(54,"dd")(55,"span"),l(56),r()()()()(),s(57,"div",2)(58,"div",17)(59,"h3")(60,"mat-icon"),l(61,"history"),r(),l(62," Antecedentes identificados"),r(),s(63,"button",34),_("click",function(){x(e);let a=h(2);return C(a.irAPestana("ia"))}),l(64,"Ver an\xE1lisis IA "),s(65,"mat-icon"),l(66,"arrow_forward"),r()()(),s(67,"div",86)(68,"mat-icon"),l(69,"schedule"),r(),v(70,hS,2,0,"span")(71,fS,3,0,"span")(72,gS,5,4,"span"),r()(),s(73,"div",2)(74,"div",17)(75,"h3")(76,"mat-icon"),l(77,"history"),r(),l(78," Historial del expediente"),r()(),_e(79,_S,1,0,"ng-container",46),r()()()}if(n&2){let e,t=h(2),a=ct(5);d(3),y((e=t.expediente.estatusCodigo)==="PROCEDENTE"?3:e==="IMPROCEDENTE"?4:e==="REMITIDA"?5:6),d(16),g(t.expediente.folio),d(5),g(t.expediente.asunto),d(5),g(t.expediente.quejoso.nombre),d(5),g((t.expediente.datosQueja==null?null:t.expediente.datosQueja.denunciado)||"\u2014"),d(5),g(t.expediente.quejoso.unidadAcademica||"\u2014"),d(5),g(t.expediente.fechaIngreso||(t.expediente.datosQueja==null?null:t.expediente.datosQueja.fechaRegistro)||"\u2014"),d(6),g(t.expediente.prioridad),d(5),ve("estatus-chip "+t.claseEstatus(t.expediente.estatusCodigo)),d(),g(t.expediente.estatus),d(14),y(t.antecedentes?t.antecedentes.total===0?71:72:70),d(9),P("ngTemplateOutlet",a)}}function vS(n,i){if(n&1){let e=T();s(0,"button",5),_("click",function(){x(e);let a=h();return C(a.volver())}),s(1,"mat-icon"),l(2,"arrow_back"),r(),l(3," Volver a expedientes"),r(),s(4,"div",6)(5,"div")(6,"h2"),l(7),s(8,"span"),l(9),r()(),s(10,"p",7),l(11),r(),v(12,eE,4,2,"p",8),r(),s(13,"div",9)(14,"span",10),l(15),r(),v(16,tE,2,1,"span",11),r()(),s(17,"nav",12)(18,"button",13),_("click",function(){x(e);let a=h();return C(a.irAPestana("ia"))}),s(19,"mat-icon"),l(20,"auto_awesome"),r(),l(21," An\xE1lisis IA"),r(),s(22,"button",13),_("click",function(){x(e);let a=h();return C(a.irAPestana("expediente"))}),s(23,"mat-icon"),l(24,"description"),r(),l(25," Expediente"),r(),s(26,"button",13),_("click",function(){x(e);let a=h();return C(a.irAPestana("gestion"))}),s(27,"mat-icon"),l(28,"event_note"),r(),l(29," Gesti\xF3n"),r(),s(30,"button",13),_("click",function(){x(e);let a=h();return C(a.irAPestana("resolucion"))}),s(31,"mat-icon"),l(32,"gavel"),r(),l(33," Resoluci\xF3n"),r()(),v(34,_E,54,7,"div",14)(35,CE,168,24,"div",15)(36,tS,53,12,"div",15)(37,bS,80,13,"div",15)}if(n&2){let e,t=h();d(7),N("",t.expediente.folio," "),d(),ve("estatus-chip "+t.claseEstatus(t.expediente.estatusCodigo)),d(),g(t.expediente.estatus),d(2),Nn("",t.expediente.asunto," \xB7 Queja ",t.expediente.folioOrigen," \xB7 Ingreso: ",t.expediente.fechaIngreso||(t.expediente.datosQueja==null?null:t.expediente.datosQueja.fechaRegistro)||"\u2014"),d(),y(t.expediente.analistaAnalisisNombre?12:-1),d(3),N("",t.expediente.prioridad," prioridad"),d(),y(t.expediente.quejoso.unidadAcademica?16:-1),d(2),k("activa",t.pestana==="ia"),d(4),k("activa",t.pestana==="expediente"),d(4),k("activa",t.pestana==="gestion"),d(4),k("activa",t.pestana==="resolucion"),d(4),y((e=t.pestana)==="ia"?34:e==="expediente"?35:e==="gestion"?36:e==="resolucion"?37:-1)}}function yS(n,i){if(n&1&&(s(0,"li"),H(1,"span",78),s(2,"div",102)(3,"small"),l(4),r(),s(5,"b"),l(6),r(),s(7,"p"),l(8),r()()()),n&2){let e=i.$implicit,t=h(2);d(),k("lleno",e.tipo==="inicio")("azul",e.tipo==="analisis"),d(),k("resaltada",e.tipo==="analisis"),d(2),g(t.formatearFechaHora(e.fecha)),d(2),g(e.titulo),d(2),g(e.detalle)}}function xS(n,i){n&1&&(s(0,"li",4),l(1,"Sin movimientos registrados."),r())}function CS(n,i){if(n&1&&(s(0,"ol",58),te(1,yS,9,9,"li",null,Fn,!1,xS,2,0,"li",4),r()),n&2){let e=h();d(),ne(e.historial)}}function wS(n,i){if(n&1){let e=T();s(0,"app-nueva-cita",103),_("guardada",function(){x(e);let a=h();return C(a.citaGuardada())})("cerrar",function(){x(e);let a=h();return C(a.mostrarNuevaCita=!1)}),r()}if(n&2){let e=h();P("folio",e.folio)}}function DS(n,i){let e=n.toLowerCase();return i===0?"Inicio del contexto":/(dijo|respond|grit|insult|coment|molest|trato|humill|burl)/.test(e)?"Trato recibido":/(reprob|calific|baja|sanci|afect|perd|consecuen)/.test(e)?"Consecuencia":/(problema|situaci|injust|suced|hecho|ocurri)/.test(e)?"Hechos principales":"Descripci\xF3n de la situaci\xF3n"}var yl=class n{constructor(i,e,t,a,o,c,u,p,f,b,w,L,$,ae,me){this.route=i;this.router=e;this.expedienteService=t;this.notaAnalisisService=a;this.conciliacionService=o;this.dictamenService=c;this.agendaService=u;this.antecedentesService=p;this.analistaSesion=f;this.snackBar=b;this.cdr=w;this.denunciadoService=L;this.dialog=$;this.resumenService=ae;this.abogadosService=me}route;router;expedienteService;notaAnalisisService;conciliacionService;dictamenService;agendaService;antecedentesService;analistaSesion;snackBar;cdr;denunciadoService;dialog;resumenService;abogadosService;folio="";pestana="expediente";narrativaCompleta=!1;mostrarNuevaNota=!1;mostrarNuevaCita=!1;resumen=null;resumenSimulado=!1;cargandoResumen=!1;fechaResumen="";antecedentesLista=[];peticionResumen;decision=null;justificacion="";observacionesDictamen="";responsableTurno="";abogados=[];etiquetaCategoria=_a;nuevaNota="";notaEnEdicion=null;textoEdicion="";expediente={folio:"",asunto:"",fechaIngreso:"",estatus:"",estatusCodigo:"",prioridad:"Media",narrativa:"",quejoso:{nombre:"",boleta:"",correo:"",telefono:"",unidadAcademica:""},evidencias:[],notas:[]};acuerdos=[];citaActiva;historialCitas=[];solicitudesDenunciado=[];respuestasDenunciado=[];enviandoSolicitudDenunciado=!1;antecedentes;mostrarFormConciliacion=!1;conciliacion={asunto:"",terminos:""};analistaActualId;cargando=!1;sinDatos=!1;procesando=!1;claseEstatus=co;formatearFechaHora=Hn;ngOnInit(){this.analistaSesion.obtener().subscribe({next:i=>{this.analistaActualId=i.id,this.cdr.detectChanges()}}),this.route.paramMap.subscribe(i=>{this.folio=i.get("id")??"",this.folio&&this.cargarExpediente()}),this.route.queryParamMap.subscribe(i=>{let e=i.get("tab");this.pestana=e&&["ia","expediente","gestion","resolucion"].includes(e)?e:"expediente";let t=i.get("decision");(t==="competente"||t==="improcedente")&&(this.decision=t),this.cdr.detectChanges()}),this.abogadosService.listar().subscribe({next:i=>{this.abogados=i,this.cdr.detectChanges()}})}ngOnDestroy(){this.peticionResumen?.unsubscribe()}irAPestana(i){this.router.navigate([],{relativeTo:this.route,queryParams:{tab:i==="expediente"?null:i},queryParamsHandling:"merge",replaceUrl:!1})}volver(){this.router.navigate(["/bandeja"])}get abierto(){return Fc(this.expediente.estatusCodigo)}get conciliacionPendiente(){return this.acuerdos.some(i=>i.estado==="PENDIENTE")}cargarExpediente(){this.cargando=!0,this.sinDatos=!1,this.expedienteService.iniciarAnalisis(this.folio).subscribe({next:i=>{this.expediente=this.expedienteService.mapearADetalle(i),this.cargando=!1,this.cdr.detectChanges(),this.cargarConciliaciones(),this.cargarCitaActiva(),this.cargarResumenAntecedentes(),this.cargarDenunciado(),this.generarResumen()},error:i=>{if(this.cargando=!1,i.status===404){this.sinDatos=!0,this.cdr.detectChanges(),this.snackBar.open(`No se ha recibido de Revisi\xF3n ning\xFAn expediente con folio ${this.folio}.`,"Cerrar",{duration:4e3});return}this.cdr.detectChanges(),this.snackBar.open("No fue posible cargar el expediente. Intenta nuevamente o contacta al administrador del sistema.","Cerrar",{duration:4e3})}})}recargarExpediente(){this.expedienteService.obtenerPorFolio(this.folio).subscribe({next:i=>{this.expediente=this.expedienteService.mapearADetalle(i),this.cdr.detectChanges()}})}abrirEvidencia(i){this.expedienteService.descargarEvidencia(i.id).subscribe({next:e=>Xr(e),error:e=>{this.snackBar.open(Ne(e,"No fue posible abrir la evidencia."),"Cerrar",{duration:3500})}})}esNotaPropia(i){return this.analistaActualId!==void 0&&i.analistaId===this.analistaActualId}agregarNota(){let i=this.nuevaNota.trim();if(i){if(!this.expediente.folio){this.snackBar.open("No fue posible identificar el expediente.","Cerrar",{duration:3e3});return}this.notaAnalisisService.crearNota({folio:this.expediente.folio,contenido:i}).subscribe({next:e=>{this.expediente.notas=[e,...this.expediente.notas],this.nuevaNota="",this.cdr.detectChanges()},error:e=>{this.cdr.detectChanges(),this.snackBar.open(Ne(e,"No fue posible guardar la nota."),"Cerrar",{duration:3e3})}})}}editarNota(i){this.notaEnEdicion=i.id,this.textoEdicion=i.contenido}cancelarEdicion(){this.notaEnEdicion=null,this.textoEdicion=""}guardarEdicion(i){let e=this.textoEdicion.trim();e&&this.notaAnalisisService.actualizarNota(i.id,{folio:this.expediente.folio,contenido:e}).subscribe({next:t=>{this.expediente.notas=this.expediente.notas.map(a=>a.id===t.id?t:a),this.cancelarEdicion(),this.cdr.detectChanges()},error:t=>{this.snackBar.open(Ne(t,"No fue posible editar la nota."),"Cerrar",{duration:3500})}})}eliminarNota(i){confirm("\xBFEliminar esta nota de an\xE1lisis? Esta acci\xF3n no se puede deshacer.")&&this.notaAnalisisService.eliminarNota(i.id).subscribe({next:()=>{this.expediente.notas=this.expediente.notas.filter(e=>e.id!==i.id),this.cdr.detectChanges()},error:e=>{this.snackBar.open(Ne(e,"No fue posible eliminar la nota."),"Cerrar",{duration:3500})}})}cargarConciliaciones(){let i=this.abierto;this.conciliacionService.listar(this.folio).subscribe({next:e=>{this.acuerdos=e,this.cdr.detectChanges(),i&&e.some(t=>t.estado==="ACEPTADO")&&this.recargarExpediente()}})}proponerConciliacion(){let i=this.conciliacion.asunto.trim(),e=this.conciliacion.terminos.trim();if(!i||!e){this.snackBar.open("Escribe el asunto y los t\xE9rminos del acuerdo.","Cerrar",{duration:3e3});return}confirm("El acuerdo se enviar\xE1 al quejoso para que lo acepte o rechace desde su panel. \xBFContinuar?")&&(this.procesando=!0,this.conciliacionService.proponer({folio:this.folio,asunto:i,terminos:e}).subscribe({next:t=>{this.acuerdos=[t,...this.acuerdos],this.conciliacion={asunto:"",terminos:""},this.mostrarFormConciliacion=!1,this.procesando=!1,this.cdr.detectChanges(),this.snackBar.open("Acuerdo enviado al quejoso.","Cerrar",{duration:3e3})},error:t=>{this.procesando=!1,this.cdr.detectChanges(),this.snackBar.open(Ne(t,"No fue posible proponer el acuerdo."),"Cerrar",{duration:4e3})}}))}etiquetaAcuerdo(i){switch(i){case"ACEPTADO":return"Aceptado por el quejoso";case"RECHAZADO":return"Rechazado por el quejoso";default:return"Esperando respuesta"}}cargarResumenAntecedentes(){this.antecedentesService.buscar(this.folio).subscribe({next:i=>{let e=new Set;this.antecedentesLista=[...i.coincidenciasFuertes??[],...i.resultados,...i.porHechos??[]].filter(t=>!e.has(t.folioQueja)&&!!e.add(t.folioQueja)).sort((t,a)=>a.similitud-t.similitud),this.antecedentes={total:this.antecedentesLista.length,mismoQuejoso:this.antecedentesLista.filter(t=>t.mismoQuejoso).length,maxSimilitud:Math.round(Math.max(0,...this.antecedentesLista.map(t=>t.similitud)))},this.cdr.detectChanges()}})}buscarAntecedentes(){this.router.navigate(["/expediente",this.folio,"antecedentes"])}verAntecedente(i){let e=M({},i);this.dialog.open(yo,{width:"720px",data:e})}claseSimilitud(i){return i>=50?"alta":i>=40?"media":"baja"}generarResumen(){let i=this.expediente.narrativa?.trim();!i||this.resumen||this.cargandoResumen||(this.cargandoResumen=!0,this.peticionResumen=this.resumenService.resumir(i).subscribe({next:e=>{this.resumen=e,this.resumenSimulado=!1,this.cargandoResumen=!1,this.fechaResumen=new Date().toISOString().slice(0,16),this.cdr.detectChanges()},error:()=>{let e=fl(i),t=i.split(/(?<=[.!?])\s+/).filter(a=>a.trim().length>25);this.resumen={resumen:e.resumen,fragmentos:e.frasesImpacto.length>=3?e.frasesImpacto:t.slice(0,5),requiereRevision:!0},this.resumenSimulado=!0,this.cargandoResumen=!1,this.fechaResumen=new Date().toISOString().slice(0,16),this.cdr.detectChanges()}}))}get fragmentos(){return(this.resumen?.fragmentos??[]).map((i,e)=>({texto:i,etiqueta:DS(i,e)}))}copiarResumen(){this.resumen?.resumen&&navigator.clipboard?.writeText(this.resumen.resumen).then(()=>this.snackBar.open("Resumen copiado.","Cerrar",{duration:2e3}),()=>this.snackBar.open("No se pudo copiar el resumen.","Cerrar",{duration:2500}))}verNarrativaCompleta(){this.narrativaCompleta=!0,this.irAPestana("expediente")}get historial(){let i=this.expediente,e=[],t=i.datosQueja?.fechaRegistro;t&&e.push({fecha:t,titulo:"Solicitud recibida",detalle:"Solicitud enviada por el quejoso a trav\xE9s del portal institucional.",tipo:"inicio"}),i.fechaInicioAnalisis&&e.push({fecha:i.fechaInicioAnalisis,titulo:"En an\xE1lisis",detalle:"Asignado a "+(i.analistaAnalisisNombre||"Primer Contacto")+".",tipo:"analisis"});for(let a of i.notas)e.push({fecha:a.fechaCreacion,titulo:"Nota de an\xE1lisis",detalle:a.analistaNombre+": "+ES(a.contenido,90),tipo:"normal"});for(let a of this.historialCitas)a.fechaCreacion&&e.push({fecha:a.fechaCreacion,titulo:"Cita "+a.estatus.toLowerCase(),detalle:`${_a(a.categoria)} el ${a.fecha} a las ${a.hora} h (${a.tipo.toLowerCase()}).`,tipo:"normal"}),a.fechaRespuestaQuejoso&&e.push({fecha:a.fechaRespuestaQuejoso,titulo:"Respuesta del quejoso",detalle:a.estatusCodigo==="CONFIRMADA"?"Confirm\xF3 su cita.":"Cancel\xF3 su cita"+(a.motivoCancelacionQuejoso?": "+a.motivoCancelacionQuejoso:"."),tipo:"normal"});for(let a of this.solicitudesDenunciado)e.push({fecha:a.fechaEnvio,titulo:"Solicitud al denunciado",detalle:"Se pidi\xF3 su versi\xF3n de los hechos a "+a.correoDenunciado+".",tipo:"normal"});for(let a of this.respuestasDenunciado)e.push({fecha:a.fechaRegistro,titulo:"Respuesta del denunciado",detalle:"Registr\xF3 su versi\xF3n ("+a.folioRespuesta+").",tipo:"normal"});for(let a of this.acuerdos)a.fechaEmision&&e.push({fecha:a.fechaEmision,titulo:"Propuesta de conciliaci\xF3n",detalle:a.asunto,tipo:"normal"}),a.fechaRespuesta&&e.push({fecha:a.fechaRespuesta,titulo:"Conciliaci\xF3n "+(a.estado==="ACEPTADO"?"aceptada":"rechazada"),detalle:a.comentarioQuejoso||"Respuesta del quejoso.",tipo:"normal"});return e.sort((a,o)=>(a.fecha??"").localeCompare(o.fecha??""))}descargarEvidencia(i){this.expedienteService.descargarEvidencia(i.id).subscribe({next:e=>Kr(e,i.nombre),error:e=>this.snackBar.open(Ne(e,"No fue posible descargar la evidencia."),"Cerrar",{duration:3500})})}abrirArchivoDenunciado(i,e=!1){this.denunciadoService.descargarArchivo(i.id).subscribe({next:t=>e?Kr(t,i.nombreArchivo):Xr(t),error:t=>this.snackBar.open(Ne(t,"No fue posible abrir el archivo."),"Cerrar",{duration:3500})})}tamanio(i){return i?i>1024*1024?(i/1024/1024).toFixed(1)+" MB":Math.max(1,Math.round(i/1024))+" KB":""}get ultimaSolicitudDenunciado(){return this.solicitudesDenunciado[0]}cargarDenunciado(){this.denunciadoService.listarSolicitudes(this.folio).subscribe({next:e=>{this.solicitudesDenunciado=e,this.cdr.detectChanges()}});let i=this.expediente?.folioOrigen;i&&this.denunciadoService.listarRespuestas(i).subscribe({next:e=>{this.respuestasDenunciado=[...e].sort((t,a)=>(a.fechaRegistro??"").localeCompare(t.fechaRegistro??"")),this.cdr.detectChanges()}})}solicitarRespuestaDenunciado(){let i=this.expediente?.folioOrigen;if(!i)return;let e={folioQueja:i,denunciado:this.expediente?.datosQueja?.denunciado,correoAnterior:this.ultimaSolicitudDenunciado?.correoDenunciado};this.dialog.open(ul,{width:"560px",data:e}).afterClosed().subscribe(t=>{t&&(this.enviandoSolicitudDenunciado=!0,this.denunciadoService.enviarSolicitud(this.folio,t).subscribe({next:()=>{this.enviandoSolicitudDenunciado=!1,this.snackBar.open(`Se envi\xF3 la solicitud a ${t}.`,"Cerrar",{duration:3500}),this.cargarDenunciado()},error:a=>{this.enviandoSolicitudDenunciado=!1,this.snackBar.open(Ne(a,"No fue posible enviar la solicitud."),"Cerrar",{duration:4500}),this.cargarDenunciado()}}))})}verRespuestaDenunciado(){let i=this.expediente?.folioOrigen;if(!i||this.respuestasDenunciado.length===0)return;let e={folioQueja:i,respuestas:this.respuestasDenunciado};this.dialog.open(ml,{width:"720px",data:e})}cargarCitaActiva(){this.agendaService.listarPorFolio(this.folio).subscribe({next:i=>{this.citaActiva=i.find(e=>!K_(e)),this.historialCitas=i,this.cdr.detectChanges()}})}agendarCita(){this.mostrarNuevaCita=!0}citaGuardada(){this.mostrarNuevaCita=!1,this.cargarCitaActiva()}irAAgenda(){this.router.navigate(["/agenda"])}marcarCompetente(){this.decision="competente",this.irAPestana("resolucion")}marcarImprocedente(){this.decision="improcedente",this.irAPestana("resolucion")}cancelarDecision(){this.decision=null,this.justificacion="",this.observacionesDictamen="",this.responsableTurno=""}registrarDictamen(){let i=this.justificacion.trim();if(!i){this.snackBar.open("Escribe la justificaci\xF3n del dictamen.","Cerrar",{duration:3e3});return}if(this.decision==="improcedente"){if(!confirm("\xBFDeclarar improcedente este expediente? Despu\xE9s deber\xE1s generar la remisi\xF3n a la instancia competente."))return;let e=this.observacionesDictamen.trim();this.procesando=!0,this.dictamenService.registrarImprocedencia({folio:this.folio,justificacion:e?`${i}

Observaciones: ${e}`:i}).subscribe({next:()=>{this.snackBar.open("Expediente declarado improcedente. Ahora genera la remisi\xF3n.","Cerrar",{duration:3500}),this.router.navigate(["/remision",this.folio])},error:t=>{this.procesando=!1,this.cdr.detectChanges(),this.snackBar.open(Ne(t,"No fue posible registrar la improcedencia."),"Cerrar",{duration:4e3})}});return}if(!this.responsableTurno){this.snackBar.open("Selecciona el responsable en Subdefensor\xEDa.","Cerrar",{duration:3e3});return}confirm("\xBFTurnar este expediente a Subdefensor\xEDa?")&&(this.procesando=!0,this.dictamenService.registrarCompetencia({folio:this.folio,justificacion:i,areaTurno:"Subdefensor\xEDa",responsableTurno:this.responsableTurno,observaciones:this.observacionesDictamen.trim()||void 0}).subscribe({next:e=>{this.procesando=!1,this.snackBar.open(e.folioSubdefensoria?`Expediente procedente y recibido por Subdefensor\xEDa (${e.folioSubdefensoria}).`:"El dictamen qued\xF3 registrado, pero Subdefensor\xEDa no respondi\xF3. Reintenta el env\xEDo.","Cerrar",{duration:4500}),this.cancelarDecision(),this.recargarExpediente()},error:e=>{this.procesando=!1,this.cdr.detectChanges(),this.snackBar.open(Ne(e,"No fue posible registrar el dictamen."),"Cerrar",{duration:4e3})}}))}verDictamen(){this.router.navigate(["/dictamen",this.expediente.folio,"consulta"])}irARemision(){this.router.navigate(["/remision",this.expediente.folio])}reenviarASubdefensoria(){this.procesando=!0,this.dictamenService.reenviarASubdefensoria(this.folio).subscribe({next:i=>{this.procesando=!1,this.expediente.folioSubdefensoria=i.folioSubdefensoria,this.cdr.detectChanges(),this.snackBar.open(`Subdefensor\xEDa recibi\xF3 el expediente (${i.folioSubdefensoria}).`,"Cerrar",{duration:3500})},error:i=>{this.procesando=!1,this.cdr.detectChanges(),this.snackBar.open(Ne(i,"No fue posible reenviar a Subdefensor\xEDa."),"Cerrar",{duration:4e3})}})}static \u0275fac=function(e){return new(e||n)(S(Ct),S(We),S(Yn),S(_l),S(bl),S(wo),S($n),S(Do),S(xo),S(Mt),S(Z),S(_o),S(An),S(bo),S(vl))};static \u0275cmp=A({type:n,selectors:[["app-expediente"]],decls:7,vars:2,consts:[["tplHistorial",""],[1,"page","exp"],[1,"pc-card"],[3,"folio"],[1,"vacio"],["type","button",1,"pc-link","volver",3,"click"],[1,"exp-cabeza"],[1,"exp-sub"],[1,"exp-meta"],[1,"exp-chips"],[1,"pc-chip","prioridad","grande"],[1,"pc-chip","unidad","grande"],["role","tablist",1,"exp-tabs"],["type","button","role","tab",3,"click"],[1,"exp-rejilla","ia"],[1,"exp-rejilla"],[1,"col"],[1,"pc-card-cabeza"],[1,"exp-etiqueta-ia"],[1,"exp-cargando"],[1,"pc-chip","unidad"],[1,"exp-fragmentos"],[1,"pc-card","rosa"],["type","button",1,"pc-link"],[1,"exp-barras"],["type","button",1,"pc-btn-borde","ancho",3,"click"],[1,"pc-chip"],[1,"barra"],[1,"exp-resumen"],[1,"exp-aviso"],[1,"acciones-der"],["type","button",1,"pc-btn-borde",3,"click"],["type","button",1,"pc-btn",3,"click"],[1,"pc-chip","prioridad"],["type","button",1,"pc-link",3,"click"],[1,"exp-nota"],[1,"exp-antecedentes"],["type","button",3,"click"],[1,"texto"],[1,"flecha"],[1,"exp-narrativa"],["type","button",1,"pc-link","derecha"],[1,"exp-datos","dos"],[1,"exp-cuenta"],[1,"exp-archivos"],[1,"exp-datos","lista"],[4,"ngTemplateOutlet"],["type","button",1,"pc-link","derecha",3,"click"],[1,"ico"],["type","button","title","Descargar",1,"ico-btn",3,"click"],["type","button","title","Abrir en otra pesta\xF1a",1,"ico-btn",3,"click"],["type","button",1,"pc-btn-borde","chico"],[1,"exp-nueva-nota"],[1,"exp-notas"],[3,"propia"],[1,"pc-vacio-caja"],[1,"exp-mas"],["type","button",1,"pc-btn-borde","chico",3,"disabled"],[1,"pc-timeline"],[1,"exp-form"],[1,"exp-acuerdo"],["type","button",1,"pc-btn-borde","chico",3,"click"],["rows","3","placeholder","Escribe la nota de an\xE1lisis\u2026","aria-label","Nueva nota",3,"ngModelChange","ngModel"],["type","button",1,"pc-btn","chico",3,"click"],[1,"nota-cabeza"],["rows","3","aria-label","Editar nota",3,"ngModelChange","ngModel"],[1,"nota-acciones"],["type","button","title","Editar nota",1,"ico-btn",3,"click"],["type","button","title","Eliminar nota",1,"ico-btn",3,"click"],[1,"exp-respuesta"],[1,"ok"],[1,"exp-subtitulo"],["type","button","title","Abrir",1,"ico-btn",3,"click"],[1,"exp-cita"],[1,"exp-cita-fecha"],[1,"rojo"],["type","button",1,"pc-btn-borde","chico",3,"click","disabled"],[1,"punto","lleno","azul"],[1,"punto"],[1,"punto","lleno"],[1,"pc-campo"],["type","text","maxlength","255","placeholder","Ej. Revisi\xF3n de la calificaci\xF3n y disculpa por escrito",3,"ngModelChange","ngModel"],["rows","4","placeholder","Qu\xE9 se compromete a hacer cada parte y en qu\xE9 plazo.",3,"ngModelChange","ngModel"],["type","button",1,"pc-btn","chico",3,"click","disabled"],[1,"cita-quejoso"],[1,"exp-datos","tabla"],[1,"exp-ant-resumen"],["type","button",1,"pc-btn",3,"disabled"],["type","button",1,"pc-btn",3,"click","disabled"],[1,"exp-decision"],["type","button",1,"opcion","competente",3,"click","disabled"],[1,"radio"],["type","button",1,"opcion","improcedente",3,"click","disabled"],[1,"exp-dictamen"],[1,"req"],["rows","4","maxlength","1000",3,"ngModelChange","ngModel","placeholder"],[1,"contador"],["rows","3","maxlength","1000","placeholder","Ingrese observaciones adicionales (opcional).",3,"ngModelChange","ngModel"],[3,"ngModelChange","ngModel"],["value","","disabled",""],[3,"value"],[1,"contador","izq"],[1,"caja"],[3,"guardada","cerrar","folio"]],template:function(e,t){e&1&&(s(0,"section",1),v(1,ZD,3,0,"div",2)(2,JD,6,1,"div",2)(3,vS,38,19),r(),_e(4,CS,4,1,"ng-template",null,0,Ia),v(6,wS,1,1,"app-nueva-cita",3)),e&2&&(d(),y(t.cargando?1:t.sinDatos?2:3),d(5),y(t.mostrarNuevaCita?6:-1))},dependencies:[Ot,io,ao,ft,Ai,Tt,sa,St,sn,Ge,ze,Ve,Un,kt,mn,fo,Ft,Nt,Co,Qi,od],styles:[".exp[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:16px}.vacio[_ngcontent-%COMP%]{color:var(--texto-suave);font-size:13.5px;list-style:none}.rojo[_ngcontent-%COMP%]{color:#b42318}.volver[_ngcontent-%COMP%]{align-self:flex-start}.exp-cabeza[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap}.exp-cabeza[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{display:flex;align-items:center;gap:14px;margin:0;color:var(--guinda);font-size:32px;font-weight:800}.exp-cabeza[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]   .estatus-chip[_ngcontent-%COMP%]{font-size:13px}.exp-sub[_ngcontent-%COMP%]{margin:6px 0 0;color:#444;font-size:15px}.exp-meta[_ngcontent-%COMP%]{display:flex;align-items:center;gap:6px;margin:4px 0 0;color:var(--texto-suave);font-size:13.5px}.exp-meta[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:18px;width:18px;height:18px;color:var(--guinda)}.exp-chips[_ngcontent-%COMP%]{display:flex;gap:10px}.pc-chip.grande[_ngcontent-%COMP%]{padding:8px 16px;border-radius:8px;font-size:14px}.exp-tabs[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;padding:6px;border:1px solid #eceef1;border-radius:12px;background:#fff}.exp-tabs[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:10px;height:44px;border:none;border-radius:8px;background:none;color:#333;font:inherit;font-size:15px;font-weight:600;cursor:pointer}.exp-tabs[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{color:var(--guinda)}.exp-tabs[_ngcontent-%COMP%]   button.activa[_ngcontent-%COMP%]{background:var(--guinda);color:#fff}.exp-tabs[_ngcontent-%COMP%]   button.activa[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{color:#fff}.exp-rejilla[_ngcontent-%COMP%]{display:grid;grid-template-columns:minmax(0,1.55fr) minmax(0,1fr);gap:18px;align-items:start}.exp-rejilla[_ngcontent-%COMP%]   .col[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:18px;min-width:0}@media(max-width:1100px){.exp-rejilla[_ngcontent-%COMP%]{grid-template-columns:minmax(0,1fr)}.exp-tabs[_ngcontent-%COMP%]{grid-template-columns:repeat(2,minmax(0,1fr))}}.acciones-der[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;flex-wrap:wrap;gap:10px;margin-top:12px}.pc-btn-borde.ancho[_ngcontent-%COMP%]{width:100%;margin-top:14px}.pc-link.derecha[_ngcontent-%COMP%]{float:right;margin-top:6px}.pc-card.rosa[_ngcontent-%COMP%]{background:#fff7f9;border-color:#f3dbe3}.exp-etiqueta-ia[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px}.exp-etiqueta-ia[_ngcontent-%COMP%]   .pc-chip[_ngcontent-%COMP%]{background:#eaf0fd;color:#2450b5}.exp-etiqueta-ia[_ngcontent-%COMP%]   .pc-chip.simulado[_ngcontent-%COMP%]{background:#fff4dc;color:#9a6a00}.exp-etiqueta-ia[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:var(--texto-suave)}.exp-resumen[_ngcontent-%COMP%]{margin:0;font-size:15px;line-height:1.65;color:#222}.exp-aviso[_ngcontent-%COMP%]{margin:10px 0 0;padding:8px 12px;border-radius:8px;background:#fff8e6;color:#7a5200;font-size:13px}.exp-cargando[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:10px;color:var(--texto-suave);font-size:14px}.exp-cargando[_ngcontent-%COMP%]   .barra[_ngcontent-%COMP%]{height:4px;border-radius:2px;background:linear-gradient(90deg,#f3dbe3 0%,var(--guinda) 50%,#f3dbe3 100%);background-size:200% 100%;animation:_ngcontent-%COMP%_exp-cargar 1.4s linear infinite}@keyframes _ngcontent-%COMP%_exp-cargar{0%{background-position:200% 0}to{background-position:0 0}}.exp-fragmentos[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:10px;margin:0;padding:0;list-style:none}.exp-fragmentos[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{display:grid;grid-template-columns:26px 1fr auto;align-items:start;gap:10px;padding:10px 12px;border-left:4px solid var(--guinda);border-radius:6px;background:#fbf2f5}.exp-fragmentos[_ngcontent-%COMP%]   li.vacio[_ngcontent-%COMP%]{display:block;border:none;background:none}.exp-fragmentos[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{color:var(--guinda)}.exp-fragmentos[_ngcontent-%COMP%]   q[_ngcontent-%COMP%]{font-size:13.5px;line-height:1.5}.exp-nota[_ngcontent-%COMP%]{margin:-6px 0 12px;color:var(--texto-suave);font-size:13.5px}.exp-antecedentes[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:8px;margin:0;padding:0;list-style:none}.exp-antecedentes[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{display:grid;grid-template-columns:26px 1fr auto 22px;align-items:center;gap:10px;width:100%;padding:10px 12px;border:1px solid #f0e2e8;border-radius:10px;background:#fff;font:inherit;text-align:left;cursor:pointer}.exp-antecedentes[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover{border-color:var(--guinda-vivo)}.exp-antecedentes[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{color:var(--guinda)}.exp-antecedentes[_ngcontent-%COMP%]   .texto[_ngcontent-%COMP%]   b[_ngcontent-%COMP%], .exp-archivos[_ngcontent-%COMP%]   .texto[_ngcontent-%COMP%]   b[_ngcontent-%COMP%]{display:block;font-size:14px}.exp-antecedentes[_ngcontent-%COMP%]   .texto[_ngcontent-%COMP%]   small[_ngcontent-%COMP%], .exp-archivos[_ngcontent-%COMP%]   .texto[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:#555;font-size:12.5px}.sim[_ngcontent-%COMP%]{padding:4px 10px;border-radius:6px;font-size:13px;font-weight:800}.sim.alta[_ngcontent-%COMP%]{background:#fde4ec;color:#9d2449}.sim.media[_ngcontent-%COMP%]{background:#fdeef3;color:#c0507a}.sim.baja[_ngcontent-%COMP%]{background:#eef0fd;color:#5b5bd6}.exp-barras[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:10px;margin:0;padding:0;list-style:none;font-size:13px}.exp-barras[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{display:grid;grid-template-columns:110px 1fr 40px;align-items:center;gap:10px}.exp-barras[_ngcontent-%COMP%]   .barra[_ngcontent-%COMP%]{height:12px;border-radius:6px;background:#eef0f3;overflow:hidden}.exp-barras[_ngcontent-%COMP%]   .barra[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{display:block;height:100%;border-radius:inherit}.exp-barras[_ngcontent-%COMP%]   .alta[_ngcontent-%COMP%]{background:var(--guinda)}.exp-barras[_ngcontent-%COMP%]   .media[_ngcontent-%COMP%]{background:#c0507a}.exp-barras[_ngcontent-%COMP%]   .baja[_ngcontent-%COMP%]{background:#8b8bec}.exp-narrativa[_ngcontent-%COMP%]{max-height:260px;overflow:hidden;padding:14px 16px;border-radius:10px;background:#f7f8fa;font-size:14.5px;line-height:1.7;white-space:pre-line;-webkit-mask-image:linear-gradient(180deg,#000 75%,transparent);mask-image:linear-gradient(180deg,#000 75%,transparent)}.exp-narrativa.completa[_ngcontent-%COMP%]{max-height:none;-webkit-mask-image:none;mask-image:none}.exp-datos[_ngcontent-%COMP%]{margin:0}.exp-datos.dos[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:0 24px}.exp-datos.dos[_ngcontent-%COMP%]   dl[_ngcontent-%COMP%]{margin:0}.exp-datos[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{display:grid;grid-template-columns:minmax(150px,1fr) 1.2fr;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #f1f2f4;font-size:13.5px}.exp-datos[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:last-child{border-bottom:none}.exp-datos[_ngcontent-%COMP%]   dt[_ngcontent-%COMP%]{display:flex;align-items:center;gap:8px;color:#444}.exp-datos[_ngcontent-%COMP%]   dt[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:18px;width:18px;height:18px;color:var(--guinda)}.exp-datos[_ngcontent-%COMP%]   dd[_ngcontent-%COMP%]{margin:0;font-weight:600;word-break:break-word}.exp-datos.tabla[_ngcontent-%COMP%]   dt[_ngcontent-%COMP%]{color:#555}@media(max-width:700px){.exp-datos.dos[_ngcontent-%COMP%]{grid-template-columns:1fr}}.exp-cuenta[_ngcontent-%COMP%]{color:var(--texto-suave);font-size:13px}.exp-archivos[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:8px;margin:0;padding:0;list-style:none}.exp-archivos[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{display:grid;grid-template-columns:30px 1fr auto auto;align-items:center;gap:10px;padding:10px 12px;border:1px solid #eceef1;border-radius:10px}.exp-archivos[_ngcontent-%COMP%]   li.vacio[_ngcontent-%COMP%]{display:block;border:none}.exp-archivos[_ngcontent-%COMP%]   .ico[_ngcontent-%COMP%]{color:var(--guinda)}.exp-archivos[_ngcontent-%COMP%]   .texto[_ngcontent-%COMP%]{min-width:0;overflow:hidden}.exp-archivos[_ngcontent-%COMP%]   .texto[_ngcontent-%COMP%]   b[_ngcontent-%COMP%]{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ico-btn[_ngcontent-%COMP%]{display:grid;place-items:center;width:32px;height:32px;border:none;border-radius:6px;background:none;color:var(--guinda);cursor:pointer}.ico-btn[_ngcontent-%COMP%]:hover{background:var(--guinda-suave)}.exp-subtitulo[_ngcontent-%COMP%]{margin:14px 0 8px;color:var(--texto-suave);font-size:12.5px;letter-spacing:.04em;text-transform:uppercase}.exp-nueva-nota[_ngcontent-%COMP%], .exp-form[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:12px;margin-bottom:12px}.exp-nueva-nota[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%], .exp-notas[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%]{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #d5d8de;border-radius:8px;font:inherit;font-size:14px;resize:vertical}.exp-notas[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:10px;margin:0;padding:0;list-style:none}.exp-notas[_ngcontent-%COMP%] > li[_ngcontent-%COMP%]:not(.vacio){position:relative;padding:12px 14px;border-left:4px solid #e2b9c8;border-radius:8px;background:#fbf2f5}.exp-notas[_ngcontent-%COMP%] > li.propia[_ngcontent-%COMP%]{border-left-color:var(--guinda)}.nota-cabeza[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;gap:10px}.nota-cabeza[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:var(--texto-suave)}.exp-notas[_ngcontent-%COMP%]   p[_ngcontent-%COMP%], .exp-acuerdo[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:6px 0 0;font-size:14px}.nota-acciones[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;gap:4px}.exp-respuesta[_ngcontent-%COMP%]{display:grid;grid-template-columns:30px 1fr auto;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;background:#f1f6fd}.exp-respuesta[_ngcontent-%COMP%]   .ok[_ngcontent-%COMP%]{color:#2e9d4a}.exp-respuesta[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{display:block;color:#555;font-size:13px}.exp-cita[_ngcontent-%COMP%]{display:grid;grid-template-columns:56px 1fr auto;align-items:center;gap:12px;margin-bottom:8px;padding:10px 12px;border:1px solid #eceef1;border-radius:10px}.exp-cita-fecha[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;padding:6px 0;border-radius:8px;background:#fbf0f4;color:var(--guinda)}.exp-cita-fecha[_ngcontent-%COMP%]   b[_ngcontent-%COMP%]{font-size:20px;line-height:1}.exp-cita[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{display:block;color:#555;font-size:12.5px}.exp-mas[_ngcontent-%COMP%]{margin-top:10px;font-size:13px}.exp-mas[_ngcontent-%COMP%]   summary[_ngcontent-%COMP%]{color:var(--guinda);font-weight:700;cursor:pointer}.exp-mas[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]{margin:8px 0 0;padding:0;list-style:none}.exp-mas[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{display:flex;justify-content:space-between;gap:8px;padding:6px 0;border-bottom:1px solid #f1f2f4}.exp-acuerdo[_ngcontent-%COMP%]{margin-top:10px;padding:12px 14px;border:1px solid #eceef1;border-radius:10px}.exp-acuerdo[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{display:block;margin-top:6px;color:var(--texto-suave)}.cita-quejoso[_ngcontent-%COMP%]{font-style:italic;color:#555}.exp-decision[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px}.exp-decision[_ngcontent-%COMP%]   .opcion[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:14px;padding:16px;border:1.5px solid;border-radius:10px;font:inherit;text-align:left;cursor:pointer}.exp-decision[_ngcontent-%COMP%]   .opcion.competente[_ngcontent-%COMP%]{border-color:#b4dcb9;background:#f4fbf5}.exp-decision[_ngcontent-%COMP%]   .opcion.improcedente[_ngcontent-%COMP%]{border-color:#f4b4b4;background:#fef4f4}.exp-decision[_ngcontent-%COMP%]   .opcion.sel.competente[_ngcontent-%COMP%]{border-color:#2e9d4a;box-shadow:0 0 0 1px #2e9d4a}.exp-decision[_ngcontent-%COMP%]   .opcion.sel.improcedente[_ngcontent-%COMP%]{border-color:#c62828;box-shadow:0 0 0 1px #c62828}.exp-decision[_ngcontent-%COMP%]   .opcion[_ngcontent-%COMP%]:disabled{opacity:.55;cursor:not-allowed}.exp-decision[_ngcontent-%COMP%]   .radio[_ngcontent-%COMP%]{width:20px;height:20px;flex-shrink:0;margin-top:2px;box-sizing:border-box;border:2px solid #9aa0a6;border-radius:50%}.exp-decision[_ngcontent-%COMP%]   .opcion.competente.sel[_ngcontent-%COMP%]   .radio[_ngcontent-%COMP%]{border:6px solid #2e9d4a}.exp-decision[_ngcontent-%COMP%]   .opcion.improcedente.sel[_ngcontent-%COMP%]   .radio[_ngcontent-%COMP%]{border:6px solid #c62828}.exp-decision[_ngcontent-%COMP%]   b[_ngcontent-%COMP%]{display:block;font-size:15px}.exp-decision[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:#555;font-size:13px}.exp-dictamen[_ngcontent-%COMP%]{display:flex;align-items:center;gap:14px;margin-bottom:14px;padding:12px 16px;border-radius:10px;background:#eef5fd}.exp-dictamen[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{color:#2e9d4a;font-size:30px;width:30px;height:30px}.exp-dictamen.improcedente[_ngcontent-%COMP%]{background:#fdeef0}.exp-dictamen.improcedente[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{color:#c62828}.exp-dictamen[_ngcontent-%COMP%]   b[_ngcontent-%COMP%]{display:block}.exp-dictamen[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:#555}.contador[_ngcontent-%COMP%]{align-self:flex-end;color:var(--texto-suave);font-size:12px;font-weight:400}.contador.izq[_ngcontent-%COMP%]{align-self:flex-start}.exp-ant-resumen[_ngcontent-%COMP%]{display:flex;align-items:center;gap:14px;padding:12px 16px;border-radius:10px;background:#fdf1f4}.exp-ant-resumen[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{color:var(--guinda)}.exp-ant-resumen[_ngcontent-%COMP%]   b[_ngcontent-%COMP%], .exp-ant-resumen[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{display:block}.exp-ant-resumen[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:#555}"]})};function ES(n,i){return n.length<=i?n:n.slice(0,i-1).trimEnd()+"\u2026"}var SS=["switch"],kS=["*"];function MS(n,i){n&1&&(s(0,"span",11),Zn(),s(1,"svg",13),H(2,"path",14),r(),s(3,"svg",15),H(4,"path",16),r()())}var IS=new E("mat-slide-toggle-default-options",{providedIn:"root",factory:()=>({disableToggleValue:!1,hideIcon:!1,disabledInteractive:!1})}),xl=class{source;checked;constructor(i,e){this.source=i,this.checked=e}},hm=(()=>{class n{_elementRef=m(B);_focusMonitor=m(Dt);_changeDetectorRef=m(Z);defaults=m(IS);_onChange=e=>{};_onTouched=()=>{};_validatorOnChange=()=>{};_uniqueId;_checked=!1;_createChangeEvent(e){return new xl(this,e)}_labelId;get buttonId(){return`${this.id||this._uniqueId}-button`}_switchElement;focus(){this._switchElement.nativeElement.focus()}_noopAnimations=Ee();_focused=!1;name=null;id;labelPosition="after";ariaLabel=null;ariaLabelledby=null;ariaDescribedby;required=!1;color;disabled=!1;disableRipple=!1;tabIndex=0;get checked(){return this._checked}set checked(e){this._checked=e,this._changeDetectorRef.markForCheck()}hideIcon;disabledInteractive;change=new z;toggleChange=new z;get inputId(){return`${this.id||this._uniqueId}-input`}constructor(){m(Oe).load(Et);let e=m(new xt("tabindex"),{optional:!0}),t=this.defaults;this.tabIndex=e==null?0:parseInt(e)||0,this.color=t.color||"accent",this.id=this._uniqueId=m(xe).getId("mat-mdc-slide-toggle-"),this.hideIcon=t.hideIcon??!1,this.disabledInteractive=t.disabledInteractive??!1,this._labelId=this._uniqueId+"-label"}ngAfterContentInit(){this._focusMonitor.monitor(this._elementRef,!0).subscribe(e=>{e==="keyboard"||e==="program"?(this._focused=!0,this._changeDetectorRef.markForCheck()):e||Promise.resolve().then(()=>{this._focused=!1,this._onTouched(),this._changeDetectorRef.markForCheck()})})}ngOnChanges(e){e.required&&this._validatorOnChange()}ngOnDestroy(){this._focusMonitor.stopMonitoring(this._elementRef)}writeValue(e){this.checked=!!e}registerOnChange(e){this._onChange=e}registerOnTouched(e){this._onTouched=e}validate(e){return this.required&&e.value!==!0?{required:!0}:null}registerOnValidatorChange(e){this._validatorOnChange=e}setDisabledState(e){this.disabled=e,this._changeDetectorRef.markForCheck()}toggle(){this.checked=!this.checked,this._onChange(this.checked)}_emitChangeEvent(){this._onChange(this.checked),this.change.emit(this._createChangeEvent(this.checked))}_handleClick(){this.disabled||(this.toggleChange.emit(),this.defaults.disableToggleValue||(this.checked=!this.checked,this._onChange(this.checked),this.change.emit(new xl(this,this.checked))))}_getAriaLabelledBy(){return this.ariaLabelledby?this.ariaLabelledby:this.ariaLabel?null:this._labelId}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-slide-toggle"]],viewQuery:function(t,a){if(t&1&&Ae(SS,5),t&2){let o;j(o=V())&&(a._switchElement=o.first)}},hostAttrs:[1,"mat-mdc-slide-toggle"],hostVars:13,hostBindings:function(t,a){t&2&&(jt("id",a.id),Y("tabindex",null)("aria-label",null)("name",null)("aria-labelledby",null),ve(a.color?"mat-"+a.color:""),k("mat-mdc-slide-toggle-focused",a._focused)("mat-mdc-slide-toggle-checked",a.checked)("_mat-animation-noopable",a._noopAnimations))},inputs:{name:"name",id:"id",labelPosition:"labelPosition",ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],ariaDescribedby:[0,"aria-describedby","ariaDescribedby"],required:[2,"required","required",R],color:"color",disabled:[2,"disabled","disabled",R],disableRipple:[2,"disableRipple","disableRipple",R],tabIndex:[2,"tabIndex","tabIndex",e=>e==null?0:lt(e)],checked:[2,"checked","checked",R],hideIcon:[2,"hideIcon","hideIcon",R],disabledInteractive:[2,"disabledInteractive","disabledInteractive",R]},outputs:{change:"change",toggleChange:"toggleChange"},exportAs:["matSlideToggle"],features:[ce([{provide:zn,useExisting:It(()=>n),multi:!0},{provide:Ii,useExisting:n,multi:!0}]),we],ngContentSelectors:kS,decls:14,vars:27,consts:[["switch",""],["mat-internal-form-field","",3,"labelPosition"],["role","switch","type","button",1,"mdc-switch",3,"click","tabIndex","disabled"],[1,"mat-mdc-slide-toggle-touch-target"],[1,"mdc-switch__track"],[1,"mdc-switch__handle-track"],[1,"mdc-switch__handle"],[1,"mdc-switch__shadow"],[1,"mdc-elevation-overlay"],[1,"mdc-switch__ripple"],["mat-ripple","",1,"mat-mdc-slide-toggle-ripple","mat-focus-indicator",3,"matRippleTrigger","matRippleDisabled","matRippleCentered"],[1,"mdc-switch__icons"],[1,"mdc-label",3,"click","for"],["viewBox","0 0 24 24","aria-hidden","true",1,"mdc-switch__icon","mdc-switch__icon--on"],["d","M19.69,5.23L8.96,15.96l-4.23-4.23L2.96,13.5l6,6L21.46,7L19.69,5.23z"],["viewBox","0 0 24 24","aria-hidden","true",1,"mdc-switch__icon","mdc-switch__icon--off"],["d","M20 13H4v-2h16v2z"]],template:function(t,a){if(t&1&&(ye(),s(0,"div",1)(1,"button",2,0),_("click",function(){return a._handleClick()}),H(3,"div",3)(4,"span",4),s(5,"span",5)(6,"span",6)(7,"span",7),H(8,"span",8),r(),s(9,"span",9),H(10,"span",10),r(),v(11,MS,5,0,"span",11),r()()(),s(12,"label",12),_("click",function(c){return c.stopPropagation()}),ee(13),r()()),t&2){let o=ct(2);P("labelPosition",a.labelPosition),d(),k("mdc-switch--selected",a.checked)("mdc-switch--unselected",!a.checked)("mdc-switch--checked",a.checked)("mdc-switch--disabled",a.disabled)("mat-mdc-slide-toggle-disabled-interactive",a.disabledInteractive),P("tabIndex",a.disabled&&!a.disabledInteractive?-1:a.tabIndex)("disabled",a.disabled&&!a.disabledInteractive),Y("id",a.buttonId)("name",a.name)("aria-label",a.ariaLabel)("aria-labelledby",a._getAriaLabelledBy())("aria-describedby",a.ariaDescribedby)("aria-required",a.required||null)("aria-checked",a.checked)("aria-disabled",a.disabled&&a.disabledInteractive?"true":null),d(9),P("matRippleTrigger",o)("matRippleDisabled",a.disableRipple||a.disabled)("matRippleCentered",!0),d(),y(a.hideIcon?-1:11),d(),P("for",a.buttonId),Y("id",a._labelId)}},dependencies:[xn,tl],styles:[`.mdc-switch {
  align-items: center;
  background: none;
  border: none;
  cursor: pointer;
  display: inline-flex;
  flex-shrink: 0;
  margin: 0;
  outline: none;
  overflow: visible;
  padding: 0;
  position: relative;
  width: var(--mat-slide-toggle-track-width, 52px);
}
.mdc-switch.mdc-switch--disabled {
  cursor: default;
  pointer-events: none;
}
.mdc-switch.mat-mdc-slide-toggle-disabled-interactive {
  pointer-events: auto;
}

.mdc-switch__track {
  overflow: hidden;
  position: relative;
  width: 100%;
  height: var(--mat-slide-toggle-track-height, 32px);
  border-radius: var(--mat-slide-toggle-track-shape, var(--mat-sys-corner-full));
}
.mdc-switch--disabled.mdc-switch .mdc-switch__track {
  opacity: var(--mat-slide-toggle-disabled-track-opacity, 0.12);
}
.mdc-switch__track::before, .mdc-switch__track::after {
  border: 1px solid transparent;
  border-radius: inherit;
  box-sizing: border-box;
  content: "";
  height: 100%;
  left: 0;
  position: absolute;
  width: 100%;
  border-width: var(--mat-slide-toggle-track-outline-width, 2px);
  border-color: var(--mat-slide-toggle-track-outline-color, var(--mat-sys-outline));
}
.mdc-switch--selected .mdc-switch__track::before, .mdc-switch--selected .mdc-switch__track::after {
  border-width: var(--mat-slide-toggle-selected-track-outline-width, 2px);
  border-color: var(--mat-slide-toggle-selected-track-outline-color, transparent);
}
.mdc-switch--disabled .mdc-switch__track::before, .mdc-switch--disabled .mdc-switch__track::after {
  border-width: var(--mat-slide-toggle-disabled-unselected-track-outline-width, 2px);
  border-color: var(--mat-slide-toggle-disabled-unselected-track-outline-color, var(--mat-sys-on-surface));
}
@media (forced-colors: active) {
  .mdc-switch__track {
    border-color: currentColor;
  }
}
.mdc-switch__track::before {
  transition: transform 75ms 0ms cubic-bezier(0, 0, 0.2, 1);
  transform: translateX(0);
  background: var(--mat-slide-toggle-unselected-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch--selected .mdc-switch__track::before {
  transition: transform 75ms 0ms cubic-bezier(0.4, 0, 0.6, 1);
  transform: translateX(100%);
}
[dir=rtl] .mdc-switch--selected .mdc-switch--selected .mdc-switch__track::before {
  transform: translateX(-100%);
}
.mdc-switch--selected .mdc-switch__track::before {
  opacity: var(--mat-slide-toggle-hidden-track-opacity, 0);
  transition: var(--mat-slide-toggle-hidden-track-transition, opacity 75ms);
}
.mdc-switch--unselected .mdc-switch__track::before {
  opacity: var(--mat-slide-toggle-visible-track-opacity, 1);
  transition: var(--mat-slide-toggle-visible-track-transition, opacity 75ms);
}
.mdc-switch:enabled:hover:not(:focus):not(:active) .mdc-switch__track::before {
  background: var(--mat-slide-toggle-unselected-hover-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch:enabled:focus:not(:active) .mdc-switch__track::before {
  background: var(--mat-slide-toggle-unselected-focus-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch:enabled:active .mdc-switch__track::before {
  background: var(--mat-slide-toggle-unselected-pressed-track-color, var(--mat-sys-surface-variant));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:hover:not(:focus):not(:active) .mdc-switch__track::before, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:focus:not(:active) .mdc-switch__track::before, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:active .mdc-switch__track::before, .mdc-switch.mdc-switch--disabled .mdc-switch__track::before {
  background: var(--mat-slide-toggle-disabled-unselected-track-color, var(--mat-sys-surface-variant));
}
.mdc-switch__track::after {
  transform: translateX(-100%);
  background: var(--mat-slide-toggle-selected-track-color, var(--mat-sys-primary));
}
[dir=rtl] .mdc-switch__track::after {
  transform: translateX(100%);
}
.mdc-switch--selected .mdc-switch__track::after {
  transform: translateX(0);
}
.mdc-switch--selected .mdc-switch__track::after {
  opacity: var(--mat-slide-toggle-visible-track-opacity, 1);
  transition: var(--mat-slide-toggle-visible-track-transition, opacity 75ms);
}
.mdc-switch--unselected .mdc-switch__track::after {
  opacity: var(--mat-slide-toggle-hidden-track-opacity, 0);
  transition: var(--mat-slide-toggle-hidden-track-transition, opacity 75ms);
}
.mdc-switch:enabled:hover:not(:focus):not(:active) .mdc-switch__track::after {
  background: var(--mat-slide-toggle-selected-hover-track-color, var(--mat-sys-primary));
}
.mdc-switch:enabled:focus:not(:active) .mdc-switch__track::after {
  background: var(--mat-slide-toggle-selected-focus-track-color, var(--mat-sys-primary));
}
.mdc-switch:enabled:active .mdc-switch__track::after {
  background: var(--mat-slide-toggle-selected-pressed-track-color, var(--mat-sys-primary));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:hover:not(:focus):not(:active) .mdc-switch__track::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:focus:not(:active) .mdc-switch__track::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:active .mdc-switch__track::after, .mdc-switch.mdc-switch--disabled .mdc-switch__track::after {
  background: var(--mat-slide-toggle-disabled-selected-track-color, var(--mat-sys-on-surface));
}

.mdc-switch__handle-track {
  height: 100%;
  pointer-events: none;
  position: absolute;
  top: 0;
  transition: transform 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
  left: 0;
  right: auto;
  transform: translateX(0);
  width: calc(100% - var(--mat-slide-toggle-handle-width));
}
[dir=rtl] .mdc-switch__handle-track {
  left: auto;
  right: 0;
}
.mdc-switch--selected .mdc-switch__handle-track {
  transform: translateX(100%);
}
[dir=rtl] .mdc-switch--selected .mdc-switch__handle-track {
  transform: translateX(-100%);
}

.mdc-switch__handle {
  display: flex;
  pointer-events: auto;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  left: 0;
  right: auto;
  transition: width 75ms cubic-bezier(0.4, 0, 0.2, 1), height 75ms cubic-bezier(0.4, 0, 0.2, 1), margin 75ms cubic-bezier(0.4, 0, 0.2, 1);
  width: var(--mat-slide-toggle-handle-width);
  height: var(--mat-slide-toggle-handle-height);
  border-radius: var(--mat-slide-toggle-handle-shape, var(--mat-sys-corner-full));
}
[dir=rtl] .mdc-switch__handle {
  left: auto;
  right: 0;
}
.mat-mdc-slide-toggle .mdc-switch--unselected .mdc-switch__handle {
  width: var(--mat-slide-toggle-unselected-handle-size, 16px);
  height: var(--mat-slide-toggle-unselected-handle-size, 16px);
  margin: var(--mat-slide-toggle-unselected-handle-horizontal-margin, 0 8px);
}
.mat-mdc-slide-toggle .mdc-switch--unselected .mdc-switch__handle:has(.mdc-switch__icons) {
  margin: var(--mat-slide-toggle-unselected-with-icon-handle-horizontal-margin, 0 4px);
}
.mat-mdc-slide-toggle .mdc-switch--selected .mdc-switch__handle {
  width: var(--mat-slide-toggle-selected-handle-size, 24px);
  height: var(--mat-slide-toggle-selected-handle-size, 24px);
  margin: var(--mat-slide-toggle-selected-handle-horizontal-margin, 0 24px);
}
.mat-mdc-slide-toggle .mdc-switch--selected .mdc-switch__handle:has(.mdc-switch__icons) {
  margin: var(--mat-slide-toggle-selected-with-icon-handle-horizontal-margin, 0 24px);
}
.mat-mdc-slide-toggle .mdc-switch__handle:has(.mdc-switch__icons) {
  width: var(--mat-slide-toggle-with-icon-handle-size, 24px);
  height: var(--mat-slide-toggle-with-icon-handle-size, 24px);
}
.mat-mdc-slide-toggle .mdc-switch:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  width: var(--mat-slide-toggle-pressed-handle-size, 28px);
  height: var(--mat-slide-toggle-pressed-handle-size, 28px);
}
.mat-mdc-slide-toggle .mdc-switch--selected:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  margin: var(--mat-slide-toggle-selected-pressed-handle-horizontal-margin, 0 22px);
}
.mat-mdc-slide-toggle .mdc-switch--unselected:active:not(.mdc-switch--disabled) .mdc-switch__handle {
  margin: var(--mat-slide-toggle-unselected-pressed-handle-horizontal-margin, 0 2px);
}
.mdc-switch--disabled.mdc-switch--selected .mdc-switch__handle::after {
  opacity: var(--mat-slide-toggle-disabled-selected-handle-opacity, 1);
}
.mdc-switch--disabled.mdc-switch--unselected .mdc-switch__handle::after {
  opacity: var(--mat-slide-toggle-disabled-unselected-handle-opacity, 0.38);
}
.mdc-switch__handle::before, .mdc-switch__handle::after {
  border: 1px solid transparent;
  border-radius: inherit;
  box-sizing: border-box;
  content: "";
  width: 100%;
  height: 100%;
  left: 0;
  position: absolute;
  top: 0;
  transition: background-color 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1), border-color 75ms 0ms cubic-bezier(0.4, 0, 0.2, 1);
  z-index: -1;
}
@media (forced-colors: active) {
  .mdc-switch__handle::before, .mdc-switch__handle::after {
    border-color: currentColor;
  }
}
.mdc-switch--selected:enabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-handle-color, var(--mat-sys-on-primary));
}
.mdc-switch--selected:enabled:hover:not(:focus):not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-hover-handle-color, var(--mat-sys-primary-container));
}
.mdc-switch--selected:enabled:focus:not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-focus-handle-color, var(--mat-sys-primary-container));
}
.mdc-switch--selected:enabled:active .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-selected-pressed-handle-color, var(--mat-sys-primary-container));
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--selected:hover:not(:focus):not(:active) .mdc-switch__handle::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--selected:focus:not(:active) .mdc-switch__handle::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled.mdc-switch--selected:active .mdc-switch__handle::after, .mdc-switch--selected.mdc-switch--disabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-disabled-selected-handle-color, var(--mat-sys-surface));
}
.mdc-switch--unselected:enabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-handle-color, var(--mat-sys-outline));
}
.mdc-switch--unselected:enabled:hover:not(:focus):not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-hover-handle-color, var(--mat-sys-on-surface-variant));
}
.mdc-switch--unselected:enabled:focus:not(:active) .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-focus-handle-color, var(--mat-sys-on-surface-variant));
}
.mdc-switch--unselected:enabled:active .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-unselected-pressed-handle-color, var(--mat-sys-on-surface-variant));
}
.mdc-switch--unselected.mdc-switch--disabled .mdc-switch__handle::after {
  background: var(--mat-slide-toggle-disabled-unselected-handle-color, var(--mat-sys-on-surface));
}
.mdc-switch__handle::before {
  background: var(--mat-slide-toggle-handle-surface-color);
}

.mdc-switch__shadow {
  border-radius: inherit;
  bottom: 0;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
}
.mdc-switch:enabled .mdc-switch__shadow {
  box-shadow: var(--mat-slide-toggle-handle-elevation-shadow);
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:hover:not(:focus):not(:active) .mdc-switch__shadow, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:focus:not(:active) .mdc-switch__shadow, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:active .mdc-switch__shadow, .mdc-switch.mdc-switch--disabled .mdc-switch__shadow {
  box-shadow: var(--mat-slide-toggle-disabled-handle-elevation-shadow);
}

.mdc-switch__ripple {
  left: 50%;
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  z-index: -1;
  width: var(--mat-slide-toggle-state-layer-size, 40px);
  height: var(--mat-slide-toggle-state-layer-size, 40px);
}
.mdc-switch__ripple::after {
  content: "";
  opacity: 0;
}
.mdc-switch--disabled .mdc-switch__ripple::after {
  display: none;
}
.mat-mdc-slide-toggle-disabled-interactive .mdc-switch__ripple::after {
  display: block;
}
.mdc-switch:hover .mdc-switch__ripple::after {
  transition: 75ms opacity cubic-bezier(0, 0, 0.2, 1);
}
.mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:enabled:focus .mdc-switch__ripple::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:enabled:active .mdc-switch__ripple::after, .mat-mdc-slide-toggle-disabled-interactive.mdc-switch--disabled:enabled:hover:not(:focus) .mdc-switch__ripple::after, .mdc-switch--unselected:enabled:hover:not(:focus) .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-slide-toggle-unselected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mdc-switch--unselected:enabled:focus .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-slide-toggle-unselected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mdc-switch--unselected:enabled:active .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-unselected-pressed-state-layer-color, var(--mat-sys-on-surface));
  opacity: var(--mat-slide-toggle-unselected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  transition: opacity 75ms linear;
}
.mdc-switch--selected:enabled:hover:not(:focus) .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-selected-hover-state-layer-color, var(--mat-sys-primary));
  opacity: var(--mat-slide-toggle-selected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mdc-switch--selected:enabled:focus .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-selected-focus-state-layer-color, var(--mat-sys-primary));
  opacity: var(--mat-slide-toggle-selected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
.mdc-switch--selected:enabled:active .mdc-switch__ripple::after {
  background: var(--mat-slide-toggle-selected-pressed-state-layer-color, var(--mat-sys-primary));
  opacity: var(--mat-slide-toggle-selected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  transition: opacity 75ms linear;
}

.mdc-switch__icons {
  position: relative;
  height: 100%;
  width: 100%;
  z-index: 1;
  transform: translateZ(0);
}
.mdc-switch--disabled.mdc-switch--unselected .mdc-switch__icons {
  opacity: var(--mat-slide-toggle-disabled-unselected-icon-opacity, 0.38);
}
.mdc-switch--disabled.mdc-switch--selected .mdc-switch__icons {
  opacity: var(--mat-slide-toggle-disabled-selected-icon-opacity, 0.38);
}

.mdc-switch__icon {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  opacity: 0;
  transition: opacity 30ms 0ms cubic-bezier(0.4, 0, 1, 1);
}
.mdc-switch--unselected .mdc-switch__icon {
  width: var(--mat-slide-toggle-unselected-icon-size, 16px);
  height: var(--mat-slide-toggle-unselected-icon-size, 16px);
  fill: var(--mat-slide-toggle-unselected-icon-color, var(--mat-sys-surface-variant));
}
.mdc-switch--unselected.mdc-switch--disabled .mdc-switch__icon {
  fill: var(--mat-slide-toggle-disabled-unselected-icon-color, var(--mat-sys-surface-variant));
}
.mdc-switch--selected .mdc-switch__icon {
  width: var(--mat-slide-toggle-selected-icon-size, 16px);
  height: var(--mat-slide-toggle-selected-icon-size, 16px);
  fill: var(--mat-slide-toggle-selected-icon-color, var(--mat-sys-on-primary-container));
}
.mdc-switch--selected.mdc-switch--disabled .mdc-switch__icon {
  fill: var(--mat-slide-toggle-disabled-selected-icon-color, var(--mat-sys-on-surface));
}

.mdc-switch--selected .mdc-switch__icon--on,
.mdc-switch--unselected .mdc-switch__icon--off {
  opacity: 1;
  transition: opacity 45ms 30ms cubic-bezier(0, 0, 0.2, 1);
}

.mat-mdc-slide-toggle {
  -webkit-user-select: none;
  user-select: none;
  display: inline-block;
  -webkit-tap-highlight-color: transparent;
  outline: 0;
}
.mat-mdc-slide-toggle .mat-mdc-slide-toggle-ripple,
.mat-mdc-slide-toggle .mdc-switch__ripple::after {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
}
.mat-mdc-slide-toggle .mat-mdc-slide-toggle-ripple:not(:empty),
.mat-mdc-slide-toggle .mdc-switch__ripple::after:not(:empty) {
  transform: translateZ(0);
}
.mat-mdc-slide-toggle.mat-mdc-slide-toggle-focused .mat-focus-indicator::before {
  content: "";
}
.mat-mdc-slide-toggle .mat-internal-form-field {
  color: var(--mat-slide-toggle-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-slide-toggle-label-text-font, var(--mat-sys-body-medium-font));
  line-height: var(--mat-slide-toggle-label-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-slide-toggle-label-text-size, var(--mat-sys-body-medium-size));
  letter-spacing: var(--mat-slide-toggle-label-text-tracking, var(--mat-sys-body-medium-tracking));
  font-weight: var(--mat-slide-toggle-label-text-weight, var(--mat-sys-body-medium-weight));
}
.mat-mdc-slide-toggle .mat-ripple-element {
  opacity: 0.12;
}
.mat-mdc-slide-toggle .mat-focus-indicator::before {
  border-radius: 50%;
}
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle-track,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__icon,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle::before,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__handle::after,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__track::before,
.mat-mdc-slide-toggle._mat-animation-noopable .mdc-switch__track::after {
  transition: none;
}
.mat-mdc-slide-toggle .mdc-switch:enabled + .mdc-label {
  cursor: pointer;
}
.mat-mdc-slide-toggle .mdc-switch--disabled + label {
  color: var(--mat-slide-toggle-disabled-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-slide-toggle label:empty {
  display: none;
}

.mat-mdc-slide-toggle-touch-target {
  position: absolute;
  top: 50%;
  left: 50%;
  height: var(--mat-slide-toggle-touch-target-size, 48px);
  width: 100%;
  transform: translate(-50%, -50%);
  display: var(--mat-slide-toggle-touch-target-display, block);
}
[dir=rtl] .mat-mdc-slide-toggle-touch-target {
  left: auto;
  right: 50%;
  transform: translate(50%, -50%);
}
`],encapsulation:2,changeDetection:0})}return n})(),c0=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[hm,de]})}return n})();var RS=["button"],TS=["*"];function OS(n,i){if(n&1&&(s(0,"div",2),H(1,"mat-pseudo-checkbox",6),r()),n&2){let e=h();d(),P("disabled",e.disabled)}}var l0=new E("MAT_BUTTON_TOGGLE_DEFAULT_OPTIONS",{providedIn:"root",factory:()=>({hideSingleSelectionIndicator:!1,hideMultipleSelectionIndicator:!1,disabledInteractive:!1})}),d0=new E("MatButtonToggleGroup"),PS={provide:zn,useExisting:It(()=>fm),multi:!0},Cl=class{source;value;constructor(i,e){this.source=i,this.value=e}},fm=(()=>{class n{_changeDetector=m(Z);_dir=m(Qe,{optional:!0});_multiple=!1;_disabled=!1;_disabledInteractive=!1;_selectionModel;_rawValue;_controlValueAccessorChangeFn=()=>{};_onTouched=()=>{};_buttonToggles;appearance;get name(){return this._name}set name(e){this._name=e,this._markButtonsForCheck()}_name=m(xe).getId("mat-button-toggle-group-");vertical=!1;get value(){let e=this._selectionModel?this._selectionModel.selected:[];return this.multiple?e.map(t=>t.value):e[0]?e[0].value:void 0}set value(e){this._setSelectionByValue(e),this.valueChange.emit(this.value)}valueChange=new z;get selected(){let e=this._selectionModel?this._selectionModel.selected:[];return this.multiple?e:e[0]||null}get multiple(){return this._multiple}set multiple(e){this._multiple=e,this._markButtonsForCheck()}get disabled(){return this._disabled}set disabled(e){this._disabled=e,this._markButtonsForCheck()}get disabledInteractive(){return this._disabledInteractive}set disabledInteractive(e){this._disabledInteractive=e,this._markButtonsForCheck()}get dir(){return this._dir&&this._dir.value==="rtl"?"rtl":"ltr"}change=new z;get hideSingleSelectionIndicator(){return this._hideSingleSelectionIndicator}set hideSingleSelectionIndicator(e){this._hideSingleSelectionIndicator=e,this._markButtonsForCheck()}_hideSingleSelectionIndicator;get hideMultipleSelectionIndicator(){return this._hideMultipleSelectionIndicator}set hideMultipleSelectionIndicator(e){this._hideMultipleSelectionIndicator=e,this._markButtonsForCheck()}_hideMultipleSelectionIndicator;constructor(){let e=m(l0,{optional:!0});this.appearance=e&&e.appearance?e.appearance:"standard",this._hideSingleSelectionIndicator=e?.hideSingleSelectionIndicator??!1,this._hideMultipleSelectionIndicator=e?.hideMultipleSelectionIndicator??!1}ngOnInit(){this._selectionModel=new ca(this.multiple,void 0,!1)}ngAfterContentInit(){this._selectionModel.select(...this._buttonToggles.filter(e=>e.checked)),this.multiple||this._initializeTabIndex()}writeValue(e){this.value=e,this._changeDetector.markForCheck()}registerOnChange(e){this._controlValueAccessorChangeFn=e}registerOnTouched(e){this._onTouched=e}setDisabledState(e){this.disabled=e}_keydown(e){if(this.multiple||this.disabled||Ze(e))return;let a=e.target.id,o=this._buttonToggles.toArray().findIndex(u=>u.buttonId===a),c=null;switch(e.keyCode){case 32:case 13:c=this._buttonToggles.get(o)||null;break;case 38:c=this._getNextButton(o,-1);break;case 37:c=this._getNextButton(o,this.dir==="ltr"?-1:1);break;case 40:c=this._getNextButton(o,1);break;case 39:c=this._getNextButton(o,this.dir==="ltr"?1:-1);break;default:return}c&&(e.preventDefault(),c._onButtonClick(),c.focus())}_emitChangeEvent(e){let t=new Cl(e,this.value);this._rawValue=t.value,this._controlValueAccessorChangeFn(t.value),this.change.emit(t)}_syncButtonToggle(e,t,a=!1,o=!1){!this.multiple&&this.selected&&!e.checked&&(this.selected.checked=!1),this._selectionModel?t?this._selectionModel.select(e):this._selectionModel.deselect(e):o=!0,o?Promise.resolve().then(()=>this._updateModelValue(e,a)):this._updateModelValue(e,a)}_isSelected(e){return this._selectionModel&&this._selectionModel.isSelected(e)}_isPrechecked(e){return typeof this._rawValue>"u"?!1:this.multiple&&Array.isArray(this._rawValue)?this._rawValue.some(t=>e.value!=null&&t===e.value):e.value===this._rawValue}_initializeTabIndex(){if(this._buttonToggles.forEach(e=>{e.tabIndex=-1}),this.selected)this.selected.tabIndex=0;else for(let e=0;e<this._buttonToggles.length;e++){let t=this._buttonToggles.get(e);if(!t.disabled){t.tabIndex=0;break}}}_getNextButton(e,t){let a=this._buttonToggles;for(let o=1;o<=a.length;o++){let c=(e+t*o+a.length)%a.length,u=a.get(c);if(u&&!u.disabled)return u}return null}_setSelectionByValue(e){if(this._rawValue=e,!this._buttonToggles)return;let t=this._buttonToggles.toArray();if(this.multiple&&e?(Array.isArray(e),this._clearSelection(),e.forEach(a=>this._selectValue(a,t))):(this._clearSelection(),this._selectValue(e,t)),!this.multiple&&t.every(a=>a.tabIndex===-1)){for(let a of t)if(!a.disabled){a.tabIndex=0;break}}}_clearSelection(){this._selectionModel.clear(),this._buttonToggles.forEach(e=>{e.checked=!1,this.multiple||(e.tabIndex=-1)})}_selectValue(e,t){for(let a of t)if(a.value===e){a.checked=!0,this._selectionModel.select(a),this.multiple||(a.tabIndex=0);break}}_updateModelValue(e,t){t&&this._emitChangeEvent(e),this.valueChange.emit(this.value)}_markButtonsForCheck(){this._buttonToggles?.forEach(e=>e._markForCheck())}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["mat-button-toggle-group"]],contentQueries:function(t,a,o){if(t&1&&st(o,wl,5),t&2){let c;j(c=V())&&(a._buttonToggles=c)}},hostAttrs:[1,"mat-button-toggle-group"],hostVars:6,hostBindings:function(t,a){t&1&&_("keydown",function(c){return a._keydown(c)}),t&2&&(Y("role",a.multiple?"group":"radiogroup")("aria-disabled",a.disabled),k("mat-button-toggle-vertical",a.vertical)("mat-button-toggle-group-appearance-standard",a.appearance==="standard"))},inputs:{appearance:"appearance",name:"name",vertical:[2,"vertical","vertical",R],value:"value",multiple:[2,"multiple","multiple",R],disabled:[2,"disabled","disabled",R],disabledInteractive:[2,"disabledInteractive","disabledInteractive",R],hideSingleSelectionIndicator:[2,"hideSingleSelectionIndicator","hideSingleSelectionIndicator",R],hideMultipleSelectionIndicator:[2,"hideMultipleSelectionIndicator","hideMultipleSelectionIndicator",R]},outputs:{valueChange:"valueChange",change:"change"},exportAs:["matButtonToggleGroup"],features:[ce([PS,{provide:d0,useExisting:n}])]})}return n})(),wl=(()=>{class n{_changeDetectorRef=m(Z);_elementRef=m(B);_focusMonitor=m(Dt);_idGenerator=m(xe);_animationDisabled=Ee();_checked=!1;ariaLabel;ariaLabelledby=null;_buttonElement;buttonToggleGroup;get buttonId(){return`${this.id}-button`}id;name;value;get tabIndex(){return this._tabIndex()}set tabIndex(e){this._tabIndex.set(e)}_tabIndex;disableRipple=!1;get appearance(){return this.buttonToggleGroup?this.buttonToggleGroup.appearance:this._appearance}set appearance(e){this._appearance=e}_appearance;get checked(){return this.buttonToggleGroup?this.buttonToggleGroup._isSelected(this):this._checked}set checked(e){e!==this._checked&&(this._checked=e,this.buttonToggleGroup&&this.buttonToggleGroup._syncButtonToggle(this,this._checked),this._changeDetectorRef.markForCheck())}get disabled(){return this._disabled||this.buttonToggleGroup&&this.buttonToggleGroup.disabled}set disabled(e){this._disabled=e}_disabled=!1;get disabledInteractive(){return this._disabledInteractive||this.buttonToggleGroup!==null&&this.buttonToggleGroup.disabledInteractive}set disabledInteractive(e){this._disabledInteractive=e}_disabledInteractive;change=new z;constructor(){m(Oe).load(Et);let e=m(d0,{optional:!0}),t=m(new xt("tabindex"),{optional:!0})||"",a=m(l0,{optional:!0});this._tabIndex=le(parseInt(t)||0),this.buttonToggleGroup=e,this._appearance=a&&a.appearance?a.appearance:"standard",this._disabledInteractive=a?.disabledInteractive??!1}ngOnInit(){let e=this.buttonToggleGroup;this.id=this.id||this._idGenerator.getId("mat-button-toggle-"),e&&(e._isPrechecked(this)?this.checked=!0:e._isSelected(this)!==this._checked&&e._syncButtonToggle(this,this._checked))}ngAfterViewInit(){this._animationDisabled||this._elementRef.nativeElement.classList.add("mat-button-toggle-animations-enabled"),this._focusMonitor.monitor(this._elementRef,!0)}ngOnDestroy(){let e=this.buttonToggleGroup;this._focusMonitor.stopMonitoring(this._elementRef),e&&e._isSelected(this)&&e._syncButtonToggle(this,!1,!1,!0)}focus(e){this._buttonElement.nativeElement.focus(e)}_onButtonClick(){if(this.disabled)return;let e=this.isSingleSelector()?!0:!this._checked;if(e!==this._checked&&(this._checked=e,this.buttonToggleGroup&&(this.buttonToggleGroup._syncButtonToggle(this,this._checked,!0),this.buttonToggleGroup._onTouched())),this.isSingleSelector()){let t=this.buttonToggleGroup._buttonToggles.find(a=>a.tabIndex===0);t&&(t.tabIndex=-1),this.tabIndex=0}this.change.emit(new Cl(this,this.value))}_markForCheck(){this._changeDetectorRef.markForCheck()}_getButtonName(){return this.isSingleSelector()?this.buttonToggleGroup.name:this.name||null}isSingleSelector(){return this.buttonToggleGroup&&!this.buttonToggleGroup.multiple}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-button-toggle"]],viewQuery:function(t,a){if(t&1&&Ae(RS,5),t&2){let o;j(o=V())&&(a._buttonElement=o.first)}},hostAttrs:["role","presentation",1,"mat-button-toggle"],hostVars:14,hostBindings:function(t,a){t&1&&_("focus",function(){return a.focus()}),t&2&&(Y("aria-label",null)("aria-labelledby",null)("id",a.id)("name",null),k("mat-button-toggle-standalone",!a.buttonToggleGroup)("mat-button-toggle-checked",a.checked)("mat-button-toggle-disabled",a.disabled)("mat-button-toggle-disabled-interactive",a.disabledInteractive)("mat-button-toggle-appearance-standard",a.appearance==="standard"))},inputs:{ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],id:"id",name:"name",value:"value",tabIndex:"tabIndex",disableRipple:[2,"disableRipple","disableRipple",R],appearance:"appearance",checked:[2,"checked","checked",R],disabled:[2,"disabled","disabled",R],disabledInteractive:[2,"disabledInteractive","disabledInteractive",R]},outputs:{change:"change"},exportAs:["matButtonToggle"],ngContentSelectors:TS,decls:7,vars:13,consts:[["button",""],["type","button",1,"mat-button-toggle-button","mat-focus-indicator",3,"click","id","disabled"],[1,"mat-button-toggle-checkbox-wrapper"],[1,"mat-button-toggle-label-content"],[1,"mat-button-toggle-focus-overlay"],["matRipple","",1,"mat-button-toggle-ripple",3,"matRippleTrigger","matRippleDisabled"],["state","checked","aria-hidden","true","appearance","minimal",3,"disabled"]],template:function(t,a){if(t&1&&(ye(),s(0,"button",1,0),_("click",function(){return a._onButtonClick()}),v(2,OS,2,1,"div",2),s(3,"span",3),ee(4),r()(),H(5,"span",4)(6,"span",5)),t&2){let o=ct(1);P("id",a.buttonId)("disabled",a.disabled&&!a.disabledInteractive||null),Y("role",a.isSingleSelector()?"radio":"button")("tabindex",a.disabled&&!a.disabledInteractive?-1:a.tabIndex)("aria-pressed",a.isSingleSelector()?null:a.checked)("aria-checked",a.isSingleSelector()?a.checked:null)("name",a._getButtonName())("aria-label",a.ariaLabel)("aria-labelledby",a.ariaLabelledby)("aria-disabled",a.disabled&&a.disabledInteractive?"true":null),d(2),y(a.buttonToggleGroup&&(!a.buttonToggleGroup.multiple&&!a.buttonToggleGroup.hideSingleSelectionIndicator||a.buttonToggleGroup.multiple&&!a.buttonToggleGroup.hideMultipleSelectionIndicator)?2:-1),d(4),P("matRippleTrigger",o)("matRippleDisabled",a.disableRipple||a.disabled)}},dependencies:[xn,Zc],styles:[`.mat-button-toggle-standalone,
.mat-button-toggle-group {
  position: relative;
  display: inline-flex;
  flex-direction: row;
  white-space: nowrap;
  overflow: hidden;
  -webkit-tap-highlight-color: transparent;
  border-radius: var(--mat-button-toggle-legacy-shape);
  transform: translateZ(0);
}
.mat-button-toggle-standalone:not([class*=mat-elevation-z]),
.mat-button-toggle-group:not([class*=mat-elevation-z]) {
  box-shadow: 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12);
}
@media (forced-colors: active) {
  .mat-button-toggle-standalone,
  .mat-button-toggle-group {
    outline: solid 1px;
  }
}

.mat-button-toggle-standalone.mat-button-toggle-appearance-standard,
.mat-button-toggle-group-appearance-standard {
  border-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
  border: solid 1px var(--mat-button-toggle-divider-color, var(--mat-sys-outline));
}
.mat-button-toggle-standalone.mat-button-toggle-appearance-standard .mat-pseudo-checkbox,
.mat-button-toggle-group-appearance-standard .mat-pseudo-checkbox {
  --mat-pseudo-checkbox-minimal-selected-checkmark-color: var(--mat-button-toggle-selected-state-text-color, var(--mat-sys-on-secondary-container));
}
.mat-button-toggle-standalone.mat-button-toggle-appearance-standard:not([class*=mat-elevation-z]),
.mat-button-toggle-group-appearance-standard:not([class*=mat-elevation-z]) {
  box-shadow: none;
}
@media (forced-colors: active) {
  .mat-button-toggle-standalone.mat-button-toggle-appearance-standard,
  .mat-button-toggle-group-appearance-standard {
    outline: 0;
  }
}

.mat-button-toggle-vertical {
  flex-direction: column;
}
.mat-button-toggle-vertical .mat-button-toggle-label-content {
  display: block;
}

.mat-button-toggle {
  white-space: nowrap;
  position: relative;
  color: var(--mat-button-toggle-legacy-text-color);
  font-family: var(--mat-button-toggle-legacy-label-text-font);
  font-size: var(--mat-button-toggle-legacy-label-text-size);
  line-height: var(--mat-button-toggle-legacy-label-text-line-height);
  font-weight: var(--mat-button-toggle-legacy-label-text-weight);
  letter-spacing: var(--mat-button-toggle-legacy-label-text-tracking);
  --mat-pseudo-checkbox-minimal-selected-checkmark-color: var(--mat-button-toggle-legacy-selected-state-text-color);
}
.mat-button-toggle.cdk-keyboard-focused .mat-button-toggle-focus-overlay {
  opacity: var(--mat-button-toggle-legacy-focus-state-layer-opacity);
}
.mat-button-toggle .mat-icon svg {
  vertical-align: top;
}

.mat-button-toggle-checkbox-wrapper {
  display: inline-block;
  justify-content: flex-start;
  align-items: center;
  width: 0;
  height: 18px;
  line-height: 18px;
  overflow: hidden;
  box-sizing: border-box;
  position: absolute;
  top: 50%;
  left: 16px;
  transform: translate3d(0, -50%, 0);
}
[dir=rtl] .mat-button-toggle-checkbox-wrapper {
  left: auto;
  right: 16px;
}
.mat-button-toggle-appearance-standard .mat-button-toggle-checkbox-wrapper {
  left: 12px;
}
[dir=rtl] .mat-button-toggle-appearance-standard .mat-button-toggle-checkbox-wrapper {
  left: auto;
  right: 12px;
}
.mat-button-toggle-checked .mat-button-toggle-checkbox-wrapper {
  width: 18px;
}
.mat-button-toggle-animations-enabled .mat-button-toggle-checkbox-wrapper {
  transition: width 150ms 45ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-button-toggle-vertical .mat-button-toggle-checkbox-wrapper {
  transition: none;
}

.mat-button-toggle-checked {
  color: var(--mat-button-toggle-legacy-selected-state-text-color);
  background-color: var(--mat-button-toggle-legacy-selected-state-background-color);
}

.mat-button-toggle-disabled {
  pointer-events: none;
  color: var(--mat-button-toggle-legacy-disabled-state-text-color);
  background-color: var(--mat-button-toggle-legacy-disabled-state-background-color);
  --mat-pseudo-checkbox-minimal-disabled-selected-checkmark-color: var(--mat-button-toggle-legacy-disabled-state-text-color);
}
.mat-button-toggle-disabled.mat-button-toggle-checked {
  background-color: var(--mat-button-toggle-legacy-disabled-selected-state-background-color);
}

.mat-button-toggle-disabled-interactive {
  pointer-events: auto;
}

.mat-button-toggle-appearance-standard {
  color: var(--mat-button-toggle-text-color, var(--mat-sys-on-surface));
  background-color: var(--mat-button-toggle-background-color, transparent);
  font-family: var(--mat-button-toggle-label-text-font, var(--mat-sys-label-large-font));
  font-size: var(--mat-button-toggle-label-text-size, var(--mat-sys-label-large-size));
  line-height: var(--mat-button-toggle-label-text-line-height, var(--mat-sys-label-large-line-height));
  font-weight: var(--mat-button-toggle-label-text-weight, var(--mat-sys-label-large-weight));
  letter-spacing: var(--mat-button-toggle-label-text-tracking, var(--mat-sys-label-large-tracking));
}
.mat-button-toggle-group-appearance-standard .mat-button-toggle-appearance-standard + .mat-button-toggle-appearance-standard {
  border-left: solid 1px var(--mat-button-toggle-divider-color, var(--mat-sys-outline));
}
[dir=rtl] .mat-button-toggle-group-appearance-standard .mat-button-toggle-appearance-standard + .mat-button-toggle-appearance-standard {
  border-left: none;
  border-right: solid 1px var(--mat-button-toggle-divider-color, var(--mat-sys-outline));
}
.mat-button-toggle-group-appearance-standard.mat-button-toggle-vertical .mat-button-toggle-appearance-standard + .mat-button-toggle-appearance-standard {
  border-left: none;
  border-right: none;
  border-top: solid 1px var(--mat-button-toggle-divider-color, var(--mat-sys-outline));
}
.mat-button-toggle-appearance-standard.mat-button-toggle-checked {
  color: var(--mat-button-toggle-selected-state-text-color, var(--mat-sys-on-secondary-container));
  background-color: var(--mat-button-toggle-selected-state-background-color, var(--mat-sys-secondary-container));
}
.mat-button-toggle-appearance-standard.mat-button-toggle-disabled {
  color: var(--mat-button-toggle-disabled-state-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  background-color: var(--mat-button-toggle-disabled-state-background-color, transparent);
}
.mat-button-toggle-appearance-standard.mat-button-toggle-disabled .mat-pseudo-checkbox {
  --mat-pseudo-checkbox-minimal-disabled-selected-checkmark-color: var(--mat-button-toggle-disabled-selected-state-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-button-toggle-appearance-standard.mat-button-toggle-disabled.mat-button-toggle-checked {
  color: var(--mat-button-toggle-disabled-selected-state-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  background-color: var(--mat-button-toggle-disabled-selected-state-background-color, color-mix(in srgb, var(--mat-sys-on-surface) 12%, transparent));
}
.mat-button-toggle-appearance-standard .mat-button-toggle-focus-overlay {
  background-color: var(--mat-button-toggle-state-layer-color, var(--mat-sys-on-surface));
}
.mat-button-toggle-appearance-standard:hover .mat-button-toggle-focus-overlay {
  opacity: var(--mat-button-toggle-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mat-button-toggle-appearance-standard.cdk-keyboard-focused .mat-button-toggle-focus-overlay {
  opacity: var(--mat-button-toggle-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
}
@media (hover: none) {
  .mat-button-toggle-appearance-standard:hover .mat-button-toggle-focus-overlay {
    display: none;
  }
}

.mat-button-toggle-label-content {
  -webkit-user-select: none;
  user-select: none;
  display: inline-block;
  padding: 0 16px;
  line-height: var(--mat-button-toggle-legacy-height);
  position: relative;
}
.mat-button-toggle-appearance-standard .mat-button-toggle-label-content {
  padding: 0 12px;
  line-height: var(--mat-button-toggle-height, 40px);
}

.mat-button-toggle-label-content > * {
  vertical-align: middle;
}

.mat-button-toggle-focus-overlay {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: inherit;
  pointer-events: none;
  opacity: 0;
  background-color: var(--mat-button-toggle-legacy-state-layer-color);
}

@media (forced-colors: active) {
  .mat-button-toggle-checked .mat-button-toggle-focus-overlay {
    border-bottom: solid 500px;
    opacity: 0.5;
    height: 0;
  }
  .mat-button-toggle-checked:hover .mat-button-toggle-focus-overlay {
    opacity: 0.6;
  }
  .mat-button-toggle-checked.mat-button-toggle-appearance-standard .mat-button-toggle-focus-overlay {
    border-bottom: solid 500px;
  }
}
.mat-button-toggle .mat-button-toggle-ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}

.mat-button-toggle-button {
  border: 0;
  background: none;
  color: inherit;
  padding: 0;
  margin: 0;
  font: inherit;
  outline: none;
  width: 100%;
  cursor: pointer;
}
.mat-button-toggle-animations-enabled .mat-button-toggle-button {
  transition: padding 150ms 45ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-button-toggle-vertical .mat-button-toggle-button {
  transition: none;
}
.mat-button-toggle-disabled .mat-button-toggle-button {
  cursor: default;
}
.mat-button-toggle-button::-moz-focus-inner {
  border: 0;
}
.mat-button-toggle-checked .mat-button-toggle-button:has(.mat-button-toggle-checkbox-wrapper) {
  padding-left: 30px;
}
[dir=rtl] .mat-button-toggle-checked .mat-button-toggle-button:has(.mat-button-toggle-checkbox-wrapper) {
  padding-left: 0;
  padding-right: 30px;
}

.mat-button-toggle-standalone.mat-button-toggle-appearance-standard {
  --mat-focus-indicator-border-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
}

.mat-button-toggle-group-appearance-standard:not(.mat-button-toggle-vertical) .mat-button-toggle:last-of-type .mat-button-toggle-button::before {
  border-top-right-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
  border-bottom-right-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
}
.mat-button-toggle-group-appearance-standard:not(.mat-button-toggle-vertical) .mat-button-toggle:first-of-type .mat-button-toggle-button::before {
  border-top-left-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
  border-bottom-left-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
}

.mat-button-toggle-group-appearance-standard.mat-button-toggle-vertical .mat-button-toggle:last-of-type .mat-button-toggle-button::before {
  border-bottom-right-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
  border-bottom-left-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
}
.mat-button-toggle-group-appearance-standard.mat-button-toggle-vertical .mat-button-toggle:first-of-type .mat-button-toggle-button::before {
  border-top-right-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
  border-top-left-radius: var(--mat-button-toggle-shape, var(--mat-sys-corner-extra-large));
}
`],encapsulation:2,changeDetection:0})}return n})(),u0=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[Si,wl,de]})}return n})();var ym=["*"];function NS(n,i){n&1&&ee(0)}var LS=["tabListContainer"],BS=["tabList"],jS=["tabListInner"],VS=["nextPaginator"],zS=["previousPaginator"],US=["content"];function HS(n,i){}var $S=["tabBodyWrapper"],GS=["tabHeader"];function qS(n,i){}function WS(n,i){if(n&1&&_e(0,qS,0,0,"ng-template",12),n&2){let e=h().$implicit;P("cdkPortalOutlet",e.templateLabel)}}function QS(n,i){if(n&1&&l(0),n&2){let e=h().$implicit;g(e.textLabel)}}function YS(n,i){if(n&1){let e=T();s(0,"div",7,2),_("click",function(){let a=x(e),o=a.$implicit,c=a.$index,u=h(),p=ct(1);return C(u._handleClick(o,p,c))})("cdkFocusChange",function(a){let o=x(e).$index,c=h();return C(c._tabFocusChanged(a,o))}),H(2,"span",8)(3,"div",9),s(4,"span",10)(5,"span",11),v(6,WS,1,1,null,12)(7,QS,1,1),r()()()}if(n&2){let e=i.$implicit,t=i.$index,a=ct(1),o=h();ve(e.labelClass),k("mdc-tab--active",o.selectedIndex===t),P("id",o._getTabLabelId(e,t))("disabled",e.disabled)("fitInkBarToContent",o.fitInkBarToContent),Y("tabIndex",o._getTabIndex(t))("aria-posinset",t+1)("aria-setsize",o._tabs.length)("aria-controls",o._getTabContentId(t))("aria-selected",o.selectedIndex===t)("aria-label",e.ariaLabel||null)("aria-labelledby",!e.ariaLabel&&e.ariaLabelledby?e.ariaLabelledby:null),d(3),P("matRippleTrigger",a)("matRippleDisabled",e.disabled||o.disableRipple),d(3),y(e.templateLabel?6:7)}}function XS(n,i){n&1&&ee(0)}function KS(n,i){if(n&1){let e=T();s(0,"mat-tab-body",13),_("_onCentered",function(){x(e);let a=h();return C(a._removeTabBodyWrapperHeight())})("_onCentering",function(a){x(e);let o=h();return C(o._setTabBodyWrapperHeight(a))})("_beforeCentering",function(a){x(e);let o=h();return C(o._bodyCentered(a))}),r()}if(n&2){let e=i.$implicit,t=i.$index,a=h();ve(e.bodyClass),P("id",a._getTabContentId(t))("content",e.content)("position",e.position)("animationDuration",a.animationDuration)("preserveContent",a.preserveContent),Y("tabindex",a.contentTabIndex!=null&&a.selectedIndex===t?a.contentTabIndex:null)("aria-labelledby",a._getTabLabelId(e,t))("aria-hidden",a.selectedIndex!==t)}}var ZS=new E("MatTabContent"),JS=(()=>{class n{template=m(He);constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","matTabContent",""]],features:[ce([{provide:ZS,useExisting:n}])]})}return n})(),ek=new E("MatTabLabel"),f0=new E("MAT_TAB"),xm=(()=>{class n extends zg{_closestTab=m(f0,{optional:!0});static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["","mat-tab-label",""],["","matTabLabel",""]],features:[ce([{provide:ek,useExisting:n}]),ie]})}return n})(),g0=new E("MAT_TAB_GROUP"),Cm=(()=>{class n{_viewContainerRef=m(Xe);_closestTabGroup=m(g0,{optional:!0});disabled=!1;get templateLabel(){return this._templateLabel}set templateLabel(e){this._setTemplateLabelInput(e)}_templateLabel;_explicitContent=void 0;_implicitContent;textLabel="";ariaLabel;ariaLabelledby;labelClass;bodyClass;id=null;_contentPortal=null;get content(){return this._contentPortal}_stateChanges=new F;position=null;origin=null;isActive=!1;constructor(){m(Oe).load(Et)}ngOnChanges(e){(e.hasOwnProperty("textLabel")||e.hasOwnProperty("disabled"))&&this._stateChanges.next()}ngOnDestroy(){this._stateChanges.complete()}ngOnInit(){this._contentPortal=new Qt(this._explicitContent||this._implicitContent,this._viewContainerRef)}_setTemplateLabelInput(e){e&&e._closestTab===this&&(this._templateLabel=e)}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-tab"]],contentQueries:function(t,a,o){if(t&1&&st(o,xm,5)(o,JS,7,He),t&2){let c;j(c=V())&&(a.templateLabel=c.first),j(c=V())&&(a._explicitContent=c.first)}},viewQuery:function(t,a){if(t&1&&Ae(He,7),t&2){let o;j(o=V())&&(a._implicitContent=o.first)}},hostAttrs:["hidden",""],hostVars:1,hostBindings:function(t,a){t&2&&Y("id",null)},inputs:{disabled:[2,"disabled","disabled",R],textLabel:[0,"label","textLabel"],ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],labelClass:"labelClass",bodyClass:"bodyClass",id:"id"},exportAs:["matTab"],features:[ce([{provide:f0,useExisting:n}]),we],ngContentSelectors:ym,decls:1,vars:0,template:function(t,a){t&1&&(ye(),Zm(0,NS,1,0,"ng-template"))},encapsulation:2})}return n})(),gm="mdc-tab-indicator--active",m0="mdc-tab-indicator--no-transition",_m=class{_items;_currentItem;constructor(i){this._items=i}hide(){this._items.forEach(i=>i.deactivateInkBar()),this._currentItem=void 0}alignToElement(i){let e=this._items.find(a=>a.elementRef.nativeElement===i),t=this._currentItem;if(e!==t&&(t?.deactivateInkBar(),e)){let a=t?.elementRef.nativeElement.getBoundingClientRect?.();e.activateInkBar(a),this._currentItem=e}}},tk=(()=>{class n{_elementRef=m(B);_inkBarElement=null;_inkBarContentElement=null;_fitToContent=!1;get fitInkBarToContent(){return this._fitToContent}set fitInkBarToContent(e){this._fitToContent!==e&&(this._fitToContent=e,this._inkBarElement&&this._appendInkBarElement())}activateInkBar(e){let t=this._elementRef.nativeElement;if(!e||!t.getBoundingClientRect||!this._inkBarContentElement){t.classList.add(gm);return}let a=t.getBoundingClientRect(),o=e.width/a.width,c=e.left-a.left;t.classList.add(m0),this._inkBarContentElement.style.setProperty("transform",`translateX(${c}px) scaleX(${o})`),t.getBoundingClientRect(),t.classList.remove(m0),t.classList.add(gm),this._inkBarContentElement.style.setProperty("transform","")}deactivateInkBar(){this._elementRef.nativeElement.classList.remove(gm)}ngOnInit(){this._createInkBarElement()}ngOnDestroy(){this._inkBarElement?.remove(),this._inkBarElement=this._inkBarContentElement=null}_createInkBarElement(){let e=this._elementRef.nativeElement.ownerDocument||document,t=this._inkBarElement=e.createElement("span"),a=this._inkBarContentElement=e.createElement("span");t.className="mdc-tab-indicator",a.className="mdc-tab-indicator__content mdc-tab-indicator__content--underline",t.appendChild(this._inkBarContentElement),this._appendInkBarElement()}_appendInkBarElement(){this._inkBarElement;let e=this._fitToContent?this._elementRef.nativeElement.querySelector(".mdc-tab__content"):this._elementRef.nativeElement;e.appendChild(this._inkBarElement)}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,inputs:{fitInkBarToContent:[2,"fitInkBarToContent","fitInkBarToContent",R]}})}return n})();var _0=(()=>{class n extends tk{elementRef=m(B);disabled=!1;focus(){this.elementRef.nativeElement.focus()}getOffsetLeft(){return this.elementRef.nativeElement.offsetLeft}getOffsetWidth(){return this.elementRef.nativeElement.offsetWidth}static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275dir=I({type:n,selectors:[["","matTabLabelWrapper",""]],hostVars:3,hostBindings:function(t,a){t&2&&(Y("aria-disabled",!!a.disabled),k("mat-mdc-tab-disabled",a.disabled))},inputs:{disabled:[2,"disabled","disabled",R]},features:[ie]})}return n})(),p0={passive:!0},nk=650,ik=100,ak=(()=>{class n{_elementRef=m(B);_changeDetectorRef=m(Z);_viewportRuler=m(un);_dir=m(Qe,{optional:!0});_ngZone=m(W);_platform=m(be);_sharedResizeObserver=m(Tc);_injector=m(re);_renderer=m(Se);_animationsDisabled=Ee();_eventCleanups;_scrollDistance=0;_selectedIndexChanged=!1;_destroyed=new F;_showPaginationControls=!1;_disableScrollAfter=!0;_disableScrollBefore=!0;_tabLabelCount;_scrollDistanceChanged=!1;_keyManager;_currentTextContent;_stopScrolling=new F;disablePagination=!1;get selectedIndex(){return this._selectedIndex}set selectedIndex(e){let t=isNaN(e)?0:e;this._selectedIndex!=t&&(this._selectedIndexChanged=!0,this._selectedIndex=t,this._keyManager&&this._keyManager.updateActiveItem(t))}_selectedIndex=0;selectFocusedIndex=new z;indexFocused=new z;constructor(){this._eventCleanups=this._ngZone.runOutsideAngular(()=>[this._renderer.listen(this._elementRef.nativeElement,"mouseleave",()=>this._stopInterval())])}ngAfterViewInit(){this._eventCleanups.push(this._renderer.listen(this._previousPaginator.nativeElement,"touchstart",()=>this._handlePaginatorPress("before"),p0),this._renderer.listen(this._nextPaginator.nativeElement,"touchstart",()=>this._handlePaginatorPress("after"),p0))}ngAfterContentInit(){let e=this._dir?this._dir.change:K("ltr"),t=this._sharedResizeObserver.observe(this._elementRef.nativeElement).pipe(On(32),pe(this._destroyed)),a=this._viewportRuler.change(150).pipe(pe(this._destroyed)),o=()=>{this.updatePagination(),this._alignInkBarToSelectedTab()};this._keyManager=new Ei(this._items).withHorizontalOrientation(this._getLayoutDirection()).withHomeAndEnd().withWrap().skipPredicate(()=>!1),this._keyManager.updateActiveItem(Math.max(this._selectedIndex,0)),Pe(o,{injector:this._injector}),ut(e,a,t,this._items.changes,this._itemsResized()).pipe(pe(this._destroyed)).subscribe(()=>{this._ngZone.run(()=>{Promise.resolve().then(()=>{this._scrollDistance=Math.max(0,Math.min(this._getMaxScrollDistance(),this._scrollDistance)),o()})}),this._keyManager?.withHorizontalOrientation(this._getLayoutDirection())}),this._keyManager.change.subscribe(c=>{this.indexFocused.emit(c),this._setTabFocus(c)})}_itemsResized(){return typeof ResizeObserver!="function"?mt:this._items.changes.pipe(tt(this._items),at(e=>new Ht(t=>this._ngZone.runOutsideAngular(()=>{let a=new ResizeObserver(o=>t.next(o));return e.forEach(o=>a.observe(o.elementRef.nativeElement)),()=>{a.disconnect()}}))),Ca(1),Ce(e=>e.some(t=>t.contentRect.width>0&&t.contentRect.height>0)))}ngAfterContentChecked(){this._tabLabelCount!=this._items.length&&(this.updatePagination(),this._tabLabelCount=this._items.length,this._changeDetectorRef.markForCheck()),this._selectedIndexChanged&&(this._scrollToLabel(this._selectedIndex),this._checkScrollingControls(),this._alignInkBarToSelectedTab(),this._selectedIndexChanged=!1,this._changeDetectorRef.markForCheck()),this._scrollDistanceChanged&&(this._updateTabScrollPosition(),this._scrollDistanceChanged=!1,this._changeDetectorRef.markForCheck())}ngOnDestroy(){this._eventCleanups.forEach(e=>e()),this._keyManager?.destroy(),this._destroyed.next(),this._destroyed.complete(),this._stopScrolling.complete()}_handleKeydown(e){if(!Ze(e))switch(e.keyCode){case 13:case 32:if(this.focusIndex!==this.selectedIndex){let t=this._items.get(this.focusIndex);t&&!t.disabled&&(this.selectFocusedIndex.emit(this.focusIndex),this._itemSelected(e))}break;default:this._keyManager?.onKeydown(e)}}_onContentChanges(){let e=this._elementRef.nativeElement.textContent;e!==this._currentTextContent&&(this._currentTextContent=e||"",this._ngZone.run(()=>{this.updatePagination(),this._alignInkBarToSelectedTab(),this._changeDetectorRef.markForCheck()}))}updatePagination(){this._checkPaginationEnabled(),this._checkScrollingControls(),this._updateTabScrollPosition()}get focusIndex(){return this._keyManager?this._keyManager.activeItemIndex:0}set focusIndex(e){!this._isValidIndex(e)||this.focusIndex===e||!this._keyManager||this._keyManager.setActiveItem(e)}_isValidIndex(e){return this._items?!!this._items.toArray()[e]:!0}_setTabFocus(e){if(this._showPaginationControls&&this._scrollToLabel(e),this._items&&this._items.length){this._items.toArray()[e].focus();let t=this._tabListContainer.nativeElement;this._getLayoutDirection()=="ltr"?t.scrollLeft=0:t.scrollLeft=t.scrollWidth-t.offsetWidth}}_getLayoutDirection(){return this._dir&&this._dir.value==="rtl"?"rtl":"ltr"}_updateTabScrollPosition(){if(this.disablePagination)return;let e=this.scrollDistance,t=this._getLayoutDirection()==="ltr"?-e:e;this._tabList.nativeElement.style.transform=`translateX(${Math.round(t)}px)`,(this._platform.TRIDENT||this._platform.EDGE)&&(this._tabListContainer.nativeElement.scrollLeft=0)}get scrollDistance(){return this._scrollDistance}set scrollDistance(e){this._scrollTo(e)}_scrollHeader(e){let t=this._tabListContainer.nativeElement.offsetWidth,a=(e=="before"?-1:1)*t/3;return this._scrollTo(this._scrollDistance+a)}_handlePaginatorClick(e){this._stopInterval(),this._scrollHeader(e)}_scrollToLabel(e){if(this.disablePagination)return;let t=this._items?this._items.toArray()[e]:null;if(!t)return;let a=this._tabListContainer.nativeElement.offsetWidth,{offsetLeft:o,offsetWidth:c}=t.elementRef.nativeElement,u,p;this._getLayoutDirection()=="ltr"?(u=o,p=u+c):(p=this._tabListInner.nativeElement.offsetWidth-o,u=p-c);let f=this.scrollDistance,b=this.scrollDistance+a;u<f?this.scrollDistance-=f-u:p>b&&(this.scrollDistance+=Math.min(p-b,u-f))}_checkPaginationEnabled(){if(this.disablePagination)this._showPaginationControls=!1;else{let e=this._tabListInner.nativeElement.scrollWidth,t=this._elementRef.nativeElement.offsetWidth,a=e-t>=5;a||(this.scrollDistance=0),a!==this._showPaginationControls&&(this._showPaginationControls=a,this._changeDetectorRef.markForCheck())}}_checkScrollingControls(){this.disablePagination?this._disableScrollAfter=this._disableScrollBefore=!0:(this._disableScrollBefore=this.scrollDistance==0,this._disableScrollAfter=this.scrollDistance==this._getMaxScrollDistance(),this._changeDetectorRef.markForCheck())}_getMaxScrollDistance(){let e=this._tabListInner.nativeElement.scrollWidth,t=this._tabListContainer.nativeElement.offsetWidth;return e-t||0}_alignInkBarToSelectedTab(){let e=this._items&&this._items.length?this._items.toArray()[this.selectedIndex]:null,t=e?e.elementRef.nativeElement:null;t?this._inkBar.alignToElement(t):this._inkBar.hide()}_stopInterval(){this._stopScrolling.next()}_handlePaginatorPress(e,t){t&&t.button!=null&&t.button!==0||(this._stopInterval(),Im(nk,ik).pipe(pe(ut(this._stopScrolling,this._destroyed))).subscribe(()=>{let{maxScrollDistance:a,distance:o}=this._scrollHeader(e);(o===0||o>=a)&&this._stopInterval()}))}_scrollTo(e){if(this.disablePagination)return{maxScrollDistance:0,distance:0};let t=this._getMaxScrollDistance();return this._scrollDistance=Math.max(0,Math.min(t,e)),this._scrollDistanceChanged=!0,this._checkScrollingControls(),{maxScrollDistance:t,distance:this._scrollDistance}}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,inputs:{disablePagination:[2,"disablePagination","disablePagination",R],selectedIndex:[2,"selectedIndex","selectedIndex",lt]},outputs:{selectFocusedIndex:"selectFocusedIndex",indexFocused:"indexFocused"}})}return n})(),ok=(()=>{class n extends ak{_items;_tabListContainer;_tabList;_tabListInner;_nextPaginator;_previousPaginator;_inkBar;ariaLabel;ariaLabelledby;disableRipple=!1;ngAfterContentInit(){this._inkBar=new _m(this._items),super.ngAfterContentInit()}_itemSelected(e){e.preventDefault()}static \u0275fac=(()=>{let e;return function(a){return(e||(e=De(n)))(a||n)}})();static \u0275cmp=A({type:n,selectors:[["mat-tab-header"]],contentQueries:function(t,a,o){if(t&1&&st(o,_0,4),t&2){let c;j(c=V())&&(a._items=c)}},viewQuery:function(t,a){if(t&1&&Ae(LS,7)(BS,7)(jS,7)(VS,5)(zS,5),t&2){let o;j(o=V())&&(a._tabListContainer=o.first),j(o=V())&&(a._tabList=o.first),j(o=V())&&(a._tabListInner=o.first),j(o=V())&&(a._nextPaginator=o.first),j(o=V())&&(a._previousPaginator=o.first)}},hostAttrs:[1,"mat-mdc-tab-header"],hostVars:4,hostBindings:function(t,a){t&2&&k("mat-mdc-tab-header-pagination-controls-enabled",a._showPaginationControls)("mat-mdc-tab-header-rtl",a._getLayoutDirection()=="rtl")},inputs:{ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],disableRipple:[2,"disableRipple","disableRipple",R]},features:[ie],ngContentSelectors:ym,decls:13,vars:10,consts:[["previousPaginator",""],["tabListContainer",""],["tabList",""],["tabListInner",""],["nextPaginator",""],["mat-ripple","",1,"mat-mdc-tab-header-pagination","mat-mdc-tab-header-pagination-before",3,"click","mousedown","touchend","matRippleDisabled"],[1,"mat-mdc-tab-header-pagination-chevron"],[1,"mat-mdc-tab-label-container",3,"keydown"],["role","tablist",1,"mat-mdc-tab-list",3,"cdkObserveContent"],[1,"mat-mdc-tab-labels"],["mat-ripple","",1,"mat-mdc-tab-header-pagination","mat-mdc-tab-header-pagination-after",3,"mousedown","click","touchend","matRippleDisabled"]],template:function(t,a){t&1&&(ye(),s(0,"div",5,0),_("click",function(){return a._handlePaginatorClick("before")})("mousedown",function(c){return a._handlePaginatorPress("before",c)})("touchend",function(){return a._stopInterval()}),H(2,"div",6),r(),s(3,"div",7,1),_("keydown",function(c){return a._handleKeydown(c)}),s(5,"div",8,2),_("cdkObserveContent",function(){return a._onContentChanges()}),s(7,"div",9,3),ee(9),r()()(),s(10,"div",10,4),_("mousedown",function(c){return a._handlePaginatorPress("after",c)})("click",function(){return a._handlePaginatorClick("after")})("touchend",function(){return a._stopInterval()}),H(12,"div",6),r()),t&2&&(k("mat-mdc-tab-header-pagination-disabled",a._disableScrollBefore),P("matRippleDisabled",a._disableScrollBefore||a.disableRipple),d(3),k("_mat-animation-noopable",a._animationsDisabled),d(2),Y("aria-label",a.ariaLabel||null)("aria-labelledby",a.ariaLabelledby||null),d(5),k("mat-mdc-tab-header-pagination-disabled",a._disableScrollAfter),P("matRippleDisabled",a._disableScrollAfter||a.disableRipple))},dependencies:[xn,_f],styles:[`.mat-mdc-tab-header {
  display: flex;
  overflow: hidden;
  position: relative;
  flex-shrink: 0;
}

.mdc-tab-indicator .mdc-tab-indicator__content {
  transition-duration: var(--mat-tab-animation-duration, 250ms);
}

.mat-mdc-tab-header-pagination {
  -webkit-user-select: none;
  user-select: none;
  position: relative;
  display: none;
  justify-content: center;
  align-items: center;
  min-width: 32px;
  cursor: pointer;
  z-index: 2;
  -webkit-tap-highlight-color: transparent;
  touch-action: none;
  box-sizing: content-box;
  outline: 0;
}
.mat-mdc-tab-header-pagination::-moz-focus-inner {
  border: 0;
}
.mat-mdc-tab-header-pagination .mat-ripple-element {
  opacity: 0.12;
  background-color: var(--mat-tab-inactive-ripple-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab-header-pagination-controls-enabled .mat-mdc-tab-header-pagination {
  display: flex;
}

.mat-mdc-tab-header-pagination-before,
.mat-mdc-tab-header-rtl .mat-mdc-tab-header-pagination-after {
  padding-left: 4px;
}
.mat-mdc-tab-header-pagination-before .mat-mdc-tab-header-pagination-chevron,
.mat-mdc-tab-header-rtl .mat-mdc-tab-header-pagination-after .mat-mdc-tab-header-pagination-chevron {
  transform: rotate(-135deg);
}

.mat-mdc-tab-header-rtl .mat-mdc-tab-header-pagination-before,
.mat-mdc-tab-header-pagination-after {
  padding-right: 4px;
}
.mat-mdc-tab-header-rtl .mat-mdc-tab-header-pagination-before .mat-mdc-tab-header-pagination-chevron,
.mat-mdc-tab-header-pagination-after .mat-mdc-tab-header-pagination-chevron {
  transform: rotate(45deg);
}

.mat-mdc-tab-header-pagination-chevron {
  border-style: solid;
  border-width: 2px 2px 0 0;
  height: 8px;
  width: 8px;
  border-color: var(--mat-tab-pagination-icon-color, var(--mat-sys-on-surface));
}

.mat-mdc-tab-header-pagination-disabled {
  box-shadow: none;
  cursor: default;
  pointer-events: none;
}
.mat-mdc-tab-header-pagination-disabled .mat-mdc-tab-header-pagination-chevron {
  opacity: 0.4;
}

.mat-mdc-tab-list {
  flex-grow: 1;
  position: relative;
  transition: transform 500ms cubic-bezier(0.35, 0, 0.25, 1);
}
._mat-animation-noopable .mat-mdc-tab-list {
  transition: none;
}

.mat-mdc-tab-label-container {
  display: flex;
  flex-grow: 1;
  overflow: hidden;
  z-index: 1;
  border-bottom-style: solid;
  border-bottom-width: var(--mat-tab-divider-height, 1px);
  border-bottom-color: var(--mat-tab-divider-color, var(--mat-sys-surface-variant));
}
.mat-mdc-tab-group-inverted-header .mat-mdc-tab-label-container {
  border-bottom: none;
  border-top-style: solid;
  border-top-width: var(--mat-tab-divider-height, 1px);
  border-top-color: var(--mat-tab-divider-color, var(--mat-sys-surface-variant));
}

.mat-mdc-tab-labels {
  display: flex;
  flex: 1 0 auto;
}
[mat-align-tabs=center] > .mat-mdc-tab-header .mat-mdc-tab-labels {
  justify-content: center;
}
[mat-align-tabs=end] > .mat-mdc-tab-header .mat-mdc-tab-labels {
  justify-content: flex-end;
}
.cdk-drop-list .mat-mdc-tab-labels, .mat-mdc-tab-labels.cdk-drop-list {
  min-height: var(--mat-tab-container-height, 48px);
}

.mat-mdc-tab::before {
  margin: 5px;
}
@media (forced-colors: active) {
  .mat-mdc-tab[aria-disabled=true] {
    color: GrayText;
  }
}
`],encapsulation:2})}return n})(),rk=new E("MAT_TABS_CONFIG"),h0=(()=>{class n extends tn{_host=m(bm);_ngZone=m(W);_centeringSub=Le.EMPTY;_leavingSub=Le.EMPTY;constructor(){super()}ngOnInit(){super.ngOnInit(),this._centeringSub=this._host._beforeCentering.pipe(tt(this._host._isCenterPosition())).subscribe(e=>{this._host._content&&e&&!this.hasAttached()&&this._ngZone.run(()=>{Promise.resolve().then(),this.attach(this._host._content)})}),this._leavingSub=this._host._afterLeavingCenter.subscribe(()=>{this._host.preserveContent||this._ngZone.run(()=>this.detach())})}ngOnDestroy(){super.ngOnDestroy(),this._centeringSub.unsubscribe(),this._leavingSub.unsubscribe()}static \u0275fac=function(t){return new(t||n)};static \u0275dir=I({type:n,selectors:[["","matTabBodyHost",""]],features:[ie]})}return n})(),bm=(()=>{class n{_elementRef=m(B);_dir=m(Qe,{optional:!0});_ngZone=m(W);_injector=m(re);_renderer=m(Se);_diAnimationsDisabled=Ee();_eventCleanups;_initialized=!1;_fallbackTimer;_positionIndex;_dirChangeSubscription=Le.EMPTY;_position;_previousPosition;_onCentering=new z;_beforeCentering=new z;_afterLeavingCenter=new z;_onCentered=new z(!0);_portalHost;_contentElement;_content;animationDuration="500ms";preserveContent=!1;set position(e){this._positionIndex=e,this._computePositionAnimationState()}constructor(){if(this._dir){let e=m(Z);this._dirChangeSubscription=this._dir.change.subscribe(t=>{this._computePositionAnimationState(t),e.markForCheck()})}}ngOnInit(){this._bindTransitionEvents(),this._position==="center"&&(this._setActiveClass(!0),Pe(()=>this._onCentering.emit(this._elementRef.nativeElement.clientHeight),{injector:this._injector})),this._initialized=!0}ngOnDestroy(){clearTimeout(this._fallbackTimer),this._eventCleanups?.forEach(e=>e()),this._dirChangeSubscription.unsubscribe()}_bindTransitionEvents(){this._ngZone.runOutsideAngular(()=>{let e=this._elementRef.nativeElement,t=a=>{a.target===this._contentElement?.nativeElement&&(this._elementRef.nativeElement.classList.remove("mat-tab-body-animating"),a.type==="transitionend"&&this._transitionDone())};this._eventCleanups=[this._renderer.listen(e,"transitionstart",a=>{a.target===this._contentElement?.nativeElement&&(this._elementRef.nativeElement.classList.add("mat-tab-body-animating"),this._transitionStarted())}),this._renderer.listen(e,"transitionend",t),this._renderer.listen(e,"transitioncancel",t)]})}_transitionStarted(){clearTimeout(this._fallbackTimer);let e=this._position==="center";this._beforeCentering.emit(e),e&&this._onCentering.emit(this._elementRef.nativeElement.clientHeight)}_transitionDone(){this._position==="center"?this._onCentered.emit():this._previousPosition==="center"&&this._afterLeavingCenter.emit()}_setActiveClass(e){this._elementRef.nativeElement.classList.toggle("mat-mdc-tab-body-active",e)}_getLayoutDirection(){return this._dir&&this._dir.value==="rtl"?"rtl":"ltr"}_isCenterPosition(){return this._positionIndex===0}_computePositionAnimationState(e=this._getLayoutDirection()){this._previousPosition=this._position,this._positionIndex<0?this._position=e=="ltr"?"left":"right":this._positionIndex>0?this._position=e=="ltr"?"right":"left":this._position="center",this._animationsDisabled()?this._simulateTransitionEvents():this._initialized&&(this._position==="center"||this._previousPosition==="center")&&(clearTimeout(this._fallbackTimer),this._fallbackTimer=this._ngZone.runOutsideAngular(()=>setTimeout(()=>this._simulateTransitionEvents(),100)))}_simulateTransitionEvents(){this._transitionStarted(),Pe(()=>this._transitionDone(),{injector:this._injector})}_animationsDisabled(){return this._diAnimationsDisabled||this.animationDuration==="0ms"||this.animationDuration==="0s"}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-tab-body"]],viewQuery:function(t,a){if(t&1&&Ae(h0,5)(US,5),t&2){let o;j(o=V())&&(a._portalHost=o.first),j(o=V())&&(a._contentElement=o.first)}},hostAttrs:[1,"mat-mdc-tab-body"],hostVars:1,hostBindings:function(t,a){t&2&&Y("inert",a._position==="center"?null:"")},inputs:{_content:[0,"content","_content"],animationDuration:"animationDuration",preserveContent:"preserveContent",position:"position"},outputs:{_onCentering:"_onCentering",_beforeCentering:"_beforeCentering",_onCentered:"_onCentered"},decls:3,vars:6,consts:[["content",""],["cdkScrollable","",1,"mat-mdc-tab-body-content"],["matTabBodyHost",""]],template:function(t,a){t&1&&(s(0,"div",1,0),_e(2,HS,0,0,"ng-template",2),r()),t&2&&k("mat-tab-body-content-left",a._position==="left")("mat-tab-body-content-right",a._position==="right")("mat-tab-body-content-can-animate",a._position==="center"||a._previousPosition==="center")},dependencies:[h0,Lr],styles:[`.mat-mdc-tab-body {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  display: block;
  overflow: hidden;
  outline: 0;
  flex-basis: 100%;
}
.mat-mdc-tab-body.mat-mdc-tab-body-active {
  position: relative;
  overflow-x: hidden;
  overflow-y: auto;
  z-index: 1;
  flex-grow: 1;
}
.mat-mdc-tab-group.mat-mdc-tab-group-dynamic-height .mat-mdc-tab-body.mat-mdc-tab-body-active {
  overflow-y: hidden;
}

.mat-mdc-tab-body-content {
  height: 100%;
  overflow: auto;
  transform: none;
  visibility: hidden;
}
.mat-tab-body-animating > .mat-mdc-tab-body-content, .mat-mdc-tab-body-active > .mat-mdc-tab-body-content {
  visibility: visible;
}
.mat-tab-body-animating > .mat-mdc-tab-body-content {
  min-height: 1px;
}
.mat-mdc-tab-group-dynamic-height .mat-mdc-tab-body-content {
  overflow: hidden;
}

.mat-tab-body-content-can-animate {
  transition: transform var(--mat-tab-animation-duration) 1ms cubic-bezier(0.35, 0, 0.25, 1);
}
.mat-mdc-tab-body-wrapper._mat-animation-noopable .mat-tab-body-content-can-animate {
  transition: none;
}

.mat-tab-body-content-left {
  transform: translate3d(-100%, 0, 0);
}

.mat-tab-body-content-right {
  transform: translate3d(100%, 0, 0);
}
`],encapsulation:2})}return n})(),b0=(()=>{class n{_elementRef=m(B);_changeDetectorRef=m(Z);_ngZone=m(W);_tabsSubscription=Le.EMPTY;_tabLabelSubscription=Le.EMPTY;_tabBodySubscription=Le.EMPTY;_diAnimationsDisabled=Ee();_allTabs;_tabBodies;_tabBodyWrapper;_tabHeader;_tabs=new di;_indexToSelect=0;_lastFocusedTabIndex=null;_tabBodyWrapperHeight=0;color;get fitInkBarToContent(){return this._fitInkBarToContent}set fitInkBarToContent(e){this._fitInkBarToContent=e,this._changeDetectorRef.markForCheck()}_fitInkBarToContent=!1;stretchTabs=!0;alignTabs=null;dynamicHeight=!1;get selectedIndex(){return this._selectedIndex}set selectedIndex(e){this._indexToSelect=isNaN(e)?null:e}_selectedIndex=null;headerPosition="above";get animationDuration(){return this._animationDuration}set animationDuration(e){let t=e+"";this._animationDuration=/^\d+$/.test(t)?e+"ms":t}_animationDuration;get contentTabIndex(){return this._contentTabIndex}set contentTabIndex(e){this._contentTabIndex=isNaN(e)?null:e}_contentTabIndex=null;disablePagination=!1;disableRipple=!1;preserveContent=!1;get backgroundColor(){return this._backgroundColor}set backgroundColor(e){let t=this._elementRef.nativeElement.classList;t.remove("mat-tabs-with-background",`mat-background-${this.backgroundColor}`),e&&t.add("mat-tabs-with-background",`mat-background-${e}`),this._backgroundColor=e}_backgroundColor;ariaLabel;ariaLabelledby;selectedIndexChange=new z;focusChange=new z;animationDone=new z;selectedTabChange=new z(!0);_groupId;_isServer=!m(be).isBrowser;constructor(){let e=m(rk,{optional:!0});this._groupId=m(xe).getId("mat-tab-group-"),this.animationDuration=e&&e.animationDuration?e.animationDuration:"500ms",this.disablePagination=e&&e.disablePagination!=null?e.disablePagination:!1,this.dynamicHeight=e&&e.dynamicHeight!=null?e.dynamicHeight:!1,e?.contentTabIndex!=null&&(this.contentTabIndex=e.contentTabIndex),this.preserveContent=!!e?.preserveContent,this.fitInkBarToContent=e&&e.fitInkBarToContent!=null?e.fitInkBarToContent:!1,this.stretchTabs=e&&e.stretchTabs!=null?e.stretchTabs:!0,this.alignTabs=e&&e.alignTabs!=null?e.alignTabs:null}ngAfterContentChecked(){let e=this._indexToSelect=this._clampTabIndex(this._indexToSelect);if(this._selectedIndex!=e){let t=this._selectedIndex==null;if(!t){this.selectedTabChange.emit(this._createChangeEvent(e));let a=this._tabBodyWrapper.nativeElement;a.style.minHeight=a.clientHeight+"px"}Promise.resolve().then(()=>{this._tabs.forEach((a,o)=>a.isActive=o===e),t||(this.selectedIndexChange.emit(e),this._tabBodyWrapper.nativeElement.style.minHeight="")})}this._tabs.forEach((t,a)=>{t.position=a-e,this._selectedIndex!=null&&t.position==0&&!t.origin&&(t.origin=e-this._selectedIndex)}),this._selectedIndex!==e&&(this._selectedIndex=e,this._lastFocusedTabIndex=null,this._changeDetectorRef.markForCheck())}ngAfterContentInit(){this._subscribeToAllTabChanges(),this._subscribeToTabLabels(),this._tabsSubscription=this._tabs.changes.subscribe(()=>{let e=this._clampTabIndex(this._indexToSelect);if(e===this._selectedIndex){let t=this._tabs.toArray(),a;for(let o=0;o<t.length;o++)if(t[o].isActive){this._indexToSelect=this._selectedIndex=o,this._lastFocusedTabIndex=null,a=t[o];break}!a&&t[e]&&Promise.resolve().then(()=>{t[e].isActive=!0,this.selectedTabChange.emit(this._createChangeEvent(e))})}this._changeDetectorRef.markForCheck()})}ngAfterViewInit(){this._tabBodySubscription=this._tabBodies.changes.subscribe(()=>this._bodyCentered(!0))}_subscribeToAllTabChanges(){this._allTabs.changes.pipe(tt(this._allTabs)).subscribe(e=>{this._tabs.reset(e.filter(t=>t._closestTabGroup===this||!t._closestTabGroup)),this._tabs.notifyOnChanges()})}ngOnDestroy(){this._tabs.destroy(),this._tabsSubscription.unsubscribe(),this._tabLabelSubscription.unsubscribe(),this._tabBodySubscription.unsubscribe()}realignInkBar(){this._tabHeader&&this._tabHeader._alignInkBarToSelectedTab()}updatePagination(){this._tabHeader&&this._tabHeader.updatePagination()}focusTab(e){let t=this._tabHeader;t&&(t.focusIndex=e)}_focusChanged(e){this._lastFocusedTabIndex=e,this.focusChange.emit(this._createChangeEvent(e))}_createChangeEvent(e){let t=new vm;return t.index=e,this._tabs&&this._tabs.length&&(t.tab=this._tabs.toArray()[e]),t}_subscribeToTabLabels(){this._tabLabelSubscription&&this._tabLabelSubscription.unsubscribe(),this._tabLabelSubscription=ut(...this._tabs.map(e=>e._stateChanges)).subscribe(()=>this._changeDetectorRef.markForCheck())}_clampTabIndex(e){return Math.min(this._tabs.length-1,Math.max(e||0,0))}_getTabLabelId(e,t){return e.id||`${this._groupId}-label-${t}`}_getTabContentId(e){return`${this._groupId}-content-${e}`}_setTabBodyWrapperHeight(e){if(!this.dynamicHeight||!this._tabBodyWrapperHeight){this._tabBodyWrapperHeight=e;return}let t=this._tabBodyWrapper.nativeElement;t.style.height=this._tabBodyWrapperHeight+"px",this._tabBodyWrapper.nativeElement.offsetHeight&&(t.style.height=e+"px")}_removeTabBodyWrapperHeight(){let e=this._tabBodyWrapper.nativeElement;this._tabBodyWrapperHeight=e.clientHeight,e.style.height="",this._ngZone.run(()=>this.animationDone.emit())}_handleClick(e,t,a){t.focusIndex=a,e.disabled||(this.selectedIndex=a)}_getTabIndex(e){let t=this._lastFocusedTabIndex??this.selectedIndex;return e===t?0:-1}_tabFocusChanged(e,t){e&&e!=="mouse"&&e!=="touch"&&(this._tabHeader.focusIndex=t)}_bodyCentered(e){e&&this._tabBodies?.forEach((t,a)=>t._setActiveClass(a===this._selectedIndex))}_animationsDisabled(){return this._diAnimationsDisabled||this.animationDuration==="0"||this.animationDuration==="0ms"}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=A({type:n,selectors:[["mat-tab-group"]],contentQueries:function(t,a,o){if(t&1&&st(o,Cm,5),t&2){let c;j(c=V())&&(a._allTabs=c)}},viewQuery:function(t,a){if(t&1&&Ae($S,5)(GS,5)(bm,5),t&2){let o;j(o=V())&&(a._tabBodyWrapper=o.first),j(o=V())&&(a._tabHeader=o.first),j(o=V())&&(a._tabBodies=o)}},hostAttrs:[1,"mat-mdc-tab-group"],hostVars:11,hostBindings:function(t,a){t&2&&(Y("mat-align-tabs",a.alignTabs),ve("mat-"+(a.color||"primary")),Gt("--mat-tab-animation-duration",a.animationDuration),k("mat-mdc-tab-group-dynamic-height",a.dynamicHeight)("mat-mdc-tab-group-inverted-header",a.headerPosition==="below")("mat-mdc-tab-group-stretch-tabs",a.stretchTabs))},inputs:{color:"color",fitInkBarToContent:[2,"fitInkBarToContent","fitInkBarToContent",R],stretchTabs:[2,"mat-stretch-tabs","stretchTabs",R],alignTabs:[0,"mat-align-tabs","alignTabs"],dynamicHeight:[2,"dynamicHeight","dynamicHeight",R],selectedIndex:[2,"selectedIndex","selectedIndex",lt],headerPosition:"headerPosition",animationDuration:"animationDuration",contentTabIndex:[2,"contentTabIndex","contentTabIndex",lt],disablePagination:[2,"disablePagination","disablePagination",R],disableRipple:[2,"disableRipple","disableRipple",R],preserveContent:[2,"preserveContent","preserveContent",R],backgroundColor:"backgroundColor",ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"]},outputs:{selectedIndexChange:"selectedIndexChange",focusChange:"focusChange",animationDone:"animationDone",selectedTabChange:"selectedTabChange"},exportAs:["matTabGroup"],features:[ce([{provide:g0,useExisting:n}])],ngContentSelectors:ym,decls:9,vars:8,consts:[["tabHeader",""],["tabBodyWrapper",""],["tabNode",""],[3,"indexFocused","selectFocusedIndex","selectedIndex","disableRipple","disablePagination","aria-label","aria-labelledby"],["role","tab","matTabLabelWrapper","","cdkMonitorElementFocus","",1,"mdc-tab","mat-mdc-tab","mat-focus-indicator",3,"id","mdc-tab--active","class","disabled","fitInkBarToContent"],[1,"mat-mdc-tab-body-wrapper"],["role","tabpanel",3,"id","class","content","position","animationDuration","preserveContent"],["role","tab","matTabLabelWrapper","","cdkMonitorElementFocus","",1,"mdc-tab","mat-mdc-tab","mat-focus-indicator",3,"click","cdkFocusChange","id","disabled","fitInkBarToContent"],[1,"mdc-tab__ripple"],["mat-ripple","",1,"mat-mdc-tab-ripple",3,"matRippleTrigger","matRippleDisabled"],[1,"mdc-tab__content"],[1,"mdc-tab__text-label"],[3,"cdkPortalOutlet"],["role","tabpanel",3,"_onCentered","_onCentering","_beforeCentering","id","content","position","animationDuration","preserveContent"]],template:function(t,a){t&1&&(ye(),s(0,"mat-tab-header",3,0),_("indexFocused",function(c){return a._focusChanged(c)})("selectFocusedIndex",function(c){return a.selectedIndex=c}),te(2,YS,8,17,"div",4,Ke),r(),v(4,XS,1,0),s(5,"div",5,1),te(7,KS,1,10,"mat-tab-body",6,Ke),r()),t&2&&(P("selectedIndex",a.selectedIndex||0)("disableRipple",a.disableRipple)("disablePagination",a.disablePagination),ep("aria-label",a.ariaLabel)("aria-labelledby",a.ariaLabelledby),d(2),ne(a._tabs),d(2),y(a._isServer?4:-1),d(),k("_mat-animation-noopable",a._animationsDisabled()),d(2),ne(a._tabs))},dependencies:[ok,_0,iu,xn,tn,bm],styles:[`.mdc-tab {
  min-width: 90px;
  padding: 0 24px;
  display: flex;
  flex: 1 0 auto;
  justify-content: center;
  box-sizing: border-box;
  border: none;
  outline: none;
  text-align: center;
  white-space: nowrap;
  cursor: pointer;
  z-index: 1;
  touch-action: manipulation;
}

.mdc-tab__content {
  display: flex;
  align-items: center;
  justify-content: center;
  height: inherit;
  pointer-events: none;
}

.mdc-tab__text-label {
  transition: 150ms color linear;
  display: inline-block;
  line-height: 1;
  z-index: 2;
}

.mdc-tab--active .mdc-tab__text-label {
  transition-delay: 100ms;
}

._mat-animation-noopable .mdc-tab__text-label {
  transition: none;
}

.mdc-tab-indicator {
  display: flex;
  position: absolute;
  top: 0;
  left: 0;
  justify-content: center;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 1;
}

.mdc-tab-indicator__content {
  transition: var(--mat-tab-animation-duration, 250ms) transform cubic-bezier(0.4, 0, 0.2, 1);
  transform-origin: left;
  opacity: 0;
}

.mdc-tab-indicator__content--underline {
  align-self: flex-end;
  box-sizing: border-box;
  width: 100%;
  border-top-style: solid;
}

.mdc-tab-indicator--active .mdc-tab-indicator__content {
  opacity: 1;
}

._mat-animation-noopable .mdc-tab-indicator__content, .mdc-tab-indicator--no-transition .mdc-tab-indicator__content {
  transition: none;
}

.mat-mdc-tab-ripple.mat-mdc-tab-ripple {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  pointer-events: none;
}

.mat-mdc-tab {
  -webkit-tap-highlight-color: transparent;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-decoration: none;
  background: none;
  height: var(--mat-tab-container-height, 48px);
  font-family: var(--mat-tab-label-text-font, var(--mat-sys-title-small-font));
  font-size: var(--mat-tab-label-text-size, var(--mat-sys-title-small-size));
  letter-spacing: var(--mat-tab-label-text-tracking, var(--mat-sys-title-small-tracking));
  line-height: var(--mat-tab-label-text-line-height, var(--mat-sys-title-small-line-height));
  font-weight: var(--mat-tab-label-text-weight, var(--mat-sys-title-small-weight));
}
.mat-mdc-tab.mdc-tab {
  flex-grow: 0;
}
.mat-mdc-tab .mdc-tab-indicator__content--underline {
  border-color: var(--mat-tab-active-indicator-color, var(--mat-sys-primary));
  border-top-width: var(--mat-tab-active-indicator-height, 2px);
  border-radius: var(--mat-tab-active-indicator-shape, 0);
}
.mat-mdc-tab:hover .mdc-tab__text-label {
  color: var(--mat-tab-inactive-hover-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab:focus .mdc-tab__text-label {
  color: var(--mat-tab-inactive-focus-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab.mdc-tab--active .mdc-tab__text-label {
  color: var(--mat-tab-active-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab.mdc-tab--active .mdc-tab__ripple::before,
.mat-mdc-tab.mdc-tab--active .mat-ripple-element {
  background-color: var(--mat-tab-active-ripple-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab.mdc-tab--active:hover .mdc-tab__text-label {
  color: var(--mat-tab-active-hover-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab.mdc-tab--active:hover .mdc-tab-indicator__content--underline {
  border-color: var(--mat-tab-active-hover-indicator-color, var(--mat-sys-primary));
}
.mat-mdc-tab.mdc-tab--active:focus .mdc-tab__text-label {
  color: var(--mat-tab-active-focus-label-text-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab.mdc-tab--active:focus .mdc-tab-indicator__content--underline {
  border-color: var(--mat-tab-active-focus-indicator-color, var(--mat-sys-primary));
}
.mat-mdc-tab.mat-mdc-tab-disabled {
  opacity: 0.4;
  pointer-events: none;
}
.mat-mdc-tab.mat-mdc-tab-disabled .mdc-tab__content {
  pointer-events: none;
}
.mat-mdc-tab.mat-mdc-tab-disabled .mdc-tab__ripple::before,
.mat-mdc-tab.mat-mdc-tab-disabled .mat-ripple-element {
  background-color: var(--mat-tab-disabled-ripple-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-tab .mdc-tab__ripple::before {
  content: "";
  display: block;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  opacity: 0;
  pointer-events: none;
  background-color: var(--mat-tab-inactive-ripple-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab .mdc-tab__text-label {
  color: var(--mat-tab-inactive-label-text-color, var(--mat-sys-on-surface));
  display: inline-flex;
  align-items: center;
}
.mat-mdc-tab .mdc-tab__content {
  position: relative;
  pointer-events: auto;
}
.mat-mdc-tab:hover .mdc-tab__ripple::before {
  opacity: 0.04;
}
.mat-mdc-tab.cdk-program-focused .mdc-tab__ripple::before, .mat-mdc-tab.cdk-keyboard-focused .mdc-tab__ripple::before {
  opacity: 0.12;
}
.mat-mdc-tab .mat-ripple-element {
  opacity: 0.12;
  background-color: var(--mat-tab-inactive-ripple-color, var(--mat-sys-on-surface));
}
.mat-mdc-tab-group.mat-mdc-tab-group-stretch-tabs > .mat-mdc-tab-header .mat-mdc-tab {
  flex-grow: 1;
}

.mat-mdc-tab-group {
  display: flex;
  flex-direction: column;
  max-width: 100%;
}
.mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header, .mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header-pagination {
  background-color: var(--mat-tab-background-color);
}
.mat-mdc-tab-group.mat-tabs-with-background.mat-primary > .mat-mdc-tab-header .mat-mdc-tab .mdc-tab__text-label {
  color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-tabs-with-background.mat-primary > .mat-mdc-tab-header .mdc-tab-indicator__content--underline {
  border-color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-tabs-with-background:not(.mat-primary) > .mat-mdc-tab-header .mat-mdc-tab:not(.mdc-tab--active) .mdc-tab__text-label {
  color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-tabs-with-background:not(.mat-primary) > .mat-mdc-tab-header .mat-mdc-tab:not(.mdc-tab--active) .mdc-tab-indicator__content--underline {
  border-color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header .mat-mdc-tab-header-pagination-chevron,
.mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header .mat-focus-indicator::before, .mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header-pagination .mat-mdc-tab-header-pagination-chevron,
.mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header-pagination .mat-focus-indicator::before {
  border-color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header .mat-ripple-element, .mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header .mdc-tab__ripple::before, .mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header-pagination .mat-ripple-element, .mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header-pagination .mdc-tab__ripple::before {
  background-color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header .mat-mdc-tab-header-pagination-chevron, .mat-mdc-tab-group.mat-tabs-with-background > .mat-mdc-tab-header-pagination .mat-mdc-tab-header-pagination-chevron {
  color: var(--mat-tab-foreground-color);
}
.mat-mdc-tab-group.mat-mdc-tab-group-inverted-header {
  flex-direction: column-reverse;
}
.mat-mdc-tab-group.mat-mdc-tab-group-inverted-header .mdc-tab-indicator__content--underline {
  align-self: flex-start;
}

.mat-mdc-tab-body-wrapper {
  position: relative;
  overflow: hidden;
  display: flex;
  transition: height 500ms cubic-bezier(0.35, 0, 0.25, 1);
}
.mat-mdc-tab-body-wrapper._mat-animation-noopable {
  transition: none !important;
  animation: none !important;
}
`],encapsulation:2})}return n})(),vm=class{index;tab};var v0=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=q({type:n});static \u0275inj=G({imports:[de]})}return n})();function wm(n){return`${n.origen}:${n.folioQueja}`}var y0=()=>[],ck=n=>({$implicit:n,fuente:"MANUAL"}),lk=(n,i)=>({$implicit:n,fuente:i}),dk=(n,i)=>i.id;function x0(n,i){return this.clave(i)}function uk(n,i){n&1&&(s(0,"p",12),l(1," Todav\xEDa no hay antecedentes guardados. M\xE1rcalos en la b\xFAsqueda manual o en la del modelo y usa \u201CGuardar seleccionados\u201D. "),r())}function mk(n,i){if(n&1&&l(0),n&2){let e=h().$implicit;N(" \xB7 ",e.similitud,"% ")}}function pk(n,i){if(n&1){let e=T();s(0,"button",36),_("click",function(){x(e);let a=h().$implicit,o=h(2);return C(o.abrirExpediente(a.folioPrimerContacto))}),s(1,"mat-icon"),l(2,"open_in_new"),r()()}}function hk(n,i){if(n&1){let e=T();s(0,"div",27)(1,"div",28),_("click",function(){let a=x(e).$implicit,o=h(2);return C(o.verDetalle(a))}),s(2,"strong"),l(3),r(),s(4,"span",29),l(5),r(),s(6,"span",30),l(7),v(8,mk,1,1),r(),s(9,"span",31),l(10),r(),s(11,"span",32),l(12),r()(),s(13,"div",33),v(14,pk,3,0,"button",34),s(15,"button",35),_("click",function(){let a=x(e).$implicit,o=h(2);return C(o.quitarGuardado(a))}),s(16,"mat-icon"),l(17,"delete_outline"),r()()()()}if(n&2){let e=i.$implicit,t=h(2);d(3),g(e.folioQueja),d(),k("historico",e.origen==="HISTORICO"),d(),N(" ",t.etiquetaOrigen(e.origen)," "),d(2),N("",t.etiquetaFuente(e.fuente)," "),d(),y(e.similitud!=null?8:-1),d(2),g(e.asunto||"Sin asunto"),d(2),ip(" Quejoso: ",e.nombreQuejoso||"\u2014"," \xB7 Denunciado: ",e.nombreDenunciado||"\u2014"," \xB7 Guard\xF3 ",e.analistaNombre||"\u2014",", ",t.formatearFecha(e.fechaRegistro)," "),d(2),y(e.folioPrimerContacto?14:-1)}}function fk(n,i){if(n&1&&(s(0,"div",13),te(1,hk,18,12,"div",27,dk),r()),n&2){let e=h();d(),ne(e.guardados)}}function gk(n,i){n&1&&(s(0,"mat-icon",37),l(1,"person_search"),r(),l(2," B\xFAsqueda manual "))}function _k(n,i){n&1&&H(0,"mat-progress-bar",23)}function bk(n,i){if(n&1&&(s(0,"div",24)(1,"mat-icon"),l(2,"error_outline"),r(),s(3,"span"),l(4),r()()),n&2){let e=h();d(4),g(e.errorManual)}}function vk(n,i){if(n&1&&(s(0,"div",38)(1,"mat-icon"),l(2,"info"),r(),s(3,"span"),l(4),r()()),n&2){let e=i.$implicit;d(4),g(e)}}function yk(n,i){n&1&&ot(0)}function xk(n,i){if(n&1&&_e(0,yk,1,0,"ng-container",41),n&2){let e=i.$implicit;h(2);let t=ct(69);P("ngTemplateOutlet",t)("ngTemplateOutletContext",ap(2,ck,e))}}function Ck(n,i){n&1&&(s(0,"mat-card",40)(1,"mat-icon"),l(2,"search_off"),r(),s(3,"p"),l(4,"No se encontraron quejas con esos nombres."),r()())}function wk(n,i){if(n&1&&(te(0,vk,5,1,"div",38,Ke),s(2,"div",39),te(3,xk,1,4,"ng-container",null,x0,!0,Ck,5,0,"mat-card",40),r()),n&2){let e=h();ne(e.manual.avisos??Yl(1,y0)),d(3),ne(e.manual.resultados)}}function Dk(n,i){n&1&&(s(0,"mat-icon",37),l(1,"psychology"),r(),l(2," Con el modelo "))}function Ek(n,i){n&1&&(s(0,"mat-card",25)(1,"mat-icon",42),l(2,"psychology"),r(),s(3,"div")(4,"strong"),l(5,"Buscando antecedentes\u2026"),r(),s(6,"p"),l(7,"Comparando la narrativa de la queja con otras quejas."),r(),H(8,"mat-progress-bar",23),r()())}function Sk(n,i){if(n&1){let e=T();s(0,"mat-card",25)(1,"mat-icon",43),l(2,"error_outline"),r(),s(3,"div")(4,"strong"),l(5,"No fue posible completar la b\xFAsqueda."),r(),s(6,"p"),l(7,"Intenta de nuevo con \u201CVolver a buscar\u201D."),r()(),s(8,"button",4),_("click",function(){x(e);let a=h();return C(a.buscarConModelo())}),s(9,"mat-icon"),l(10,"refresh"),r(),l(11," Volver a buscar "),r()()}}function kk(n,i){if(n&1&&(s(0,"div",38)(1,"mat-icon"),l(2,"info"),r(),s(3,"span"),l(4),r()()),n&2){let e=i.$implicit;d(4),g(e)}}function Mk(n,i){if(n&1){let e=T();s(0,"mat-slide-toggle",56),ge("ngModelChange",function(a){x(e);let o=h(2);return fe(o.soloMismoQuejoso,a)||(o.soloMismoQuejoso=a),C(a)}),l(1,"Solo del mismo quejoso"),r()}if(n&2){let e=h(2);he("ngModel",e.soloMismoQuejoso)}}function Ik(n,i){n&1&&ot(0)}function Ak(n,i){if(n&1&&_e(0,Ik,1,0,"ng-container",41),n&2){let e=i.$implicit,t=h(2),a=ct(69);P("ngTemplateOutlet",a)("ngTemplateOutletContext",op(2,lk,e,t.modelo.motor))}}function Rk(n,i){n&1&&l(0," Ning\xFAn antecedente cumple los filtros seleccionados. ")}function Tk(n,i){n&1&&l(0," No hay quejas de la misma persona con hechos parecidos. ")}function Ok(n,i){n&1&&l(0," No se encontraron quejas del mismo quejoso ni del mismo denunciado. ")}function Pk(n,i){n&1&&l(0," No se encontraron quejas con hechos parecidos. ")}function Fk(n,i){if(n&1&&(s(0,"mat-card",40)(1,"mat-icon"),l(2,"verified"),r(),s(3,"p"),v(4,Rk,1,0)(5,Tk,1,0)(6,Ok,1,0)(7,Pk,1,0),r()()),n&2){let e=h(2);d(4),y(e.lista(e.categoria).length>0?4:e.categoria==="fuertes"?5:e.categoria==="involucrados"?6:7)}}function Nk(n,i){if(n&1){let e=T();te(0,kk,5,1,"div",38,Ke),s(2,"div",44)(3,"mat-icon"),l(4),r(),s(5,"span")(6,"strong"),l(7),r(),l(8),r(),s(9,"button",45),_("click",function(){x(e);let a=h();return C(a.buscarConModelo())}),s(10,"mat-icon"),l(11,"refresh"),r(),l(12," Volver a buscar "),r()(),s(13,"div",46)(14,"button",47),_("click",function(){x(e);let a=h();return C(a.categoria="fuertes")}),s(15,"span",48),l(16),r(),s(17,"span",49)(18,"strong"),l(19,"Coincidencias fuertes"),r(),s(20,"small"),l(21,"Misma persona y hechos parecidos: revisar primero"),r()()(),s(22,"button",50),_("click",function(){x(e);let a=h();return C(a.categoria="involucrados")}),s(23,"span",48),l(24),r(),s(25,"span",49)(26,"strong"),l(27,"Por involucrados"),r(),s(28,"small"),l(29,"Mismo quejoso y/o denunciado"),r()()(),s(30,"button",50),_("click",function(){x(e);let a=h();return C(a.categoria="hechos")}),s(31,"span",48),l(32),r(),s(33,"span",49)(34,"strong"),l(35,"Por hechos"),r(),s(36,"small"),l(37,"Narrativa parecida, aunque sean otras personas"),r()()()(),s(38,"div",51)(39,"div",52),v(40,Mk,2,1,"mat-slide-toggle",53),s(41,"mat-button-toggle-group",54),ge("ngModelChange",function(a){x(e);let o=h();return fe(o.similitudMinima,a)||(o.similitudMinima=a),C(a)}),s(42,"mat-button-toggle",55),l(43,"Todas"),r(),s(44,"mat-button-toggle",55),l(45,"\u2265 40%"),r(),s(46,"mat-button-toggle",55),l(47,"\u2265 70%"),r()()()(),s(48,"div",39),te(49,Ak,1,5,"ng-container",null,x0,!0,Fk,8,1,"mat-card",40),r()}if(n&2){let e=h();ne(e.modelo.avisos??Yl(23,y0)),d(2),k("provisional",e.esProvisional),d(2),g(e.esProvisional?"construction":"psychology"),d(3),N("",e.esProvisional?"Motor provisional":"Modelo de b\xFAsqueda","."),d(),N(" ",e.modelo.descripcionMotor," Los resultados apoyan la revisi\xF3n: no determinan si una queja est\xE1 duplicada. "),d(6),k("activa",e.categoria==="fuertes"),Y("aria-selected",e.categoria==="fuertes"),d(2),g(e.lista("fuertes").length),d(6),k("activa",e.categoria==="involucrados"),Y("aria-selected",e.categoria==="involucrados"),d(2),g(e.lista("involucrados").length),d(6),k("activa",e.categoria==="hechos"),Y("aria-selected",e.categoria==="hechos"),d(2),g(e.lista("hechos").length),d(8),y(e.categoria==="involucrados"?40:-1),d(),he("ngModel",e.similitudMinima),d(),P("value",0),d(2),P("value",40),d(2),P("value",70),d(3),ne(e.resultadosModelo)}}function Lk(n,i){if(n&1){let e=T();s(0,"div",26)(1,"mat-icon"),l(2,"checklist"),r(),s(3,"span")(4,"strong"),l(5),r(),l(6),r(),s(7,"button",57),_("click",function(){x(e);let a=h();return C(a.limpiarSeleccion())}),l(8,"Limpiar"),r(),s(9,"button",58),_("click",function(){x(e);let a=h();return C(a.guardarSeleccion())}),s(10,"mat-icon"),l(11,"bookmark_add"),r(),l(12," Guardar seleccionados "),r()()}if(n&2){let e=h();d(5),g(e.seleccion.size),d(),N(" seleccionado",e.seleccion.size===1?"":"s"," (de cualquier pesta\xF1a) "),d(),P("disabled",e.guardando),d(2),P("disabled",e.guardando)}}function Bk(n,i){n&1&&(s(0,"mat-icon",61),l(1,"bookmark_added"),r())}function jk(n,i){if(n&1){let e=T();s(0,"mat-checkbox",74),_("change",function(){x(e);let a=h(),o=a.$implicit,c=a.fuente,u=h();return C(u.alternarSeleccion(o,c))}),r()}if(n&2){let e=h().$implicit,t=h();P("checked",t.estaSeleccionado(e))}}function Vk(n,i){if(n&1&&(s(0,"div",63)(1,"span",75),l(2),r(),s(3,"div",76),H(4,"div"),r(),s(5,"span",77),l(6),r()()),n&2){let e=h().$implicit,t=h();d(2),N("",e.similitud,"%"),d(2),Gt("width",e.similitud,"%"),d(2),N("Similitud ",t.nivel(e.similitud))}}function zk(n,i){if(n&1&&(s(0,"span",68)(1,"mat-icon"),l(2,"priority_high"),r(),l(3),r()),n&2){let e=h().$implicit;d(3),g(e.razonCoincidencia)}}function Uk(n,i){if(n&1&&(s(0,"p"),l(1),r()),n&2){let e=h().$implicit;d(),g(e.extracto)}}function Hk(n,i){if(n&1&&(s(0,"span",71),l(1),r()),n&2){let e=i.$implicit;k("fuerte",e.startsWith("Quejoso:")||e.startsWith("Denunciado:")||e.startsWith("Identificaci\xF3n")||e.startsWith("Correo"))("por-verificar",e.includes("por verificar")),d(),g(e)}}function $k(n,i){if(n&1&&(s(0,"span",71),l(1),r()),n&2){let e=h().$implicit;d(),N("Hechos con ",e.diasDiferencia," d\xEDas de diferencia")}}function Gk(n,i){if(n&1){let e=T();s(0,"button",4),_("click",function(){x(e);let a=h().$implicit,o=h();return C(o.abrirExpediente(a.folioPrimerContacto))}),s(1,"mat-icon"),l(2,"open_in_new"),r(),l(3," Ver expediente "),r()}}function qk(n,i){if(n&1){let e=T();s(0,"mat-card",59)(1,"div",60),v(2,Bk,2,0,"mat-icon",61)(3,jk,1,1,"mat-checkbox",62),r(),v(4,Vk,7,4,"div",63),s(5,"div",64)(6,"div",65)(7,"strong",66),_("click",function(){let a=x(e).$implicit,o=h();return C(o.verDetalle(a))}),l(8),r(),s(9,"span",29),l(10),r(),s(11,"span",67),l(12),r()(),s(13,"span",32),l(14),r(),s(15,"span",32),l(16),r(),v(17,zk,4,1,"span",68),v(18,Uk,2,1,"p"),s(19,"div",69),te(20,Hk,2,5,"span",70,Ke),v(22,$k,2,1,"span",71),r()(),s(23,"div",72)(24,"button",4),_("click",function(){let a=x(e).$implicit,o=h();return C(o.verDetalle(a))}),s(25,"mat-icon"),l(26,"visibility"),r(),l(27," Ver detalle "),r(),s(28,"button",4),_("click",function(){let a=x(e).$implicit,o=h();return C(o.verResumen(a))}),s(29,"mat-icon"),l(30,"summarize"),r(),l(31," Resumen "),r(),v(32,Gk,4,0,"button",73),r()()}if(n&2){let e=i.$implicit,t=i.fuente,a=h();k("manual",t==="MANUAL")("seleccionado",a.estaSeleccionado(e)),Y("data-nivel",t==="MANUAL"?null:a.nivel(e.similitud)),d(2),y(a.estaGuardado(e)?2:3),d(2),y(t!=="MANUAL"?4:-1),d(4),g(e.asunto||"Sin asunto"),d(),k("historico",e.origen==="HISTORICO"),d(),N(" ",a.etiquetaOrigen(e.origen)," "),d(2),g(a.etiquetaQueja(e.estatus)),d(2),Nn(" ",e.folioQueja," \xB7 ",a.formatearFecha(e.fecha)," \xB7 ",e.unidadAcademica||"Sin unidad"," "),d(2),qe(" Quejoso: ",e.nombreQuejoso||"\u2014"," \xB7 Denunciado: ",e.nombreDenunciado||"\u2014"," "),d(),y(e.razonCoincidencia?17:-1),d(),y(e.extracto?18:-1),d(2),ne(e.coincidencias),d(2),y(e.diasDiferencia!=null?22:-1),d(10),y(e.folioPrimerContacto?32:-1)}}var Wk={RECIBIDA:"Recibida",EN_VALIDACION:"En validaci\xF3n",RECHAZADA:"Rechazada",CORREGIDA:"Corregida",CANCELADA:"Cancelada",TURNADA:"Turnada",EN_ANALISIS:"En an\xE1lisis",PROCEDENTE:"Procedente",IMPROCEDENTE:"Improcedente",REMITIDA:"Remitida",CONCLUIDA:"Concluida"},Qk={MANUAL:"B\xFAsqueda manual",MODELO:"Modelo",REGLAS_PROVISIONAL:"Motor provisional"},Dl=class n{constructor(i,e,t,a,o,c,u){this.route=i;this.router=e;this.antecedentesService=t;this.expedienteService=a;this.dialog=o;this.snackBar=c;this.cdr=u;this.folio=this.route.snapshot.paramMap.get("id")??""}route;router;antecedentesService;expedienteService;dialog;snackBar;cdr;folio="";expediente;nombreQuejoso="";nombreDenunciado="";manual;buscandoManual=!1;errorManual="";modelo;buscandoModelo=!1;errorModelo=!1;soloMismoQuejoso=!1;similitudMinima=0;categoria="involucrados";seleccion=new Map;guardados=[];guardando=!1;formatearFecha=oi;ngOnInit(){this.expedienteService.obtenerPorFolio(this.folio).subscribe({next:i=>{this.expediente=this.expedienteService.mapearADetalle(i),this.cdr.detectChanges()}}),this.cargarGuardados(),this.buscarConModelo()}usarQuejosoDeLaQueja(){this.nombreQuejoso=this.expediente?.quejoso?.nombre??""}buscarManual(){if(!this.nombreQuejoso.trim()&&!this.nombreDenunciado.trim()){this.errorManual="Escribe el nombre del quejoso, del denunciado o de ambos.";return}this.buscandoManual=!0,this.errorManual="",this.cdr.detectChanges(),this.antecedentesService.buscarManual(this.folio,this.nombreQuejoso,this.nombreDenunciado).subscribe({next:i=>{this.manual=i,this.buscandoManual=!1,this.cdr.detectChanges()},error:i=>{this.buscandoManual=!1,this.errorManual=Ne(i,"No fue posible completar la b\xFAsqueda."),this.cdr.detectChanges()}})}buscarConModelo(){this.buscandoModelo=!0,this.errorModelo=!1,this.cdr.detectChanges(),this.antecedentesService.buscar(this.folio).subscribe({next:i=>{this.modelo=i,this.categoria=this.lista("fuertes").length>0?"fuertes":this.lista("involucrados").length>0?"involucrados":"hechos",this.buscandoModelo=!1,this.cdr.detectChanges()},error:()=>{this.buscandoModelo=!1,this.errorModelo=!0,this.cdr.detectChanges()}})}lista(i){switch(i){case"fuertes":return this.modelo?.coincidenciasFuertes??[];case"hechos":return this.modelo?.porHechos??[];default:return this.modelo?.porInvolucrados??this.modelo?.resultados??[]}}get resultadosModelo(){return this.lista(this.categoria).filter(i=>(this.categoria!=="involucrados"||!this.soloMismoQuejoso||i.mismoQuejoso)&&i.similitud>=this.similitudMinima)}get esProvisional(){return this.modelo?.motor==="REGLAS_PROVISIONAL"}clave(i){return wm(i)}estaSeleccionado(i){return this.seleccion.has(this.clave(i))}estaGuardado(i){let e=this.clave(i);return this.guardados.some(t=>wm(t)===e)}alternarSeleccion(i,e){let t=this.clave(i);this.seleccion.has(t)?this.seleccion.delete(t):this.seleccion.set(t,{antecedente:i,fuente:e})}limpiarSeleccion(){this.seleccion.clear()}guardarSeleccion(){if(this.seleccion.size===0)return;let i=[...this.seleccion.values()].map(({antecedente:e,fuente:t})=>({origen:e.origen,folioQueja:e.folioQueja,fuente:t,similitud:t==="MANUAL"?null:e.similitud,asunto:e.asunto,fecha:e.fecha,nombreQuejoso:e.nombreQuejoso,nombreDenunciado:e.nombreDenunciado,unidadAcademica:e.unidadAcademica,estatus:e.estatus,folioPrimerContacto:e.folioPrimerContacto,extracto:e.extracto,descripcion:e.descripcion,resultado:e.resultado}));this.guardando=!0,this.antecedentesService.guardar(this.folio,i).subscribe({next:e=>{this.guardados=e,this.guardando=!1;let t=this.seleccion.size;this.seleccion.clear(),this.cdr.detectChanges(),this.snackBar.open(`${t} antecedente${t===1?"":"s"} guardado${t===1?"":"s"} en el expediente.`,"Cerrar",{duration:3e3})},error:e=>{this.guardando=!1,this.cdr.detectChanges(),this.snackBar.open(Ne(e,"No fue posible guardar los antecedentes."),"Cerrar",{duration:3500})}})}quitarGuardado(i){i.id&&confirm(`\xBFQuitar ${i.folioQueja} de los antecedentes del expediente?`)&&this.antecedentesService.quitar(this.folio,i.id).subscribe({next:()=>{this.guardados=this.guardados.filter(e=>e.id!==i.id),this.cdr.detectChanges()},error:e=>{this.snackBar.open(Ne(e,"No fue posible quitar el antecedente."),"Cerrar",{duration:3500})}})}cargarGuardados(){this.antecedentesService.guardados(this.folio).subscribe({next:i=>{this.guardados=i,this.cdr.detectChanges()}})}verResumenQuejaAnalizada(){this.abrirResumen({folio:this.expediente?.folioOrigen??this.folio,asunto:this.expediente?.asunto,texto:this.expediente?.narrativa})}verResumen(i){this.abrirResumen({folio:i.folioQueja,asunto:i.asunto,texto:i.descripcion??i.extracto})}verDetalle(i){this.dialog.open(yo,{width:"720px",data:i})}abrirResumen(i){this.dialog.open(vo,{width:"640px",data:i})}nivel(i){return i>=70?"alta":i>=40?"media":"baja"}etiquetaQueja(i){return i?Wk[i]??i:"Sin estatus"}etiquetaOrigen(i){return i==="HISTORICO"?"Hist\xF3rico":"Sistema"}etiquetaFuente(i){return Qk[i]??i}abrirExpediente(i){i&&this.router.navigate(["/expediente",i])}volver(){this.router.navigate(["/expediente",this.folio])}static \u0275fac=function(e){return new(e||n)(S(Ct),S(We),S(Do),S(Yn),S(An),S(Mt),S(Z))};static \u0275cmp=A({type:n,selectors:[["app-antecedentes"]],decls:70,vars:16,consts:[["tarjeta",""],[1,"page"],[1,"page-header"],[1,"header-actions"],["mat-stroked-button","",3,"click"],[1,"card","referencia"],[1,"referencia-icon"],[1,"referencia-texto"],[1,"eyebrow"],[1,"card","guardados"],[1,"guardados-titulo"],[1,"contador"],[1,"ayuda"],[1,"lista-guardados"],["animationDuration","0ms",1,"pestanas"],["mat-tab-label",""],[1,"tab-contenido"],[1,"form-manual",3,"ngSubmit"],["appearance","outline"],["matInput","","name","quejoso","autocomplete","off",3,"ngModelChange","ngModel"],["mat-icon-button","","matSuffix","","type","button","matTooltip","Usar el quejoso de esta queja",3,"click"],["matInput","","name","denunciado","autocomplete","off",3,"ngModelChange","ngModel"],["mat-flat-button","","type","submit",1,"primary-btn",3,"disabled"],["mode","indeterminate"],[1,"aviso","error"],[1,"card","estado-busqueda"],[1,"barra-seleccion"],[1,"guardado"],["matTooltip","Ver detalle de la queja",1,"guardado-datos","clicable",3,"click"],[1,"chip","origen"],[1,"chip"],[1,"guardado-asunto"],[1,"meta"],[1,"guardado-acciones"],["mat-icon-button","","matTooltip","Ver expediente"],["mat-icon-button","","matTooltip","Quitar de los antecedentes",3,"click"],["mat-icon-button","","matTooltip","Ver expediente",3,"click"],[1,"tab-icon"],[1,"aviso"],[1,"resultados"],[1,"card","vacio"],[4,"ngTemplateOutlet","ngTemplateOutletContext"],[1,"pulso"],[1,"error-icon"],[1,"motor"],["mat-stroked-button","",1,"motor-boton",3,"click"],["role","tablist","aria-label","Tipo de antecedente",1,"categorias"],["type","button","role","tab",1,"categoria","fuertes",3,"click"],[1,"numero"],[1,"categoria-texto"],["type","button","role","tab",1,"categoria",3,"click"],[1,"barra"],[1,"filtros"],[3,"ngModel"],["aria-label","Similitud m\xEDnima",3,"ngModelChange","ngModel"],[3,"value"],[3,"ngModelChange","ngModel"],["mat-stroked-button","",3,"click","disabled"],["mat-flat-button","",1,"primary-btn",3,"click","disabled"],[1,"card","resultado"],[1,"marca"],["matTooltip","Ya est\xE1 guardado en el expediente",1,"ya-guardado"],["aria-label","Seleccionar como antecedente",3,"checked"],[1,"similitud"],[1,"contenido"],[1,"titulo"],["matTooltip","Ver detalle de la queja",1,"clicable",3,"click"],[1,"estatus-queja"],[1,"razon"],[1,"coincidencias"],[1,"coincidencia",3,"fuerte","por-verificar"],[1,"coincidencia"],[1,"acciones"],["mat-stroked-button",""],["aria-label","Seleccionar como antecedente",3,"change","checked"],[1,"porcentaje"],[1,"barra-similitud"],[1,"nivel"]],template:function(e,t){if(e&1){let a=T();s(0,"section",1)(1,"div",2)(2,"div")(3,"h2"),l(4,"B\xFAsqueda de antecedentes"),r(),s(5,"p"),l(6),r()(),s(7,"div",3)(8,"button",4),_("click",function(){return t.volver()}),s(9,"mat-icon"),l(10,"arrow_back"),r(),l(11," Volver al expediente "),r()()(),s(12,"mat-card",5)(13,"mat-icon",6),l(14,"description"),r(),s(15,"div",7)(16,"span",8),l(17,"Queja analizada"),r(),s(18,"strong"),l(19),r(),s(20,"p"),l(21),r()(),s(22,"button",4),_("click",function(){return t.verResumenQuejaAnalizada()}),s(23,"mat-icon"),l(24,"summarize"),r(),l(25," Resumen "),r()(),s(26,"mat-card",9)(27,"div",10)(28,"mat-icon"),l(29,"bookmarks"),r(),s(30,"strong"),l(31,"Antecedentes guardados en el expediente"),r(),s(32,"span",11),l(33),r()(),v(34,uk,2,0,"p",12)(35,fk,3,0,"div",13),r(),s(36,"mat-tab-group",14)(37,"mat-tab"),_e(38,gk,3,0,"ng-template",15),s(39,"div",16)(40,"form",17),_("ngSubmit",function(){return t.buscarManual()}),s(41,"mat-form-field",18)(42,"mat-label"),l(43,"Nombre del quejoso"),r(),s(44,"input",19),ge("ngModelChange",function(c){return x(a),fe(t.nombreQuejoso,c)||(t.nombreQuejoso=c),C(c)}),r(),s(45,"button",20),_("click",function(){return t.usarQuejosoDeLaQueja()}),s(46,"mat-icon"),l(47,"person"),r()()(),s(48,"mat-form-field",18)(49,"mat-label"),l(50,"Nombre del denunciado"),r(),s(51,"input",21),ge("ngModelChange",function(c){return x(a),fe(t.nombreDenunciado,c)||(t.nombreDenunciado=c),C(c)}),r()(),s(52,"button",22)(53,"mat-icon"),l(54,"search"),r(),l(55," Buscar "),r()(),s(56,"p",12),l(57," Busca en las quejas del sistema y en los casos hist\xF3ricos. No importan may\xFAsculas ni acentos; puedes escribir solo una parte del nombre. "),r(),v(58,_k,1,0,"mat-progress-bar",23)(59,bk,5,1,"div",24)(60,wk,6,2),r()(),s(61,"mat-tab"),_e(62,Dk,3,0,"ng-template",15),s(63,"div",16),v(64,Ek,9,0,"mat-card",25)(65,Sk,12,0,"mat-card",25)(66,Nk,52,24),r()()(),v(67,Lk,13,4,"div",26),r(),_e(68,qk,33,21,"ng-template",null,0,Ia)}e&2&&(k("con-seleccion",t.seleccion.size>0),d(6),Nn(" Expediente ",t.folio," \xB7 Queja ",t.expediente==null?null:t.expediente.folioOrigen," \xB7 ",(t.expediente==null?null:t.expediente.asunto)||"Sin asunto"," "),d(13),qe("",t.expediente==null||t.expediente.quejoso==null?null:t.expediente.quejoso.nombre," \xB7 ",t.expediente==null||t.expediente.quejoso==null?null:t.expediente.quejoso.unidadAcademica),d(2),g(t.expediente==null?null:t.expediente.narrativa),d(12),g(t.guardados.length),d(),y(t.guardados.length===0?34:35),d(10),he("ngModel",t.nombreQuejoso),d(7),he("ngModel",t.nombreDenunciado),d(),P("disabled",t.buscandoManual),d(6),y(t.buscandoManual?58:t.errorManual?59:t.manual?60:-1),d(6),y(t.buscandoModelo?64:t.errorModelo?65:t.modelo?66:-1),d(3),y(t.seleccion.size>0?67:-1))},dependencies:[Qi,Ot,bg,ft,Tt,ug,St,ra,sn,jn,Ge,Je,yu,ze,Ve,c0,hm,u0,fm,wl,hl,pl,fo,qr,v0,xm,Cm,b0,po,ha,kt,ln,Jt,Tu,mn,Gn,Nt,Ft],styles:[".page[_ngcontent-%COMP%]{max-width:1280px}.page-header[_ngcontent-%COMP%]{margin-bottom:var(--space-5);display:flex;justify-content:space-between;align-items:center;gap:var(--space-5)}.page-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{margin:0;color:var(--guinda);font-size:28px;font-weight:800}.page-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-1) 0 0;color:var(--texto-suave)}.header-actions[_ngcontent-%COMP%]{display:flex;gap:var(--space-2)}button[_ngcontent-%COMP%]{border-radius:8px!important;font-weight:700!important}.primary-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important}.card[_ngcontent-%COMP%]{border-radius:14px;box-shadow:0 2px 8px #0f172a14;padding:var(--space-4);background:#fff}.eyebrow[_ngcontent-%COMP%]{display:block;color:var(--guinda);text-transform:uppercase;font-size:var(--font-size-xs);font-weight:900;letter-spacing:.05em}.referencia[_ngcontent-%COMP%]{display:flex;flex-direction:row;gap:var(--space-3);margin-bottom:var(--space-4);background:var(--guinda-suave)}.referencia-icon[_ngcontent-%COMP%]{color:var(--guinda)}.referencia[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-1) 0 0;color:var(--texto);font-size:var(--font-size-sm)}.estado-busqueda[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:center;gap:var(--space-4);padding:var(--space-5)}.estado-busqueda[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{flex:1}.estado-busqueda[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-1) 0 var(--space-3);color:var(--texto-suave)}.estado-busqueda[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:40px;width:40px;height:40px;color:var(--guinda)}.estado-busqueda[_ngcontent-%COMP%]   .error-icon[_ngcontent-%COMP%]{color:var(--peligro)}.pulso[_ngcontent-%COMP%]{animation:_ngcontent-%COMP%_pulso 1.2s ease-in-out infinite}@keyframes _ngcontent-%COMP%_pulso{50%{opacity:.35}}.motor[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:var(--space-2);padding:var(--space-3) var(--space-4);border-radius:10px;background:#e0f2fe;color:#075985;font-size:var(--font-size-sm);margin-bottom:var(--space-4)}.motor.provisional[_ngcontent-%COMP%]{background:#fff4e5;color:#7a4800}.categorias[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:var(--space-3);margin-bottom:var(--space-4)}.categoria[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) var(--space-4);border:2px solid var(--borde, #e5e7eb);border-radius:10px;background:#fff;text-align:left;cursor:pointer;font:inherit;color:var(--texto)}.categoria[_ngcontent-%COMP%]:hover{border-color:var(--guinda-suave)}.categoria.activa[_ngcontent-%COMP%]{border-color:var(--guinda);background:var(--guinda-suave)}.categoria[_ngcontent-%COMP%]:focus-visible{outline:3px solid var(--guinda);outline-offset:2px}.categoria-texto[_ngcontent-%COMP%]{display:grid;gap:2px}.categoria-texto[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{color:var(--texto-suave);font-size:var(--font-size-xs)}.razon[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-1);color:var(--guinda);font-size:var(--font-size-sm);font-weight:700}.razon[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:18px;width:18px;height:18px}.barra[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:var(--space-4);margin-bottom:var(--space-4)}.resumen[_ngcontent-%COMP%]{display:flex;gap:var(--space-5)}.resumen[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{display:flex;align-items:baseline;gap:var(--space-2);color:var(--texto-suave);font-size:var(--font-size-sm)}.numero[_ngcontent-%COMP%]{font-size:var(--font-size-2xl);font-weight:900;color:var(--guinda)}.filtros[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-4)}.resultados[_ngcontent-%COMP%]{display:grid;gap:var(--space-3)}.resultado[_ngcontent-%COMP%]{display:grid;grid-template-columns:32px 120px 1fr auto;gap:var(--space-4);align-items:start;border-left:5px solid var(--borde)}.resultado[data-nivel=alta][_ngcontent-%COMP%]{border-left-color:var(--guinda)}.resultado[data-nivel=media][_ngcontent-%COMP%]{border-left-color:var(--advertencia)}.similitud[_ngcontent-%COMP%]{display:grid;gap:var(--space-1)}.porcentaje[_ngcontent-%COMP%]{font-size:var(--font-size-2xl);font-weight:900;color:var(--negro-inst)}.barra-similitud[_ngcontent-%COMP%]{height:6px;border-radius:var(--radius-pill);background:#f1f1f3;overflow:hidden}.barra-similitud[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{height:100%;background:var(--texto-suave)}.resultado[data-nivel=alta][_ngcontent-%COMP%]   .barra-similitud[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{background:var(--guinda)}.resultado[data-nivel=media][_ngcontent-%COMP%]   .barra-similitud[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{background:var(--advertencia)}.nivel[_ngcontent-%COMP%]{font-size:var(--font-size-xs);color:var(--texto-suave);text-transform:capitalize}.contenido[_ngcontent-%COMP%]{min-width:0}.titulo[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-2)}.titulo[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:var(--font-size-md);color:var(--negro-inst)}.estatus-queja[_ngcontent-%COMP%]{padding:1px 8px;border-radius:var(--radius-pill);background:#f3f4f6;color:var(--texto-suave);font-size:var(--font-size-xs);font-weight:700}.meta[_ngcontent-%COMP%]{display:block;margin-top:2px;color:var(--texto-suave);font-size:var(--font-size-xs)}.contenido[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-2) 0;font-size:var(--font-size-sm);color:var(--texto)}.coincidencias[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;gap:var(--space-1)}.coincidencia[_ngcontent-%COMP%]{padding:2px 10px;border-radius:var(--radius-pill);background:#f3f4f6;color:var(--texto);font-size:var(--font-size-xs);font-weight:600}.coincidencia.fuerte[_ngcontent-%COMP%]{background:var(--guinda-suave);color:var(--guinda)}.coincidencia.por-verificar[_ngcontent-%COMP%]{background:#fff4e5;color:#7a4800}.acciones[_ngcontent-%COMP%]{display:grid;gap:var(--space-2);justify-items:end}.registrado[_ngcontent-%COMP%]{display:flex;align-items:center;gap:4px;color:var(--exito);font-size:var(--font-size-sm);font-weight:700}.vacio[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:center;gap:var(--space-3);color:var(--texto-suave)}.vacio[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{color:var(--exito)}.resultado.manual[_ngcontent-%COMP%]{grid-template-columns:32px 1fr auto}.resultado.seleccionado[_ngcontent-%COMP%]{outline:2px solid var(--guinda)}.marca[_ngcontent-%COMP%]{padding-top:4px}.ya-guardado[_ngcontent-%COMP%]{color:var(--exito)}.referencia[_ngcontent-%COMP%]{align-items:flex-start}.referencia-texto[_ngcontent-%COMP%]{flex:1;min-width:0}.guardados[_ngcontent-%COMP%]{margin-bottom:var(--space-4)}.guardados-titulo[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-2);color:var(--guinda)}.contador[_ngcontent-%COMP%]{min-width:24px;padding:0 8px;border-radius:var(--radius-pill);background:var(--guinda);color:#fff;font-size:var(--font-size-xs);font-weight:800;text-align:center}.lista-guardados[_ngcontent-%COMP%]{display:grid;gap:var(--space-2);margin-top:var(--space-3)}.guardado[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;gap:var(--space-3);padding:var(--space-2) var(--space-3);border:1px solid var(--borde);border-radius:10px}.guardado-datos[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;align-items:center;gap:4px var(--space-2);min-width:0}.guardado-asunto[_ngcontent-%COMP%]{color:var(--texto);font-size:var(--font-size-sm)}.guardado-datos[_ngcontent-%COMP%]   .meta[_ngcontent-%COMP%]{flex-basis:100%}.guardado-acciones[_ngcontent-%COMP%]{display:flex;flex-shrink:0}.ayuda[_ngcontent-%COMP%]{margin:var(--space-2) 0 0;color:var(--texto-suave);font-size:var(--font-size-sm)}.chip[_ngcontent-%COMP%]{padding:1px 8px;border-radius:var(--radius-pill);background:#f3f4f6;color:var(--texto-suave);font-size:var(--font-size-xs);font-weight:700}.chip.origen[_ngcontent-%COMP%]{background:#e0f2fe;color:#075985}.chip.origen.historico[_ngcontent-%COMP%]{background:#ede9fe;color:#5b21b6}.pestanas[_ngcontent-%COMP%]{margin-bottom:var(--space-4)}.tab-icon[_ngcontent-%COMP%]{margin-right:6px}.tab-contenido[_ngcontent-%COMP%]{padding-top:var(--space-4)}.form-manual[_ngcontent-%COMP%]{display:flex;flex-wrap:wrap;align-items:flex-start;gap:var(--space-3)}.form-manual[_ngcontent-%COMP%]   mat-form-field[_ngcontent-%COMP%]{flex:1 1 260px}.form-manual[_ngcontent-%COMP%]   button[type=submit][_ngcontent-%COMP%]{height:56px}.aviso[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:var(--space-2);padding:var(--space-3) var(--space-4);margin:var(--space-3) 0;border-radius:10px;background:#fff4e5;color:#7a4800;font-size:var(--font-size-sm)}.aviso.error[_ngcontent-%COMP%]{background:#fdecec;color:var(--peligro)}.motor-boton[_ngcontent-%COMP%]{margin-left:auto;flex-shrink:0}.titulo[_ngcontent-%COMP%]{flex-wrap:wrap}.page.con-seleccion[_ngcontent-%COMP%]{padding-bottom:88px}.barra-seleccion[_ngcontent-%COMP%]{position:sticky;bottom:var(--space-3);display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) var(--space-4);border-radius:14px;background:#fff;box-shadow:0 6px 24px #0f172a2e;border:1px solid var(--guinda);z-index:5}.barra-seleccion[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{flex:1}.barra-seleccion[_ngcontent-%COMP%] > mat-icon[_ngcontent-%COMP%]{color:var(--guinda)}@media(max-width:1000px){.page-header[_ngcontent-%COMP%]{flex-direction:column;align-items:flex-start}.resultado[_ngcontent-%COMP%], .resultado.manual[_ngcontent-%COMP%]{grid-template-columns:1fr}.referencia[_ngcontent-%COMP%]{flex-wrap:wrap}.acciones[_ngcontent-%COMP%]{justify-items:start}}.clicable[_ngcontent-%COMP%]{cursor:pointer}.titulo[_ngcontent-%COMP%]   strong.clicable[_ngcontent-%COMP%]:hover, .guardado-datos.clicable[_ngcontent-%COMP%]:hover   strong[_ngcontent-%COMP%]{color:var(--guinda);text-decoration:underline}"]})};function Yk(n,i){if(n&1&&(s(0,"p"),l(1," Esperando respuesta. Tiene hasta el "),s(2,"strong"),l(3),r(),l(4," para confirmar o cancelar con motivo. "),r()),n&2){let e=h(2);d(3),g(e.formatearFechaHora(e.cita.fechaLimiteRespuesta))}}function Xk(n,i){n&1&&(s(0,"p"),l(1,"Esperando respuesta (cita registrada antes del plazo de 48 h)."),r())}function Kk(n,i){if(n&1&&v(0,Yk,5,1,"p")(1,Xk,2,0,"p"),n&2){let e=h();y(e.cita.fechaLimiteRespuesta?0:1)}}function Zk(n,i){if(n&1&&(s(0,"p"),l(1," El quejoso "),s(2,"strong"),l(3,"no respondi\xF3"),r(),l(4),r()),n&2){let e=h();d(4),N(" dentro del plazo (venci\xF3 el ",e.formatearFechaHora(e.cita.fechaLimiteRespuesta),"). Reagenda o cancela la cita. ")}}function Jk(n,i){if(n&1&&l(0),n&2){let e=h(2);qe(" el ",e.formatearFechaHora(e.cita.fechaRespuestaQuejoso)," por ",e.quienRespondio,". ")}}function eM(n,i){if(n&1&&(s(0,"p"),l(1," Confirmada "),v(2,Jk,1,2),r()),n&2){let e=h();d(2),y(e.cita.fechaRespuestaQuejoso?2:-1)}}function tM(n,i){if(n&1&&l(0),n&2){let e=h(2);N(" el ",e.formatearFechaHora(e.cita.fechaRespuestaQuejoso)," ")}}function nM(n,i){if(n&1&&(s(0,"p"),l(1," El quejoso "),s(2,"strong"),l(3,"cancel\xF3"),r(),l(4," la cita "),v(5,tM,1,1),l(6),r(),s(7,"p",8)(8,"mat-icon"),l(9,"format_quote"),r(),l(10),r()),n&2){let e=h();d(5),y(e.cita.fechaRespuestaQuejoso?5:-1),d(),N(" (registrado por ",e.quienRespondio,"). Reagenda con una nueva fecha o cancela la cita. "),d(4),N(" ",e.cita.motivoCancelacionQuejoso)}}function iM(n,i){if(n&1&&l(0),n&2){let e=h(2);N(" Antes, el quejoso la hab\xEDa cancelado (registrado por ",e.quienRespondio,"): ")}}function aM(n,i){if(n&1&&l(0),n&2){let e=h(2);N(" El quejoso la hab\xEDa confirmado el ",e.formatearFechaHora(e.cita.fechaRespuestaQuejoso),". ")}}function oM(n,i){n&1&&l(0," El quejoso no hab\xEDa respondido. ")}function rM(n,i){if(n&1&&(s(0,"p",8)(1,"mat-icon"),l(2,"format_quote"),r(),l(3),r()),n&2){let e=h(2);d(3),N(" ",e.cita.motivoCancelacionQuejoso)}}function sM(n,i){if(n&1&&(s(0,"p"),l(1," Esta cita se "),s(2,"strong"),l(3,"reagend\xF3"),r(),l(4,"; la sustituye una cita nueva. "),v(5,iM,1,1)(6,aM,1,1)(7,oM,1,0),r(),v(8,rM,4,1,"p",8)),n&2){let e=h();d(5),y(e.cita.motivoCancelacionQuejoso?5:e.cita.fechaRespuestaQuejoso?6:7),d(3),y(e.cita.motivoCancelacionQuejoso?8:-1)}}function cM(n,i){n&1&&(s(0,"p"),l(1,"La cita fue cancelada por Primer Contacto."),r())}function lM(n,i){if(n&1){let e=T();s(0,"mat-form-field",9)(1,"mat-label"),l(2,"Motivo que dio el quejoso"),r(),s(3,"textarea",10),ge("ngModelChange",function(a){x(e);let o=h();return fe(o.motivoCancelacion,a)||(o.motivoCancelacion=a),C(a)}),r()(),s(4,"div",11)(5,"button",6),_("click",function(){x(e);let a=h();return C(a.registrandoCancelacion=!1)}),l(6,"Volver"),r(),s(7,"button",12),_("click",function(){x(e);let a=h();return C(a.registrarCancelacionQuejoso())}),l(8," Registrar cancelaci\xF3n "),r()()}if(n&2){let e=h();d(3),he("ngModel",e.motivoCancelacion),d(4),P("disabled",!e.motivoCancelacion.trim())}}function dM(n,i){if(n&1){let e=T();s(0,"button",16),_("click",function(){x(e);let a=h(2);return C(a.confirmar())}),s(1,"mat-icon"),l(2,"event_available"),r(),l(3," Registrar confirmaci\xF3n "),r()}}function uM(n,i){if(n&1){let e=T();s(0,"button",6),_("click",function(){x(e);let a=h(2);return C(a.registrandoCancelacion=!0)}),s(1,"mat-icon"),l(2,"person_off"),r(),l(3," El quejoso cancel\xF3 "),r()}}function mM(n,i){if(n&1){let e=T();v(0,dM,4,0,"button",13),v(1,uM,4,0,"button",14),s(2,"button",6),_("click",function(){x(e);let a=h();return C(a.reagendar())}),s(3,"mat-icon"),l(4,"event_repeat"),r(),l(5," Reagendar "),r(),s(6,"button",15),_("click",function(){x(e);let a=h();return C(a.cancelar())}),s(7,"mat-icon"),l(8,"event_busy"),r(),l(9," Cancelar cita "),r()}if(n&2){let e=h();y(e.confirmada?-1:0),d(),y(e.pendienteDeRespuesta?1:-1)}}var El=class n{constructor(i,e,t){this.cita=i;this.dialogRef=e;this.router=t}cita;dialogRef;router;registrandoCancelacion=!1;motivoCancelacion="";formatearFechaHora=Hn;get cancelada(){return this.cita.estatusCodigo==="CANCELADA"||this.cita.estatusCodigo==="REAGENDADA"}get confirmada(){return this.cita.estatusCodigo==="CONFIRMADA"}get pendienteDeRespuesta(){return this.cita.estatusCodigo==="PROGRAMADA"||this.cita.estatusCodigo==="SIN_RESPUESTA"}get canceladaPorQuejoso(){return this.cita.estatusCodigo==="CANCELADA_QUEJOSO"}get quienRespondio(){return this.cita.respuestaRegistradaPor==="QUEJOSO"?"el quejoso, desde su panel":"Primer Contacto, a nombre del quejoso"}cerrar(){this.dialogRef.close()}verExpediente(){this.dialogRef.close(),this.router.navigate(["/expediente",this.cita.folio])}confirmar(){this.dialogRef.close({accion:"confirmar",cita:this.cita})}reagendar(){this.dialogRef.close({accion:"reagendar",cita:this.cita})}cancelar(){this.dialogRef.close({accion:"cancelar",cita:this.cita})}registrarCancelacionQuejoso(){this.motivoCancelacion.trim()&&this.dialogRef.close({accion:"cancelacion-quejoso",cita:this.cita,motivo:this.motivoCancelacion.trim()})}static \u0275fac=function(e){return new(e||n)(S(In),S(Mn),S(We))};static \u0275cmp=A({type:n,selectors:[["app-cita-detalle-dialog"]],decls:72,vars:16,consts:[["mat-dialog-title",""],[1,"detail-grid"],[1,"section"],[1,"section","respuesta"],[1,"section","muted"],["align","end"],["mat-stroked-button","",3,"click"],["mat-flat-button","",1,"primary-btn",3,"click"],[1,"motivo-quejoso"],["appearance","outline",1,"campo-motivo"],["matInput","","rows","3","maxlength","1000",3,"ngModelChange","ngModel"],[1,"acciones-motivo"],["mat-flat-button","",1,"primary-btn",3,"click","disabled"],["mat-stroked-button","",1,"success-outline"],["mat-stroked-button",""],["mat-stroked-button","",1,"danger-outline",3,"click"],["mat-stroked-button","",1,"success-outline",3,"click"]],template:function(e,t){if(e&1&&(s(0,"h2",0),l(1,"Detalle de la cita"),r(),s(2,"mat-dialog-content")(3,"div",1)(4,"div")(5,"span"),l(6,"Folio"),r(),s(7,"strong"),l(8),r()(),s(9,"div")(10,"span"),l(11,"Quejoso"),r(),s(12,"strong"),l(13),r()(),s(14,"div")(15,"span"),l(16,"Fecha"),r(),s(17,"strong"),l(18),r()(),s(19,"div")(20,"span"),l(21,"Hora"),r(),s(22,"strong"),l(23),r()(),s(24,"div")(25,"span"),l(26,"Tipo"),r(),s(27,"strong"),l(28),r()(),s(29,"div")(30,"span"),l(31,"Estatus"),r(),s(32,"mat-chip"),l(33),r()(),s(34,"div")(35,"span"),l(36,"Agendada por"),r(),s(37,"strong"),l(38),r()(),s(39,"div")(40,"span"),l(41,"\xDAltimo movimiento"),r(),s(42,"strong"),l(43),r()()(),s(44,"div",2)(45,"span"),l(46,"Motivo"),r(),s(47,"p"),l(48),r()(),s(49,"div",3)(50,"span"),l(51,"Respuesta del quejoso"),r(),v(52,Kk,2,1)(53,Zk,5,1,"p")(54,eM,3,1,"p")(55,nM,11,3)(56,sM,9,2)(57,cM,2,0,"p"),v(58,lM,9,2),r(),s(59,"div",4)(60,"span"),l(61,"Notificaci\xF3n"),r(),s(62,"p"),l(63," Al agendar o reagendar, el quejoso recibe un aviso en su panel y un correo con los datos de la cita y el plazo de 48 horas para confirmarla o cancelarla. "),r()()(),s(64,"mat-dialog-actions",5)(65,"button",6),_("click",function(){return t.verExpediente()}),s(66,"mat-icon"),l(67,"description"),r(),l(68," Ver expediente "),r(),v(69,mM,10,2),s(70,"button",7),_("click",function(){return t.cerrar()}),l(71," Cerrar "),r()()),e&2){let a;d(8),g(t.cita.folio),d(5),g(t.cita.quejoso),d(5),g(t.cita.fecha),d(5),g(t.cita.hora),d(5),g(t.cita.tipo),d(5),g(t.cita.estatus),d(5),g(t.cita.analistaNombre||"\u2014"),d(5),g(t.cita.actualizadoPorNombre||"\u2014"),d(5),g(t.cita.motivo),d(),k("alerta",t.cita.estatusCodigo==="SIN_RESPUESTA"||t.canceladaPorQuejoso)("ok",t.confirmada),d(3),y((a=t.cita.estatusCodigo)==="PROGRAMADA"?52:a==="SIN_RESPUESTA"?53:a==="CONFIRMADA"?54:a==="CANCELADA_QUEJOSO"?55:a==="REAGENDADA"?56:57),d(6),y(t.registrandoCancelacion?58:-1),d(11),y(!t.cancelada&&!t.registrandoCancelacion?69:-1)}},dependencies:[Ot,ft,Tt,sa,St,Nt,qn,Qn,Wn,Ge,Je,ze,Ve,Un,Ti,kt,ln,Jt,mn,Gn],styles:[".detail-grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px}.detail-grid[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{display:grid;gap:4px;padding:12px;border:1px solid var(--borde);border-radius:12px;background:#fbfbfc}span[_ngcontent-%COMP%]{color:var(--texto-suave);font-size:12px;font-weight:900;text-transform:uppercase}strong[_ngcontent-%COMP%]{color:var(--negro-inst)}.section[_ngcontent-%COMP%]{border-top:1px solid var(--borde);padding-top:14px;margin-top:14px}.section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:6px 0 0;color:var(--negro-inst)}.muted[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:var(--texto-suave)}.primary-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important;border-radius:999px!important;font-weight:800}.danger-outline[_ngcontent-%COMP%]{color:var(--peligro)!important;border-color:var(--peligro)!important}.success-outline[_ngcontent-%COMP%]{color:var(--exito)!important;border-color:var(--exito)!important}.respuesta[_ngcontent-%COMP%]{padding:12px 14px;border:1px solid var(--borde);border-radius:12px;background:#fbfbfc}.respuesta.alerta[_ngcontent-%COMP%]{border-color:#f4c27a;background:#fff8ed}.respuesta.ok[_ngcontent-%COMP%]{border-color:#b7e4c7;background:#f1fbf4}.motivo-quejoso[_ngcontent-%COMP%]{display:flex;gap:6px;font-style:italic}.motivo-quejoso[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{color:var(--guinda);flex-shrink:0}.campo-motivo[_ngcontent-%COMP%]{width:100%;margin-top:10px}.acciones-motivo[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;gap:8px}"]})};var Em=(n,i)=>i.id,w0=(n,i)=>i.clave;function pM(n,i){if(n&1&&(s(0,"span",17),l(1),r()),n&2){let e=i.$implicit;d(),g(e)}}function hM(n,i){n&1&&H(0,"span",39)}function fM(n,i){n&1&&H(0,"i",42)}function gM(n,i){if(n&1){let e=T();s(0,"button",41),_("click",function(){x(e);let a=h().$implicit,o=h(2);return C(o.diaSel=o.isoDe(a))}),l(1),v(2,fM,1,0,"i",42),r()}if(n&2){let e=h().$implicit,t=h(2);k("sel",t.isoDe(e)===t.diaSel)("hoy",t.isoDe(e)===t.hoyIso),d(),N(" ",e," "),d(),y(t.tieneCitas(e)?2:-1)}}function _M(n,i){if(n&1&&v(0,hM,1,0,"span",39)(1,gM,3,6,"button",40),n&2){let e=i.$implicit;y(e===null?0:1)}}function bM(n,i){if(n&1){let e=T();s(0,"li")(1,"b",43),l(2),r(),s(3,"span",44),l(4),r(),s(5,"span",45)(6,"b"),l(7),r(),s(8,"small"),l(9),r()(),s(10,"span"),l(11),r(),s(12,"button",15),_("click",function(){let a=x(e).$implicit,o=h(2);return C(o.abrirDetalle(a))}),s(13,"mat-icon"),l(14,"visibility"),r(),l(15," Detalles"),r()()}if(n&2){let e=i.$implicit,t=h(2);k("apagada",!t.activa(e)),d(2),N("",e.hora," hrs"),d(2),g(e.folio),d(3),g(e.quejoso||"\u2014"),d(2),qe("",t.etiquetaCategoria(e.categoria)," ",e.tipo.toLowerCase()),d(),ve("pc-chip "+e.estatusCodigo),d(),g(e.estatus)}}function vM(n,i){if(n&1){let e=T();s(0,"button",24),_("click",function(){x(e);let a=h(3);return C(a.nuevaCita())}),l(1,"Agendar una"),r()}}function yM(n,i){if(n&1&&(s(0,"li",21),l(1,"No hay citas este d\xEDa. "),v(2,vM,2,0,"button",46),r()),n&2){let e=h(2);d(2),y(e.diaSel>=e.hoyIso?2:-1)}}function xM(n,i){if(n&1){let e=T();s(0,"li")(1,"span",47)(2,"b"),l(3),r(),s(4,"small"),l(5),r()(),s(6,"span",48)(7,"b"),l(8),r(),s(9,"span"),l(10),r(),s(11,"small"),l(12),r(),s(13,"small"),l(14),r()(),s(15,"span",49)(16,"span"),l(17),r(),s(18,"button",15),_("click",function(){let a=x(e).$implicit,o=h(2);return C(o.abrirDetalle(a))}),s(19,"mat-icon"),l(20,"visibility"),r(),l(21," Detalles"),r()()()}if(n&2){let e=i.$implicit,t=h(2);d(3),g(t.diaCorto(e)),d(2),g(t.mesCorto(e)),d(3),N("",e.hora," hrs"),d(2),g(e.folio),d(2),g(e.quejoso),d(2),g(e.tipo),d(2),ve("pc-chip "+e.estatusCodigo),d(),g(e.estatus)}}function CM(n,i){n&1&&(s(0,"li",21),l(1,"No tienes citas pr\xF3ximas."),r())}function wM(n,i){if(n&1&&(s(0,"option",35),l(1),r()),n&2){let e=i.$implicit;P("value",e.clave),d(),g(e.etiqueta)}}function DM(n,i){if(n&1){let e=T();s(0,"div",8)(1,"div",10)(2,"div",11)(3,"h3"),l(4,"Calendario Institucional"),r(),s(5,"div",12)(6,"button",13),_("click",function(){x(e);let a=h();return C(a.mover(-1))}),s(7,"mat-icon"),l(8,"chevron_left"),r()(),s(9,"b"),l(10),r(),s(11,"button",14),_("click",function(){x(e);let a=h();return C(a.mover(1))}),s(12,"mat-icon"),l(13,"chevron_right"),r()(),s(14,"button",15),_("click",function(){x(e);let a=h();return C(a.irAHoy())}),l(15,"Hoy"),r()()(),s(16,"div",16),te(17,pM,2,1,"span",17,Ke),te(19,_M,2,1,null,null,Fn),r(),s(21,"h4",18),l(22),r(),s(23,"ul",19),te(24,bM,16,10,"li",20,Em,!1,yM,3,1,"li",21),r()(),s(27,"div",22)(28,"div",10)(29,"div",23)(30,"h3"),l(31,"Mis pr\xF3ximas citas"),r(),s(32,"button",24),_("click",function(){x(e);let a=h();return C(a.cambiarVista("lista"))}),l(33,"Ver todas "),s(34,"mat-icon"),l(35,"arrow_forward"),r()()(),s(36,"ul",25),te(37,xM,22,9,"li",null,Em,!1,CM,2,0,"li",21),r()(),s(40,"div",10)(41,"h3",26),l(42,"Filtrar citas"),r(),s(43,"div",27)(44,"label",28),l(45,"Estado "),s(46,"select",29),ge("ngModelChange",function(a){x(e);let o=h();return fe(o.filtro.estado,a)||(o.filtro.estado=a),C(a)}),s(47,"option",30),l(48,"Todas"),r(),s(49,"option",31),l(50,"Programada"),r(),s(51,"option",32),l(52,"Confirmada"),r(),s(53,"option",33),l(54,"Sin respuesta"),r(),s(55,"option",34),l(56,"Cancelada"),r()()(),s(57,"label",28),l(58,"Tipo de cita "),s(59,"select",29),ge("ngModelChange",function(a){x(e);let o=h();return fe(o.filtro.categoria,a)||(o.filtro.categoria=a),C(a)}),s(60,"option",30),l(61,"Todos"),r(),te(62,wM,2,2,"option",35,w0),r()(),s(64,"div",36)(65,"label",28),l(66,"Fecha de inicio "),s(67,"input",37),ge("ngModelChange",function(a){x(e);let o=h();return fe(o.filtro.desde,a)||(o.filtro.desde=a),C(a)}),r()(),s(68,"label",28),l(69,"Fecha de fin "),s(70,"input",37),ge("ngModelChange",function(a){x(e);let o=h();return fe(o.filtro.hasta,a)||(o.filtro.hasta=a),C(a)}),r()()(),s(71,"button",38),_("click",function(){x(e);let a=h();return C(a.aplicarFiltros())}),s(72,"mat-icon"),l(73,"filter_alt"),r(),l(74," Aplicar filtros"),r()()()()()}if(n&2){let e=h();d(10),g(e.tituloMes),d(7),ne(e.diasSemana),d(2),ne(e.celdas),d(3),N("Citas del ",e.tituloDia),d(2),ne(e.citasDelDia),d(13),ne(e.proximas.slice(0,3)),d(9),he("ngModel",e.filtro.estado),d(13),he("ngModel",e.filtro.categoria),d(3),ne(e.categorias),d(5),he("ngModel",e.filtro.desde),d(3),he("ngModel",e.filtro.hasta)}}function EM(n,i){if(n&1&&(s(0,"option",35),l(1),r()),n&2){let e=i.$implicit;P("value",e.clave),d(),g(e.etiqueta)}}function SM(n,i){if(n&1){let e=T();s(0,"button",57),_("click",function(){x(e);let a=h(2).$implicit,o=h(2);return C(o.ejecutar("confirmar",a))}),l(1,"Confirmar asistencia"),r()}}function kM(n,i){if(n&1){let e=T();s(0,"button",57),_("click",function(){x(e);let a=h(2).$implicit,o=h(2);return C(o.ejecutar("reagendar",a))}),l(1,"Reagendar"),r(),s(2,"button",66),_("click",function(){x(e);let a=h(2).$implicit,o=h(2);return C(o.ejecutar("cancelar",a))}),l(3,"Cancelar cita"),r()}}function MM(n,i){if(n&1){let e=T();s(0,"span",64),_("click",function(a){return a.stopPropagation()}),v(1,SM,2,0,"button",65),v(2,kM,4,0),s(3,"button",57),_("click",function(){x(e);let a=h().$implicit,o=h(2);return C(o.abrirDetalle(a))}),l(4,"Ver detalle y expediente"),r()()}if(n&2){let e=h().$implicit,t=h(2);d(),y(t.puedeConfirmar(e)?1:-1),d(),y(t.activa(e)?2:-1)}}function IM(n,i){if(n&1){let e=T();s(0,"tr")(1,"td"),l(2),r(),s(3,"td"),l(4),r(),s(5,"td",59),l(6),r(),s(7,"td"),l(8),r(),s(9,"td"),l(10),r(),s(11,"td"),l(12),r(),s(13,"td")(14,"span"),l(15),r()(),s(16,"td",60)(17,"button",15),_("click",function(){let a=x(e).$implicit,o=h(2);return C(o.abrirDetalle(a))}),s(18,"mat-icon"),l(19,"visibility"),r(),l(20," Detalles"),r(),s(21,"span",61)(22,"button",62),_("click",function(a){let o=x(e).$implicit,c=h(2);return C(c.alternarMenu(o.id,a))}),s(23,"mat-icon"),l(24,"more_vert"),r()(),v(25,MM,5,2,"span",63),r()()()}if(n&2){let e=i.$implicit,t=h(2);d(2),g(e.fecha),d(2),g(e.hora),d(2),g(e.folio),d(2),g(e.quejoso||"\u2014"),d(2),g(t.etiquetaCategoria(e.categoria)),d(2),g(e.tipo),d(2),ve("pc-chip "+e.estatusCodigo),d(),g(e.estatus),d(10),y(t.menuAbierto===e.id?25:-1)}}function AM(n,i){if(n&1&&(s(0,"tr")(1,"td",67),l(2),r()()),n&2){let e=h(2);d(2),g(e.cargandoLista?"Cargando\u2026":"No hay citas con estos filtros.")}}function RM(n,i){if(n&1){let e=T();s(0,"button",57),_("click",function(){let a=x(e).$implicit,o=h(3);return C(o.pagina=a)}),l(1),r()}if(n&2){let e=i.$implicit,t=h(3);k("actual",e===t.pagina),d(),g(e+1)}}function TM(n,i){if(n&1){let e=T();s(0,"nav")(1,"button",68),_("click",function(){x(e);let a=h(2);return C(a.pagina=a.pagina-1)}),s(2,"mat-icon"),l(3,"chevron_left"),r()(),te(4,RM,2,3,"button",69,Ke),s(6,"button",70),_("click",function(){x(e);let a=h(2);return C(a.pagina=a.pagina+1)}),s(7,"mat-icon"),l(8,"chevron_right"),r()()()}if(n&2){let e=h(2);d(),P("disabled",e.pagina===0),d(3),ne(e.paginas),d(2),P("disabled",e.pagina>=e.totalPaginas-1)}}function OM(n,i){if(n&1){let e=T();s(0,"div",50)(1,"label",28),l(2,"Estado "),s(3,"select",29),ge("ngModelChange",function(a){x(e);let o=h();return fe(o.filtro.estado,a)||(o.filtro.estado=a),C(a)}),_("ngModelChange",function(){x(e);let a=h();return C(a.pagina=0)}),s(4,"option",30),l(5,"Todas"),r(),s(6,"option",31),l(7,"Programada"),r(),s(8,"option",32),l(9,"Confirmada"),r(),s(10,"option",33),l(11,"Sin respuesta"),r(),s(12,"option",34),l(13,"Cancelada"),r()()(),s(14,"label",28),l(15,"Tipo de cita "),s(16,"select",29),ge("ngModelChange",function(a){x(e);let o=h();return fe(o.filtro.categoria,a)||(o.filtro.categoria=a),C(a)}),_("ngModelChange",function(){x(e);let a=h();return C(a.pagina=0)}),s(17,"option",30),l(18,"Todos"),r(),te(19,EM,2,2,"option",35,w0),r()(),s(21,"label",28),l(22,"Modalidad "),s(23,"select",29),ge("ngModelChange",function(a){x(e);let o=h();return fe(o.filtro.modalidad,a)||(o.filtro.modalidad=a),C(a)}),_("ngModelChange",function(){x(e);let a=h();return C(a.pagina=0)}),s(24,"option",30),l(25,"Todas"),r(),s(26,"option",51),l(27,"Presencial"),r(),s(28,"option",52),l(29,"Virtual"),r()()(),s(30,"label",28),l(31,"Fecha de inicio "),s(32,"input",37),ge("ngModelChange",function(a){x(e);let o=h();return fe(o.filtro.desde,a)||(o.filtro.desde=a),C(a)}),r()(),s(33,"label",28),l(34,"Fecha de fin "),s(35,"input",37),ge("ngModelChange",function(a){x(e);let o=h();return fe(o.filtro.hasta,a)||(o.filtro.hasta=a),C(a)}),r()(),s(36,"button",53),_("click",function(){x(e);let a=h();return C(a.aplicarFiltros())}),s(37,"mat-icon"),l(38,"filter_alt"),r(),l(39," Aplicar filtros"),r()(),s(40,"div",10)(41,"div",23)(42,"h3")(43,"mat-icon"),l(44,"description"),r(),l(45," Listado de citas"),r(),s(46,"button",54),_("click",function(){x(e);let a=h();return C(a.exportar())}),s(47,"mat-icon"),l(48,"download"),r(),l(49," Exportar"),r()(),s(50,"div",55)(51,"table",56)(52,"thead")(53,"tr")(54,"th")(55,"button",57),_("click",function(){x(e);let a=h();return C(a.ordenarPor("fecha"))}),l(56,"Fecha "),s(57,"mat-icon"),l(58),r()()(),s(59,"th")(60,"button",57),_("click",function(){x(e);let a=h();return C(a.ordenarPor("hora"))}),l(61,"Hora "),s(62,"mat-icon"),l(63),r()()(),s(64,"th")(65,"button",57),_("click",function(){x(e);let a=h();return C(a.ordenarPor("folio"))}),l(66,"Expediente "),s(67,"mat-icon"),l(68),r()()(),s(69,"th")(70,"button",57),_("click",function(){x(e);let a=h();return C(a.ordenarPor("quejoso"))}),l(71,"Persona citada "),s(72,"mat-icon"),l(73),r()()(),s(74,"th")(75,"button",57),_("click",function(){x(e);let a=h();return C(a.ordenarPor("categoria"))}),l(76,"Tipo de cita "),s(77,"mat-icon"),l(78),r()()(),s(79,"th")(80,"button",57),_("click",function(){x(e);let a=h();return C(a.ordenarPor("tipo"))}),l(81,"Modalidad "),s(82,"mat-icon"),l(83),r()()(),s(84,"th")(85,"button",57),_("click",function(){x(e);let a=h();return C(a.ordenarPor("estatus"))}),l(86,"Estado "),s(87,"mat-icon"),l(88),r()()(),s(89,"th"),l(90,"Acciones"),r()()(),s(91,"tbody"),te(92,IM,26,10,"tr",null,Em,!1,AM,3,1,"tr"),r()()(),s(95,"div",58)(96,"span"),l(97),r(),v(98,TM,9,2,"nav"),r()()}if(n&2){let e=h();d(3),he("ngModel",e.filtro.estado),d(13),he("ngModel",e.filtro.categoria),d(3),ne(e.categorias),d(4),he("ngModel",e.filtro.modalidad),d(9),he("ngModel",e.filtro.desde),d(3),he("ngModel",e.filtro.hasta),d(11),P("disabled",!e.filtradas.length),d(4),k("recargando",e.cargandoLista),d(8),g(e.flecha("fecha")),d(5),g(e.flecha("hora")),d(5),g(e.flecha("folio")),d(5),g(e.flecha("quejoso")),d(5),g(e.flecha("categoria")),d(5),g(e.flecha("tipo")),d(5),g(e.flecha("estatus")),d(4),ne(e.visibles),d(5),g(e.rango),d(),y(e.totalPaginas>1?98:-1)}}function PM(n,i){if(n&1){let e=T();s(0,"app-nueva-cita",71),_("guardada",function(){x(e);let a=h();return C(a.citaGuardada())})("cerrar",function(){x(e);let a=h();return a.mostrarNueva=!1,C(a.citaReagendar=void 0)}),r()}if(n&2){let e=h();P("folio",e.folioNueva)("cita",e.citaReagendar)("fechaInicial",e.fechaParaNueva)}}var Dm=["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"],Sl=10,Il=class n{constructor(i,e,t,a){this.agenda=i;this.dialog=e;this.snackBar=t;this.cdr=a;let o=history.state?.folio;o&&(this.folioNueva=o,this.mostrarNueva=!0)}agenda;dialog;snackBar;cdr;diasSemana=["Dom","Lun","Mar","Mi\xE9","Jue","Vie","S\xE1b"];categorias=Yr;etiquetaCategoria=_a;vista="calendario";anio=new Date().getFullYear();mes=new Date().getMonth();diaSel=Rn(new Date);citasMes=[];proximas=[];citasVentana=[];filtro={estado:"",categoria:"",modalidad:"",desde:"",hasta:""};citasLista=[];cargandoLista=!1;orden={campo:"fecha",asc:!0};pagina=0;menuAbierto=null;mostrarNueva=!1;folioNueva="";citaReagendar;ngOnInit(){this.recargarTodo()}cerrarMenu(){this.menuAbierto=null}recargarTodo(){this.cargarMes(),this.cargarVentana(),this.agenda.obtenerMisProximasCitas().subscribe({next:i=>{this.proximas=i,this.cdr.detectChanges()}}),this.vista==="lista"&&this.cargarLista()}cargarVentana(){let i=new Date;this.agenda.obtenerRango(Rn(kl(i,-30)),Rn(kl(i,90))).subscribe({next:e=>{this.citasVentana=e,this.cdr.detectChanges()}})}get hoyIso(){return Rn(new Date)}get kpiHoy(){return this.citasVentana.filter(i=>Ml(i.fecha)===this.hoyIso&&ga(i)).length}get kpiProximas(){let i=Date.now();return this.citasVentana.filter(e=>ga(e)&&C0(e)>i).length}get kpiConfirmadas(){let i=Date.now();return this.citasVentana.filter(e=>e.estatusCodigo==="CONFIRMADA"&&C0(e)>i).length}get kpiCanceladas(){return this.citasVentana.filter(i=>i.estatusCodigo==="CANCELADA"||i.estatusCodigo==="CANCELADA_QUEJOSO").length}get tituloMes(){let i=Dm[this.mes];return`${i.charAt(0).toUpperCase()+i.slice(1)} ${this.anio}`}get celdas(){let i=new Date(this.anio,this.mes,1).getDay(),e=new Date(this.anio,this.mes+1,0).getDate(),t=[...Array(i).fill(null),...Array.from({length:e},(a,o)=>o+1)];for(;t.length%7;)t.push(null);return t}isoDe(i){return Rn(new Date(this.anio,this.mes,i))}citasDe(i){return this.citasMes.filter(e=>Ml(e.fecha)===i)}tieneCitas(i){return this.citasDe(this.isoDe(i)).some(e=>ga(e))}get citasDelDia(){return this.citasDe(this.diaSel)}get tituloDia(){let[i,e,t]=this.diaSel.split("-").map(Number);return`${t} de ${Dm[e-1]} de ${i}`}mover(i){let e=new Date(this.anio,this.mes+i,1);this.anio=e.getFullYear(),this.mes=e.getMonth(),this.diaSel=Rn(e),this.cargarMes()}irAHoy(){let i=new Date;this.anio=i.getFullYear(),this.mes=i.getMonth(),this.diaSel=Rn(i),this.cargarMes()}cargarMes(){let i=Rn(new Date(this.anio,this.mes,1)),e=Rn(new Date(this.anio,this.mes+1,0));this.agenda.obtenerRango(i,e).subscribe({next:t=>{this.citasMes=t,this.cdr.detectChanges()},error:()=>this.snackBar.open("No fue posible cargar la agenda del mes.","Cerrar",{duration:3e3})})}cambiarVista(i){this.vista=i,i==="lista"&&this.cargarLista()}aplicarFiltros(){if(this.filtro.desde&&this.filtro.hasta&&this.filtro.hasta<this.filtro.desde){this.snackBar.open("La fecha de fin no puede ser anterior a la de inicio.","Cerrar",{duration:3e3});return}this.pagina=0,this.cambiarVista("lista")}limpiarFiltros(){this.filtro={estado:"",categoria:"",modalidad:"",desde:"",hasta:""},this.aplicarFiltros()}cargarLista(){let i=new Date,e=this.filtro.desde||Rn(kl(i,-30)),t=this.filtro.hasta||Rn(kl(new Date(e+"T00:00:00"),120));this.cargandoLista=!0,this.agenda.obtenerRango(e,t).subscribe({next:a=>{this.citasLista=a,this.cargandoLista=!1,this.cdr.detectChanges()},error:a=>{this.cargandoLista=!1,this.snackBar.open(Ne(a,"No fue posible cargar las citas."),"Cerrar",{duration:3500}),this.cdr.detectChanges()}})}get filtradas(){let i=this.filtro,e=this.citasLista.filter(a=>(!i.estado||(i.estado==="CANCELADA"?a.estatusCodigo?.startsWith("CANCELADA"):a.estatusCodigo===i.estado))&&(!i.categoria||(a.categoria??"COMPARECENCIA")===i.categoria)&&(!i.modalidad||a.tipo.toUpperCase()===i.modalidad)),t=a=>{switch(this.orden.campo){case"fecha":return Ml(a.fecha)+a.hora;case"hora":return a.hora;case"folio":return a.folio;case"quejoso":return a.quejoso??"";case"categoria":return _a(a.categoria);case"tipo":return a.tipo;default:return a.estatus}};return[...e].sort((a,o)=>t(a).localeCompare(t(o))*(this.orden.asc?1:-1))}get visibles(){return this.filtradas.slice(this.pagina*Sl,(this.pagina+1)*Sl)}get totalPaginas(){return Math.max(1,Math.ceil(this.filtradas.length/Sl))}get paginas(){return Array.from({length:this.totalPaginas},(i,e)=>e)}get rango(){let i=this.filtradas.length;if(!i)return"Sin citas";let e=this.pagina*Sl+1;return`Mostrando ${e} a ${e+this.visibles.length-1} de ${i} citas`}ordenarPor(i){this.orden={campo:i,asc:this.orden.campo===i?!this.orden.asc:!0}}flecha(i){return this.orden.campo!==i?"unfold_more":this.orden.asc?"expand_less":"expand_more"}exportar(){let i=this.filtradas,e=c=>`"${String(c??"").replace(/"/g,'""').replace(/\r?\n/g," ")}"`,t=[["Fecha","Hora","Expediente","Persona citada","Tipo de cita","Modalidad","Estado","Motivo","Agend\xF3"]].concat(i.map(c=>[c.fecha,c.hora,c.folio,c.quejoso,_a(c.categoria),c.tipo,c.estatus,c.motivo,c.analistaNombre??""])).map(c=>c.map(e).join(";")).join(`\r
`),a=URL.createObjectURL(new Blob(["\uFEFF"+t],{type:"text/csv;charset=utf-8"})),o=document.createElement("a");o.href=a,o.download=`citas-${this.hoyIso}.csv`,o.click(),setTimeout(()=>URL.revokeObjectURL(a),5e3)}alternarMenu(i,e){e.stopPropagation(),this.menuAbierto=this.menuAbierto===i?null:i??null}nuevaCita(){this.citaReagendar=void 0,this.folioNueva="",this.mostrarNueva=!0}get fechaParaNueva(){return this.diaSel>=this.hoyIso?this.diaSel:""}citaGuardada(){this.mostrarNueva=!1,this.citaReagendar=void 0,this.recargarTodo()}abrirDetalle(i){this.menuAbierto=null,this.dialog.open(El,{width:"720px",data:i}).afterClosed().subscribe(e=>{e&&this.ejecutar(e.accion,e.cita,e.motivo)})}ejecutar(i,e,t){if(this.menuAbierto=null,!e.id)return;if(i==="reagendar"){this.citaReagendar=e,this.mostrarNueva=!0;return}let a,o;if(i==="confirmar")a=this.agenda.confirmarCita(e.id),o="Cita confirmada. Se avis\xF3 al quejoso.";else if(i==="cancelacion-quejoso"&&t)a=this.agenda.registrarCancelacionQuejoso(e.id,t),o="Cancelaci\xF3n del quejoso registrada. Reagenda o cancela la cita.";else if(i==="cancelar"){if(!confirm("\xBFCancelar la cita? Se le avisar\xE1 al quejoso."))return;a=this.agenda.cancelarCita(e.id),o="Cita cancelada. Se avis\xF3 al quejoso."}else return;a.subscribe({next:()=>{this.snackBar.open(o,"Cerrar",{duration:3e3}),this.recargarTodo()},error:c=>this.snackBar.open(Ne(c,"No fue posible completar la acci\xF3n."),"Cerrar",{duration:3500})})}puedeConfirmar(i){return i.estatusCodigo==="PROGRAMADA"||i.estatusCodigo==="SIN_RESPUESTA"}activa(i){return ga(i)||i.estatusCodigo==="CANCELADA_QUEJOSO"}diaCorto(i){return i.fecha.slice(0,2)}mesCorto(i){return Dm[Number(i.fecha.slice(3,5))-1]?.slice(0,3).toUpperCase()??""}static \u0275fac=function(e){return new(e||n)(S($n),S(An),S(Mt),S(Z))};static \u0275cmp=A({type:n,selectors:[["app-agenda"]],hostBindings:function(e,t){e&1&&_("click",function(){return t.cerrarMenu()},ns)},decls:60,vars:10,consts:[[1,"page","ag"],[1,"ag-cabeza"],["type","button",1,"pc-btn","grande",3,"click"],[1,"pc-kpis"],[1,"pc-kpi"],[1,"icono"],["role","tablist",1,"ag-tabs"],["type","button","role","tab",3,"click"],[1,"ag-rejilla"],[3,"folio","cita","fechaInicial"],[1,"pc-card"],[1,"ag-cal-cabeza"],[1,"ag-nav"],["type","button","aria-label","Mes anterior",1,"ico",3,"click"],["type","button","aria-label","Mes siguiente",1,"ico",3,"click"],["type","button",1,"pc-btn-borde","chico",3,"click"],[1,"ag-cal"],[1,"ag-sem"],[1,"ag-dia-titulo"],[1,"ag-dia-lista"],[3,"apagada"],[1,"vacio"],[1,"col"],[1,"pc-card-cabeza"],["type","button",1,"pc-link",3,"click"],[1,"ag-proximas"],[1,"ag-h3"],[1,"ag-filtros-lado"],[1,"pc-campo"],[3,"ngModelChange","ngModel"],["value",""],["value","PROGRAMADA"],["value","CONFIRMADA"],["value","SIN_RESPUESTA"],["value","CANCELADA"],[3,"value"],[1,"dos"],["type","date",3,"ngModelChange","ngModel"],["type","button",1,"pc-btn-borde","ancho",3,"click"],[1,"ag-dia","vacio"],["type","button",1,"ag-dia",3,"sel","hoy"],["type","button",1,"ag-dia",3,"click"],[1,"punto"],[1,"hora"],[1,"folio"],[1,"quien"],["type","button",1,"pc-link"],[1,"fecha"],[1,"datos"],[1,"der"],[1,"pc-card","ag-filtros"],["value","PRESENCIAL"],["value","VIRTUAL"],["type","button",1,"pc-btn-borde",3,"click"],["type","button",1,"pc-btn-borde","chico",3,"click","disabled"],[1,"ag-tabla-env"],[1,"ag-tabla"],["type","button",3,"click"],[1,"ag-paginado"],[1,"fuerte"],[1,"acciones"],[1,"menu-fila"],["type","button","aria-label","M\xE1s acciones",1,"ico",3,"click"],[1,"menu"],[1,"menu",3,"click"],["type","button"],["type","button",1,"peligro",3,"click"],["colspan","8",1,"vacio"],["type","button","aria-label","Anterior",3,"click","disabled"],["type","button",3,"actual"],["type","button","aria-label","Siguiente",3,"click","disabled"],[3,"guardada","cerrar","folio","cita","fechaInicial"]],template:function(e,t){e&1&&(s(0,"section",0)(1,"div",1)(2,"div")(3,"h2"),l(4,"Agenda de Citas"),r(),s(5,"p"),l(6,"Gesti\xF3n de citas, comparecencias y seguimiento con personas quejosas."),r()(),s(7,"button",2),_("click",function(){return t.nuevaCita()}),s(8,"mat-icon"),l(9,"add"),r(),l(10," Nueva cita"),r()(),s(11,"div",3)(12,"div",4)(13,"span",5)(14,"mat-icon"),l(15,"calendar_today"),r()(),s(16,"div")(17,"span"),l(18,"Citas de hoy"),r(),s(19,"strong"),l(20),r()()(),s(21,"div",4)(22,"span",5)(23,"mat-icon"),l(24,"schedule"),r()(),s(25,"div")(26,"span"),l(27,"Pr\xF3ximas citas"),r(),s(28,"strong"),l(29),r()()(),s(30,"div",4)(31,"span",5)(32,"mat-icon"),l(33,"check_circle_outline"),r()(),s(34,"div")(35,"span"),l(36,"Confirmadas"),r(),s(37,"strong"),l(38),r()()(),s(39,"div",4)(40,"span",5)(41,"mat-icon"),l(42,"highlight_off"),r()(),s(43,"div")(44,"span"),l(45,"Canceladas"),r(),s(46,"strong"),l(47),r()()()(),s(48,"div",6)(49,"button",7),_("click",function(){return t.cambiarVista("calendario")}),s(50,"mat-icon"),l(51,"calendar_month"),r(),l(52," Calendario"),r(),s(53,"button",7),_("click",function(){return t.cambiarVista("lista")}),s(54,"mat-icon"),l(55,"format_list_bulleted"),r(),l(56," Lista de citas"),r()(),v(57,DM,75,8,"div",8)(58,OM,99,18),r(),v(59,PM,1,3,"app-nueva-cita",9)),e&2&&(d(20),g(t.kpiHoy),d(9),g(t.kpiProximas),d(9),g(t.kpiConfirmadas),d(9),g(t.kpiCanceladas),d(2),k("activa",t.vista==="calendario"),d(4),k("activa",t.vista==="lista"),d(4),y(t.vista==="calendario"?57:58),d(2),y(t.mostrarNueva?59:-1))},dependencies:[Ot,io,ao,ft,Ai,Tt,St,ze,Ve,Ft,Nt,Co],styles:[".ag[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:18px}.vacio[_ngcontent-%COMP%]{color:var(--texto-suave);font-size:13.5px}.ag-cabeza[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:flex-start;gap:16px}.ag-cabeza[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{margin:0;color:var(--guinda);font-size:30px;font-weight:800}.ag-cabeza[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:4px 0 0;color:#555;font-size:15px}.pc-btn.grande[_ngcontent-%COMP%]{height:46px;padding:0 22px;font-size:15px}.pc-kpis[_ngcontent-%COMP%]{margin-bottom:0}.ag-tabs[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:6px;max-width:920px;padding:6px;border:1px solid #eceef1;border-radius:12px;background:#fff}.ag-tabs[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;gap:10px;height:44px;border:none;border-radius:8px;background:#f6f7f9;color:#333;font:inherit;font-size:15px;font-weight:600;cursor:pointer}.ag-tabs[_ngcontent-%COMP%]   button.activa[_ngcontent-%COMP%]{background:var(--guinda);color:#fff}.ag-rejilla[_ngcontent-%COMP%]{display:grid;grid-template-columns:minmax(0,1.55fr) minmax(0,1fr);gap:18px;align-items:start}.ag-rejilla[_ngcontent-%COMP%]   .col[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:18px}@media(max-width:1100px){.ag-rejilla[_ngcontent-%COMP%]{grid-template-columns:minmax(0,1fr)}}.ag-cal-cabeza[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:14px}.ag-cal-cabeza[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%], .ag-h3[_ngcontent-%COMP%]{margin:0;font-size:18px;font-weight:800}.ag-h3[_ngcontent-%COMP%]{margin-bottom:12px}.ag-nav[_ngcontent-%COMP%]{display:flex;align-items:center;gap:10px}.ag-nav[_ngcontent-%COMP%]   b[_ngcontent-%COMP%]{min-width:120px;text-align:center}.ico[_ngcontent-%COMP%]{display:grid;place-items:center;width:32px;height:32px;border:none;border-radius:6px;background:none;color:#333;cursor:pointer}.ico[_ngcontent-%COMP%]:hover{background:#f3f4f6}.ag-cal[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(7,1fr);border:1px solid #eceef1;border-radius:10px;overflow:hidden}.ag-sem[_ngcontent-%COMP%]{padding:10px 0;background:#1f2430;color:#fff;font-size:14px;font-weight:700;text-align:center}.ag-dia[_ngcontent-%COMP%]{position:relative;height:64px;border:none;border-right:1px solid #f0f1f3;border-bottom:1px solid #f0f1f3;background:#fff;font:inherit;font-size:15px;font-weight:600;cursor:pointer}.ag-dia.vacio[_ngcontent-%COMP%]{background:#fafafb;cursor:default}.ag-dia[_ngcontent-%COMP%]:hover:not(.vacio){background:#fcf4f7}.ag-dia.hoy[_ngcontent-%COMP%]{color:var(--guinda);font-weight:900}.ag-dia.sel[_ngcontent-%COMP%]{outline:2px solid var(--guinda);outline-offset:-2px;background:#fbf0f4}.ag-dia[_ngcontent-%COMP%]   .punto[_ngcontent-%COMP%]{position:absolute;left:50%;bottom:12px;width:6px;height:6px;margin-left:-3px;border-radius:50%;background:var(--guinda)}.ag-dia-titulo[_ngcontent-%COMP%]{margin:18px 0 10px;font-size:17px}.ag-dia-lista[_ngcontent-%COMP%], .ag-proximas[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:8px;margin:0;padding:0;list-style:none}.ag-dia-lista[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:not(.vacio){display:grid;grid-template-columns:80px 120px 1fr auto auto;align-items:center;gap:12px;padding:10px 14px;border:1px solid #eceef1;border-radius:10px}.ag-dia-lista[_ngcontent-%COMP%]   li.apagada[_ngcontent-%COMP%]{opacity:.6}.ag-dia-lista[_ngcontent-%COMP%]   .folio[_ngcontent-%COMP%]{font-weight:700;font-size:13.5px}.ag-dia-lista[_ngcontent-%COMP%]   .quien[_ngcontent-%COMP%]   small[_ngcontent-%COMP%], .ag-proximas[_ngcontent-%COMP%]   small[_ngcontent-%COMP%]{display:block;color:#555;font-size:12.5px}.ag-proximas[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:not(.vacio){display:grid;grid-template-columns:58px 1fr auto;align-items:center;gap:12px;padding:10px 12px;border:1px solid #eceef1;border-radius:10px}.ag-proximas[_ngcontent-%COMP%]   .fecha[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:center;padding:6px 0;border-radius:8px;background:#fbf0f4;color:var(--guinda)}.ag-proximas[_ngcontent-%COMP%]   .fecha[_ngcontent-%COMP%]   b[_ngcontent-%COMP%]{font-size:22px;line-height:1.1}.ag-proximas[_ngcontent-%COMP%]   .datos[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{display:block;font-weight:700;font-size:13.5px}.ag-proximas[_ngcontent-%COMP%]   .der[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:flex-end;gap:8px}.ag-filtros-lado[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:12px}.ag-filtros-lado[_ngcontent-%COMP%]   .dos[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:10px}.pc-btn-borde.ancho[_ngcontent-%COMP%]{width:100%}.ag-filtros[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(5,minmax(0,1fr)) auto;align-items:end;gap:14px}@media(max-width:1100px){.ag-filtros[_ngcontent-%COMP%]{grid-template-columns:repeat(2,minmax(0,1fr))}}.ag-tabla-env[_ngcontent-%COMP%]{overflow-x:auto}.ag-tabla-env.recargando[_ngcontent-%COMP%]{opacity:.55}.ag-tabla[_ngcontent-%COMP%]{width:100%;border-collapse:collapse;font-size:14px}.ag-tabla[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]{padding:10px 12px;background:#f7f8fa;text-align:left;white-space:nowrap}.ag-tabla[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:2px;border:none;background:none;color:#2b2f36;font:inherit;font-weight:700;cursor:pointer}.ag-tabla[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:18px;width:18px;height:18px;color:#8a8f98}.ag-tabla[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{padding:10px 12px;border-bottom:1px solid #f0f1f3}.ag-tabla[_ngcontent-%COMP%]   td.fuerte[_ngcontent-%COMP%]{font-weight:700}.ag-tabla[_ngcontent-%COMP%]   td.acciones[_ngcontent-%COMP%]{white-space:nowrap}.menu-fila[_ngcontent-%COMP%]{position:relative;display:inline-block;margin-left:6px;vertical-align:middle}.menu[_ngcontent-%COMP%]{position:absolute;right:0;top:34px;z-index:20;display:flex;flex-direction:column;min-width:210px;padding:6px;border:1px solid #e6e8ec;border-radius:10px;background:#fff;box-shadow:0 10px 28px #00000024}.menu[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{padding:9px 12px;border:none;border-radius:6px;background:none;font:inherit;font-size:13.5px;text-align:left;cursor:pointer}.menu[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover{background:var(--guinda-suave);color:var(--guinda)}.menu[_ngcontent-%COMP%]   button.peligro[_ngcontent-%COMP%]{color:#b42318}.ag-paginado[_ngcontent-%COMP%]{display:flex;justify-content:space-between;align-items:center;margin-top:12px;color:#555;font-size:13.5px}.ag-paginado[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%]{display:flex;gap:4px}.ag-paginado[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{display:grid;place-items:center;min-width:36px;height:36px;border:1px solid #e6e8ec;border-radius:8px;background:#fff;font:inherit;font-weight:600;cursor:pointer}.ag-paginado[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%]   button.actual[_ngcontent-%COMP%]{border-color:var(--guinda);background:var(--guinda);color:#fff}.ag-paginado[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:disabled{opacity:.4}"]})};function Rn(n){return`${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,"0")}-${String(n.getDate()).padStart(2,"0")}`}function kl(n,i){let e=new Date(n);return e.setDate(e.getDate()+i),e}function Ml(n){let[i,e,t]=n.split("/");return`${t}-${e}-${i}`}function C0(n){return new Date(`${Ml(n.fecha)}T${n.hora||"00:00"}:00`).getTime()}var Al=class n{static \u0275fac=function(e){return new(e||n)};static \u0275cmp=A({type:n,selectors:[["app-perfil"]],decls:2,vars:0,template:function(e,t){e&1&&(Te(0,"p"),l(1,"perfil works!"),Be())},encapsulation:2})};var Rl=class n{constructor(i){this.api=i}api;crearRemision(i){return this.api.post("/remisiones",i)}obtenerPorFolio(i){return this.api.get(`/remisiones/folio/${encodeURIComponent(i)}`)}descargarPdf(i){return this.api.getBlob(`/remisiones/folio/${encodeURIComponent(i)}/pdf`)}enviarRemision(i){return this.api.put(`/remisiones/folio/${encodeURIComponent(i)}/enviar`,{})}static \u0275fac=function(e){return new(e||n)(U(Ue))};static \u0275prov=D({token:n,factory:n.\u0275fac,providedIn:"root"})};function NM(n,i){n&1&&(s(0,"mat-card",7)(1,"p",9),l(2,"Cargando\u2026"),r()())}function LM(n,i){if(n&1&&(s(0,"div")(1,"span"),l(2,"Orientaci\xF3n al quejoso"),r(),s(3,"strong"),l(4),r()()),n&2){let e=h(3);d(4),g(e.remision.sugerenciaQuejoso)}}function BM(n,i){if(n&1&&(s(0,"strong",13),l(1),r()),n&2){let e=h(3);d(),N("Enviado ",e.formatearFechaHora(e.remision.fechaEnvio))}}function jM(n,i){n&1&&(s(0,"strong",14),l(1,"Pendiente de registrar"),r())}function VM(n,i){if(n&1){let e=T();s(0,"button",18),_("click",function(){x(e);let a=h(3);return C(a.registrarEnvio())}),s(1,"mat-icon"),l(2,"mark_email_read"),r(),l(3," Registrar env\xEDo "),r()}if(n&2){let e=h(3);P("disabled",e.procesando)}}function zM(n,i){if(n&1){let e=T();s(0,"mat-card",12)(1,"h3"),l(2),r(),s(3,"div",10)(4,"div")(5,"span"),l(6,"Instancia destino"),r(),s(7,"strong"),l(8),r()(),s(9,"div")(10,"span"),l(11,"Fundamento"),r(),s(12,"strong"),l(13),r()(),v(14,LM,5,1,"div"),s(15,"div")(16,"span"),l(17,"Generado"),r(),s(18,"strong"),l(19),r()(),s(20,"div")(21,"span"),l(22,"Env\xEDo"),r(),v(23,BM,2,1,"strong",13)(24,jM,2,0,"strong",14),r()(),s(25,"div",15)(26,"button",16),_("click",function(){x(e);let a=h(2);return C(a.descargarOficio())}),s(27,"mat-icon"),l(28,"picture_as_pdf"),r(),l(29," Descargar oficio (PDF) "),r(),v(30,VM,4,1,"button",17),r()()}if(n&2){let e=h(2);d(2),N("Oficio ",e.remision.numeroOficio),d(6),g(e.remision.autoridadRemision),d(5),g(e.remision.justificacionLegal),d(),y(e.remision.sugerenciaQuejoso?14:-1),d(5),qe("",e.formatearFechaHora(e.remision.fechaRemision)," por ",e.remision.analistaNombre),d(4),y(e.remision.estatus==="ENVIADA"?23:24),d(7),y(e.remision.estatus!=="ENVIADA"?30:-1)}}function UM(n,i){if(n&1&&(s(0,"mat-card",12)(1,"h3"),l(2,"Remisi\xF3n no disponible"),r(),s(3,"p",9),l(4," Solo se remite un expediente dictaminado como improcedente. Estado actual: "),s(5,"strong"),l(6),r(),l(7,". "),r()()),n&2){let e=h(2);d(6),g(e.expediente==null?null:e.expediente.estatus)}}function HM(n,i){if(n&1&&(s(0,"mat-option",21),l(1),r()),n&2){let e=i.$implicit;P("value",e),d(),g(e)}}function $M(n,i){if(n&1){let e=T();s(0,"mat-form-field",19)(1,"mat-label"),l(2,"Nombre de la instituci\xF3n"),r(),s(3,"input",26),ge("ngModelChange",function(a){x(e);let o=h(3);return fe(o.institucionOtra,a)||(o.institucionOtra=a),C(a)}),r()()}if(n&2){let e=h(3);d(3),he("ngModel",e.institucionOtra)}}function GM(n,i){if(n&1){let e=T();s(0,"mat-card",12)(1,"h3"),l(2,"Datos de la remisi\xF3n"),r(),s(3,"mat-form-field",19)(4,"mat-label"),l(5,"Instituci\xF3n o \xE1rea destino"),r(),s(6,"mat-select",20),ge("ngModelChange",function(a){x(e);let o=h(2);return fe(o.institucion,a)||(o.institucion=a),C(a)}),te(7,HM,2,2,"mat-option",21,Ke),r()(),v(9,$M,4,1,"mat-form-field",19),s(10,"mat-form-field",19)(11,"mat-label"),l(12,"Fundamento de la remisi\xF3n"),r(),s(13,"textarea",22),ge("ngModelChange",function(a){x(e);let o=h(2);return fe(o.fundamento,a)||(o.fundamento=a),C(a)}),r()(),s(14,"p",23),l(15,"Se cita en el oficio: \u201Ccon fundamento en \u2026\u201D."),r(),s(16,"mat-form-field",19)(17,"mat-label"),l(18,"Orientaci\xF3n para el quejoso"),r(),s(19,"textarea",24),ge("ngModelChange",function(a){x(e);let o=h(2);return fe(o.orientacion,a)||(o.orientacion=a),C(a)}),l(20,"          "),r()(),s(21,"p",23),l(22,"Aparece en el oficio y en el aviso que recibe el quejoso."),r(),s(23,"mat-checkbox",20),ge("ngModelChange",function(a){x(e);let o=h(2);return fe(o.adjuntarExpediente,a)||(o.adjuntarExpediente=a),C(a)}),l(24," Anexar copia del expediente y la lista de evidencias "),r(),s(25,"div",15)(26,"button",25),_("click",function(){x(e);let a=h(2);return C(a.generarRemision())}),s(27,"mat-icon"),l(28,"picture_as_pdf"),r(),l(29," Generar oficio "),r()()()}if(n&2){let e=h(2);d(6),he("ngModel",e.institucion),d(),ne(e.instituciones),d(2),y(e.institucion==="Otra"?9:-1),d(4),he("ngModel",e.fundamento),d(6),he("ngModel",e.orientacion),d(4),he("ngModel",e.adjuntarExpediente),d(3),P("disabled",e.procesando)}}function qM(n,i){if(n&1){let e=T();s(0,"div",8)(1,"mat-card",7)(2,"h3"),l(3,"Datos del expediente"),r(),s(4,"div",10)(5,"div")(6,"span"),l(7,"Folio"),r(),s(8,"strong"),l(9),r()(),s(10,"div")(11,"span"),l(12,"Folio de la queja"),r(),s(13,"strong"),l(14),r()(),s(15,"div")(16,"span"),l(17,"Quejoso"),r(),s(18,"strong"),l(19),r()(),s(20,"div")(21,"span"),l(22,"Asunto"),r(),s(23,"strong"),l(24),r()(),s(25,"div")(26,"span"),l(27,"Unidad acad\xE9mica"),r(),s(28,"strong"),l(29),r()(),s(30,"div")(31,"span"),l(32,"Estado"),r(),s(33,"strong"),l(34),r()()(),s(35,"button",11),_("click",function(){x(e);let a=h();return C(a.volver())}),s(36,"mat-icon"),l(37,"arrow_back"),r(),l(38," Volver al expediente "),r()(),v(39,zM,31,8,"mat-card",12)(40,UM,8,1,"mat-card",12)(41,GM,30,6,"mat-card",12),r()}if(n&2){let e=h();d(9),g(e.folio),d(5),g(e.expediente==null?null:e.expediente.folioOrigen),d(5),g(e.expediente==null||e.expediente.quejoso==null?null:e.expediente.quejoso.nombre),d(5),g(e.expediente==null?null:e.expediente.asunto),d(5),g(e.expediente==null||e.expediente.quejoso==null?null:e.expediente.quejoso.unidadAcademica),d(5),g(e.expediente==null?null:e.expediente.estatus),d(5),y(e.remision?39:e.esImprocedente?41:40)}}var Tl=class n{constructor(i,e,t,a,o,c){this.route=i;this.router=e;this.snackBar=t;this.expedienteService=a;this.remisionService=o;this.cdr=c;this.folio=this.route.snapshot.paramMap.get("id")??""}route;router;snackBar;expedienteService;remisionService;cdr;folio="";institucion="";institucionOtra="";fundamento="";orientacion="";adjuntarExpediente=!0;expediente;remision;cargando=!0;procesando=!1;formatearFechaHora=Hn;instituciones=["\xD3rgano Interno de Control IPN","Abogado General","Comisi\xF3n de Derechos Humanos","Ministerio P\xFAblico","Otra"];ngOnInit(){this.folio&&this.expedienteService.obtenerPorFolio(this.folio).subscribe({next:i=>{this.expediente=this.expedienteService.mapearADetalle(i),this.cargarRemision()},error:()=>{this.cargando=!1,this.cdr.detectChanges(),this.snackBar.open("No fue posible cargar los datos del expediente.","Cerrar",{duration:3e3})}})}cargarRemision(){this.remisionService.obtenerPorFolio(this.folio).subscribe({next:i=>{this.remision=i,this.cargando=!1,this.cdr.detectChanges()},error:()=>{this.cargando=!1,this.cdr.detectChanges()}})}get esImprocedente(){return this.expediente?.estatusCodigo==="IMPROCEDENTE"}get paso(){return this.remision?this.remision.estatus==="ENVIADA"?2:1:0}generarRemision(){if(!this.expediente?.folio){this.snackBar.open("No fue posible identificar el expediente.","Cerrar",{duration:3e3});return}let i=this.institucion==="Otra"?this.institucionOtra.trim():this.institucion;if(!i||!this.fundamento.trim()){this.snackBar.open("Completa la instituci\xF3n destino y el fundamento de la remisi\xF3n.","Cerrar",{duration:3500});return}this.procesando=!0,this.remisionService.crearRemision({folio:this.expediente.folio,autoridadRemision:i,justificacionLegal:this.fundamento.trim(),sugerenciaQuejoso:this.orientacion.trim()||void 0,adjuntarExpediente:this.adjuntarExpediente}).subscribe({next:e=>{this.remision=e,this.procesando=!1,this.cdr.detectChanges(),this.snackBar.open(`Oficio ${e.numeroOficio} generado. Desc\xE1rgalo y registra su env\xEDo.`,"Cerrar",{duration:4e3})},error:e=>{this.procesando=!1,this.cdr.detectChanges(),this.snackBar.open(Ne(e,"No fue posible generar la remisi\xF3n."),"Cerrar",{duration:4e3})}})}descargarOficio(){this.remisionService.descargarPdf(this.folio).subscribe({next:i=>Kr(i,`oficio-remision-${this.expediente?.folioOrigen??this.folio}.pdf`),error:()=>{this.snackBar.open("No fue posible descargar el oficio.","Cerrar",{duration:3500})}})}registrarEnvio(){confirm("Registra el env\xEDo solo cuando el oficio ya se haya entregado a la instancia. El expediente quedar\xE1 como Remitido y se avisar\xE1 al quejoso. \xBFContinuar?")&&(this.procesando=!0,this.remisionService.enviarRemision(this.folio).subscribe({next:e=>{this.remision=e,this.procesando=!1,this.expediente&&(this.expediente.estatus="Remitida",this.expediente.estatusCodigo="REMITIDA"),this.cdr.detectChanges(),this.snackBar.open("Env\xEDo registrado. El expediente qued\xF3 remitido.","Cerrar",{duration:3500})},error:e=>{this.procesando=!1,this.cdr.detectChanges(),this.snackBar.open(Ne(e,"No fue posible registrar el env\xEDo."),"Cerrar",{duration:4e3})}}))}volver(){this.router.navigate(["/expediente",this.folio])}static \u0275fac=function(e){return new(e||n)(S(Ct),S(We),S(Mt),S(Yn),S(Rl),S(Z))};static \u0275cmp=A({type:n,selectors:[["app-remision"]],decls:35,vars:19,consts:[[1,"page"],[1,"page-header"],[1,"warning-chip"],[1,"flow-card"],[1,"step","done"],[1,"line"],[1,"step"],[1,"card"],[1,"grid"],[1,"muted"],[1,"info-list"],["mat-button","",1,"back-link",3,"click"],[1,"card","form-card"],[1,"ok"],[1,"pendiente"],[1,"actions"],["mat-stroked-button","",3,"click"],["mat-flat-button","",1,"danger-btn",3,"disabled"],["mat-flat-button","",1,"danger-btn",3,"click","disabled"],["appearance","outline"],[3,"ngModelChange","ngModel"],[3,"value"],["matInput","","rows","3","placeholder","Ej. el art\xEDculo 12 del Reglamento de la Defensor\xEDa de los Derechos Polit\xE9cnicos",3,"ngModelChange","ngModel"],[1,"campo-ayuda"],["matInput","","rows","3","placeholder","Qu\xE9 debe hacer el quejoso ante la instancia competente.",3,"ngModelChange","ngModel"],["mat-flat-button","",1,"primary-btn",3,"click","disabled"],["matInput","",3,"ngModelChange","ngModel"]],template:function(e,t){e&1&&(s(0,"section",0)(1,"div",1)(2,"div")(3,"h2"),l(4,"Remisi\xF3n Externa"),r(),s(5,"p"),l(6),r()(),s(7,"mat-chip",2),l(8),r()(),s(9,"div",3)(10,"div",4)(11,"mat-icon"),l(12,"check_circle"),r(),s(13,"span"),l(14,"Improcedente"),r()(),H(15,"div",5),s(16,"div",6)(17,"mat-icon"),l(18),r(),s(19,"span"),l(20,"Datos de la remisi\xF3n"),r()(),H(21,"div",5),s(22,"div",6)(23,"mat-icon"),l(24),r(),s(25,"span"),l(26,"Oficio generado"),r()(),H(27,"div",5),s(28,"div",6)(29,"mat-icon"),l(30),r(),s(31,"span"),l(32,"Enviado"),r()()(),v(33,NM,3,0,"mat-card",7)(34,qM,42,7,"div",8),r()),e&2&&(d(6),qe(" Expediente ",t.folio," \xB7 ",(t.expediente==null?null:t.expediente.asunto)||"Sin asunto"," \xB7 Canalizaci\xF3n a una autoridad externa. "),d(2),N(" ",t.paso===2?"Remisi\xF3n enviada":t.paso===1?"Oficio generado":"Remisi\xF3n externa"," "),d(8),k("active",t.paso===0)("done",t.paso>0),d(2),g(t.paso>0?"check_circle":"edit_document"),d(4),k("active",t.paso===1)("done",t.paso>1),d(2),g(t.paso>1?"check_circle":"picture_as_pdf"),d(4),k("active",t.paso===2)("done",t.paso===2),d(2),g(t.paso===2?"check_circle":"mark_email_read"),d(3),y(t.cargando?33:34))},dependencies:[Ot,ft,Tt,St,sn,jn,Ge,Je,ze,Ve,mn,Gn,ln,Jt,kt,el,Jc,Li,Un,Ti,po,ha,Ft],styles:[".page[_ngcontent-%COMP%]{max-width:1280px}.page-header[_ngcontent-%COMP%]{margin-bottom:var(--space-5);display:flex;justify-content:space-between;align-items:center;gap:var(--space-5)}.page-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{margin:0;color:var(--guinda);font-size:28px;font-weight:800}.page-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-1) 0 0;color:var(--texto-suave)}.flow-card[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:space-between;gap:var(--space-3);background:#fff;border-radius:14px;box-shadow:0 2px 8px #0f172a14;padding:var(--space-4);margin-bottom:var(--space-5)}.step[_ngcontent-%COMP%]{display:flex;align-items:center;gap:var(--space-2);padding:var(--space-2) var(--space-4);border-radius:8px;font-weight:700;font-size:var(--font-size-sm);background:#f3f4f6;color:var(--texto-suave)}.step.done[_ngcontent-%COMP%]{background:#e8f5e9;color:var(--exito)}.step.active[_ngcontent-%COMP%]{background:var(--guinda);color:#fff}.line[_ngcontent-%COMP%]{height:2px;background:#f1f1f3;flex:1}.grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:340px 1fr;gap:var(--space-5);align-items:start}.card[_ngcontent-%COMP%]{border-radius:14px;box-shadow:0 2px 8px #0f172a14;padding:var(--space-4);background:#fff}.card[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{margin:0 0 var(--space-4);color:var(--negro-inst);font-size:var(--font-size-lg);font-weight:900}.info-list[_ngcontent-%COMP%]{display:grid;gap:var(--space-3)}.info-list[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{display:grid;gap:var(--space-1);border-bottom:1px solid #f1f1f3;padding-bottom:var(--space-2)}.info-list[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:last-child{border-bottom:none;padding-bottom:0}.info-list[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{color:var(--texto-suave);font-size:var(--font-size-xs);font-weight:800;text-transform:uppercase}.info-list[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--negro-inst);font-weight:700;font-size:var(--font-size-sm)}.form-card[_ngcontent-%COMP%]   mat-form-field[_ngcontent-%COMP%]{width:100%}.form-card[_ngcontent-%COMP%]     .mat-mdc-form-field-subscript-wrapper{display:none}.form-card[_ngcontent-%COMP%]   mat-form-field[_ngcontent-%COMP%]{margin-bottom:var(--space-4)}.actions[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;gap:var(--space-3);margin-top:var(--space-2)}.outline-btn[_ngcontent-%COMP%]{border-color:var(--texto-suave)!important;color:var(--texto)!important;font-weight:700;border-radius:8px!important;height:42px}.danger-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important;font-weight:700;border-radius:8px!important;height:42px}mat-chip[_ngcontent-%COMP%]{font-weight:700!important}.danger-chip[_ngcontent-%COMP%]{background:#ffebee!important;color:var(--peligro)!important}.warning-chip[_ngcontent-%COMP%]{background:#fdf6e3!important;color:var(--advertencia)!important}@media(max-width:1000px){.page-header[_ngcontent-%COMP%]{flex-direction:column;align-items:flex-start;gap:var(--space-2)}.flow-card[_ngcontent-%COMP%]{flex-direction:column;align-items:stretch;gap:var(--space-2)}.line[_ngcontent-%COMP%]{display:none}.grid[_ngcontent-%COMP%]{grid-template-columns:1fr}}.primary-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important;font-weight:700;border-radius:8px!important;height:42px}.campo-ayuda[_ngcontent-%COMP%]{margin:calc(-1 * var(--space-3)) 0 var(--space-4);color:var(--texto-suave);font-size:var(--font-size-xs)}.muted[_ngcontent-%COMP%]{color:var(--texto-suave);margin:0}.info-list[_ngcontent-%COMP%]   .ok[_ngcontent-%COMP%]{color:var(--exito)}.info-list[_ngcontent-%COMP%]   .pendiente[_ngcontent-%COMP%]{color:#9a5b00}.back-link[_ngcontent-%COMP%]{margin-top:var(--space-4);color:var(--guinda)!important}"]})};function WM(n,i){n&1&&(s(0,"mat-card",3)(1,"p",4),l(2,"Cargando dictamen\u2026"),r()())}function QM(n,i){if(n&1&&(s(0,"mat-card",3)(1,"p",4),l(2," El expediente "),s(3,"strong"),l(4),r(),l(5," todav\xEDa no tiene dictamen registrado. "),r()()),n&2){let e=h();d(4),g(e.folio)}}function YM(n,i){if(n&1&&(s(0,"span"),l(1),r()),n&2){let e=h(2);ve("estatus-chip "+e.claseEstatus(e.dictamen.estatusExpediente)),d(),N(" Expediente: ",e.etiquetaEstatus(e.dictamen.estatusExpediente)," ")}}function XM(n,i){if(n&1&&(s(0,"h3"),l(1,"Observaciones"),r(),s(2,"p",10),l(3),r()),n&2){let e=h(2);d(3),g(e.dictamen.observaciones)}}function KM(n,i){if(n&1&&(s(0,"strong"),l(1),r()),n&2){let e=h(3);d(),N("Recibido \xB7 ",e.dictamen.folioSubdefensoria)}}function ZM(n,i){n&1&&(s(0,"strong",15),l(1,"Pendiente de confirmar"),r())}function JM(n,i){if(n&1&&(s(0,"div")(1,"span"),l(2,"\xC1rea de turno"),r(),s(3,"strong"),l(4),r()(),s(5,"div")(6,"span"),l(7,"Responsable"),r(),s(8,"strong"),l(9),r()(),s(10,"div")(11,"span"),l(12,"Recepci\xF3n en Subdefensor\xEDa"),r(),v(13,KM,2,1,"strong")(14,ZM,2,0,"strong",15),r()),n&2){let e=h(2);d(4),g(e.dictamen.areaTurno||"Subdefensor\xEDa"),d(5),g(e.dictamen.responsableTurno||"\u2014"),d(4),y(e.dictamen.folioSubdefensoria?13:14)}}function eI(n,i){if(n&1&&(s(0,"div")(1,"span"),l(2,"Siguiente paso"),r(),s(3,"strong"),l(4),r()()),n&2){let e=h(2);d(4),N(" ",e.dictamen.estatusExpediente==="REMITIDA"?"Remisi\xF3n enviada a la instancia competente":"Generar y enviar la remisi\xF3n externa"," ")}}function tI(n,i){if(n&1){let e=T();s(0,"button",16),_("click",function(){x(e);let a=h(2);return C(a.reenviar())}),s(1,"mat-icon"),l(2,"sync"),r(),l(3," Reintentar env\xEDo a Subdefensor\xEDa "),r()}if(n&2){let e=h(2);P("disabled",e.procesando)}}function nI(n,i){if(n&1){let e=T();s(0,"button",17),_("click",function(){x(e);let a=h(2);return C(a.irARemision())}),s(1,"mat-icon"),l(2,"outgoing_mail"),r(),l(3),r()}if(n&2){let e=h(2);d(3),N(" ",e.dictamen.estatusExpediente==="REMITIDA"?"Ver remisi\xF3n":"Continuar con la remisi\xF3n"," ")}}function iI(n,i){if(n&1&&(s(0,"mat-card",5)(1,"mat-icon",6),l(2),r(),s(3,"div")(4,"span",7),l(5,"Resultado del dictamen"),r(),s(6,"h3"),l(7),r(),s(8,"p"),l(9," Emitido por "),s(10,"strong"),l(11),r(),l(12),r()(),v(13,YM,2,3,"span",8),r(),s(14,"div",9)(15,"mat-card",3)(16,"h3"),l(17,"Justificaci\xF3n"),r(),s(18,"p",10),l(19),r(),v(20,XM,4,1),r(),s(21,"mat-card",3)(22,"h3"),l(23,"Seguimiento"),r(),s(24,"div",11)(25,"div")(26,"span"),l(27,"Folio del expediente"),r(),s(28,"strong"),l(29),r()(),v(30,JM,15,3)(31,eI,5,1,"div"),r(),s(32,"div",12),v(33,tI,4,1,"button",13),v(34,nI,4,1,"button",14),r()()()),n&2){let e=h();k("competente",e.esCompetente)("improcedente",!e.esCompetente),d(2),g(e.esCompetente?"verified":"block"),d(5),g(e.esCompetente?"Competente \xB7 Procedente":"Improcedente"),d(4),g(e.dictamen.analistaNombre),d(),N(" el ",e.formatearFechaHora(e.dictamen.fechaDictamen),". "),d(),y(e.dictamen.estatusExpediente?13:-1),d(6),g(e.dictamen.justificacion),d(),y(e.dictamen.observaciones?20:-1),d(9),g(e.dictamen.folio),d(),y(e.esCompetente?30:31),d(3),y(e.pendienteSubdefensoria?33:-1),d(),y(e.esCompetente?-1:34)}}var Ol=class n{constructor(i,e,t,a,o){this.route=i;this.router=e;this.dictamenService=t;this.snackBar=a;this.cdr=o;this.folio=this.route.snapshot.paramMap.get("id")??""}route;router;dictamenService;snackBar;cdr;folio="";dictamen;cargando=!0;sinDictamen=!1;procesando=!1;claseEstatus=co;etiquetaEstatus=Oi;formatearFechaHora=Hn;ngOnInit(){this.dictamenService.obtenerPorFolio(this.folio).subscribe({next:i=>{this.dictamen=i,this.cargando=!1,this.cdr.detectChanges()},error:i=>{this.cargando=!1,this.sinDictamen=i.status===404,this.cdr.detectChanges(),this.sinDictamen||this.snackBar.open("No fue posible cargar el dictamen.","Cerrar",{duration:3500})}})}get esCompetente(){return this.dictamen?.resultado==="COMPETENTE"}get pendienteSubdefensoria(){return this.esCompetente&&!this.dictamen?.folioSubdefensoria}volver(){this.router.navigate(["/expediente",this.folio])}irARemision(){this.router.navigate(["/remision",this.folio])}reenviar(){this.procesando=!0,this.dictamenService.reenviarASubdefensoria(this.folio).subscribe({next:i=>{this.dictamen=i,this.procesando=!1,this.cdr.detectChanges(),this.snackBar.open("Subdefensor\xEDa recibi\xF3 el expediente.","Cerrar",{duration:3e3})},error:i=>{this.procesando=!1,this.cdr.detectChanges(),this.snackBar.open(Ne(i,"No fue posible reenviar a Subdefensor\xEDa."),"Cerrar",{duration:4e3})}})}static \u0275fac=function(e){return new(e||n)(S(Ct),S(We),S(wo),S(Mt),S(Z))};static \u0275cmp=A({type:n,selectors:[["app-dictamen-consulta"]],decls:14,vars:2,consts:[[1,"page"],[1,"page-header"],["mat-stroked-button","",3,"click"],[1,"card"],[1,"muted"],[1,"card","resultado"],[1,"resultado-icon"],[1,"eyebrow"],[3,"class"],[1,"grid"],[1,"texto"],[1,"info-list"],[1,"acciones"],["mat-flat-button","",1,"primary-btn",3,"disabled"],["mat-flat-button","",1,"primary-btn"],[1,"pendiente"],["mat-flat-button","",1,"primary-btn",3,"click","disabled"],["mat-flat-button","",1,"primary-btn",3,"click"]],template:function(e,t){e&1&&(s(0,"section",0)(1,"div",1)(2,"div")(3,"h2"),l(4,"Consulta de dictamen"),r(),s(5,"p"),l(6),r()(),s(7,"button",2),_("click",function(){return t.volver()}),s(8,"mat-icon"),l(9,"arrow_back"),r(),l(10," Volver al expediente "),r()(),v(11,WM,3,0,"mat-card",3)(12,QM,6,1,"mat-card",3)(13,iI,35,15),r()),e&2&&(d(6),N("Expediente ",t.folio," \xB7 Resoluci\xF3n de Primer Contacto."),d(5),y(t.cargando?11:t.sinDictamen?12:t.dictamen?13:-1))},dependencies:[sn,jn,Ge,Je,ze,Ve,Ft],styles:[".page[_ngcontent-%COMP%]{max-width:1280px}.page-header[_ngcontent-%COMP%]{margin-bottom:var(--space-5);display:flex;justify-content:space-between;align-items:center;gap:var(--space-5)}.page-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{margin:0;color:var(--guinda);font-size:28px;font-weight:800}.page-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-1) 0 0;color:var(--texto-suave)}.card[_ngcontent-%COMP%]{border-radius:14px;box-shadow:0 2px 8px #0f172a14;padding:var(--space-5);background:#fff}.card[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{margin:0 0 var(--space-3);font-size:var(--font-size-lg);font-weight:900;color:var(--negro-inst)}.muted[_ngcontent-%COMP%]{color:var(--texto-suave);margin:0}.resultado[_ngcontent-%COMP%]{display:flex;flex-direction:row;align-items:center;gap:var(--space-4);margin-bottom:var(--space-5);border-left:6px solid var(--exito)}.resultado.improcedente[_ngcontent-%COMP%]{border-left-color:#9a5b00}.resultado[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{flex:1}.resultado[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{margin:0}.resultado[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:var(--space-1) 0 0;color:var(--texto-suave)}.resultado-icon[_ngcontent-%COMP%]{font-size:40px;width:40px;height:40px;color:var(--exito)}.improcedente[_ngcontent-%COMP%]   .resultado-icon[_ngcontent-%COMP%]{color:#9a5b00}.eyebrow[_ngcontent-%COMP%]{display:block;color:var(--guinda);text-transform:uppercase;font-size:var(--font-size-xs);font-weight:900;letter-spacing:.05em}.grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 380px;gap:var(--space-5)}.texto[_ngcontent-%COMP%]{margin:0 0 var(--space-4);white-space:pre-line;color:var(--texto)}.info-list[_ngcontent-%COMP%]{display:grid;gap:var(--space-3)}.info-list[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{display:grid;gap:var(--space-1);padding-bottom:var(--space-2);border-bottom:1px solid #f1f1f3}.info-list[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:var(--font-size-xs);color:var(--texto-suave);text-transform:uppercase;font-weight:800}.info-list[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{color:var(--negro-inst);font-size:var(--font-size-sm)}.info-list[_ngcontent-%COMP%]   .pendiente[_ngcontent-%COMP%]{color:#9a5b00}.acciones[_ngcontent-%COMP%]{display:grid;gap:var(--space-2);margin-top:var(--space-4)}button[_ngcontent-%COMP%]{border-radius:8px!important;font-weight:700!important}.primary-btn[_ngcontent-%COMP%]{background:var(--guinda)!important;color:#fff!important}@media(max-width:1000px){.grid[_ngcontent-%COMP%]{grid-template-columns:1fr}.page-header[_ngcontent-%COMP%], .resultado[_ngcontent-%COMP%]{flex-direction:column;align-items:flex-start}}"]})};var D0=()=>{let n=m(Ci);return n.haySesion()&&n.esAnalistaPrimerContacto()?!0:(window.location.assign("/revision/login"),!1)};var E0=[{path:"",component:ec,canActivate:[D0],children:[{path:"",redirectTo:"dashboard",pathMatch:"full"},{path:"dashboard",component:Vc},{path:"bandeja",component:cl},{path:"expediente/:id",component:yl},{path:"expediente/:id/antecedentes",component:Dl},{path:"agenda",component:Il},{path:"perfil",component:Al},{path:"dictamen/:id",pathMatch:"full",redirectTo:({params:n,queryParams:i})=>`/expediente/${n.id}?tab=resolucion&decision=${i.tipo==="improcedente"?"improcedente":"competente"}`},{path:"dictamen/:id/consulta",component:Ol},{path:"remision/:id",component:Tl}]}];var S0={providers:[Nm(),Kd(E0),yd(xd([tf])),nf()]};var Pl=class n{static \u0275fac=function(e){return new(e||n)};static \u0275cmp=A({type:n,selectors:[["app-root"]],decls:1,vars:0,template:function(e,t){e&1&&H(0,"router-outlet")},dependencies:[na],encapsulation:2})};pd(Pl,S0).catch(n=>console.error(n));
