package ipn.escom.defensoria.primercontacto.repository;

import ipn.escom.defensoria.primercontacto.entity.CitaPrimerContacto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface CitaPrimerContactoRepository
        extends JpaRepository<CitaPrimerContacto, Long> {

    List<CitaPrimerContacto>
    findByExpedienteIdOrderByFechaCitaDescHoraCitaDesc(
            Long expedienteId
    );

    List<CitaPrimerContacto>
    findByFolioOrderByFechaCitaDescHoraCitaDesc(
            String folio
    );

    List<CitaPrimerContacto>
    findByFechaCitaOrderByHoraCitaAsc(
            LocalDate fechaCita
    );

    List<CitaPrimerContacto>
    findByAnalistaIdOrderByFechaCitaAscHoraCitaAsc(
            Long analistaId
    );

    List<CitaPrimerContacto>
    findByAnalistaIdAndFechaCitaGreaterThanEqualAndEstatusNotInOrderByFechaCitaAscHoraCitaAsc(
            Long analistaId,
            LocalDate desde,
            java.util.Collection<String> estatus
    );

    List<CitaPrimerContacto>
    findByEstatusOrderByFechaCitaAscHoraCitaAsc(
            String estatus
    );

    boolean existsByFolioAndEstatusNot(
            String folio,
            String estatus
    );

    List<CitaPrimerContacto>
    findByEstatusAndFechaLimiteRespuestaBefore(
            String estatus,
            LocalDateTime limite
    );

    List<CitaPrimerContacto>
    findByExpedienteIdInOrderByFechaCitaDescHoraCitaDesc(
            List<Long> expedienteIds
    );

    boolean existsByExpedienteIdAndEstatusNotIn(
            Long expedienteId,
            java.util.Collection<String> estatus
    );

    boolean existsByExpedienteIdAndEstatusNot(
            Long expedienteId,
            String estatus
    );

    Optional<CitaPrimerContacto> findByTokenRespuesta(
            String tokenRespuesta
    );

    List<CitaPrimerContacto>
    findByAnalistaIdAndFechaCitaAndEstatusIn(
            Long analistaId,
            LocalDate fechaCita,
            java.util.Collection<String> estatus
    );
}
