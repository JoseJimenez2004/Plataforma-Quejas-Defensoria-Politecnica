import { Routes } from '@angular/router';

import { MainLayout } from './layout/main-layout/main-layout';

import { Dashboard } from './features/dashboard/dashboard';
import { BandejaAnalisis } from './features/bandeja-analisis/bandeja-analisis';
import { Expediente } from './features/expediente/expediente';
import { Antecedentes } from './features/antecedentes/antecedentes';
import { Agenda } from './features/agenda/agenda';
import { Perfil } from './features/perfil/perfil';
import { Remision } from './features/remision/remision';
import { DictamenConsulta } from './features/dictamen-consulta/dictamen-consulta';

import { authPrimerContactoGuard } from './core/guards/auth-primer-contacto.guard';

export const routes: Routes = [
  {
    path: '',
    component: MainLayout,
    canActivate: [authPrimerContactoGuard],

    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },

      {
        path: 'dashboard',
        component: Dashboard
      },

      {
        path: 'bandeja',
        component: BandejaAnalisis
      },

      {
        path: 'expediente/:id',
        component: Expediente
      },

      // Búsqueda de antecedentes de la queja (modelo de búsqueda).
      {
        path: 'expediente/:id/antecedentes',
        component: Antecedentes
      },

      {
        path: 'agenda',
        component: Agenda
      },

      {
        path: 'perfil',
        component: Perfil
      },

      // El dictamen ahora se registra en la pestaña "Resolución" del expediente (diseño
      // 2026-10-18); la ruta vieja lleva ahí con la decisión ya elegida.
      {
        path: 'dictamen/:id',
        pathMatch: 'full',
        redirectTo: ({ params, queryParams }) =>
          `/expediente/${params['id']}?tab=resolucion&decision=${queryParams['tipo'] === 'improcedente' ? 'improcedente' : 'competente'}`
      },

      // CU-PC-08: consulta del dictamen ya registrado.
      {
        path: 'dictamen/:id/consulta',
        component: DictamenConsulta
      },

      {
        path: 'remision/:id',
        component: Remision
      }
    ]
  }
];