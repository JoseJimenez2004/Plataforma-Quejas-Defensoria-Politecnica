import {
  etiquetaRol,
  iniciales
} from "./chunk-WGADOSRI.js";
import {
  CheckboxControlValueAccessor,
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel,
  NgSelectOption,
  SelectControlValueAccessor,
  ɵNgSelectMultipleOption
} from "./chunk-Y3SUXXGM.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  HttpClient,
  Injectable,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-3WR4SCJM.js";

// src/app/core/services/personal.service.ts
var PersonalService = class _PersonalService {
  http;
  apiUrl = "/api/admin/personal";
  constructor(http) {
    this.http = http;
  }
  listar() {
    return this.http.get(this.apiUrl);
  }
  crear(datos) {
    return this.http.post(this.apiUrl, datos);
  }
  editar(id, datos) {
    return this.http.put(`${this.apiUrl}/${id}`, datos);
  }
  resetearPassword(id) {
    return this.http.post(`${this.apiUrl}/${id}/resetear-password`, {});
  }
  darDeBaja(id) {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
  reactivar(id) {
    return this.http.post(`${this.apiUrl}/${id}/reactivar`, {});
  }
  static \u0275fac = function PersonalService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _PersonalService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _PersonalService, factory: _PersonalService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PersonalService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/usuarios-roles/usuarios-roles.ts
var _forTrack0 = ($index, $item) => $item.id;
function UsuariosRoles_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 3);
    \u0275\u0275text(1, "Cargando personal\u2026");
    \u0275\u0275elementEnd();
  }
}
function UsuariosRoles_Conditional_9_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 11);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(1, "svg", 13);
    \u0275\u0275element(2, "path", 14)(3, "circle", 15);
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(4, "p");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r1.busqueda ? "Ning\xFAn usuario coincide con tu b\xFAsqueda." : "A\xFAn no hay personal registrado.");
  }
}
function UsuariosRoles_Conditional_9_Conditional_7_For_17_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 19);
    \u0275\u0275text(1, "Temporal");
    \u0275\u0275elementEnd();
  }
}
function UsuariosRoles_Conditional_9_Conditional_7_For_17_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 24);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_9_Conditional_7_For_17_Conditional_21_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const persona_r4 = \u0275\u0275nextContext().$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.darDeBaja(persona_r4));
    });
    \u0275\u0275text(1, "Baja");
    \u0275\u0275elementEnd();
  }
}
function UsuariosRoles_Conditional_9_Conditional_7_For_17_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 21);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_9_Conditional_7_For_17_Conditional_22_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r6);
      const persona_r4 = \u0275\u0275nextContext().$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.reactivar(persona_r4));
    });
    \u0275\u0275text(1, "Reactivar");
    \u0275\u0275elementEnd();
  }
}
function UsuariosRoles_Conditional_9_Conditional_7_For_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "tr")(1, "td")(2, "div", 16)(3, "span", 17);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "td");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "td");
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "td");
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "td")(13, "span", 18);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(15, UsuariosRoles_Conditional_9_Conditional_7_For_17_Conditional_15_Template, 2, 0, "span", 19);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "td", 20)(17, "button", 21);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_9_Conditional_7_For_17_Template_button_click_17_listener() {
      const persona_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.abrirEditar(persona_r4));
    });
    \u0275\u0275text(18, "Editar");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "button", 21);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_9_Conditional_7_For_17_Template_button_click_19_listener() {
      const persona_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.resetearPassword(persona_r4));
    });
    \u0275\u0275text(20, "Reset. contrase\xF1a");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(21, UsuariosRoles_Conditional_9_Conditional_7_For_17_Conditional_21_Template, 2, 0, "button", 22)(22, UsuariosRoles_Conditional_9_Conditional_7_For_17_Conditional_22_Template, 2, 0, "button", 23);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const persona_r4 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.iniciales(persona_r4.nombreCompleto));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", persona_r4.nombreCompleto, " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(persona_r4.numeroEmpleado);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(persona_r4.correoInstitucional);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.etiquetaRol(persona_r4.rol));
    \u0275\u0275advance(2);
    \u0275\u0275classProp("activo", persona_r4.activo)("inactivo", !persona_r4.activo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", persona_r4.activo ? "Activo" : "Inactivo", " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(persona_r4.cuentaTemporal ? 15 : -1);
    \u0275\u0275advance(6);
    \u0275\u0275conditional(persona_r4.activo ? 21 : 22);
  }
}
function UsuariosRoles_Conditional_9_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "table", 12)(1, "thead")(2, "tr")(3, "th");
    \u0275\u0275text(4, "Nombre");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "th");
    \u0275\u0275text(6, "Usuario/Boleta");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "th");
    \u0275\u0275text(8, "Correo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "th");
    \u0275\u0275text(10, "Rol Asignado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "th");
    \u0275\u0275text(12, "Estatus");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "th");
    \u0275\u0275text(14, "Acciones");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(15, "tbody");
    \u0275\u0275repeaterCreate(16, UsuariosRoles_Conditional_9_Conditional_7_For_17_Template, 23, 12, "tr", null, _forTrack0);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(16);
    \u0275\u0275repeater(ctx_r1.listaFiltrada);
  }
}
function UsuariosRoles_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 4)(1, "div", 6);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 7);
    \u0275\u0275element(3, "circle", 8)(4, "line", 9);
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(5, "input", 10);
    \u0275\u0275twoWayListener("ngModelChange", function UsuariosRoles_Conditional_9_Template_input_ngModelChange_5_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.busqueda, $event) || (ctx_r1.busqueda = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(6, UsuariosRoles_Conditional_9_Conditional_6_Template, 6, 1, "div", 11)(7, UsuariosRoles_Conditional_9_Conditional_7_Template, 18, 0, "table", 12);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.busqueda);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.listaFiltrada.length === 0 ? 6 : 7);
  }
}
function UsuariosRoles_Conditional_10_For_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 34);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const rol_r8 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275property("value", rol_r8);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.etiquetaRol(rol_r8));
  }
}
function UsuariosRoles_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 25);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_10_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarCrear());
    });
    \u0275\u0275elementStart(1, "div", 26);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_10_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 27)(3, "h3");
    \u0275\u0275text(4, "Registro de Nuevo Personal Administrativo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 28);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_10_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarCrear());
    });
    \u0275\u0275text(6, "\u2715");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 29)(8, "label");
    \u0275\u0275text(9, "Nombre Completo:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "input", 30);
    \u0275\u0275twoWayListener("ngModelChange", function UsuariosRoles_Conditional_10_Template_input_ngModelChange_10_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.nombreCompleto, $event) || (ctx_r1.formulario.nombreCompleto = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 29)(12, "label");
    \u0275\u0275text(13, "N\xFAmero de Empleado / Boleta:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "input", 31);
    \u0275\u0275twoWayListener("ngModelChange", function UsuariosRoles_Conditional_10_Template_input_ngModelChange_14_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.numeroEmpleado, $event) || (ctx_r1.formulario.numeroEmpleado = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 29)(16, "label");
    \u0275\u0275text(17, "Correo Electr\xF3nico Institucional:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "input", 32);
    \u0275\u0275twoWayListener("ngModelChange", function UsuariosRoles_Conditional_10_Template_input_ngModelChange_18_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.correoInstitucional, $event) || (ctx_r1.formulario.correoInstitucional = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(19, "div", 29)(20, "label");
    \u0275\u0275text(21, "Asignar Rol de Sistema:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "select", 33);
    \u0275\u0275twoWayListener("ngModelChange", function UsuariosRoles_Conditional_10_Template_select_ngModelChange_22_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.rol, $event) || (ctx_r1.formulario.rol = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275repeaterCreate(23, UsuariosRoles_Conditional_10_For_24_Template, 2, 2, "option", 34, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(25, "div", 29)(26, "label");
    \u0275\u0275text(27, "Contrase\xF1a Temporal (opcional, se genera una si la dejas vac\xEDa):");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "input", 35);
    \u0275\u0275twoWayListener("ngModelChange", function UsuariosRoles_Conditional_10_Template_input_ngModelChange_28_listener($event) {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.passwordTemporal, $event) || (ctx_r1.formulario.passwordTemporal = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(29, "div", 36)(30, "button", 2);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_10_Template_button_click_30_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.guardarNuevo());
    });
    \u0275\u0275text(31, "Guardar y Activar Usuario");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(32, "button", 37);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_10_Template_button_click_32_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarCrear());
    });
    \u0275\u0275text(33, "Cancelar");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(10);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.nombreCompleto);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.numeroEmpleado);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.correoInstitucional);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.rol);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r1.roles);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.passwordTemporal);
  }
}
function UsuariosRoles_Conditional_11_For_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 34);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const rol_r10 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275property("value", rol_r10);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.etiquetaRol(rol_r10));
  }
}
function UsuariosRoles_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 25);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_11_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarEditar());
    });
    \u0275\u0275elementStart(1, "div", 26);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_11_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 27)(3, "h3");
    \u0275\u0275text(4, "Editar Perfil de Usuario");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 28);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_11_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarEditar());
    });
    \u0275\u0275text(6, "\u2715");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 29)(8, "label");
    \u0275\u0275text(9, "Nombre Completo:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "input", 38);
    \u0275\u0275twoWayListener("ngModelChange", function UsuariosRoles_Conditional_11_Template_input_ngModelChange_10_listener($event) {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.nombreCompleto, $event) || (ctx_r1.formulario.nombreCompleto = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 29)(12, "label");
    \u0275\u0275text(13, "Correo Electr\xF3nico Institucional:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "input", 39);
    \u0275\u0275twoWayListener("ngModelChange", function UsuariosRoles_Conditional_11_Template_input_ngModelChange_14_listener($event) {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.correoInstitucional, $event) || (ctx_r1.formulario.correoInstitucional = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 29)(16, "label");
    \u0275\u0275text(17, "Asignar Rol de Sistema:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "select", 40);
    \u0275\u0275twoWayListener("ngModelChange", function UsuariosRoles_Conditional_11_Template_select_ngModelChange_18_listener($event) {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.rol, $event) || (ctx_r1.formulario.rol = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275repeaterCreate(19, UsuariosRoles_Conditional_11_For_20_Template, 2, 2, "option", 34, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(21, "label", 41)(22, "input", 42);
    \u0275\u0275twoWayListener("ngModelChange", function UsuariosRoles_Conditional_11_Template_input_ngModelChange_22_listener($event) {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.restablecerPassword, $event) || (ctx_r1.formulario.restablecerPassword = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275text(23, " Restablecer contrase\xF1a en el pr\xF3ximo inicio de sesi\xF3n ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "label", 41)(25, "input", 43);
    \u0275\u0275twoWayListener("ngModelChange", function UsuariosRoles_Conditional_11_Template_input_ngModelChange_25_listener($event) {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.desactivarTemporalmente, $event) || (ctx_r1.formulario.desactivarTemporalmente = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275text(26, " Desactivar cuenta temporalmente ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "div", 36)(28, "button", 2);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_11_Template_button_click_28_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.guardarEdicion());
    });
    \u0275\u0275text(29, "Actualizar Informaci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "button", 37);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_11_Template_button_click_30_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarEditar());
    });
    \u0275\u0275text(31, "Volver a la Lista");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(10);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.nombreCompleto);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.correoInstitucional);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.rol);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r1.roles);
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.restablecerPassword);
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.desactivarTemporalmente);
  }
}
function UsuariosRoles_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 25);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_12_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r11);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarModalPassword());
    });
    \u0275\u0275elementStart(1, "div", 26);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_12_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 27)(3, "h3");
    \u0275\u0275text(4, "Contrase\xF1a temporal generada");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 28);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_12_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r11);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarModalPassword());
    });
    \u0275\u0275text(6, "\u2715");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "p", 44);
    \u0275\u0275text(8, " Comparte estos datos de forma segura con ");
    \u0275\u0275elementStart(9, "strong");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275text(11, ". Esta contrase\xF1a solo se muestra esta vez. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "div", 45);
    \u0275\u0275text(13);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "div", 36)(15, "button", 2);
    \u0275\u0275listener("click", function UsuariosRoles_Conditional_12_Template_button_click_15_listener() {
      \u0275\u0275restoreView(_r11);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarModalPassword());
    });
    \u0275\u0275text(16, "Entendido");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate(ctx_r1.correoGenerado);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r1.passwordGenerada);
  }
}
var ROLES_DISPONIBLES = [
  "RECEPCIONISTA",
  "ANALISTA_PRIMER_CONTACTO",
  "SUBDEFENSOR",
  "DEFENSOR",
  "ADMIN_SISTEMAS"
];
var UsuariosRoles = class _UsuariosRoles {
  personalService;
  toast;
  cdr;
  roles = ROLES_DISPONIBLES;
  etiquetaRol = etiquetaRol;
  iniciales = iniciales;
  lista = [];
  cargando = true;
  busqueda = "";
  mostrarModalCrear = false;
  mostrarModalEditar = false;
  mostrarModalPasswordGenerada = false;
  formulario = this.formularioVacio();
  editandoId = null;
  passwordGenerada = "";
  correoGenerado = "";
  constructor(personalService, toast, cdr) {
    this.personalService = personalService;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.cargarLista();
  }
  get listaFiltrada() {
    const termino = this.busqueda.trim().toLowerCase();
    if (!termino)
      return this.lista;
    return this.lista.filter((p) => p.nombreCompleto.toLowerCase().includes(termino) || p.correoInstitucional.toLowerCase().includes(termino) || p.numeroEmpleado.toLowerCase().includes(termino) || this.etiquetaRol(p.rol).toLowerCase().includes(termino));
  }
  cargarLista() {
    this.cargando = true;
    this.personalService.listar().subscribe({
      next: (lista) => {
        this.lista = lista;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.toast.error("No se pudo cargar la lista de personal.");
        this.cdr.detectChanges();
      }
    });
  }
  abrirCrear() {
    this.formulario = this.formularioVacio();
    this.mostrarModalCrear = true;
  }
  cerrarCrear() {
    this.mostrarModalCrear = false;
  }
  guardarNuevo() {
    if (!this.formulario.nombreCompleto || !this.formulario.numeroEmpleado || !this.formulario.correoInstitucional || !this.formulario.rol) {
      this.toast.advertencia("Completa nombre, n\xFAmero de empleado, correo y rol.");
      return;
    }
    this.personalService.crear(this.formulario).subscribe({
      next: (creado) => {
        this.mostrarModalCrear = false;
        this.correoGenerado = creado.correoInstitucional;
        this.passwordGenerada = creado.passwordTemporal;
        this.mostrarModalPasswordGenerada = true;
        this.toast.exito("Usuario creado correctamente.");
        this.cargarLista();
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.toast.error(err?.error?.mensaje ?? "No se pudo crear el usuario.");
        this.cdr.detectChanges();
      }
    });
  }
  abrirEditar(personal) {
    this.editandoId = personal.id;
    this.formulario = {
      nombreCompleto: personal.nombreCompleto,
      correoInstitucional: personal.correoInstitucional,
      rol: personal.rol,
      restablecerPassword: false,
      desactivarTemporalmente: false
    };
    this.mostrarModalEditar = true;
  }
  cerrarEditar() {
    this.mostrarModalEditar = false;
    this.editandoId = null;
  }
  guardarEdicion() {
    if (this.editandoId == null)
      return;
    this.personalService.editar(this.editandoId, this.formulario).subscribe({
      next: () => {
        this.mostrarModalEditar = false;
        this.editandoId = null;
        this.toast.exito("Informaci\xF3n actualizada.");
        this.cargarLista();
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.toast.error(err?.error?.mensaje ?? "No se pudo actualizar la informaci\xF3n.");
        this.cdr.detectChanges();
      }
    });
  }
  resetearPassword(personal) {
    if (!confirm(`\xBFGenerar una nueva contrase\xF1a temporal para ${personal.nombreCompleto}?`))
      return;
    this.personalService.resetearPassword(personal.id).subscribe({
      next: (resp) => {
        this.correoGenerado = personal.correoInstitucional;
        this.passwordGenerada = resp.passwordTemporalNueva;
        this.mostrarModalPasswordGenerada = true;
        this.toast.exito("Contrase\xF1a restablecida.");
        this.cargarLista();
        this.cdr.detectChanges();
      },
      error: () => {
        this.toast.error("No se pudo restablecer la contrase\xF1a.");
        this.cdr.detectChanges();
      }
    });
  }
  darDeBaja(personal) {
    if (!confirm(`\xBFEst\xE1 seguro de dar de baja a ${personal.nombreCompleto}? Perder\xE1 acceso inmediato al sistema.`)) {
      return;
    }
    this.personalService.darDeBaja(personal.id).subscribe({
      next: () => {
        this.toast.exito("Usuario dado de baja.");
        this.cargarLista();
      },
      error: () => {
        this.toast.error("No se pudo dar de baja al usuario.");
        this.cdr.detectChanges();
      }
    });
  }
  reactivar(personal) {
    this.personalService.reactivar(personal.id).subscribe({
      next: () => {
        this.toast.exito("Usuario reactivado.");
        this.cargarLista();
      },
      error: () => {
        this.toast.error("No se pudo reactivar al usuario.");
        this.cdr.detectChanges();
      }
    });
  }
  cerrarModalPassword() {
    this.mostrarModalPasswordGenerada = false;
    this.passwordGenerada = "";
  }
  formularioVacio() {
    return {
      nombreCompleto: "",
      numeroEmpleado: "",
      correoInstitucional: "",
      rol: "RECEPCIONISTA",
      passwordTemporal: ""
    };
  }
  static \u0275fac = function UsuariosRoles_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _UsuariosRoles)(\u0275\u0275directiveInject(PersonalService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _UsuariosRoles, selectors: [["app-usuarios-roles"]], decls: 13, vars: 5, consts: [[1, "page-header"], [1, "page-header-subtitulo"], [1, "btn-primary", 3, "click"], [1, "cargando"], [1, "card"], [1, "modal-overlay"], [1, "buscador"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["cx", "11", "cy", "11", "r", "8"], ["x1", "21", "y1", "21", "x2", "16.65", "y2", "16.65"], ["type", "text", "name", "busqueda", "placeholder", "Buscar por nombre, correo, boleta o rol\u2026", 3, "ngModelChange", "ngModel"], [1, "estado-vacio"], [1, "tabla-admin", "tabla-usuarios"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round", 1, "estado-vacio-icono"], ["d", "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"], ["cx", "9", "cy", "7", "r", "4"], [1, "fila-nombre"], [1, "avatar", "chico"], [1, "badge"], [1, "badge", "temporal"], [1, "acciones"], [1, "btn-texto", 3, "click"], [1, "btn-texto", "peligro"], [1, "btn-texto"], [1, "btn-texto", "peligro", 3, "click"], [1, "modal-overlay", 3, "click"], [1, "modal", "card", 3, "click"], [1, "modal-header"], ["aria-label", "Cerrar", 1, "modal-cerrar", 3, "click"], [1, "input-group"], ["type", "text", "name", "nombreCompleto", 3, "ngModelChange", "ngModel"], ["type", "text", "name", "numeroEmpleado", 3, "ngModelChange", "ngModel"], ["type", "email", "name", "correoInstitucional", 3, "ngModelChange", "ngModel"], ["name", "rol", 3, "ngModelChange", "ngModel"], [3, "value"], ["type", "text", "name", "passwordTemporal", 3, "ngModelChange", "ngModel"], [1, "modal-acciones"], [1, "btn-secondary", 3, "click"], ["type", "text", "name", "nombreCompletoEdit", 3, "ngModelChange", "ngModel"], ["type", "email", "name", "correoInstitucionalEdit", 3, "ngModelChange", "ngModel"], ["name", "rolEdit", 3, "ngModelChange", "ngModel"], [1, "opcion-check"], ["type", "checkbox", "name", "restablecerPassword", 3, "ngModelChange", "ngModel"], ["type", "checkbox", "name", "desactivarTemporalmente", 3, "ngModelChange", "ngModel"], [1, "aviso-inline"], [1, "password-generada"]], template: function UsuariosRoles_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "div")(2, "h2");
      \u0275\u0275text(3, "Gesti\xF3n de Personal Administrativo");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(4, "p", 1);
      \u0275\u0275text(5);
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(6, "button", 2);
      \u0275\u0275listener("click", function UsuariosRoles_Template_button_click_6_listener() {
        return ctx.abrirCrear();
      });
      \u0275\u0275text(7, "+ Agregar Nuevo Usuario");
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(8, UsuariosRoles_Conditional_8_Template, 2, 0, "p", 3)(9, UsuariosRoles_Conditional_9_Template, 8, 2, "div", 4);
      \u0275\u0275conditionalCreate(10, UsuariosRoles_Conditional_10_Template, 34, 5, "div", 5);
      \u0275\u0275conditionalCreate(11, UsuariosRoles_Conditional_11_Template, 32, 5, "div", 5);
      \u0275\u0275conditionalCreate(12, UsuariosRoles_Conditional_12_Template, 17, 2, "div", 5);
    }
    if (rf & 2) {
      \u0275\u0275advance(5);
      \u0275\u0275textInterpolate1("", ctx.lista.length, " cuentas registradas en el sistema.");
      \u0275\u0275advance(3);
      \u0275\u0275conditional(ctx.cargando ? 8 : 9);
      \u0275\u0275advance(2);
      \u0275\u0275conditional(ctx.mostrarModalCrear ? 10 : -1);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.mostrarModalEditar ? 11 : -1);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.mostrarModalPasswordGenerada ? 12 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, NgSelectOption, \u0275NgSelectMultipleOption, DefaultValueAccessor, CheckboxControlValueAccessor, SelectControlValueAccessor, NgControlStatus, NgModel], styles: ["\n.cargando[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.buscador[_ngcontent-%COMP%] {\n  margin-bottom: 16px;\n}\n.fila-nombre[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  font-weight: 500;\n}\n.tabla-usuarios[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], \n.tabla-usuarios[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  vertical-align: middle;\n}\n.acciones[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  flex-wrap: wrap;\n}\n.acciones[_ngcontent-%COMP%]   .peligro[_ngcontent-%COMP%] {\n  color: var(--peligro);\n}\n.opcion-check[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 0.88rem;\n  margin-bottom: 12px;\n  cursor: pointer;\n}\n.opcion-check[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  width: auto;\n}\n.password-generada[_ngcontent-%COMP%] {\n  background: var(--guinda-suave);\n  border: 1px dashed var(--guinda-vivo);\n  border-radius: 6px;\n  padding: 14px;\n  text-align: center;\n  font-size: 1.2rem;\n  font-weight: 700;\n  letter-spacing: 1px;\n  color: var(--guinda);\n  margin-bottom: 6px;\n}\n/*# sourceMappingURL=usuarios-roles.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UsuariosRoles, [{
    type: Component,
    args: [{ selector: "app-usuarios-roles", standalone: true, imports: [CommonModule, FormsModule], template: `<div class="page-header">
  <div>
    <h2>Gesti\xF3n de Personal Administrativo</h2>
    <p class="page-header-subtitulo">{{ lista.length }} cuentas registradas en el sistema.</p>
  </div>
  <button class="btn-primary" (click)="abrirCrear()">+ Agregar Nuevo Usuario</button>
</div>

@if (cargando) {
  <p class="cargando">Cargando personal\u2026</p>
} @else {
  <div class="card">
    <div class="buscador">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
      <input type="text" [(ngModel)]="busqueda" name="busqueda" placeholder="Buscar por nombre, correo, boleta o rol\u2026" />
    </div>

    @if (listaFiltrada.length === 0) {
      <div class="estado-vacio">
        <svg class="estado-vacio-icono" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
        <p>{{ busqueda ? 'Ning\xFAn usuario coincide con tu b\xFAsqueda.' : 'A\xFAn no hay personal registrado.' }}</p>
      </div>
    } @else {
      <table class="tabla-admin tabla-usuarios">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Usuario/Boleta</th>
            <th>Correo</th>
            <th>Rol Asignado</th>
            <th>Estatus</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          @for (persona of listaFiltrada; track persona.id) {
            <tr>
              <td>
                <div class="fila-nombre">
                  <span class="avatar chico">{{ iniciales(persona.nombreCompleto) }}</span>
                  {{ persona.nombreCompleto }}
                </div>
              </td>
              <td>{{ persona.numeroEmpleado }}</td>
              <td>{{ persona.correoInstitucional }}</td>
              <td>{{ etiquetaRol(persona.rol) }}</td>
              <td>
                <span class="badge" [class.activo]="persona.activo" [class.inactivo]="!persona.activo">
                  {{ persona.activo ? 'Activo' : 'Inactivo' }}
                </span>
                @if (persona.cuentaTemporal) {
                  <span class="badge temporal">Temporal</span>
                }
              </td>
              <td class="acciones">
                <button class="btn-texto" (click)="abrirEditar(persona)">Editar</button>
                <button class="btn-texto" (click)="resetearPassword(persona)">Reset. contrase\xF1a</button>
                @if (persona.activo) {
                  <button class="btn-texto peligro" (click)="darDeBaja(persona)">Baja</button>
                } @else {
                  <button class="btn-texto" (click)="reactivar(persona)">Reactivar</button>
                }
              </td>
            </tr>
          }
        </tbody>
      </table>
    }
  </div>
}

@if (mostrarModalCrear) {
  <div class="modal-overlay" (click)="cerrarCrear()">
    <div class="modal card" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>Registro de Nuevo Personal Administrativo</h3>
        <button class="modal-cerrar" (click)="cerrarCrear()" aria-label="Cerrar">\u2715</button>
      </div>

      <div class="input-group">
        <label>Nombre Completo:</label>
        <input type="text" [(ngModel)]="formulario.nombreCompleto" name="nombreCompleto" />
      </div>
      <div class="input-group">
        <label>N\xFAmero de Empleado / Boleta:</label>
        <input type="text" [(ngModel)]="formulario.numeroEmpleado" name="numeroEmpleado" />
      </div>
      <div class="input-group">
        <label>Correo Electr\xF3nico Institucional:</label>
        <input type="email" [(ngModel)]="formulario.correoInstitucional" name="correoInstitucional" />
      </div>
      <div class="input-group">
        <label>Asignar Rol de Sistema:</label>
        <select [(ngModel)]="formulario.rol" name="rol">
          @for (rol of roles; track rol) {
            <option [value]="rol">{{ etiquetaRol(rol) }}</option>
          }
        </select>
      </div>
      <div class="input-group">
        <label>Contrase\xF1a Temporal (opcional, se genera una si la dejas vac\xEDa):</label>
        <input type="text" [(ngModel)]="formulario.passwordTemporal" name="passwordTemporal" />
      </div>

      <div class="modal-acciones">
        <button class="btn-primary" (click)="guardarNuevo()">Guardar y Activar Usuario</button>
        <button class="btn-secondary" (click)="cerrarCrear()">Cancelar</button>
      </div>
    </div>
  </div>
}

@if (mostrarModalEditar) {
  <div class="modal-overlay" (click)="cerrarEditar()">
    <div class="modal card" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>Editar Perfil de Usuario</h3>
        <button class="modal-cerrar" (click)="cerrarEditar()" aria-label="Cerrar">\u2715</button>
      </div>

      <div class="input-group">
        <label>Nombre Completo:</label>
        <input type="text" [(ngModel)]="formulario.nombreCompleto" name="nombreCompletoEdit" />
      </div>
      <div class="input-group">
        <label>Correo Electr\xF3nico Institucional:</label>
        <input type="email" [(ngModel)]="formulario.correoInstitucional" name="correoInstitucionalEdit" />
      </div>
      <div class="input-group">
        <label>Asignar Rol de Sistema:</label>
        <select [(ngModel)]="formulario.rol" name="rolEdit">
          @for (rol of roles; track rol) {
            <option [value]="rol">{{ etiquetaRol(rol) }}</option>
          }
        </select>
      </div>

      <label class="opcion-check">
        <input type="checkbox" [(ngModel)]="formulario.restablecerPassword" name="restablecerPassword" />
        Restablecer contrase\xF1a en el pr\xF3ximo inicio de sesi\xF3n
      </label>
      <label class="opcion-check">
        <input type="checkbox" [(ngModel)]="formulario.desactivarTemporalmente" name="desactivarTemporalmente" />
        Desactivar cuenta temporalmente
      </label>

      <div class="modal-acciones">
        <button class="btn-primary" (click)="guardarEdicion()">Actualizar Informaci\xF3n</button>
        <button class="btn-secondary" (click)="cerrarEditar()">Volver a la Lista</button>
      </div>
    </div>
  </div>
}

@if (mostrarModalPasswordGenerada) {
  <div class="modal-overlay" (click)="cerrarModalPassword()">
    <div class="modal card" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>Contrase\xF1a temporal generada</h3>
        <button class="modal-cerrar" (click)="cerrarModalPassword()" aria-label="Cerrar">\u2715</button>
      </div>
      <p class="aviso-inline">
        Comparte estos datos de forma segura con <strong>{{ correoGenerado }}</strong>. Esta
        contrase\xF1a solo se muestra esta vez.
      </p>
      <div class="password-generada">{{ passwordGenerada }}</div>
      <div class="modal-acciones">
        <button class="btn-primary" (click)="cerrarModalPassword()">Entendido</button>
      </div>
    </div>
  </div>
}
`, styles: ["/* src/app/pages/usuarios-roles/usuarios-roles.scss */\n.cargando {\n  color: var(--texto-suave);\n}\n.buscador {\n  margin-bottom: 16px;\n}\n.fila-nombre {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  font-weight: 500;\n}\n.tabla-usuarios th,\n.tabla-usuarios td {\n  vertical-align: middle;\n}\n.acciones {\n  display: flex;\n  gap: 10px;\n  flex-wrap: wrap;\n}\n.acciones .peligro {\n  color: var(--peligro);\n}\n.opcion-check {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 0.88rem;\n  margin-bottom: 12px;\n  cursor: pointer;\n}\n.opcion-check input {\n  width: auto;\n}\n.password-generada {\n  background: var(--guinda-suave);\n  border: 1px dashed var(--guinda-vivo);\n  border-radius: 6px;\n  padding: 14px;\n  text-align: center;\n  font-size: 1.2rem;\n  font-weight: 700;\n  letter-spacing: 1px;\n  color: var(--guinda);\n  margin-bottom: 6px;\n}\n/*# sourceMappingURL=usuarios-roles.css.map */\n"] }]
  }], () => [{ type: PersonalService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(UsuariosRoles, { className: "UsuariosRoles", filePath: "src/app/pages/usuarios-roles/usuarios-roles.ts", lineNumber: 24 });
})();
export {
  UsuariosRoles
};
//# sourceMappingURL=chunk-654ZYCGY.js.map
