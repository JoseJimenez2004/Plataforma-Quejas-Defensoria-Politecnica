import {
  CheckboxControlValueAccessor,
  DefaultValueAccessor,
  FormsModule,
  MaxLengthValidator,
  MinValidator,
  NgControlStatus,
  NgControlStatusGroup,
  NgForm,
  NgModel,
  NgSelectOption,
  NumberValueAccessor,
  SelectControlValueAccessor,
  ɵNgNoValidate,
  ɵNgSelectMultipleOption
} from "./chunk-Y3SUXXGM.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  HttpClient,
  Injectable,
  ToastService,
  __spreadProps,
  __spreadValues,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-3WR4SCJM.js";

// src/app/core/services/chatbot-admin.service.ts
var ChatbotAdminService = class _ChatbotAdminService {
  http;
  apiUrl = "/api/chatbot/admin/preguntas";
  constructor(http) {
    this.http = http;
  }
  listar() {
    return this.http.get(this.apiUrl);
  }
  crear(datos) {
    return this.http.post(this.apiUrl, datos);
  }
  editar(id, datos) {
    return this.http.put(`${this.apiUrl}/${id}`, datos);
  }
  eliminar(id) {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
  static \u0275fac = function ChatbotAdminService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _ChatbotAdminService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _ChatbotAdminService, factory: _ChatbotAdminService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ChatbotAdminService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/chatbot/chatbot.ts
var _forTrack0 = ($index, $item) => $item.id;
function Chatbot_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 3);
    \u0275\u0275text(1, "Cargando preguntas\u2026");
    \u0275\u0275elementEnd();
  }
}
function Chatbot_Conditional_9_For_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 9);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const c_r3 = ctx.$implicit;
    \u0275\u0275property("value", c_r3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(c_r3);
  }
}
function Chatbot_Conditional_9_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 13)(1, "p");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.preguntas.length === 0 ? "Todav\xEDa no hay preguntas. Crea la primera." : "Ninguna pregunta coincide con los filtros.");
  }
}
function Chatbot_Conditional_9_Conditional_15_For_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "tr")(1, "td", 16);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td")(4, "span", 19);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "td")(7, "strong", 20);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "span", 21);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "td")(12, "button", 22);
    \u0275\u0275listener("click", function Chatbot_Conditional_9_Conditional_15_For_16_Template_button_click_12_listener() {
      const p_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.alternarActivo(p_r5));
    });
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "td", 17)(15, "button", 23);
    \u0275\u0275listener("click", function Chatbot_Conditional_9_Conditional_15_For_16_Template_button_click_15_listener() {
      const p_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.editar(p_r5));
    });
    \u0275\u0275text(16, "Editar");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "button", 24);
    \u0275\u0275listener("click", function Chatbot_Conditional_9_Conditional_15_For_16_Template_button_click_17_listener() {
      const p_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.confirmarEliminar(p_r5));
    });
    \u0275\u0275text(18, "Eliminar");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const p_r5 = ctx.$implicit;
    \u0275\u0275classProp("inactiva", !p_r5.activo);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(p_r5.orden);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(p_r5.categoria);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(p_r5.pregunta);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(p_r5.respuesta);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("activo", p_r5.activo);
    \u0275\u0275property("title", p_r5.activo ? "Clic para ocultarla del chatbot" : "Clic para mostrarla en el chatbot");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", p_r5.activo ? "Visible" : "Oculta", " ");
  }
}
function Chatbot_Conditional_9_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 14)(1, "table", 15)(2, "thead")(3, "tr")(4, "th", 16);
    \u0275\u0275text(5, "Orden");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "th");
    \u0275\u0275text(7, "Categor\xEDa");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "th");
    \u0275\u0275text(9, "Pregunta y respuesta");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "th");
    \u0275\u0275text(11, "Estado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "th", 17);
    \u0275\u0275text(13, "Acciones");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(14, "tbody");
    \u0275\u0275repeaterCreate(15, Chatbot_Conditional_9_Conditional_15_For_16_Template, 19, 10, "tr", 18, _forTrack0);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(15);
    \u0275\u0275repeater(ctx_r1.filtradas);
  }
}
function Chatbot_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 5)(1, "input", 6);
    \u0275\u0275twoWayListener("ngModelChange", function Chatbot_Conditional_9_Template_input_ngModelChange_1_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.filtroTexto, $event) || (ctx_r1.filtroTexto = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "select", 7);
    \u0275\u0275twoWayListener("ngModelChange", function Chatbot_Conditional_9_Template_select_ngModelChange_2_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.filtroCategoria, $event) || (ctx_r1.filtroCategoria = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementStart(3, "option", 8);
    \u0275\u0275text(4, "Todas las categor\xEDas");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(5, Chatbot_Conditional_9_For_6_Template, 2, 2, "option", 9, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "select", 10);
    \u0275\u0275twoWayListener("ngModelChange", function Chatbot_Conditional_9_Template_select_ngModelChange_7_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.filtroEstado, $event) || (ctx_r1.filtroEstado = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementStart(8, "option", 8);
    \u0275\u0275text(9, "Visibles y ocultas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "option", 11);
    \u0275\u0275text(11, "Solo visibles");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "option", 12);
    \u0275\u0275text(13, "Solo ocultas");
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(14, Chatbot_Conditional_9_Conditional_14_Template, 3, 1, "div", 13)(15, Chatbot_Conditional_9_Conditional_15_Template, 17, 0, "div", 14);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.filtroTexto);
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.filtroCategoria);
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r1.categorias);
    \u0275\u0275advance(2);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.filtroEstado);
    \u0275\u0275advance(7);
    \u0275\u0275conditional(ctx_r1.filtradas.length === 0 ? 14 : 15);
  }
}
function Chatbot_Conditional_10_For_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "option", 9);
  }
  if (rf & 2) {
    const c_r7 = ctx.$implicit;
    \u0275\u0275property("value", c_r7);
  }
}
function Chatbot_Conditional_10_Conditional_32_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 44);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorFormulario);
  }
}
function Chatbot_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 25);
    \u0275\u0275listener("click", function Chatbot_Conditional_10_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    \u0275\u0275elementStart(1, "form", 26);
    \u0275\u0275listener("click", function Chatbot_Conditional_10_Template_form_click_1_listener($event) {
      return $event.stopPropagation();
    })("submit", function Chatbot_Conditional_10_Template_form_submit_1_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      $event.preventDefault();
      return \u0275\u0275resetView(ctx_r1.guardar());
    });
    \u0275\u0275elementStart(2, "div", 27)(3, "h3");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 28);
    \u0275\u0275listener("click", function Chatbot_Conditional_10_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    \u0275\u0275text(6, "\xD7");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 29)(8, "div", 30)(9, "label", 31);
    \u0275\u0275text(10, "Categor\xEDa");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "input", 32);
    \u0275\u0275twoWayListener("ngModelChange", function Chatbot_Conditional_10_Template_input_ngModelChange_11_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.categoria, $event) || (ctx_r1.formulario.categoria = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "datalist", 33);
    \u0275\u0275repeaterCreate(13, Chatbot_Conditional_10_For_14_Template, 1, 1, "option", 9, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 34)(16, "label", 35);
    \u0275\u0275text(17, "Orden");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "input", 36);
    \u0275\u0275twoWayListener("ngModelChange", function Chatbot_Conditional_10_Template_input_ngModelChange_18_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.orden, $event) || (ctx_r1.formulario.orden = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(19, "div", 30)(20, "label", 37);
    \u0275\u0275text(21, "Pregunta");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "input", 38);
    \u0275\u0275twoWayListener("ngModelChange", function Chatbot_Conditional_10_Template_input_ngModelChange_22_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.pregunta, $event) || (ctx_r1.formulario.pregunta = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "span", 39);
    \u0275\u0275text(24);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(25, "div", 30)(26, "label", 40);
    \u0275\u0275text(27, "Respuesta");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "textarea", 41);
    \u0275\u0275twoWayListener("ngModelChange", function Chatbot_Conditional_10_Template_textarea_ngModelChange_28_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.respuesta, $event) || (ctx_r1.formulario.respuesta = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(29, "label", 42)(30, "input", 43);
    \u0275\u0275twoWayListener("ngModelChange", function Chatbot_Conditional_10_Template_input_ngModelChange_30_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.activo, $event) || (ctx_r1.formulario.activo = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275text(31, " Visible en el chatbot del portal ");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(32, Chatbot_Conditional_10_Conditional_32_Template, 2, 1, "p", 44);
    \u0275\u0275elementStart(33, "div", 45)(34, "button", 46);
    \u0275\u0275listener("click", function Chatbot_Conditional_10_Template_button_click_34_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    \u0275\u0275text(35, "Cancelar");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(36, "button", 47);
    \u0275\u0275text(37);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.editando ? "Editar pregunta" : "Nueva pregunta");
    \u0275\u0275advance(7);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.categoria);
    \u0275\u0275property("maxlength", ctx_r1.categoriaMaxima);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r1.categorias);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.orden);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.pregunta);
    \u0275\u0275property("maxlength", ctx_r1.preguntaMaxima);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", ctx_r1.formulario.pregunta.length, " / ", ctx_r1.preguntaMaxima);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.respuesta);
    \u0275\u0275advance(2);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.activo);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r1.errorFormulario ? 32 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275property("disabled", ctx_r1.guardando);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.guardando ? "Guardando\u2026" : "Guardar");
  }
}
function Chatbot_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 25);
    \u0275\u0275listener("click", function Chatbot_Conditional_11_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.porEliminar = null);
    });
    \u0275\u0275elementStart(1, "div", 48);
    \u0275\u0275listener("click", function Chatbot_Conditional_11_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 27)(3, "h3");
    \u0275\u0275text(4, "\xBFEliminar esta pregunta?");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "p")(6, "strong");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "p", 49);
    \u0275\u0275text(9, "Se borra definitivamente. Si solo quieres que deje de verse, mejor m\xE1rcala como oculta.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "div", 45)(11, "button", 46);
    \u0275\u0275listener("click", function Chatbot_Conditional_11_Template_button_click_11_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.porEliminar = null);
    });
    \u0275\u0275text(12, "Cancelar");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "button", 50);
    \u0275\u0275listener("click", function Chatbot_Conditional_11_Template_button_click_13_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.eliminar());
    });
    \u0275\u0275text(14, "Eliminar");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(ctx_r1.porEliminar.pregunta);
  }
}
var PREGUNTA_MAXIMA = 300;
var CATEGORIA_MAXIMA = 80;
var Chatbot = class _Chatbot {
  chatbotService;
  toast;
  cdr;
  preguntaMaxima = PREGUNTA_MAXIMA;
  categoriaMaxima = CATEGORIA_MAXIMA;
  preguntas = [];
  cargando = true;
  filtroTexto = "";
  filtroCategoria = "";
  filtroEstado = "";
  modalAbierto = false;
  editando = null;
  formulario = this.vacio();
  errorFormulario = "";
  guardando = false;
  porEliminar = null;
  constructor(chatbotService, toast, cdr) {
    this.chatbotService = chatbotService;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.cargar();
  }
  get categorias() {
    return [...new Set(this.preguntas.map((p) => p.categoria))].sort((a, b) => a.localeCompare(b, "es"));
  }
  get filtradas() {
    const texto = this.normalizar(this.filtroTexto);
    return this.preguntas.filter((p) => !this.filtroCategoria || p.categoria === this.filtroCategoria).filter((p) => this.filtroEstado === "" || this.filtroEstado === "activas" === p.activo).filter((p) => !texto || this.normalizar(p.pregunta).includes(texto) || this.normalizar(p.respuesta).includes(texto) || this.normalizar(p.categoria).includes(texto)).sort((a, b) => a.categoria.localeCompare(b.categoria, "es") || a.orden - b.orden);
  }
  get totalActivas() {
    return this.preguntas.filter((p) => p.activo).length;
  }
  // ---------------- modal ----------------
  nueva() {
    this.editando = null;
    const siguienteOrden = this.preguntas.reduce((max, p) => Math.max(max, p.orden ?? 0), 0) + 1;
    this.formulario = __spreadProps(__spreadValues({}, this.vacio()), { categoria: this.filtroCategoria, orden: siguienteOrden });
    this.errorFormulario = "";
    this.modalAbierto = true;
  }
  editar(p) {
    this.editando = p;
    this.formulario = {
      categoria: p.categoria,
      pregunta: p.pregunta,
      respuesta: p.respuesta,
      orden: p.orden,
      activo: p.activo
    };
    this.errorFormulario = "";
    this.modalAbierto = true;
  }
  cerrarModal() {
    this.modalAbierto = false;
    this.guardando = false;
  }
  guardar() {
    const datos = {
      categoria: this.formulario.categoria.trim(),
      pregunta: this.formulario.pregunta.trim(),
      respuesta: this.formulario.respuesta.trim(),
      orden: Number(this.formulario.orden) || 0,
      activo: this.formulario.activo
    };
    if (!datos.categoria || !datos.pregunta || !datos.respuesta) {
      this.errorFormulario = "Completa categor\xEDa, pregunta y respuesta.";
      return;
    }
    if (datos.pregunta.length > PREGUNTA_MAXIMA || datos.categoria.length > CATEGORIA_MAXIMA) {
      this.errorFormulario = `La pregunta admite ${PREGUNTA_MAXIMA} caracteres y la categor\xEDa ${CATEGORIA_MAXIMA}.`;
      return;
    }
    this.guardando = true;
    const peticion = this.editando ? this.chatbotService.editar(this.editando.id, datos) : this.chatbotService.crear(datos);
    peticion.subscribe({
      next: () => {
        this.toast.exito(this.editando ? "Pregunta actualizada." : "Pregunta creada.");
        this.cerrarModal();
        this.cargar();
      },
      error: (err) => {
        this.guardando = false;
        this.errorFormulario = err?.error?.mensaje ?? "No se pudo guardar la pregunta.";
        this.cdr.detectChanges();
      }
    });
  }
  // ---------------- activar / eliminar ----------------
  alternarActivo(p) {
    const datos = {
      categoria: p.categoria,
      pregunta: p.pregunta,
      respuesta: p.respuesta,
      orden: p.orden,
      activo: !p.activo
    };
    this.chatbotService.editar(p.id, datos).subscribe({
      next: () => {
        p.activo = !p.activo;
        this.toast.exito(p.activo ? "La pregunta ya se muestra en el chatbot." : "La pregunta se ocult\xF3 del chatbot.");
        this.cdr.detectChanges();
      },
      error: (err) => this.toast.error(err?.error?.mensaje ?? "No se pudo cambiar el estado.")
    });
  }
  confirmarEliminar(p) {
    this.porEliminar = p;
  }
  eliminar() {
    const p = this.porEliminar;
    if (!p) {
      return;
    }
    this.chatbotService.eliminar(p.id).subscribe({
      next: () => {
        this.toast.exito("Pregunta eliminada.");
        this.porEliminar = null;
        this.cargar();
      },
      error: (err) => {
        this.porEliminar = null;
        this.toast.error(err?.error?.mensaje ?? "No se pudo eliminar la pregunta.");
        this.cdr.detectChanges();
      }
    });
  }
  // ---------------- utilidades ----------------
  cargar() {
    this.cargando = true;
    this.chatbotService.listar().subscribe({
      next: (lista) => {
        this.preguntas = lista;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.toast.error("No se pudieron cargar las preguntas del chatbot.");
        this.cdr.detectChanges();
      }
    });
  }
  vacio() {
    return { categoria: "", pregunta: "", respuesta: "", orden: 0, activo: true };
  }
  normalizar(texto) {
    return (texto ?? "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
  }
  static \u0275fac = function Chatbot_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Chatbot)(\u0275\u0275directiveInject(ChatbotAdminService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Chatbot, selectors: [["app-chatbot"]], decls: 12, vars: 5, consts: [[1, "page-header"], [1, "page-header-subtitulo"], ["type", "button", 1, "btn-primary", 3, "click"], [1, "cargando"], [1, "modal-overlay"], [1, "card", "filtros"], ["type", "search", "placeholder", "Buscar en preguntas y respuestas\u2026", "name", "filtroTexto", 1, "filtro-texto", 3, "ngModelChange", "ngModel"], ["name", "filtroCategoria", 3, "ngModelChange", "ngModel"], ["value", ""], [3, "value"], ["name", "filtroEstado", 3, "ngModelChange", "ngModel"], ["value", "activas"], ["value", "inactivas"], [1, "card", "estado-vacio"], [1, "card", "tabla-contenedor"], [1, "tabla-admin"], [1, "col-orden"], [1, "col-acciones"], [3, "inactiva"], [1, "categoria"], [1, "pregunta"], [1, "respuesta"], ["type", "button", 1, "badge", "estado", 3, "click", "title"], ["type", "button", 1, "btn-texto", 3, "click"], ["type", "button", 1, "btn-texto", "peligro", 3, "click"], [1, "modal-overlay", 3, "click"], [1, "modal", 3, "click", "submit"], [1, "modal-header"], ["type", "button", "aria-label", "Cerrar", 1, "cerrar", 3, "click"], [1, "fila-modal"], [1, "input-group"], ["for", "bot-categoria"], ["id", "bot-categoria", "list", "bot-categorias", "name", "categoria", "placeholder", "Ej. Presentar una queja", 3, "ngModelChange", "ngModel", "maxlength"], ["id", "bot-categorias"], [1, "input-group", "orden"], ["for", "bot-orden"], ["id", "bot-orden", "type", "number", "min", "0", "name", "orden", 3, "ngModelChange", "ngModel"], ["for", "bot-pregunta"], ["id", "bot-pregunta", "name", "pregunta", 3, "ngModelChange", "ngModel", "maxlength"], [1, "contador"], ["for", "bot-respuesta"], ["id", "bot-respuesta", "rows", "6", "name", "respuesta", 3, "ngModelChange", "ngModel"], [1, "casilla"], ["type", "checkbox", "name", "activo", 3, "ngModelChange", "ngModel"], [1, "aviso-peligro"], [1, "modal-acciones"], ["type", "button", 1, "btn-secondary", 3, "click"], ["type", "submit", 1, "btn-primary", 3, "disabled"], [1, "modal", 3, "click"], [1, "aviso-inline"], ["type", "button", 1, "btn-primary", "peligro", 3, "click"]], template: function Chatbot_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "div")(2, "h2");
      \u0275\u0275text(3, "Preguntas del Chatbot");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(4, "p", 1);
      \u0275\u0275text(5);
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(6, "button", 2);
      \u0275\u0275listener("click", function Chatbot_Template_button_click_6_listener() {
        return ctx.nueva();
      });
      \u0275\u0275text(7, "+ Nueva pregunta");
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(8, Chatbot_Conditional_8_Template, 2, 0, "p", 3)(9, Chatbot_Conditional_9_Template, 16, 4);
      \u0275\u0275conditionalCreate(10, Chatbot_Conditional_10_Template, 38, 13, "div", 4);
      \u0275\u0275conditionalCreate(11, Chatbot_Conditional_11_Template, 15, 1, "div", 4);
    }
    if (rf & 2) {
      \u0275\u0275advance(5);
      \u0275\u0275textInterpolate2(" Lo que ve el p\xFAblico en el asistente del portal. ", ctx.totalActivas, " de ", ctx.preguntas.length, " preguntas visibles. ");
      \u0275\u0275advance(3);
      \u0275\u0275conditional(ctx.cargando ? 8 : 9);
      \u0275\u0275advance(2);
      \u0275\u0275conditional(ctx.modalAbierto ? 10 : -1);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.porEliminar ? 11 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, \u0275NgNoValidate, NgSelectOption, \u0275NgSelectMultipleOption, DefaultValueAccessor, NumberValueAccessor, CheckboxControlValueAccessor, SelectControlValueAccessor, NgControlStatus, NgControlStatusGroup, MaxLengthValidator, MinValidator, NgModel, NgForm], styles: ["\n.page-header[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  justify-content: space-between;\n  gap: 16px;\n  flex-wrap: wrap;\n}\n.filtros[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(0, 2fr) minmax(0, 1fr) minmax(0, 1fr);\n  gap: 12px;\n  margin-bottom: 16px;\n}\n.filtros[_ngcontent-%COMP%]   input[_ngcontent-%COMP%], \n.filtros[_ngcontent-%COMP%]   select[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 9px 12px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font: inherit;\n  font-size: 0.88rem;\n  background: #fff;\n}\n@media (max-width: 760px) {\n  .filtros[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n}\n.tabla-contenedor[_ngcontent-%COMP%] {\n  overflow-x: auto;\n  padding: 0;\n}\n.col-orden[_ngcontent-%COMP%] {\n  width: 70px;\n  text-align: center;\n}\n.col-acciones[_ngcontent-%COMP%] {\n  width: 150px;\n  white-space: nowrap;\n}\n.categoria[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding: 3px 9px;\n  border-radius: 999px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-size: 0.78rem;\n  font-weight: 600;\n}\n.pregunta[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 4px;\n}\n.respuesta[_ngcontent-%COMP%] {\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n  font-size: 0.84rem;\n  color: var(--texto-suave);\n}\ntr.inactiva[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  opacity: 0.6;\n}\n.estado[_ngcontent-%COMP%] {\n  border: none;\n  cursor: pointer;\n  background: #eee;\n  color: var(--texto-suave);\n}\n.estado.activo[_ngcontent-%COMP%] {\n  background: var(--acento-verde-suave);\n  color: var(--acento-verde);\n}\n.peligro[_ngcontent-%COMP%] {\n  color: var(--peligro);\n}\n.btn-primary.peligro[_ngcontent-%COMP%] {\n  background: var(--peligro);\n  color: #fff;\n}\n.fila-modal[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) 110px;\n  gap: 12px;\n}\n.contador[_ngcontent-%COMP%] {\n  display: block;\n  text-align: right;\n  font-size: 0.75rem;\n  color: var(--texto-suave);\n}\n.cerrar[_ngcontent-%COMP%] {\n  border: none;\n  background: none;\n  font-size: 1.4rem;\n  cursor: pointer;\n}\n.casilla[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin: 8px 0 12px;\n  font-weight: 500;\n}\n.casilla[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  width: 17px;\n  height: 17px;\n  accent-color: var(--guinda);\n}\n.modal[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {\n  width: 100%;\n  font: inherit;\n}\n/*# sourceMappingURL=chatbot.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Chatbot, [{
    type: Component,
    args: [{ selector: "app-chatbot", standalone: true, imports: [CommonModule, FormsModule], template: `<div class="page-header">
  <div>
    <h2>Preguntas del Chatbot</h2>
    <p class="page-header-subtitulo">
      Lo que ve el p\xFAblico en el asistente del portal. {{ totalActivas }} de {{ preguntas.length }} preguntas visibles.
    </p>
  </div>
  <button type="button" class="btn-primary" (click)="nueva()">+ Nueva pregunta</button>
</div>

@if (cargando) {
  <p class="cargando">Cargando preguntas\u2026</p>
} @else {
  <div class="card filtros">
    <input type="search" class="filtro-texto" placeholder="Buscar en preguntas y respuestas\u2026"
           [(ngModel)]="filtroTexto" name="filtroTexto" />
    <select [(ngModel)]="filtroCategoria" name="filtroCategoria">
      <option value="">Todas las categor\xEDas</option>
      @for (c of categorias; track c) { <option [value]="c">{{ c }}</option> }
    </select>
    <select [(ngModel)]="filtroEstado" name="filtroEstado">
      <option value="">Visibles y ocultas</option>
      <option value="activas">Solo visibles</option>
      <option value="inactivas">Solo ocultas</option>
    </select>
  </div>

  @if (filtradas.length === 0) {
    <div class="card estado-vacio">
      <p>{{ preguntas.length === 0 ? 'Todav\xEDa no hay preguntas. Crea la primera.' : 'Ninguna pregunta coincide con los filtros.' }}</p>
    </div>
  } @else {
    <div class="card tabla-contenedor">
      <table class="tabla-admin">
        <thead>
          <tr>
            <th class="col-orden">Orden</th>
            <th>Categor\xEDa</th>
            <th>Pregunta y respuesta</th>
            <th>Estado</th>
            <th class="col-acciones">Acciones</th>
          </tr>
        </thead>
        <tbody>
          @for (p of filtradas; track p.id) {
            <tr [class.inactiva]="!p.activo">
              <td class="col-orden">{{ p.orden }}</td>
              <td><span class="categoria">{{ p.categoria }}</span></td>
              <td>
                <strong class="pregunta">{{ p.pregunta }}</strong>
                <span class="respuesta">{{ p.respuesta }}</span>
              </td>
              <td>
                <button type="button" class="badge estado" [class.activo]="p.activo" (click)="alternarActivo(p)"
                        [title]="p.activo ? 'Clic para ocultarla del chatbot' : 'Clic para mostrarla en el chatbot'">
                  {{ p.activo ? 'Visible' : 'Oculta' }}
                </button>
              </td>
              <td class="col-acciones">
                <button type="button" class="btn-texto" (click)="editar(p)">Editar</button>
                <button type="button" class="btn-texto peligro" (click)="confirmarEliminar(p)">Eliminar</button>
              </td>
            </tr>
          }
        </tbody>
      </table>
    </div>
  }
}

@if (modalAbierto) {
  <div class="modal-overlay" (click)="cerrarModal()">
    <form class="modal" (click)="$event.stopPropagation()" (submit)="$event.preventDefault(); guardar()">
      <div class="modal-header">
        <h3>{{ editando ? 'Editar pregunta' : 'Nueva pregunta' }}</h3>
        <button type="button" class="cerrar" (click)="cerrarModal()" aria-label="Cerrar">\xD7</button>
      </div>

      <div class="fila-modal">
        <div class="input-group">
          <label for="bot-categoria">Categor\xEDa</label>
          <input id="bot-categoria" list="bot-categorias" [(ngModel)]="formulario.categoria" name="categoria"
                 [maxlength]="categoriaMaxima" placeholder="Ej. Presentar una queja" />
          <datalist id="bot-categorias">
            @for (c of categorias; track c) { <option [value]="c"></option> }
          </datalist>
        </div>
        <div class="input-group orden">
          <label for="bot-orden">Orden</label>
          <input id="bot-orden" type="number" min="0" [(ngModel)]="formulario.orden" name="orden" />
        </div>
      </div>

      <div class="input-group">
        <label for="bot-pregunta">Pregunta</label>
        <input id="bot-pregunta" [(ngModel)]="formulario.pregunta" name="pregunta" [maxlength]="preguntaMaxima" />
        <span class="contador">{{ formulario.pregunta.length }} / {{ preguntaMaxima }}</span>
      </div>

      <div class="input-group">
        <label for="bot-respuesta">Respuesta</label>
        <textarea id="bot-respuesta" rows="6" [(ngModel)]="formulario.respuesta" name="respuesta"></textarea>
      </div>

      <label class="casilla">
        <input type="checkbox" [(ngModel)]="formulario.activo" name="activo" />
        Visible en el chatbot del portal
      </label>

      @if (errorFormulario) { <p class="aviso-peligro">{{ errorFormulario }}</p> }

      <div class="modal-acciones">
        <button type="button" class="btn-secondary" (click)="cerrarModal()">Cancelar</button>
        <button type="submit" class="btn-primary" [disabled]="guardando">{{ guardando ? 'Guardando\u2026' : 'Guardar' }}</button>
      </div>
    </form>
  </div>
}

@if (porEliminar) {
  <div class="modal-overlay" (click)="porEliminar = null">
    <div class="modal" (click)="$event.stopPropagation()">
      <div class="modal-header"><h3>\xBFEliminar esta pregunta?</h3></div>
      <p><strong>{{ porEliminar.pregunta }}</strong></p>
      <p class="aviso-inline">Se borra definitivamente. Si solo quieres que deje de verse, mejor m\xE1rcala como oculta.</p>
      <div class="modal-acciones">
        <button type="button" class="btn-secondary" (click)="porEliminar = null">Cancelar</button>
        <button type="button" class="btn-primary peligro" (click)="eliminar()">Eliminar</button>
      </div>
    </div>
  </div>
}
`, styles: ["/* src/app/pages/chatbot/chatbot.scss */\n.page-header {\n  display: flex;\n  align-items: flex-start;\n  justify-content: space-between;\n  gap: 16px;\n  flex-wrap: wrap;\n}\n.filtros {\n  display: grid;\n  grid-template-columns: minmax(0, 2fr) minmax(0, 1fr) minmax(0, 1fr);\n  gap: 12px;\n  margin-bottom: 16px;\n}\n.filtros input,\n.filtros select {\n  width: 100%;\n  padding: 9px 12px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font: inherit;\n  font-size: 0.88rem;\n  background: #fff;\n}\n@media (max-width: 760px) {\n  .filtros {\n    grid-template-columns: 1fr;\n  }\n}\n.tabla-contenedor {\n  overflow-x: auto;\n  padding: 0;\n}\n.col-orden {\n  width: 70px;\n  text-align: center;\n}\n.col-acciones {\n  width: 150px;\n  white-space: nowrap;\n}\n.categoria {\n  display: inline-block;\n  padding: 3px 9px;\n  border-radius: 999px;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-size: 0.78rem;\n  font-weight: 600;\n}\n.pregunta {\n  display: block;\n  margin-bottom: 4px;\n}\n.respuesta {\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n  font-size: 0.84rem;\n  color: var(--texto-suave);\n}\ntr.inactiva td {\n  opacity: 0.6;\n}\n.estado {\n  border: none;\n  cursor: pointer;\n  background: #eee;\n  color: var(--texto-suave);\n}\n.estado.activo {\n  background: var(--acento-verde-suave);\n  color: var(--acento-verde);\n}\n.peligro {\n  color: var(--peligro);\n}\n.btn-primary.peligro {\n  background: var(--peligro);\n  color: #fff;\n}\n.fila-modal {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) 110px;\n  gap: 12px;\n}\n.contador {\n  display: block;\n  text-align: right;\n  font-size: 0.75rem;\n  color: var(--texto-suave);\n}\n.cerrar {\n  border: none;\n  background: none;\n  font-size: 1.4rem;\n  cursor: pointer;\n}\n.casilla {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin: 8px 0 12px;\n  font-weight: 500;\n}\n.casilla input {\n  width: 17px;\n  height: 17px;\n  accent-color: var(--guinda);\n}\n.modal textarea {\n  width: 100%;\n  font: inherit;\n}\n/*# sourceMappingURL=chatbot.css.map */\n"] }]
  }], () => [{ type: ChatbotAdminService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Chatbot, { className: "Chatbot", filePath: "src/app/pages/chatbot/chatbot.ts", lineNumber: 20 });
})();
export {
  Chatbot
};
//# sourceMappingURL=chunk-SZVSHDLA.js.map
