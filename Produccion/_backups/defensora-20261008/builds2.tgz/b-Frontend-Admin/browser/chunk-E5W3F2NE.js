import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel,
  NgSelectOption,
  SelectControlValueAccessor,
  ɵNgSelectMultipleOption
} from "./chunk-Y3SUXXGM.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  HttpClient,
  Injectable,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-3WR4SCJM.js";

// src/app/core/services/plantilla.service.ts
var PlantillaService = class _PlantillaService {
  http;
  apiUrl = "/api/admin/plantillas";
  constructor(http) {
    this.http = http;
  }
  listar() {
    return this.http.get(this.apiUrl);
  }
  placeholders() {
    return this.http.get(`${this.apiUrl}/placeholders`);
  }
  obtener(tipo) {
    return this.http.get(`${this.apiUrl}/${tipo}`);
  }
  previsualizar(tipo) {
    return this.http.get(`${this.apiUrl}/${tipo}/previsualizar`, { responseType: "text" });
  }
  actualizar(tipo, contenido) {
    return this.http.put(`${this.apiUrl}/${tipo}`, { contenido });
  }
  static \u0275fac = function PlantillaService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _PlantillaService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _PlantillaService, factory: _PlantillaService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PlantillaService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/plantillas/plantillas.ts
var _forTrack0 = ($index, $item) => $item.tipo;
function Plantillas_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 2);
    \u0275\u0275text(1, "Cargando plantillas\u2026");
    \u0275\u0275elementEnd();
  }
}
function Plantillas_Conditional_7_For_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 6);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r3 = ctx.$implicit;
    \u0275\u0275property("value", p_r3.tipo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(p_r3.nombre);
  }
}
function Plantillas_Conditional_7_For_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r4 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(item_r4);
  }
}
function Plantillas_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 4)(1, "label");
    \u0275\u0275text(2, "Seleccione el documento a editar:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "select", 5);
    \u0275\u0275listener("change", function Plantillas_Conditional_7_Template_select_change_3_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onCambioSelector($event));
    });
    \u0275\u0275repeaterCreate(4, Plantillas_Conditional_7_For_5_Template, 2, 2, "option", 6, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 7)(7, "textarea", 8);
    \u0275\u0275twoWayListener("ngModelChange", function Plantillas_Conditional_7_Template_textarea_ngModelChange_7_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.contenido, $event) || (ctx_r1.contenido = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p", 9);
    \u0275\u0275text(9, "Placeholders disponibles:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "ul", 10);
    \u0275\u0275repeaterCreate(11, Plantillas_Conditional_7_For_12_Template, 2, 1, "li", null, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "div", 11)(14, "button", 12);
    \u0275\u0275listener("click", function Plantillas_Conditional_7_Template_button_click_14_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.guardar());
    });
    \u0275\u0275text(15);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "button", 13);
    \u0275\u0275listener("click", function Plantillas_Conditional_7_Template_button_click_16_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.verPrevisualizacion());
    });
    \u0275\u0275text(17, "Ver Previsualizaci\xF3n");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275property("ngModel", ctx_r1.tipoSeleccionado);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r1.lista);
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.contenido);
    \u0275\u0275advance(4);
    \u0275\u0275repeater(ctx_r1.listaPlaceholders);
    \u0275\u0275advance(3);
    \u0275\u0275property("disabled", ctx_r1.guardando);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.guardando ? "Guardando\u2026" : "Guardar Cambios y Publicar Plantilla", " ");
  }
}
function Plantillas_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 14);
    \u0275\u0275listener("click", function Plantillas_Conditional_8_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarPrevisualizacion());
    });
    \u0275\u0275elementStart(1, "div", 15);
    \u0275\u0275listener("click", function Plantillas_Conditional_8_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 16)(3, "h3");
    \u0275\u0275text(4, "Previsualizaci\xF3n (con datos de ejemplo)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 17);
    \u0275\u0275listener("click", function Plantillas_Conditional_8_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarPrevisualizacion());
    });
    \u0275\u0275text(6, "\u2715");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 18);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "div", 19)(10, "button", 20);
    \u0275\u0275listener("click", function Plantillas_Conditional_8_Template_button_click_10_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarPrevisualizacion());
    });
    \u0275\u0275text(11, "Cerrar");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(ctx_r1.textoPrevisualizacion);
  }
}
var Plantillas = class _Plantillas {
  plantillaService;
  toast;
  cdr;
  lista = [];
  placeholders = {};
  cargando = true;
  guardando = false;
  tipoSeleccionado = "";
  contenido = "";
  mostrarPrevisualizacion = false;
  textoPrevisualizacion = "";
  constructor(plantillaService, toast, cdr) {
    this.plantillaService = plantillaService;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.plantillaService.placeholders().subscribe({
      next: (p) => this.placeholders = p
    });
    this.plantillaService.listar().subscribe({
      next: (lista) => {
        this.lista = lista;
        this.cargando = false;
        if (lista.length) {
          this.seleccionar(lista[0].tipo);
        }
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.toast.error("No se pudieron cargar las plantillas.");
        this.cdr.detectChanges();
      }
    });
  }
  seleccionar(tipo) {
    this.tipoSeleccionado = tipo;
    const plantilla = this.lista.find((p) => p.tipo === tipo);
    this.contenido = plantilla?.contenido ?? "";
  }
  onCambioSelector(event) {
    const tipo = event.target.value;
    this.seleccionar(tipo);
  }
  guardar() {
    if (!this.tipoSeleccionado)
      return;
    this.guardando = true;
    this.plantillaService.actualizar(this.tipoSeleccionado, this.contenido).subscribe({
      next: (actualizada) => {
        this.guardando = false;
        const indice = this.lista.findIndex((p) => p.tipo === actualizada.tipo);
        if (indice >= 0)
          this.lista[indice] = actualizada;
        this.toast.exito("Plantilla guardada y publicada.");
        this.cdr.detectChanges();
      },
      error: () => {
        this.guardando = false;
        this.toast.error("No se pudo guardar la plantilla.");
        this.cdr.detectChanges();
      }
    });
  }
  verPrevisualizacion() {
    if (!this.tipoSeleccionado)
      return;
    this.plantillaService.previsualizar(this.tipoSeleccionado).subscribe({
      next: (texto) => {
        this.textoPrevisualizacion = texto;
        this.mostrarPrevisualizacion = true;
        this.cdr.detectChanges();
      },
      error: () => this.toast.error("No se pudo generar la previsualizaci\xF3n.")
    });
  }
  cerrarPrevisualizacion() {
    this.mostrarPrevisualizacion = false;
  }
  get listaPlaceholders() {
    return Object.keys(this.placeholders).map((clave) => `{${clave}} \u2014 ${this.placeholders[clave]}`);
  }
  static \u0275fac = function Plantillas_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Plantillas)(\u0275\u0275directiveInject(PlantillaService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Plantillas, selectors: [["app-plantillas"]], decls: 9, vars: 2, consts: [[1, "page-header"], [1, "page-header-subtitulo"], [1, "cargando"], [1, "modal-overlay"], [1, "input-group", "selector"], ["name", "tipoSeleccionado", 3, "change", "ngModel"], [3, "value"], [1, "card"], ["rows", "10", "name", "contenido", 3, "ngModelChange", "ngModel"], [1, "hint"], [1, "lista-placeholders"], [1, "acciones"], [1, "btn-primary", 3, "click", "disabled"], [1, "btn-secondary", 3, "click"], [1, "modal-overlay", 3, "click"], [1, "modal", "card", 3, "click"], [1, "modal-header"], ["aria-label", "Cerrar", 1, "modal-cerrar", 3, "click"], [1, "hoja-previsualizacion"], [1, "modal-acciones"], [1, "btn-primary", 3, "click"]], template: function Plantillas_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "div")(2, "h2");
      \u0275\u0275text(3, "Configuraci\xF3n de Plantillas y Oficios");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(4, "p", 1);
      \u0275\u0275text(5, "Edita los formatos oficiales que se generan autom\xE1ticamente.");
      \u0275\u0275elementEnd()()();
      \u0275\u0275conditionalCreate(6, Plantillas_Conditional_6_Template, 2, 0, "p", 2)(7, Plantillas_Conditional_7_Template, 18, 4);
      \u0275\u0275conditionalCreate(8, Plantillas_Conditional_8_Template, 12, 1, "div", 3);
    }
    if (rf & 2) {
      \u0275\u0275advance(6);
      \u0275\u0275conditional(ctx.cargando ? 6 : 7);
      \u0275\u0275advance(2);
      \u0275\u0275conditional(ctx.mostrarPrevisualizacion ? 8 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, NgSelectOption, \u0275NgSelectMultipleOption, DefaultValueAccessor, SelectControlValueAccessor, NgControlStatus, NgModel], styles: ['\n.cargando[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.selector[_ngcontent-%COMP%] {\n  max-width: 420px;\n}\ntextarea[_ngcontent-%COMP%] {\n  font-family: "Courier New", monospace;\n  font-size: 0.88rem;\n  min-height: 220px;\n}\n.hint[_ngcontent-%COMP%] {\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n  margin: 14px 0 4px;\n}\n.lista-placeholders[_ngcontent-%COMP%] {\n  margin: 0 0 16px;\n  padding-left: 18px;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.lista-placeholders[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin-bottom: 2px;\n}\n.acciones[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n}\n.hoja-previsualizacion[_ngcontent-%COMP%] {\n  background: var(--gris-fondo);\n  border: 1px solid var(--borde);\n  border-radius: 6px;\n  padding: 16px;\n  white-space: pre-wrap;\n  font-size: 0.9rem;\n  line-height: 1.5;\n  max-height: 50vh;\n  overflow-y: auto;\n}\n/*# sourceMappingURL=plantillas.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Plantillas, [{
    type: Component,
    args: [{ selector: "app-plantillas", standalone: true, imports: [CommonModule, FormsModule], template: `<div class="page-header">
  <div>
    <h2>Configuraci\xF3n de Plantillas y Oficios</h2>
    <p class="page-header-subtitulo">Edita los formatos oficiales que se generan autom\xE1ticamente.</p>
  </div>
</div>

@if (cargando) {
  <p class="cargando">Cargando plantillas\u2026</p>
} @else {
  <div class="input-group selector">
    <label>Seleccione el documento a editar:</label>
    <select [ngModel]="tipoSeleccionado" (change)="onCambioSelector($event)" name="tipoSeleccionado">
      @for (p of lista; track p.tipo) {
        <option [value]="p.tipo">{{ p.nombre }}</option>
      }
    </select>
  </div>

  <div class="card">
    <textarea rows="10" [(ngModel)]="contenido" name="contenido"></textarea>

    <p class="hint">Placeholders disponibles:</p>
    <ul class="lista-placeholders">
      @for (item of listaPlaceholders; track item) {
        <li>{{ item }}</li>
      }
    </ul>

    <div class="acciones">
      <button class="btn-primary" (click)="guardar()" [disabled]="guardando">
        {{ guardando ? 'Guardando\u2026' : 'Guardar Cambios y Publicar Plantilla' }}
      </button>
      <button class="btn-secondary" (click)="verPrevisualizacion()">Ver Previsualizaci\xF3n</button>
    </div>
  </div>
}

@if (mostrarPrevisualizacion) {
  <div class="modal-overlay" (click)="cerrarPrevisualizacion()">
    <div class="modal card" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>Previsualizaci\xF3n (con datos de ejemplo)</h3>
        <button class="modal-cerrar" (click)="cerrarPrevisualizacion()" aria-label="Cerrar">\u2715</button>
      </div>
      <div class="hoja-previsualizacion">{{ textoPrevisualizacion }}</div>
      <div class="modal-acciones">
        <button class="btn-primary" (click)="cerrarPrevisualizacion()">Cerrar</button>
      </div>
    </div>
  </div>
}
`, styles: ['/* src/app/pages/plantillas/plantillas.scss */\n.cargando {\n  color: var(--texto-suave);\n}\n.selector {\n  max-width: 420px;\n}\ntextarea {\n  font-family: "Courier New", monospace;\n  font-size: 0.88rem;\n  min-height: 220px;\n}\n.hint {\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n  margin: 14px 0 4px;\n}\n.lista-placeholders {\n  margin: 0 0 16px;\n  padding-left: 18px;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.lista-placeholders li {\n  margin-bottom: 2px;\n}\n.acciones {\n  display: flex;\n  gap: 12px;\n}\n.hoja-previsualizacion {\n  background: var(--gris-fondo);\n  border: 1px solid var(--borde);\n  border-radius: 6px;\n  padding: 16px;\n  white-space: pre-wrap;\n  font-size: 0.9rem;\n  line-height: 1.5;\n  max-height: 50vh;\n  overflow-y: auto;\n}\n/*# sourceMappingURL=plantillas.css.map */\n'] }]
  }], () => [{ type: PlantillaService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Plantillas, { className: "Plantillas", filePath: "src/app/pages/plantillas/plantillas.ts", lineNumber: 16 });
})();
export {
  Plantillas
};
//# sourceMappingURL=chunk-E5W3F2NE.js.map
