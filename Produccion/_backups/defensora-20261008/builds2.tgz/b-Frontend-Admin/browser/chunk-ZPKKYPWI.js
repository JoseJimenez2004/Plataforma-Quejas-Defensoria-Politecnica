import {
  RouterLink
} from "./chunk-UNI6KQ5Z.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  HttpClient,
  Injectable,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵinject,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵstyleProp,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-3WR4SCJM.js";

// src/app/core/services/dashboard.service.ts
var DashboardService = class _DashboardService {
  http;
  apiUrl = "/api/admin/dashboard";
  constructor(http) {
    this.http = http;
  }
  resumen() {
    return this.http.get(`${this.apiUrl}/resumen`);
  }
  static \u0275fac = function DashboardService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DashboardService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _DashboardService, factory: _DashboardService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DashboardService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/dashboard/dashboard.ts
var _forTrack0 = ($index, $item) => $item.clave;
function Dashboard_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 2);
    \u0275\u0275text(1, "Cargando resumen\u2026");
    \u0275\u0275elementEnd();
  }
}
function Dashboard_Conditional_7_Conditional_0_For_50_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 44)(1, "span", 46);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275element(3, "span", 47);
    \u0275\u0275elementStart(4, "span", 48);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const m_r1 = ctx.$implicit;
    const q_r2 = \u0275\u0275nextContext();
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275property("title", m_r1.total + " quejas en " + m_r1.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(m_r1.total);
    \u0275\u0275advance();
    \u0275\u0275styleProp("height", ctx_r2.maximo(q_r2.porMes) ? m_r1.total / ctx_r2.maximo(q_r2.porMes) * 100 : 0, "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r2.nombreMes(m_r1.etiqueta));
  }
}
function Dashboard_Conditional_7_Conditional_0_Conditional_54_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 15);
    \u0275\u0275text(1, "Todav\xEDa no hay quejas con unidad registrada.");
    \u0275\u0275elementEnd();
  }
}
function Dashboard_Conditional_7_Conditional_0_Conditional_55_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li")(1, "span", 49);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 50);
    \u0275\u0275element(4, "span");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 51);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const u_r4 = ctx.$implicit;
    const q_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("title", u_r4.clave);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(u_r4.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", u_r4.total / q_r2.unidadesConMasQuejas[0].total * 100, "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(u_r4.total);
  }
}
function Dashboard_Conditional_7_Conditional_0_Conditional_55_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ul", 45);
    \u0275\u0275repeaterCreate(1, Dashboard_Conditional_7_Conditional_0_Conditional_55_For_2_Template, 7, 5, "li", null, _forTrack0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const q_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275repeater(q_r2.unidadesConMasQuejas);
  }
}
function Dashboard_Conditional_7_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 3)(1, "h3", 4);
    \u0275\u0275text(2, "Quejas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 33)(4, "div", 34)(5, "span", 35);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "span", 36);
    \u0275\u0275text(8, "Total registradas");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 34)(10, "span", 35);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "span", 36);
    \u0275\u0275text(13, "\xDAltimos 30 d\xEDas");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "div", 37)(15, "span", 35);
    \u0275\u0275text(16);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "span", 36);
    \u0275\u0275text(18, "Esperando revisi\xF3n");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(19, "div", 38)(20, "span", 35);
    \u0275\u0275text(21);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "span", 36);
    \u0275\u0275text(23, "En validaci\xF3n");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(24, "div", 39)(25, "span", 35);
    \u0275\u0275text(26);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "span", 36);
    \u0275\u0275text(28);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(29, "div", 40)(30, "span", 35);
    \u0275\u0275text(31);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(32, "span", 36);
    \u0275\u0275text(33, "Rechazadas");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(34, "div", 34)(35, "span", 35);
    \u0275\u0275text(36);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "span", 36);
    \u0275\u0275text(38, "Canceladas por el quejoso");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(39, "div", 34)(40, "span", 35);
    \u0275\u0275text(41);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(42, "span", 36);
    \u0275\u0275text(43, "Respuestas de denunciados");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(44, "div", 41)(45, "div", 42)(46, "h4");
    \u0275\u0275text(47, "Quejas por mes");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(48, "div", 43);
    \u0275\u0275repeaterCreate(49, Dashboard_Conditional_7_Conditional_0_For_50_Template, 6, 5, "div", 44, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(51, "div", 42)(52, "h4");
    \u0275\u0275text(53, "Unidades con m\xE1s quejas");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(54, Dashboard_Conditional_7_Conditional_0_Conditional_54_Template, 2, 0, "p", 15)(55, Dashboard_Conditional_7_Conditional_0_Conditional_55_Template, 3, 0, "ul", 45);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const q_r2 = ctx;
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(q_r2.total);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(q_r2.ultimos30Dias);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(q_r2.recibidas + q_r2.corregidas);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(q_r2.enValidacion);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(q_r2.turnadas);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Turnadas (", q_r2.turnadasEsteMes, " este mes)");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(q_r2.rechazadas);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(q_r2.canceladas);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(q_r2.respuestasDenunciado);
    \u0275\u0275advance(8);
    \u0275\u0275repeater(q_r2.porMes);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(q_r2.unidadesConMasQuejas.length === 0 ? 54 : 55);
  }
}
function Dashboard_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, Dashboard_Conditional_7_Conditional_0_Template, 56, 10, "section", 3);
    \u0275\u0275elementStart(1, "h3", 4);
    \u0275\u0275text(2, "Administraci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 5)(4, "div", 6)(5, "div", 7)(6, "span", 8);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(7, "svg", 9);
    \u0275\u0275element(8, "path", 10)(9, "circle", 11)(10, "path", 12)(11, "path", 13);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(12, "h3");
    \u0275\u0275text(13, "Estado del Personal");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "p", 14);
    \u0275\u0275text(15);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "p", 15);
    \u0275\u0275text(17, "usuarios registrados");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "a", 16);
    \u0275\u0275text(19, "Gestionar Usuarios");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(20, "div", 6)(21, "div", 7)(22, "span", 17);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(23, "svg", 9);
    \u0275\u0275element(24, "path", 18)(25, "path", 19)(26, "path", 20);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(27, "h3");
    \u0275\u0275text(28, "Directorio IPN");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(29, "p", 14);
    \u0275\u0275text(30);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "p", 15);
    \u0275\u0275text(32, "Unidades Acad\xE9micas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(33, "a", 21);
    \u0275\u0275text(34, "Actualizar Cat\xE1logo");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(35, "div", 6)(36, "div", 7)(37, "span", 22);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(38, "svg", 9);
    \u0275\u0275element(39, "path", 23);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(40, "h3");
    \u0275\u0275text(41, "Seguridad");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(42, "p", 24);
    \u0275\u0275text(43, "\xDAltimo respaldo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(44, "p", 25);
    \u0275\u0275text(45);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "a", 26);
    \u0275\u0275text(47, "Ver Bit\xE1cora");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(48, "div", 6)(49, "div", 7)(50, "span", 27);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(51, "svg", 9);
    \u0275\u0275element(52, "path", 28)(53, "polyline", 29)(54, "line", 30)(55, "line", 31);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(56, "h3");
    \u0275\u0275text(57, "Formatos Legales");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(58, "p", 14);
    \u0275\u0275text(59);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(60, "p", 15);
    \u0275\u0275text(61, "Plantillas activas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(62, "a", 32);
    \u0275\u0275text(63, "Editar Formatos");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    let tmp_1_0;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275conditional((tmp_1_0 = ctx_r2.resumen.quejas) ? 0 : -1, tmp_1_0);
    \u0275\u0275advance(15);
    \u0275\u0275textInterpolate(ctx_r2.resumen.totalPersonalActivo);
    \u0275\u0275advance(15);
    \u0275\u0275textInterpolate(ctx_r2.resumen.totalDependencias);
    \u0275\u0275advance(15);
    \u0275\u0275textInterpolate(ctx_r2.resumen.ultimoRespaldo);
    \u0275\u0275advance(14);
    \u0275\u0275textInterpolate(ctx_r2.resumen.totalPlantillasActivas);
  }
}
var Dashboard = class _Dashboard {
  dashboardService;
  toast;
  cdr;
  resumen = null;
  cargando = true;
  constructor(dashboardService, toast, cdr) {
    this.dashboardService = dashboardService;
    this.toast = toast;
    this.cdr = cdr;
  }
  static MESES = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
  maximo(lista) {
    return lista.reduce((max, x) => Math.max(max, x.total), 0);
  }
  /** "2026-10" -> "Oct" */
  nombreMes(clave) {
    const mes = Number(clave.split("-")[1]);
    return _Dashboard.MESES[mes - 1] ?? clave;
  }
  ngOnInit() {
    this.dashboardService.resumen().subscribe({
      next: (resumen) => {
        this.resumen = resumen;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.toast.error("No se pudo cargar el resumen del sistema.");
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function Dashboard_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Dashboard)(\u0275\u0275directiveInject(DashboardService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Dashboard, selectors: [["app-dashboard"]], decls: 8, vars: 1, consts: [[1, "page-header"], [1, "page-header-subtitulo"], [1, "cargando"], [1, "quejas"], [1, "seccion-titulo"], [1, "tarjetas"], [1, "card", "tarjeta"], [1, "tarjeta-encabezado"], [1, "icono-acento", "azul"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"], ["cx", "9", "cy", "7", "r", "4"], ["d", "M23 21v-2a4 4 0 0 0-3-3.87"], ["d", "M16 3.13a4 4 0 0 1 0 7.75"], [1, "dato-numero"], [1, "dato-etiqueta"], ["routerLink", "/usuarios-roles", 1, "btn-primary"], [1, "icono-acento", "morado"], ["d", "M3 21h18"], ["d", "M5 21V7l7-4 7 4v14"], ["d", "M10 21v-5h4v5"], ["routerLink", "/catalogo-dependencias", 1, "btn-primary"], [1, "icono-acento", "verde"], ["d", "M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6z"], [1, "dato-texto"], [1, "dato-etiqueta", "dato-etiqueta-fuerte"], ["routerLink", "/seguridad-respaldos", 1, "btn-primary"], [1, "icono-acento", "ambar"], ["d", "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"], ["points", "14 2 14 8 20 8"], ["x1", "8", "y1", "13", "x2", "16", "y2", "13"], ["x1", "8", "y1", "17", "x2", "16", "y2", "17"], ["routerLink", "/plantillas", 1, "btn-primary"], [1, "kpis"], [1, "kpi"], [1, "kpi-valor"], [1, "kpi-etiqueta"], [1, "kpi", "ambar"], [1, "kpi", "azul"], [1, "kpi", "verde"], [1, "kpi", "rojo"], [1, "graficas"], [1, "card", "grafica"], [1, "barras"], [1, "barra-col", 3, "title"], [1, "ranking"], [1, "barra-valor"], [1, "barra"], [1, "barra-etiqueta"], [1, "ranking-nombre", 3, "title"], [1, "ranking-barra"], [1, "ranking-total"]], template: function Dashboard_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "div")(2, "h2");
      \u0275\u0275text(3, "Panel de la Defensora");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(4, "p", 1);
      \u0275\u0275text(5, "Panorama de las quejas y de la administraci\xF3n del sistema.");
      \u0275\u0275elementEnd()()();
      \u0275\u0275conditionalCreate(6, Dashboard_Conditional_6_Template, 2, 0, "p", 2)(7, Dashboard_Conditional_7_Template, 64, 5);
    }
    if (rf & 2) {
      \u0275\u0275advance(6);
      \u0275\u0275conditional(ctx.cargando ? 6 : ctx.resumen ? 7 : -1);
    }
  }, dependencies: [CommonModule, RouterLink], styles: ["\n.cargando[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.tarjetas[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 20px;\n}\n@media (max-width: 700px) {\n  .tarjetas[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n}\n.tarjeta[_ngcontent-%COMP%] {\n  transition: box-shadow 0.2s ease, transform 0.2s ease;\n}\n.tarjeta[_ngcontent-%COMP%]:hover {\n  box-shadow: var(--sombra-media);\n  transform: translateY(-2px);\n}\n.tarjeta-encabezado[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  margin-bottom: 14px;\n}\n.tarjeta-encabezado[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 0.95rem;\n}\n.tarjeta[_ngcontent-%COMP%]   .dato-numero[_ngcontent-%COMP%] {\n  font-size: 2.1rem;\n  font-weight: 700;\n  color: var(--negro-inst);\n  margin: 0 0 2px;\n  line-height: 1.1;\n}\n.tarjeta[_ngcontent-%COMP%]   .dato-texto[_ngcontent-%COMP%] {\n  font-size: 0.85rem;\n  color: var(--texto-suave);\n  margin: 0;\n}\n.tarjeta[_ngcontent-%COMP%]   .dato-etiqueta[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 0.85rem;\n  margin: 0 0 18px;\n}\n.tarjeta[_ngcontent-%COMP%]   .dato-etiqueta-fuerte[_ngcontent-%COMP%] {\n  color: var(--negro-inst);\n  font-weight: 600;\n  font-size: 0.95rem;\n}\n.tarjeta[_ngcontent-%COMP%]   .btn-primary[_ngcontent-%COMP%] {\n  display: inline-block;\n  text-decoration: none;\n  font-size: 0.85rem;\n}\n.seccion-titulo[_ngcontent-%COMP%] {\n  margin: 8px 0 12px;\n  font-size: 1rem;\n  color: var(--texto);\n}\n.kpis[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));\n  gap: 12px;\n  margin-bottom: 16px;\n}\n.kpi[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  padding: 14px 16px;\n  border-radius: 10px;\n  border-left: 4px solid var(--borde);\n  background: #fff;\n  box-shadow: var(--sombra-suave);\n}\n.kpi.ambar[_ngcontent-%COMP%] {\n  border-left-color: var(--acento-ambar);\n}\n.kpi.azul[_ngcontent-%COMP%] {\n  border-left-color: var(--acento-azul);\n}\n.kpi.verde[_ngcontent-%COMP%] {\n  border-left-color: var(--acento-verde);\n}\n.kpi.rojo[_ngcontent-%COMP%] {\n  border-left-color: var(--peligro);\n}\n.kpi-valor[_ngcontent-%COMP%] {\n  font-size: 1.6rem;\n  font-weight: 700;\n  color: var(--negro-inst);\n}\n.kpi-etiqueta[_ngcontent-%COMP%] {\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.graficas[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));\n  gap: 16px;\n  margin-bottom: 24px;\n}\n.graficas[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0 0 14px;\n  font-size: 0.92rem;\n}\n.barras[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-end;\n  gap: 10px;\n  height: 160px;\n}\n.barra-col[_ngcontent-%COMP%] {\n  flex: 1;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: flex-end;\n  align-items: center;\n  gap: 4px;\n}\n.barra[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 42px;\n  min-height: 2px;\n  border-radius: 6px 6px 0 0;\n  background: var(--guinda);\n}\n.barra-valor[_ngcontent-%COMP%], \n.barra-etiqueta[_ngcontent-%COMP%] {\n  font-size: 0.75rem;\n  color: var(--texto-suave);\n}\n.ranking[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 10px;\n}\n.ranking[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(0, 140px) minmax(0, 1fr) 32px;\n  align-items: center;\n  gap: 10px;\n  font-size: 0.85rem;\n}\n.ranking-nombre[_ngcontent-%COMP%] {\n  overflow: hidden;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n}\n.ranking-barra[_ngcontent-%COMP%] {\n  height: 10px;\n  border-radius: 5px;\n  background: var(--gris-fondo);\n}\n.ranking-barra[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  display: block;\n  height: 100%;\n  border-radius: 5px;\n  background: var(--guinda-vivo);\n}\n.ranking-total[_ngcontent-%COMP%] {\n  text-align: right;\n  font-weight: 600;\n}\n/*# sourceMappingURL=dashboard.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Dashboard, [{
    type: Component,
    args: [{ selector: "app-dashboard", standalone: true, imports: [CommonModule, RouterLink], template: `<div class="page-header">
  <div>
    <h2>Panel de la Defensora</h2>
    <p class="page-header-subtitulo">Panorama de las quejas y de la administraci\xF3n del sistema.</p>
  </div>
</div>

@if (cargando) {
  <p class="cargando">Cargando resumen\u2026</p>
} @else if (resumen) {
  @if (resumen.quejas; as q) {
    <section class="quejas">
      <h3 class="seccion-titulo">Quejas</h3>
      <div class="kpis">
        <div class="kpi"><span class="kpi-valor">{{ q.total }}</span><span class="kpi-etiqueta">Total registradas</span></div>
        <div class="kpi"><span class="kpi-valor">{{ q.ultimos30Dias }}</span><span class="kpi-etiqueta">\xDAltimos 30 d\xEDas</span></div>
        <div class="kpi ambar"><span class="kpi-valor">{{ q.recibidas + q.corregidas }}</span><span class="kpi-etiqueta">Esperando revisi\xF3n</span></div>
        <div class="kpi azul"><span class="kpi-valor">{{ q.enValidacion }}</span><span class="kpi-etiqueta">En validaci\xF3n</span></div>
        <div class="kpi verde"><span class="kpi-valor">{{ q.turnadas }}</span><span class="kpi-etiqueta">Turnadas ({{ q.turnadasEsteMes }} este mes)</span></div>
        <div class="kpi rojo"><span class="kpi-valor">{{ q.rechazadas }}</span><span class="kpi-etiqueta">Rechazadas</span></div>
        <div class="kpi"><span class="kpi-valor">{{ q.canceladas }}</span><span class="kpi-etiqueta">Canceladas por el quejoso</span></div>
        <div class="kpi"><span class="kpi-valor">{{ q.respuestasDenunciado }}</span><span class="kpi-etiqueta">Respuestas de denunciados</span></div>
      </div>

      <div class="graficas">
        <div class="card grafica">
          <h4>Quejas por mes</h4>
          <div class="barras">
            @for (m of q.porMes; track m.clave) {
              <div class="barra-col" [title]="m.total + ' quejas en ' + m.etiqueta">
                <span class="barra-valor">{{ m.total }}</span>
                <span class="barra" [style.height.%]="maximo(q.porMes) ? (m.total / maximo(q.porMes)) * 100 : 0"></span>
                <span class="barra-etiqueta">{{ nombreMes(m.etiqueta) }}</span>
              </div>
            }
          </div>
        </div>
        <div class="card grafica">
          <h4>Unidades con m\xE1s quejas</h4>
          @if (q.unidadesConMasQuejas.length === 0) {
            <p class="dato-etiqueta">Todav\xEDa no hay quejas con unidad registrada.</p>
          } @else {
            <ul class="ranking">
              @for (u of q.unidadesConMasQuejas; track u.clave) {
                <li>
                  <span class="ranking-nombre" [title]="u.clave">{{ u.etiqueta }}</span>
                  <span class="ranking-barra"><span [style.width.%]="(u.total / q.unidadesConMasQuejas[0].total) * 100"></span></span>
                  <span class="ranking-total">{{ u.total }}</span>
                </li>
              }
            </ul>
          }
        </div>
      </div>
    </section>
  }

  <h3 class="seccion-titulo">Administraci\xF3n</h3>
  <div class="tarjetas">
    <div class="card tarjeta">
      <div class="tarjeta-encabezado">
        <span class="icono-acento azul">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
        </span>
        <h3>Estado del Personal</h3>
      </div>
      <p class="dato-numero">{{ resumen.totalPersonalActivo }}</p>
      <p class="dato-etiqueta">usuarios registrados</p>
      <a routerLink="/usuarios-roles" class="btn-primary">Gestionar Usuarios</a>
    </div>

    <div class="card tarjeta">
      <div class="tarjeta-encabezado">
        <span class="icono-acento morado">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"></path><path d="M5 21V7l7-4 7 4v14"></path><path d="M10 21v-5h4v5"></path></svg>
        </span>
        <h3>Directorio IPN</h3>
      </div>
      <p class="dato-numero">{{ resumen.totalDependencias }}</p>
      <p class="dato-etiqueta">Unidades Acad\xE9micas</p>
      <a routerLink="/catalogo-dependencias" class="btn-primary">Actualizar Cat\xE1logo</a>
    </div>

    <div class="card tarjeta">
      <div class="tarjeta-encabezado">
        <span class="icono-acento verde">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6z"></path></svg>
        </span>
        <h3>Seguridad</h3>
      </div>
      <p class="dato-texto">\xDAltimo respaldo</p>
      <p class="dato-etiqueta dato-etiqueta-fuerte">{{ resumen.ultimoRespaldo }}</p>
      <a routerLink="/seguridad-respaldos" class="btn-primary">Ver Bit\xE1cora</a>
    </div>

    <div class="card tarjeta">
      <div class="tarjeta-encabezado">
        <span class="icono-acento ambar">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="8" y1="13" x2="16" y2="13"></line><line x1="8" y1="17" x2="16" y2="17"></line></svg>
        </span>
        <h3>Formatos Legales</h3>
      </div>
      <p class="dato-numero">{{ resumen.totalPlantillasActivas }}</p>
      <p class="dato-etiqueta">Plantillas activas</p>
      <a routerLink="/plantillas" class="btn-primary">Editar Formatos</a>
    </div>
  </div>
}
`, styles: ["/* src/app/pages/dashboard/dashboard.scss */\n.cargando {\n  color: var(--texto-suave);\n}\n.tarjetas {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 20px;\n}\n@media (max-width: 700px) {\n  .tarjetas {\n    grid-template-columns: 1fr;\n  }\n}\n.tarjeta {\n  transition: box-shadow 0.2s ease, transform 0.2s ease;\n}\n.tarjeta:hover {\n  box-shadow: var(--sombra-media);\n  transform: translateY(-2px);\n}\n.tarjeta-encabezado {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  margin-bottom: 14px;\n}\n.tarjeta-encabezado h3 {\n  margin: 0;\n  font-size: 0.95rem;\n}\n.tarjeta .dato-numero {\n  font-size: 2.1rem;\n  font-weight: 700;\n  color: var(--negro-inst);\n  margin: 0 0 2px;\n  line-height: 1.1;\n}\n.tarjeta .dato-texto {\n  font-size: 0.85rem;\n  color: var(--texto-suave);\n  margin: 0;\n}\n.tarjeta .dato-etiqueta {\n  color: var(--texto-suave);\n  font-size: 0.85rem;\n  margin: 0 0 18px;\n}\n.tarjeta .dato-etiqueta-fuerte {\n  color: var(--negro-inst);\n  font-weight: 600;\n  font-size: 0.95rem;\n}\n.tarjeta .btn-primary {\n  display: inline-block;\n  text-decoration: none;\n  font-size: 0.85rem;\n}\n.seccion-titulo {\n  margin: 8px 0 12px;\n  font-size: 1rem;\n  color: var(--texto);\n}\n.kpis {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));\n  gap: 12px;\n  margin-bottom: 16px;\n}\n.kpi {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  padding: 14px 16px;\n  border-radius: 10px;\n  border-left: 4px solid var(--borde);\n  background: #fff;\n  box-shadow: var(--sombra-suave);\n}\n.kpi.ambar {\n  border-left-color: var(--acento-ambar);\n}\n.kpi.azul {\n  border-left-color: var(--acento-azul);\n}\n.kpi.verde {\n  border-left-color: var(--acento-verde);\n}\n.kpi.rojo {\n  border-left-color: var(--peligro);\n}\n.kpi-valor {\n  font-size: 1.6rem;\n  font-weight: 700;\n  color: var(--negro-inst);\n}\n.kpi-etiqueta {\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.graficas {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));\n  gap: 16px;\n  margin-bottom: 24px;\n}\n.graficas h4 {\n  margin: 0 0 14px;\n  font-size: 0.92rem;\n}\n.barras {\n  display: flex;\n  align-items: flex-end;\n  gap: 10px;\n  height: 160px;\n}\n.barra-col {\n  flex: 1;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: flex-end;\n  align-items: center;\n  gap: 4px;\n}\n.barra {\n  width: 100%;\n  max-width: 42px;\n  min-height: 2px;\n  border-radius: 6px 6px 0 0;\n  background: var(--guinda);\n}\n.barra-valor,\n.barra-etiqueta {\n  font-size: 0.75rem;\n  color: var(--texto-suave);\n}\n.ranking {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 10px;\n}\n.ranking li {\n  display: grid;\n  grid-template-columns: minmax(0, 140px) minmax(0, 1fr) 32px;\n  align-items: center;\n  gap: 10px;\n  font-size: 0.85rem;\n}\n.ranking-nombre {\n  overflow: hidden;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n}\n.ranking-barra {\n  height: 10px;\n  border-radius: 5px;\n  background: var(--gris-fondo);\n}\n.ranking-barra span {\n  display: block;\n  height: 100%;\n  border-radius: 5px;\n  background: var(--guinda-vivo);\n}\n.ranking-total {\n  text-align: right;\n  font-weight: 600;\n}\n/*# sourceMappingURL=dashboard.css.map */\n"] }]
  }], () => [{ type: DashboardService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Dashboard, { className: "Dashboard", filePath: "src/app/pages/dashboard/dashboard.ts", lineNumber: 16 });
})();
export {
  Dashboard
};
//# sourceMappingURL=chunk-ZPKKYPWI.js.map
