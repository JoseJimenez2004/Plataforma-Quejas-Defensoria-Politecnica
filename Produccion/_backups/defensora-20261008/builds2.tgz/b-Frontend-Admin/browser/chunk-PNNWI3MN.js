import {
  HttpClient,
  Injectable,
  __spreadProps,
  __spreadValues,
  setClassMetadata,
  signal,
  tap,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-3WR4SCJM.js";

// src/app/core/sesion/sesion-personal.ts
var RUTA_LOGIN_PERSONAL = "/revision/login";
var ROLES_DEFENSORA = ["DEFENSOR", "ADMIN_SISTEMAS"];
var CLAVES_ADMIN = ["ddp_admin_token", "ddp_admin_nombre", "ddp_admin_rol", "ddp_admin_forzar_cambio"];
var CLAVES_REVISION = ["ddp_revision_token", "ddp_revision_nombre", "ddp_revision_rol", "ddp_revision_forzar_cambio"];
function esRolDefensora(rol) {
  return !!rol && ROLES_DEFENSORA.includes(rol);
}
function cerrarSesionPersonal() {
  [...CLAVES_ADMIN, ...CLAVES_REVISION].forEach((clave) => localStorage.removeItem(clave));
}
function irALoginPersonal() {
  window.location.assign(RUTA_LOGIN_PERSONAL);
}

// src/app/core/services/auth-admin.service.ts
var TOKEN_KEY = "ddp_admin_token";
var NOMBRE_KEY = "ddp_admin_nombre";
var ROL_KEY = "ddp_admin_rol";
var FORZAR_KEY = "ddp_admin_forzar_cambio";
var AuthAdminService = class _AuthAdminService {
  http;
  apiUrl = "/api/admin/auth";
  usuarioActual = signal(this.leerSesionGuardada(), ...ngDevMode ? [{ debugName: "usuarioActual" }] : (
    /* istanbul ignore next */
    []
  ));
  constructor(http) {
    this.http = http;
  }
  login(datos) {
    return this.http.post(`${this.apiUrl}/login`, datos).pipe(tap((resp) => this.guardarSesion(resp)));
  }
  /** Cierra la sesión del personal en todos los paneles (login unificado). */
  logout() {
    cerrarSesionPersonal();
    this.usuarioActual.set(null);
  }
  isLoggedIn() {
    return !!this.usuarioActual();
  }
  getToken() {
    return this.usuarioActual()?.token ?? null;
  }
  /** Se llama tras un cambio de contraseña exitoso para dejar de pedirlo en cada carga. */
  marcarPasswordActualizada() {
    localStorage.setItem(FORZAR_KEY, "false");
    const actual = this.usuarioActual();
    if (actual) {
      this.usuarioActual.set(__spreadProps(__spreadValues({}, actual), { forzarCambioPassword: false }));
    }
  }
  guardarSesion(resp) {
    localStorage.setItem(TOKEN_KEY, resp.token);
    localStorage.setItem(NOMBRE_KEY, resp.nombre);
    localStorage.setItem(ROL_KEY, resp.rol);
    localStorage.setItem(FORZAR_KEY, String(resp.forzarCambioPassword));
    this.usuarioActual.set({
      token: resp.token,
      nombre: resp.nombre,
      rol: resp.rol,
      forzarCambioPassword: resp.forzarCambioPassword
    });
  }
  leerSesionGuardada() {
    const token = localStorage.getItem(TOKEN_KEY);
    const nombre = localStorage.getItem(NOMBRE_KEY);
    const rol = localStorage.getItem(ROL_KEY);
    const forzarCambioPassword = localStorage.getItem(FORZAR_KEY) === "true";
    if (!token || !nombre || !rol) {
      return null;
    }
    return { token, nombre, rol, forzarCambioPassword };
  }
  static \u0275fac = function AuthAdminService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _AuthAdminService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _AuthAdminService, factory: _AuthAdminService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AuthAdminService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

export {
  esRolDefensora,
  irALoginPersonal,
  AuthAdminService
};
//# sourceMappingURL=chunk-PNNWI3MN.js.map
