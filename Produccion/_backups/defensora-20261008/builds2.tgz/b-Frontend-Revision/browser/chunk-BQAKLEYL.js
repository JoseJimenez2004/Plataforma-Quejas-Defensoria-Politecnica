import {
  AuthRevisionService
} from "./chunk-6EXO4JCA.js";
import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel
} from "./chunk-2GLX7GEQ.js";
import {
  Router,
  RouterLink,
  RouterLinkActive,
  RouterOutlet
} from "./chunk-7JMYQEZG.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DatePipe,
  HostListener,
  HttpClient,
  Injectable,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵdomElement,
  ɵɵdomElementEnd,
  ɵɵdomElementStart,
  ɵɵdomListener,
  ɵɵdomProperty,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵresolveDocument,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-O4ZH52IX.js";

// src/app/core/models/revision.models.ts
function etiquetaRol(rol) {
  switch (rol) {
    case "ADMIN_SISTEMAS":
      return "Admin. de Sistemas";
    case "RECEPCIONISTA":
      return "Recepcionista";
    case "ANALISTA_PRIMER_CONTACTO":
      return "Analista de Primer Contacto";
    case "SUBDEFENSOR":
      return "Subdefensor";
    case "DEFENSOR":
      return "Defensor";
    default:
      return rol;
  }
}
function iniciales(nombreCompleto) {
  const partes = (nombreCompleto ?? "").trim().split(/\s+/).filter(Boolean);
  if (partes.length === 0)
    return "?";
  if (partes.length === 1)
    return partes[0].slice(0, 2).toUpperCase();
  return (partes[0][0] + partes[1][0]).toUpperCase();
}

// src/app/shared/campana-notificaciones/campana-notificaciones.ts
var _forTrack0 = ($index, $item) => $item.id;
function CampanaNotificaciones_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "span", 5);
    \u0275\u0275text(1);
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.noLeidas > 99 ? "99+" : ctx_r0.noLeidas);
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275domElementStart(0, "button", 11);
    \u0275\u0275domListener("click", function CampanaNotificaciones_Conditional_6_Conditional_4_Template_button_click_0_listener($event) {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.marcarTodas($event));
    });
    \u0275\u0275text(1, "Marcar todas como le\xEDdas");
    \u0275\u0275domElementEnd();
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "p", 10);
    \u0275\u0275text(1, "Cargando\u2026");
    \u0275\u0275domElementEnd();
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "p", 10);
    \u0275\u0275text(1, "No se pudieron cargar las notificaciones.");
    \u0275\u0275domElementEnd();
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "p", 10);
    \u0275\u0275text(1, "No tienes notificaciones.");
    \u0275\u0275domElementEnd();
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_8_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275domElementStart(0, "li", 13);
    \u0275\u0275domListener("click", function CampanaNotificaciones_Conditional_6_Conditional_8_For_2_Template_li_click_0_listener($event) {
      const n_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.marcarLeida(n_r4, $event));
    });
    \u0275\u0275domElementStart(1, "span", 14);
    \u0275\u0275text(2);
    \u0275\u0275domElementEnd();
    \u0275\u0275domElementStart(3, "span", 15);
    \u0275\u0275text(4);
    \u0275\u0275domElementEnd();
    \u0275\u0275domElementStart(5, "span", 16);
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "date");
    \u0275\u0275domElementEnd()();
  }
  if (rf & 2) {
    const n_r4 = ctx.$implicit;
    \u0275\u0275classProp("no-leida", !n_r4.leida);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(n_r4.titulo);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(n_r4.mensaje);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(7, 5, n_r4.fechaCreacion, "dd/MM/yyyy HH:mm"));
  }
}
function CampanaNotificaciones_Conditional_6_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "ul");
    \u0275\u0275repeaterCreate(1, CampanaNotificaciones_Conditional_6_Conditional_8_For_2_Template, 8, 8, "li", 12, _forTrack0);
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.notificaciones);
  }
}
function CampanaNotificaciones_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "div", 7);
    \u0275\u0275domListener("click", function CampanaNotificaciones_Conditional_6_Template_div_click_0_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275domElementStart(1, "div", 8)(2, "strong");
    \u0275\u0275text(3, "Notificaciones");
    \u0275\u0275domElementEnd();
    \u0275\u0275conditionalCreate(4, CampanaNotificaciones_Conditional_6_Conditional_4_Template, 2, 0, "button", 9);
    \u0275\u0275domElementEnd();
    \u0275\u0275conditionalCreate(5, CampanaNotificaciones_Conditional_6_Conditional_5_Template, 2, 0, "p", 10)(6, CampanaNotificaciones_Conditional_6_Conditional_6_Template, 2, 0, "p", 10)(7, CampanaNotificaciones_Conditional_6_Conditional_7_Template, 2, 0, "p", 10)(8, CampanaNotificaciones_Conditional_6_Conditional_8_Template, 3, 0, "ul");
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r0.noLeidas > 0 ? 4 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.cargando ? 5 : !ctx_r0.disponible ? 6 : ctx_r0.notificaciones.length === 0 ? 7 : 8);
  }
}
var CampanaNotificaciones = class _CampanaNotificaciones {
  http;
  cdr;
  apiUrl = "/api/notificaciones";
  intervaloMs = 6e4;
  temporizador = null;
  noLeidas = 0;
  abierta = false;
  cargando = false;
  disponible = true;
  notificaciones = [];
  constructor(http, cdr) {
    this.http = http;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.contar();
    this.temporizador = setInterval(() => this.contar(), this.intervaloMs);
  }
  ngOnDestroy() {
    if (this.temporizador) {
      clearInterval(this.temporizador);
    }
  }
  cerrar() {
    if (this.abierta) {
      this.abierta = false;
      this.cdr.detectChanges();
    }
  }
  alternar(evento) {
    evento.stopPropagation();
    this.abierta = !this.abierta;
    if (this.abierta) {
      this.cargarLista();
    }
    this.cdr.detectChanges();
  }
  marcarLeida(n, evento) {
    evento.stopPropagation();
    if (n.leida) {
      return;
    }
    this.http.put(`${this.apiUrl}/${n.id}/leida`, {}).subscribe({
      next: () => {
        n.leida = true;
        this.noLeidas = Math.max(0, this.noLeidas - 1);
        this.cdr.detectChanges();
      },
      error: () => {
      }
    });
  }
  marcarTodas(evento) {
    evento.stopPropagation();
    this.notificaciones.filter((n) => !n.leida).forEach((n) => this.marcarLeida(n, evento));
  }
  contar() {
    this.http.get(`${this.apiUrl}/mias/no-leidas`).subscribe({
      next: (r) => {
        this.disponible = true;
        this.noLeidas = r?.noLeidas ?? 0;
        this.cdr.detectChanges();
      },
      // Si notificaciones-service no responde, la campana simplemente no muestra conteo.
      error: () => {
        this.disponible = false;
        this.cdr.detectChanges();
      }
    });
  }
  cargarLista() {
    this.cargando = true;
    this.http.get(`${this.apiUrl}/mias`).subscribe({
      next: (lista) => {
        this.notificaciones = (lista ?? []).slice(0, 30);
        this.noLeidas = this.notificaciones.filter((n) => !n.leida).length;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.disponible = false;
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function CampanaNotificaciones_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _CampanaNotificaciones)(\u0275\u0275directiveInject(HttpClient), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _CampanaNotificaciones, selectors: [["app-campana-notificaciones"]], hostBindings: function CampanaNotificaciones_HostBindings(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275listener("click", function CampanaNotificaciones_click_HostBindingHandler() {
        return ctx.cerrar();
      }, \u0275\u0275resolveDocument);
    }
  }, decls: 7, vars: 4, consts: [[1, "campana"], ["type", "button", 1, "campana-boton", 3, "click", "title"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"], ["d", "M10.3 21a1.94 1.94 0 0 0 3.4 0"], [1, "campana-conteo"], [1, "campana-panel"], [1, "campana-panel", 3, "click"], [1, "campana-encabezado"], ["type", "button", 1, "campana-todas"], [1, "campana-vacio"], ["type", "button", 1, "campana-todas", 3, "click"], [3, "no-leida"], [3, "click"], [1, "titulo"], [1, "mensaje"], [1, "fecha"]], template: function CampanaNotificaciones_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275domElementStart(0, "div", 0)(1, "button", 1);
      \u0275\u0275domListener("click", function CampanaNotificaciones_Template_button_click_1_listener($event) {
        return ctx.alternar($event);
      });
      \u0275\u0275namespaceSVG();
      \u0275\u0275domElementStart(2, "svg", 2);
      \u0275\u0275domElement(3, "path", 3)(4, "path", 4);
      \u0275\u0275domElementEnd();
      \u0275\u0275conditionalCreate(5, CampanaNotificaciones_Conditional_5_Template, 2, 1, "span", 5);
      \u0275\u0275domElementEnd();
      \u0275\u0275conditionalCreate(6, CampanaNotificaciones_Conditional_6_Template, 9, 2, "div", 6);
      \u0275\u0275domElementEnd();
    }
    if (rf & 2) {
      \u0275\u0275advance();
      \u0275\u0275domProperty("title", ctx.disponible ? "Notificaciones" : "Notificaciones no disponibles por ahora");
      \u0275\u0275attribute("aria-label", ctx.noLeidas ? ctx.noLeidas + " notificaciones sin leer" : "Notificaciones");
      \u0275\u0275advance(4);
      \u0275\u0275conditional(ctx.noLeidas > 0 ? 5 : -1);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.abierta ? 6 : -1);
    }
  }, dependencies: [CommonModule, DatePipe], styles: ["\n.campana[_ngcontent-%COMP%] {\n  position: relative;\n}\n.campana-boton[_ngcontent-%COMP%] {\n  position: relative;\n  width: 40px;\n  height: 40px;\n  display: grid;\n  place-items: center;\n  border: none;\n  border-radius: 50%;\n  background: transparent;\n  color: var(--texto-suave, #666);\n  cursor: pointer;\n}\n.campana-boton[_ngcontent-%COMP%]:hover {\n  background: var(--guinda-suave, #f7eef1);\n  color: var(--guinda, #6c1d45);\n}\n.campana-boton[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 21px;\n  height: 21px;\n}\n.campana-conteo[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 3px;\n  right: 2px;\n  min-width: 18px;\n  height: 18px;\n  padding: 0 5px;\n  border-radius: 9px;\n  background: var(--peligro, #c62828);\n  color: #fff;\n  font-size: 0.68rem;\n  font-weight: 700;\n  line-height: 18px;\n  text-align: center;\n}\n.campana-panel[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  top: 46px;\n  z-index: 50;\n  width: min(360px, 90vw);\n  max-height: 420px;\n  overflow-y: auto;\n  border-radius: 10px;\n  background: #fff;\n  box-shadow: 0 12px 32px rgba(16, 24, 40, 0.18);\n}\n.campana-panel[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n.campana-panel[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 2px;\n  padding: 10px 14px;\n  border-top: 1px solid #eee;\n  cursor: pointer;\n}\n.campana-panel[_ngcontent-%COMP%]   li.no-leida[_ngcontent-%COMP%] {\n  background: var(--guinda-suave, #f7eef1);\n}\n.campana-encabezado[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px 14px;\n}\n.campana-todas[_ngcontent-%COMP%] {\n  border: none;\n  background: none;\n  color: var(--guinda-vivo, #9d2449);\n  font-size: 0.78rem;\n  font-weight: 600;\n  cursor: pointer;\n}\n.titulo[_ngcontent-%COMP%] {\n  font-weight: 600;\n  font-size: 0.86rem;\n}\n.mensaje[_ngcontent-%COMP%] {\n  font-size: 0.82rem;\n  color: var(--texto, #333);\n}\n.fecha[_ngcontent-%COMP%] {\n  font-size: 0.72rem;\n  color: var(--texto-suave, #666);\n}\n.campana-vacio[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 18px 14px;\n  font-size: 0.85rem;\n  color: var(--texto-suave, #666);\n}\n/*# sourceMappingURL=campana-notificaciones.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CampanaNotificaciones, [{
    type: Component,
    args: [{ selector: "app-campana-notificaciones", standalone: true, imports: [CommonModule], template: `<div class="campana">
  <button type="button" class="campana-boton" (click)="alternar($event)"
          [attr.aria-label]="noLeidas ? noLeidas + ' notificaciones sin leer' : 'Notificaciones'"
          [title]="disponible ? 'Notificaciones' : 'Notificaciones no disponibles por ahora'">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
    @if (noLeidas > 0) {
      <span class="campana-conteo">{{ noLeidas > 99 ? '99+' : noLeidas }}</span>
    }
  </button>

  @if (abierta) {
    <div class="campana-panel" (click)="$event.stopPropagation()">
      <div class="campana-encabezado">
        <strong>Notificaciones</strong>
        @if (noLeidas > 0) {
          <button type="button" class="campana-todas" (click)="marcarTodas($event)">Marcar todas como le\xEDdas</button>
        }
      </div>
      @if (cargando) {
        <p class="campana-vacio">Cargando\u2026</p>
      } @else if (!disponible) {
        <p class="campana-vacio">No se pudieron cargar las notificaciones.</p>
      } @else if (notificaciones.length === 0) {
        <p class="campana-vacio">No tienes notificaciones.</p>
      } @else {
        <ul>
          @for (n of notificaciones; track n.id) {
            <li [class.no-leida]="!n.leida" (click)="marcarLeida(n, $event)">
              <span class="titulo">{{ n.titulo }}</span>
              <span class="mensaje">{{ n.mensaje }}</span>
              <span class="fecha">{{ n.fechaCreacion | date: 'dd/MM/yyyy HH:mm' }}</span>
            </li>
          }
        </ul>
      }
    </div>
  }
</div>
`, styles: ["/* src/app/shared/campana-notificaciones/campana-notificaciones.scss */\n.campana {\n  position: relative;\n}\n.campana-boton {\n  position: relative;\n  width: 40px;\n  height: 40px;\n  display: grid;\n  place-items: center;\n  border: none;\n  border-radius: 50%;\n  background: transparent;\n  color: var(--texto-suave, #666);\n  cursor: pointer;\n}\n.campana-boton:hover {\n  background: var(--guinda-suave, #f7eef1);\n  color: var(--guinda, #6c1d45);\n}\n.campana-boton svg {\n  width: 21px;\n  height: 21px;\n}\n.campana-conteo {\n  position: absolute;\n  top: 3px;\n  right: 2px;\n  min-width: 18px;\n  height: 18px;\n  padding: 0 5px;\n  border-radius: 9px;\n  background: var(--peligro, #c62828);\n  color: #fff;\n  font-size: 0.68rem;\n  font-weight: 700;\n  line-height: 18px;\n  text-align: center;\n}\n.campana-panel {\n  position: absolute;\n  right: 0;\n  top: 46px;\n  z-index: 50;\n  width: min(360px, 90vw);\n  max-height: 420px;\n  overflow-y: auto;\n  border-radius: 10px;\n  background: #fff;\n  box-shadow: 0 12px 32px rgba(16, 24, 40, 0.18);\n}\n.campana-panel ul {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n.campana-panel li {\n  display: grid;\n  gap: 2px;\n  padding: 10px 14px;\n  border-top: 1px solid #eee;\n  cursor: pointer;\n}\n.campana-panel li.no-leida {\n  background: var(--guinda-suave, #f7eef1);\n}\n.campana-encabezado {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px 14px;\n}\n.campana-todas {\n  border: none;\n  background: none;\n  color: var(--guinda-vivo, #9d2449);\n  font-size: 0.78rem;\n  font-weight: 600;\n  cursor: pointer;\n}\n.titulo {\n  font-weight: 600;\n  font-size: 0.86rem;\n}\n.mensaje {\n  font-size: 0.82rem;\n  color: var(--texto, #333);\n}\n.fecha {\n  font-size: 0.72rem;\n  color: var(--texto-suave, #666);\n}\n.campana-vacio {\n  margin: 0;\n  padding: 18px 14px;\n  font-size: 0.85rem;\n  color: var(--texto-suave, #666);\n}\n/*# sourceMappingURL=campana-notificaciones.css.map */\n"] }]
  }], () => [{ type: HttpClient }, { type: ChangeDetectorRef }], { cerrar: [{
    type: HostListener,
    args: ["document:click"]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(CampanaNotificaciones, { className: "CampanaNotificaciones", filePath: "src/app/shared/campana-notificaciones/campana-notificaciones.ts", lineNumber: 30 });
})();

// src/app/core/services/perfil.service.ts
var PerfilService = class _PerfilService {
  http;
  apiUrl = "/api/admin/perfil";
  constructor(http) {
    this.http = http;
  }
  cambiarPassword(datos) {
    return this.http.put(`${this.apiUrl}/password`, datos);
  }
  static \u0275fac = function PerfilService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _PerfilService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _PerfilService, factory: _PerfilService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PerfilService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/recepcion-layout/recepcion-layout.ts
var _c0 = () => ({ exact: true });
function RecepcionLayout_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 32);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_18_Template_div_click_0_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(1, "button", 33);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_18_Template_button_click_1_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.abrirModalPassword());
    });
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 10);
    \u0275\u0275element(3, "circle", 34)(4, "path", 35)(5, "path", 36)(6, "path", 37);
    \u0275\u0275elementEnd();
    \u0275\u0275text(7, " Cambiar contrase\xF1a ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275element(8, "div", 38);
    \u0275\u0275elementStart(9, "button", 39);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_18_Template_button_click_9_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarSesion());
    });
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(10, "svg", 10);
    \u0275\u0275element(11, "path", 40)(12, "polyline", 41)(13, "line", 42);
    \u0275\u0275elementEnd();
    \u0275\u0275text(14, " Cerrar sesi\xF3n ");
    \u0275\u0275elementEnd()();
  }
}
function RecepcionLayout_Conditional_50_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 60);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_50_Conditional_5_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.cerrarModalPassword());
    });
    \u0275\u0275text(1, "\u2715");
    \u0275\u0275elementEnd();
  }
}
function RecepcionLayout_Conditional_50_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 46);
    \u0275\u0275text(1, " Tu cuenta tiene una contrase\xF1a temporal. Debes establecer una nueva antes de continuar usando el panel. ");
    \u0275\u0275elementEnd();
  }
}
function RecepcionLayout_Conditional_50_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 56);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorPassword);
  }
}
function RecepcionLayout_Conditional_50_Conditional_45_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 61);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_50_Conditional_45_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.cerrarModalPassword());
    });
    \u0275\u0275text(1, "Cancelar");
    \u0275\u0275elementEnd();
  }
}
function RecepcionLayout_Conditional_50_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 31)(1, "div", 43);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_50_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 44)(3, "h3");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(5, RecepcionLayout_Conditional_50_Conditional_5_Template, 2, 0, "button", 45);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(6, RecepcionLayout_Conditional_50_Conditional_6_Template, 2, 0, "p", 46);
    \u0275\u0275elementStart(7, "div", 47)(8, "label");
    \u0275\u0275text(9, "Contrase\xF1a actual");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "div", 48)(11, "input", 49);
    \u0275\u0275twoWayListener("ngModelChange", function RecepcionLayout_Conditional_50_Template_input_ngModelChange_11_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordActual, $event) || (ctx_r1.passwordActual = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "button", 50);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_50_Template_button_click_12_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.mostrarActual = !ctx_r1.mostrarActual);
    });
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(14, "div", 47)(15, "label");
    \u0275\u0275text(16, "Contrase\xF1a nueva");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "div", 48)(18, "input", 51);
    \u0275\u0275twoWayListener("ngModelChange", function RecepcionLayout_Conditional_50_Template_input_ngModelChange_18_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordNueva, $event) || (ctx_r1.passwordNueva = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "button", 50);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_50_Template_button_click_19_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.mostrarNueva = !ctx_r1.mostrarNueva);
    });
    \u0275\u0275text(20);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "ul", 52)(22, "li")(23, "span", 15);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(24, "svg", 53);
    \u0275\u0275element(25, "polyline", 54);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(26, " Al menos 8 caracteres ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(27, "li")(28, "span", 15);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(29, "svg", 53);
    \u0275\u0275element(30, "polyline", 54);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(31, " Una letra may\xFAscula ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(32, "li")(33, "span", 15);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(34, "svg", 53);
    \u0275\u0275element(35, "polyline", 54);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(36, " Un n\xFAmero ");
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(37, "div", 47)(38, "label");
    \u0275\u0275text(39, "Confirmar contrase\xF1a nueva");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "input", 55);
    \u0275\u0275twoWayListener("ngModelChange", function RecepcionLayout_Conditional_50_Template_input_ngModelChange_40_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordConfirmar, $event) || (ctx_r1.passwordConfirmar = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(41, RecepcionLayout_Conditional_50_Conditional_41_Template, 2, 1, "p", 56);
    \u0275\u0275elementStart(42, "div", 57)(43, "button", 58);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_50_Template_button_click_43_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.guardarPassword());
    });
    \u0275\u0275text(44);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(45, RecepcionLayout_Conditional_50_Conditional_45_Template, 2, 0, "button", 59);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.cambioObligatorio ? "Actualiza tu contrase\xF1a temporal" : "Cambiar mi contrase\xF1a");
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx_r1.cambioObligatorio ? 5 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.cambioObligatorio ? 6 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275property("type", ctx_r1.mostrarActual ? "text" : "password");
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordActual);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.mostrarActual ? "\u{1F648}" : "\u{1F441}\uFE0F");
    \u0275\u0275advance(5);
    \u0275\u0275property("type", ctx_r1.mostrarNueva ? "text" : "password");
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordNueva);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.mostrarNueva ? "\u{1F648}" : "\u{1F441}\uFE0F");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleLongitud);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleMayuscula);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleNumero);
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordConfirmar);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.errorPassword ? 41 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r1.guardandoPassword);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.guardandoPassword ? "Guardando\u2026" : "Actualizar Contrase\xF1a", " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx_r1.cambioObligatorio ? 45 : -1);
  }
}
var RecepcionLayout = class _RecepcionLayout {
  authService;
  perfilService;
  router;
  toast;
  cdr;
  etiquetaRol = etiquetaRol;
  menuAbierto = false;
  mostrarModalPassword = false;
  cambioObligatorio = false;
  passwordActual = "";
  passwordNueva = "";
  passwordConfirmar = "";
  mostrarActual = false;
  mostrarNueva = false;
  guardandoPassword = false;
  errorPassword = "";
  constructor(authService, perfilService, router, toast, cdr) {
    this.authService = authService;
    this.perfilService = perfilService;
    this.router = router;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    const usuario = this.authService.usuarioActual();
    if (usuario?.forzarCambioPassword) {
      this.cambioObligatorio = true;
      this.abrirModalPassword();
    }
  }
  get nombreUsuario() {
    return this.authService.usuarioActual()?.nombre ?? "";
  }
  get rolUsuario() {
    const rol = this.authService.usuarioActual()?.rol;
    return rol ? this.etiquetaRol(rol) : "";
  }
  get inicialesUsuario() {
    return iniciales(this.nombreUsuario);
  }
  cerrarMenuAlHacerClickFuera() {
    this.menuAbierto = false;
  }
  alternarMenu(evento) {
    evento.stopPropagation();
    this.menuAbierto = !this.menuAbierto;
  }
  abrirModalPassword() {
    this.menuAbierto = false;
    this.passwordActual = "";
    this.passwordNueva = "";
    this.passwordConfirmar = "";
    this.errorPassword = "";
    this.mostrarModalPassword = true;
  }
  cerrarModalPassword() {
    if (this.cambioObligatorio) {
      this.toast.advertencia("Debes actualizar tu contrase\xF1a temporal antes de continuar.");
      return;
    }
    this.mostrarModalPassword = false;
  }
  get cumpleLongitud() {
    return this.passwordNueva.length >= 8;
  }
  get cumpleMayuscula() {
    return /[A-Z]/.test(this.passwordNueva);
  }
  get cumpleNumero() {
    return /\d/.test(this.passwordNueva);
  }
  get cumpleCoinciden() {
    return this.passwordNueva.length > 0 && this.passwordNueva === this.passwordConfirmar;
  }
  guardarPassword() {
    this.errorPassword = "";
    if (!this.passwordActual) {
      this.errorPassword = "Ingresa tu contrase\xF1a actual.";
      return;
    }
    if (!this.cumpleLongitud || !this.cumpleMayuscula || !this.cumpleNumero) {
      this.errorPassword = "La nueva contrase\xF1a no cumple los requisitos.";
      return;
    }
    if (!this.cumpleCoinciden) {
      this.errorPassword = "La confirmaci\xF3n no coincide con la nueva contrase\xF1a.";
      return;
    }
    this.guardandoPassword = true;
    this.perfilService.cambiarPassword({
      passwordActual: this.passwordActual,
      passwordNueva: this.passwordNueva
    }).subscribe({
      next: () => {
        this.guardandoPassword = false;
        this.cambioObligatorio = false;
        this.mostrarModalPassword = false;
        this.authService.marcarPasswordActualizada();
        this.toast.exito("Contrase\xF1a actualizada correctamente.");
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.guardandoPassword = false;
        this.errorPassword = err?.error?.mensaje ?? "No se pudo actualizar la contrase\xF1a.";
        this.cdr.detectChanges();
      }
    });
  }
  cerrarSesion() {
    this.authService.logout();
    this.router.navigate(["/login"]);
  }
  static \u0275fac = function RecepcionLayout_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _RecepcionLayout)(\u0275\u0275directiveInject(AuthRevisionService), \u0275\u0275directiveInject(PerfilService), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _RecepcionLayout, selectors: [["app-recepcion-layout"]], hostBindings: function RecepcionLayout_HostBindings(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275listener("click", function RecepcionLayout_click_HostBindingHandler() {
        return ctx.cerrarMenuAlHacerClickFuera();
      }, \u0275\u0275resolveDocument);
    }
  }, decls: 51, vars: 8, consts: [[1, "topbar"], [1, "topbar-marca"], [1, "topbar-marca-punto"], [1, "topbar-acciones"], [1, "dropdown"], [1, "perfil-boton", 3, "click"], [1, "avatar"], [1, "perfil-texto"], [1, "perfil-nombre"], [1, "perfil-rol"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["points", "6 9 12 15 18 9"], [1, "dropdown-menu"], [1, "layout"], [1, "sidebar"], [1, "marca"], [1, "marca-escudo"], [1, "marca-texto"], ["routerLink", "/", "routerLinkActive", "activo", 3, "routerLinkActiveOptions"], ["d", "M4 4h16v16H4z", "opacity", "0"], ["d", "M22 6l-10 7L2 6"], ["x", "2", "y", "4", "width", "20", "height", "16", "rx", "2"], [1, "punto-notificacion"], ["routerLink", "/historial", "routerLinkActive", "activo"], ["d", "M3 12a9 9 0 1 0 3-6.7"], ["points", "3 4 3 9 8 9"], ["points", "12 7 12 12 16 14"], ["routerLink", "/registro-manual", "routerLinkActive", "activo"], ["d", "M12 20h9"], ["d", "M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"], [1, "contenido"], [1, "modal-overlay"], [1, "dropdown-menu", 3, "click"], [3, "click"], ["cx", "7.5", "cy", "15.5", "r", "5.5"], ["d", "M21 2l-9.6 9.6"], ["d", "M15.5 7.5L18 5"], ["d", "M17 3l4 4"], [1, "dropdown-separador"], [1, "peligro", 3, "click"], ["d", "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"], ["points", "16 17 21 12 16 7"], ["x1", "21", "y1", "12", "x2", "9", "y2", "12"], [1, "modal", "card", 3, "click"], [1, "modal-header"], ["aria-label", "Cerrar", 1, "modal-cerrar"], [1, "aviso-inline"], [1, "input-group"], [1, "campo-password"], ["name", "passwordActual", 3, "ngModelChange", "type", "ngModel"], ["type", "button", 1, "alternar-password", 3, "click"], ["name", "passwordNueva", 3, "ngModelChange", "type", "ngModel"], [1, "requisitos-password"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "3", "stroke-linecap", "round", "stroke-linejoin", "round"], ["points", "20 6 9 17 4 12"], ["type", "password", "name", "passwordConfirmar", 3, "ngModelChange", "ngModel"], [1, "mensaje-campo"], [1, "modal-acciones"], [1, "btn-primary", 3, "click", "disabled"], [1, "btn-secondary"], ["aria-label", "Cerrar", 1, "modal-cerrar", 3, "click"], [1, "btn-secondary", 3, "click"]], template: function RecepcionLayout_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "header", 0)(1, "div", 1);
      \u0275\u0275element(2, "span", 2);
      \u0275\u0275elementStart(3, "span");
      \u0275\u0275text(4, "Defensor\xEDa de los Derechos Polit\xE9cnicos");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(5, "div", 3);
      \u0275\u0275element(6, "app-campana-notificaciones");
      \u0275\u0275elementStart(7, "div", 4)(8, "button", 5);
      \u0275\u0275listener("click", function RecepcionLayout_Template_button_click_8_listener($event) {
        return ctx.alternarMenu($event);
      });
      \u0275\u0275elementStart(9, "span", 6);
      \u0275\u0275text(10);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(11, "span", 7)(12, "span", 8);
      \u0275\u0275text(13);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(14, "span", 9);
      \u0275\u0275text(15);
      \u0275\u0275elementEnd()();
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(16, "svg", 10);
      \u0275\u0275element(17, "polyline", 11);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(18, RecepcionLayout_Conditional_18_Template, 15, 0, "div", 12);
      \u0275\u0275elementEnd()()();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(19, "div", 13)(20, "aside", 14)(21, "div", 15)(22, "div", 16);
      \u0275\u0275text(23, "DDP");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(24, "div", 17)(25, "strong");
      \u0275\u0275text(26, "Panel de Revisi\xF3n");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(27, "span");
      \u0275\u0275text(28);
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(29, "nav")(30, "a", 18);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(31, "svg", 10);
      \u0275\u0275element(32, "path", 19)(33, "path", 20)(34, "rect", 21);
      \u0275\u0275elementEnd();
      \u0275\u0275text(35, " Bandeja de Entrada ");
      \u0275\u0275namespaceHTML();
      \u0275\u0275element(36, "span", 22);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(37, "a", 23);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(38, "svg", 10);
      \u0275\u0275element(39, "path", 24)(40, "polyline", 25)(41, "polyline", 26);
      \u0275\u0275elementEnd();
      \u0275\u0275text(42, " Historial ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(43, "a", 27);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(44, "svg", 10);
      \u0275\u0275element(45, "path", 28)(46, "path", 29);
      \u0275\u0275elementEnd();
      \u0275\u0275text(47, " Registro Manual ");
      \u0275\u0275elementEnd()()();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(48, "main", 30);
      \u0275\u0275element(49, "router-outlet");
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(50, RecepcionLayout_Conditional_50_Template, 46, 20, "div", 31);
    }
    if (rf & 2) {
      \u0275\u0275advance(10);
      \u0275\u0275textInterpolate(ctx.inicialesUsuario);
      \u0275\u0275advance(3);
      \u0275\u0275textInterpolate(ctx.nombreUsuario);
      \u0275\u0275advance(2);
      \u0275\u0275textInterpolate(ctx.rolUsuario);
      \u0275\u0275advance(3);
      \u0275\u0275conditional(ctx.menuAbierto ? 18 : -1);
      \u0275\u0275advance(10);
      \u0275\u0275textInterpolate(ctx.rolUsuario);
      \u0275\u0275advance(2);
      \u0275\u0275property("routerLinkActiveOptions", \u0275\u0275pureFunction0(7, _c0));
      \u0275\u0275advance(20);
      \u0275\u0275conditional(ctx.mostrarModalPassword ? 50 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, DefaultValueAccessor, NgControlStatus, NgModel, RouterLink, RouterLinkActive, RouterOutlet, CampanaNotificaciones], styles: ["\n[_nghost-%COMP%] {\n  display: block;\n  min-height: 100vh;\n}\n.topbar[_ngcontent-%COMP%] {\n  background: #fff;\n  border-bottom: 1px solid var(--borde);\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 16px;\n  padding: 10px 24px;\n  position: sticky;\n  top: 0;\n  z-index: 100;\n}\n.topbar-marca[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: var(--texto-suave);\n}\n.topbar-marca-punto[_ngcontent-%COMP%] {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: var(--exito);\n}\n.perfil-boton[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: none;\n  border: none;\n  padding: 5px 8px;\n  border-radius: 8px;\n}\n.perfil-boton[_ngcontent-%COMP%]:hover {\n  background: var(--gris-fondo);\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-texto[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  line-height: 1.2;\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-nombre[_ngcontent-%COMP%] {\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-rol[_ngcontent-%COMP%] {\n  font-size: 0.72rem;\n  color: var(--guinda-vivo);\n  font-weight: 600;\n}\n.perfil-boton[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.layout[_ngcontent-%COMP%] {\n  display: flex;\n  min-height: calc(100vh - 53px);\n}\n.sidebar[_ngcontent-%COMP%] {\n  width: 240px;\n  background: var(--sidebar-fondo);\n  padding: 18px 0;\n  flex-shrink: 0;\n}\n.sidebar[_ngcontent-%COMP%]   .marca[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  padding: 0 20px 22px;\n  margin-bottom: 6px;\n  border-bottom: 1px solid rgba(255, 255, 255, 0.08);\n}\n.sidebar[_ngcontent-%COMP%]   .marca-escudo[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 8px;\n  background:\n    linear-gradient(\n      135deg,\n      var(--guinda-vivo),\n      var(--guinda-oscuro));\n  color: #fff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 700;\n  font-size: 0.72rem;\n  letter-spacing: 0.5px;\n  flex-shrink: 0;\n}\n.sidebar[_ngcontent-%COMP%]   .marca-texto[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  line-height: 1.25;\n}\n.sidebar[_ngcontent-%COMP%]   .marca-texto[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #fff;\n  font-size: 0.9rem;\n}\n.sidebar[_ngcontent-%COMP%]   .marca-texto[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: var(--sidebar-texto);\n  font-size: 0.72rem;\n}\n.sidebar[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%] {\n  padding-top: 8px;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  color: var(--sidebar-texto);\n  text-decoration: none;\n  padding: 12px 22px;\n  font-size: 0.87rem;\n  border-left: 3px solid transparent;\n  transition: background 0.15s ease, color 0.15s ease;\n  position: relative;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  flex-shrink: 0;\n  opacity: 0.85;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   .punto-notificacion[_ngcontent-%COMP%] {\n  width: 7px;\n  height: 7px;\n  border-radius: 50%;\n  background: var(--guinda-vivo);\n  margin-left: auto;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  background: rgba(255, 255, 255, 0.05);\n  color: #fff;\n}\n.sidebar[_ngcontent-%COMP%]   a.activo[_ngcontent-%COMP%] {\n  background: var(--sidebar-fondo-activo);\n  color: #fff;\n  font-weight: 600;\n  border-left-color: var(--guinda-vivo);\n}\n.sidebar[_ngcontent-%COMP%]   a.activo[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  opacity: 1;\n}\n.contenido[_ngcontent-%COMP%] {\n  flex: 1;\n  padding: 30px 34px;\n  max-width: 1180px;\n}\n.topbar-acciones[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n/*# sourceMappingURL=recepcion-layout.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RecepcionLayout, [{
    type: Component,
    args: [{ selector: "app-recepcion-layout", standalone: true, imports: [CommonModule, FormsModule, RouterLink, RouterLinkActive, RouterOutlet, CampanaNotificaciones], template: `<header class="topbar">
  <div class="topbar-marca">
    <span class="topbar-marca-punto"></span>
    <span>Defensor\xEDa de los Derechos Polit\xE9cnicos</span>
  </div>

  <div class="topbar-acciones">
  <app-campana-notificaciones></app-campana-notificaciones>
  <div class="dropdown">
    <button class="perfil-boton" (click)="alternarMenu($event)">
      <span class="avatar">{{ inicialesUsuario }}</span>
      <span class="perfil-texto">
        <span class="perfil-nombre">{{ nombreUsuario }}</span>
        <span class="perfil-rol">{{ rolUsuario }}</span>
      </span>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
    </button>

    @if (menuAbierto) {
      <div class="dropdown-menu" (click)="$event.stopPropagation()">
        <button (click)="abrirModalPassword()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="5.5"></circle><path d="M21 2l-9.6 9.6"></path><path d="M15.5 7.5L18 5"></path><path d="M17 3l4 4"></path></svg>
          Cambiar contrase\xF1a
        </button>
        <div class="dropdown-separador"></div>
        <button class="peligro" (click)="cerrarSesion()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
          Cerrar sesi\xF3n
        </button>
      </div>
    }
  </div>
  </div>
</header>

<div class="layout">
  <aside class="sidebar">
    <div class="marca">
      <div class="marca-escudo">DDP</div>
      <div class="marca-texto">
        <strong>Panel de Revisi\xF3n</strong>
        <span>{{ rolUsuario }}</span>
      </div>
    </div>

    <nav>
      <a routerLink="/" routerLinkActive="activo" [routerLinkActiveOptions]="{ exact: true }">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v16H4z" opacity="0"></path><path d="M22 6l-10 7L2 6"></path><rect x="2" y="4" width="20" height="16" rx="2"></rect></svg>
        Bandeja de Entrada
        <span class="punto-notificacion"></span>
      </a>
      <a routerLink="/historial" routerLinkActive="activo">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"></path><polyline points="3 4 3 9 8 9"></polyline><polyline points="12 7 12 12 16 14"></polyline></svg>
        Historial
      </a>
      <a routerLink="/registro-manual" routerLinkActive="activo">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"></path></svg>
        Registro Manual
      </a>
    </nav>
  </aside>

  <main class="contenido">
    <router-outlet />
  </main>
</div>

@if (mostrarModalPassword) {
  <div class="modal-overlay">
    <div class="modal card" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>{{ cambioObligatorio ? 'Actualiza tu contrase\xF1a temporal' : 'Cambiar mi contrase\xF1a' }}</h3>
        @if (!cambioObligatorio) {
          <button class="modal-cerrar" (click)="cerrarModalPassword()" aria-label="Cerrar">\u2715</button>
        }
      </div>

      @if (cambioObligatorio) {
        <p class="aviso-inline">
          Tu cuenta tiene una contrase\xF1a temporal. Debes establecer una nueva antes de continuar
          usando el panel.
        </p>
      }

      <div class="input-group">
        <label>Contrase\xF1a actual</label>
        <div class="campo-password">
          <input
            [type]="mostrarActual ? 'text' : 'password'"
            [(ngModel)]="passwordActual"
            name="passwordActual"
          />
          <button
            type="button"
            class="alternar-password"
            (click)="mostrarActual = !mostrarActual"
          >{{ mostrarActual ? '\u{1F648}' : '\u{1F441}\uFE0F' }}</button>
        </div>
      </div>

      <div class="input-group">
        <label>Contrase\xF1a nueva</label>
        <div class="campo-password">
          <input
            [type]="mostrarNueva ? 'text' : 'password'"
            [(ngModel)]="passwordNueva"
            name="passwordNueva"
          />
          <button
            type="button"
            class="alternar-password"
            (click)="mostrarNueva = !mostrarNueva"
          >{{ mostrarNueva ? '\u{1F648}' : '\u{1F441}\uFE0F' }}</button>
        </div>
      </div>

      <ul class="requisitos-password">
        <li [class.cumplido]="cumpleLongitud">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Al menos 8 caracteres
        </li>
        <li [class.cumplido]="cumpleMayuscula">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Una letra may\xFAscula
        </li>
        <li [class.cumplido]="cumpleNumero">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Un n\xFAmero
        </li>
      </ul>

      <div class="input-group">
        <label>Confirmar contrase\xF1a nueva</label>
        <input type="password" [(ngModel)]="passwordConfirmar" name="passwordConfirmar" />
      </div>

      @if (errorPassword) {
        <p class="mensaje-campo">{{ errorPassword }}</p>
      }

      <div class="modal-acciones">
        <button class="btn-primary" (click)="guardarPassword()" [disabled]="guardandoPassword">
          {{ guardandoPassword ? 'Guardando\u2026' : 'Actualizar Contrase\xF1a' }}
        </button>
        @if (!cambioObligatorio) {
          <button class="btn-secondary" (click)="cerrarModalPassword()">Cancelar</button>
        }
      </div>
    </div>
  </div>
}
`, styles: ["/* src/app/pages/recepcion-layout/recepcion-layout.scss */\n:host {\n  display: block;\n  min-height: 100vh;\n}\n.topbar {\n  background: #fff;\n  border-bottom: 1px solid var(--borde);\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 16px;\n  padding: 10px 24px;\n  position: sticky;\n  top: 0;\n  z-index: 100;\n}\n.topbar-marca {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: var(--texto-suave);\n}\n.topbar-marca-punto {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: var(--exito);\n}\n.perfil-boton {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: none;\n  border: none;\n  padding: 5px 8px;\n  border-radius: 8px;\n}\n.perfil-boton:hover {\n  background: var(--gris-fondo);\n}\n.perfil-boton .perfil-texto {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  line-height: 1.2;\n}\n.perfil-boton .perfil-nombre {\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.perfil-boton .perfil-rol {\n  font-size: 0.72rem;\n  color: var(--guinda-vivo);\n  font-weight: 600;\n}\n.perfil-boton svg {\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.layout {\n  display: flex;\n  min-height: calc(100vh - 53px);\n}\n.sidebar {\n  width: 240px;\n  background: var(--sidebar-fondo);\n  padding: 18px 0;\n  flex-shrink: 0;\n}\n.sidebar .marca {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  padding: 0 20px 22px;\n  margin-bottom: 6px;\n  border-bottom: 1px solid rgba(255, 255, 255, 0.08);\n}\n.sidebar .marca-escudo {\n  width: 38px;\n  height: 38px;\n  border-radius: 8px;\n  background:\n    linear-gradient(\n      135deg,\n      var(--guinda-vivo),\n      var(--guinda-oscuro));\n  color: #fff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 700;\n  font-size: 0.72rem;\n  letter-spacing: 0.5px;\n  flex-shrink: 0;\n}\n.sidebar .marca-texto {\n  display: flex;\n  flex-direction: column;\n  line-height: 1.25;\n}\n.sidebar .marca-texto strong {\n  color: #fff;\n  font-size: 0.9rem;\n}\n.sidebar .marca-texto span {\n  color: var(--sidebar-texto);\n  font-size: 0.72rem;\n}\n.sidebar nav {\n  padding-top: 8px;\n}\n.sidebar a {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  color: var(--sidebar-texto);\n  text-decoration: none;\n  padding: 12px 22px;\n  font-size: 0.87rem;\n  border-left: 3px solid transparent;\n  transition: background 0.15s ease, color 0.15s ease;\n  position: relative;\n}\n.sidebar a svg {\n  width: 18px;\n  height: 18px;\n  flex-shrink: 0;\n  opacity: 0.85;\n}\n.sidebar a .punto-notificacion {\n  width: 7px;\n  height: 7px;\n  border-radius: 50%;\n  background: var(--guinda-vivo);\n  margin-left: auto;\n}\n.sidebar a:hover {\n  background: rgba(255, 255, 255, 0.05);\n  color: #fff;\n}\n.sidebar a.activo {\n  background: var(--sidebar-fondo-activo);\n  color: #fff;\n  font-weight: 600;\n  border-left-color: var(--guinda-vivo);\n}\n.sidebar a.activo svg {\n  opacity: 1;\n}\n.contenido {\n  flex: 1;\n  padding: 30px 34px;\n  max-width: 1180px;\n}\n.topbar-acciones {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n/*# sourceMappingURL=recepcion-layout.css.map */\n"] }]
  }], () => [{ type: AuthRevisionService }, { type: PerfilService }, { type: Router }, { type: ToastService }, { type: ChangeDetectorRef }], { cerrarMenuAlHacerClickFuera: [{
    type: HostListener,
    args: ["document:click"]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(RecepcionLayout, { className: "RecepcionLayout", filePath: "src/app/pages/recepcion-layout/recepcion-layout.ts", lineNumber: 19 });
})();
export {
  RecepcionLayout
};
//# sourceMappingURL=chunk-BQAKLEYL.js.map
