import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel,
  NgSelectOption,
  SelectControlValueAccessor,
  ɵNgSelectMultipleOption
} from "./chunk-2GLX7GEQ.js";
import {
  RevisionService
} from "./chunk-DFMBCVKM.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DatePipe,
  HttpClient,
  Injectable,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-O4ZH52IX.js";

// src/app/core/services/historial.service.ts
var HistorialService = class _HistorialService {
  http;
  apiUrl = "/api/revision/historial";
  constructor(http) {
    this.http = http;
  }
  listar(texto, estatus, fechaDesde, fechaHasta) {
    const params = {};
    if (texto)
      params["texto"] = texto;
    if (estatus)
      params["estatus"] = estatus;
    if (fechaDesde)
      params["fechaDesde"] = fechaDesde;
    if (fechaHasta)
      params["fechaHasta"] = fechaHasta;
    return this.http.get(this.apiUrl, { params });
  }
  /** El endpoint exige JWT -- se descarga como blob (no un <a href> directo) para poder
   * mandar el Authorization header, igual que la descarga de evidencias. */
  exportar(texto, estatus, fechaDesde, fechaHasta) {
    const params = {};
    if (texto)
      params["texto"] = texto;
    if (estatus)
      params["estatus"] = estatus;
    if (fechaDesde)
      params["fechaDesde"] = fechaDesde;
    if (fechaHasta)
      params["fechaHasta"] = fechaHasta;
    return this.http.get(`${this.apiUrl}/exportar`, { params, responseType: "blob" });
  }
  static \u0275fac = function HistorialService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _HistorialService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _HistorialService, factory: _HistorialService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HistorialService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/historial/historial.ts
var _forTrack0 = ($index, $item) => $item.numeroFolio;
function Historial_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 19);
    \u0275\u0275text(1, "Cargando historial\u2026");
    \u0275\u0275elementEnd();
  }
}
function Historial_Conditional_32_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 20);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(1, "svg", 22);
    \u0275\u0275element(2, "path", 23)(3, "polyline", 24);
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(4, "p");
    \u0275\u0275text(5, "No hay tr\xE1mites que coincidan con los filtros.");
    \u0275\u0275elementEnd()();
  }
}
function Historial_Conditional_33_For_17_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 30);
    \u0275\u0275listener("click", function Historial_Conditional_33_For_17_Conditional_14_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r1);
      const item_r2 = \u0275\u0275nextContext().$implicit;
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.verDetalle(item_r2.numeroFolio));
    });
    \u0275\u0275text(1, "Ver Motivo");
    \u0275\u0275elementEnd();
  }
}
function Historial_Conditional_33_For_17_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 31);
    \u0275\u0275listener("click", function Historial_Conditional_33_For_17_Conditional_15_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r4);
      const item_r2 = \u0275\u0275nextContext().$implicit;
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.verDetalle(item_r2.numeroFolio));
    });
    \u0275\u0275text(1, "Ver Detalle");
    \u0275\u0275elementEnd();
  }
}
function Historial_Conditional_33_For_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td");
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "date");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "td");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "td");
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "td")(11, "span", 27);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "td");
    \u0275\u0275conditionalCreate(14, Historial_Conditional_33_For_17_Conditional_14_Template, 2, 0, "button", 28)(15, Historial_Conditional_33_For_17_Conditional_15_Template, 2, 0, "button", 29);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const item_r2 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r2.numeroFolio);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(5, 10, item_r2.fechaCreacion, "dd/MM/yy"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(item_r2.nombreQuejoso);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r2.tipoIngreso);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("exito", item_r2.estatusFinal === "TURNADO")("peligro", item_r2.estatusFinal === "RECHAZADO");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", item_r2.estatusFinal, " ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(item_r2.estatusFinal === "RECHAZADO" ? 14 : 15);
  }
}
function Historial_Conditional_33_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "table", 25)(1, "thead")(2, "tr")(3, "th");
    \u0275\u0275text(4, "Folio");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "th");
    \u0275\u0275text(6, "Fecha Recibido");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "th");
    \u0275\u0275text(8, "Quejoso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "th");
    \u0275\u0275text(10, "Tipo de Ingreso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "th");
    \u0275\u0275text(12, "Estatus Final");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "th");
    \u0275\u0275text(14, "Acciones");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(15, "tbody");
    \u0275\u0275repeaterCreate(16, Historial_Conditional_33_For_17_Template, 16, 13, "tr", null, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "p", 26);
    \u0275\u0275text(19);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(16);
    \u0275\u0275repeater(ctx_r2.items);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Mostrando ", ctx_r2.items.length, " registro(s) procesado(s).");
  }
}
function Historial_Conditional_34_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 37);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r2.detalleSeleccionado.motivoRechazo);
  }
}
function Historial_Conditional_34_Conditional_20_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 36)(1, "strong");
    \u0275\u0275text(2, "Comentarios:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", ctx_r2.detalleSeleccionado.comentariosRecepcion);
  }
}
function Historial_Conditional_34_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 36)(1, "strong");
    \u0275\u0275text(2, "\xC1rea:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 36)(5, "strong");
    \u0275\u0275text(6, "Defensor asignado:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(8, Historial_Conditional_34_Conditional_20_Conditional_8_Template, 4, 1, "p", 36);
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", ctx_r2.detalleSeleccionado.areaTurnada);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", ctx_r2.detalleSeleccionado.defensorAsignado);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.detalleSeleccionado.comentariosRecepcion ? 8 : -1);
  }
}
function Historial_Conditional_34_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 32);
    \u0275\u0275listener("click", function Historial_Conditional_34_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.cerrarDetalle());
    });
    \u0275\u0275elementStart(1, "div", 33);
    \u0275\u0275listener("click", function Historial_Conditional_34_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 34)(3, "h3");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 35);
    \u0275\u0275listener("click", function Historial_Conditional_34_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.cerrarDetalle());
    });
    \u0275\u0275text(6, "\u2715");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "p", 36)(8, "strong");
    \u0275\u0275text(9, "Quejoso:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "p", 36)(12, "strong");
    \u0275\u0275text(13, "Motivo:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "p", 36)(16, "strong");
    \u0275\u0275text(17, "Estatus:");
    \u0275\u0275elementEnd();
    \u0275\u0275text(18);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(19, Historial_Conditional_34_Conditional_19_Template, 2, 1, "p", 37)(20, Historial_Conditional_34_Conditional_20_Template, 9, 3);
    \u0275\u0275elementStart(21, "div", 38)(22, "button", 17);
    \u0275\u0275listener("click", function Historial_Conditional_34_Template_button_click_22_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.cerrarDetalle());
    });
    \u0275\u0275text(23, "Cerrar");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r2.detalleSeleccionado.numeroFolio);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1(" ", ctx_r2.detalleSeleccionado.nombreCompletoQuejoso);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", ctx_r2.detalleSeleccionado.motivo);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", ctx_r2.detalleSeleccionado.estatus);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.detalleSeleccionado.estatus === "RECHAZADA" ? 19 : ctx_r2.detalleSeleccionado.estatus === "TURNADA" ? 20 : -1);
  }
}
var Historial = class _Historial {
  historialService;
  revisionService;
  toast;
  cdr;
  items = [];
  cargando = true;
  exportando = false;
  filtroTexto = "";
  filtroEstatus = "";
  filtroFechaDesde = "";
  filtroFechaHasta = "";
  mostrarModalDetalle = false;
  detalleSeleccionado = null;
  constructor(historialService, revisionService, toast, cdr) {
    this.historialService = historialService;
    this.revisionService = revisionService;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.aplicarFiltros();
  }
  aplicarFiltros() {
    if (this.filtroFechaDesde && this.filtroFechaHasta && this.filtroFechaDesde > this.filtroFechaHasta) {
      this.toast.advertencia('La fecha "Desde" no puede ser posterior a la fecha "Hasta".');
      return;
    }
    this.cargando = true;
    this.historialService.listar(this.filtroTexto, this.filtroEstatus, this.filtroFechaDesde, this.filtroFechaHasta).subscribe({
      next: (items) => {
        this.items = items;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.toast.error("No se pudo cargar el historial.");
        this.cdr.detectChanges();
      }
    });
  }
  verDetalle(folio) {
    this.revisionService.detalle(folio).subscribe({
      next: (detalle) => {
        this.detalleSeleccionado = detalle;
        this.mostrarModalDetalle = true;
        this.cdr.detectChanges();
      },
      error: () => this.toast.error("No se pudo cargar el detalle de la queja.")
    });
  }
  cerrarDetalle() {
    this.mostrarModalDetalle = false;
    this.detalleSeleccionado = null;
  }
  exportar() {
    this.exportando = true;
    this.historialService.exportar(this.filtroTexto, this.filtroEstatus, this.filtroFechaDesde, this.filtroFechaHasta).subscribe({
      next: (blob) => {
        this.exportando = false;
        const url = URL.createObjectURL(blob);
        const enlace = document.createElement("a");
        enlace.href = url;
        enlace.download = "historial-tramites.xlsx";
        enlace.click();
        URL.revokeObjectURL(url);
        this.cdr.detectChanges();
      },
      error: () => {
        this.exportando = false;
        this.toast.error("No se pudo exportar el reporte.");
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function Historial_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Historial)(\u0275\u0275directiveInject(HistorialService), \u0275\u0275directiveInject(RevisionService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Historial, selectors: [["app-historial"]], decls: 35, vars: 8, consts: [[1, "page-header"], [1, "page-header-subtitulo"], [1, "card"], [1, "fila-filtros"], [1, "buscador", "buscador-ancho"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["cx", "11", "cy", "11", "r", "8"], ["x1", "21", "y1", "21", "x2", "16.65", "y2", "16.65"], ["type", "text", "name", "filtroTexto", "placeholder", "Buscar por Folio (DDP-XXXX), Nombre o Unidad Acad\xE9mica", 3, "ngModelChange", "ngModel"], ["name", "filtroEstatus", 1, "select-estatus", 3, "ngModelChange", "ngModel"], ["value", ""], ["value", "TURNADO"], ["value", "RECHAZADO"], [1, "filtro-rango-fechas"], [1, "etiqueta-rango"], ["type", "date", "name", "filtroFechaDesde", 3, "ngModelChange", "ngModel"], ["type", "date", "name", "filtroFechaHasta", 3, "ngModelChange", "ngModel"], [1, "btn-primary", 3, "click"], [1, "btn-secondary", 3, "click", "disabled"], [1, "cargando"], [1, "estado-vacio"], [1, "modal-overlay"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round", 1, "estado-vacio-icono"], ["d", "M3 12a9 9 0 1 0 3-6.7"], ["points", "3 4 3 9 8 9"], [1, "tabla-admin"], [1, "pie-conteo"], [1, "badge"], [1, "btn-texto", "peligro"], [1, "btn-texto"], [1, "btn-texto", "peligro", 3, "click"], [1, "btn-texto", 3, "click"], [1, "modal-overlay", 3, "click"], [1, "modal", "card", 3, "click"], [1, "modal-header"], ["aria-label", "Cerrar", 1, "modal-cerrar", 3, "click"], [1, "detalle-linea"], [1, "aviso-peligro"], [1, "modal-acciones"]], template: function Historial_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "div")(2, "h2");
      \u0275\u0275text(3, "Historial de Tr\xE1mites Recibidos");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(4, "p", 1);
      \u0275\u0275text(5, "Consulta de quejas ya turnadas o rechazadas.");
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(6, "div", 2)(7, "div", 3)(8, "div", 4);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(9, "svg", 5);
      \u0275\u0275element(10, "circle", 6)(11, "line", 7);
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(12, "input", 8);
      \u0275\u0275twoWayListener("ngModelChange", function Historial_Template_input_ngModelChange_12_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.filtroTexto, $event) || (ctx.filtroTexto = $event);
        return $event;
      });
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(13, "select", 9);
      \u0275\u0275twoWayListener("ngModelChange", function Historial_Template_select_ngModelChange_13_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.filtroEstatus, $event) || (ctx.filtroEstatus = $event);
        return $event;
      });
      \u0275\u0275elementStart(14, "option", 10);
      \u0275\u0275text(15, "Estatus");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(16, "option", 11);
      \u0275\u0275text(17, "Turnado");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(18, "option", 12);
      \u0275\u0275text(19, "Rechazado");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(20, "div", 13)(21, "label", 14);
      \u0275\u0275text(22, "Desde ");
      \u0275\u0275elementStart(23, "input", 15);
      \u0275\u0275twoWayListener("ngModelChange", function Historial_Template_input_ngModelChange_23_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.filtroFechaDesde, $event) || (ctx.filtroFechaDesde = $event);
        return $event;
      });
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(24, "label", 14);
      \u0275\u0275text(25, "Hasta ");
      \u0275\u0275elementStart(26, "input", 16);
      \u0275\u0275twoWayListener("ngModelChange", function Historial_Template_input_ngModelChange_26_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.filtroFechaHasta, $event) || (ctx.filtroFechaHasta = $event);
        return $event;
      });
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(27, "button", 17);
      \u0275\u0275listener("click", function Historial_Template_button_click_27_listener() {
        return ctx.aplicarFiltros();
      });
      \u0275\u0275text(28, "Aplicar Filtros");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(29, "button", 18);
      \u0275\u0275listener("click", function Historial_Template_button_click_29_listener() {
        return ctx.exportar();
      });
      \u0275\u0275text(30);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(31, Historial_Conditional_31_Template, 2, 0, "p", 19)(32, Historial_Conditional_32_Template, 6, 0, "div", 20)(33, Historial_Conditional_33_Template, 20, 1);
      \u0275\u0275elementEnd();
      \u0275\u0275conditionalCreate(34, Historial_Conditional_34_Template, 24, 5, "div", 21);
    }
    if (rf & 2) {
      \u0275\u0275advance(12);
      \u0275\u0275twoWayProperty("ngModel", ctx.filtroTexto);
      \u0275\u0275advance();
      \u0275\u0275twoWayProperty("ngModel", ctx.filtroEstatus);
      \u0275\u0275advance(10);
      \u0275\u0275twoWayProperty("ngModel", ctx.filtroFechaDesde);
      \u0275\u0275advance(3);
      \u0275\u0275twoWayProperty("ngModel", ctx.filtroFechaHasta);
      \u0275\u0275advance(3);
      \u0275\u0275property("disabled", ctx.exportando);
      \u0275\u0275advance();
      \u0275\u0275textInterpolate1(" ", ctx.exportando ? "Exportando\u2026" : "Exportar Reporte (Excel)", " ");
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.cargando ? 31 : ctx.items.length === 0 ? 32 : 33);
      \u0275\u0275advance(3);
      \u0275\u0275conditional(ctx.mostrarModalDetalle && ctx.detalleSeleccionado ? 34 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, NgSelectOption, \u0275NgSelectMultipleOption, DefaultValueAccessor, SelectControlValueAccessor, NgControlStatus, NgModel, DatePipe], styles: ["\n.fila-filtros[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  flex-wrap: wrap;\n  margin-bottom: 18px;\n}\n.fila-filtros[_ngcontent-%COMP%]   select[_ngcontent-%COMP%], \n.fila-filtros[_ngcontent-%COMP%]   input[type=date][_ngcontent-%COMP%] {\n  padding: 9px 12px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font-size: 0.88rem;\n}\n.fila-filtros[_ngcontent-%COMP%]   .select-estatus[_ngcontent-%COMP%] {\n  max-width: 160px;\n}\n.buscador-ancho[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 220px;\n  max-width: none;\n}\n.filtro-rango-fechas[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.etiqueta-rango[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n  white-space: nowrap;\n}\n.cargando[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.pie-conteo[_ngcontent-%COMP%] {\n  margin-top: 14px;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n}\n.detalle-linea[_ngcontent-%COMP%] {\n  font-size: 0.9rem;\n  margin: 0 0 8px;\n}\n/*# sourceMappingURL=historial.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Historial, [{
    type: Component,
    args: [{ selector: "app-historial", standalone: true, imports: [CommonModule, FormsModule], template: `<div class="page-header">
  <div>
    <h2>Historial de Tr\xE1mites Recibidos</h2>
    <p class="page-header-subtitulo">Consulta de quejas ya turnadas o rechazadas.</p>
  </div>
</div>

<div class="card">
  <div class="fila-filtros">
    <div class="buscador buscador-ancho">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
      <input type="text" [(ngModel)]="filtroTexto" name="filtroTexto" placeholder="Buscar por Folio (DDP-XXXX), Nombre o Unidad Acad\xE9mica" />
    </div>
    <select [(ngModel)]="filtroEstatus" name="filtroEstatus" class="select-estatus">
      <option value="">Estatus</option>
      <option value="TURNADO">Turnado</option>
      <option value="RECHAZADO">Rechazado</option>
    </select>
    <div class="filtro-rango-fechas">
      <label class="etiqueta-rango">Desde
        <input type="date" [(ngModel)]="filtroFechaDesde" name="filtroFechaDesde" />
      </label>
      <label class="etiqueta-rango">Hasta
        <input type="date" [(ngModel)]="filtroFechaHasta" name="filtroFechaHasta" />
      </label>
    </div>
    <button class="btn-primary" (click)="aplicarFiltros()">Aplicar Filtros</button>
    <button class="btn-secondary" (click)="exportar()" [disabled]="exportando">
      {{ exportando ? 'Exportando\u2026' : 'Exportar Reporte (Excel)' }}
    </button>
  </div>

  @if (cargando) {
    <p class="cargando">Cargando historial\u2026</p>
  } @else if (items.length === 0) {
    <div class="estado-vacio">
      <svg class="estado-vacio-icono" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"></path><polyline points="3 4 3 9 8 9"></polyline></svg>
      <p>No hay tr\xE1mites que coincidan con los filtros.</p>
    </div>
  } @else {
    <table class="tabla-admin">
      <thead>
        <tr>
          <th>Folio</th>
          <th>Fecha Recibido</th>
          <th>Quejoso</th>
          <th>Tipo de Ingreso</th>
          <th>Estatus Final</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        @for (item of items; track item.numeroFolio) {
          <tr>
            <td>{{ item.numeroFolio }}</td>
            <td>{{ item.fechaCreacion | date: 'dd/MM/yy' }}</td>
            <td>{{ item.nombreQuejoso }}</td>
            <td>{{ item.tipoIngreso }}</td>
            <td>
              <span class="badge" [class.exito]="item.estatusFinal === 'TURNADO'" [class.peligro]="item.estatusFinal === 'RECHAZADO'">
                {{ item.estatusFinal }}
              </span>
            </td>
            <td>
              @if (item.estatusFinal === 'RECHAZADO') {
                <button class="btn-texto peligro" (click)="verDetalle(item.numeroFolio)">Ver Motivo</button>
              } @else {
                <button class="btn-texto" (click)="verDetalle(item.numeroFolio)">Ver Detalle</button>
              }
            </td>
          </tr>
        }
      </tbody>
    </table>
    <p class="pie-conteo">Mostrando {{ items.length }} registro(s) procesado(s).</p>
  }
</div>

@if (mostrarModalDetalle && detalleSeleccionado) {
  <div class="modal-overlay" (click)="cerrarDetalle()">
    <div class="modal card" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>{{ detalleSeleccionado.numeroFolio }}</h3>
        <button class="modal-cerrar" (click)="cerrarDetalle()" aria-label="Cerrar">\u2715</button>
      </div>

      <p class="detalle-linea"><strong>Quejoso:</strong> {{ detalleSeleccionado.nombreCompletoQuejoso }}</p>
      <p class="detalle-linea"><strong>Motivo:</strong> {{ detalleSeleccionado.motivo }}</p>
      <p class="detalle-linea"><strong>Estatus:</strong> {{ detalleSeleccionado.estatus }}</p>

      @if (detalleSeleccionado.estatus === 'RECHAZADA') {
        <p class="aviso-peligro">{{ detalleSeleccionado.motivoRechazo }}</p>
      } @else if (detalleSeleccionado.estatus === 'TURNADA') {
        <p class="detalle-linea"><strong>\xC1rea:</strong> {{ detalleSeleccionado.areaTurnada }}</p>
        <p class="detalle-linea"><strong>Defensor asignado:</strong> {{ detalleSeleccionado.defensorAsignado }}</p>
        @if (detalleSeleccionado.comentariosRecepcion) {
          <p class="detalle-linea"><strong>Comentarios:</strong> {{ detalleSeleccionado.comentariosRecepcion }}</p>
        }
      }

      <div class="modal-acciones">
        <button class="btn-primary" (click)="cerrarDetalle()">Cerrar</button>
      </div>
    </div>
  </div>
}
`, styles: ["/* src/app/pages/historial/historial.scss */\n.fila-filtros {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  flex-wrap: wrap;\n  margin-bottom: 18px;\n}\n.fila-filtros select,\n.fila-filtros input[type=date] {\n  padding: 9px 12px;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  font-size: 0.88rem;\n}\n.fila-filtros .select-estatus {\n  max-width: 160px;\n}\n.buscador-ancho {\n  flex: 1;\n  min-width: 220px;\n  max-width: none;\n}\n.filtro-rango-fechas {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.etiqueta-rango {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n  white-space: nowrap;\n}\n.cargando {\n  color: var(--texto-suave);\n}\n.pie-conteo {\n  margin-top: 14px;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n}\n.detalle-linea {\n  font-size: 0.9rem;\n  margin: 0 0 8px;\n}\n/*# sourceMappingURL=historial.css.map */\n"] }]
  }], () => [{ type: HistorialService }, { type: RevisionService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Historial, { className: "Historial", filePath: "src/app/pages/historial/historial.ts", lineNumber: 17 });
})();
export {
  Historial
};
//# sourceMappingURL=chunk-BRLVHE4K.js.map
