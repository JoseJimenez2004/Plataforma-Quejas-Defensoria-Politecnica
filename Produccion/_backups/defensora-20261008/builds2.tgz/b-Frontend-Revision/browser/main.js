import {
  AuthRevisionService,
  RUTA_PANEL_DEFENSORA,
  esRolDefensora
} from "./chunk-6EXO4JCA.js";
import {
  Router,
  RouterOutlet,
  bootstrapApplication,
  provideRouter
} from "./chunk-7JMYQEZG.js";
import {
  ApplicationRef,
  CommonModule,
  Component,
  ToastService,
  catchError,
  inject,
  provideHttpClient,
  setClassMetadata,
  tap,
  throwError,
  withInterceptors,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassMap,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵdomElementEnd,
  ɵɵdomElementStart,
  ɵɵdomListener,
  ɵɵelement,
  ɵɵgetCurrentView,
  ɵɵnextContext,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate
} from "./chunk-O4ZH52IX.js";

// src/app/core/guards/auth-revision.guard.ts
var authRevisionGuard = () => {
  const authService = inject(AuthRevisionService);
  const router = inject(Router);
  if (authService.isLoggedIn()) {
    const rol = localStorage.getItem("ddp_revision_rol");
    if (esRolDefensora(rol)) {
      window.location.assign(RUTA_PANEL_DEFENSORA);
      return false;
    }
    return true;
  }
  if (esRolDefensora(localStorage.getItem("ddp_admin_rol")) && localStorage.getItem("ddp_admin_token")) {
    window.location.assign(RUTA_PANEL_DEFENSORA);
    return false;
  }
  router.navigate(["/login"]);
  return false;
};

// src/app/app.routes.ts
var routes = [
  {
    path: "login",
    loadComponent: () => import("./chunk-556EWCDR.js").then((m) => m.Login)
  },
  {
    path: "",
    loadComponent: () => import("./chunk-BQAKLEYL.js").then((m) => m.RecepcionLayout),
    canActivate: [authRevisionGuard],
    children: [
      {
        path: "",
        loadComponent: () => import("./chunk-FP3HQR7R.js").then((m) => m.Bandeja)
      },
      {
        path: "validacion/:folio",
        loadComponent: () => import("./chunk-QWXMQ4U7.js").then((m) => m.Validacion)
      },
      {
        path: "rechazo/:folio",
        loadComponent: () => import("./chunk-HWCH2HQP.js").then((m) => m.Rechazo)
      },
      {
        path: "turnado/:folio",
        loadComponent: () => import("./chunk-WFB6N2PU.js").then((m) => m.Turnado)
      },
      {
        path: "registro-manual",
        loadComponent: () => import("./chunk-OFH3RXML.js").then((m) => m.RegistroManual)
      },
      {
        path: "historial",
        loadComponent: () => import("./chunk-BRLVHE4K.js").then((m) => m.Historial)
      }
    ]
  },
  { path: "**", redirectTo: "" }
];

// src/app/core/interceptors/jwt-revision.interceptor.ts
var jwtRevisionInterceptor = (req, next) => {
  const authService = inject(AuthRevisionService);
  const router = inject(Router);
  const token = authService.getToken();
  if (token && req.url.startsWith("/api/")) {
    req = req.clone({
      setHeaders: { Authorization: `Bearer ${token}` }
    });
  }
  return next(req).pipe(catchError((err) => {
    if (err.status === 401 && req.url.startsWith("/api/") && !req.url.startsWith("/api/notificaciones/")) {
      authService.logout();
      router.navigate(["/login"]);
    }
    return throwError(() => err);
  }));
};

// src/app/core/interceptors/change-detection.interceptor.ts
var changeDetectionInterceptor = (req, next) => {
  const appRef = inject(ApplicationRef);
  return next(req).pipe(tap(() => {
    setTimeout(() => {
      try {
        appRef.tick();
      } catch {
      }
    }, 0);
  }));
};

// src/app/app.config.ts
var appConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(withInterceptors([jwtRevisionInterceptor, changeDetectionInterceptor]))
  ]
};

// src/app/shared/toast/toast.ts
var _forTrack0 = ($index, $item) => $item.id;
function Toast_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275domElementStart(0, "div", 2)(1, "span");
    \u0275\u0275text(2);
    \u0275\u0275domElementEnd();
    \u0275\u0275domElementStart(3, "button", 3);
    \u0275\u0275domListener("click", function Toast_For_2_Template_button_click_3_listener() {
      const mensaje_r2 = \u0275\u0275restoreView(_r1).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.toastService.descartar(mensaje_r2.id));
    });
    \u0275\u0275text(4, "\u2715");
    \u0275\u0275domElementEnd()();
  }
  if (rf & 2) {
    const mensaje_r2 = ctx.$implicit;
    \u0275\u0275classMap(mensaje_r2.tipo);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(mensaje_r2.texto);
  }
}
var Toast = class _Toast {
  toastService;
  constructor(toastService) {
    this.toastService = toastService;
  }
  static \u0275fac = function Toast_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Toast)(\u0275\u0275directiveInject(ToastService));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Toast, selectors: [["app-toast"]], decls: 3, vars: 0, consts: [[1, "toast-contenedor"], [1, "toast", 3, "class"], [1, "toast"], ["type", "button", "aria-label", "Cerrar", 3, "click"]], template: function Toast_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275domElementStart(0, "div", 0);
      \u0275\u0275repeaterCreate(1, Toast_For_2_Template, 5, 3, "div", 1, _forTrack0);
      \u0275\u0275domElementEnd();
    }
    if (rf & 2) {
      \u0275\u0275advance();
      \u0275\u0275repeater(ctx.toastService.mensajes());
    }
  }, dependencies: [CommonModule], styles: ["\n.toast-contenedor[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 16px;\n  right: 16px;\n  z-index: 500;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n  max-width: 340px;\n}\n.toast[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 10px;\n  padding: 12px 14px;\n  border-radius: 8px;\n  color: #fff;\n  font-size: 0.85rem;\n  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.15);\n  animation: _ngcontent-%COMP%_toast-entrada 0.2s ease both;\n}\n.toast[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  color: inherit;\n  opacity: 0.8;\n  font-size: 0.9rem;\n}\n.toast[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover {\n  opacity: 1;\n}\n.toast.exito[_ngcontent-%COMP%] {\n  background: #2e7d32;\n}\n.toast.error[_ngcontent-%COMP%] {\n  background: #c62828;\n}\n.toast.advertencia[_ngcontent-%COMP%] {\n  background: #b8860b;\n}\n.toast.info[_ngcontent-%COMP%] {\n  background: #37474f;\n}\n@keyframes _ngcontent-%COMP%_toast-entrada {\n  from {\n    opacity: 0;\n    transform: translateX(20px);\n  }\n  to {\n    opacity: 1;\n    transform: translateX(0);\n  }\n}\n/*# sourceMappingURL=toast.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Toast, [{
    type: Component,
    args: [{ selector: "app-toast", standalone: true, imports: [CommonModule], template: '<div class="toast-contenedor">\n  @for (mensaje of toastService.mensajes(); track mensaje.id) {\n    <div class="toast" [class]="mensaje.tipo">\n      <span>{{ mensaje.texto }}</span>\n      <button type="button" (click)="toastService.descartar(mensaje.id)" aria-label="Cerrar">\u2715</button>\n    </div>\n  }\n</div>\n', styles: ["/* src/app/shared/toast/toast.scss */\n.toast-contenedor {\n  position: fixed;\n  top: 16px;\n  right: 16px;\n  z-index: 500;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n  max-width: 340px;\n}\n.toast {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 10px;\n  padding: 12px 14px;\n  border-radius: 8px;\n  color: #fff;\n  font-size: 0.85rem;\n  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.15);\n  animation: toast-entrada 0.2s ease both;\n}\n.toast button {\n  background: none;\n  border: none;\n  color: inherit;\n  opacity: 0.8;\n  font-size: 0.9rem;\n}\n.toast button:hover {\n  opacity: 1;\n}\n.toast.exito {\n  background: #2e7d32;\n}\n.toast.error {\n  background: #c62828;\n}\n.toast.advertencia {\n  background: #b8860b;\n}\n.toast.info {\n  background: #37474f;\n}\n@keyframes toast-entrada {\n  from {\n    opacity: 0;\n    transform: translateX(20px);\n  }\n  to {\n    opacity: 1;\n    transform: translateX(0);\n  }\n}\n/*# sourceMappingURL=toast.css.map */\n"] }]
  }], () => [{ type: ToastService }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Toast, { className: "Toast", filePath: "src/app/shared/toast/toast.ts", lineNumber: 13 });
})();

// src/app/app.ts
var App = class _App {
  static \u0275fac = function App_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _App)();
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _App, selectors: [["app-root"]], decls: 2, vars: 0, template: function App_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275element(0, "app-toast")(1, "router-outlet");
    }
  }, dependencies: [RouterOutlet, Toast], styles: ["\n[_nghost-%COMP%] {\n  display: block;\n}\n/*# sourceMappingURL=app.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(App, [{
    type: Component,
    args: [{ selector: "app-root", standalone: true, imports: [RouterOutlet, Toast], template: "<app-toast />\n<router-outlet />\n", styles: ["/* src/app/app.scss */\n:host {\n  display: block;\n}\n/*# sourceMappingURL=app.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(App, { className: "App", filePath: "src/app/app.ts", lineNumber: 13 });
})();

// src/main.ts
bootstrapApplication(App, appConfig).catch((err) => console.error(err));
//# sourceMappingURL=main.js.map
