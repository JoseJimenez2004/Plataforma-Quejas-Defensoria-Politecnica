import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel,
  NgSelectOption,
  SelectControlValueAccessor,
  ɵNgSelectMultipleOption
} from "./chunk-2GLX7GEQ.js";
import {
  RevisionService
} from "./chunk-DFMBCVKM.js";
import {
  Router
} from "./chunk-7JMYQEZG.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-O4ZH52IX.js";

// src/app/pages/registro-manual/registro-manual.ts
var _forTrack0 = ($index, $item) => $item.clave;
function RegistroManual_For_63_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 22);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const area_r1 = ctx.$implicit;
    \u0275\u0275property("value", area_r1.clave);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(area_r1.nombre);
  }
}
var RegistroManual = class _RegistroManual {
  revisionService;
  toast;
  router;
  cdr;
  areas = [];
  guardando = false;
  archivoSeleccionado = null;
  nombreArchivo = "";
  formulario = this.formularioVacio();
  constructor(revisionService, toast, router, cdr) {
    this.revisionService = revisionService;
    this.toast = toast;
    this.router = router;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.revisionService.areas().subscribe({
      next: (areas) => {
        this.areas = areas;
        this.cdr.detectChanges();
      },
      error: () => {
      }
    });
  }
  onArchivoSeleccionado(event) {
    const input = event.target;
    const archivo = input.files?.[0] ?? null;
    this.archivoSeleccionado = archivo;
    this.nombreArchivo = archivo?.name ?? "";
  }
  limpiarFormulario() {
    this.formulario = this.formularioVacio();
    this.archivoSeleccionado = null;
    this.nombreArchivo = "";
  }
  guardar() {
    if (!this.formulario.nombre || !this.formulario.apellido1 || !this.formulario.descripcion) {
      this.toast.advertencia("Completa al menos nombre, primer apellido y descripci\xF3n del asunto.");
      return;
    }
    const datos = new FormData();
    datos.append("nombre", this.formulario.nombre);
    datos.append("apellido1", this.formulario.apellido1);
    if (this.formulario.apellido2)
      datos.append("apellido2", this.formulario.apellido2);
    if (this.formulario.tipoUsuario)
      datos.append("tipoUsuario", this.formulario.tipoUsuario);
    if (this.formulario.dependenciaClave)
      datos.append("dependenciaClave", this.formulario.dependenciaClave);
    if (this.formulario.numeroOficio)
      datos.append("numeroOficio", this.formulario.numeroOficio);
    if (this.formulario.fechaRecepcionFisica)
      datos.append("fechaRecepcionFisica", this.formulario.fechaRecepcionFisica);
    if (this.formulario.tipoDocumento)
      datos.append("tipoDocumento", this.formulario.tipoDocumento);
    datos.append("descripcion", this.formulario.descripcion);
    if (this.formulario.ubicacionFisica)
      datos.append("ubicacionFisica", this.formulario.ubicacionFisica);
    if (this.formulario.correoContacto)
      datos.append("correoContacto", this.formulario.correoContacto);
    if (this.formulario.telefonoContacto)
      datos.append("telefonoContacto", this.formulario.telefonoContacto);
    if (this.archivoSeleccionado)
      datos.append("archivo", this.archivoSeleccionado);
    this.guardando = true;
    this.revisionService.registrarManual(datos).subscribe({
      next: (resp) => {
        this.guardando = false;
        this.toast.exito(resp.mensaje);
        this.limpiarFormulario();
        this.router.navigate(["/"]);
      },
      error: (err) => {
        this.guardando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo registrar la entrada.");
        this.cdr.detectChanges();
      }
    });
  }
  formularioVacio() {
    return {
      nombre: "",
      apellido1: "",
      apellido2: "",
      tipoUsuario: "",
      dependenciaClave: "",
      numeroOficio: "",
      fechaRecepcionFisica: "",
      tipoDocumento: "",
      descripcion: "",
      ubicacionFisica: "",
      correoContacto: "",
      telefonoContacto: ""
    };
  }
  static \u0275fac = function RegistroManual_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _RegistroManual)(\u0275\u0275directiveInject(RevisionService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _RegistroManual, selectors: [["app-registro-manual"]], decls: 97, vars: 15, consts: [[1, "page-header"], [1, "page-header-subtitulo"], [1, "card"], [1, "grid-2"], [1, "input-group"], ["type", "text", "name", "nombre", 3, "ngModelChange", "ngModel"], ["type", "text", "name", "numeroOficio", 3, "ngModelChange", "ngModel"], ["type", "text", "name", "apellido1", 3, "ngModelChange", "ngModel"], ["type", "date", "name", "fechaRecepcionFisica", 3, "ngModelChange", "ngModel"], ["type", "text", "name", "apellido2", 3, "ngModelChange", "ngModel"], ["name", "tipoDocumento", 3, "ngModelChange", "ngModel"], ["value", "", "disabled", "", "selected", ""], ["value", "IDENTIFICACION"], ["value", "OFICIO"], ["value", "ESCRITO_LIBRE"], ["value", "OTRO"], ["name", "tipoUsuario", 3, "ngModelChange", "ngModel"], ["value", "alumno"], ["value", "empleado"], ["value", "externo"], ["name", "dependenciaClave", 3, "ngModelChange", "ngModel"], ["value", "", "selected", ""], [3, "value"], ["type", "email", "name", "correoContacto", "placeholder", "Si el quejoso lo proporciona", 3, "ngModelChange", "ngModel"], ["type", "tel", "name", "telefonoContacto", "placeholder", "Si el quejoso lo proporciona", 3, "ngModelChange", "ngModel"], [1, "aviso-inline"], [1, "card", "seccion-descripcion"], ["rows", "4", "name", "descripcion", 3, "ngModelChange", "ngModel"], [1, "input-group", "sin-margen"], ["type", "text", "name", "ubicacionFisica", "placeholder", "Ej. Archivero 3, carpeta 12", 3, "ngModelChange", "ngModel"], [1, "card", "seccion-archivo"], [1, "etiqueta-archivo"], [1, "zona-archivo"], [1, "btn-secondary", "boton-archivo"], ["type", "file", "accept", ".pdf,.jpg,.jpeg,.png", "hidden", "", 3, "change"], [1, "pie-formulario"], [1, "btn-texto", 3, "click"], [1, "btn-primary", 3, "click", "disabled"]], template: function RegistroManual_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "div")(2, "h2");
      \u0275\u0275text(3, "Registro Manual de Nueva Queja");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(4, "p", 1);
      \u0275\u0275text(5, "Ingresa los datos del documento f\xEDsico para generar un folio de seguimiento.");
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(6, "div", 2)(7, "h3");
      \u0275\u0275text(8, "Datos del Emisor");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(9, "div", 3)(10, "div", 4)(11, "label");
      \u0275\u0275text(12, "Nombre del Denunciante:");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(13, "input", 5);
      \u0275\u0275twoWayListener("ngModelChange", function RegistroManual_Template_input_ngModelChange_13_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.formulario.nombre, $event) || (ctx.formulario.nombre = $event);
        return $event;
      });
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(14, "div", 4)(15, "label");
      \u0275\u0275text(16, "N\xFAmero de Oficio (Si aplica):");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(17, "input", 6);
      \u0275\u0275twoWayListener("ngModelChange", function RegistroManual_Template_input_ngModelChange_17_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.formulario.numeroOficio, $event) || (ctx.formulario.numeroOficio = $event);
        return $event;
      });
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(18, "div", 4)(19, "label");
      \u0275\u0275text(20, "Primer Apellido:");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(21, "input", 7);
      \u0275\u0275twoWayListener("ngModelChange", function RegistroManual_Template_input_ngModelChange_21_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.formulario.apellido1, $event) || (ctx.formulario.apellido1 = $event);
        return $event;
      });
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(22, "div", 4)(23, "label");
      \u0275\u0275text(24, "Fecha de Recepci\xF3n F\xEDsica:");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(25, "input", 8);
      \u0275\u0275twoWayListener("ngModelChange", function RegistroManual_Template_input_ngModelChange_25_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.formulario.fechaRecepcionFisica, $event) || (ctx.formulario.fechaRecepcionFisica = $event);
        return $event;
      });
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(26, "div", 4)(27, "label");
      \u0275\u0275text(28, "Segundo Apellido:");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(29, "input", 9);
      \u0275\u0275twoWayListener("ngModelChange", function RegistroManual_Template_input_ngModelChange_29_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.formulario.apellido2, $event) || (ctx.formulario.apellido2 = $event);
        return $event;
      });
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(30, "div", 4)(31, "label");
      \u0275\u0275text(32, "Tipo de Documento:");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(33, "select", 10);
      \u0275\u0275twoWayListener("ngModelChange", function RegistroManual_Template_select_ngModelChange_33_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.formulario.tipoDocumento, $event) || (ctx.formulario.tipoDocumento = $event);
        return $event;
      });
      \u0275\u0275elementStart(34, "option", 11);
      \u0275\u0275text(35, "Seleccione");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(36, "option", 12);
      \u0275\u0275text(37, "Identificaci\xF3n");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(38, "option", 13);
      \u0275\u0275text(39, "Oficio");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(40, "option", 14);
      \u0275\u0275text(41, "Escrito libre");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(42, "option", 15);
      \u0275\u0275text(43, "Otro");
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(44, "div", 4)(45, "label");
      \u0275\u0275text(46, "Tipo de Usuario:");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(47, "select", 16);
      \u0275\u0275twoWayListener("ngModelChange", function RegistroManual_Template_select_ngModelChange_47_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.formulario.tipoUsuario, $event) || (ctx.formulario.tipoUsuario = $event);
        return $event;
      });
      \u0275\u0275elementStart(48, "option", 11);
      \u0275\u0275text(49, "Seleccione");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(50, "option", 17);
      \u0275\u0275text(51, "Alumno");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(52, "option", 18);
      \u0275\u0275text(53, "Empleado");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(54, "option", 19);
      \u0275\u0275text(55, "Externo");
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(56, "div", 4)(57, "label");
      \u0275\u0275text(58, "Dependencia / Escuela:");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(59, "select", 20);
      \u0275\u0275twoWayListener("ngModelChange", function RegistroManual_Template_select_ngModelChange_59_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.formulario.dependenciaClave, $event) || (ctx.formulario.dependenciaClave = $event);
        return $event;
      });
      \u0275\u0275elementStart(60, "option", 21);
      \u0275\u0275text(61, "Seleccione Unidad Acad\xE9mica");
      \u0275\u0275elementEnd();
      \u0275\u0275repeaterCreate(62, RegistroManual_For_63_Template, 2, 2, "option", 22, _forTrack0);
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(64, "div", 4)(65, "label");
      \u0275\u0275text(66, "Correo de Contacto:");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(67, "input", 23);
      \u0275\u0275twoWayListener("ngModelChange", function RegistroManual_Template_input_ngModelChange_67_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.formulario.correoContacto, $event) || (ctx.formulario.correoContacto = $event);
        return $event;
      });
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(68, "div", 4)(69, "label");
      \u0275\u0275text(70, "Tel\xE9fono de Contacto:");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(71, "input", 24);
      \u0275\u0275twoWayListener("ngModelChange", function RegistroManual_Template_input_ngModelChange_71_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.formulario.telefonoContacto, $event) || (ctx.formulario.telefonoContacto = $event);
        return $event;
      });
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(72, "p", 25);
      \u0275\u0275text(73, "Si capturas un correo de contacto, el quejoso recibir\xE1 ah\xED las notificaciones autom\xE1ticas de rechazo o turnado, igual que en un registro digital.");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(74, "div", 26)(75, "div", 4)(76, "label");
      \u0275\u0275text(77, "Descripci\xF3n Breve del Asunto:");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(78, "textarea", 27);
      \u0275\u0275twoWayListener("ngModelChange", function RegistroManual_Template_textarea_ngModelChange_78_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.formulario.descripcion, $event) || (ctx.formulario.descripcion = $event);
        return $event;
      });
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(79, "div", 28)(80, "label");
      \u0275\u0275text(81, "Ubicaci\xF3n F\xEDsica del Expediente:");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(82, "input", 29);
      \u0275\u0275twoWayListener("ngModelChange", function RegistroManual_Template_input_ngModelChange_82_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.formulario.ubicacionFisica, $event) || (ctx.formulario.ubicacionFisica = $event);
        return $event;
      });
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(83, "div", 30)(84, "label", 31);
      \u0275\u0275text(85, "Digitalizaci\xF3n de Evidencia");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(86, "div", 32)(87, "span");
      \u0275\u0275text(88);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(89, "label", 33);
      \u0275\u0275text(90, " Seleccionar Archivos ");
      \u0275\u0275elementStart(91, "input", 34);
      \u0275\u0275listener("change", function RegistroManual_Template_input_change_91_listener($event) {
        return ctx.onArchivoSeleccionado($event);
      });
      \u0275\u0275elementEnd()()()();
      \u0275\u0275elementStart(92, "div", 35)(93, "button", 36);
      \u0275\u0275listener("click", function RegistroManual_Template_button_click_93_listener() {
        return ctx.limpiarFormulario();
      });
      \u0275\u0275text(94, "Limpiar Formulario");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(95, "button", 37);
      \u0275\u0275listener("click", function RegistroManual_Template_button_click_95_listener() {
        return ctx.guardar();
      });
      \u0275\u0275text(96);
      \u0275\u0275elementEnd()();
    }
    if (rf & 2) {
      \u0275\u0275advance(13);
      \u0275\u0275twoWayProperty("ngModel", ctx.formulario.nombre);
      \u0275\u0275advance(4);
      \u0275\u0275twoWayProperty("ngModel", ctx.formulario.numeroOficio);
      \u0275\u0275advance(4);
      \u0275\u0275twoWayProperty("ngModel", ctx.formulario.apellido1);
      \u0275\u0275advance(4);
      \u0275\u0275twoWayProperty("ngModel", ctx.formulario.fechaRecepcionFisica);
      \u0275\u0275advance(4);
      \u0275\u0275twoWayProperty("ngModel", ctx.formulario.apellido2);
      \u0275\u0275advance(4);
      \u0275\u0275twoWayProperty("ngModel", ctx.formulario.tipoDocumento);
      \u0275\u0275advance(14);
      \u0275\u0275twoWayProperty("ngModel", ctx.formulario.tipoUsuario);
      \u0275\u0275advance(12);
      \u0275\u0275twoWayProperty("ngModel", ctx.formulario.dependenciaClave);
      \u0275\u0275advance(3);
      \u0275\u0275repeater(ctx.areas);
      \u0275\u0275advance(5);
      \u0275\u0275twoWayProperty("ngModel", ctx.formulario.correoContacto);
      \u0275\u0275advance(4);
      \u0275\u0275twoWayProperty("ngModel", ctx.formulario.telefonoContacto);
      \u0275\u0275advance(7);
      \u0275\u0275twoWayProperty("ngModel", ctx.formulario.descripcion);
      \u0275\u0275advance(4);
      \u0275\u0275twoWayProperty("ngModel", ctx.formulario.ubicacionFisica);
      \u0275\u0275advance(6);
      \u0275\u0275textInterpolate(ctx.nombreArchivo || "Escanee y adjunte el documento original (PDF/JPG)");
      \u0275\u0275advance(7);
      \u0275\u0275property("disabled", ctx.guardando);
      \u0275\u0275advance();
      \u0275\u0275textInterpolate1(" ", ctx.guardando ? "Guardando\u2026" : "GUARDAR Y GENERAR ENTRADA", " ");
    }
  }, dependencies: [CommonModule, FormsModule, NgSelectOption, \u0275NgSelectMultipleOption, DefaultValueAccessor, SelectControlValueAccessor, NgControlStatus, NgModel], styles: ["\n.grid-2[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  gap: 0 24px;\n}\n@media (max-width: 700px) {\n  .grid-2[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n}\n.seccion-descripcion[_ngcontent-%COMP%], \n.seccion-archivo[_ngcontent-%COMP%] {\n  margin-top: 20px;\n}\n.sin-margen[_ngcontent-%COMP%] {\n  margin-bottom: 0;\n}\n.etiqueta-archivo[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 10px;\n  font-weight: 600;\n  font-size: 0.88rem;\n}\n.zona-archivo[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 14px;\n  border: 1px dashed var(--borde);\n  border-radius: 8px;\n  padding: 20px;\n  background: var(--gris-fondo);\n  font-size: 0.88rem;\n  color: var(--texto-suave);\n  flex-wrap: wrap;\n}\n.boton-archivo[_ngcontent-%COMP%] {\n  cursor: pointer;\n  white-space: nowrap;\n}\n.pie-formulario[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: flex-end;\n  align-items: center;\n  gap: 18px;\n  margin-top: 20px;\n}\n/*# sourceMappingURL=registro-manual.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RegistroManual, [{
    type: Component,
    args: [{ selector: "app-registro-manual", standalone: true, imports: [CommonModule, FormsModule], template: `<div class="page-header">
  <div>
    <h2>Registro Manual de Nueva Queja</h2>
    <p class="page-header-subtitulo">Ingresa los datos del documento f\xEDsico para generar un folio de seguimiento.</p>
  </div>
</div>

<div class="card">
  <h3>Datos del Emisor</h3>
  <div class="grid-2">
    <div class="input-group">
      <label>Nombre del Denunciante:</label>
      <input type="text" [(ngModel)]="formulario.nombre" name="nombre" />
    </div>
    <div class="input-group">
      <label>N\xFAmero de Oficio (Si aplica):</label>
      <input type="text" [(ngModel)]="formulario.numeroOficio" name="numeroOficio" />
    </div>
    <div class="input-group">
      <label>Primer Apellido:</label>
      <input type="text" [(ngModel)]="formulario.apellido1" name="apellido1" />
    </div>
    <div class="input-group">
      <label>Fecha de Recepci\xF3n F\xEDsica:</label>
      <input type="date" [(ngModel)]="formulario.fechaRecepcionFisica" name="fechaRecepcionFisica" />
    </div>
    <div class="input-group">
      <label>Segundo Apellido:</label>
      <input type="text" [(ngModel)]="formulario.apellido2" name="apellido2" />
    </div>
    <div class="input-group">
      <label>Tipo de Documento:</label>
      <select [(ngModel)]="formulario.tipoDocumento" name="tipoDocumento">
        <option value="" disabled selected>Seleccione</option>
        <option value="IDENTIFICACION">Identificaci\xF3n</option>
        <option value="OFICIO">Oficio</option>
        <option value="ESCRITO_LIBRE">Escrito libre</option>
        <option value="OTRO">Otro</option>
      </select>
    </div>
    <div class="input-group">
      <label>Tipo de Usuario:</label>
      <select [(ngModel)]="formulario.tipoUsuario" name="tipoUsuario">
        <option value="" disabled selected>Seleccione</option>
        <option value="alumno">Alumno</option>
        <option value="empleado">Empleado</option>
        <option value="externo">Externo</option>
      </select>
    </div>
    <div class="input-group">
      <label>Dependencia / Escuela:</label>
      <select [(ngModel)]="formulario.dependenciaClave" name="dependenciaClave">
        <option value="" selected>Seleccione Unidad Acad\xE9mica</option>
        @for (area of areas; track area.clave) {
          <option [value]="area.clave">{{ area.nombre }}</option>
        }
      </select>
    </div>
    <div class="input-group">
      <label>Correo de Contacto:</label>
      <input type="email" [(ngModel)]="formulario.correoContacto" name="correoContacto" placeholder="Si el quejoso lo proporciona" />
    </div>
    <div class="input-group">
      <label>Tel\xE9fono de Contacto:</label>
      <input type="tel" [(ngModel)]="formulario.telefonoContacto" name="telefonoContacto" placeholder="Si el quejoso lo proporciona" />
    </div>
  </div>
  <p class="aviso-inline">Si capturas un correo de contacto, el quejoso recibir\xE1 ah\xED las notificaciones autom\xE1ticas de rechazo o turnado, igual que en un registro digital.</p>
</div>

<div class="card seccion-descripcion">
  <div class="input-group">
    <label>Descripci\xF3n Breve del Asunto:</label>
    <textarea rows="4" [(ngModel)]="formulario.descripcion" name="descripcion"></textarea>
  </div>
  <div class="input-group sin-margen">
    <label>Ubicaci\xF3n F\xEDsica del Expediente:</label>
    <input type="text" [(ngModel)]="formulario.ubicacionFisica" name="ubicacionFisica" placeholder="Ej. Archivero 3, carpeta 12" />
  </div>
</div>

<div class="card seccion-archivo">
  <label class="etiqueta-archivo">Digitalizaci\xF3n de Evidencia</label>
  <div class="zona-archivo">
    <span>{{ nombreArchivo || 'Escanee y adjunte el documento original (PDF/JPG)' }}</span>
    <label class="btn-secondary boton-archivo">
      Seleccionar Archivos
      <input type="file" accept=".pdf,.jpg,.jpeg,.png" (change)="onArchivoSeleccionado($event)" hidden />
    </label>
  </div>
</div>

<div class="pie-formulario">
  <button class="btn-texto" (click)="limpiarFormulario()">Limpiar Formulario</button>
  <button class="btn-primary" (click)="guardar()" [disabled]="guardando">
    {{ guardando ? 'Guardando\u2026' : 'GUARDAR Y GENERAR ENTRADA' }}
  </button>
</div>
`, styles: ["/* src/app/pages/registro-manual/registro-manual.scss */\n.grid-2 {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  gap: 0 24px;\n}\n@media (max-width: 700px) {\n  .grid-2 {\n    grid-template-columns: 1fr;\n  }\n}\n.seccion-descripcion,\n.seccion-archivo {\n  margin-top: 20px;\n}\n.sin-margen {\n  margin-bottom: 0;\n}\n.etiqueta-archivo {\n  display: block;\n  margin-bottom: 10px;\n  font-weight: 600;\n  font-size: 0.88rem;\n}\n.zona-archivo {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 14px;\n  border: 1px dashed var(--borde);\n  border-radius: 8px;\n  padding: 20px;\n  background: var(--gris-fondo);\n  font-size: 0.88rem;\n  color: var(--texto-suave);\n  flex-wrap: wrap;\n}\n.boton-archivo {\n  cursor: pointer;\n  white-space: nowrap;\n}\n.pie-formulario {\n  display: flex;\n  justify-content: flex-end;\n  align-items: center;\n  gap: 18px;\n  margin-top: 20px;\n}\n/*# sourceMappingURL=registro-manual.css.map */\n"] }]
  }], () => [{ type: RevisionService }, { type: ToastService }, { type: Router }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(RegistroManual, { className: "RegistroManual", filePath: "src/app/pages/registro-manual/registro-manual.ts", lineNumber: 17 });
})();
export {
  RegistroManual
};
//# sourceMappingURL=chunk-OFH3RXML.js.map
