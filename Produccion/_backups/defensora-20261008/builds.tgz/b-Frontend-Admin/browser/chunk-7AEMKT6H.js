import {
  RouterLink
} from "./chunk-FZQGDKC3.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  HttpClient,
  Injectable,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵinject,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵtext,
  ɵɵtextInterpolate
} from "./chunk-FOUSSYWU.js";

// src/app/core/services/dashboard.service.ts
var DashboardService = class _DashboardService {
  http;
  apiUrl = "/api/admin/dashboard";
  constructor(http) {
    this.http = http;
  }
  resumen() {
    return this.http.get(`${this.apiUrl}/resumen`);
  }
  static \u0275fac = function DashboardService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DashboardService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _DashboardService, factory: _DashboardService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DashboardService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/dashboard/dashboard.ts
function Dashboard_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 2);
    \u0275\u0275text(1, "Cargando resumen\u2026");
    \u0275\u0275elementEnd();
  }
}
function Dashboard_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 3)(1, "div", 4)(2, "div", 5)(3, "span", 6);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(4, "svg", 7);
    \u0275\u0275element(5, "path", 8)(6, "circle", 9)(7, "path", 10)(8, "path", 11);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(9, "h3");
    \u0275\u0275text(10, "Estado del Personal");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "p", 12);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "p", 13);
    \u0275\u0275text(14, "usuarios registrados");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "a", 14);
    \u0275\u0275text(16, "Gestionar Usuarios");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(17, "div", 4)(18, "div", 5)(19, "span", 15);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(20, "svg", 7);
    \u0275\u0275element(21, "path", 16)(22, "path", 17)(23, "path", 18);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(24, "h3");
    \u0275\u0275text(25, "Directorio IPN");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(26, "p", 12);
    \u0275\u0275text(27);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "p", 13);
    \u0275\u0275text(29, "Unidades Acad\xE9micas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "a", 19);
    \u0275\u0275text(31, "Actualizar Cat\xE1logo");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(32, "div", 4)(33, "div", 5)(34, "span", 20);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(35, "svg", 7);
    \u0275\u0275element(36, "path", 21);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(37, "h3");
    \u0275\u0275text(38, "Seguridad");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(39, "p", 22);
    \u0275\u0275text(40, "\xDAltimo respaldo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(41, "p", 23);
    \u0275\u0275text(42);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(43, "a", 24);
    \u0275\u0275text(44, "Ver Bit\xE1cora");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(45, "div", 4)(46, "div", 5)(47, "span", 25);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(48, "svg", 7);
    \u0275\u0275element(49, "path", 26)(50, "polyline", 27)(51, "line", 28)(52, "line", 29);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(53, "h3");
    \u0275\u0275text(54, "Formatos Legales");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(55, "p", 12);
    \u0275\u0275text(56);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(57, "p", 13);
    \u0275\u0275text(58, "Plantillas activas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(59, "a", 30);
    \u0275\u0275text(60, "Editar Formatos");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(12);
    \u0275\u0275textInterpolate(ctx_r0.resumen.totalPersonalActivo);
    \u0275\u0275advance(15);
    \u0275\u0275textInterpolate(ctx_r0.resumen.totalDependencias);
    \u0275\u0275advance(15);
    \u0275\u0275textInterpolate(ctx_r0.resumen.ultimoRespaldo);
    \u0275\u0275advance(14);
    \u0275\u0275textInterpolate(ctx_r0.resumen.totalPlantillasActivas);
  }
}
var Dashboard = class _Dashboard {
  dashboardService;
  toast;
  cdr;
  resumen = null;
  cargando = true;
  constructor(dashboardService, toast, cdr) {
    this.dashboardService = dashboardService;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.dashboardService.resumen().subscribe({
      next: (resumen) => {
        this.resumen = resumen;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.toast.error("No se pudo cargar el resumen del sistema.");
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function Dashboard_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Dashboard)(\u0275\u0275directiveInject(DashboardService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Dashboard, selectors: [["app-dashboard"]], decls: 8, vars: 1, consts: [[1, "page-header"], [1, "page-header-subtitulo"], [1, "cargando"], [1, "tarjetas"], [1, "card", "tarjeta"], [1, "tarjeta-encabezado"], [1, "icono-acento", "azul"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["d", "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"], ["cx", "9", "cy", "7", "r", "4"], ["d", "M23 21v-2a4 4 0 0 0-3-3.87"], ["d", "M16 3.13a4 4 0 0 1 0 7.75"], [1, "dato-numero"], [1, "dato-etiqueta"], ["routerLink", "/usuarios-roles", 1, "btn-primary"], [1, "icono-acento", "morado"], ["d", "M3 21h18"], ["d", "M5 21V7l7-4 7 4v14"], ["d", "M10 21v-5h4v5"], ["routerLink", "/catalogo-dependencias", 1, "btn-primary"], [1, "icono-acento", "verde"], ["d", "M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6z"], [1, "dato-texto"], [1, "dato-etiqueta", "dato-etiqueta-fuerte"], ["routerLink", "/seguridad-respaldos", 1, "btn-primary"], [1, "icono-acento", "ambar"], ["d", "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"], ["points", "14 2 14 8 20 8"], ["x1", "8", "y1", "13", "x2", "16", "y2", "13"], ["x1", "8", "y1", "17", "x2", "16", "y2", "17"], ["routerLink", "/plantillas", 1, "btn-primary"]], template: function Dashboard_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "div")(2, "h2");
      \u0275\u0275text(3, "Consola de Administraci\xF3n del Sistema");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(4, "p", 1);
      \u0275\u0275text(5, "Panorama general de accesos, cat\xE1logo y respaldos.");
      \u0275\u0275elementEnd()()();
      \u0275\u0275conditionalCreate(6, Dashboard_Conditional_6_Template, 2, 0, "p", 2)(7, Dashboard_Conditional_7_Template, 61, 4, "div", 3);
    }
    if (rf & 2) {
      \u0275\u0275advance(6);
      \u0275\u0275conditional(ctx.cargando ? 6 : ctx.resumen ? 7 : -1);
    }
  }, dependencies: [CommonModule, RouterLink], styles: ["\n.cargando[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.tarjetas[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 20px;\n}\n@media (max-width: 700px) {\n  .tarjetas[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n}\n.tarjeta[_ngcontent-%COMP%] {\n  transition: box-shadow 0.2s ease, transform 0.2s ease;\n}\n.tarjeta[_ngcontent-%COMP%]:hover {\n  box-shadow: var(--sombra-media);\n  transform: translateY(-2px);\n}\n.tarjeta-encabezado[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  margin-bottom: 14px;\n}\n.tarjeta-encabezado[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 0.95rem;\n}\n.tarjeta[_ngcontent-%COMP%]   .dato-numero[_ngcontent-%COMP%] {\n  font-size: 2.1rem;\n  font-weight: 700;\n  color: var(--negro-inst);\n  margin: 0 0 2px;\n  line-height: 1.1;\n}\n.tarjeta[_ngcontent-%COMP%]   .dato-texto[_ngcontent-%COMP%] {\n  font-size: 0.85rem;\n  color: var(--texto-suave);\n  margin: 0;\n}\n.tarjeta[_ngcontent-%COMP%]   .dato-etiqueta[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 0.85rem;\n  margin: 0 0 18px;\n}\n.tarjeta[_ngcontent-%COMP%]   .dato-etiqueta-fuerte[_ngcontent-%COMP%] {\n  color: var(--negro-inst);\n  font-weight: 600;\n  font-size: 0.95rem;\n}\n.tarjeta[_ngcontent-%COMP%]   .btn-primary[_ngcontent-%COMP%] {\n  display: inline-block;\n  text-decoration: none;\n  font-size: 0.85rem;\n}\n/*# sourceMappingURL=dashboard.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Dashboard, [{
    type: Component,
    args: [{ selector: "app-dashboard", standalone: true, imports: [CommonModule, RouterLink], template: '<div class="page-header">\n  <div>\n    <h2>Consola de Administraci\xF3n del Sistema</h2>\n    <p class="page-header-subtitulo">Panorama general de accesos, cat\xE1logo y respaldos.</p>\n  </div>\n</div>\n\n@if (cargando) {\n  <p class="cargando">Cargando resumen\u2026</p>\n} @else if (resumen) {\n  <div class="tarjetas">\n    <div class="card tarjeta">\n      <div class="tarjeta-encabezado">\n        <span class="icono-acento azul">\n          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>\n        </span>\n        <h3>Estado del Personal</h3>\n      </div>\n      <p class="dato-numero">{{ resumen.totalPersonalActivo }}</p>\n      <p class="dato-etiqueta">usuarios registrados</p>\n      <a routerLink="/usuarios-roles" class="btn-primary">Gestionar Usuarios</a>\n    </div>\n\n    <div class="card tarjeta">\n      <div class="tarjeta-encabezado">\n        <span class="icono-acento morado">\n          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"></path><path d="M5 21V7l7-4 7 4v14"></path><path d="M10 21v-5h4v5"></path></svg>\n        </span>\n        <h3>Directorio IPN</h3>\n      </div>\n      <p class="dato-numero">{{ resumen.totalDependencias }}</p>\n      <p class="dato-etiqueta">Unidades Acad\xE9micas</p>\n      <a routerLink="/catalogo-dependencias" class="btn-primary">Actualizar Cat\xE1logo</a>\n    </div>\n\n    <div class="card tarjeta">\n      <div class="tarjeta-encabezado">\n        <span class="icono-acento verde">\n          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6z"></path></svg>\n        </span>\n        <h3>Seguridad</h3>\n      </div>\n      <p class="dato-texto">\xDAltimo respaldo</p>\n      <p class="dato-etiqueta dato-etiqueta-fuerte">{{ resumen.ultimoRespaldo }}</p>\n      <a routerLink="/seguridad-respaldos" class="btn-primary">Ver Bit\xE1cora</a>\n    </div>\n\n    <div class="card tarjeta">\n      <div class="tarjeta-encabezado">\n        <span class="icono-acento ambar">\n          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="8" y1="13" x2="16" y2="13"></line><line x1="8" y1="17" x2="16" y2="17"></line></svg>\n        </span>\n        <h3>Formatos Legales</h3>\n      </div>\n      <p class="dato-numero">{{ resumen.totalPlantillasActivas }}</p>\n      <p class="dato-etiqueta">Plantillas activas</p>\n      <a routerLink="/plantillas" class="btn-primary">Editar Formatos</a>\n    </div>\n  </div>\n}\n', styles: ["/* src/app/pages/dashboard/dashboard.scss */\n.cargando {\n  color: var(--texto-suave);\n}\n.tarjetas {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 20px;\n}\n@media (max-width: 700px) {\n  .tarjetas {\n    grid-template-columns: 1fr;\n  }\n}\n.tarjeta {\n  transition: box-shadow 0.2s ease, transform 0.2s ease;\n}\n.tarjeta:hover {\n  box-shadow: var(--sombra-media);\n  transform: translateY(-2px);\n}\n.tarjeta-encabezado {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  margin-bottom: 14px;\n}\n.tarjeta-encabezado h3 {\n  margin: 0;\n  font-size: 0.95rem;\n}\n.tarjeta .dato-numero {\n  font-size: 2.1rem;\n  font-weight: 700;\n  color: var(--negro-inst);\n  margin: 0 0 2px;\n  line-height: 1.1;\n}\n.tarjeta .dato-texto {\n  font-size: 0.85rem;\n  color: var(--texto-suave);\n  margin: 0;\n}\n.tarjeta .dato-etiqueta {\n  color: var(--texto-suave);\n  font-size: 0.85rem;\n  margin: 0 0 18px;\n}\n.tarjeta .dato-etiqueta-fuerte {\n  color: var(--negro-inst);\n  font-weight: 600;\n  font-size: 0.95rem;\n}\n.tarjeta .btn-primary {\n  display: inline-block;\n  text-decoration: none;\n  font-size: 0.85rem;\n}\n/*# sourceMappingURL=dashboard.css.map */\n"] }]
  }], () => [{ type: DashboardService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Dashboard, { className: "Dashboard", filePath: "src/app/pages/dashboard/dashboard.ts", lineNumber: 16 });
})();
export {
  Dashboard
};
//# sourceMappingURL=chunk-7AEMKT6H.js.map
