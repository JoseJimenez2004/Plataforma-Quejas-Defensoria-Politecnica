// src/app/core/models/admin.models.ts
function etiquetaRol(rol) {
  switch (rol) {
    case "ADMIN_SISTEMAS":
      return "Admin. de Sistemas";
    case "RECEPCIONISTA":
      return "Recepcionista";
    case "ANALISTA_PRIMER_CONTACTO":
      return "Analista de Primer Contacto";
    case "SUBDEFENSOR":
      return "Subdefensor";
    case "DEFENSOR":
      return "Defensor";
    default:
      return rol;
  }
}
function iniciales(nombreCompleto) {
  const partes = nombreCompleto.trim().split(/\s+/).filter(Boolean);
  if (partes.length === 0)
    return "?";
  if (partes.length === 1)
    return partes[0].slice(0, 2).toUpperCase();
  return (partes[0][0] + partes[1][0]).toUpperCase();
}

export {
  etiquetaRol,
  iniciales
};
//# sourceMappingURL=chunk-GNNLFNWH.js.map
