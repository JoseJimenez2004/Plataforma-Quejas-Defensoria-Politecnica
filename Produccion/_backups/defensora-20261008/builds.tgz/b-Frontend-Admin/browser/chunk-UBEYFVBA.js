import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel,
  NgSelectOption,
  SelectControlValueAccessor,
  ɵNgSelectMultipleOption
} from "./chunk-QAQG5DUR.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  HttpClient,
  Injectable,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-FOUSSYWU.js";

// src/app/core/services/catalogo-admin.service.ts
var CatalogoAdminService = class _CatalogoAdminService {
  http;
  apiUrl = "/api/catalogos/dependencias/admin";
  constructor(http) {
    this.http = http;
  }
  listarTodas() {
    return this.http.get(this.apiUrl);
  }
  crear(datos) {
    return this.http.post(this.apiUrl, datos);
  }
  editar(clave, datos) {
    return this.http.put(`${this.apiUrl}/${encodeURIComponent(clave)}`, datos);
  }
  importarExcel(archivo) {
    const formData = new FormData();
    formData.append("archivo", archivo);
    return this.http.post(`${this.apiUrl}/importar-excel`, formData);
  }
  static \u0275fac = function CatalogoAdminService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _CatalogoAdminService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _CatalogoAdminService, factory: _CatalogoAdminService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CatalogoAdminService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/catalogo-dependencias/catalogo-dependencias.ts
var _forTrack0 = ($index, $item) => $item.clave;
function CatalogoDependencias_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 2);
    \u0275\u0275text(1, "Cargando cat\xE1logo\u2026");
    \u0275\u0275elementEnd();
  }
}
function CatalogoDependencias_Conditional_7_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 10);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(1, "svg", 16);
    \u0275\u0275element(2, "path", 17)(3, "path", 18);
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(4, "p");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r1.busqueda ? "Ninguna dependencia coincide con tu b\xFAsqueda." : "A\xFAn no hay dependencias registradas.");
  }
}
function CatalogoDependencias_Conditional_7_Conditional_7_For_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "td");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "td")(8, "button", 19);
    \u0275\u0275listener("click", function CatalogoDependencias_Conditional_7_Conditional_7_For_13_Template_button_click_8_listener() {
      const dep_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.abrirEditar(dep_r4));
    });
    \u0275\u0275text(9, "Editar");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const dep_r4 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(dep_r4.abreviatura || dep_r4.clave);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(dep_r4.nombre);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(dep_r4.correoContacto || "\u2014");
  }
}
function CatalogoDependencias_Conditional_7_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "table", 11)(1, "thead")(2, "tr")(3, "th");
    \u0275\u0275text(4, "Abreviatura");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "th");
    \u0275\u0275text(6, "Nombre Oficial de la Dependencia");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "th");
    \u0275\u0275text(8, "Correo de Contacto Oficial");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "th");
    \u0275\u0275text(10, "Acci\xF3n");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "tbody");
    \u0275\u0275repeaterCreate(12, CatalogoDependencias_Conditional_7_Conditional_7_For_13_Template, 10, 3, "tr", null, _forTrack0);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(12);
    \u0275\u0275repeater(ctx_r1.listaFiltrada);
  }
}
function CatalogoDependencias_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 3)(1, "div", 5);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 6);
    \u0275\u0275element(3, "circle", 7)(4, "line", 8);
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(5, "input", 9);
    \u0275\u0275twoWayListener("ngModelChange", function CatalogoDependencias_Conditional_7_Template_input_ngModelChange_5_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.busqueda, $event) || (ctx_r1.busqueda = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(6, CatalogoDependencias_Conditional_7_Conditional_6_Template, 6, 1, "div", 10)(7, CatalogoDependencias_Conditional_7_Conditional_7_Template, 14, 0, "table", 11);
    \u0275\u0275elementStart(8, "div", 12)(9, "button", 13);
    \u0275\u0275listener("click", function CatalogoDependencias_Conditional_7_Template_button_click_9_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.abrirCrear());
    });
    \u0275\u0275text(10, "Agregar Academia o Dependencia");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "label", 14);
    \u0275\u0275text(12);
    \u0275\u0275elementStart(13, "input", 15);
    \u0275\u0275listener("change", function CatalogoDependencias_Conditional_7_Template_input_change_13_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.onArchivoSeleccionado($event));
    });
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.busqueda);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.listaFiltrada.length === 0 ? 6 : 7);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1(" ", ctx_r1.importando ? "Importando\u2026" : "Importar Directorio desde Excel (SIA/IPN)", " ");
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r1.importando);
  }
}
function CatalogoDependencias_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 20);
    \u0275\u0275listener("click", function CatalogoDependencias_Conditional_8_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    \u0275\u0275elementStart(1, "div", 21);
    \u0275\u0275listener("click", function CatalogoDependencias_Conditional_8_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 22)(3, "h3");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 23);
    \u0275\u0275listener("click", function CatalogoDependencias_Conditional_8_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    \u0275\u0275text(6, "\u2715");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 24)(8, "label");
    \u0275\u0275text(9, "Clave:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "input", 25);
    \u0275\u0275twoWayListener("ngModelChange", function CatalogoDependencias_Conditional_8_Template_input_ngModelChange_10_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.clave, $event) || (ctx_r1.formulario.clave = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 24)(12, "label");
    \u0275\u0275text(13, "Nombre Oficial:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "input", 26);
    \u0275\u0275twoWayListener("ngModelChange", function CatalogoDependencias_Conditional_8_Template_input_ngModelChange_14_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.nombre, $event) || (ctx_r1.formulario.nombre = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 24)(16, "label");
    \u0275\u0275text(17, "Abreviatura:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "input", 27);
    \u0275\u0275twoWayListener("ngModelChange", function CatalogoDependencias_Conditional_8_Template_input_ngModelChange_18_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.abreviatura, $event) || (ctx_r1.formulario.abreviatura = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(19, "div", 24)(20, "label");
    \u0275\u0275text(21, "Tipo:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "select", 28);
    \u0275\u0275twoWayListener("ngModelChange", function CatalogoDependencias_Conditional_8_Template_select_ngModelChange_22_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.tipo, $event) || (ctx_r1.formulario.tipo = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementStart(23, "option", 29);
    \u0275\u0275text(24, "Unidad Acad\xE9mica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "option", 30);
    \u0275\u0275text(26, "\xC1rea Central");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "option", 31);
    \u0275\u0275text(28, "Secretar\xEDa");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "option", 32);
    \u0275\u0275text(30, "Direcci\xF3n");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(31, "div", 24)(32, "label");
    \u0275\u0275text(33, "Correo Electr\xF3nico de Contacto (Oficial):");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "input", 33);
    \u0275\u0275twoWayListener("ngModelChange", function CatalogoDependencias_Conditional_8_Template_input_ngModelChange_34_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.correoContacto, $event) || (ctx_r1.formulario.correoContacto = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(35, "div", 24)(36, "label");
    \u0275\u0275text(37, "Nombre del Titular o Director actual:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(38, "input", 34);
    \u0275\u0275twoWayListener("ngModelChange", function CatalogoDependencias_Conditional_8_Template_input_ngModelChange_38_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.formulario.nombreTitular, $event) || (ctx_r1.formulario.nombreTitular = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(39, "div", 35)(40, "button", 13);
    \u0275\u0275listener("click", function CatalogoDependencias_Conditional_8_Template_button_click_40_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.guardar());
    });
    \u0275\u0275text(41, "Guardar Dependencia");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(42, "button", 36);
    \u0275\u0275listener("click", function CatalogoDependencias_Conditional_8_Template_button_click_42_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    \u0275\u0275text(43, "Cancelar y Volver");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.editandoClave ? "Editar Dependencia" : "Registro de Unidad Acad\xE9mica / Dependencia");
    \u0275\u0275advance(6);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.clave);
    \u0275\u0275property("readOnly", !!ctx_r1.editandoClave);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.nombre);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.abreviatura);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.tipo);
    \u0275\u0275advance(12);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.correoContacto);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.formulario.nombreTitular);
  }
}
var CatalogoDependencias = class _CatalogoDependencias {
  catalogoService;
  toast;
  cdr;
  lista = [];
  cargando = true;
  importando = false;
  busqueda = "";
  mostrarModal = false;
  editandoClave = null;
  formulario = this.formularioVacio();
  constructor(catalogoService, toast, cdr) {
    this.catalogoService = catalogoService;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.cargarLista();
  }
  get listaFiltrada() {
    const termino = this.busqueda.trim().toLowerCase();
    if (!termino)
      return this.lista;
    return this.lista.filter((d) => d.nombre.toLowerCase().includes(termino) || (d.abreviatura ?? "").toLowerCase().includes(termino) || d.clave.toLowerCase().includes(termino) || (d.correoContacto ?? "").toLowerCase().includes(termino));
  }
  cargarLista() {
    this.cargando = true;
    this.catalogoService.listarTodas().subscribe({
      next: (lista) => {
        this.lista = lista;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.toast.error("No se pudo cargar el cat\xE1logo de dependencias.");
        this.cdr.detectChanges();
      }
    });
  }
  abrirCrear() {
    this.editandoClave = null;
    this.formulario = this.formularioVacio();
    this.mostrarModal = true;
  }
  abrirEditar(dep) {
    this.editandoClave = dep.clave;
    this.formulario = {
      clave: dep.clave,
      clavePadre: dep.clavePadre,
      nombre: dep.nombre,
      abreviatura: dep.abreviatura,
      tipo: dep.tipo,
      categoria: dep.categoria,
      nivel: dep.nivel,
      correoContacto: dep.correoContacto,
      nombreTitular: dep.nombreTitular
    };
    this.mostrarModal = true;
  }
  cerrarModal() {
    this.mostrarModal = false;
    this.editandoClave = null;
  }
  guardar() {
    if (!this.formulario.clave || !this.formulario.nombre || !this.formulario.tipo) {
      this.toast.advertencia("Completa clave, nombre y tipo.");
      return;
    }
    const accion = this.editandoClave ? this.catalogoService.editar(this.editandoClave, this.formulario) : this.catalogoService.crear(this.formulario);
    accion.subscribe({
      next: () => {
        this.mostrarModal = false;
        this.toast.exito(this.editandoClave ? "Dependencia actualizada." : "Dependencia creada.");
        this.cargarLista();
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.toast.error(err?.error?.mensaje ?? "No se pudo guardar la dependencia.");
        this.cdr.detectChanges();
      }
    });
  }
  onArchivoSeleccionado(event) {
    const input = event.target;
    const archivo = input.files?.[0];
    if (!archivo)
      return;
    this.importando = true;
    this.catalogoService.importarExcel(archivo).subscribe({
      next: (resumen) => {
        this.importando = false;
        this.toast.exito(`Importaci\xF3n completa: ${resumen.filasCreadas} creadas, ${resumen.filasActualizadas} actualizadas.`);
        if (resumen.errores.length) {
          this.toast.advertencia(`${resumen.errores.length} filas con errores, revisa el formato del archivo.`);
        }
        this.cargarLista();
        this.cdr.detectChanges();
        input.value = "";
      },
      error: (err) => {
        this.importando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo importar el archivo.");
        this.cdr.detectChanges();
        input.value = "";
      }
    });
  }
  formularioVacio() {
    return { clave: "", nombre: "", tipo: "UNIDAD_ACADEMICA", nivel: 1 };
  }
  static \u0275fac = function CatalogoDependencias_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _CatalogoDependencias)(\u0275\u0275directiveInject(CatalogoAdminService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _CatalogoDependencias, selectors: [["app-catalogo-dependencias"]], decls: 9, vars: 3, consts: [[1, "page-header"], [1, "page-header-subtitulo"], [1, "cargando"], [1, "card"], [1, "modal-overlay"], [1, "buscador"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["cx", "11", "cy", "11", "r", "8"], ["x1", "21", "y1", "21", "x2", "16.65", "y2", "16.65"], ["type", "text", "name", "busqueda", "placeholder", "Buscar por clave, nombre o correo\u2026", 3, "ngModelChange", "ngModel"], [1, "estado-vacio"], [1, "tabla-admin"], [1, "pie-tabla"], [1, "btn-primary", 3, "click"], [1, "btn-secondary", "boton-archivo"], ["type", "file", "accept", ".xlsx,.xls", "hidden", "", 3, "change", "disabled"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round", 1, "estado-vacio-icono"], ["d", "M5 21V7l7-4 7 4v14"], ["d", "M3 21h18"], [1, "btn-texto", 3, "click"], [1, "modal-overlay", 3, "click"], [1, "modal", "card", 3, "click"], [1, "modal-header"], ["aria-label", "Cerrar", 1, "modal-cerrar", 3, "click"], [1, "input-group"], ["type", "text", "name", "clave", 3, "ngModelChange", "ngModel", "readOnly"], ["type", "text", "name", "nombre", 3, "ngModelChange", "ngModel"], ["type", "text", "name", "abreviatura", 3, "ngModelChange", "ngModel"], ["name", "tipo", 3, "ngModelChange", "ngModel"], ["value", "UNIDAD_ACADEMICA"], ["value", "AREA_CENTRAL"], ["value", "SECRETARIA"], ["value", "DIRECCION"], ["type", "email", "name", "correoContacto", 3, "ngModelChange", "ngModel"], ["type", "text", "name", "nombreTitular", 3, "ngModelChange", "ngModel"], [1, "modal-acciones"], [1, "btn-secondary", 3, "click"]], template: function CatalogoDependencias_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "div")(2, "h2");
      \u0275\u0275text(3, "Cat\xE1logo de Unidades Acad\xE9micas y Dependencias");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(4, "p", 1);
      \u0275\u0275text(5);
      \u0275\u0275elementEnd()()();
      \u0275\u0275conditionalCreate(6, CatalogoDependencias_Conditional_6_Template, 2, 0, "p", 2)(7, CatalogoDependencias_Conditional_7_Template, 14, 4, "div", 3);
      \u0275\u0275conditionalCreate(8, CatalogoDependencias_Conditional_8_Template, 44, 8, "div", 4);
    }
    if (rf & 2) {
      \u0275\u0275advance(5);
      \u0275\u0275textInterpolate1("", ctx.lista.length, " dependencias registradas.");
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.cargando ? 6 : 7);
      \u0275\u0275advance(2);
      \u0275\u0275conditional(ctx.mostrarModal ? 8 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, NgSelectOption, \u0275NgSelectMultipleOption, DefaultValueAccessor, SelectControlValueAccessor, NgControlStatus, NgModel], styles: ["\n.encabezado[_ngcontent-%COMP%] {\n  margin-bottom: 16px;\n}\n.encabezado[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n}\n.cargando[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.pie-tabla[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  margin-top: 18px;\n  flex-wrap: wrap;\n}\n.boton-archivo[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  cursor: pointer;\n  text-align: center;\n}\n/*# sourceMappingURL=catalogo-dependencias.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CatalogoDependencias, [{
    type: Component,
    args: [{ selector: "app-catalogo-dependencias", standalone: true, imports: [CommonModule, FormsModule], template: `<div class="page-header">
  <div>
    <h2>Cat\xE1logo de Unidades Acad\xE9micas y Dependencias</h2>
    <p class="page-header-subtitulo">{{ lista.length }} dependencias registradas.</p>
  </div>
</div>

@if (cargando) {
  <p class="cargando">Cargando cat\xE1logo\u2026</p>
} @else {
  <div class="card">
    <div class="buscador">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
      <input type="text" [(ngModel)]="busqueda" name="busqueda" placeholder="Buscar por clave, nombre o correo\u2026" />
    </div>

    @if (listaFiltrada.length === 0) {
      <div class="estado-vacio">
        <svg class="estado-vacio-icono" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 21V7l7-4 7 4v14"></path><path d="M3 21h18"></path></svg>
        <p>{{ busqueda ? 'Ninguna dependencia coincide con tu b\xFAsqueda.' : 'A\xFAn no hay dependencias registradas.' }}</p>
      </div>
    } @else {
      <table class="tabla-admin">
        <thead>
          <tr>
            <th>Abreviatura</th>
            <th>Nombre Oficial de la Dependencia</th>
            <th>Correo de Contacto Oficial</th>
            <th>Acci\xF3n</th>
          </tr>
        </thead>
        <tbody>
          @for (dep of listaFiltrada; track dep.clave) {
            <tr>
              <td>{{ dep.abreviatura || dep.clave }}</td>
              <td>{{ dep.nombre }}</td>
              <td>{{ dep.correoContacto || '\u2014' }}</td>
              <td><button class="btn-texto" (click)="abrirEditar(dep)">Editar</button></td>
            </tr>
          }
        </tbody>
      </table>
    }

    <div class="pie-tabla">
      <button class="btn-primary" (click)="abrirCrear()">Agregar Academia o Dependencia</button>

      <label class="btn-secondary boton-archivo">
        {{ importando ? 'Importando\u2026' : 'Importar Directorio desde Excel (SIA/IPN)' }}
        <input type="file" accept=".xlsx,.xls" (change)="onArchivoSeleccionado($event)" [disabled]="importando" hidden />
      </label>
    </div>
  </div>
}

@if (mostrarModal) {
  <div class="modal-overlay" (click)="cerrarModal()">
    <div class="modal card" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>{{ editandoClave ? 'Editar Dependencia' : 'Registro de Unidad Acad\xE9mica / Dependencia' }}</h3>
        <button class="modal-cerrar" (click)="cerrarModal()" aria-label="Cerrar">\u2715</button>
      </div>

      <div class="input-group">
        <label>Clave:</label>
        <input type="text" [(ngModel)]="formulario.clave" name="clave" [readOnly]="!!editandoClave" />
      </div>
      <div class="input-group">
        <label>Nombre Oficial:</label>
        <input type="text" [(ngModel)]="formulario.nombre" name="nombre" />
      </div>
      <div class="input-group">
        <label>Abreviatura:</label>
        <input type="text" [(ngModel)]="formulario.abreviatura" name="abreviatura" />
      </div>
      <div class="input-group">
        <label>Tipo:</label>
        <select [(ngModel)]="formulario.tipo" name="tipo">
          <option value="UNIDAD_ACADEMICA">Unidad Acad\xE9mica</option>
          <option value="AREA_CENTRAL">\xC1rea Central</option>
          <option value="SECRETARIA">Secretar\xEDa</option>
          <option value="DIRECCION">Direcci\xF3n</option>
        </select>
      </div>
      <div class="input-group">
        <label>Correo Electr\xF3nico de Contacto (Oficial):</label>
        <input type="email" [(ngModel)]="formulario.correoContacto" name="correoContacto" />
      </div>
      <div class="input-group">
        <label>Nombre del Titular o Director actual:</label>
        <input type="text" [(ngModel)]="formulario.nombreTitular" name="nombreTitular" />
      </div>

      <div class="modal-acciones">
        <button class="btn-primary" (click)="guardar()">Guardar Dependencia</button>
        <button class="btn-secondary" (click)="cerrarModal()">Cancelar y Volver</button>
      </div>
    </div>
  </div>
}
`, styles: ["/* src/app/pages/catalogo-dependencias/catalogo-dependencias.scss */\n.encabezado {\n  margin-bottom: 16px;\n}\n.encabezado h2 {\n  margin: 0;\n}\n.cargando {\n  color: var(--texto-suave);\n}\n.pie-tabla {\n  display: flex;\n  gap: 12px;\n  margin-top: 18px;\n  flex-wrap: wrap;\n}\n.boton-archivo {\n  display: inline-flex;\n  align-items: center;\n  cursor: pointer;\n  text-align: center;\n}\n/*# sourceMappingURL=catalogo-dependencias.css.map */\n"] }]
  }], () => [{ type: CatalogoAdminService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(CatalogoDependencias, { className: "CatalogoDependencias", filePath: "src/app/pages/catalogo-dependencias/catalogo-dependencias.ts", lineNumber: 19 });
})();
export {
  CatalogoDependencias
};
//# sourceMappingURL=chunk-UBEYFVBA.js.map
