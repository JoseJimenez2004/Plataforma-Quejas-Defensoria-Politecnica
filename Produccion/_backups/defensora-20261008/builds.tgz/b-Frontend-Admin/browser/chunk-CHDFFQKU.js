import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel
} from "./chunk-QAQG5DUR.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  HttpClient,
  Injectable,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-FOUSSYWU.js";

// src/app/core/services/seguridad.service.ts
var SeguridadService = class _SeguridadService {
  http;
  apiUrl = "/api/admin/seguridad";
  constructor(http) {
    this.http = http;
  }
  listarRespaldos() {
    return this.http.get(`${this.apiUrl}/respaldos`);
  }
  respaldoManual() {
    return this.http.post(`${this.apiUrl}/respaldos/manual`, {});
  }
  urlDescarga(nombreArchivo) {
    return `${this.apiUrl}/respaldos/${encodeURIComponent(nombreArchivo)}/descargar`;
  }
  restaurar(nombreArchivo) {
    return this.http.post(`${this.apiUrl}/restaurar`, { confirmar: true, nombreArchivo });
  }
  bitacora() {
    return this.http.get(`${this.apiUrl}/bitacora`);
  }
  static \u0275fac = function SeguridadService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _SeguridadService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _SeguridadService, factory: _SeguridadService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SeguridadService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/seguridad-respaldos/seguridad-respaldos.ts
var _forTrack0 = ($index, $item) => $item.id;
var _forTrack1 = ($index, $item) => $item.nombreArchivo;
function SeguridadRespaldos_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 13);
    \u0275\u0275listener("click", function SeguridadRespaldos_Conditional_17_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.descargar(ctx_r1.respaldos[0]));
    });
    \u0275\u0275text(1, "Descargar \xDAltimo Backup");
    \u0275\u0275elementEnd();
  }
}
function SeguridadRespaldos_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 10);
    \u0275\u0275text(1, "Cargando\u2026");
    \u0275\u0275elementEnd();
  }
}
function SeguridadRespaldos_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 10);
    \u0275\u0275text(1, "Todav\xEDa no se ha generado ning\xFAn respaldo.");
    \u0275\u0275elementEnd();
  }
}
function SeguridadRespaldos_Conditional_25_For_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "td");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "td", 14)(8, "button", 15);
    \u0275\u0275listener("click", function SeguridadRespaldos_Conditional_25_For_13_Template_button_click_8_listener() {
      const r_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.descargar(r_r4));
    });
    \u0275\u0275text(9, "Descargar");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "button", 16);
    \u0275\u0275listener("click", function SeguridadRespaldos_Conditional_25_For_13_Template_button_click_10_listener() {
      const r_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.abrirRestaurar(r_r4));
    });
    \u0275\u0275text(11, "Restaurar");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const r_r4 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(r_r4.nombreArchivo);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(r_r4.fecha);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.formatearTamanio(r_r4.tamanioBytes));
  }
}
function SeguridadRespaldos_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "table", 11)(1, "thead")(2, "tr")(3, "th");
    \u0275\u0275text(4, "Archivo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "th");
    \u0275\u0275text(6, "Fecha");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "th");
    \u0275\u0275text(8, "Tama\xF1o");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "th");
    \u0275\u0275text(10, "Acciones");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "tbody");
    \u0275\u0275repeaterCreate(12, SeguridadRespaldos_Conditional_25_For_13_Template, 12, 3, "tr", null, _forTrack1);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(12);
    \u0275\u0275repeater(ctx_r1.respaldos);
  }
}
function SeguridadRespaldos_For_42_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "td");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "td");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const item_r5 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r5.fecha);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r5.usuario);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r5.accionRealizada);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r5.ip);
  }
}
function SeguridadRespaldos_Conditional_43_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 17);
    \u0275\u0275listener("click", function SeguridadRespaldos_Conditional_43_Template_div_click_0_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarRestaurar());
    });
    \u0275\u0275elementStart(1, "div", 18);
    \u0275\u0275listener("click", function SeguridadRespaldos_Conditional_43_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 19)(3, "h3");
    \u0275\u0275text(4, "Restaurar Punto Anterior");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "button", 20);
    \u0275\u0275listener("click", function SeguridadRespaldos_Conditional_43_Template_button_click_5_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarRestaurar());
    });
    \u0275\u0275text(6, "\u2715");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "p", 21);
    \u0275\u0275text(8, " Esta acci\xF3n reemplazar\xE1 TODOS los datos actuales de la base de datos con el contenido del respaldo ");
    \u0275\u0275elementStart(9, "strong");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275text(11, ". No se puede deshacer. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "div", 22)(13, "label");
    \u0275\u0275text(14, "Escribe RESTAURAR para confirmar:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "input", 23);
    \u0275\u0275twoWayListener("ngModelChange", function SeguridadRespaldos_Conditional_43_Template_input_ngModelChange_15_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.confirmacionTexto, $event) || (ctx_r1.confirmacionTexto = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(16, "div", 24)(17, "button", 25);
    \u0275\u0275listener("click", function SeguridadRespaldos_Conditional_43_Template_button_click_17_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.confirmarRestauracion());
    });
    \u0275\u0275text(18, "Confirmar Restauraci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "button", 13);
    \u0275\u0275listener("click", function SeguridadRespaldos_Conditional_43_Template_button_click_19_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarRestaurar());
    });
    \u0275\u0275text(20, "Cancelar");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate(ctx_r1.archivoARestaurar);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.confirmacionTexto);
  }
}
var SeguridadRespaldos = class _SeguridadRespaldos {
  seguridadService;
  toast;
  cdr;
  respaldos = [];
  bitacora = [];
  cargando = true;
  ejecutandoRespaldo = false;
  mostrarModalRestaurar = false;
  archivoARestaurar = "";
  confirmacionTexto = "";
  constructor(seguridadService, toast, cdr) {
    this.seguridadService = seguridadService;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.cargarTodo();
  }
  cargarTodo() {
    this.cargando = true;
    this.seguridadService.listarRespaldos().subscribe({
      next: (respaldos) => {
        this.respaldos = respaldos;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        this.cdr.detectChanges();
      }
    });
    this.seguridadService.bitacora().subscribe({
      next: (bitacora) => {
        this.bitacora = bitacora;
        this.cdr.detectChanges();
      }
    });
  }
  get ultimoRespaldoTexto() {
    return this.respaldos.length ? this.respaldos[0].fecha : "Sin respaldos todav\xEDa";
  }
  ejecutarRespaldoManual() {
    this.ejecutandoRespaldo = true;
    this.seguridadService.respaldoManual().subscribe({
      next: () => {
        this.ejecutandoRespaldo = false;
        this.toast.exito("Respaldo manual generado correctamente.");
        this.cargarTodo();
      },
      error: (err) => {
        this.ejecutandoRespaldo = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo generar el respaldo.");
        this.cdr.detectChanges();
      }
    });
  }
  descargar(respaldo) {
    window.open(this.seguridadService.urlDescarga(respaldo.nombreArchivo), "_blank");
  }
  abrirRestaurar(respaldo) {
    this.archivoARestaurar = respaldo.nombreArchivo;
    this.confirmacionTexto = "";
    this.mostrarModalRestaurar = true;
  }
  cerrarRestaurar() {
    this.mostrarModalRestaurar = false;
  }
  confirmarRestauracion() {
    if (this.confirmacionTexto !== "RESTAURAR") {
      this.toast.advertencia("Escribe RESTAURAR (en may\xFAsculas) para confirmar esta acci\xF3n.");
      return;
    }
    this.seguridadService.restaurar(this.archivoARestaurar).subscribe({
      next: () => {
        this.mostrarModalRestaurar = false;
        this.toast.exito("Base de datos restaurada correctamente.");
      },
      error: (err) => {
        this.toast.error(err?.error?.mensaje ?? "No se pudo restaurar el respaldo.");
        this.cdr.detectChanges();
      }
    });
  }
  formatearTamanio(bytes) {
    if (bytes < 1024)
      return `${bytes} B`;
    if (bytes < 1024 * 1024)
      return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
  static \u0275fac = function SeguridadRespaldos_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _SeguridadRespaldos)(\u0275\u0275directiveInject(SeguridadService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _SeguridadRespaldos, selectors: [["app-seguridad-respaldos"]], decls: 44, vars: 6, consts: [[1, "page-header"], [1, "page-header-subtitulo"], [1, "card", "seccion"], [1, "estado-ok"], [1, "punto-estado"], [1, "dato"], [1, "acciones"], [1, "btn-primary", 3, "click", "disabled"], [1, "btn-secondary"], [1, "config-nota"], [1, "cargando"], [1, "tabla-admin"], [1, "modal-overlay"], [1, "btn-secondary", 3, "click"], [1, "acciones-fila"], [1, "btn-texto", 3, "click"], [1, "btn-texto", "peligro", 3, "click"], [1, "modal-overlay", 3, "click"], [1, "modal", "card", 3, "click"], [1, "modal-header"], ["aria-label", "Cerrar", 1, "modal-cerrar", 3, "click"], [1, "aviso-peligro"], [1, "input-group"], ["type", "text", "name", "confirmacionTexto", 3, "ngModelChange", "ngModel"], [1, "modal-acciones"], [1, "btn-primary", "boton-peligro", 3, "click"]], template: function SeguridadRespaldos_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "div")(2, "h2");
      \u0275\u0275text(3, "Gesti\xF3n de Seguridad y Copias de Respaldo");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(4, "p", 1);
      \u0275\u0275text(5, "Respaldos de base de datos y auditor\xEDa de acciones cr\xEDticas.");
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(6, "div", 2)(7, "h3");
      \u0275\u0275text(8, "Respaldos de Base de Datos y Expedientes");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(9, "p", 3);
      \u0275\u0275element(10, "span", 4);
      \u0275\u0275text(11, " Sistema Seguro ");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(12, "p", 5);
      \u0275\u0275text(13);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(14, "div", 6)(15, "button", 7);
      \u0275\u0275listener("click", function SeguridadRespaldos_Template_button_click_15_listener() {
        return ctx.ejecutarRespaldoManual();
      });
      \u0275\u0275text(16);
      \u0275\u0275elementEnd();
      \u0275\u0275conditionalCreate(17, SeguridadRespaldos_Conditional_17_Template, 2, 0, "button", 8);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(18, "p", 9);
      \u0275\u0275text(19, "Configuraci\xF3n: respaldo autom\xE1tico cada 24 horas (04:00 AM).");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(20, "div", 2)(21, "h3");
      \u0275\u0275text(22, "Respaldos disponibles");
      \u0275\u0275elementEnd();
      \u0275\u0275conditionalCreate(23, SeguridadRespaldos_Conditional_23_Template, 2, 0, "p", 10)(24, SeguridadRespaldos_Conditional_24_Template, 2, 0, "p", 10)(25, SeguridadRespaldos_Conditional_25_Template, 14, 0, "table", 11);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(26, "div", 2)(27, "h3");
      \u0275\u0275text(28, "Historial de Acciones Cr\xEDticas");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(29, "table", 11)(30, "thead")(31, "tr")(32, "th");
      \u0275\u0275text(33, "Fecha/Hora");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(34, "th");
      \u0275\u0275text(35, "Usuario");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(36, "th");
      \u0275\u0275text(37, "Acci\xF3n Realizada");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(38, "th");
      \u0275\u0275text(39, "IP");
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(40, "tbody");
      \u0275\u0275repeaterCreate(41, SeguridadRespaldos_For_42_Template, 9, 4, "tr", null, _forTrack0);
      \u0275\u0275elementEnd()()();
      \u0275\u0275conditionalCreate(43, SeguridadRespaldos_Conditional_43_Template, 21, 2, "div", 12);
    }
    if (rf & 2) {
      \u0275\u0275advance(13);
      \u0275\u0275textInterpolate1("\xDAltimo respaldo realizado: ", ctx.ultimoRespaldoTexto);
      \u0275\u0275advance(2);
      \u0275\u0275property("disabled", ctx.ejecutandoRespaldo);
      \u0275\u0275advance();
      \u0275\u0275textInterpolate1(" ", ctx.ejecutandoRespaldo ? "Generando\u2026" : "Ejecutar Respaldo Manual Ahora", " ");
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.respaldos.length ? 17 : -1);
      \u0275\u0275advance(6);
      \u0275\u0275conditional(ctx.cargando ? 23 : !ctx.respaldos.length ? 24 : 25);
      \u0275\u0275advance(18);
      \u0275\u0275repeater(ctx.bitacora);
      \u0275\u0275advance(2);
      \u0275\u0275conditional(ctx.mostrarModalRestaurar ? 43 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, DefaultValueAccessor, NgControlStatus, NgModel], styles: ["\n.seccion[_ngcontent-%COMP%] {\n  margin-bottom: 20px;\n}\n.seccion[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin-bottom: 10px;\n}\n.estado-ok[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  color: var(--exito);\n  font-weight: 600;\n  margin: 0 0 4px;\n}\n.estado-ok[_ngcontent-%COMP%]   .punto-estado[_ngcontent-%COMP%] {\n  width: 9px;\n  height: 9px;\n  border-radius: 50%;\n  background: var(--exito);\n}\n.dato[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 0.88rem;\n  margin-bottom: 16px;\n}\n.acciones[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  flex-wrap: wrap;\n  margin-bottom: 10px;\n}\n.config-nota[_ngcontent-%COMP%] {\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n  margin: 0;\n}\n.cargando[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.acciones-fila[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n}\n.acciones-fila[_ngcontent-%COMP%]   .peligro[_ngcontent-%COMP%] {\n  color: var(--peligro);\n}\n.boton-peligro[_ngcontent-%COMP%] {\n  background-color: var(--peligro) !important;\n}\n.boton-peligro[_ngcontent-%COMP%]:hover {\n  background-color: #a31f1f !important;\n}\n/*# sourceMappingURL=seguridad-respaldos.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SeguridadRespaldos, [{
    type: Component,
    args: [{ selector: "app-seguridad-respaldos", standalone: true, imports: [CommonModule, FormsModule], template: `<div class="page-header">
  <div>
    <h2>Gesti\xF3n de Seguridad y Copias de Respaldo</h2>
    <p class="page-header-subtitulo">Respaldos de base de datos y auditor\xEDa de acciones cr\xEDticas.</p>
  </div>
</div>

<div class="card seccion">
  <h3>Respaldos de Base de Datos y Expedientes</h3>
  <p class="estado-ok">
    <span class="punto-estado"></span>
    Sistema Seguro
  </p>
  <p class="dato">\xDAltimo respaldo realizado: {{ ultimoRespaldoTexto }}</p>

  <div class="acciones">
    <button class="btn-primary" (click)="ejecutarRespaldoManual()" [disabled]="ejecutandoRespaldo">
      {{ ejecutandoRespaldo ? 'Generando\u2026' : 'Ejecutar Respaldo Manual Ahora' }}
    </button>
    @if (respaldos.length) {
      <button class="btn-secondary" (click)="descargar(respaldos[0])">Descargar \xDAltimo Backup</button>
    }
  </div>

  <p class="config-nota">Configuraci\xF3n: respaldo autom\xE1tico cada 24 horas (04:00 AM).</p>
</div>

<div class="card seccion">
  <h3>Respaldos disponibles</h3>
  @if (cargando) {
    <p class="cargando">Cargando\u2026</p>
  } @else if (!respaldos.length) {
    <p class="cargando">Todav\xEDa no se ha generado ning\xFAn respaldo.</p>
  } @else {
    <table class="tabla-admin">
      <thead>
        <tr>
          <th>Archivo</th>
          <th>Fecha</th>
          <th>Tama\xF1o</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        @for (r of respaldos; track r.nombreArchivo) {
          <tr>
            <td>{{ r.nombreArchivo }}</td>
            <td>{{ r.fecha }}</td>
            <td>{{ formatearTamanio(r.tamanioBytes) }}</td>
            <td class="acciones-fila">
              <button class="btn-texto" (click)="descargar(r)">Descargar</button>
              <button class="btn-texto peligro" (click)="abrirRestaurar(r)">Restaurar</button>
            </td>
          </tr>
        }
      </tbody>
    </table>
  }
</div>

<div class="card seccion">
  <h3>Historial de Acciones Cr\xEDticas</h3>
  <table class="tabla-admin">
    <thead>
      <tr>
        <th>Fecha/Hora</th>
        <th>Usuario</th>
        <th>Acci\xF3n Realizada</th>
        <th>IP</th>
      </tr>
    </thead>
    <tbody>
      @for (item of bitacora; track item.id) {
        <tr>
          <td>{{ item.fecha }}</td>
          <td>{{ item.usuario }}</td>
          <td>{{ item.accionRealizada }}</td>
          <td>{{ item.ip }}</td>
        </tr>
      }
    </tbody>
  </table>
</div>

@if (mostrarModalRestaurar) {
  <div class="modal-overlay" (click)="cerrarRestaurar()">
    <div class="modal card" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>Restaurar Punto Anterior</h3>
        <button class="modal-cerrar" (click)="cerrarRestaurar()" aria-label="Cerrar">\u2715</button>
      </div>
      <p class="aviso-peligro">
        Esta acci\xF3n reemplazar\xE1 TODOS los datos actuales de la base de datos con el contenido
        del respaldo <strong>{{ archivoARestaurar }}</strong>. No se puede deshacer.
      </p>
      <div class="input-group">
        <label>Escribe RESTAURAR para confirmar:</label>
        <input type="text" [(ngModel)]="confirmacionTexto" name="confirmacionTexto" />
      </div>
      <div class="modal-acciones">
        <button class="btn-primary boton-peligro" (click)="confirmarRestauracion()">Confirmar Restauraci\xF3n</button>
        <button class="btn-secondary" (click)="cerrarRestaurar()">Cancelar</button>
      </div>
    </div>
  </div>
}
`, styles: ["/* src/app/pages/seguridad-respaldos/seguridad-respaldos.scss */\n.seccion {\n  margin-bottom: 20px;\n}\n.seccion h3 {\n  margin-bottom: 10px;\n}\n.estado-ok {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  color: var(--exito);\n  font-weight: 600;\n  margin: 0 0 4px;\n}\n.estado-ok .punto-estado {\n  width: 9px;\n  height: 9px;\n  border-radius: 50%;\n  background: var(--exito);\n}\n.dato {\n  color: var(--texto-suave);\n  font-size: 0.88rem;\n  margin-bottom: 16px;\n}\n.acciones {\n  display: flex;\n  gap: 12px;\n  flex-wrap: wrap;\n  margin-bottom: 10px;\n}\n.config-nota {\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n  margin: 0;\n}\n.cargando {\n  color: var(--texto-suave);\n}\n.acciones-fila {\n  display: flex;\n  gap: 10px;\n}\n.acciones-fila .peligro {\n  color: var(--peligro);\n}\n.boton-peligro {\n  background-color: var(--peligro) !important;\n}\n.boton-peligro:hover {\n  background-color: #a31f1f !important;\n}\n/*# sourceMappingURL=seguridad-respaldos.css.map */\n"] }]
  }], () => [{ type: SeguridadService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(SeguridadRespaldos, { className: "SeguridadRespaldos", filePath: "src/app/pages/seguridad-respaldos/seguridad-respaldos.ts", lineNumber: 16 });
})();
export {
  SeguridadRespaldos
};
//# sourceMappingURL=chunk-CHDFFQKU.js.map
