import {
  AuthAdminService,
  irALoginPersonal
} from "./chunk-OE7LXFF3.js";
import {
  Router,
  RouterLink,
  RouterLinkActive,
  RouterOutlet
} from "./chunk-FZQGDKC3.js";
import {
  etiquetaRol,
  iniciales
} from "./chunk-GNNLFNWH.js";
import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel
} from "./chunk-QAQG5DUR.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  HostListener,
  HttpClient,
  Injectable,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵresetView,
  ɵɵresolveDocument,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-FOUSSYWU.js";

// src/app/core/services/perfil.service.ts
var PerfilService = class _PerfilService {
  http;
  apiUrl = "/api/admin/perfil";
  constructor(http) {
    this.http = http;
  }
  cambiarPassword(datos) {
    return this.http.put(`${this.apiUrl}/password`, datos);
  }
  static \u0275fac = function PerfilService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _PerfilService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _PerfilService, factory: _PerfilService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PerfilService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/admin-layout/admin-layout.ts
var _c0 = () => ({ exact: true });
function AdminLayout_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 43);
    \u0275\u0275listener("click", function AdminLayout_Conditional_16_Template_div_click_0_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(1, "button", 44);
    \u0275\u0275listener("click", function AdminLayout_Conditional_16_Template_button_click_1_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.abrirModalPassword());
    });
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 9);
    \u0275\u0275element(3, "circle", 45)(4, "path", 46)(5, "path", 47)(6, "path", 48);
    \u0275\u0275elementEnd();
    \u0275\u0275text(7, " Cambiar contrase\xF1a ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275element(8, "div", 49);
    \u0275\u0275elementStart(9, "button", 50);
    \u0275\u0275listener("click", function AdminLayout_Conditional_16_Template_button_click_9_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarSesion());
    });
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(10, "svg", 9);
    \u0275\u0275element(11, "path", 51)(12, "polyline", 52)(13, "line", 53);
    \u0275\u0275elementEnd();
    \u0275\u0275text(14, " Cerrar sesi\xF3n ");
    \u0275\u0275elementEnd()();
  }
}
function AdminLayout_Conditional_64_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 71);
    \u0275\u0275listener("click", function AdminLayout_Conditional_64_Conditional_5_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.cerrarModalPassword());
    });
    \u0275\u0275text(1, "\u2715");
    \u0275\u0275elementEnd();
  }
}
function AdminLayout_Conditional_64_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 57);
    \u0275\u0275text(1, " Tu cuenta tiene una contrase\xF1a temporal. Debes establecer una nueva antes de continuar usando la consola. ");
    \u0275\u0275elementEnd();
  }
}
function AdminLayout_Conditional_64_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 67);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorPassword);
  }
}
function AdminLayout_Conditional_64_Conditional_45_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 72);
    \u0275\u0275listener("click", function AdminLayout_Conditional_64_Conditional_45_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.cerrarModalPassword());
    });
    \u0275\u0275text(1, "Cancelar");
    \u0275\u0275elementEnd();
  }
}
function AdminLayout_Conditional_64_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 42)(1, "div", 54);
    \u0275\u0275listener("click", function AdminLayout_Conditional_64_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 55)(3, "h3");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(5, AdminLayout_Conditional_64_Conditional_5_Template, 2, 0, "button", 56);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(6, AdminLayout_Conditional_64_Conditional_6_Template, 2, 0, "p", 57);
    \u0275\u0275elementStart(7, "div", 58)(8, "label");
    \u0275\u0275text(9, "Contrase\xF1a actual");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "div", 59)(11, "input", 60);
    \u0275\u0275twoWayListener("ngModelChange", function AdminLayout_Conditional_64_Template_input_ngModelChange_11_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordActual, $event) || (ctx_r1.passwordActual = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "button", 61);
    \u0275\u0275listener("click", function AdminLayout_Conditional_64_Template_button_click_12_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.mostrarActual = !ctx_r1.mostrarActual);
    });
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(14, "div", 58)(15, "label");
    \u0275\u0275text(16, "Contrase\xF1a nueva");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "div", 59)(18, "input", 62);
    \u0275\u0275twoWayListener("ngModelChange", function AdminLayout_Conditional_64_Template_input_ngModelChange_18_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordNueva, $event) || (ctx_r1.passwordNueva = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "button", 61);
    \u0275\u0275listener("click", function AdminLayout_Conditional_64_Template_button_click_19_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.mostrarNueva = !ctx_r1.mostrarNueva);
    });
    \u0275\u0275text(20);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "ul", 63)(22, "li")(23, "span", 14);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(24, "svg", 64);
    \u0275\u0275element(25, "polyline", 65);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(26, " Al menos 8 caracteres ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(27, "li")(28, "span", 14);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(29, "svg", 64);
    \u0275\u0275element(30, "polyline", 65);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(31, " Una letra may\xFAscula ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(32, "li")(33, "span", 14);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(34, "svg", 64);
    \u0275\u0275element(35, "polyline", 65);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(36, " Un n\xFAmero ");
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(37, "div", 58)(38, "label");
    \u0275\u0275text(39, "Confirmar contrase\xF1a nueva");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "input", 66);
    \u0275\u0275twoWayListener("ngModelChange", function AdminLayout_Conditional_64_Template_input_ngModelChange_40_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordConfirmar, $event) || (ctx_r1.passwordConfirmar = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(41, AdminLayout_Conditional_64_Conditional_41_Template, 2, 1, "p", 67);
    \u0275\u0275elementStart(42, "div", 68)(43, "button", 69);
    \u0275\u0275listener("click", function AdminLayout_Conditional_64_Template_button_click_43_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.guardarPassword());
    });
    \u0275\u0275text(44);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(45, AdminLayout_Conditional_64_Conditional_45_Template, 2, 0, "button", 70);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.cambioObligatorio ? "Actualiza tu contrase\xF1a temporal" : "Cambiar mi contrase\xF1a");
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx_r1.cambioObligatorio ? 5 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.cambioObligatorio ? 6 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275property("type", ctx_r1.mostrarActual ? "text" : "password");
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordActual);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.mostrarActual ? "\u{1F648}" : "\u{1F441}\uFE0F");
    \u0275\u0275advance(5);
    \u0275\u0275property("type", ctx_r1.mostrarNueva ? "text" : "password");
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordNueva);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.mostrarNueva ? "\u{1F648}" : "\u{1F441}\uFE0F");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleLongitud);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleMayuscula);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleNumero);
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordConfirmar);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.errorPassword ? 41 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r1.guardandoPassword);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.guardandoPassword ? "Guardando\u2026" : "Actualizar Contrase\xF1a", " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx_r1.cambioObligatorio ? 45 : -1);
  }
}
var AdminLayout = class _AdminLayout {
  authService;
  perfilService;
  router;
  toast;
  cdr;
  etiquetaRol = etiquetaRol;
  menuAbierto = false;
  mostrarModalPassword = false;
  cambioObligatorio = false;
  passwordActual = "";
  passwordNueva = "";
  passwordConfirmar = "";
  mostrarActual = false;
  mostrarNueva = false;
  guardandoPassword = false;
  errorPassword = "";
  constructor(authService, perfilService, router, toast, cdr) {
    this.authService = authService;
    this.perfilService = perfilService;
    this.router = router;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    const usuario = this.authService.usuarioActual();
    if (usuario?.forzarCambioPassword) {
      this.cambioObligatorio = true;
      this.abrirModalPassword();
    }
  }
  get nombreUsuario() {
    return this.authService.usuarioActual()?.nombre ?? "";
  }
  get rolUsuario() {
    const rol = this.authService.usuarioActual()?.rol;
    return rol ? this.etiquetaRol(rol) : "";
  }
  get inicialesUsuario() {
    return iniciales(this.nombreUsuario);
  }
  cerrarMenuAlHacerClickFuera() {
    this.menuAbierto = false;
  }
  alternarMenu(evento) {
    evento.stopPropagation();
    this.menuAbierto = !this.menuAbierto;
  }
  abrirModalPassword() {
    this.menuAbierto = false;
    this.passwordActual = "";
    this.passwordNueva = "";
    this.passwordConfirmar = "";
    this.errorPassword = "";
    this.mostrarModalPassword = true;
  }
  cerrarModalPassword() {
    if (this.cambioObligatorio) {
      this.toast.advertencia("Debes actualizar tu contrase\xF1a temporal antes de continuar.");
      return;
    }
    this.mostrarModalPassword = false;
  }
  get cumpleLongitud() {
    return this.passwordNueva.length >= 8;
  }
  get cumpleMayuscula() {
    return /[A-Z]/.test(this.passwordNueva);
  }
  get cumpleNumero() {
    return /\d/.test(this.passwordNueva);
  }
  get cumpleCoinciden() {
    return this.passwordNueva.length > 0 && this.passwordNueva === this.passwordConfirmar;
  }
  guardarPassword() {
    this.errorPassword = "";
    if (!this.passwordActual) {
      this.errorPassword = "Ingresa tu contrase\xF1a actual.";
      return;
    }
    if (!this.cumpleLongitud || !this.cumpleMayuscula || !this.cumpleNumero) {
      this.errorPassword = "La nueva contrase\xF1a no cumple los requisitos.";
      return;
    }
    if (!this.cumpleCoinciden) {
      this.errorPassword = "La confirmaci\xF3n no coincide con la nueva contrase\xF1a.";
      return;
    }
    const datos = {
      passwordActual: this.passwordActual,
      passwordNueva: this.passwordNueva
    };
    this.guardandoPassword = true;
    this.perfilService.cambiarPassword(datos).subscribe({
      next: () => {
        this.guardandoPassword = false;
        this.cambioObligatorio = false;
        this.mostrarModalPassword = false;
        this.authService.marcarPasswordActualizada();
        this.toast.exito("Contrase\xF1a actualizada correctamente.");
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.guardandoPassword = false;
        this.errorPassword = err?.error?.mensaje ?? "No se pudo actualizar la contrase\xF1a.";
        this.cdr.detectChanges();
      }
    });
  }
  cerrarSesion() {
    this.authService.logout();
    irALoginPersonal();
  }
  static \u0275fac = function AdminLayout_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _AdminLayout)(\u0275\u0275directiveInject(AuthAdminService), \u0275\u0275directiveInject(PerfilService), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AdminLayout, selectors: [["app-admin-layout"]], hostBindings: function AdminLayout_HostBindings(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275listener("click", function AdminLayout_click_HostBindingHandler() {
        return ctx.cerrarMenuAlHacerClickFuera();
      }, \u0275\u0275resolveDocument);
    }
  }, decls: 65, vars: 7, consts: [[1, "topbar"], [1, "topbar-marca"], [1, "topbar-marca-punto"], [1, "dropdown"], [1, "perfil-boton", 3, "click"], [1, "avatar"], [1, "perfil-texto"], [1, "perfil-nombre"], [1, "perfil-rol"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["points", "6 9 12 15 18 9"], [1, "dropdown-menu"], [1, "layout"], [1, "sidebar"], [1, "marca"], [1, "marca-escudo"], [1, "marca-texto"], ["routerLink", "/", "routerLinkActive", "activo", 3, "routerLinkActiveOptions"], ["d", "M3 9.5L12 3l9 6.5"], ["d", "M5 10v10h14V10"], ["d", "M9 20v-6h6v6"], ["routerLink", "/usuarios-roles", "routerLinkActive", "activo"], ["d", "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"], ["cx", "9", "cy", "7", "r", "4"], ["d", "M23 21v-2a4 4 0 0 0-3-3.87"], ["d", "M16 3.13a4 4 0 0 1 0 7.75"], ["routerLink", "/catalogo-dependencias", "routerLinkActive", "activo"], ["d", "M3 21h18"], ["d", "M5 21V7l7-4 7 4v14"], ["d", "M9 9h1"], ["d", "M9 13h1"], ["d", "M14 9h1"], ["d", "M14 13h1"], ["d", "M10 21v-5h4v5"], ["routerLink", "/plantillas", "routerLinkActive", "activo"], ["d", "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"], ["points", "14 2 14 8 20 8"], ["x1", "8", "y1", "13", "x2", "16", "y2", "13"], ["x1", "8", "y1", "17", "x2", "16", "y2", "17"], ["routerLink", "/seguridad-respaldos", "routerLinkActive", "activo"], ["d", "M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6z"], [1, "contenido"], [1, "modal-overlay"], [1, "dropdown-menu", 3, "click"], [3, "click"], ["cx", "7.5", "cy", "15.5", "r", "5.5"], ["d", "M21 2l-9.6 9.6"], ["d", "M15.5 7.5L18 5"], ["d", "M17 3l4 4"], [1, "dropdown-separador"], [1, "peligro", 3, "click"], ["d", "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"], ["points", "16 17 21 12 16 7"], ["x1", "21", "y1", "12", "x2", "9", "y2", "12"], [1, "modal", "card", 3, "click"], [1, "modal-header"], ["aria-label", "Cerrar", 1, "modal-cerrar"], [1, "aviso-inline"], [1, "input-group"], [1, "campo-password"], ["name", "passwordActual", 3, "ngModelChange", "type", "ngModel"], ["type", "button", 1, "alternar-password", 3, "click"], ["name", "passwordNueva", 3, "ngModelChange", "type", "ngModel"], [1, "requisitos-password"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "3", "stroke-linecap", "round", "stroke-linejoin", "round"], ["points", "20 6 9 17 4 12"], ["type", "password", "name", "passwordConfirmar", 3, "ngModelChange", "ngModel"], [1, "mensaje-campo"], [1, "modal-acciones"], [1, "btn-primary", 3, "click", "disabled"], [1, "btn-secondary"], ["aria-label", "Cerrar", 1, "modal-cerrar", 3, "click"], [1, "btn-secondary", 3, "click"]], template: function AdminLayout_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "header", 0)(1, "div", 1);
      \u0275\u0275element(2, "span", 2);
      \u0275\u0275elementStart(3, "span");
      \u0275\u0275text(4, "Defensor\xEDa de los Derechos Polit\xE9cnicos");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(5, "div", 3)(6, "button", 4);
      \u0275\u0275listener("click", function AdminLayout_Template_button_click_6_listener($event) {
        return ctx.alternarMenu($event);
      });
      \u0275\u0275elementStart(7, "span", 5);
      \u0275\u0275text(8);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(9, "span", 6)(10, "span", 7);
      \u0275\u0275text(11);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(12, "span", 8);
      \u0275\u0275text(13);
      \u0275\u0275elementEnd()();
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(14, "svg", 9);
      \u0275\u0275element(15, "polyline", 10);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(16, AdminLayout_Conditional_16_Template, 15, 0, "div", 11);
      \u0275\u0275elementEnd()();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(17, "div", 12)(18, "aside", 13)(19, "div", 14)(20, "div", 15);
      \u0275\u0275text(21, "DDP");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(22, "div", 16)(23, "strong");
      \u0275\u0275text(24, "Panel de la Defensora");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(25, "span");
      \u0275\u0275text(26, "Sistema de Accesos");
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(27, "nav")(28, "a", 17);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(29, "svg", 9);
      \u0275\u0275element(30, "path", 18)(31, "path", 19)(32, "path", 20);
      \u0275\u0275elementEnd();
      \u0275\u0275text(33, " Configuraci\xF3n General ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(34, "a", 21);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(35, "svg", 9);
      \u0275\u0275element(36, "path", 22)(37, "circle", 23)(38, "path", 24)(39, "path", 25);
      \u0275\u0275elementEnd();
      \u0275\u0275text(40, " Usuarios y Roles ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(41, "a", 26);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(42, "svg", 9);
      \u0275\u0275element(43, "path", 27)(44, "path", 28)(45, "path", 29)(46, "path", 30)(47, "path", 31)(48, "path", 32)(49, "path", 33);
      \u0275\u0275elementEnd();
      \u0275\u0275text(50, " Cat\xE1logo de Dependencias ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(51, "a", 34);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(52, "svg", 9);
      \u0275\u0275element(53, "path", 35)(54, "polyline", 36)(55, "line", 37)(56, "line", 38);
      \u0275\u0275elementEnd();
      \u0275\u0275text(57, " Plantillas Oficiales ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(58, "a", 39);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(59, "svg", 9);
      \u0275\u0275element(60, "path", 40);
      \u0275\u0275elementEnd();
      \u0275\u0275text(61, " Seguridad y Respaldos ");
      \u0275\u0275elementEnd()()();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(62, "main", 41);
      \u0275\u0275element(63, "router-outlet");
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(64, AdminLayout_Conditional_64_Template, 46, 20, "div", 42);
    }
    if (rf & 2) {
      \u0275\u0275advance(8);
      \u0275\u0275textInterpolate(ctx.inicialesUsuario);
      \u0275\u0275advance(3);
      \u0275\u0275textInterpolate(ctx.nombreUsuario);
      \u0275\u0275advance(2);
      \u0275\u0275textInterpolate(ctx.rolUsuario);
      \u0275\u0275advance(3);
      \u0275\u0275conditional(ctx.menuAbierto ? 16 : -1);
      \u0275\u0275advance(12);
      \u0275\u0275property("routerLinkActiveOptions", \u0275\u0275pureFunction0(6, _c0));
      \u0275\u0275advance(36);
      \u0275\u0275conditional(ctx.mostrarModalPassword ? 64 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, DefaultValueAccessor, NgControlStatus, NgModel, RouterLink, RouterLinkActive, RouterOutlet], styles: ["\n[_nghost-%COMP%] {\n  display: block;\n  min-height: 100vh;\n}\n.topbar[_ngcontent-%COMP%] {\n  background: #fff;\n  border-bottom: 1px solid var(--borde);\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 16px;\n  padding: 10px 24px;\n  position: sticky;\n  top: 0;\n  z-index: 100;\n}\n.topbar-marca[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: var(--texto-suave);\n}\n.topbar-marca-punto[_ngcontent-%COMP%] {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: var(--exito);\n}\n.perfil-boton[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: none;\n  border: none;\n  padding: 5px 8px;\n  border-radius: 8px;\n}\n.perfil-boton[_ngcontent-%COMP%]:hover {\n  background: var(--gris-fondo);\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-texto[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  line-height: 1.2;\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-nombre[_ngcontent-%COMP%] {\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-rol[_ngcontent-%COMP%] {\n  font-size: 0.72rem;\n  color: var(--guinda-vivo);\n  font-weight: 600;\n}\n.perfil-boton[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.layout[_ngcontent-%COMP%] {\n  display: flex;\n  min-height: calc(100vh - 53px);\n}\n.sidebar[_ngcontent-%COMP%] {\n  width: 252px;\n  background: var(--sidebar-fondo);\n  padding: 18px 0;\n  flex-shrink: 0;\n}\n.sidebar[_ngcontent-%COMP%]   .marca[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  padding: 0 20px 22px;\n  margin-bottom: 6px;\n  border-bottom: 1px solid rgba(255, 255, 255, 0.08);\n}\n.sidebar[_ngcontent-%COMP%]   .marca-escudo[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 8px;\n  background:\n    linear-gradient(\n      135deg,\n      var(--guinda-vivo),\n      var(--guinda-oscuro));\n  color: #fff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 700;\n  font-size: 0.72rem;\n  letter-spacing: 0.5px;\n  flex-shrink: 0;\n}\n.sidebar[_ngcontent-%COMP%]   .marca-texto[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  line-height: 1.25;\n}\n.sidebar[_ngcontent-%COMP%]   .marca-texto[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #fff;\n  font-size: 0.9rem;\n}\n.sidebar[_ngcontent-%COMP%]   .marca-texto[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: var(--sidebar-texto);\n  font-size: 0.72rem;\n}\n.sidebar[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%] {\n  padding-top: 8px;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  color: var(--sidebar-texto);\n  text-decoration: none;\n  padding: 12px 22px;\n  font-size: 0.87rem;\n  border-left: 3px solid transparent;\n  transition: background 0.15s ease, color 0.15s ease;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  flex-shrink: 0;\n  opacity: 0.85;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  background: rgba(255, 255, 255, 0.05);\n  color: #fff;\n}\n.sidebar[_ngcontent-%COMP%]   a.activo[_ngcontent-%COMP%] {\n  background: var(--sidebar-fondo-activo);\n  color: #fff;\n  font-weight: 600;\n  border-left-color: var(--guinda-vivo);\n}\n.sidebar[_ngcontent-%COMP%]   a.activo[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  opacity: 1;\n}\n.contenido[_ngcontent-%COMP%] {\n  flex: 1;\n  padding: 30px 34px;\n  max-width: 1180px;\n}\n/*# sourceMappingURL=admin-layout.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AdminLayout, [{
    type: Component,
    args: [{ selector: "app-admin-layout", standalone: true, imports: [CommonModule, FormsModule, RouterLink, RouterLinkActive, RouterOutlet], template: `<header class="topbar">
  <div class="topbar-marca">
    <span class="topbar-marca-punto"></span>
    <span>Defensor\xEDa de los Derechos Polit\xE9cnicos</span>
  </div>

  <div class="dropdown">
    <button class="perfil-boton" (click)="alternarMenu($event)">
      <span class="avatar">{{ inicialesUsuario }}</span>
      <span class="perfil-texto">
        <span class="perfil-nombre">{{ nombreUsuario }}</span>
        <span class="perfil-rol">{{ rolUsuario }}</span>
      </span>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
    </button>

    @if (menuAbierto) {
      <div class="dropdown-menu" (click)="$event.stopPropagation()">
        <button (click)="abrirModalPassword()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="5.5"></circle><path d="M21 2l-9.6 9.6"></path><path d="M15.5 7.5L18 5"></path><path d="M17 3l4 4"></path></svg>
          Cambiar contrase\xF1a
        </button>
        <div class="dropdown-separador"></div>
        <button class="peligro" (click)="cerrarSesion()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
          Cerrar sesi\xF3n
        </button>
      </div>
    }
  </div>
</header>

<div class="layout">
  <aside class="sidebar">
    <div class="marca">
      <div class="marca-escudo">DDP</div>
      <div class="marca-texto">
        <strong>Panel de la Defensora</strong>
        <span>Sistema de Accesos</span>
      </div>
    </div>

    <nav>
      <a routerLink="/" routerLinkActive="activo" [routerLinkActiveOptions]="{ exact: true }">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5L12 3l9 6.5"></path><path d="M5 10v10h14V10"></path><path d="M9 20v-6h6v6"></path></svg>
        Configuraci\xF3n General
      </a>
      <a routerLink="/usuarios-roles" routerLinkActive="activo">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
        Usuarios y Roles
      </a>
      <a routerLink="/catalogo-dependencias" routerLinkActive="activo">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"></path><path d="M5 21V7l7-4 7 4v14"></path><path d="M9 9h1"></path><path d="M9 13h1"></path><path d="M14 9h1"></path><path d="M14 13h1"></path><path d="M10 21v-5h4v5"></path></svg>
        Cat\xE1logo de Dependencias
      </a>
      <a routerLink="/plantillas" routerLinkActive="activo">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="8" y1="13" x2="16" y2="13"></line><line x1="8" y1="17" x2="16" y2="17"></line></svg>
        Plantillas Oficiales
      </a>
      <a routerLink="/seguridad-respaldos" routerLinkActive="activo">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6z"></path></svg>
        Seguridad y Respaldos
      </a>
    </nav>
  </aside>

  <main class="contenido">
    <router-outlet />
  </main>
</div>

@if (mostrarModalPassword) {
  <div class="modal-overlay">
    <div class="modal card" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>{{ cambioObligatorio ? 'Actualiza tu contrase\xF1a temporal' : 'Cambiar mi contrase\xF1a' }}</h3>
        @if (!cambioObligatorio) {
          <button class="modal-cerrar" (click)="cerrarModalPassword()" aria-label="Cerrar">\u2715</button>
        }
      </div>

      @if (cambioObligatorio) {
        <p class="aviso-inline">
          Tu cuenta tiene una contrase\xF1a temporal. Debes establecer una nueva antes de continuar
          usando la consola.
        </p>
      }

      <div class="input-group">
        <label>Contrase\xF1a actual</label>
        <div class="campo-password">
          <input
            [type]="mostrarActual ? 'text' : 'password'"
            [(ngModel)]="passwordActual"
            name="passwordActual"
          />
          <button
            type="button"
            class="alternar-password"
            (click)="mostrarActual = !mostrarActual"
          >{{ mostrarActual ? '\u{1F648}' : '\u{1F441}\uFE0F' }}</button>
        </div>
      </div>

      <div class="input-group">
        <label>Contrase\xF1a nueva</label>
        <div class="campo-password">
          <input
            [type]="mostrarNueva ? 'text' : 'password'"
            [(ngModel)]="passwordNueva"
            name="passwordNueva"
          />
          <button
            type="button"
            class="alternar-password"
            (click)="mostrarNueva = !mostrarNueva"
          >{{ mostrarNueva ? '\u{1F648}' : '\u{1F441}\uFE0F' }}</button>
        </div>
      </div>

      <ul class="requisitos-password">
        <li [class.cumplido]="cumpleLongitud">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Al menos 8 caracteres
        </li>
        <li [class.cumplido]="cumpleMayuscula">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Una letra may\xFAscula
        </li>
        <li [class.cumplido]="cumpleNumero">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Un n\xFAmero
        </li>
      </ul>

      <div class="input-group">
        <label>Confirmar contrase\xF1a nueva</label>
        <input type="password" [(ngModel)]="passwordConfirmar" name="passwordConfirmar" />
      </div>

      @if (errorPassword) {
        <p class="mensaje-campo">{{ errorPassword }}</p>
      }

      <div class="modal-acciones">
        <button class="btn-primary" (click)="guardarPassword()" [disabled]="guardandoPassword">
          {{ guardandoPassword ? 'Guardando\u2026' : 'Actualizar Contrase\xF1a' }}
        </button>
        @if (!cambioObligatorio) {
          <button class="btn-secondary" (click)="cerrarModalPassword()">Cancelar</button>
        }
      </div>
    </div>
  </div>
}
`, styles: ["/* src/app/pages/admin-layout/admin-layout.scss */\n:host {\n  display: block;\n  min-height: 100vh;\n}\n.topbar {\n  background: #fff;\n  border-bottom: 1px solid var(--borde);\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 16px;\n  padding: 10px 24px;\n  position: sticky;\n  top: 0;\n  z-index: 100;\n}\n.topbar-marca {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: var(--texto-suave);\n}\n.topbar-marca-punto {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: var(--exito);\n}\n.perfil-boton {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: none;\n  border: none;\n  padding: 5px 8px;\n  border-radius: 8px;\n}\n.perfil-boton:hover {\n  background: var(--gris-fondo);\n}\n.perfil-boton .perfil-texto {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  line-height: 1.2;\n}\n.perfil-boton .perfil-nombre {\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.perfil-boton .perfil-rol {\n  font-size: 0.72rem;\n  color: var(--guinda-vivo);\n  font-weight: 600;\n}\n.perfil-boton svg {\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.layout {\n  display: flex;\n  min-height: calc(100vh - 53px);\n}\n.sidebar {\n  width: 252px;\n  background: var(--sidebar-fondo);\n  padding: 18px 0;\n  flex-shrink: 0;\n}\n.sidebar .marca {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  padding: 0 20px 22px;\n  margin-bottom: 6px;\n  border-bottom: 1px solid rgba(255, 255, 255, 0.08);\n}\n.sidebar .marca-escudo {\n  width: 38px;\n  height: 38px;\n  border-radius: 8px;\n  background:\n    linear-gradient(\n      135deg,\n      var(--guinda-vivo),\n      var(--guinda-oscuro));\n  color: #fff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 700;\n  font-size: 0.72rem;\n  letter-spacing: 0.5px;\n  flex-shrink: 0;\n}\n.sidebar .marca-texto {\n  display: flex;\n  flex-direction: column;\n  line-height: 1.25;\n}\n.sidebar .marca-texto strong {\n  color: #fff;\n  font-size: 0.9rem;\n}\n.sidebar .marca-texto span {\n  color: var(--sidebar-texto);\n  font-size: 0.72rem;\n}\n.sidebar nav {\n  padding-top: 8px;\n}\n.sidebar a {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  color: var(--sidebar-texto);\n  text-decoration: none;\n  padding: 12px 22px;\n  font-size: 0.87rem;\n  border-left: 3px solid transparent;\n  transition: background 0.15s ease, color 0.15s ease;\n}\n.sidebar a svg {\n  width: 18px;\n  height: 18px;\n  flex-shrink: 0;\n  opacity: 0.85;\n}\n.sidebar a:hover {\n  background: rgba(255, 255, 255, 0.05);\n  color: #fff;\n}\n.sidebar a.activo {\n  background: var(--sidebar-fondo-activo);\n  color: #fff;\n  font-weight: 600;\n  border-left-color: var(--guinda-vivo);\n}\n.sidebar a.activo svg {\n  opacity: 1;\n}\n.contenido {\n  flex: 1;\n  padding: 30px 34px;\n  max-width: 1180px;\n}\n/*# sourceMappingURL=admin-layout.css.map */\n"] }]
  }], () => [{ type: AuthAdminService }, { type: PerfilService }, { type: Router }, { type: ToastService }, { type: ChangeDetectorRef }], { cerrarMenuAlHacerClickFuera: [{
    type: HostListener,
    args: ["document:click"]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AdminLayout, { className: "AdminLayout", filePath: "src/app/pages/admin-layout/admin-layout.ts", lineNumber: 19 });
})();
export {
  AdminLayout
};
//# sourceMappingURL=chunk-U3YAV3RC.js.map
