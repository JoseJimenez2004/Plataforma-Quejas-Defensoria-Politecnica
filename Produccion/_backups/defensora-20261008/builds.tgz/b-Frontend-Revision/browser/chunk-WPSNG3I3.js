import {
  AuthRevisionService
} from "./chunk-T3TYP7ZV.js";
import {
  RevisionService
} from "./chunk-6BWVIYFH.js";
import {
  RouterLink
} from "./chunk-F26HINUV.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DatePipe,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction1,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-FT7UGDQZ.js";

// src/app/pages/bandeja/bandeja.ts
var _c0 = (a0) => ["/validacion", a0];
var _forTrack0 = ($index, $item) => $item.numeroFolio;
function Bandeja_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 2);
    \u0275\u0275text(1, "Cargando bandeja\u2026");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_7_Conditional_34_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 18);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(1, "svg", 20);
    \u0275\u0275element(2, "rect", 8)(3, "polyline", 9);
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(4, "p");
    \u0275\u0275text(5, "No hay quejas pendientes por trabajar.");
    \u0275\u0275elementEnd()();
  }
}
function Bandeja_Conditional_7_Conditional_35_For_17_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 22);
    \u0275\u0275text(1, "\u2713");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_7_Conditional_35_For_17_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 23);
    \u0275\u0275text(1, "\u2715");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_7_Conditional_35_For_17_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 24);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r1 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275property("title", "En revisi\xF3n por " + item_r1.revisandoPorNombre);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" En revisi\xF3n \xB7 ", item_r1.revisandoPorNombre, " ");
  }
}
function Bandeja_Conditional_7_Conditional_35_For_17_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 25);
    \u0275\u0275text(1, "Pendiente");
    \u0275\u0275elementEnd();
  }
}
function Bandeja_Conditional_7_Conditional_35_For_17_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "button", 26);
    \u0275\u0275text(1, " En revisi\xF3n ");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r1 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275property("title", "La est\xE1 revisando " + item_r1.revisandoPorNombre + ". Se libera sola si la deja inactiva.");
  }
}
function Bandeja_Conditional_7_Conditional_35_For_17_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "a", 27);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r1 = \u0275\u0275nextContext().$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275property("routerLink", \u0275\u0275pureFunction1(2, _c0, item_r1.numeroFolio));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.esMiRevision(item_r1) ? "Continuar" : "Validar", " ");
  }
}
function Bandeja_Conditional_7_Conditional_35_For_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td");
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "date");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "td");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "td");
    \u0275\u0275conditionalCreate(9, Bandeja_Conditional_7_Conditional_35_For_17_Conditional_9_Template, 2, 0, "span", 22)(10, Bandeja_Conditional_7_Conditional_35_For_17_Conditional_10_Template, 2, 0, "span", 23);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "td");
    \u0275\u0275conditionalCreate(12, Bandeja_Conditional_7_Conditional_35_For_17_Conditional_12_Template, 2, 2, "span", 24)(13, Bandeja_Conditional_7_Conditional_35_For_17_Conditional_13_Template, 2, 0, "span", 25);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "td");
    \u0275\u0275conditionalCreate(15, Bandeja_Conditional_7_Conditional_35_For_17_Conditional_15_Template, 2, 1, "button", 26)(16, Bandeja_Conditional_7_Conditional_35_For_17_Conditional_16_Template, 2, 4, "a", 27);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const item_r1 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("fila-bloqueada", ctx_r1.bloqueadaPorOtro(item_r1));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(item_r1.numeroFolio);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(5, 8, item_r1.fechaCreacion, "dd/MM/yy"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(item_r1.nombreQuejoso);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(item_r1.documentacionAparenteCompleta ? 9 : 10);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(item_r1.estatus === "EN_VALIDACION" && item_r1.revisandoPorNombre ? 12 : 13);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r1.bloqueadaPorOtro(item_r1) ? 15 : 16);
  }
}
function Bandeja_Conditional_7_Conditional_35_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "table", 19)(1, "thead")(2, "tr")(3, "th");
    \u0275\u0275text(4, "Folio");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "th");
    \u0275\u0275text(6, "Fecha");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "th");
    \u0275\u0275text(8, "Quejoso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "th");
    \u0275\u0275text(10, "Documentaci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "th");
    \u0275\u0275text(12, "Estatus");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "th");
    \u0275\u0275text(14, "Acciones");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(15, "tbody");
    \u0275\u0275repeaterCreate(16, Bandeja_Conditional_7_Conditional_35_For_17_Template, 17, 11, "tr", 21, _forTrack0);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(16);
    \u0275\u0275repeater(ctx_r1.resumen.lista);
  }
}
function Bandeja_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 3)(1, "div", 4)(2, "div", 5)(3, "span", 6);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(4, "svg", 7);
    \u0275\u0275element(5, "rect", 8)(6, "polyline", 9);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(7, "h3");
    \u0275\u0275text(8, "Pendientes");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "p", 10);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 4)(12, "div", 5)(13, "span", 11);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(14, "svg", 7);
    \u0275\u0275element(15, "circle", 12)(16, "polyline", 13);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(17, "h3");
    \u0275\u0275text(18, "En Proceso");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(19, "p", 10);
    \u0275\u0275text(20);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(21, "div", 4)(22, "div", 5)(23, "span", 14);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(24, "svg", 7);
    \u0275\u0275element(25, "path", 15)(26, "polyline", 16);
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(27, "h3");
    \u0275\u0275text(28, "Turnadas hoy");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(29, "p", 10);
    \u0275\u0275text(30);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(31, "div", 17)(32, "h3");
    \u0275\u0275text(33, "Panel de Gesti\xF3n de Recepci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(34, Bandeja_Conditional_7_Conditional_34_Template, 6, 0, "div", 18)(35, Bandeja_Conditional_7_Conditional_35_Template, 18, 0, "table", 19);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate(ctx_r1.resumen.pendientes);
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate(ctx_r1.resumen.enProceso);
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate(ctx_r1.resumen.turnadasHoy);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r1.resumen.lista.length === 0 ? 34 : 35);
  }
}
var INTERVALO_REFRESCO_MS = 2e4;
var Bandeja = class _Bandeja {
  revisionService;
  authService;
  toast;
  cdr;
  resumen = null;
  cargando = true;
  intervaloId = null;
  constructor(revisionService, authService, toast, cdr) {
    this.revisionService = revisionService;
    this.authService = authService;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.cargar();
    this.intervaloId = setInterval(() => this.cargar(
      /* silencioso */
      true
    ), INTERVALO_REFRESCO_MS);
  }
  ngOnDestroy() {
    if (this.intervaloId !== null) {
      clearInterval(this.intervaloId);
    }
  }
  /** true si la propia sesión es quien tiene abierta esta queja (puede continuar). */
  esMiRevision(item) {
    const miNombre = this.authService.usuarioActual()?.nombre;
    return !!miNombre && item.revisandoPorNombre === miNombre;
  }
  /** true si OTRO recepcionista la tiene abierta ahora mismo -- se deshabilita para que no la
   * dupliquen; se libera sola si esa persona la deja inactiva (ver revision-service). */
  bloqueadaPorOtro(item) {
    return item.estatus === "EN_VALIDACION" && !!item.revisandoPorNombre && !this.esMiRevision(item);
  }
  cargar(silencioso = false) {
    if (!silencioso) {
      this.cargando = true;
    }
    this.revisionService.bandeja().subscribe({
      next: (resumen) => {
        this.resumen = resumen;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargando = false;
        if (!silencioso) {
          this.toast.error("No se pudo cargar la bandeja de entrada.");
        }
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function Bandeja_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Bandeja)(\u0275\u0275directiveInject(RevisionService), \u0275\u0275directiveInject(AuthRevisionService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Bandeja, selectors: [["app-bandeja"]], decls: 8, vars: 1, consts: [[1, "page-header"], [1, "page-header-subtitulo"], [1, "cargando"], [1, "tarjetas"], [1, "card", "tarjeta"], [1, "tarjeta-encabezado"], [1, "icono-acento", "ambar"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["x", "2", "y", "4", "width", "20", "height", "16", "rx", "2"], ["points", "22 6 12 13 2 6"], [1, "dato-numero"], [1, "icono-acento", "azul"], ["cx", "12", "cy", "12", "r", "10"], ["points", "12 6 12 12 16 14"], [1, "icono-acento", "verde"], ["d", "M22 11.08V12a10 10 0 1 1-5.93-9.14"], ["points", "22 4 12 14.01 9 11.01"], [1, "card", "tabla-contenedor"], [1, "estado-vacio"], [1, "tabla-admin"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "1.5", "stroke-linecap", "round", "stroke-linejoin", "round", 1, "estado-vacio-icono"], [3, "fila-bloqueada"], ["title", "Documentaci\xF3n aparente completa", 1, "indicador", "verde"], ["title", "Podr\xEDa faltar documentaci\xF3n", 1, "indicador", "rojo"], [1, "badge-estatus", "en-revision", 3, "title"], [1, "badge-estatus", "pendiente"], ["type", "button", "disabled", "", 1, "btn-primary", "boton-validar", 3, "title"], [1, "btn-primary", "boton-validar", 3, "routerLink"]], template: function Bandeja_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "div")(2, "h2");
      \u0275\u0275text(3, "Bandeja de Entrada");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(4, "p", 1);
      \u0275\u0275text(5, "Quejas pendientes de validar y turnar.");
      \u0275\u0275elementEnd()()();
      \u0275\u0275conditionalCreate(6, Bandeja_Conditional_6_Template, 2, 0, "p", 2)(7, Bandeja_Conditional_7_Template, 36, 4);
    }
    if (rf & 2) {
      \u0275\u0275advance(6);
      \u0275\u0275conditional(ctx.cargando ? 6 : ctx.resumen ? 7 : -1);
    }
  }, dependencies: [CommonModule, RouterLink, DatePipe], styles: ['@charset "UTF-8";\n\n\n.cargando[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.tarjetas[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 20px;\n  margin-bottom: 24px;\n}\n@media (max-width: 800px) {\n  .tarjetas[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n}\n.tarjeta-encabezado[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  margin-bottom: 10px;\n}\n.tarjeta-encabezado[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 0.95rem;\n}\n.tarjeta[_ngcontent-%COMP%]   .dato-numero[_ngcontent-%COMP%] {\n  font-size: 2.1rem;\n  font-weight: 700;\n  color: var(--negro-inst);\n  margin: 0;\n  line-height: 1.1;\n}\n.tabla-contenedor[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin-bottom: 14px;\n}\n.indicador[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  border-radius: 50%;\n  font-size: 0.75rem;\n  font-weight: 700;\n  color: #fff;\n}\n.indicador.verde[_ngcontent-%COMP%] {\n  background: var(--exito);\n}\n.indicador.rojo[_ngcontent-%COMP%] {\n  background: var(--peligro);\n}\n.boton-validar[_ngcontent-%COMP%] {\n  display: inline-block;\n  text-decoration: none;\n  padding: 7px 16px;\n  font-size: 0.85rem;\n}\n.boton-validar[_ngcontent-%COMP%]:disabled {\n  cursor: not-allowed;\n  opacity: 0.55;\n}\n.badge-estatus[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  padding: 4px 10px;\n  border-radius: 999px;\n  font-size: 0.78rem;\n  font-weight: 600;\n  white-space: nowrap;\n}\n.badge-estatus.pendiente[_ngcontent-%COMP%] {\n  background: var(--acento-ambar-suave);\n  color: var(--acento-ambar);\n}\n.badge-estatus.en-revision[_ngcontent-%COMP%] {\n  background: var(--acento-azul-suave);\n  color: var(--acento-azul);\n}\n.fila-bloqueada[_ngcontent-%COMP%] {\n  background: rgba(0, 0, 0, 0.02);\n}\n.fila-bloqueada[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n/*# sourceMappingURL=bandeja.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Bandeja, [{
    type: Component,
    args: [{ selector: "app-bandeja", standalone: true, imports: [CommonModule, RouterLink], template: `<div class="page-header">
  <div>
    <h2>Bandeja de Entrada</h2>
    <p class="page-header-subtitulo">Quejas pendientes de validar y turnar.</p>
  </div>
</div>

@if (cargando) {
  <p class="cargando">Cargando bandeja\u2026</p>
} @else if (resumen) {
  <div class="tarjetas">
    <div class="card tarjeta">
      <div class="tarjeta-encabezado">
        <span class="icono-acento ambar">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"></rect><polyline points="22 6 12 13 2 6"></polyline></svg>
        </span>
        <h3>Pendientes</h3>
      </div>
      <p class="dato-numero">{{ resumen.pendientes }}</p>
    </div>

    <div class="card tarjeta">
      <div class="tarjeta-encabezado">
        <span class="icono-acento azul">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
        </span>
        <h3>En Proceso</h3>
      </div>
      <p class="dato-numero">{{ resumen.enProceso }}</p>
    </div>

    <div class="card tarjeta">
      <div class="tarjeta-encabezado">
        <span class="icono-acento verde">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
        </span>
        <h3>Turnadas hoy</h3>
      </div>
      <p class="dato-numero">{{ resumen.turnadasHoy }}</p>
    </div>
  </div>

  <div class="card tabla-contenedor">
    <h3>Panel de Gesti\xF3n de Recepci\xF3n</h3>

    @if (resumen.lista.length === 0) {
      <div class="estado-vacio">
        <svg class="estado-vacio-icono" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"></rect><polyline points="22 6 12 13 2 6"></polyline></svg>
        <p>No hay quejas pendientes por trabajar.</p>
      </div>
    } @else {
      <table class="tabla-admin">
        <thead>
          <tr>
            <th>Folio</th>
            <th>Fecha</th>
            <th>Quejoso</th>
            <th>Documentaci\xF3n</th>
            <th>Estatus</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          @for (item of resumen.lista; track item.numeroFolio) {
            <tr [class.fila-bloqueada]="bloqueadaPorOtro(item)">
              <td>{{ item.numeroFolio }}</td>
              <td>{{ item.fechaCreacion | date: 'dd/MM/yy' }}</td>
              <td>{{ item.nombreQuejoso }}</td>
              <td>
                @if (item.documentacionAparenteCompleta) {
                  <span class="indicador verde" title="Documentaci\xF3n aparente completa">\u2713</span>
                } @else {
                  <span class="indicador rojo" title="Podr\xEDa faltar documentaci\xF3n">\u2715</span>
                }
              </td>
              <td>
                @if (item.estatus === 'EN_VALIDACION' && item.revisandoPorNombre) {
                  <span class="badge-estatus en-revision" [title]="'En revisi\xF3n por ' + item.revisandoPorNombre">
                    En revisi\xF3n \xB7 {{ item.revisandoPorNombre }}
                  </span>
                } @else {
                  <span class="badge-estatus pendiente">Pendiente</span>
                }
              </td>
              <td>
                @if (bloqueadaPorOtro(item)) {
                  <button
                    type="button"
                    class="btn-primary boton-validar"
                    disabled
                    [title]="'La est\xE1 revisando ' + item.revisandoPorNombre + '. Se libera sola si la deja inactiva.'"
                  >
                    En revisi\xF3n
                  </button>
                } @else {
                  <a [routerLink]="['/validacion', item.numeroFolio]" class="btn-primary boton-validar">
                    {{ esMiRevision(item) ? 'Continuar' : 'Validar' }}
                  </a>
                }
              </td>
            </tr>
          }
        </tbody>
      </table>
    }
  </div>
}
`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/bandeja/bandeja.scss */\n.cargando {\n  color: var(--texto-suave);\n}\n.tarjetas {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 20px;\n  margin-bottom: 24px;\n}\n@media (max-width: 800px) {\n  .tarjetas {\n    grid-template-columns: 1fr;\n  }\n}\n.tarjeta-encabezado {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  margin-bottom: 10px;\n}\n.tarjeta-encabezado h3 {\n  margin: 0;\n  font-size: 0.95rem;\n}\n.tarjeta .dato-numero {\n  font-size: 2.1rem;\n  font-weight: 700;\n  color: var(--negro-inst);\n  margin: 0;\n  line-height: 1.1;\n}\n.tabla-contenedor h3 {\n  margin-bottom: 14px;\n}\n.indicador {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  border-radius: 50%;\n  font-size: 0.75rem;\n  font-weight: 700;\n  color: #fff;\n}\n.indicador.verde {\n  background: var(--exito);\n}\n.indicador.rojo {\n  background: var(--peligro);\n}\n.boton-validar {\n  display: inline-block;\n  text-decoration: none;\n  padding: 7px 16px;\n  font-size: 0.85rem;\n}\n.boton-validar:disabled {\n  cursor: not-allowed;\n  opacity: 0.55;\n}\n.badge-estatus {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  padding: 4px 10px;\n  border-radius: 999px;\n  font-size: 0.78rem;\n  font-weight: 600;\n  white-space: nowrap;\n}\n.badge-estatus.pendiente {\n  background: var(--acento-ambar-suave);\n  color: var(--acento-ambar);\n}\n.badge-estatus.en-revision {\n  background: var(--acento-azul-suave);\n  color: var(--acento-azul);\n}\n.fila-bloqueada {\n  background: rgba(0, 0, 0, 0.02);\n}\n.fila-bloqueada td {\n  color: var(--texto-suave);\n}\n/*# sourceMappingURL=bandeja.css.map */\n'] }]
  }], () => [{ type: RevisionService }, { type: AuthRevisionService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Bandeja, { className: "Bandeja", filePath: "src/app/pages/bandeja/bandeja.ts", lineNumber: 22 });
})();
export {
  Bandeja
};
//# sourceMappingURL=chunk-WPSNG3I3.js.map
