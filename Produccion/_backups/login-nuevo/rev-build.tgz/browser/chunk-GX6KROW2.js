import {
  CheckboxControlValueAccessor,
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel
} from "./chunk-BJ6JQKEH.js";
import {
  RevisionService
} from "./chunk-6BWVIYFH.js";
import {
  ActivatedRoute,
  Router
} from "./chunk-F26HINUV.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-FT7UGDQZ.js";

// src/app/pages/rechazo/rechazo.ts
var _forTrack0 = ($index, $item) => $item.texto;
function Rechazo_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 1);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2("Folio: ", ctx_r0.folio, " | Quejoso: ", ctx_r0.queja.nombreCompletoQuejoso);
  }
}
function Rechazo_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 2);
    \u0275\u0275text(1, "Cargando\u2026");
    \u0275\u0275elementEnd();
  }
}
function Rechazo_Conditional_6_For_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "li")(1, "label", 11)(2, "input", 12);
    \u0275\u0275twoWayListener("ngModelChange", function Rechazo_Conditional_6_For_5_Template_input_ngModelChange_2_listener($event) {
      const motivo_r4 = \u0275\u0275restoreView(_r3).$implicit;
      \u0275\u0275twoWayBindingSet(motivo_r4.marcado, $event) || (motivo_r4.marcado = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const motivo_r4 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275twoWayProperty("ngModel", motivo_r4.marcado);
    \u0275\u0275property("name", motivo_r4.texto);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", motivo_r4.texto, " ");
  }
}
function Rechazo_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 3)(1, "h3");
    \u0275\u0275text(2, "Seleccione los motivos detectados en la validaci\xF3n:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "ul", 4);
    \u0275\u0275repeaterCreate(4, Rechazo_Conditional_6_For_5_Template, 4, 3, "li", null, _forTrack0);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "div", 5)(7, "label");
    \u0275\u0275text(8, "Observaciones adicionales y sugerencias para el quejoso:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "textarea", 6);
    \u0275\u0275twoWayListener("ngModelChange", function Rechazo_Conditional_6_Template_textarea_ngModelChange_9_listener($event) {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.observaciones, $event) || (ctx_r0.observaciones = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "p", 7);
    \u0275\u0275text(11, " Se enviar\xE1 un correo autom\xE1tico a ");
    \u0275\u0275elementStart(12, "strong");
    \u0275\u0275text(13);
    \u0275\u0275elementEnd();
    \u0275\u0275text(14, " con el texto legal de rechazo y tus observaciones. ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "div", 8)(16, "button", 9);
    \u0275\u0275listener("click", function Rechazo_Conditional_6_Template_button_click_16_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.regresar());
    });
    \u0275\u0275text(17, "Regresar a Validaci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "button", 10);
    \u0275\u0275listener("click", function Rechazo_Conditional_6_Template_button_click_18_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.confirmarRechazo());
    });
    \u0275\u0275text(19);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275repeater(ctx_r0.motivos);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.observaciones);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r0.queja.correoInstitucional);
    \u0275\u0275advance(5);
    \u0275\u0275property("disabled", ctx_r0.enviando);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r0.enviando ? "Enviando\u2026" : "Confirmar y Enviar Rechazo", " ");
  }
}
var Rechazo = class _Rechazo {
  route;
  router;
  revisionService;
  toast;
  cdr;
  folio = "";
  queja = null;
  cargando = true;
  enviando = false;
  observaciones = "";
  motivos = [
    { texto: "Documentaci\xF3n ilegible o incompleta.", marcado: false },
    { texto: "Falta de pruebas m\xEDnimas requeridas.", marcado: false },
    { texto: "El asunto no es competencia de esta Defensor\xEDa.", marcado: false },
    { texto: "Datos de contacto err\xF3neos.", marcado: false }
  ];
  constructor(route, router, revisionService, toast, cdr) {
    this.route = route;
    this.router = router;
    this.revisionService = revisionService;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.folio = this.route.snapshot.paramMap.get("folio") ?? "";
    this.cargar();
  }
  regresar() {
    this.router.navigate(["/validacion", this.folio]);
  }
  confirmarRechazo() {
    const motivosMarcados = this.motivos.filter((m) => m.marcado).map((m) => m.texto);
    if (motivosMarcados.length === 0 && !this.observaciones.trim()) {
      this.toast.advertencia("Selecciona al menos un motivo o escribe una observaci\xF3n.");
      return;
    }
    this.enviando = true;
    this.revisionService.rechazar(this.folio, {
      motivos: motivosMarcados,
      observaciones: this.observaciones
    }).subscribe({
      next: () => {
        this.enviando = false;
        this.toast.exito("Rechazo enviado. Se notific\xF3 al quejoso por correo.");
        this.router.navigate(["/"]);
      },
      error: (err) => {
        this.enviando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo enviar el rechazo.");
        this.cdr.detectChanges();
      }
    });
  }
  cargar() {
    this.cargando = true;
    this.revisionService.detalle(this.folio).subscribe({
      next: (queja) => {
        this.queja = queja;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.cargando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo cargar la queja.");
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function Rechazo_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Rechazo)(\u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(RevisionService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Rechazo, selectors: [["app-rechazo"]], decls: 7, vars: 2, consts: [[1, "page-header"], [1, "page-header-subtitulo"], [1, "cargando"], [1, "card"], [1, "checklist"], [1, "input-group"], ["rows", "5", "name", "observaciones", "placeholder", "Escriba aqu\xED detalladamente qu\xE9 debe corregir el usuario para poder reingresar su queja\u2026", 3, "ngModelChange", "ngModel"], [1, "aviso-inline"], [1, "modal-acciones", "acciones-rechazo"], [1, "btn-secondary", 3, "click"], [1, "btn-peligro", 3, "click", "disabled"], [1, "check-linea"], ["type", "checkbox", 3, "ngModelChange", "ngModel", "name"]], template: function Rechazo_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "div")(2, "h2");
      \u0275\u0275text(3, "Emisi\xF3n de Notificaci\xF3n de Rechazo");
      \u0275\u0275elementEnd();
      \u0275\u0275conditionalCreate(4, Rechazo_Conditional_4_Template, 2, 2, "p", 1);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(5, Rechazo_Conditional_5_Template, 2, 0, "p", 2)(6, Rechazo_Conditional_6_Template, 20, 4, "div", 3);
    }
    if (rf & 2) {
      \u0275\u0275advance(4);
      \u0275\u0275conditional(ctx.queja ? 4 : -1);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.cargando ? 5 : ctx.queja ? 6 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, DefaultValueAccessor, CheckboxControlValueAccessor, NgControlStatus, NgModel], styles: ["\n.cargando[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.check-linea[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  cursor: pointer;\n  width: 100%;\n}\n.acciones-rechazo[_ngcontent-%COMP%] {\n  margin-top: 0;\n}\n/*# sourceMappingURL=rechazo.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Rechazo, [{
    type: Component,
    args: [{ selector: "app-rechazo", standalone: true, imports: [CommonModule, FormsModule], template: `<div class="page-header">
  <div>
    <h2>Emisi\xF3n de Notificaci\xF3n de Rechazo</h2>
    @if (queja) {
      <p class="page-header-subtitulo">Folio: {{ folio }} | Quejoso: {{ queja.nombreCompletoQuejoso }}</p>
    }
  </div>
</div>

@if (cargando) {
  <p class="cargando">Cargando\u2026</p>
} @else if (queja) {
  <div class="card">
    <h3>Seleccione los motivos detectados en la validaci\xF3n:</h3>
    <ul class="checklist">
      @for (motivo of motivos; track motivo.texto) {
        <li>
          <label class="check-linea">
            <input type="checkbox" [(ngModel)]="motivo.marcado" [name]="motivo.texto" />
            {{ motivo.texto }}
          </label>
        </li>
      }
    </ul>

    <div class="input-group">
      <label>Observaciones adicionales y sugerencias para el quejoso:</label>
      <textarea
        rows="5"
        [(ngModel)]="observaciones"
        name="observaciones"
        placeholder="Escriba aqu\xED detalladamente qu\xE9 debe corregir el usuario para poder reingresar su queja\u2026"
      ></textarea>
    </div>

    <p class="aviso-inline">
      Se enviar\xE1 un correo autom\xE1tico a <strong>{{ queja.correoInstitucional }}</strong> con el texto
      legal de rechazo y tus observaciones.
    </p>

    <div class="modal-acciones acciones-rechazo">
      <button class="btn-secondary" (click)="regresar()">Regresar a Validaci\xF3n</button>
      <button class="btn-peligro" (click)="confirmarRechazo()" [disabled]="enviando">
        {{ enviando ? 'Enviando\u2026' : 'Confirmar y Enviar Rechazo' }}
      </button>
    </div>
  </div>
}
`, styles: ["/* src/app/pages/rechazo/rechazo.scss */\n.cargando {\n  color: var(--texto-suave);\n}\n.check-linea {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  cursor: pointer;\n  width: 100%;\n}\n.acciones-rechazo {\n  margin-top: 0;\n}\n/*# sourceMappingURL=rechazo.css.map */\n"] }]
  }], () => [{ type: ActivatedRoute }, { type: Router }, { type: RevisionService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Rechazo, { className: "Rechazo", filePath: "src/app/pages/rechazo/rechazo.ts", lineNumber: 22 });
})();
export {
  Rechazo
};
//# sourceMappingURL=chunk-GX6KROW2.js.map
