import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel,
  NgSelectOption,
  SelectControlValueAccessor,
  ɵNgSelectMultipleOption
} from "./chunk-BJ6JQKEH.js";
import {
  RevisionService
} from "./chunk-6BWVIYFH.js";
import {
  ActivatedRoute,
  Router
} from "./chunk-F26HINUV.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  DatePipe,
  ToastService,
  forkJoin,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-FT7UGDQZ.js";

// src/app/pages/turnado/turnado.ts
var _forTrack0 = ($index, $item) => $item.id;
var _forTrack1 = ($index, $item) => $item.numeroFolio;
function Turnado_Conditional_4_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275textInterpolate1(" | Boleta/Empleado: ", ctx_r0.queja.numeroIdentificacionQuejoso, " ");
  }
}
function Turnado_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 1);
    \u0275\u0275text(1);
    \u0275\u0275conditionalCreate(2, Turnado_Conditional_4_Conditional_2_Template, 1, 1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" C. ", ctx_r0.queja.nombreCompletoQuejoso, " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.queja.numeroIdentificacionQuejoso ? 2 : -1);
  }
}
function Turnado_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 2);
    \u0275\u0275text(1, "Cargando\u2026");
    \u0275\u0275elementEnd();
  }
}
function Turnado_Conditional_6_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 4);
    \u0275\u0275text(1, "No se encontraron quejas previas de esta persona.");
    \u0275\u0275elementEnd();
  }
}
function Turnado_Conditional_6_Conditional_4_For_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td");
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "date");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "td");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "td");
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const a_r3 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r3.numeroFolio);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(5, 4, a_r3.fecha, "dd/MM/yy"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(a_r3.asunto);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r3.estadoActual);
  }
}
function Turnado_Conditional_6_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "table", 16)(1, "thead")(2, "tr")(3, "th");
    \u0275\u0275text(4, "Folio");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "th");
    \u0275\u0275text(6, "Fecha");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "th");
    \u0275\u0275text(8, "Asunto");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "th");
    \u0275\u0275text(10, "Estado Actual");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(11, "tbody");
    \u0275\u0275repeaterCreate(12, Turnado_Conditional_6_Conditional_4_For_13_Template, 10, 7, "tr", null, _forTrack1);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "p", 17);
    \u0275\u0275text(15);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(12);
    \u0275\u0275repeater(ctx_r0.antecedentes);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" Se encontraron ", ctx_r0.antecedentes.length, " antecedente(s) relacionado(s). Verifica si existe duplicidad antes de turnar. ");
  }
}
function Turnado_Conditional_6_For_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 10);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const defensor_r4 = ctx.$implicit;
    \u0275\u0275property("value", defensor_r4.nombreCompleto);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(defensor_r4.nombreCompleto);
  }
}
function Turnado_Conditional_6_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 11);
    \u0275\u0275text(1, " Todav\xEDa no hay personal con rol Defensor/Subdefensor dado de alta en Usuarios y Roles. ");
    \u0275\u0275elementEnd();
  }
}
function Turnado_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 3)(1, "h3");
    \u0275\u0275text(2, "Historial del Usuario en el Sistema");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(3, Turnado_Conditional_6_Conditional_3_Template, 2, 0, "p", 4)(4, Turnado_Conditional_6_Conditional_4_Template, 16, 1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 5)(6, "h3");
    \u0275\u0275text(7, "Canalizaci\xF3n del Expediente");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p", 6);
    \u0275\u0275text(9, "Esta queja se canalizar\xE1 a ");
    \u0275\u0275elementStart(10, "strong");
    \u0275\u0275text(11, "Primer Contacto");
    \u0275\u0275elementEnd();
    \u0275\u0275text(12, " para su an\xE1lisis.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "div", 7)(14, "label");
    \u0275\u0275text(15, "Defensor / Abogado Responsable:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "select", 8);
    \u0275\u0275twoWayListener("ngModelChange", function Turnado_Conditional_6_Template_select_ngModelChange_16_listener($event) {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.defensorAsignado, $event) || (ctx_r0.defensorAsignado = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementStart(17, "option", 9);
    \u0275\u0275text(18, "Seleccione un responsable");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(19, Turnado_Conditional_6_For_20_Template, 2, 2, "option", 10, _forTrack0);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(21, Turnado_Conditional_6_Conditional_21_Template, 2, 0, "span", 11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "div", 7)(23, "label");
    \u0275\u0275text(24, "Comentarios de Recepci\xF3n:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "textarea", 12);
    \u0275\u0275twoWayListener("ngModelChange", function Turnado_Conditional_6_Template_textarea_ngModelChange_25_listener($event) {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.comentarios, $event) || (ctx_r0.comentarios = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(26, "div", 13)(27, "button", 14);
    \u0275\u0275listener("click", function Turnado_Conditional_6_Template_button_click_27_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.turnar());
    });
    \u0275\u0275text(28);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "button", 15);
    \u0275\u0275listener("click", function Turnado_Conditional_6_Template_button_click_29_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.pausar());
    });
    \u0275\u0275text(30, "Pausar / Guardar Avance");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r0.antecedentes.length === 0 ? 3 : 4);
    \u0275\u0275advance(13);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.defensorAsignado);
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r0.defensores);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r0.defensores.length === 0 ? 21 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.comentarios);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r0.turnando);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r0.turnando ? "Turnando\u2026" : "\u2B06 Generar Folio Oficial y Turnar", " ");
  }
}
var Turnado = class _Turnado {
  route;
  router;
  revisionService;
  toast;
  cdr;
  folio = "";
  queja = null;
  antecedentes = [];
  defensores = [];
  cargando = true;
  turnando = false;
  defensorAsignado = "";
  comentarios = "";
  constructor(route, router, revisionService, toast, cdr) {
    this.route = route;
    this.router = router;
    this.revisionService = revisionService;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.folio = this.route.snapshot.paramMap.get("folio") ?? "";
    this.cargar();
  }
  cargar() {
    this.cargando = true;
    forkJoin({
      queja: this.revisionService.detalle(this.folio),
      antecedentes: this.revisionService.antecedentes(this.folio),
      defensores: this.revisionService.defensores()
    }).subscribe({
      next: ({ queja, antecedentes, defensores }) => {
        this.queja = queja;
        this.antecedentes = antecedentes;
        this.defensores = defensores;
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.cargando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo cargar la informaci\xF3n de turnado.");
        this.cdr.detectChanges();
      }
    });
  }
  pausar() {
    this.toast.info('Avance guardado. La queja sigue "En Proceso".');
    this.router.navigate(["/"]);
  }
  turnar() {
    if (!this.defensorAsignado) {
      this.toast.advertencia("Selecciona el defensor responsable.");
      return;
    }
    this.turnando = true;
    this.revisionService.turnar(this.folio, {
      defensorAsignado: this.defensorAsignado,
      comentarios: this.comentarios
    }).subscribe({
      next: () => {
        this.turnando = false;
        this.toast.exito("Queja turnada correctamente.");
        this.router.navigate(["/"]);
      },
      error: (err) => {
        this.turnando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo turnar la queja.");
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function Turnado_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Turnado)(\u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(RevisionService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Turnado, selectors: [["app-turnado"]], decls: 7, vars: 2, consts: [[1, "page-header"], [1, "page-header-subtitulo"], [1, "cargando"], [1, "card"], [1, "sin-antecedentes"], [1, "card", "canalizacion-card"], [1, "aviso-inline"], [1, "input-group"], ["name", "defensorAsignado", 3, "ngModelChange", "ngModel"], ["value", "", "disabled", "", "selected", ""], [3, "value"], [1, "mensaje-campo", "aviso-sin-datos"], ["rows", "4", "name", "comentarios", "placeholder", "Escriba aqu\xED una nota breve para el abogado\u2026", 3, "ngModelChange", "ngModel"], [1, "modal-acciones", "acciones-turnado"], [1, "btn-primary", 3, "click", "disabled"], [1, "btn-secondary", 3, "click"], [1, "tabla-admin"], [1, "aviso-peligro"]], template: function Turnado_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "div")(2, "h2");
      \u0275\u0275text(3, "B\xFAsqueda de Antecedentes y Turnado");
      \u0275\u0275elementEnd();
      \u0275\u0275conditionalCreate(4, Turnado_Conditional_4_Template, 3, 2, "p", 1);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(5, Turnado_Conditional_5_Template, 2, 0, "p", 2)(6, Turnado_Conditional_6_Template, 31, 6);
    }
    if (rf & 2) {
      \u0275\u0275advance(4);
      \u0275\u0275conditional(ctx.queja ? 4 : -1);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.cargando ? 5 : ctx.queja ? 6 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, NgSelectOption, \u0275NgSelectMultipleOption, DefaultValueAccessor, SelectControlValueAccessor, NgControlStatus, NgModel, DatePipe], styles: ["\n.cargando[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.sin-antecedentes[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-size: 0.88rem;\n}\n.aviso-advertencia[_ngcontent-%COMP%] {\n  margin-top: 14px;\n  margin-bottom: 0;\n}\n.canalizacion-card[_ngcontent-%COMP%] {\n  margin-top: 20px;\n}\n.aviso-sin-datos[_ngcontent-%COMP%] {\n  color: var(--advertencia);\n}\n.acciones-turnado[_ngcontent-%COMP%] {\n  margin-top: 4px;\n}\n/*# sourceMappingURL=turnado.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Turnado, [{
    type: Component,
    args: [{ selector: "app-turnado", standalone: true, imports: [CommonModule, FormsModule], template: `<div class="page-header">
  <div>
    <h2>B\xFAsqueda de Antecedentes y Turnado</h2>
    @if (queja) {
      <p class="page-header-subtitulo">
        C. {{ queja.nombreCompletoQuejoso }}
        @if (queja.numeroIdentificacionQuejoso) { | Boleta/Empleado: {{ queja.numeroIdentificacionQuejoso }} }
      </p>
    }
  </div>
</div>

@if (cargando) {
  <p class="cargando">Cargando\u2026</p>
} @else if (queja) {
  <div class="card">
    <h3>Historial del Usuario en el Sistema</h3>

    @if (antecedentes.length === 0) {
      <p class="sin-antecedentes">No se encontraron quejas previas de esta persona.</p>
    } @else {
      <table class="tabla-admin">
        <thead>
          <tr>
            <th>Folio</th>
            <th>Fecha</th>
            <th>Asunto</th>
            <th>Estado Actual</th>
          </tr>
        </thead>
        <tbody>
          @for (a of antecedentes; track a.numeroFolio) {
            <tr>
              <td>{{ a.numeroFolio }}</td>
              <td>{{ a.fecha | date: 'dd/MM/yy' }}</td>
              <td>{{ a.asunto }}</td>
              <td>{{ a.estadoActual }}</td>
            </tr>
          }
        </tbody>
      </table>

      <p class="aviso-peligro">
        Se encontraron {{ antecedentes.length }} antecedente(s) relacionado(s). Verifica si existe
        duplicidad antes de turnar.
      </p>
    }
  </div>

  <div class="card canalizacion-card">
    <h3>Canalizaci\xF3n del Expediente</h3>

    <p class="aviso-inline">Esta queja se canalizar\xE1 a <strong>Primer Contacto</strong> para su an\xE1lisis.</p>

    <div class="input-group">
      <label>Defensor / Abogado Responsable:</label>
      <select [(ngModel)]="defensorAsignado" name="defensorAsignado">
        <option value="" disabled selected>Seleccione un responsable</option>
        @for (defensor of defensores; track defensor.id) {
          <option [value]="defensor.nombreCompleto">{{ defensor.nombreCompleto }}</option>
        }
      </select>
      @if (defensores.length === 0) {
        <span class="mensaje-campo aviso-sin-datos">
          Todav\xEDa no hay personal con rol Defensor/Subdefensor dado de alta en Usuarios y Roles.
        </span>
      }
    </div>

    <div class="input-group">
      <label>Comentarios de Recepci\xF3n:</label>
      <textarea rows="4" [(ngModel)]="comentarios" name="comentarios" placeholder="Escriba aqu\xED una nota breve para el abogado\u2026"></textarea>
    </div>

    <div class="modal-acciones acciones-turnado">
      <button class="btn-primary" (click)="turnar()" [disabled]="turnando">
        {{ turnando ? 'Turnando\u2026' : '\u2B06 Generar Folio Oficial y Turnar' }}
      </button>
      <button class="btn-secondary" (click)="pausar()">Pausar / Guardar Avance</button>
    </div>
  </div>
}
`, styles: ["/* src/app/pages/turnado/turnado.scss */\n.cargando {\n  color: var(--texto-suave);\n}\n.sin-antecedentes {\n  color: var(--texto-suave);\n  font-size: 0.88rem;\n}\n.aviso-advertencia {\n  margin-top: 14px;\n  margin-bottom: 0;\n}\n.canalizacion-card {\n  margin-top: 20px;\n}\n.aviso-sin-datos {\n  color: var(--advertencia);\n}\n.acciones-turnado {\n  margin-top: 4px;\n}\n/*# sourceMappingURL=turnado.css.map */\n"] }]
  }], () => [{ type: ActivatedRoute }, { type: Router }, { type: RevisionService }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Turnado, { className: "Turnado", filePath: "src/app/pages/turnado/turnado.ts", lineNumber: 18 });
})();
export {
  Turnado
};
//# sourceMappingURL=chunk-EAX4QVK7.js.map
