import {
  HttpClient,
  Injectable,
  setClassMetadata,
  ɵɵdefineInjectable,
  ɵɵinject
} from "./chunk-FT7UGDQZ.js";

// src/app/core/services/revision.service.ts
var RevisionService = class _RevisionService {
  http;
  apiUrl = "/api/revision";
  constructor(http) {
    this.http = http;
  }
  bandeja() {
    return this.http.get(`${this.apiUrl}/bandeja`);
  }
  detalle(folio) {
    return this.http.get(`${this.apiUrl}/quejas/${folio}`);
  }
  antecedentes(folio) {
    return this.http.get(`${this.apiUrl}/quejas/${folio}/antecedentes`);
  }
  urlEvidencia(id) {
    return `${this.apiUrl}/quejas/evidencias/${id}`;
  }
  /** El endpoint exige JWT, así que un <a href> normal no sirve (el navegador no manda el
   * Authorization header en una navegación directa) -- se descarga como blob y se abre. */
  descargarEvidencia(id) {
    return this.http.get(this.urlEvidencia(id), { responseType: "blob" });
  }
  rechazar(folio, datos) {
    return this.http.post(`${this.apiUrl}/quejas/${folio}/rechazar`, datos);
  }
  turnar(folio, datos) {
    return this.http.post(`${this.apiUrl}/quejas/${folio}/turnar`, datos);
  }
  areas() {
    return this.http.get(`${this.apiUrl}/catalogos/areas`);
  }
  defensores() {
    return this.http.get(`${this.apiUrl}/catalogos/defensores`);
  }
  identificacionesOficiales() {
    return this.http.get(`${this.apiUrl}/catalogos/identificaciones-oficiales`);
  }
  registrarManual(formData) {
    return this.http.post(`${this.apiUrl}/registro-manual`, formData);
  }
  static \u0275fac = function RevisionService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _RevisionService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _RevisionService, factory: _RevisionService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RevisionService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

export {
  RevisionService
};
//# sourceMappingURL=chunk-6BWVIYFH.js.map
