import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel,
  NgSelectOption,
  SelectControlValueAccessor,
  ɵNgSelectMultipleOption
} from "./chunk-BJ6JQKEH.js";
import {
  RevisionService
} from "./chunk-6BWVIYFH.js";
import {
  ActivatedRoute,
  DomSanitizer,
  Router,
  RouterLink
} from "./chunk-F26HINUV.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  NgTemplateOutlet,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassMap,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainer,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵreference,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtemplateRefExtractor,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtextInterpolate3,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-FT7UGDQZ.js";

// src/app/pages/validacion/validacion.ts
var _c0 = () => ({ clave: "nombreCompleto" });
var _c1 = () => ({ clave: "identificacionOficial", obsSiempre: true });
var _c2 = () => ({ clave: "numeroIdentificacion" });
var _c3 = () => ({ clave: "fechaHechos" });
var _c4 = () => ({ clave: "datosDenunciado" });
var _forTrack0 = ($index, $item) => $item.clave;
var _forTrack1 = ($index, $item) => $item.id;
function Validacion_ng_template_8_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 10)(1, "label", 11);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "textarea", 12);
    \u0275\u0275twoWayListener("ngModelChange", function Validacion_ng_template_8_Conditional_5_Template_textarea_ngModelChange_3_listener($event) {
      \u0275\u0275restoreView(_r4);
      const clave_r2 = \u0275\u0275nextContext().clave;
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.r(clave_r2).observacion, $event) || (ctx_r2.r(clave_r2).observacion = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const clave_r2 = \u0275\u0275nextContext().clave;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275classProp("obs-requerida", ctx_r2.r(clave_r2).valor === false);
    \u0275\u0275advance();
    \u0275\u0275property("for", "obs-" + clave_r2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" Observaciones", ctx_r2.r(clave_r2).valor === false ? " para el quejoso (obligatorio)" : " (opcional)", ": ");
    \u0275\u0275advance();
    \u0275\u0275property("id", "obs-" + clave_r2);
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.r(clave_r2).observacion);
    \u0275\u0275property("name", "obs-" + clave_r2);
  }
}
function Validacion_ng_template_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 6)(1, "button", 7);
    \u0275\u0275listener("click", function Validacion_ng_template_8_Template_button_click_1_listener() {
      const clave_r2 = \u0275\u0275restoreView(_r1).clave;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.setRespuesta(clave_r2, true));
    });
    \u0275\u0275text(2, "S\xED");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "button", 8);
    \u0275\u0275listener("click", function Validacion_ng_template_8_Template_button_click_3_listener() {
      const clave_r2 = \u0275\u0275restoreView(_r1).clave;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.setRespuesta(clave_r2, false));
    });
    \u0275\u0275text(4, "No");
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(5, Validacion_ng_template_8_Conditional_5_Template, 4, 7, "div", 9);
  }
  if (rf & 2) {
    const clave_r2 = ctx.clave;
    const obsSiempre_r5 = ctx.obsSiempre;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275classProp("activo", ctx_r2.r(clave_r2).valor === true);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("activo", ctx_r2.r(clave_r2).valor === false);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r2.r(clave_r2).valor === false || obsSiempre_r5 ? 5 : -1);
  }
}
function Validacion_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 4);
    \u0275\u0275text(1, "Cargando queja\u2026");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_11_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 18);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Tel: ", ctx_r2.queja.telefonoContacto);
  }
}
function Validacion_Conditional_11_ng_container_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function Validacion_Conditional_11_Conditional_32_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 30);
    \u0275\u0275text(1, "Cargando listado\u2026");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_11_Conditional_32_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 30);
    \u0275\u0275text(1, "No se pudo cargar el listado oficial.");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_11_Conditional_32_Conditional_3_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const identificacion_r7 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(identificacion_r7.nombre);
  }
}
function Validacion_Conditional_11_Conditional_32_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ul");
    \u0275\u0275repeaterCreate(1, Validacion_Conditional_11_Conditional_32_Conditional_3_For_2_Template, 2, 1, "li", null, _forTrack0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r2.identificaciones);
  }
}
function Validacion_Conditional_11_Conditional_32_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 23);
    \u0275\u0275conditionalCreate(1, Validacion_Conditional_11_Conditional_32_Conditional_1_Template, 2, 0, "span", 30)(2, Validacion_Conditional_11_Conditional_32_Conditional_2_Template, 2, 0, "span", 30)(3, Validacion_Conditional_11_Conditional_32_Conditional_3_Template, 3, 0, "ul");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.cargandoIdentificaciones ? 1 : ctx_r2.identificaciones.length === 0 ? 2 : 3);
  }
}
function Validacion_Conditional_11_Conditional_33_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 24);
    \u0275\u0275text(1, " En caso de ser alumno, la credencial del IPN vigente tambi\xE9n es v\xE1lida; revise que la boleta coincida (pregunta 3). ");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_11_For_41_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "option", 29);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const identificacion_r8 = ctx.$implicit;
    \u0275\u0275property("value", identificacion_r8.clave);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(identificacion_r8.nombre);
  }
}
function Validacion_Conditional_11_ng_container_42_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function Validacion_Conditional_11_Conditional_47_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "strong");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2("", ctx_r2.etiquetaTipoIdentificacion, ": ", ctx_r2.queja.numeroIdentificacionQuejoso);
  }
}
function Validacion_Conditional_11_Conditional_48_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 30);
    \u0275\u0275text(1, "No proporcion\xF3 n\xFAmero de boleta ni de empleado.");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_11_ng_container_49_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function Validacion_Conditional_11_Conditional_54_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 18);
    \u0275\u0275text(1, "Fecha de los hechos: ");
    \u0275\u0275elementStart(2, "strong", 45);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(4, "span", 18);
    \u0275\u0275text(5, "Fecha de registro: ");
    \u0275\u0275elementStart(6, "strong", 45);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "span", 46);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx_r2.formatearFecha(ctx_r2.queja.fechaHechos));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r2.formatearFecha(ctx_r2.queja.fechaCreacion));
    \u0275\u0275advance();
    \u0275\u0275classProp("plazo-ok", ctx_r2.dentroDePlazo)("plazo-vencido", !ctx_r2.dentroDePlazo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate3(" ", ctx_r2.diasDesdeHechos, " ", ctx_r2.diasDesdeHechos === 1 ? "d\xEDa" : "d\xEDas", " transcurridos \u2014 ", ctx_r2.dentroDePlazo ? "dentro del plazo" : "fuera del plazo de " + ctx_r2.plazoDias + " d\xEDas", " ");
  }
}
function Validacion_Conditional_11_Conditional_55_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 30);
    \u0275\u0275text(1, "La queja no tiene fecha de los hechos capturada; verif\xEDquela en el documento.");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_11_ng_container_56_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function Validacion_Conditional_11_Conditional_61_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "strong");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r2.queja.nombreCompletoDenunciado);
  }
}
function Validacion_Conditional_11_Conditional_62_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 30);
    \u0275\u0275text(1, "No captur\xF3 datos del denunciado.");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_11_ng_container_65_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function Validacion_Conditional_11_Conditional_75_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275textInterpolate1(" \xB7 faltan ", ctx_r2.totalRequisitos - ctx_r2.contestadas, " por contestar ");
  }
}
function Validacion_Conditional_11_Conditional_84_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 14);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("", ctx_r2.imagenesCredencial.length, " im\xE1genes adjuntas \u2014 elige cu\xE1l ver en grande.");
  }
}
function Validacion_Conditional_11_Conditional_85_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 48);
    \u0275\u0275text(1, "Cargando\u2026");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_11_Conditional_85_Conditional_5_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 54);
    \u0275\u0275listener("click", function Validacion_Conditional_11_Conditional_85_Conditional_5_For_2_Template_button_click_0_listener() {
      const \u0275$index_254_r11 = \u0275\u0275restoreView(_r10).$index;
      const ctx_r2 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r2.seleccionarCredencial(\u0275$index_254_r11));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const img_r12 = ctx.$implicit;
    const \u0275$index_254_r11 = ctx.$index;
    const ctx_r2 = \u0275\u0275nextContext(4);
    \u0275\u0275classProp("activa", \u0275$index_254_r11 === ctx_r2.indiceCredencial);
    \u0275\u0275property("title", img_r12.nombreArchivo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", \u0275$index_254_r11 + 1, " ");
  }
}
function Validacion_Conditional_11_Conditional_85_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 51);
    \u0275\u0275repeaterCreate(1, Validacion_Conditional_11_Conditional_85_Conditional_5_For_2_Template, 2, 4, "button", 53, _forTrack1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r2.imagenesCredencial);
  }
}
function Validacion_Conditional_11_Conditional_85_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 47);
    \u0275\u0275conditionalCreate(1, Validacion_Conditional_11_Conditional_85_Conditional_1_Template, 2, 0, "div", 48);
    \u0275\u0275element(2, "img", 49);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p", 50);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(5, Validacion_Conditional_11_Conditional_85_Conditional_5_Template, 3, 0, "div", 51);
    \u0275\u0275elementStart(6, "button", 52);
    \u0275\u0275listener("click", function Validacion_Conditional_11_Conditional_85_Template_button_click_6_listener() {
      \u0275\u0275restoreView(_r9);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.verDocumento(ctx_r2.credencialId));
    });
    \u0275\u0275text(7, "Abrir en tama\xF1o real");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.cargandoCredencial ? 1 : -1);
    \u0275\u0275advance();
    \u0275\u0275property("src", ctx_r2.credencialUrl, \u0275\u0275sanitizeUrl)("alt", ctx_r2.credencialNombre);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r2.credencialNombre);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.imagenesCredencial.length > 1 ? 5 : -1);
  }
}
function Validacion_Conditional_11_Conditional_86_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 4);
    \u0275\u0275text(1, "Cargando identificaci\xF3n\u2026");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_11_Conditional_87_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 42)(1, "p");
    \u0275\u0275text(2, "No se adjunt\xF3 una imagen de identificaci\xF3n.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p", 18);
    \u0275\u0275text(4, "Si el quejoso subi\xF3 un PDF, \xE1brelo desde la lista de evidencias.");
    \u0275\u0275elementEnd()();
  }
}
function Validacion_Conditional_11_Conditional_91_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 30);
    \u0275\u0275text(1, "No se adjuntaron documentos.");
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_11_Conditional_92_For_2_Case_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(0, "svg", 56);
    \u0275\u0275element(1, "rect", 60)(2, "circle", 61)(3, "polyline", 62);
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_11_Conditional_92_For_2_Case_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(0, "svg", 56);
    \u0275\u0275element(1, "path", 63)(2, "polyline", 64);
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_11_Conditional_92_For_2_Case_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(0, "svg", 56);
    \u0275\u0275element(1, "path", 65)(2, "polyline", 66);
    \u0275\u0275elementEnd();
  }
}
function Validacion_Conditional_11_Conditional_92_For_2_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 18);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ev_r14 = \u0275\u0275nextContext().$implicit;
    const ctx_r2 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r2.formatearTamanio(ev_r14.tamanioBytes));
  }
}
function Validacion_Conditional_11_Conditional_92_For_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "li")(1, "span", 55);
    \u0275\u0275conditionalCreate(2, Validacion_Conditional_11_Conditional_92_For_2_Case_2_Template, 4, 0, ":svg:svg", 56)(3, Validacion_Conditional_11_Conditional_92_For_2_Case_3_Template, 3, 0, ":svg:svg", 56)(4, Validacion_Conditional_11_Conditional_92_For_2_Case_4_Template, 3, 0, ":svg:svg", 56);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 57)(6, "span", 58);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(8, Validacion_Conditional_11_Conditional_92_For_2_Conditional_8_Template, 2, 1, "span", 18);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "button", 59);
    \u0275\u0275listener("click", function Validacion_Conditional_11_Conditional_92_For_2_Template_button_click_9_listener() {
      const ev_r14 = \u0275\u0275restoreView(_r13).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r2.verDocumento(ev_r14.id));
    });
    \u0275\u0275text(10, "Ver");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    let tmp_14_0;
    const ev_r14 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275classMap(ctx_r2.tipoIcono(ev_r14));
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_14_0 = ctx_r2.tipoIcono(ev_r14)) === "imagen" ? 2 : tmp_14_0 === "pdf" ? 3 : 4);
    \u0275\u0275advance(4);
    \u0275\u0275property("title", ev_r14.nombreArchivo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ev_r14.nombreArchivo);
    \u0275\u0275advance();
    \u0275\u0275conditional(ev_r14.tamanioBytes ? 8 : -1);
  }
}
function Validacion_Conditional_11_Conditional_92_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ul", 44);
    \u0275\u0275repeaterCreate(1, Validacion_Conditional_11_Conditional_92_For_2_Template, 11, 6, "li", null, _forTrack1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r2.queja.evidencias);
  }
}
function Validacion_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 5)(1, "div", 13)(2, "h3");
    \u0275\u0275text(3, "Revisi\xF3n del Quejoso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 14);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "ol", 15)(7, "li")(8, "p", 16);
    \u0275\u0275text(9, "\xBFEl quejoso proporcion\xF3 su nombre completo (nombre y apellidos*)?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "div", 17)(11, "strong");
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span", 18);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(15, Validacion_Conditional_11_Conditional_15_Template, 2, 1, "span", 18);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "p", 19);
    \u0275\u0275text(17, "* Recuerde que hay personas que solo tienen un apellido.");
    \u0275\u0275elementEnd();
    \u0275\u0275template(18, Validacion_Conditional_11_ng_container_18_Template, 1, 0, "ng-container", 20);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "li")(20, "p", 21);
    \u0275\u0275text(21, " Verifique que la identificaci\xF3n presentada sea ");
    \u0275\u0275elementStart(22, "strong");
    \u0275\u0275text(23, "legible, oficial, vigente");
    \u0275\u0275elementEnd();
    \u0275\u0275text(24, " y ");
    \u0275\u0275elementStart(25, "strong");
    \u0275\u0275text(26, "coincida con el nombre proporcionado");
    \u0275\u0275elementEnd();
    \u0275\u0275text(27, ". ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(28, "p", 16);
    \u0275\u0275text(29, " \xBFEl quejoso present\xF3 una identificaci\xF3n oficial v\xE1lida y vigente de acuerdo al art\xEDculo 48? ");
    \u0275\u0275elementStart(30, "button", 22);
    \u0275\u0275listener("click", function Validacion_Conditional_11_Template_button_click_30_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.alternarListadoOficial());
    });
    \u0275\u0275text(31);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(32, Validacion_Conditional_11_Conditional_32_Template, 4, 1, "div", 23);
    \u0275\u0275conditionalCreate(33, Validacion_Conditional_11_Conditional_33_Template, 2, 0, "p", 24);
    \u0275\u0275elementStart(34, "div", 25)(35, "label", 26);
    \u0275\u0275text(36, "Identificaci\xF3n que present\xF3:");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "select", 27);
    \u0275\u0275twoWayListener("ngModelChange", function Validacion_Conditional_11_Template_select_ngModelChange_37_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.tipoIdentificacionPresentada, $event) || (ctx_r2.tipoIdentificacionPresentada = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementStart(38, "option", 28);
    \u0275\u0275text(39, "Seleccione el tipo de identificaci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(40, Validacion_Conditional_11_For_41_Template, 2, 2, "option", 29, _forTrack0);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(42, Validacion_Conditional_11_ng_container_42_Template, 1, 0, "ng-container", 20);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(43, "li")(44, "p", 16);
    \u0275\u0275text(45);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "div", 17);
    \u0275\u0275conditionalCreate(47, Validacion_Conditional_11_Conditional_47_Template, 2, 2, "strong")(48, Validacion_Conditional_11_Conditional_48_Template, 2, 0, "span", 30);
    \u0275\u0275elementEnd();
    \u0275\u0275template(49, Validacion_Conditional_11_ng_container_49_Template, 1, 0, "ng-container", 20);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(50, "li")(51, "p", 16);
    \u0275\u0275text(52);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(53, "div", 17);
    \u0275\u0275conditionalCreate(54, Validacion_Conditional_11_Conditional_54_Template, 10, 9)(55, Validacion_Conditional_11_Conditional_55_Template, 2, 0, "span", 30);
    \u0275\u0275elementEnd();
    \u0275\u0275template(56, Validacion_Conditional_11_ng_container_56_Template, 1, 0, "ng-container", 20);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(57, "li")(58, "p", 16);
    \u0275\u0275text(59, "\xBFEl quejoso proporcion\xF3 los datos del denunciado (nombre y apellidos*)?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(60, "div", 17);
    \u0275\u0275conditionalCreate(61, Validacion_Conditional_11_Conditional_61_Template, 2, 1, "strong")(62, Validacion_Conditional_11_Conditional_62_Template, 2, 0, "span", 30);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(63, "p", 19);
    \u0275\u0275text(64, "* Recuerde que hay personas que solo tienen un apellido.");
    \u0275\u0275elementEnd();
    \u0275\u0275template(65, Validacion_Conditional_11_ng_container_65_Template, 1, 0, "ng-container", 20);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(66, "div", 31)(67, "label", 32);
    \u0275\u0275text(68, "Observaciones generales (opcional):");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(69, "textarea", 33);
    \u0275\u0275twoWayListener("ngModelChange", function Validacion_Conditional_11_Template_textarea_ngModelChange_69_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.observaciones, $event) || (ctx_r2.observaciones = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(70, "div", 34)(71, "div", 35);
    \u0275\u0275element(72, "div", 36);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(73, "p", 37);
    \u0275\u0275text(74);
    \u0275\u0275conditionalCreate(75, Validacion_Conditional_11_Conditional_75_Template, 1, 1);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(76, "div", 38)(77, "button", 39);
    \u0275\u0275listener("click", function Validacion_Conditional_11_Template_button_click_77_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.irACanalizar());
    });
    \u0275\u0275text(78, " \u2192 Canalizar Queja ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(79, "button", 40);
    \u0275\u0275listener("click", function Validacion_Conditional_11_Template_button_click_79_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.regresarAlQuejoso());
    });
    \u0275\u0275text(80);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(81, "div", 41)(82, "h3");
    \u0275\u0275text(83, "Identificaci\xF3n del quejoso");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(84, Validacion_Conditional_11_Conditional_84_Template, 2, 1, "p", 14);
    \u0275\u0275conditionalCreate(85, Validacion_Conditional_11_Conditional_85_Template, 8, 5)(86, Validacion_Conditional_11_Conditional_86_Template, 2, 0, "p", 4)(87, Validacion_Conditional_11_Conditional_87_Template, 5, 0, "div", 42);
    \u0275\u0275elementStart(88, "div", 43)(89, "h4");
    \u0275\u0275text(90, "Evidencias adjuntas");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(91, Validacion_Conditional_11_Conditional_91_Template, 2, 0, "span", 30)(92, Validacion_Conditional_11_Conditional_92_Template, 3, 0, "ul", 44);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    const sino_r15 = \u0275\u0275reference(9);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1(" Contesta las ", ctx_r2.totalRequisitos, ' preguntas comparando lo capturado contra la identificaci\xF3n. Todas deben ser "S\xED" para canalizar; si alguna es "No", escribe qu\xE9 debe corregir el quejoso. ');
    \u0275\u0275advance(2);
    \u0275\u0275classProp("dato-cumplido", ctx_r2.respuestas.nombreCompleto.valor === true)("dato-fallido", ctx_r2.respuestas.nombreCompleto.valor === false);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r2.queja.nombreCompletoQuejoso);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r2.queja.correoInstitucional);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.queja.telefonoContacto ? 15 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275property("ngTemplateOutlet", sino_r15)("ngTemplateOutletContext", \u0275\u0275pureFunction0(62, _c0));
    \u0275\u0275advance();
    \u0275\u0275classProp("dato-cumplido", ctx_r2.respuestas.identificacionOficial.valor === true)("dato-fallido", ctx_r2.respuestas.identificacionOficial.valor === false);
    \u0275\u0275advance(12);
    \u0275\u0275textInterpolate1(" ", ctx_r2.mostrarListadoOficial ? "Ocultar listado oficial" : "Ver listado oficial", " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.mostrarListadoOficial ? 32 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.esAlumno ? 33 : -1);
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.tipoIdentificacionPresentada);
    \u0275\u0275property("disabled", ctx_r2.cargandoIdentificaciones);
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r2.identificaciones);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", sino_r15)("ngTemplateOutletContext", \u0275\u0275pureFunction0(63, _c1));
    \u0275\u0275advance();
    \u0275\u0275classProp("dato-cumplido", ctx_r2.respuestas.numeroIdentificacion.valor === true)("dato-fallido", ctx_r2.respuestas.numeroIdentificacion.valor === false);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" \xBFEl ", ctx_r2.etiquetaTipoIdentificacion.toLowerCase(), " proporcionado coincide con el de la identificaci\xF3n? ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r2.queja.numeroIdentificacionQuejoso ? 47 : 48);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", sino_r15)("ngTemplateOutletContext", \u0275\u0275pureFunction0(64, _c2));
    \u0275\u0275advance();
    \u0275\u0275classProp("dato-cumplido", ctx_r2.respuestas.fechaHechos.valor === true)("dato-fallido", ctx_r2.respuestas.fechaHechos.valor === false);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" \xBFLos hechos ocurrieron dentro de los ", ctx_r2.plazoDias, " d\xEDas previos al registro de la queja? ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r2.diasDesdeHechos !== null ? 54 : 55);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", sino_r15)("ngTemplateOutletContext", \u0275\u0275pureFunction0(65, _c3));
    \u0275\u0275advance();
    \u0275\u0275classProp("dato-cumplido", ctx_r2.respuestas.datosDenunciado.valor === true)("dato-fallido", ctx_r2.respuestas.datosDenunciado.valor === false);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r2.queja.nombreCompletoDenunciado && ctx_r2.queja.nombreCompletoDenunciado.trim() ? 61 : 62);
    \u0275\u0275advance(4);
    \u0275\u0275property("ngTemplateOutlet", sino_r15)("ngTemplateOutletContext", \u0275\u0275pureFunction0(66, _c4));
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.observaciones);
    \u0275\u0275advance(3);
    \u0275\u0275styleProp("width", ctx_r2.cumplidos / ctx_r2.totalRequisitos * 100, "%");
    \u0275\u0275classProp("completo", ctx_r2.puedeCanalizar);
    \u0275\u0275advance();
    \u0275\u0275classProp("completo", ctx_r2.puedeCanalizar);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2(" ", ctx_r2.cumplidos, " de ", ctx_r2.totalRequisitos, ' verificaciones en "S\xED" ');
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.contestadas < ctx_r2.totalRequisitos ? 75 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", !ctx_r2.puedeCanalizar)("title", ctx_r2.puedeCanalizar ? "" : "Todas las verificaciones deben ser S\xED para canalizar.");
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", !ctx_r2.puedeRegresar)("title", ctx_r2.motivoBloqueoRegresar);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r2.enviando ? "Enviando\u2026" : "\u2190 Regresar al Quejoso", " ");
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r2.imagenesCredencial.length > 1 ? 84 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.credencialUrl ? 85 : ctx_r2.cargandoCredencial ? 86 : 87);
    \u0275\u0275advance(6);
    \u0275\u0275conditional(ctx_r2.queja.evidencias.length === 0 ? 91 : 92);
  }
}
var PLAZO_DIAS_QUEJA = 90;
var MOTIVO_SI_NO = {
  nombreCompleto: "No proporcion\xF3 su nombre completo (nombre y apellidos).",
  identificacionOficial: "La identificaci\xF3n oficial no es legible, no es oficial, no est\xE1 vigente o no coincide con el nombre proporcionado.",
  numeroIdentificacion: "El n\xFAmero de boleta o de empleado no coincide con el de la identificaci\xF3n presentada.",
  fechaHechos: `Los hechos ocurrieron hace m\xE1s de ${PLAZO_DIAS_QUEJA} d\xEDas respecto a la fecha de registro de la queja.`,
  datosDenunciado: "Faltan los datos de la persona denunciada (nombre y apellidos)."
};
var TITULO_PREGUNTA = {
  nombreCompleto: "Nombre completo",
  identificacionOficial: "Identificaci\xF3n oficial",
  numeroIdentificacion: "N\xFAmero de boleta / empleado",
  fechaHechos: "Fecha de los hechos",
  datosDenunciado: "Datos del denunciado"
};
var ORDEN_PREGUNTAS = [
  "nombreCompleto",
  "identificacionOficial",
  "numeroIdentificacion",
  "fechaHechos",
  "datosDenunciado"
];
var Validacion = class _Validacion {
  route;
  router;
  revisionService;
  toast;
  sanitizer;
  cdr;
  plazoDias = PLAZO_DIAS_QUEJA;
  folio = "";
  queja = null;
  cargando = true;
  enviando = false;
  respuestas = {
    nombreCompleto: { valor: null, observacion: "" },
    identificacionOficial: { valor: null, observacion: "" },
    numeroIdentificacion: { valor: null, observacion: "" },
    fechaHechos: { valor: null, observacion: "" },
    datosDenunciado: { valor: null, observacion: "" }
  };
  totalRequisitos = ORDEN_PREGUNTAS.length;
  /** Observaciones generales, adicionales a las de cada pregunta (opcional). */
  observaciones = "";
  identificaciones = [];
  tipoIdentificacionPresentada = "";
  cargandoIdentificaciones = false;
  mostrarListadoOficial = false;
  imagenesCredencial = [];
  indiceCredencial = 0;
  credencialUrl = null;
  credencialNombre = "";
  credencialId = null;
  cargandoCredencial = false;
  credencialObjectUrl = null;
  constructor(route, router, revisionService, toast, sanitizer, cdr) {
    this.route = route;
    this.router = router;
    this.revisionService = revisionService;
    this.toast = toast;
    this.sanitizer = sanitizer;
    this.cdr = cdr;
  }
  ngOnInit() {
    this.folio = this.route.snapshot.paramMap.get("folio") ?? "";
    this.cargar();
  }
  ngOnDestroy() {
    if (this.credencialObjectUrl) {
      URL.revokeObjectURL(this.credencialObjectUrl);
      this.credencialObjectUrl = null;
    }
  }
  // ---------------- lista de verificación ----------------
  /** Acceso tipado desde la plantilla (el ng-template recibe la clave como string). */
  r(clave) {
    return this.respuestas[clave];
  }
  setRespuesta(clave, valor) {
    this.r(clave).valor = valor;
    this.cdr.detectChanges();
  }
  get cumplidos() {
    return ORDEN_PREGUNTAS.filter((c) => this.respuestas[c].valor === true).length;
  }
  get contestadas() {
    return ORDEN_PREGUNTAS.filter((c) => this.respuestas[c].valor !== null).length;
  }
  /** Preguntas contestadas con "No". */
  get preguntasEnNo() {
    return ORDEN_PREGUNTAS.filter((c) => this.respuestas[c].valor === false);
  }
  /** Preguntas en "No" a las que todavía les falta la observación para el quejoso. */
  get noSinObservacion() {
    return this.preguntasEnNo.filter((c) => !this.respuestas[c].observacion.trim());
  }
  get puedeCanalizar() {
    return this.cumplidos === this.totalRequisitos;
  }
  get puedeRegresar() {
    return this.preguntasEnNo.length > 0 && this.noSinObservacion.length === 0 && !this.enviando;
  }
  get motivoBloqueoRegresar() {
    if (this.preguntasEnNo.length === 0) {
      return 'Marca al menos una pregunta como "No" para regresar la queja.';
    }
    if (this.noSinObservacion.length > 0) {
      return 'Escribe la observaci\xF3n de cada pregunta marcada como "No".';
    }
    return "";
  }
  // ---------------- datos calculados para las preguntas ----------------
  /** Días naturales entre la fecha de los hechos y la fecha de registro de la queja.
   * null si la queja no trae fecha de los hechos (p. ej. registros manuales). */
  get diasDesdeHechos() {
    const hechos = this.aFechaLocal(this.queja?.fechaHechos);
    const registro = this.aFechaLocal(this.queja?.fechaCreacion);
    if (!hechos || !registro) {
      return null;
    }
    const msPorDia = 24 * 60 * 60 * 1e3;
    return Math.round((registro.getTime() - hechos.getTime()) / msPorDia);
  }
  get dentroDePlazo() {
    const dias = this.diasDesdeHechos;
    return dias === null ? null : dias <= this.plazoDias;
  }
  get etiquetaTipoIdentificacion() {
    switch ((this.queja?.tipoIdentificacionQuejoso ?? "").toLowerCase()) {
      case "alumno":
        return "N\xFAmero de boleta";
      case "empleado":
        return "N\xFAmero de empleado";
      default:
        return "Boleta / n\xFAmero de empleado";
    }
  }
  get esAlumno() {
    return (this.queja?.tipoIdentificacionQuejoso ?? "").toLowerCase() === "alumno";
  }
  /** "2026-09-30" o "2026-09-30T12:34:56" → fecha local a medianoche, sin corrimiento por
   * zona horaria (new Date('2026-09-30') la interpretaría como UTC y en México daría el 29). */
  aFechaLocal(valor) {
    if (!valor) {
      return null;
    }
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(valor);
    if (!m) {
      return null;
    }
    return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  }
  formatearFecha(valor) {
    const fecha = this.aFechaLocal(valor);
    return fecha ? fecha.toLocaleDateString("es-MX", { day: "2-digit", month: "long", year: "numeric" }) : "";
  }
  alternarListadoOficial() {
    this.mostrarListadoOficial = !this.mostrarListadoOficial;
  }
  // ---------------- acciones ----------------
  irACanalizar() {
    if (!this.puedeCanalizar) {
      this.toast.advertencia('Todas las verificaciones deben estar en "S\xED" para canalizar la queja.');
      return;
    }
    this.router.navigate(["/turnado", this.folio]);
  }
  regresarAlQuejoso() {
    if (!this.puedeRegresar) {
      this.toast.advertencia(this.motivoBloqueoRegresar || "Revisa las respuestas antes de regresar la queja.");
      return;
    }
    const motivos = this.preguntasEnNo.map((c) => MOTIVO_SI_NO[c]);
    const detalle = this.preguntasEnNo.map((c) => `\u2022 ${TITULO_PREGUNTA[c]}: ${this.respuestas[c].observacion.trim()}`);
    const idPresentada = this.identificaciones.find((i) => i.clave === this.tipoIdentificacionPresentada);
    if (idPresentada && this.respuestas.identificacionOficial.valor === false) {
      detalle.push(`\u2022 Identificaci\xF3n revisada: ${idPresentada.nombre}`);
    }
    if (this.observaciones.trim()) {
      detalle.push("", this.observaciones.trim());
    }
    this.enviando = true;
    this.revisionService.rechazar(this.folio, { motivos, observaciones: detalle.join("\n") }).subscribe({
      next: () => {
        this.toast.exito("La queja fue regresada al quejoso con observaciones.");
        this.router.navigate(["/"]);
      },
      error: (err) => {
        this.enviando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo regresar la queja.");
        this.cdr.detectChanges();
      }
    });
  }
  verDocumento(id) {
    this.revisionService.descargarEvidencia(id).subscribe({
      next: (blob) => {
        const url = URL.createObjectURL(blob);
        window.open(url, "_blank");
      },
      error: () => this.toast.error("No se pudo abrir el documento.")
    });
  }
  // ---------------- carga ----------------
  cargar() {
    this.cargando = true;
    this.revisionService.detalle(this.folio).subscribe({
      next: (queja) => {
        this.queja = queja;
        this.cargando = false;
        this.cargarCredencial();
        this.cargarIdentificaciones();
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.cargando = false;
        this.toast.error(err?.error?.mensaje ?? "No se pudo cargar la queja.");
        this.cdr.detectChanges();
      }
    });
  }
  cargarIdentificaciones() {
    this.cargandoIdentificaciones = true;
    this.revisionService.identificacionesOficiales().subscribe({
      next: (lista) => {
        this.identificaciones = lista;
        this.cargandoIdentificaciones = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargandoIdentificaciones = false;
        this.identificaciones = [];
        this.cdr.detectChanges();
      }
    });
  }
  cargarCredencial() {
    this.imagenesCredencial = (this.queja?.evidencias ?? []).filter((ev) => (ev.tipoMime ?? "").toLowerCase().startsWith("image/"));
    this.indiceCredencial = 0;
    if (this.imagenesCredencial.length === 0) {
      return;
    }
    this.mostrarCredencial(0);
  }
  seleccionarCredencial(indice) {
    if (indice === this.indiceCredencial || indice < 0 || indice >= this.imagenesCredencial.length) {
      return;
    }
    this.mostrarCredencial(indice);
  }
  mostrarCredencial(indice) {
    const imagen = this.imagenesCredencial[indice];
    if (!imagen) {
      return;
    }
    this.indiceCredencial = indice;
    this.credencialId = imagen.id;
    this.credencialNombre = imagen.nombreArchivo;
    this.cargandoCredencial = true;
    if (this.credencialObjectUrl) {
      URL.revokeObjectURL(this.credencialObjectUrl);
      this.credencialObjectUrl = null;
      this.credencialUrl = null;
    }
    this.revisionService.descargarEvidencia(imagen.id).subscribe({
      next: (blob) => {
        this.credencialObjectUrl = URL.createObjectURL(blob);
        this.credencialUrl = this.sanitizer.bypassSecurityTrustUrl(this.credencialObjectUrl);
        this.cargandoCredencial = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.cargandoCredencial = false;
        this.cdr.detectChanges();
      }
    });
  }
  formatearTamanio(bytes) {
    if (!bytes || bytes <= 0) {
      return "";
    }
    if (bytes < 1024) {
      return `${bytes} B`;
    }
    const kb = bytes / 1024;
    if (kb < 1024) {
      return `${kb.toFixed(kb < 10 ? 1 : 0)} KB`;
    }
    return `${(kb / 1024).toFixed(1)} MB`;
  }
  tipoIcono(ev) {
    const tipo = (ev.tipoMime ?? "").toLowerCase();
    if (tipo.startsWith("image/")) {
      return "imagen";
    }
    if (tipo === "application/pdf") {
      return "pdf";
    }
    return "archivo";
  }
  static \u0275fac = function Validacion_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Validacion)(\u0275\u0275directiveInject(ActivatedRoute), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(RevisionService), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(DomSanitizer), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Validacion, selectors: [["app-validacion"]], decls: 12, vars: 2, consts: [["sino", ""], [1, "page-header"], [1, "page-header-subtitulo"], ["routerLink", "/", 1, "btn-secondary"], [1, "cargando"], [1, "rejilla-validacion"], [1, "acciones-pregunta"], ["type", "button", 1, "btn-si", 3, "click"], ["type", "button", 1, "btn-no", 3, "click"], [1, "obs-pregunta", 3, "obs-requerida"], [1, "obs-pregunta"], [3, "for"], ["rows", "2", "placeholder", "Qu\xE9 falta o qu\xE9 no coincide, y qu\xE9 debe corregir el quejoso\u2026", 3, "ngModelChange", "id", "ngModel", "name"], [1, "card"], [1, "pista-checks"], [1, "lista-preguntas"], [1, "etiqueta-dato"], [1, "dato-capturado"], [1, "meta"], [1, "nota-apellido"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "instruccion"], ["type", "button", 1, "link-listado", 3, "click"], [1, "listado-oficial"], [1, "sub-pregunta"], [1, "input-group"], ["for", "tipoIdentificacionPresentada"], ["id", "tipoIdentificacionPresentada", "name", "tipoIdentificacionPresentada", 3, "ngModelChange", "ngModel", "disabled"], ["value", "", "disabled", ""], [3, "value"], [1, "sin-dato"], [1, "observaciones-validacion"], ["for", "obs-generales"], ["id", "obs-generales", "rows", "3", "name", "observaciones", "placeholder", "Algo adicional que deba saber el quejoso\u2026", 3, "ngModelChange", "ngModel"], [1, "progreso-requisitos"], [1, "progreso-barra"], [1, "progreso-relleno"], [1, "contador-checks"], [1, "acciones-validacion"], [1, "btn-exito", 3, "click", "disabled", "title"], [1, "btn-secondary", "boton-rechazar", 3, "click", "disabled", "title"], [1, "card", "card-credencial"], [1, "credencial-vacia"], [1, "evidencias-validacion"], [1, "lista-documentos"], [1, "en-linea"], [1, "plazo"], [1, "marco-credencial"], [1, "marco-credencial-cargando"], [3, "src", "alt"], [1, "pie-credencial"], [1, "miniaturas-credencial"], [1, "btn-secondary", 3, "click"], ["type", "button", 1, "miniatura-boton", 3, "activa", "title"], ["type", "button", 1, "miniatura-boton", 3, "click", "title"], [1, "icono-documento"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], [1, "datos-documento"], [1, "nombre-documento", 3, "title"], [1, "btn-secondary", "boton-ver", 3, "click"], ["x", "3", "y", "3", "width", "18", "height", "18", "rx", "2"], ["cx", "8.5", "cy", "8.5", "r", "1.5"], ["points", "21 15 16 10 5 21"], ["d", "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"], ["points", "14 2 14 8 20 8"], ["d", "M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"], ["points", "13 2 13 9 20 9"]], template: function Validacion_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 1)(1, "div")(2, "h2");
      \u0275\u0275text(3);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(4, "p", 2);
      \u0275\u0275text(5, "Verifica que los datos proporcionados existan y coincidan con la identificaci\xF3n.");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(6, "a", 3);
      \u0275\u0275text(7, "Volver a la Bandeja");
      \u0275\u0275elementEnd()();
      \u0275\u0275template(8, Validacion_ng_template_8_Template, 6, 5, "ng-template", null, 0, \u0275\u0275templateRefExtractor);
      \u0275\u0275conditionalCreate(10, Validacion_Conditional_10_Template, 2, 0, "p", 4)(11, Validacion_Conditional_11_Template, 93, 67, "div", 5);
    }
    if (rf & 2) {
      \u0275\u0275advance(3);
      \u0275\u0275textInterpolate1("Validaci\xF3n de Datos e Identificaci\xF3n \u2014 ", ctx.folio);
      \u0275\u0275advance(7);
      \u0275\u0275conditional(ctx.cargando ? 10 : ctx.queja ? 11 : -1);
    }
  }, dependencies: [CommonModule, NgTemplateOutlet, FormsModule, NgSelectOption, \u0275NgSelectMultipleOption, DefaultValueAccessor, SelectControlValueAccessor, NgControlStatus, NgModel, RouterLink], styles: ['@charset "UTF-8";\n\n\n.cargando[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n}\n.rejilla-validacion[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(0, 1.25fr) minmax(0, 1fr);\n  gap: 20px;\n  align-items: start;\n}\n@media (max-width: 1000px) {\n  .rejilla-validacion[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n}\n.pista-checks[_ngcontent-%COMP%] {\n  margin: 0 0 14px;\n  font-size: 0.84rem;\n  color: var(--texto-suave);\n}\n.etiqueta-dato[_ngcontent-%COMP%] {\n  font-size: 0.86rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.sin-dato[_ngcontent-%COMP%] {\n  color: var(--texto-suave);\n  font-style: italic;\n}\n.lista-documentos[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n.lista-documentos[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 9px 10px;\n  margin: 0 -10px;\n  border-radius: 8px;\n  font-size: 0.86rem;\n  transition: background 0.15s ease;\n}\n.lista-documentos[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:hover {\n  background: var(--gris-fondo);\n}\n.lista-documentos[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]:not(:last-child) {\n  border-bottom: 1px solid var(--borde);\n}\n.icono-documento[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 32px;\n  height: 32px;\n  border-radius: 8px;\n  flex-shrink: 0;\n}\n.icono-documento[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 17px;\n  height: 17px;\n}\n.icono-documento.imagen[_ngcontent-%COMP%] {\n  background: var(--acento-azul-suave);\n  color: var(--acento-azul);\n}\n.icono-documento.pdf[_ngcontent-%COMP%] {\n  background: #fdecea;\n  color: var(--peligro);\n}\n.icono-documento.archivo[_ngcontent-%COMP%] {\n  background: var(--gris-fondo);\n  color: var(--texto-suave);\n}\n.datos-documento[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n  flex: 1;\n}\n.nombre-documento[_ngcontent-%COMP%] {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-weight: 500;\n}\n.datos-documento[_ngcontent-%COMP%]   .meta[_ngcontent-%COMP%] {\n  font-size: 0.76rem;\n  color: var(--texto-suave);\n}\n.boton-ver[_ngcontent-%COMP%] {\n  padding: 5px 12px;\n  font-size: 0.78rem;\n  flex-shrink: 0;\n}\n.card-credencial[_ngcontent-%COMP%] {\n  position: sticky;\n  top: 16px;\n}\n.marco-credencial[_ngcontent-%COMP%] {\n  position: relative;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  background: var(--gris-fondo);\n  padding: 8px;\n  overflow: hidden;\n}\n.marco-credencial[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  display: block;\n  width: 100%;\n  height: auto;\n  max-height: 62vh;\n  object-fit: contain;\n  border-radius: 4px;\n}\n.marco-credencial-cargando[_ngcontent-%COMP%] {\n  position: absolute;\n  inset: 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: rgba(255, 255, 255, 0.75);\n  color: var(--texto-suave);\n  font-size: 0.8rem;\n  z-index: 1;\n}\n.miniaturas-credencial[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin: 10px 0 12px;\n}\n.miniatura-boton[_ngcontent-%COMP%] {\n  width: 30px;\n  height: 30px;\n  border-radius: 6px;\n  border: 1.5px solid var(--borde);\n  background: #fff;\n  color: var(--texto-suave);\n  font-size: 0.78rem;\n  font-weight: 600;\n}\n.miniatura-boton[_ngcontent-%COMP%]:hover {\n  border-color: var(--guinda-vivo);\n  color: var(--guinda-vivo);\n}\n.miniatura-boton.activa[_ngcontent-%COMP%] {\n  border-color: var(--guinda);\n  background: var(--guinda);\n  color: #fff;\n}\n.pie-credencial[_ngcontent-%COMP%] {\n  margin: 10px 0 12px;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n  word-break: break-word;\n}\n.credencial-vacia[_ngcontent-%COMP%] {\n  padding: 26px 16px;\n  border: 1px dashed var(--borde);\n  border-radius: 8px;\n  text-align: center;\n  color: var(--texto-suave);\n  font-size: 0.88rem;\n}\n.credencial-vacia[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0 0 6px;\n}\n.credencial-vacia[_ngcontent-%COMP%]   .meta[_ngcontent-%COMP%] {\n  font-size: 0.78rem;\n}\n.progreso-requisitos[_ngcontent-%COMP%] {\n  margin-top: 22px;\n}\n.progreso-barra[_ngcontent-%COMP%] {\n  height: 8px;\n  border-radius: 999px;\n  background: var(--gris-fondo);\n  overflow: hidden;\n}\n.progreso-relleno[_ngcontent-%COMP%] {\n  height: 100%;\n  border-radius: 999px;\n  background: var(--acento-ambar);\n  transition: width 0.25s ease, background 0.25s ease;\n}\n.progreso-relleno.completo[_ngcontent-%COMP%] {\n  background: var(--exito);\n}\n.contador-checks[_ngcontent-%COMP%] {\n  margin: 8px 0 0;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.contador-checks.completo[_ngcontent-%COMP%] {\n  color: var(--exito);\n  font-weight: 600;\n}\n.acciones-validacion[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 12px;\n  margin-top: 14px;\n  flex-wrap: wrap;\n}\n.acciones-validacion[_ngcontent-%COMP%]   .boton-rechazar[_ngcontent-%COMP%] {\n  color: var(--peligro);\n  border-color: var(--peligro);\n}\n.acciones-validacion[_ngcontent-%COMP%]   .boton-rechazar[_ngcontent-%COMP%]:hover {\n  background: #fdecea;\n}\n.acciones-pregunta[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  justify-content: flex-end;\n  align-items: start;\n  flex-wrap: wrap;\n}\n.btn-si[_ngcontent-%COMP%], \n.btn-no[_ngcontent-%COMP%] {\n  padding: 7px 18px;\n  border-radius: 8px;\n  border: 1.5px solid var(--borde);\n  background: #fff;\n  color: var(--texto);\n  font-size: 0.84rem;\n  font-weight: 600;\n  cursor: pointer;\n  transition:\n    background 0.15s ease,\n    border-color 0.15s ease,\n    color 0.15s ease;\n}\n.btn-si[_ngcontent-%COMP%]:hover, \n.btn-no[_ngcontent-%COMP%]:hover {\n  border-color: var(--guinda-vivo);\n  color: var(--guinda-vivo);\n}\n.btn-si.activo[_ngcontent-%COMP%], \n.btn-no.activo[_ngcontent-%COMP%] {\n  border-color: var(--guinda);\n  background: var(--guinda);\n  color: #fff;\n}\n.btn-si.activo[_ngcontent-%COMP%] {\n  background: var(--exito);\n  border-color: var(--exito);\n}\n.btn-no.activo[_ngcontent-%COMP%] {\n  background: var(--peligro);\n  border-color: var(--peligro);\n}\n.nota-apellido[_ngcontent-%COMP%] {\n  margin: 8px 0 0;\n  font-size: 0.78rem;\n  color: var(--texto-suave);\n}\n.sub-pregunta[_ngcontent-%COMP%] {\n  margin: 4px 0 8px;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n}\n.input-group[_ngcontent-%COMP%] {\n  margin-top: 12px;\n}\n.input-group[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 5px;\n  font-size: 0.82rem;\n  font-weight: 500;\n  color: var(--texto);\n}\n.input-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 8px 10px;\n  border-radius: 6px;\n  border: 1px solid var(--borde);\n  background: #fff;\n  color: var(--texto);\n  font-size: 0.85rem;\n}\n.observaciones-validacion[_ngcontent-%COMP%] {\n  margin-top: 16px;\n}\n.observaciones-validacion[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 6px;\n  font-size: 0.84rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.observaciones-validacion[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 10px;\n  border-radius: 6px;\n  border: 1px solid var(--borde);\n  resize: vertical;\n  font-size: 0.85rem;\n  font-family: inherit;\n}\n.lista-preguntas[_ngcontent-%COMP%] {\n  list-style: none;\n  counter-reset: pregunta;\n  margin: 0;\n  padding: 0;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%] {\n  counter-increment: pregunta;\n  position: relative;\n  padding: 14px 12px 14px 44px;\n  margin: 0 -12px;\n  border-radius: 8px;\n  border-bottom: 1px solid var(--borde);\n  transition: background 0.15s ease;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]::before {\n  content: counter(pregunta);\n  position: absolute;\n  left: 12px;\n  top: 14px;\n  width: 22px;\n  height: 22px;\n  border-radius: 50%;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-size: 0.78rem;\n  font-weight: 700;\n  display: grid;\n  place-items: center;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]:last-child {\n  border-bottom: none;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li[_ngcontent-%COMP%]   .acciones-pregunta[_ngcontent-%COMP%] {\n  justify-content: flex-start;\n  margin-top: 10px;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li.dato-cumplido[_ngcontent-%COMP%] {\n  background: var(--acento-verde-suave);\n  border-bottom-color: transparent;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li.dato-cumplido[_ngcontent-%COMP%]::before {\n  background: var(--acento-verde);\n  color: #fff;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li.dato-fallido[_ngcontent-%COMP%] {\n  background: #fdecec;\n  border-bottom-color: transparent;\n}\n.lista-preguntas[_ngcontent-%COMP%]    > li.dato-fallido[_ngcontent-%COMP%]::before {\n  background: var(--peligro);\n  color: #fff;\n}\n.instruccion[_ngcontent-%COMP%] {\n  margin: 0 0 6px;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n}\n.dato-capturado[_ngcontent-%COMP%] {\n  margin: 6px 0 0;\n  font-size: 0.9rem;\n  color: var(--texto);\n}\n.dato-capturado[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  display: block;\n  font-weight: 600;\n  word-break: break-word;\n}\n.dato-capturado[_ngcontent-%COMP%]   strong.en-linea[_ngcontent-%COMP%] {\n  display: inline;\n}\n.dato-capturado[_ngcontent-%COMP%]   .meta[_ngcontent-%COMP%] {\n  display: block;\n  margin-top: 4px;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.plazo[_ngcontent-%COMP%] {\n  display: inline-block;\n  margin-top: 8px;\n  padding: 3px 10px;\n  border-radius: 999px;\n  font-size: 0.78rem;\n  font-weight: 600;\n}\n.plazo.plazo-ok[_ngcontent-%COMP%] {\n  background: var(--acento-verde-suave);\n  color: var(--acento-verde);\n}\n.plazo.plazo-vencido[_ngcontent-%COMP%] {\n  background: #fdecec;\n  color: var(--peligro);\n}\n.link-listado[_ngcontent-%COMP%] {\n  margin-left: 6px;\n  padding: 0;\n  border: none;\n  background: none;\n  color: var(--guinda-vivo);\n  font-size: 0.8rem;\n  font-weight: 600;\n  text-decoration: underline;\n  cursor: pointer;\n}\n.listado-oficial[_ngcontent-%COMP%] {\n  margin: 8px 0;\n  padding: 10px 14px;\n  border-radius: 6px;\n  background: var(--gris-fondo);\n  font-size: 0.82rem;\n}\n.listado-oficial[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  margin: 0;\n  padding-left: 18px;\n}\n.listado-oficial[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin: 2px 0;\n}\n.obs-pregunta[_ngcontent-%COMP%] {\n  margin-top: 10px;\n}\n.obs-pregunta[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 5px;\n  font-size: 0.8rem;\n  font-weight: 500;\n  color: var(--texto-suave);\n}\n.obs-pregunta[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 8px 10px;\n  border-radius: 6px;\n  border: 1px solid var(--borde);\n  resize: vertical;\n  font-size: 0.85rem;\n  font-family: inherit;\n  background: #fff;\n}\n.obs-pregunta.obs-requerida[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  color: var(--peligro);\n  font-weight: 600;\n}\n/*# sourceMappingURL=validacion.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Validacion, [{
    type: Component,
    args: [{ selector: "app-validacion", standalone: true, imports: [CommonModule, FormsModule, RouterLink], template: `<div class="page-header">
  <div>
    <h2>Validaci\xF3n de Datos e Identificaci\xF3n \u2014 {{ folio }}</h2>
    <p class="page-header-subtitulo">Verifica que los datos proporcionados existan y coincidan con la identificaci\xF3n.</p>
  </div>
  <a routerLink="/" class="btn-secondary">Volver a la Bandeja</a>
</div>

<!-- Botones S\xED / No + observaci\xF3n cuando la respuesta es "No". Se reutiliza en las 5 preguntas. -->
<ng-template #sino let-clave="clave" let-obsSiempre="obsSiempre">
  <div class="acciones-pregunta">
    <button type="button" class="btn-si" [class.activo]="r(clave).valor === true"
            (click)="setRespuesta(clave, true)">S\xED</button>
    <button type="button" class="btn-no" [class.activo]="r(clave).valor === false"
            (click)="setRespuesta(clave, false)">No</button>
  </div>
  @if (r(clave).valor === false || obsSiempre) {
    <div class="obs-pregunta" [class.obs-requerida]="r(clave).valor === false">
      <label [for]="'obs-' + clave">
        Observaciones{{ r(clave).valor === false ? ' para el quejoso (obligatorio)' : ' (opcional)' }}:
      </label>
      <textarea
        [id]="'obs-' + clave"
        rows="2"
        [(ngModel)]="r(clave).observacion"
        [name]="'obs-' + clave"
        placeholder="Qu\xE9 falta o qu\xE9 no coincide, y qu\xE9 debe corregir el quejoso\u2026"
      ></textarea>
    </div>
  }
</ng-template>

@if (cargando) {
  <p class="cargando">Cargando queja\u2026</p>
} @else if (queja) {
  <div class="rejilla-validacion">

    <!-- Columna izquierda: lista de verificaci\xF3n -->
    <div class="card">
      <h3>Revisi\xF3n del Quejoso</h3>
      <p class="pista-checks">
        Contesta las {{ totalRequisitos }} preguntas comparando lo capturado contra la identificaci\xF3n.
        Todas deben ser "S\xED" para canalizar; si alguna es "No", escribe qu\xE9 debe corregir el quejoso.
      </p>

      <ol class="lista-preguntas">
        <!-- 1. Nombre completo -->
        <li [class.dato-cumplido]="respuestas.nombreCompleto.valor === true"
            [class.dato-fallido]="respuestas.nombreCompleto.valor === false">
          <p class="etiqueta-dato">\xBFEl quejoso proporcion\xF3 su nombre completo (nombre y apellidos*)?</p>
          <div class="dato-capturado">
            <strong>{{ queja.nombreCompletoQuejoso }}</strong>
            <span class="meta">{{ queja.correoInstitucional }}</span>
            @if (queja.telefonoContacto) {
              <span class="meta">Tel: {{ queja.telefonoContacto }}</span>
            }
          </div>
          <p class="nota-apellido">* Recuerde que hay personas que solo tienen un apellido.</p>
          <ng-container *ngTemplateOutlet="sino; context: { clave: 'nombreCompleto' }"></ng-container>
        </li>

        <!-- 2. Identificaci\xF3n oficial -->
        <li [class.dato-cumplido]="respuestas.identificacionOficial.valor === true"
            [class.dato-fallido]="respuestas.identificacionOficial.valor === false">
          <p class="instruccion">
            Verifique que la identificaci\xF3n presentada sea <strong>legible, oficial, vigente</strong> y
            <strong>coincida con el nombre proporcionado</strong>.
          </p>
          <p class="etiqueta-dato">
            \xBFEl quejoso present\xF3 una identificaci\xF3n oficial v\xE1lida y vigente de acuerdo al art\xEDculo 48?
            <button type="button" class="link-listado" (click)="alternarListadoOficial()">
              {{ mostrarListadoOficial ? 'Ocultar listado oficial' : 'Ver listado oficial' }}
            </button>
          </p>
          @if (mostrarListadoOficial) {
            <div class="listado-oficial">
              @if (cargandoIdentificaciones) {
                <span class="sin-dato">Cargando listado\u2026</span>
              } @else if (identificaciones.length === 0) {
                <span class="sin-dato">No se pudo cargar el listado oficial.</span>
              } @else {
                <ul>
                  @for (identificacion of identificaciones; track identificacion.clave) {
                    <li>{{ identificacion.nombre }}</li>
                  }
                </ul>
              }
            </div>
          }
          @if (esAlumno) {
            <p class="sub-pregunta">
              En caso de ser alumno, la credencial del IPN vigente tambi\xE9n es v\xE1lida; revise que la boleta
              coincida (pregunta 3).
            </p>
          }
          <div class="input-group">
            <label for="tipoIdentificacionPresentada">Identificaci\xF3n que present\xF3:</label>
            <select id="tipoIdentificacionPresentada" [(ngModel)]="tipoIdentificacionPresentada"
                    name="tipoIdentificacionPresentada" [disabled]="cargandoIdentificaciones">
              <option value="" disabled>Seleccione el tipo de identificaci\xF3n</option>
              @for (identificacion of identificaciones; track identificacion.clave) {
                <option [value]="identificacion.clave">{{ identificacion.nombre }}</option>
              }
            </select>
          </div>
          <ng-container *ngTemplateOutlet="sino; context: { clave: 'identificacionOficial', obsSiempre: true }"></ng-container>
        </li>

        <!-- 3. Boleta / n\xFAmero de empleado -->
        <li [class.dato-cumplido]="respuestas.numeroIdentificacion.valor === true"
            [class.dato-fallido]="respuestas.numeroIdentificacion.valor === false">
          <p class="etiqueta-dato">
            \xBFEl {{ etiquetaTipoIdentificacion.toLowerCase() }} proporcionado coincide con el de la identificaci\xF3n?
          </p>
          <div class="dato-capturado">
            @if (queja.numeroIdentificacionQuejoso) {
              <strong>{{ etiquetaTipoIdentificacion }}: {{ queja.numeroIdentificacionQuejoso }}</strong>
            } @else {
              <span class="sin-dato">No proporcion\xF3 n\xFAmero de boleta ni de empleado.</span>
            }
          </div>
          <ng-container *ngTemplateOutlet="sino; context: { clave: 'numeroIdentificacion' }"></ng-container>
        </li>

        <!-- 4. Fecha de los hechos: plazo de 90 d\xEDas -->
        <li [class.dato-cumplido]="respuestas.fechaHechos.valor === true"
            [class.dato-fallido]="respuestas.fechaHechos.valor === false">
          <p class="etiqueta-dato">
            \xBFLos hechos ocurrieron dentro de los {{ plazoDias }} d\xEDas previos al registro de la queja?
          </p>
          <div class="dato-capturado">
            @if (diasDesdeHechos !== null) {
              <span class="meta">Fecha de los hechos: <strong class="en-linea">{{ formatearFecha(queja.fechaHechos) }}</strong></span>
              <span class="meta">Fecha de registro: <strong class="en-linea">{{ formatearFecha(queja.fechaCreacion) }}</strong></span>
              <span class="plazo" [class.plazo-ok]="dentroDePlazo" [class.plazo-vencido]="!dentroDePlazo">
                {{ diasDesdeHechos }} {{ diasDesdeHechos === 1 ? 'd\xEDa' : 'd\xEDas' }} transcurridos \u2014
                {{ dentroDePlazo ? 'dentro del plazo' : 'fuera del plazo de ' + plazoDias + ' d\xEDas' }}
              </span>
            } @else {
              <span class="sin-dato">La queja no tiene fecha de los hechos capturada; verif\xEDquela en el documento.</span>
            }
          </div>
          <ng-container *ngTemplateOutlet="sino; context: { clave: 'fechaHechos' }"></ng-container>
        </li>

        <!-- 5. Datos del denunciado -->
        <li [class.dato-cumplido]="respuestas.datosDenunciado.valor === true"
            [class.dato-fallido]="respuestas.datosDenunciado.valor === false">
          <p class="etiqueta-dato">\xBFEl quejoso proporcion\xF3 los datos del denunciado (nombre y apellidos*)?</p>
          <div class="dato-capturado">
            @if (queja.nombreCompletoDenunciado && queja.nombreCompletoDenunciado.trim()) {
              <strong>{{ queja.nombreCompletoDenunciado }}</strong>
            } @else {
              <span class="sin-dato">No captur\xF3 datos del denunciado.</span>
            }
          </div>
          <p class="nota-apellido">* Recuerde que hay personas que solo tienen un apellido.</p>
          <ng-container *ngTemplateOutlet="sino; context: { clave: 'datosDenunciado' }"></ng-container>
        </li>
      </ol>

      <div class="observaciones-validacion">
        <label for="obs-generales">Observaciones generales (opcional):</label>
        <textarea
          id="obs-generales"
          rows="3"
          [(ngModel)]="observaciones"
          name="observaciones"
          placeholder="Algo adicional que deba saber el quejoso\u2026"
        ></textarea>
      </div>

      <div class="progreso-requisitos">
        <div class="progreso-barra">
          <div class="progreso-relleno" [class.completo]="puedeCanalizar"
               [style.width.%]="(cumplidos / totalRequisitos) * 100"></div>
        </div>
        <p class="contador-checks" [class.completo]="puedeCanalizar">
          {{ cumplidos }} de {{ totalRequisitos }} verificaciones en "S\xED"
          @if (contestadas < totalRequisitos) {
            \xB7 faltan {{ totalRequisitos - contestadas }} por contestar
          }
        </p>
      </div>

      <div class="acciones-validacion">
        <button class="btn-exito" [disabled]="!puedeCanalizar"
                [title]="puedeCanalizar ? '' : 'Todas las verificaciones deben ser S\xED para canalizar.'"
                (click)="irACanalizar()">
          \u2192 Canalizar Queja
        </button>
        <button class="btn-secondary boton-rechazar" [disabled]="!puedeRegresar"
                [title]="motivoBloqueoRegresar" (click)="regresarAlQuejoso()">
          {{ enviando ? 'Enviando\u2026' : '\u2190 Regresar al Quejoso' }}
        </button>
      </div>
    </div>

    <!-- Columna derecha: credencial en grande -->
    <div class="card card-credencial">
      <h3>Identificaci\xF3n del quejoso</h3>
      @if (imagenesCredencial.length > 1) {
        <p class="pista-checks">{{ imagenesCredencial.length }} im\xE1genes adjuntas \u2014 elige cu\xE1l ver en grande.</p>
      }

      @if (credencialUrl) {
        <div class="marco-credencial">
          @if (cargandoCredencial) {
            <div class="marco-credencial-cargando">Cargando\u2026</div>
          }
          <img [src]="credencialUrl" [alt]="credencialNombre" />
        </div>
        <p class="pie-credencial">{{ credencialNombre }}</p>

        @if (imagenesCredencial.length > 1) {
          <div class="miniaturas-credencial">
            @for (img of imagenesCredencial; track img.id; let i = $index) {
              <button
                type="button"
                class="miniatura-boton"
                [class.activa]="i === indiceCredencial"
                [title]="img.nombreArchivo"
                (click)="seleccionarCredencial(i)"
              >
                {{ i + 1 }}
              </button>
            }
          </div>
        }

        <button class="btn-secondary" (click)="verDocumento(credencialId!)">Abrir en tama\xF1o real</button>
      } @else if (cargandoCredencial) {
        <p class="cargando">Cargando identificaci\xF3n\u2026</p>
      } @else {
        <div class="credencial-vacia">
          <p>No se adjunt\xF3 una imagen de identificaci\xF3n.</p>
          <p class="meta">Si el quejoso subi\xF3 un PDF, \xE1brelo desde la lista de evidencias.</p>
        </div>
      }

      <!-- Evidencias (lista compacta) -->
      <div class="evidencias-validacion">
        <h4>Evidencias adjuntas</h4>
        @if (queja.evidencias.length === 0) {
          <span class="sin-dato">No se adjuntaron documentos.</span>
        } @else {
          <ul class="lista-documentos">
            @for (ev of queja.evidencias; track ev.id) {
              <li>
                <span class="icono-documento" [class]="tipoIcono(ev)">
                  @switch (tipoIcono(ev)) {
                    @case ('imagen') {
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>
                    }
                    @case ('pdf') {
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>
                    }
                    @default {
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                    }
                  }
                </span>
                <span class="datos-documento">
                  <span class="nombre-documento" [title]="ev.nombreArchivo">{{ ev.nombreArchivo }}</span>
                  @if (ev.tamanioBytes) {
                    <span class="meta">{{ formatearTamanio(ev.tamanioBytes) }}</span>
                  }
                </span>
                <button class="btn-secondary boton-ver" (click)="verDocumento(ev.id)">Ver</button>
              </li>
            }
          </ul>
        }
      </div>
    </div>

  </div>
}
`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/validacion/validacion.scss */\n.cargando {\n  color: var(--texto-suave);\n}\n.rejilla-validacion {\n  display: grid;\n  grid-template-columns: minmax(0, 1.25fr) minmax(0, 1fr);\n  gap: 20px;\n  align-items: start;\n}\n@media (max-width: 1000px) {\n  .rejilla-validacion {\n    grid-template-columns: 1fr;\n  }\n}\n.pista-checks {\n  margin: 0 0 14px;\n  font-size: 0.84rem;\n  color: var(--texto-suave);\n}\n.etiqueta-dato {\n  font-size: 0.86rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.sin-dato {\n  color: var(--texto-suave);\n  font-style: italic;\n}\n.lista-documentos {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n.lista-documentos li {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  padding: 9px 10px;\n  margin: 0 -10px;\n  border-radius: 8px;\n  font-size: 0.86rem;\n  transition: background 0.15s ease;\n}\n.lista-documentos li:hover {\n  background: var(--gris-fondo);\n}\n.lista-documentos li:not(:last-child) {\n  border-bottom: 1px solid var(--borde);\n}\n.icono-documento {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 32px;\n  height: 32px;\n  border-radius: 8px;\n  flex-shrink: 0;\n}\n.icono-documento svg {\n  width: 17px;\n  height: 17px;\n}\n.icono-documento.imagen {\n  background: var(--acento-azul-suave);\n  color: var(--acento-azul);\n}\n.icono-documento.pdf {\n  background: #fdecea;\n  color: var(--peligro);\n}\n.icono-documento.archivo {\n  background: var(--gris-fondo);\n  color: var(--texto-suave);\n}\n.datos-documento {\n  display: flex;\n  flex-direction: column;\n  min-width: 0;\n  flex: 1;\n}\n.nombre-documento {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  font-weight: 500;\n}\n.datos-documento .meta {\n  font-size: 0.76rem;\n  color: var(--texto-suave);\n}\n.boton-ver {\n  padding: 5px 12px;\n  font-size: 0.78rem;\n  flex-shrink: 0;\n}\n.card-credencial {\n  position: sticky;\n  top: 16px;\n}\n.marco-credencial {\n  position: relative;\n  border: 1px solid var(--borde);\n  border-radius: 8px;\n  background: var(--gris-fondo);\n  padding: 8px;\n  overflow: hidden;\n}\n.marco-credencial img {\n  display: block;\n  width: 100%;\n  height: auto;\n  max-height: 62vh;\n  object-fit: contain;\n  border-radius: 4px;\n}\n.marco-credencial-cargando {\n  position: absolute;\n  inset: 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: rgba(255, 255, 255, 0.75);\n  color: var(--texto-suave);\n  font-size: 0.8rem;\n  z-index: 1;\n}\n.miniaturas-credencial {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin: 10px 0 12px;\n}\n.miniatura-boton {\n  width: 30px;\n  height: 30px;\n  border-radius: 6px;\n  border: 1.5px solid var(--borde);\n  background: #fff;\n  color: var(--texto-suave);\n  font-size: 0.78rem;\n  font-weight: 600;\n}\n.miniatura-boton:hover {\n  border-color: var(--guinda-vivo);\n  color: var(--guinda-vivo);\n}\n.miniatura-boton.activa {\n  border-color: var(--guinda);\n  background: var(--guinda);\n  color: #fff;\n}\n.pie-credencial {\n  margin: 10px 0 12px;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n  word-break: break-word;\n}\n.credencial-vacia {\n  padding: 26px 16px;\n  border: 1px dashed var(--borde);\n  border-radius: 8px;\n  text-align: center;\n  color: var(--texto-suave);\n  font-size: 0.88rem;\n}\n.credencial-vacia p {\n  margin: 0 0 6px;\n}\n.credencial-vacia .meta {\n  font-size: 0.78rem;\n}\n.progreso-requisitos {\n  margin-top: 22px;\n}\n.progreso-barra {\n  height: 8px;\n  border-radius: 999px;\n  background: var(--gris-fondo);\n  overflow: hidden;\n}\n.progreso-relleno {\n  height: 100%;\n  border-radius: 999px;\n  background: var(--acento-ambar);\n  transition: width 0.25s ease, background 0.25s ease;\n}\n.progreso-relleno.completo {\n  background: var(--exito);\n}\n.contador-checks {\n  margin: 8px 0 0;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.contador-checks.completo {\n  color: var(--exito);\n  font-weight: 600;\n}\n.acciones-validacion {\n  display: flex;\n  gap: 12px;\n  margin-top: 14px;\n  flex-wrap: wrap;\n}\n.acciones-validacion .boton-rechazar {\n  color: var(--peligro);\n  border-color: var(--peligro);\n}\n.acciones-validacion .boton-rechazar:hover {\n  background: #fdecea;\n}\n.acciones-pregunta {\n  display: flex;\n  gap: 10px;\n  justify-content: flex-end;\n  align-items: start;\n  flex-wrap: wrap;\n}\n.btn-si,\n.btn-no {\n  padding: 7px 18px;\n  border-radius: 8px;\n  border: 1.5px solid var(--borde);\n  background: #fff;\n  color: var(--texto);\n  font-size: 0.84rem;\n  font-weight: 600;\n  cursor: pointer;\n  transition:\n    background 0.15s ease,\n    border-color 0.15s ease,\n    color 0.15s ease;\n}\n.btn-si:hover,\n.btn-no:hover {\n  border-color: var(--guinda-vivo);\n  color: var(--guinda-vivo);\n}\n.btn-si.activo,\n.btn-no.activo {\n  border-color: var(--guinda);\n  background: var(--guinda);\n  color: #fff;\n}\n.btn-si.activo {\n  background: var(--exito);\n  border-color: var(--exito);\n}\n.btn-no.activo {\n  background: var(--peligro);\n  border-color: var(--peligro);\n}\n.nota-apellido {\n  margin: 8px 0 0;\n  font-size: 0.78rem;\n  color: var(--texto-suave);\n}\n.sub-pregunta {\n  margin: 4px 0 8px;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n}\n.input-group {\n  margin-top: 12px;\n}\n.input-group label {\n  display: block;\n  margin-bottom: 5px;\n  font-size: 0.82rem;\n  font-weight: 500;\n  color: var(--texto);\n}\n.input-group select {\n  width: 100%;\n  padding: 8px 10px;\n  border-radius: 6px;\n  border: 1px solid var(--borde);\n  background: #fff;\n  color: var(--texto);\n  font-size: 0.85rem;\n}\n.observaciones-validacion {\n  margin-top: 16px;\n}\n.observaciones-validacion label {\n  display: block;\n  margin-bottom: 6px;\n  font-size: 0.84rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.observaciones-validacion textarea {\n  width: 100%;\n  padding: 10px;\n  border-radius: 6px;\n  border: 1px solid var(--borde);\n  resize: vertical;\n  font-size: 0.85rem;\n  font-family: inherit;\n}\n.lista-preguntas {\n  list-style: none;\n  counter-reset: pregunta;\n  margin: 0;\n  padding: 0;\n}\n.lista-preguntas > li {\n  counter-increment: pregunta;\n  position: relative;\n  padding: 14px 12px 14px 44px;\n  margin: 0 -12px;\n  border-radius: 8px;\n  border-bottom: 1px solid var(--borde);\n  transition: background 0.15s ease;\n}\n.lista-preguntas > li::before {\n  content: counter(pregunta);\n  position: absolute;\n  left: 12px;\n  top: 14px;\n  width: 22px;\n  height: 22px;\n  border-radius: 50%;\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  font-size: 0.78rem;\n  font-weight: 700;\n  display: grid;\n  place-items: center;\n}\n.lista-preguntas > li:last-child {\n  border-bottom: none;\n}\n.lista-preguntas > li .acciones-pregunta {\n  justify-content: flex-start;\n  margin-top: 10px;\n}\n.lista-preguntas > li.dato-cumplido {\n  background: var(--acento-verde-suave);\n  border-bottom-color: transparent;\n}\n.lista-preguntas > li.dato-cumplido::before {\n  background: var(--acento-verde);\n  color: #fff;\n}\n.lista-preguntas > li.dato-fallido {\n  background: #fdecec;\n  border-bottom-color: transparent;\n}\n.lista-preguntas > li.dato-fallido::before {\n  background: var(--peligro);\n  color: #fff;\n}\n.instruccion {\n  margin: 0 0 6px;\n  font-size: 0.82rem;\n  color: var(--texto-suave);\n}\n.dato-capturado {\n  margin: 6px 0 0;\n  font-size: 0.9rem;\n  color: var(--texto);\n}\n.dato-capturado strong {\n  display: block;\n  font-weight: 600;\n  word-break: break-word;\n}\n.dato-capturado strong.en-linea {\n  display: inline;\n}\n.dato-capturado .meta {\n  display: block;\n  margin-top: 4px;\n  font-size: 0.8rem;\n  color: var(--texto-suave);\n}\n.plazo {\n  display: inline-block;\n  margin-top: 8px;\n  padding: 3px 10px;\n  border-radius: 999px;\n  font-size: 0.78rem;\n  font-weight: 600;\n}\n.plazo.plazo-ok {\n  background: var(--acento-verde-suave);\n  color: var(--acento-verde);\n}\n.plazo.plazo-vencido {\n  background: #fdecec;\n  color: var(--peligro);\n}\n.link-listado {\n  margin-left: 6px;\n  padding: 0;\n  border: none;\n  background: none;\n  color: var(--guinda-vivo);\n  font-size: 0.8rem;\n  font-weight: 600;\n  text-decoration: underline;\n  cursor: pointer;\n}\n.listado-oficial {\n  margin: 8px 0;\n  padding: 10px 14px;\n  border-radius: 6px;\n  background: var(--gris-fondo);\n  font-size: 0.82rem;\n}\n.listado-oficial ul {\n  margin: 0;\n  padding-left: 18px;\n}\n.listado-oficial li {\n  margin: 2px 0;\n}\n.obs-pregunta {\n  margin-top: 10px;\n}\n.obs-pregunta label {\n  display: block;\n  margin-bottom: 5px;\n  font-size: 0.8rem;\n  font-weight: 500;\n  color: var(--texto-suave);\n}\n.obs-pregunta textarea {\n  width: 100%;\n  padding: 8px 10px;\n  border-radius: 6px;\n  border: 1px solid var(--borde);\n  resize: vertical;\n  font-size: 0.85rem;\n  font-family: inherit;\n  background: #fff;\n}\n.obs-pregunta.obs-requerida label {\n  color: var(--peligro);\n  font-weight: 600;\n}\n/*# sourceMappingURL=validacion.css.map */\n'] }]
  }], () => [{ type: ActivatedRoute }, { type: Router }, { type: RevisionService }, { type: ToastService }, { type: DomSanitizer }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Validacion, { className: "Validacion", filePath: "src/app/pages/validacion/validacion.ts", lineNumber: 62 });
})();
export {
  PLAZO_DIAS_QUEJA,
  Validacion
};
//# sourceMappingURL=chunk-R2OMQ26N.js.map
