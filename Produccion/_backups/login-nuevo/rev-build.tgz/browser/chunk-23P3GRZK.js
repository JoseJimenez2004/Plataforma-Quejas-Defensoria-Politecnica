import {
  AuthRevisionService
} from "./chunk-JXDKWF54.js";
import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel
} from "./chunk-BJ6JQKEH.js";
import {
  Router,
  RouterLink,
  RouterLinkActive,
  RouterOutlet
} from "./chunk-F26HINUV.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  HostListener,
  HttpClient,
  Injectable,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵresetView,
  ɵɵresolveDocument,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-FT7UGDQZ.js";

// src/app/core/models/revision.models.ts
function etiquetaRol(rol) {
  switch (rol) {
    case "ADMIN_SISTEMAS":
      return "Admin. de Sistemas";
    case "RECEPCIONISTA":
      return "Recepcionista";
    case "ANALISTA_PRIMER_CONTACTO":
      return "Analista de Primer Contacto";
    case "SUBDEFENSOR":
      return "Subdefensor";
    case "DEFENSOR":
      return "Defensor";
    default:
      return rol;
  }
}
function iniciales(nombreCompleto) {
  const partes = (nombreCompleto ?? "").trim().split(/\s+/).filter(Boolean);
  if (partes.length === 0)
    return "?";
  if (partes.length === 1)
    return partes[0].slice(0, 2).toUpperCase();
  return (partes[0][0] + partes[1][0]).toUpperCase();
}

// src/app/core/services/perfil.service.ts
var PerfilService = class _PerfilService {
  http;
  apiUrl = "/api/admin/perfil";
  constructor(http) {
    this.http = http;
  }
  cambiarPassword(datos) {
    return this.http.put(`${this.apiUrl}/password`, datos);
  }
  static \u0275fac = function PerfilService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _PerfilService)(\u0275\u0275inject(HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _PerfilService, factory: _PerfilService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PerfilService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [{ type: HttpClient }], null);
})();

// src/app/pages/recepcion-layout/recepcion-layout.ts
var _c0 = () => ({ exact: true });
function RecepcionLayout_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 31);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_16_Template_div_click_0_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(1, "button", 32);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_16_Template_button_click_1_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.abrirModalPassword());
    });
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 9);
    \u0275\u0275element(3, "circle", 33)(4, "path", 34)(5, "path", 35)(6, "path", 36);
    \u0275\u0275elementEnd();
    \u0275\u0275text(7, " Cambiar contrase\xF1a ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275element(8, "div", 37);
    \u0275\u0275elementStart(9, "button", 38);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_16_Template_button_click_9_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.cerrarSesion());
    });
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(10, "svg", 9);
    \u0275\u0275element(11, "path", 39)(12, "polyline", 40)(13, "line", 41);
    \u0275\u0275elementEnd();
    \u0275\u0275text(14, " Cerrar sesi\xF3n ");
    \u0275\u0275elementEnd()();
  }
}
function RecepcionLayout_Conditional_48_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 59);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_48_Conditional_5_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r4);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.cerrarModalPassword());
    });
    \u0275\u0275text(1, "\u2715");
    \u0275\u0275elementEnd();
  }
}
function RecepcionLayout_Conditional_48_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 45);
    \u0275\u0275text(1, " Tu cuenta tiene una contrase\xF1a temporal. Debes establecer una nueva antes de continuar usando el panel. ");
    \u0275\u0275elementEnd();
  }
}
function RecepcionLayout_Conditional_48_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 55);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.errorPassword);
  }
}
function RecepcionLayout_Conditional_48_Conditional_45_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 60);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_48_Conditional_45_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r5);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.cerrarModalPassword());
    });
    \u0275\u0275text(1, "Cancelar");
    \u0275\u0275elementEnd();
  }
}
function RecepcionLayout_Conditional_48_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 30)(1, "div", 42);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_48_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(2, "div", 43)(3, "h3");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(5, RecepcionLayout_Conditional_48_Conditional_5_Template, 2, 0, "button", 44);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(6, RecepcionLayout_Conditional_48_Conditional_6_Template, 2, 0, "p", 45);
    \u0275\u0275elementStart(7, "div", 46)(8, "label");
    \u0275\u0275text(9, "Contrase\xF1a actual");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "div", 47)(11, "input", 48);
    \u0275\u0275twoWayListener("ngModelChange", function RecepcionLayout_Conditional_48_Template_input_ngModelChange_11_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordActual, $event) || (ctx_r1.passwordActual = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "button", 49);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_48_Template_button_click_12_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.mostrarActual = !ctx_r1.mostrarActual);
    });
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(14, "div", 46)(15, "label");
    \u0275\u0275text(16, "Contrase\xF1a nueva");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "div", 47)(18, "input", 50);
    \u0275\u0275twoWayListener("ngModelChange", function RecepcionLayout_Conditional_48_Template_input_ngModelChange_18_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordNueva, $event) || (ctx_r1.passwordNueva = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "button", 49);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_48_Template_button_click_19_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.mostrarNueva = !ctx_r1.mostrarNueva);
    });
    \u0275\u0275text(20);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "ul", 51)(22, "li")(23, "span", 14);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(24, "svg", 52);
    \u0275\u0275element(25, "polyline", 53);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(26, " Al menos 8 caracteres ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(27, "li")(28, "span", 14);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(29, "svg", 52);
    \u0275\u0275element(30, "polyline", 53);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(31, " Una letra may\xFAscula ");
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(32, "li")(33, "span", 14);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(34, "svg", 52);
    \u0275\u0275element(35, "polyline", 53);
    \u0275\u0275elementEnd()();
    \u0275\u0275text(36, " Un n\xFAmero ");
    \u0275\u0275elementEnd()();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(37, "div", 46)(38, "label");
    \u0275\u0275text(39, "Confirmar contrase\xF1a nueva");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "input", 54);
    \u0275\u0275twoWayListener("ngModelChange", function RecepcionLayout_Conditional_48_Template_input_ngModelChange_40_listener($event) {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.passwordConfirmar, $event) || (ctx_r1.passwordConfirmar = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(41, RecepcionLayout_Conditional_48_Conditional_41_Template, 2, 1, "p", 55);
    \u0275\u0275elementStart(42, "div", 56)(43, "button", 57);
    \u0275\u0275listener("click", function RecepcionLayout_Conditional_48_Template_button_click_43_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.guardarPassword());
    });
    \u0275\u0275text(44);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(45, RecepcionLayout_Conditional_48_Conditional_45_Template, 2, 0, "button", 58);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r1.cambioObligatorio ? "Actualiza tu contrase\xF1a temporal" : "Cambiar mi contrase\xF1a");
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx_r1.cambioObligatorio ? 5 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.cambioObligatorio ? 6 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275property("type", ctx_r1.mostrarActual ? "text" : "password");
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordActual);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.mostrarActual ? "\u{1F648}" : "\u{1F441}\uFE0F");
    \u0275\u0275advance(5);
    \u0275\u0275property("type", ctx_r1.mostrarNueva ? "text" : "password");
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordNueva);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx_r1.mostrarNueva ? "\u{1F648}" : "\u{1F441}\uFE0F");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleLongitud);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleMayuscula);
    \u0275\u0275advance(5);
    \u0275\u0275classProp("cumplido", ctx_r1.cumpleNumero);
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.passwordConfirmar);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.errorPassword ? 41 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r1.guardandoPassword);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r1.guardandoPassword ? "Guardando\u2026" : "Actualizar Contrase\xF1a", " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx_r1.cambioObligatorio ? 45 : -1);
  }
}
var RecepcionLayout = class _RecepcionLayout {
  authService;
  perfilService;
  router;
  toast;
  cdr;
  etiquetaRol = etiquetaRol;
  menuAbierto = false;
  mostrarModalPassword = false;
  cambioObligatorio = false;
  passwordActual = "";
  passwordNueva = "";
  passwordConfirmar = "";
  mostrarActual = false;
  mostrarNueva = false;
  guardandoPassword = false;
  errorPassword = "";
  constructor(authService, perfilService, router, toast, cdr) {
    this.authService = authService;
    this.perfilService = perfilService;
    this.router = router;
    this.toast = toast;
    this.cdr = cdr;
  }
  ngOnInit() {
    const usuario = this.authService.usuarioActual();
    if (usuario?.forzarCambioPassword) {
      this.cambioObligatorio = true;
      this.abrirModalPassword();
    }
  }
  get nombreUsuario() {
    return this.authService.usuarioActual()?.nombre ?? "";
  }
  get rolUsuario() {
    const rol = this.authService.usuarioActual()?.rol;
    return rol ? this.etiquetaRol(rol) : "";
  }
  get inicialesUsuario() {
    return iniciales(this.nombreUsuario);
  }
  cerrarMenuAlHacerClickFuera() {
    this.menuAbierto = false;
  }
  alternarMenu(evento) {
    evento.stopPropagation();
    this.menuAbierto = !this.menuAbierto;
  }
  abrirModalPassword() {
    this.menuAbierto = false;
    this.passwordActual = "";
    this.passwordNueva = "";
    this.passwordConfirmar = "";
    this.errorPassword = "";
    this.mostrarModalPassword = true;
  }
  cerrarModalPassword() {
    if (this.cambioObligatorio) {
      this.toast.advertencia("Debes actualizar tu contrase\xF1a temporal antes de continuar.");
      return;
    }
    this.mostrarModalPassword = false;
  }
  get cumpleLongitud() {
    return this.passwordNueva.length >= 8;
  }
  get cumpleMayuscula() {
    return /[A-Z]/.test(this.passwordNueva);
  }
  get cumpleNumero() {
    return /\d/.test(this.passwordNueva);
  }
  get cumpleCoinciden() {
    return this.passwordNueva.length > 0 && this.passwordNueva === this.passwordConfirmar;
  }
  guardarPassword() {
    this.errorPassword = "";
    if (!this.passwordActual) {
      this.errorPassword = "Ingresa tu contrase\xF1a actual.";
      return;
    }
    if (!this.cumpleLongitud || !this.cumpleMayuscula || !this.cumpleNumero) {
      this.errorPassword = "La nueva contrase\xF1a no cumple los requisitos.";
      return;
    }
    if (!this.cumpleCoinciden) {
      this.errorPassword = "La confirmaci\xF3n no coincide con la nueva contrase\xF1a.";
      return;
    }
    this.guardandoPassword = true;
    this.perfilService.cambiarPassword({
      passwordActual: this.passwordActual,
      passwordNueva: this.passwordNueva
    }).subscribe({
      next: () => {
        this.guardandoPassword = false;
        this.cambioObligatorio = false;
        this.mostrarModalPassword = false;
        this.authService.marcarPasswordActualizada();
        this.toast.exito("Contrase\xF1a actualizada correctamente.");
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.guardandoPassword = false;
        this.errorPassword = err?.error?.mensaje ?? "No se pudo actualizar la contrase\xF1a.";
        this.cdr.detectChanges();
      }
    });
  }
  cerrarSesion() {
    this.authService.logout();
    this.router.navigate(["/login"]);
  }
  static \u0275fac = function RecepcionLayout_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _RecepcionLayout)(\u0275\u0275directiveInject(AuthRevisionService), \u0275\u0275directiveInject(PerfilService), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _RecepcionLayout, selectors: [["app-recepcion-layout"]], hostBindings: function RecepcionLayout_HostBindings(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275listener("click", function RecepcionLayout_click_HostBindingHandler() {
        return ctx.cerrarMenuAlHacerClickFuera();
      }, \u0275\u0275resolveDocument);
    }
  }, decls: 49, vars: 8, consts: [[1, "topbar"], [1, "topbar-marca"], [1, "topbar-marca-punto"], [1, "dropdown"], [1, "perfil-boton", 3, "click"], [1, "avatar"], [1, "perfil-texto"], [1, "perfil-nombre"], [1, "perfil-rol"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["points", "6 9 12 15 18 9"], [1, "dropdown-menu"], [1, "layout"], [1, "sidebar"], [1, "marca"], [1, "marca-escudo"], [1, "marca-texto"], ["routerLink", "/", "routerLinkActive", "activo", 3, "routerLinkActiveOptions"], ["d", "M4 4h16v16H4z", "opacity", "0"], ["d", "M22 6l-10 7L2 6"], ["x", "2", "y", "4", "width", "20", "height", "16", "rx", "2"], [1, "punto-notificacion"], ["routerLink", "/historial", "routerLinkActive", "activo"], ["d", "M3 12a9 9 0 1 0 3-6.7"], ["points", "3 4 3 9 8 9"], ["points", "12 7 12 12 16 14"], ["routerLink", "/registro-manual", "routerLinkActive", "activo"], ["d", "M12 20h9"], ["d", "M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"], [1, "contenido"], [1, "modal-overlay"], [1, "dropdown-menu", 3, "click"], [3, "click"], ["cx", "7.5", "cy", "15.5", "r", "5.5"], ["d", "M21 2l-9.6 9.6"], ["d", "M15.5 7.5L18 5"], ["d", "M17 3l4 4"], [1, "dropdown-separador"], [1, "peligro", 3, "click"], ["d", "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"], ["points", "16 17 21 12 16 7"], ["x1", "21", "y1", "12", "x2", "9", "y2", "12"], [1, "modal", "card", 3, "click"], [1, "modal-header"], ["aria-label", "Cerrar", 1, "modal-cerrar"], [1, "aviso-inline"], [1, "input-group"], [1, "campo-password"], ["name", "passwordActual", 3, "ngModelChange", "type", "ngModel"], ["type", "button", 1, "alternar-password", 3, "click"], ["name", "passwordNueva", 3, "ngModelChange", "type", "ngModel"], [1, "requisitos-password"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "3", "stroke-linecap", "round", "stroke-linejoin", "round"], ["points", "20 6 9 17 4 12"], ["type", "password", "name", "passwordConfirmar", 3, "ngModelChange", "ngModel"], [1, "mensaje-campo"], [1, "modal-acciones"], [1, "btn-primary", 3, "click", "disabled"], [1, "btn-secondary"], ["aria-label", "Cerrar", 1, "modal-cerrar", 3, "click"], [1, "btn-secondary", 3, "click"]], template: function RecepcionLayout_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "header", 0)(1, "div", 1);
      \u0275\u0275element(2, "span", 2);
      \u0275\u0275elementStart(3, "span");
      \u0275\u0275text(4, "Defensor\xEDa de los Derechos Polit\xE9cnicos");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(5, "div", 3)(6, "button", 4);
      \u0275\u0275listener("click", function RecepcionLayout_Template_button_click_6_listener($event) {
        return ctx.alternarMenu($event);
      });
      \u0275\u0275elementStart(7, "span", 5);
      \u0275\u0275text(8);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(9, "span", 6)(10, "span", 7);
      \u0275\u0275text(11);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(12, "span", 8);
      \u0275\u0275text(13);
      \u0275\u0275elementEnd()();
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(14, "svg", 9);
      \u0275\u0275element(15, "polyline", 10);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(16, RecepcionLayout_Conditional_16_Template, 15, 0, "div", 11);
      \u0275\u0275elementEnd()();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(17, "div", 12)(18, "aside", 13)(19, "div", 14)(20, "div", 15);
      \u0275\u0275text(21, "DDP");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(22, "div", 16)(23, "strong");
      \u0275\u0275text(24, "Panel de Revisi\xF3n");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(25, "span");
      \u0275\u0275text(26);
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(27, "nav")(28, "a", 17);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(29, "svg", 9);
      \u0275\u0275element(30, "path", 18)(31, "path", 19)(32, "rect", 20);
      \u0275\u0275elementEnd();
      \u0275\u0275text(33, " Bandeja de Entrada ");
      \u0275\u0275namespaceHTML();
      \u0275\u0275element(34, "span", 21);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(35, "a", 22);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(36, "svg", 9);
      \u0275\u0275element(37, "path", 23)(38, "polyline", 24)(39, "polyline", 25);
      \u0275\u0275elementEnd();
      \u0275\u0275text(40, " Historial ");
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(41, "a", 26);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(42, "svg", 9);
      \u0275\u0275element(43, "path", 27)(44, "path", 28);
      \u0275\u0275elementEnd();
      \u0275\u0275text(45, " Registro Manual ");
      \u0275\u0275elementEnd()()();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(46, "main", 29);
      \u0275\u0275element(47, "router-outlet");
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(48, RecepcionLayout_Conditional_48_Template, 46, 20, "div", 30);
    }
    if (rf & 2) {
      \u0275\u0275advance(8);
      \u0275\u0275textInterpolate(ctx.inicialesUsuario);
      \u0275\u0275advance(3);
      \u0275\u0275textInterpolate(ctx.nombreUsuario);
      \u0275\u0275advance(2);
      \u0275\u0275textInterpolate(ctx.rolUsuario);
      \u0275\u0275advance(3);
      \u0275\u0275conditional(ctx.menuAbierto ? 16 : -1);
      \u0275\u0275advance(10);
      \u0275\u0275textInterpolate(ctx.rolUsuario);
      \u0275\u0275advance(2);
      \u0275\u0275property("routerLinkActiveOptions", \u0275\u0275pureFunction0(7, _c0));
      \u0275\u0275advance(20);
      \u0275\u0275conditional(ctx.mostrarModalPassword ? 48 : -1);
    }
  }, dependencies: [CommonModule, FormsModule, DefaultValueAccessor, NgControlStatus, NgModel, RouterLink, RouterLinkActive, RouterOutlet], styles: ["\n[_nghost-%COMP%] {\n  display: block;\n  min-height: 100vh;\n}\n.topbar[_ngcontent-%COMP%] {\n  background: #fff;\n  border-bottom: 1px solid var(--borde);\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 16px;\n  padding: 10px 24px;\n  position: sticky;\n  top: 0;\n  z-index: 100;\n}\n.topbar-marca[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: var(--texto-suave);\n}\n.topbar-marca-punto[_ngcontent-%COMP%] {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: var(--exito);\n}\n.perfil-boton[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: none;\n  border: none;\n  padding: 5px 8px;\n  border-radius: 8px;\n}\n.perfil-boton[_ngcontent-%COMP%]:hover {\n  background: var(--gris-fondo);\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-texto[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  line-height: 1.2;\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-nombre[_ngcontent-%COMP%] {\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.perfil-boton[_ngcontent-%COMP%]   .perfil-rol[_ngcontent-%COMP%] {\n  font-size: 0.72rem;\n  color: var(--guinda-vivo);\n  font-weight: 600;\n}\n.perfil-boton[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.layout[_ngcontent-%COMP%] {\n  display: flex;\n  min-height: calc(100vh - 53px);\n}\n.sidebar[_ngcontent-%COMP%] {\n  width: 240px;\n  background: var(--sidebar-fondo);\n  padding: 18px 0;\n  flex-shrink: 0;\n}\n.sidebar[_ngcontent-%COMP%]   .marca[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  padding: 0 20px 22px;\n  margin-bottom: 6px;\n  border-bottom: 1px solid rgba(255, 255, 255, 0.08);\n}\n.sidebar[_ngcontent-%COMP%]   .marca-escudo[_ngcontent-%COMP%] {\n  width: 38px;\n  height: 38px;\n  border-radius: 8px;\n  background:\n    linear-gradient(\n      135deg,\n      var(--guinda-vivo),\n      var(--guinda-oscuro));\n  color: #fff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 700;\n  font-size: 0.72rem;\n  letter-spacing: 0.5px;\n  flex-shrink: 0;\n}\n.sidebar[_ngcontent-%COMP%]   .marca-texto[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  line-height: 1.25;\n}\n.sidebar[_ngcontent-%COMP%]   .marca-texto[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #fff;\n  font-size: 0.9rem;\n}\n.sidebar[_ngcontent-%COMP%]   .marca-texto[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: var(--sidebar-texto);\n  font-size: 0.72rem;\n}\n.sidebar[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%] {\n  padding-top: 8px;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  color: var(--sidebar-texto);\n  text-decoration: none;\n  padding: 12px 22px;\n  font-size: 0.87rem;\n  border-left: 3px solid transparent;\n  transition: background 0.15s ease, color 0.15s ease;\n  position: relative;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n  flex-shrink: 0;\n  opacity: 0.85;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   .punto-notificacion[_ngcontent-%COMP%] {\n  width: 7px;\n  height: 7px;\n  border-radius: 50%;\n  background: var(--guinda-vivo);\n  margin-left: auto;\n}\n.sidebar[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  background: rgba(255, 255, 255, 0.05);\n  color: #fff;\n}\n.sidebar[_ngcontent-%COMP%]   a.activo[_ngcontent-%COMP%] {\n  background: var(--sidebar-fondo-activo);\n  color: #fff;\n  font-weight: 600;\n  border-left-color: var(--guinda-vivo);\n}\n.sidebar[_ngcontent-%COMP%]   a.activo[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  opacity: 1;\n}\n.contenido[_ngcontent-%COMP%] {\n  flex: 1;\n  padding: 30px 34px;\n  max-width: 1180px;\n}\n/*# sourceMappingURL=recepcion-layout.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RecepcionLayout, [{
    type: Component,
    args: [{ selector: "app-recepcion-layout", standalone: true, imports: [CommonModule, FormsModule, RouterLink, RouterLinkActive, RouterOutlet], template: `<header class="topbar">
  <div class="topbar-marca">
    <span class="topbar-marca-punto"></span>
    <span>Defensor\xEDa de los Derechos Polit\xE9cnicos</span>
  </div>

  <div class="dropdown">
    <button class="perfil-boton" (click)="alternarMenu($event)">
      <span class="avatar">{{ inicialesUsuario }}</span>
      <span class="perfil-texto">
        <span class="perfil-nombre">{{ nombreUsuario }}</span>
        <span class="perfil-rol">{{ rolUsuario }}</span>
      </span>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
    </button>

    @if (menuAbierto) {
      <div class="dropdown-menu" (click)="$event.stopPropagation()">
        <button (click)="abrirModalPassword()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="5.5"></circle><path d="M21 2l-9.6 9.6"></path><path d="M15.5 7.5L18 5"></path><path d="M17 3l4 4"></path></svg>
          Cambiar contrase\xF1a
        </button>
        <div class="dropdown-separador"></div>
        <button class="peligro" (click)="cerrarSesion()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
          Cerrar sesi\xF3n
        </button>
      </div>
    }
  </div>
</header>

<div class="layout">
  <aside class="sidebar">
    <div class="marca">
      <div class="marca-escudo">DDP</div>
      <div class="marca-texto">
        <strong>Panel de Revisi\xF3n</strong>
        <span>{{ rolUsuario }}</span>
      </div>
    </div>

    <nav>
      <a routerLink="/" routerLinkActive="activo" [routerLinkActiveOptions]="{ exact: true }">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v16H4z" opacity="0"></path><path d="M22 6l-10 7L2 6"></path><rect x="2" y="4" width="20" height="16" rx="2"></rect></svg>
        Bandeja de Entrada
        <span class="punto-notificacion"></span>
      </a>
      <a routerLink="/historial" routerLinkActive="activo">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7"></path><polyline points="3 4 3 9 8 9"></polyline><polyline points="12 7 12 12 16 14"></polyline></svg>
        Historial
      </a>
      <a routerLink="/registro-manual" routerLinkActive="activo">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"></path></svg>
        Registro Manual
      </a>
    </nav>
  </aside>

  <main class="contenido">
    <router-outlet />
  </main>
</div>

@if (mostrarModalPassword) {
  <div class="modal-overlay">
    <div class="modal card" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>{{ cambioObligatorio ? 'Actualiza tu contrase\xF1a temporal' : 'Cambiar mi contrase\xF1a' }}</h3>
        @if (!cambioObligatorio) {
          <button class="modal-cerrar" (click)="cerrarModalPassword()" aria-label="Cerrar">\u2715</button>
        }
      </div>

      @if (cambioObligatorio) {
        <p class="aviso-inline">
          Tu cuenta tiene una contrase\xF1a temporal. Debes establecer una nueva antes de continuar
          usando el panel.
        </p>
      }

      <div class="input-group">
        <label>Contrase\xF1a actual</label>
        <div class="campo-password">
          <input
            [type]="mostrarActual ? 'text' : 'password'"
            [(ngModel)]="passwordActual"
            name="passwordActual"
          />
          <button
            type="button"
            class="alternar-password"
            (click)="mostrarActual = !mostrarActual"
          >{{ mostrarActual ? '\u{1F648}' : '\u{1F441}\uFE0F' }}</button>
        </div>
      </div>

      <div class="input-group">
        <label>Contrase\xF1a nueva</label>
        <div class="campo-password">
          <input
            [type]="mostrarNueva ? 'text' : 'password'"
            [(ngModel)]="passwordNueva"
            name="passwordNueva"
          />
          <button
            type="button"
            class="alternar-password"
            (click)="mostrarNueva = !mostrarNueva"
          >{{ mostrarNueva ? '\u{1F648}' : '\u{1F441}\uFE0F' }}</button>
        </div>
      </div>

      <ul class="requisitos-password">
        <li [class.cumplido]="cumpleLongitud">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Al menos 8 caracteres
        </li>
        <li [class.cumplido]="cumpleMayuscula">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Una letra may\xFAscula
        </li>
        <li [class.cumplido]="cumpleNumero">
          <span class="marca"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></span>
          Un n\xFAmero
        </li>
      </ul>

      <div class="input-group">
        <label>Confirmar contrase\xF1a nueva</label>
        <input type="password" [(ngModel)]="passwordConfirmar" name="passwordConfirmar" />
      </div>

      @if (errorPassword) {
        <p class="mensaje-campo">{{ errorPassword }}</p>
      }

      <div class="modal-acciones">
        <button class="btn-primary" (click)="guardarPassword()" [disabled]="guardandoPassword">
          {{ guardandoPassword ? 'Guardando\u2026' : 'Actualizar Contrase\xF1a' }}
        </button>
        @if (!cambioObligatorio) {
          <button class="btn-secondary" (click)="cerrarModalPassword()">Cancelar</button>
        }
      </div>
    </div>
  </div>
}
`, styles: ["/* src/app/pages/recepcion-layout/recepcion-layout.scss */\n:host {\n  display: block;\n  min-height: 100vh;\n}\n.topbar {\n  background: #fff;\n  border-bottom: 1px solid var(--borde);\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 16px;\n  padding: 10px 24px;\n  position: sticky;\n  top: 0;\n  z-index: 100;\n}\n.topbar-marca {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: var(--texto-suave);\n}\n.topbar-marca-punto {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: var(--exito);\n}\n.perfil-boton {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  background: none;\n  border: none;\n  padding: 5px 8px;\n  border-radius: 8px;\n}\n.perfil-boton:hover {\n  background: var(--gris-fondo);\n}\n.perfil-boton .perfil-texto {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  line-height: 1.2;\n}\n.perfil-boton .perfil-nombre {\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.perfil-boton .perfil-rol {\n  font-size: 0.72rem;\n  color: var(--guinda-vivo);\n  font-weight: 600;\n}\n.perfil-boton svg {\n  width: 16px;\n  height: 16px;\n  color: var(--texto-suave);\n}\n.layout {\n  display: flex;\n  min-height: calc(100vh - 53px);\n}\n.sidebar {\n  width: 240px;\n  background: var(--sidebar-fondo);\n  padding: 18px 0;\n  flex-shrink: 0;\n}\n.sidebar .marca {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  padding: 0 20px 22px;\n  margin-bottom: 6px;\n  border-bottom: 1px solid rgba(255, 255, 255, 0.08);\n}\n.sidebar .marca-escudo {\n  width: 38px;\n  height: 38px;\n  border-radius: 8px;\n  background:\n    linear-gradient(\n      135deg,\n      var(--guinda-vivo),\n      var(--guinda-oscuro));\n  color: #fff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 700;\n  font-size: 0.72rem;\n  letter-spacing: 0.5px;\n  flex-shrink: 0;\n}\n.sidebar .marca-texto {\n  display: flex;\n  flex-direction: column;\n  line-height: 1.25;\n}\n.sidebar .marca-texto strong {\n  color: #fff;\n  font-size: 0.9rem;\n}\n.sidebar .marca-texto span {\n  color: var(--sidebar-texto);\n  font-size: 0.72rem;\n}\n.sidebar nav {\n  padding-top: 8px;\n}\n.sidebar a {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  color: var(--sidebar-texto);\n  text-decoration: none;\n  padding: 12px 22px;\n  font-size: 0.87rem;\n  border-left: 3px solid transparent;\n  transition: background 0.15s ease, color 0.15s ease;\n  position: relative;\n}\n.sidebar a svg {\n  width: 18px;\n  height: 18px;\n  flex-shrink: 0;\n  opacity: 0.85;\n}\n.sidebar a .punto-notificacion {\n  width: 7px;\n  height: 7px;\n  border-radius: 50%;\n  background: var(--guinda-vivo);\n  margin-left: auto;\n}\n.sidebar a:hover {\n  background: rgba(255, 255, 255, 0.05);\n  color: #fff;\n}\n.sidebar a.activo {\n  background: var(--sidebar-fondo-activo);\n  color: #fff;\n  font-weight: 600;\n  border-left-color: var(--guinda-vivo);\n}\n.sidebar a.activo svg {\n  opacity: 1;\n}\n.contenido {\n  flex: 1;\n  padding: 30px 34px;\n  max-width: 1180px;\n}\n/*# sourceMappingURL=recepcion-layout.css.map */\n"] }]
  }], () => [{ type: AuthRevisionService }, { type: PerfilService }, { type: Router }, { type: ToastService }, { type: ChangeDetectorRef }], { cerrarMenuAlHacerClickFuera: [{
    type: HostListener,
    args: ["document:click"]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(RecepcionLayout, { className: "RecepcionLayout", filePath: "src/app/pages/recepcion-layout/recepcion-layout.ts", lineNumber: 18 });
})();
export {
  RecepcionLayout
};
//# sourceMappingURL=chunk-23P3GRZK.js.map
