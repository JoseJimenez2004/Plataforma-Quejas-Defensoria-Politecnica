import {
  AuthRevisionService
} from "./chunk-JXDKWF54.js";
import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgControlStatusGroup,
  NgForm,
  NgModel,
  ɵNgNoValidate
} from "./chunk-BJ6JQKEH.js";
import {
  Router
} from "./chunk-F26HINUV.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  ToastService,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-FT7UGDQZ.js";

// src/app/pages/login/login.ts
function Login_Conditional_50_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(0, "svg", 18);
    \u0275\u0275element(1, "path", 30)(2, "path", 31);
    \u0275\u0275elementEnd();
  }
}
function Login_Conditional_51_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(0, "svg", 18);
    \u0275\u0275element(1, "path", 32)(2, "circle", 33);
    \u0275\u0275elementEnd();
  }
}
function Login_Conditional_52_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 26);
    \u0275\u0275text(1, "Bloq May\xFAs est\xE1 activado");
    \u0275\u0275elementEnd();
  }
}
function Login_Conditional_53_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 27);
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(1, "svg", 18);
    \u0275\u0275element(2, "circle", 34)(3, "path", 35);
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(4, "span");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r0.error);
  }
}
function Login_Conditional_55_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "span", 36);
    \u0275\u0275text(1, " Verificando\u2026 ");
  }
}
function Login_Conditional_56_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Entrar al panel ");
  }
}
var Login = class _Login {
  authService;
  router;
  toast;
  cdr;
  correo = "";
  password = "";
  mostrarPassword = false;
  cargando = false;
  error = "";
  errorCorreo = false;
  errorPassword = false;
  mayusculasActivas = false;
  constructor(authService, router, toast, cdr) {
    this.authService = authService;
    this.router = router;
    this.toast = toast;
    this.cdr = cdr;
  }
  limpiarError() {
    this.error = "";
    this.errorCorreo = false;
    this.errorPassword = false;
  }
  revisarMayusculas(evento) {
    this.mayusculasActivas = !!evento.getModifierState?.("CapsLock");
  }
  ingresar() {
    if (this.cargando) {
      return;
    }
    this.limpiarError();
    const correo = this.correo.trim();
    this.errorCorreo = !correo;
    this.errorPassword = !this.password;
    if (this.errorCorreo || this.errorPassword) {
      this.error = this.errorCorreo && this.errorPassword ? "Escribe tu correo institucional y tu contrase\xF1a." : this.errorCorreo ? "Escribe tu correo institucional." : "Escribe tu contrase\xF1a.";
      return;
    }
    this.cargando = true;
    this.authService.login({ correo, password: this.password }).subscribe({
      next: (resp) => {
        this.cargando = false;
        switch (resp.rol) {
          case "RECEPCIONISTA":
            this.router.navigate(["/"]);
            break;
          case "ANALISTA_PRIMER_CONTACTO":
            window.location.assign("/primer-contacto/");
            break;
          case "SUBDEFENSOR":
            window.location.assign("/subdefensoria/");
            break;
          case "ADMIN_SISTEMAS":
            this.toast.advertencia("Tu cuenta corresponde a Administraci\xF3n. Utiliza la consola administrativa.");
            break;
          case "DEFENSOR":
            this.toast.advertencia("La vista correspondiente al rol Defensor todav\xEDa no est\xE1 disponible.");
            break;
          default:
            this.toast.advertencia("No existe una pantalla configurada para este rol.");
            break;
        }
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.cargando = false;
        if (!err?.status || err.status >= 500) {
          this.error = "No pudimos conectar con el servidor. Intenta de nuevo en unos minutos.";
        } else {
          this.error = err?.error?.mensaje ?? "Correo o contrase\xF1a incorrectos.";
          this.errorPassword = true;
        }
        this.cdr.detectChanges();
      }
    });
  }
  static \u0275fac = function Login_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Login)(\u0275\u0275directiveInject(AuthRevisionService), \u0275\u0275directiveInject(Router), \u0275\u0275directiveInject(ToastService), \u0275\u0275directiveInject(ChangeDetectorRef));
  };
  static \u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _Login, selectors: [["app-login"]], decls: 59, vars: 16, consts: [[1, "acceso"], ["aria-hidden", "true", 1, "acceso-marca"], [1, "marca-contenido"], [1, "marca-sello"], ["viewBox", "0 0 48 48", "fill", "none", "stroke", "currentColor", "stroke-width", "2.4", "stroke-linejoin", "round"], ["d", "M24 4 7 10v12c0 11 7.4 18.6 17 22 9.6-3.4 17-11 17-22V10L24 4Z"], ["d", "M16 24.5 21.5 30 32 19", "stroke-linecap", "round"], [1, "marca-ipn"], [1, "marca-texto"], [1, "marca-areas"], [1, "marca-pie"], [1, "acceso-form"], ["novalidate", "", 1, "tarjeta", 3, "submit"], [1, "sello-movil"], [1, "tarjeta-sub"], [1, "campo"], [1, "campo-etiqueta"], [1, "campo-control"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round"], ["x", "3", "y", "5", "width", "18", "height", "14", "rx", "2"], ["d", "m3 7 9 6 9-6"], ["type", "email", "name", "correo", "autocomplete", "username", "placeholder", "nombre@ipn.mx", 3, "ngModelChange", "input", "ngModel"], ["x", "4", "y", "11", "width", "16", "height", "10", "rx", "2"], ["d", "M8 11V7a4 4 0 0 1 8 0v4"], ["name", "password", "autocomplete", "current-password", "placeholder", "Tu contrase\xF1a", 3, "ngModelChange", "input", "keyup", "keydown", "type", "ngModel"], ["type", "button", 1, "alternar", 3, "click", "title"], [1, "aviso-mayus"], ["role", "alert", 1, "alerta"], ["type", "submit", 1, "boton-entrar", 3, "disabled"], [1, "ayuda"], ["d", "M17.9 17.9A10.4 10.4 0 0 1 12 20c-6.5 0-10-8-10-8a18 18 0 0 1 5.1-5.9M9.9 4.2A9.7 9.7 0 0 1 12 4c6.5 0 10 8 10 8a18 18 0 0 1-2.2 3.2M14.1 14.1a3 3 0 1 1-4.2-4.2"], ["d", "m2 2 20 20"], ["d", "M2 12s3.5-8 10-8 10 8 10 8-3.5 8-10 8S2 12 2 12Z"], ["cx", "12", "cy", "12", "r", "3"], ["cx", "12", "cy", "12", "r", "10"], ["d", "M12 8v4M12 16h.01"], ["aria-hidden", "true", 1, "spinner"]], template: function Login_Template(rf, ctx) {
    if (rf & 1) {
      \u0275\u0275elementStart(0, "div", 0)(1, "aside", 1)(2, "div", 2)(3, "div", 3);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(4, "svg", 4);
      \u0275\u0275element(5, "path", 5)(6, "path", 6);
      \u0275\u0275elementEnd()();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(7, "p", 7);
      \u0275\u0275text(8, "Instituto Polit\xE9cnico Nacional");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(9, "h1");
      \u0275\u0275text(10, "Defensor\xEDa de los Derechos Polit\xE9cnicos");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(11, "p", 8);
      \u0275\u0275text(12, "Panel del personal para la atenci\xF3n y seguimiento de quejas.");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(13, "ul", 9)(14, "li");
      \u0275\u0275element(15, "span");
      \u0275\u0275text(16, "Recepci\xF3n y validaci\xF3n");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(17, "li");
      \u0275\u0275element(18, "span");
      \u0275\u0275text(19, "Primer Contacto");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(20, "li");
      \u0275\u0275element(21, "span");
      \u0275\u0275text(22, "Subdefensor\xEDa");
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(23, "p", 10);
      \u0275\u0275text(24, "Uso exclusivo del personal autorizado. Los accesos quedan registrados.");
      \u0275\u0275elementEnd()();
      \u0275\u0275elementStart(25, "main", 11)(26, "form", 12);
      \u0275\u0275listener("submit", function Login_Template_form_submit_26_listener($event) {
        $event.preventDefault();
        return ctx.ingresar();
      });
      \u0275\u0275elementStart(27, "p", 13);
      \u0275\u0275text(28, "DDP \xB7 IPN");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(29, "h2");
      \u0275\u0275text(30, "Iniciar sesi\xF3n");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(31, "p", 14);
      \u0275\u0275text(32, "Ingresa con tu correo institucional y la contrase\xF1a asignada por Administraci\xF3n.");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(33, "label", 15)(34, "span", 16);
      \u0275\u0275text(35, "Correo institucional");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(36, "span", 17);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(37, "svg", 18);
      \u0275\u0275element(38, "rect", 19)(39, "path", 20);
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(40, "input", 21);
      \u0275\u0275twoWayListener("ngModelChange", function Login_Template_input_ngModelChange_40_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.correo, $event) || (ctx.correo = $event);
        return $event;
      });
      \u0275\u0275listener("input", function Login_Template_input_input_40_listener() {
        return ctx.limpiarError();
      });
      \u0275\u0275elementEnd()()();
      \u0275\u0275elementStart(41, "label", 15)(42, "span", 16);
      \u0275\u0275text(43, "Contrase\xF1a");
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(44, "span", 17);
      \u0275\u0275namespaceSVG();
      \u0275\u0275elementStart(45, "svg", 18);
      \u0275\u0275element(46, "rect", 22)(47, "path", 23);
      \u0275\u0275elementEnd();
      \u0275\u0275namespaceHTML();
      \u0275\u0275elementStart(48, "input", 24);
      \u0275\u0275twoWayListener("ngModelChange", function Login_Template_input_ngModelChange_48_listener($event) {
        \u0275\u0275twoWayBindingSet(ctx.password, $event) || (ctx.password = $event);
        return $event;
      });
      \u0275\u0275listener("input", function Login_Template_input_input_48_listener() {
        return ctx.limpiarError();
      })("keyup", function Login_Template_input_keyup_48_listener($event) {
        return ctx.revisarMayusculas($event);
      })("keydown", function Login_Template_input_keydown_48_listener($event) {
        return ctx.revisarMayusculas($event);
      });
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(49, "button", 25);
      \u0275\u0275listener("click", function Login_Template_button_click_49_listener() {
        return ctx.mostrarPassword = !ctx.mostrarPassword;
      });
      \u0275\u0275conditionalCreate(50, Login_Conditional_50_Template, 3, 0, ":svg:svg", 18)(51, Login_Conditional_51_Template, 3, 0, ":svg:svg", 18);
      \u0275\u0275elementEnd()();
      \u0275\u0275conditionalCreate(52, Login_Conditional_52_Template, 2, 0, "span", 26);
      \u0275\u0275elementEnd();
      \u0275\u0275conditionalCreate(53, Login_Conditional_53_Template, 6, 1, "div", 27);
      \u0275\u0275elementStart(54, "button", 28);
      \u0275\u0275conditionalCreate(55, Login_Conditional_55_Template, 2, 0)(56, Login_Conditional_56_Template, 1, 0);
      \u0275\u0275elementEnd();
      \u0275\u0275elementStart(57, "p", 29);
      \u0275\u0275text(58, "\xBFOlvidaste tu contrase\xF1a o tu cuenta est\xE1 bloqueada? Solicita el restablecimiento al \xE1rea de Administraci\xF3n de Sistemas.");
      \u0275\u0275elementEnd()()()();
    }
    if (rf & 2) {
      \u0275\u0275advance(33);
      \u0275\u0275classProp("campo-error", ctx.errorCorreo);
      \u0275\u0275advance(7);
      \u0275\u0275twoWayProperty("ngModel", ctx.correo);
      \u0275\u0275attribute("aria-invalid", ctx.errorCorreo);
      \u0275\u0275advance();
      \u0275\u0275classProp("campo-error", ctx.errorPassword);
      \u0275\u0275advance(7);
      \u0275\u0275property("type", ctx.mostrarPassword ? "text" : "password");
      \u0275\u0275twoWayProperty("ngModel", ctx.password);
      \u0275\u0275attribute("aria-invalid", ctx.errorPassword);
      \u0275\u0275advance();
      \u0275\u0275property("title", ctx.mostrarPassword ? "Ocultar contrase\xF1a" : "Mostrar contrase\xF1a");
      \u0275\u0275attribute("aria-label", ctx.mostrarPassword ? "Ocultar contrase\xF1a" : "Mostrar contrase\xF1a");
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.mostrarPassword ? 50 : 51);
      \u0275\u0275advance(2);
      \u0275\u0275conditional(ctx.mayusculasActivas ? 52 : -1);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.error ? 53 : -1);
      \u0275\u0275advance();
      \u0275\u0275property("disabled", ctx.cargando);
      \u0275\u0275advance();
      \u0275\u0275conditional(ctx.cargando ? 55 : 56);
    }
  }, dependencies: [CommonModule, FormsModule, \u0275NgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, NgModel, NgForm], styles: ["\n[_nghost-%COMP%] {\n  display: block;\n}\n.acceso[_ngcontent-%COMP%] {\n  min-height: 100vh;\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);\n  background: var(--gris-fondo);\n}\n.acceso-marca[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  padding: 56px 56px 32px;\n  color: #fff;\n  overflow: hidden;\n  background:\n    radial-gradient(\n      circle at 85% 15%,\n      rgba(212, 175, 55, 0.22),\n      transparent 42%),\n    radial-gradient(rgba(255, 255, 255, 0.07) 1px, transparent 1px) 0 0/22px 22px,\n    linear-gradient(\n      155deg,\n      var(--guinda-vivo) 0%,\n      var(--guinda) 45%,\n      var(--guinda-oscuro) 100%);\n}\n.marca-contenido[_ngcontent-%COMP%] {\n  max-width: 440px;\n  margin: auto 0;\n}\n.marca-sello[_ngcontent-%COMP%] {\n  width: 64px;\n  height: 64px;\n  display: grid;\n  place-items: center;\n  border-radius: 18px;\n  background: rgba(255, 255, 255, 0.12);\n  border: 1px solid rgba(255, 255, 255, 0.25);\n  margin-bottom: 28px;\n}\n.marca-sello[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 34px;\n  height: 34px;\n  color: #f3d98b;\n}\n.marca-ipn[_ngcontent-%COMP%] {\n  margin: 0 0 8px;\n  font-size: 0.78rem;\n  letter-spacing: 0.14em;\n  text-transform: uppercase;\n  color: rgba(255, 255, 255, 0.7);\n}\n.acceso-marca[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%] {\n  color: #fff;\n  margin: 0 0 14px;\n  font-size: 2.1rem;\n  line-height: 1.15;\n  font-weight: 700;\n}\n.marca-texto[_ngcontent-%COMP%] {\n  margin: 0 0 32px;\n  font-size: 1rem;\n  line-height: 1.5;\n  color: rgba(255, 255, 255, 0.82);\n}\n.marca-areas[_ngcontent-%COMP%] {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 12px;\n}\n.marca-areas[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  font-size: 0.92rem;\n  color: rgba(255, 255, 255, 0.9);\n}\n.marca-areas[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: #f3d98b;\n  box-shadow: 0 0 0 4px rgba(243, 217, 139, 0.18);\n}\n.marca-pie[_ngcontent-%COMP%] {\n  margin: 32px 0 0;\n  font-size: 0.75rem;\n  color: rgba(255, 255, 255, 0.55);\n}\n.acceso-form[_ngcontent-%COMP%] {\n  display: grid;\n  place-items: center;\n  padding: 32px 20px;\n}\n.tarjeta[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 400px;\n  background: #fff;\n  border-radius: 16px;\n  padding: 40px 36px 32px;\n  box-shadow: var(--sombra-alta);\n}\n.tarjeta[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0 0 6px;\n  font-size: 1.55rem;\n  color: var(--negro-inst);\n}\n.sello-movil[_ngcontent-%COMP%] {\n  display: none;\n  margin: 0 0 18px;\n  font-size: 0.75rem;\n  font-weight: 700;\n  letter-spacing: 0.14em;\n  color: var(--guinda);\n}\n.tarjeta-sub[_ngcontent-%COMP%] {\n  margin: 0 0 28px;\n  font-size: 0.88rem;\n  line-height: 1.45;\n  color: var(--texto-suave);\n}\n.campo[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 18px;\n}\n.campo-etiqueta[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 6px;\n  font-size: 0.82rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.campo-control[_ngcontent-%COMP%] {\n  position: relative;\n  display: flex;\n  align-items: center;\n}\n.campo-control[_ngcontent-%COMP%]    > svg[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 13px;\n  width: 18px;\n  height: 18px;\n  color: #9aa0aa;\n  pointer-events: none;\n}\n.campo-control[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 46px;\n  padding: 0 44px 0 42px;\n  border: 1.5px solid var(--borde);\n  border-radius: 10px;\n  font: inherit;\n  font-size: 0.95rem;\n  color: var(--texto);\n  background: #fafbfc;\n  transition:\n    border-color 0.15s ease,\n    box-shadow 0.15s ease,\n    background 0.15s ease;\n}\n.campo-control[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]:focus {\n  outline: none;\n  border-color: var(--guinda-vivo);\n  background: #fff;\n  box-shadow: 0 0 0 4px rgba(157, 36, 73, 0.12);\n}\n.campo-error[_ngcontent-%COMP%]   .campo-control[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  border-color: var(--peligro);\n}\n.alternar[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 6px;\n  width: 34px;\n  height: 34px;\n  display: grid;\n  place-items: center;\n  border: none;\n  border-radius: 8px;\n  background: transparent;\n  color: #7a808a;\n  cursor: pointer;\n}\n.alternar[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  width: 18px;\n  height: 18px;\n}\n.alternar[_ngcontent-%COMP%]:hover, \n.alternar[_ngcontent-%COMP%]:focus-visible {\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  outline: none;\n}\n.aviso-mayus[_ngcontent-%COMP%] {\n  display: block;\n  margin-top: 6px;\n  font-size: 0.78rem;\n  font-weight: 600;\n  color: var(--advertencia);\n}\n.alerta[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  align-items: flex-start;\n  margin: 4px 0 18px;\n  padding: 11px 12px;\n  border-radius: 10px;\n  background: #fdecec;\n  color: var(--peligro);\n  font-size: 0.85rem;\n  line-height: 1.4;\n}\n.alerta[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\n  flex-shrink: 0;\n  width: 18px;\n  height: 18px;\n}\n.boton-entrar[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 48px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 10px;\n  border: none;\n  border-radius: 10px;\n  background: var(--guinda);\n  color: #fff;\n  font: inherit;\n  font-size: 0.98rem;\n  font-weight: 600;\n  cursor: pointer;\n  transition: background 0.15s ease, transform 0.1s ease;\n}\n.boton-entrar[_ngcontent-%COMP%]:hover:not(:disabled) {\n  background: var(--guinda-vivo);\n}\n.boton-entrar[_ngcontent-%COMP%]:active:not(:disabled) {\n  transform: translateY(1px);\n}\n.boton-entrar[_ngcontent-%COMP%]:disabled {\n  opacity: 0.75;\n  cursor: progress;\n}\n.spinner[_ngcontent-%COMP%] {\n  width: 16px;\n  height: 16px;\n  border: 2px solid rgba(255, 255, 255, 0.35);\n  border-top-color: #fff;\n  border-radius: 50%;\n  animation: _ngcontent-%COMP%_girar 0.7s linear infinite;\n}\n@keyframes _ngcontent-%COMP%_girar {\n  to {\n    transform: rotate(360deg);\n  }\n}\n.ayuda[_ngcontent-%COMP%] {\n  margin: 20px 0 0;\n  font-size: 0.78rem;\n  line-height: 1.45;\n  text-align: center;\n  color: var(--texto-suave);\n}\n@media (max-width: 860px) {\n  .acceso[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n  .acceso-marca[_ngcontent-%COMP%] {\n    display: none;\n  }\n  .acceso-form[_ngcontent-%COMP%] {\n    min-height: 100vh;\n    place-items: start center;\n    padding-top: 56px;\n    background:\n      linear-gradient(\n        180deg,\n        var(--guinda) 0,\n        var(--guinda) 150px,\n        var(--gris-fondo) 150px);\n  }\n  .sello-movil[_ngcontent-%COMP%] {\n    display: block;\n  }\n  .tarjeta[_ngcontent-%COMP%] {\n    padding: 32px 22px 26px;\n  }\n}\n/*# sourceMappingURL=login.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Login, [{
    type: Component,
    args: [{ selector: "app-login", standalone: true, imports: [CommonModule, FormsModule], template: `<div class="acceso">
  <!-- Panel institucional -->
  <aside class="acceso-marca" aria-hidden="true">
    <div class="marca-contenido">
      <div class="marca-sello">
        <svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round">
          <path d="M24 4 7 10v12c0 11 7.4 18.6 17 22 9.6-3.4 17-11 17-22V10L24 4Z" />
          <path d="M16 24.5 21.5 30 32 19" stroke-linecap="round" />
        </svg>
      </div>
      <p class="marca-ipn">Instituto Polit\xE9cnico Nacional</p>
      <h1>Defensor\xEDa de los Derechos Polit\xE9cnicos</h1>
      <p class="marca-texto">Panel del personal para la atenci\xF3n y seguimiento de quejas.</p>

      <ul class="marca-areas">
        <li><span></span>Recepci\xF3n y validaci\xF3n</li>
        <li><span></span>Primer Contacto</li>
        <li><span></span>Subdefensor\xEDa</li>
      </ul>
    </div>
    <p class="marca-pie">Uso exclusivo del personal autorizado. Los accesos quedan registrados.</p>
  </aside>

  <!-- Formulario -->
  <main class="acceso-form">
    <form class="tarjeta" (submit)="$event.preventDefault(); ingresar()" novalidate>
      <p class="sello-movil">DDP \xB7 IPN</p>
      <h2>Iniciar sesi\xF3n</h2>
      <p class="tarjeta-sub">Ingresa con tu correo institucional y la contrase\xF1a asignada por Administraci\xF3n.</p>

      <label class="campo" [class.campo-error]="errorCorreo">
        <span class="campo-etiqueta">Correo institucional</span>
        <span class="campo-control">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>
          <input
            type="email"
            [(ngModel)]="correo"
            name="correo"
            autocomplete="username"
            placeholder="nombre@ipn.mx"
            (input)="limpiarError()"
            [attr.aria-invalid]="errorCorreo"
          />
        </span>
      </label>

      <label class="campo" [class.campo-error]="errorPassword">
        <span class="campo-etiqueta">Contrase\xF1a</span>
        <span class="campo-control">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>
          <input
            [type]="mostrarPassword ? 'text' : 'password'"
            [(ngModel)]="password"
            name="password"
            autocomplete="current-password"
            placeholder="Tu contrase\xF1a"
            (input)="limpiarError()"
            (keyup)="revisarMayusculas($event)"
            (keydown)="revisarMayusculas($event)"
            [attr.aria-invalid]="errorPassword"
          />
          <button
            type="button"
            class="alternar"
            (click)="mostrarPassword = !mostrarPassword"
            [attr.aria-label]="mostrarPassword ? 'Ocultar contrase\xF1a' : 'Mostrar contrase\xF1a'"
            [title]="mostrarPassword ? 'Ocultar contrase\xF1a' : 'Mostrar contrase\xF1a'"
          >
            @if (mostrarPassword) {
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.4 10.4 0 0 1 12 20c-6.5 0-10-8-10-8a18 18 0 0 1 5.1-5.9M9.9 4.2A9.7 9.7 0 0 1 12 4c6.5 0 10 8 10 8a18 18 0 0 1-2.2 3.2M14.1 14.1a3 3 0 1 1-4.2-4.2"/><path d="m2 2 20 20"/></svg>
            } @else {
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-8 10-8 10 8 10 8-3.5 8-10 8S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>
            }
          </button>
        </span>
        @if (mayusculasActivas) {
          <span class="aviso-mayus">Bloq May\xFAs est\xE1 activado</span>
        }
      </label>

      @if (error) {
        <div class="alerta" role="alert">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
          <span>{{ error }}</span>
        </div>
      }

      <button type="submit" class="boton-entrar" [disabled]="cargando">
        @if (cargando) {
          <span class="spinner" aria-hidden="true"></span> Verificando\u2026
        } @else {
          Entrar al panel
        }
      </button>

      <p class="ayuda">\xBFOlvidaste tu contrase\xF1a o tu cuenta est\xE1 bloqueada? Solicita el restablecimiento al \xE1rea de Administraci\xF3n de Sistemas.</p>
    </form>
  </main>
</div>
`, styles: ["/* src/app/pages/login/login.scss */\n:host {\n  display: block;\n}\n.acceso {\n  min-height: 100vh;\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);\n  background: var(--gris-fondo);\n}\n.acceso-marca {\n  position: relative;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  padding: 56px 56px 32px;\n  color: #fff;\n  overflow: hidden;\n  background:\n    radial-gradient(\n      circle at 85% 15%,\n      rgba(212, 175, 55, 0.22),\n      transparent 42%),\n    radial-gradient(rgba(255, 255, 255, 0.07) 1px, transparent 1px) 0 0/22px 22px,\n    linear-gradient(\n      155deg,\n      var(--guinda-vivo) 0%,\n      var(--guinda) 45%,\n      var(--guinda-oscuro) 100%);\n}\n.marca-contenido {\n  max-width: 440px;\n  margin: auto 0;\n}\n.marca-sello {\n  width: 64px;\n  height: 64px;\n  display: grid;\n  place-items: center;\n  border-radius: 18px;\n  background: rgba(255, 255, 255, 0.12);\n  border: 1px solid rgba(255, 255, 255, 0.25);\n  margin-bottom: 28px;\n}\n.marca-sello svg {\n  width: 34px;\n  height: 34px;\n  color: #f3d98b;\n}\n.marca-ipn {\n  margin: 0 0 8px;\n  font-size: 0.78rem;\n  letter-spacing: 0.14em;\n  text-transform: uppercase;\n  color: rgba(255, 255, 255, 0.7);\n}\n.acceso-marca h1 {\n  color: #fff;\n  margin: 0 0 14px;\n  font-size: 2.1rem;\n  line-height: 1.15;\n  font-weight: 700;\n}\n.marca-texto {\n  margin: 0 0 32px;\n  font-size: 1rem;\n  line-height: 1.5;\n  color: rgba(255, 255, 255, 0.82);\n}\n.marca-areas {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n  display: grid;\n  gap: 12px;\n}\n.marca-areas li {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  font-size: 0.92rem;\n  color: rgba(255, 255, 255, 0.9);\n}\n.marca-areas span {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: #f3d98b;\n  box-shadow: 0 0 0 4px rgba(243, 217, 139, 0.18);\n}\n.marca-pie {\n  margin: 32px 0 0;\n  font-size: 0.75rem;\n  color: rgba(255, 255, 255, 0.55);\n}\n.acceso-form {\n  display: grid;\n  place-items: center;\n  padding: 32px 20px;\n}\n.tarjeta {\n  width: 100%;\n  max-width: 400px;\n  background: #fff;\n  border-radius: 16px;\n  padding: 40px 36px 32px;\n  box-shadow: var(--sombra-alta);\n}\n.tarjeta h2 {\n  margin: 0 0 6px;\n  font-size: 1.55rem;\n  color: var(--negro-inst);\n}\n.sello-movil {\n  display: none;\n  margin: 0 0 18px;\n  font-size: 0.75rem;\n  font-weight: 700;\n  letter-spacing: 0.14em;\n  color: var(--guinda);\n}\n.tarjeta-sub {\n  margin: 0 0 28px;\n  font-size: 0.88rem;\n  line-height: 1.45;\n  color: var(--texto-suave);\n}\n.campo {\n  display: block;\n  margin-bottom: 18px;\n}\n.campo-etiqueta {\n  display: block;\n  margin-bottom: 6px;\n  font-size: 0.82rem;\n  font-weight: 600;\n  color: var(--texto);\n}\n.campo-control {\n  position: relative;\n  display: flex;\n  align-items: center;\n}\n.campo-control > svg {\n  position: absolute;\n  left: 13px;\n  width: 18px;\n  height: 18px;\n  color: #9aa0aa;\n  pointer-events: none;\n}\n.campo-control input {\n  width: 100%;\n  height: 46px;\n  padding: 0 44px 0 42px;\n  border: 1.5px solid var(--borde);\n  border-radius: 10px;\n  font: inherit;\n  font-size: 0.95rem;\n  color: var(--texto);\n  background: #fafbfc;\n  transition:\n    border-color 0.15s ease,\n    box-shadow 0.15s ease,\n    background 0.15s ease;\n}\n.campo-control input:focus {\n  outline: none;\n  border-color: var(--guinda-vivo);\n  background: #fff;\n  box-shadow: 0 0 0 4px rgba(157, 36, 73, 0.12);\n}\n.campo-error .campo-control input {\n  border-color: var(--peligro);\n}\n.alternar {\n  position: absolute;\n  right: 6px;\n  width: 34px;\n  height: 34px;\n  display: grid;\n  place-items: center;\n  border: none;\n  border-radius: 8px;\n  background: transparent;\n  color: #7a808a;\n  cursor: pointer;\n}\n.alternar svg {\n  width: 18px;\n  height: 18px;\n}\n.alternar:hover,\n.alternar:focus-visible {\n  background: var(--guinda-suave);\n  color: var(--guinda);\n  outline: none;\n}\n.aviso-mayus {\n  display: block;\n  margin-top: 6px;\n  font-size: 0.78rem;\n  font-weight: 600;\n  color: var(--advertencia);\n}\n.alerta {\n  display: flex;\n  gap: 10px;\n  align-items: flex-start;\n  margin: 4px 0 18px;\n  padding: 11px 12px;\n  border-radius: 10px;\n  background: #fdecec;\n  color: var(--peligro);\n  font-size: 0.85rem;\n  line-height: 1.4;\n}\n.alerta svg {\n  flex-shrink: 0;\n  width: 18px;\n  height: 18px;\n}\n.boton-entrar {\n  width: 100%;\n  height: 48px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 10px;\n  border: none;\n  border-radius: 10px;\n  background: var(--guinda);\n  color: #fff;\n  font: inherit;\n  font-size: 0.98rem;\n  font-weight: 600;\n  cursor: pointer;\n  transition: background 0.15s ease, transform 0.1s ease;\n}\n.boton-entrar:hover:not(:disabled) {\n  background: var(--guinda-vivo);\n}\n.boton-entrar:active:not(:disabled) {\n  transform: translateY(1px);\n}\n.boton-entrar:disabled {\n  opacity: 0.75;\n  cursor: progress;\n}\n.spinner {\n  width: 16px;\n  height: 16px;\n  border: 2px solid rgba(255, 255, 255, 0.35);\n  border-top-color: #fff;\n  border-radius: 50%;\n  animation: girar 0.7s linear infinite;\n}\n@keyframes girar {\n  to {\n    transform: rotate(360deg);\n  }\n}\n.ayuda {\n  margin: 20px 0 0;\n  font-size: 0.78rem;\n  line-height: 1.45;\n  text-align: center;\n  color: var(--texto-suave);\n}\n@media (max-width: 860px) {\n  .acceso {\n    grid-template-columns: 1fr;\n  }\n  .acceso-marca {\n    display: none;\n  }\n  .acceso-form {\n    min-height: 100vh;\n    place-items: start center;\n    padding-top: 56px;\n    background:\n      linear-gradient(\n        180deg,\n        var(--guinda) 0,\n        var(--guinda) 150px,\n        var(--gris-fondo) 150px);\n  }\n  .sello-movil {\n    display: block;\n  }\n  .tarjeta {\n    padding: 32px 22px 26px;\n  }\n}\n/*# sourceMappingURL=login.css.map */\n"] }]
  }], () => [{ type: AuthRevisionService }, { type: Router }, { type: ToastService }, { type: ChangeDetectorRef }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(Login, { className: "Login", filePath: "src/app/pages/login/login.ts", lineNumber: 16 });
})();
export {
  Login
};
//# sourceMappingURL=chunk-KA3DD7EH.js.map
